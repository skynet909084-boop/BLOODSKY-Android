package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Build;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class h extends ImageView implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    String C;
    String D;
    String E;
    String F;
    String G;
    String H;
    String I;
    String J;
    String K;
    String L;
    String M;
    String N;
    String O;
    String P;
    int Q;
    int R;
    int S;
    boolean T;
    int U;
    int V;
    private long W;
    public String a;
    public Point a0;
    int b;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public byte f8797d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public b f8798e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8799f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f8800g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f8801h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    Bitmap f8802i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    Paint f8803j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    Paint f8804k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    int f8805l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8806m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8807n;
    String o;

    class a implements f.b.a.t.f<File, Bitmap> {
        a() {
        }

        @Override // f.b.a.t.f
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public boolean b(Exception exc, File file, f.b.a.t.j.j<Bitmap> jVar, boolean z) {
            Toast.makeText(h.this.getContext(), h.this.getResources().getString(R.string.custom_dyn_pictures_error_load_pictures), 1).show();
            h.this.a();
            return true;
        }

        @Override // f.b.a.t.f
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public boolean a(Bitmap bitmap, File file, f.b.a.t.j.j<Bitmap> jVar, boolean z, boolean z2) {
            return false;
        }
    }

    public h(Context context) {
        super(context);
        this.a = getResources().getString(R.string.custom_dyn_pictures);
        this.b = 17;
        this.f8797d = (byte) 3;
        this.f8798e = new b();
        this.f8802i = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.f8803j = new Paint();
        this.f8804k = new Paint();
        this.f8805l = 0;
        this.f8806m = 0;
        this.f8807n = "";
        this.o = "";
        this.C = "";
        this.D = "";
        this.E = "";
        this.F = "";
        this.G = "";
        this.H = "";
        this.I = "";
        this.J = "";
        this.K = "";
        this.L = "";
        this.M = "";
        this.N = "";
        this.O = "";
        this.P = "";
        this.Q = 0;
        this.R = 0;
        this.S = 0;
        this.T = false;
        this.U = 0;
        this.V = 0;
        this.W = 0L;
        this.a0 = new Point();
    }

    private void setPicture(String str) {
        if (str.length() == 0) {
            return;
        }
        try {
            f.b.a.b<File> bVarK = f.b.a.i.v(getContext()).t(new File(str)).K();
            bVarK.E(new a());
            bVarK.n(this);
        } catch (Exception unused) {
            a();
        }
    }

    public void a() {
        setImageDrawable(Build.VERSION.SDK_INT >= 21 ? getResources().getDrawable(R.drawable.no_picture, null) : getResources().getDrawable(R.drawable.no_picture));
    }

    public void b(boolean z) {
        this.Q = 0;
        if (!z) {
            if (this.f8807n.equals("")) {
                a();
            } else {
                setPicture(this.f8807n);
            }
            if (mbCanvas.a1 == this.f8799f) {
                setVisibility(0);
            }
        } else if (this.f8807n.equals("")) {
            setVisibility(4);
        } else {
            setPicture(this.f8807n);
        }
        invalidate();
    }

    public String c(int i2) {
        switch (i2) {
            case 0:
                return this.f8807n;
            case 1:
                return this.o;
            case 2:
                return this.C;
            case 3:
                return this.D;
            case 4:
                return this.E;
            case 5:
                return this.F;
            case 6:
                return this.G;
            case 7:
                return this.H;
            case 8:
                return this.I;
            case 9:
                return this.J;
            case 10:
                return this.K;
            case 11:
                return this.L;
            case 12:
                return this.M;
            case 13:
                return this.N;
            case 14:
                return this.O;
            case 15:
                return this.P;
            default:
                return "";
        }
    }

    public void d(int i2, int i3, int i4, boolean z) {
        setScaleType(ImageView.ScaleType.FIT_XY);
        setPadding(10, 10, 10, 10);
        setImageDrawable(Build.VERSION.SDK_INT >= 21 ? getResources().getDrawable(R.drawable.no_picture, null) : getResources().getDrawable(R.drawable.no_picture));
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setKey(i4);
        this.f8798e.A(this.b);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.a0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e(String str, int i2) {
        switch (i2) {
            case 0:
                this.f8807n = str;
            case 1:
                this.o = str;
            case 2:
                this.C = str;
            case 3:
                this.D = str;
            case 4:
                this.E = str;
            case 5:
                this.F = str;
            case 6:
                this.G = str;
            case 7:
                this.H = str;
            case 8:
                this.I = str;
            case 9:
                this.J = str;
            case 10:
                this.K = str;
            case 11:
                this.L = str;
            case 12:
                this.M = str;
            case 13:
                this.N = str;
            case 14:
                this.O = str;
            case 15:
                this.P = str;
                break;
        }
    }

    public void f(int i2, int i3) {
        this.f8805l = i2;
        this.f8806m = i3;
    }

    public void g(int i2, int i3) {
        int i4 = this.f8805l;
        if (i4 > 9 && i4 < ru.himik.nightscream.kascada.q.d.b.E) {
            if (i2 >= 0) {
                MyApplication.b().v0.f9265j[this.f8805l] = Math.min((int) ((i2 / getWidth()) * 100.0f), 100);
            } else {
                MyApplication.b().v0.f9265j[this.f8805l] = 0;
            }
        }
        int i5 = this.f8806m;
        if (i5 <= 9 || i5 >= ru.himik.nightscream.kascada.q.d.b.E) {
            return;
        }
        int[] iArr = MyApplication.b().v0.f9265j;
        if (i3 >= 0) {
            iArr[this.f8806m] = 100 - Math.min((int) ((i3 / getHeight()) * 100.0f), 100);
        } else {
            iArr[this.f8806m] = 100;
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8798e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8799f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.U;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8798e.l());
        jSONObject.put("addressRegister", this.f8798e.c());
        jSONObject.put("addressBit", (int) this.f8798e.a());
        jSONObject.put("typeRequest", (int) this.f8798e.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("pathPic_0", c(0));
        jSONObject.put("pathPic_1", c(1));
        jSONObject.put("pathPic_2", c(2));
        jSONObject.put("pathPic_3", c(3));
        jSONObject.put("pathPic_4", c(4));
        jSONObject.put("pathPic_5", c(5));
        jSONObject.put("pathPic_6", c(6));
        jSONObject.put("pathPic_7", c(7));
        jSONObject.put("pathPic_8", c(8));
        jSONObject.put("pathPic_9", c(9));
        jSONObject.put("pathPic_10", c(10));
        jSONObject.put("pathPic_11", c(11));
        jSONObject.put("pathPic_12", c(12));
        jSONObject.put("pathPic_13", c(13));
        jSONObject.put("pathPic_14", c(14));
        jSONObject.put("pathPic_15", c(15));
        jSONObject.put("typeCommand", getTypeCommand());
        jSONObject.put("timeZ", getTimeZ());
        jSONObject.put("regTouchX", getRegTouchX());
        jSONObject.put("regTouchY", getRegTouchY());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.c;
    }

    public int getNumScreen() {
        return this.f8799f;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.a0;
    }

    public int getRegTouchX() {
        return this.f8805l;
    }

    public int getRegTouchY() {
        return this.f8806m;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8798e.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8798e.l() >= 100) {
            this.f8798e.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8798e.c();
        }
        this.f8798e.u((byte) MyApplication.b().E.get(this.f8798e.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8798e.b()) + "#" + this.f8798e.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8798e.l() >= 0) {
            if (this.f8798e.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8798e.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.W;
    }

    public int getTypeCommand() {
        return this.S;
    }

    public int getValueWeb() {
        return this.R;
    }

    /* JADX WARN: Code duplicated, block: B:82:0x0100  */
    /* JADX WARN: Failed to find 'out' block for switch in B:18:0x002f. Please report as an issue. */
    public void h(int i2, boolean z) {
        String str;
        if (z) {
            this.R = i2;
            if (this.S == 1 && i2 == 0 && getVisibility() != 4) {
                setVisibility(4);
                invalidate();
            }
            if (this.Q == i2) {
                return;
            }
            this.Q = i2;
            if (this.S != 0) {
                for (int i3 = 0; i3 <= 15; i3++) {
                    if (((i2 >> i3) & 1) == 1) {
                        if (getVisibility() == 4 && this.f8799f == mbCanvas.a1) {
                            setVisibility(0);
                        }
                        switch (i3) {
                            case 0:
                                if (this.f8807n.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.f8807n);
                                    return;
                                }
                            case 1:
                                if (this.o.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.o);
                                    return;
                                }
                            case 2:
                                if (this.C.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.C);
                                    return;
                                }
                            case 3:
                                if (this.D.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.D);
                                    return;
                                }
                            case 4:
                                if (this.E.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.E);
                                    return;
                                }
                            case 5:
                                if (this.F.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.F);
                                    return;
                                }
                            case 6:
                                if (this.G.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.G);
                                    return;
                                }
                            case 7:
                                if (this.H.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.H);
                                    return;
                                }
                            case 8:
                                if (this.I.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.I);
                                    return;
                                }
                            case 9:
                                if (this.J.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.J);
                                    return;
                                }
                            case 10:
                                if (this.K.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.K);
                                    return;
                                }
                            case 11:
                                if (this.L.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.L);
                                    return;
                                }
                            case 12:
                                if (this.M.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.M);
                                    return;
                                }
                            case 13:
                                if (this.N.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.N);
                                    return;
                                }
                            case 14:
                                if (this.O.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.O);
                                    return;
                                }
                            case 15:
                                if (this.P.equals("")) {
                                    a();
                                    return;
                                } else {
                                    setPicture(this.P);
                                    return;
                                }
                        }
                    }
                }
                setVisibility(4);
                return;
            }
            if (i2 < 0 || i2 > 15) {
                setVisibility(4);
                return;
            }
            switch (i2) {
                case 0:
                    if (this.f8807n.equals("")) {
                        a();
                    } else {
                        str = this.f8807n;
                        setPicture(str);
                    }
                    break;
                case 1:
                    if (this.o.equals("")) {
                        a();
                    } else {
                        str = this.o;
                        setPicture(str);
                    }
                    break;
                case 2:
                    if (this.C.equals("")) {
                        a();
                    } else {
                        str = this.C;
                        setPicture(str);
                    }
                    break;
                case 3:
                    if (this.D.equals("")) {
                        a();
                    } else {
                        str = this.D;
                        setPicture(str);
                    }
                    break;
                case 4:
                    if (this.E.equals("")) {
                        a();
                    } else {
                        str = this.E;
                        setPicture(str);
                    }
                    break;
                case 5:
                    if (this.F.equals("")) {
                        a();
                    } else {
                        str = this.F;
                        setPicture(str);
                    }
                    break;
                case 6:
                    if (this.G.equals("")) {
                        a();
                    } else {
                        str = this.G;
                        setPicture(str);
                    }
                    break;
                case 7:
                    if (this.H.equals("")) {
                        a();
                    } else {
                        str = this.H;
                        setPicture(str);
                    }
                    break;
                case 8:
                    if (this.I.equals("")) {
                        a();
                    } else {
                        str = this.I;
                        setPicture(str);
                    }
                    break;
                case 9:
                    if (this.J.equals("")) {
                        a();
                    } else {
                        str = this.J;
                        setPicture(str);
                    }
                    break;
                case 10:
                    if (this.K.equals("")) {
                        a();
                    } else {
                        str = this.K;
                        setPicture(str);
                    }
                    break;
                case 11:
                    if (this.L.equals("")) {
                        a();
                    } else {
                        str = this.L;
                        setPicture(str);
                    }
                    break;
                case 12:
                    if (this.M.equals("")) {
                        a();
                    } else {
                        str = this.M;
                        setPicture(str);
                    }
                    break;
                case 13:
                    if (this.N.equals("")) {
                        a();
                    } else {
                        str = this.N;
                        setPicture(str);
                    }
                    break;
                case 14:
                    if (this.O.equals("")) {
                        a();
                    } else {
                        str = this.O;
                        setPicture(str);
                    }
                    break;
                case 15:
                    if (this.P.equals("")) {
                        a();
                    } else {
                        str = this.P;
                        setPicture(str);
                    }
                    break;
            }
            if (getVisibility() == 4 && this.f8799f == mbCanvas.a1) {
                setVisibility(0);
            }
        }
    }

    @Override // android.widget.ImageView, android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8801h) {
            this.f8804k.setColor(-65536);
            this.f8804k.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f8804k);
        }
        if (this.f8800g && mbCanvas.g1) {
            canvas.drawBitmap(this.f8802i, (getWidth() / 2) - (this.f8802i.getWidth() / 2), (getHeight() / 2) - this.f8802i.getHeight(), this.f8803j);
        }
        if (this.T) {
            this.f8804k.setColor(-16711936);
            this.f8804k.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f8804k);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.T;
    }

    public void setConnectionError(boolean z) {
        this.f8801h = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8800g = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.T = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.U = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.V = i2;
    }

    public void setFont(String str) {
    }

    public void setIdComponent(int i2) {
        this.b = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.c = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8799f = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.W = j2;
    }

    public void setTypeCommand(int i2) {
        this.S = i2;
    }
}
