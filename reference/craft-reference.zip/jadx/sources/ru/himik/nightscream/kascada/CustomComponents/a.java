package ru.himik.nightscream.kascada.CustomComponents;

/* JADX INFO: loaded from: classes2.dex */
public class a {
    private int a;
    private int b;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8704d;

    public int a() {
        return this.f8704d;
    }

    public int b() {
        return this.c;
    }

    public int c() {
        return this.a;
    }

    public int d() {
        return this.b;
    }

    public void e(int i2) {
    }

    public void f(int i2) {
    }

    public void g(int i2) {
    }

    public void h(int i2) {
        this.f8704d = i2;
    }

    public void i(int i2) {
        this.c = i2;
    }

    public void j(String str) {
    }

    public void k(int i2) {
    }

    public void l(int i2) {
    }

    public void m(int i2) {
    }

    public void n(int i2) {
        this.a = i2;
    }

    public void o(int i2) {
        this.b = i2;
    }

    public void p(int i2) {
    }

    public void q(int i2) {
    }

    public void r(int i2) {
    }

    public void s(String str) {
    }

    public void t(boolean z) {
    }

    public void u(int i2) {
    }

    public void v(int i2) {
    }

    public void w(int i2) {
    }
}
