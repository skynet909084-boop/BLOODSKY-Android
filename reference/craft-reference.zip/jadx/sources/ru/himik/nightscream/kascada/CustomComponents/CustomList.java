package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Connections.Usb.driver.FtdiSerialDriver;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class CustomList extends androidx.appcompat.widget.y implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    String C;
    String D;
    String E;
    String F;
    String G;
    String H;
    String I;
    String J;
    String K;
    String L;
    String M;
    String N;
    String O;
    String P;
    String Q;
    String R;
    int S;
    boolean T;
    boolean U;
    boolean V;
    int W;
    int a0;
    private long b0;
    public Point c0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f8683e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8684f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8685g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public byte f8686h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public b f8687i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f8688j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f8689k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f8690l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    Bitmap f8691m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    Paint f8692n;
    Paint o;

    public CustomList(Context context) {
        super(context);
        this.f8683e = getResources().getString(R.string.custom_list);
        this.f8684f = 20;
        this.f8686h = (byte) 6;
        this.f8687i = new b();
        this.f8691m = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.f8692n = new Paint();
        this.o = new Paint();
        this.C = "";
        this.D = "";
        this.E = "";
        this.F = "";
        this.G = "";
        this.H = "";
        this.I = "";
        this.J = "";
        this.K = "";
        this.L = "";
        this.M = "";
        this.N = "";
        this.O = "";
        this.P = "";
        this.Q = "";
        this.R = "";
        this.S = 0;
        this.T = true;
        this.U = false;
        this.V = false;
        this.W = 0;
        this.a0 = 0;
        this.b0 = 0L;
        this.c0 = new Point();
    }

    public CustomList(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f8683e = getResources().getString(R.string.custom_list);
        this.f8684f = 20;
        this.f8686h = (byte) 6;
        this.f8687i = new b();
        this.f8691m = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.f8692n = new Paint();
        this.o = new Paint();
        this.C = "";
        this.D = "";
        this.E = "";
        this.F = "";
        this.G = "";
        this.H = "";
        this.I = "";
        this.J = "";
        this.K = "";
        this.L = "";
        this.M = "";
        this.N = "";
        this.O = "";
        this.P = "";
        this.Q = "";
        this.R = "";
        this.S = 0;
        this.T = true;
        this.U = false;
        this.V = false;
        this.W = 0;
        this.a0 = 0;
        this.b0 = 0L;
        this.c0 = new Point();
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.c0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void f(int i2) {
        setText(getResources().getString(R.string.custom_list) + ": " + i2);
    }

    public boolean g(int i2) {
        return ((this.S >> i2) & 1) == 1;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8687i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8684f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8688j;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return getText().toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.a0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8684f;
    }

    public b getInitConnectionInfo() {
        b bVar = new b();
        bVar.A(getIdComponent());
        bVar.v(this.f8687i.c());
        bVar.L((byte) 3);
        bVar.C(getKey());
        bVar.K(0);
        bVar.F(this.f8687i.r());
        bVar.u(this.f8687i.b());
        bVar.x(new ru.himik.nightscream.kascada.x.a().c(bVar, this.f8687i.i()));
        return bVar;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8687i.l());
        jSONObject.put("addressRegister", this.f8687i.c());
        jSONObject.put("typeRequest", (int) this.f8687i.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("textBit", getTextValue());
        jSONObject.put("visibleInWork", k());
        jSONObject.put("checkNoChange", j());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8685g;
    }

    public int getNumScreen() {
        return this.f8688j;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.c0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8687i.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8687i.l() >= 100) {
            this.f8687i.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8687i.c();
        }
        this.f8687i.u((byte) MyApplication.b().E.get(this.f8687i.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8687i.b()) + "#" + this.f8687i.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8687i.l() >= 0) {
            if (this.f8687i.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8687i.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    public String getTextValue() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("textBit0", this.C);
            jSONObject.put("textBit1", this.D);
            jSONObject.put("textBit2", this.E);
            jSONObject.put("textBit3", this.F);
            jSONObject.put("textBit4", this.G);
            jSONObject.put("textBit5", this.H);
            jSONObject.put("textBit6", this.I);
            jSONObject.put("textBit7", this.J);
            jSONObject.put("textBit8", this.K);
            jSONObject.put("textBit9", this.L);
            jSONObject.put("textBit10", this.M);
            jSONObject.put("textBit11", this.N);
            jSONObject.put("textBit12", this.O);
            jSONObject.put("textBit13", this.P);
            jSONObject.put("textBit14", this.Q);
            jSONObject.put("textBit15", this.R);
        } catch (JSONException unused) {
        }
        return jSONObject.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.b0;
    }

    public int getValue() {
        return this.S;
    }

    public int getValueCheckNoChange() {
        this.S = this.C.length() > 0 ? this.S | 1 : this.S & (-2);
        this.S = this.D.length() > 0 ? this.S | 2 : this.S & (-3);
        this.S = this.E.length() > 0 ? this.S | 4 : this.S & (-5);
        this.S = this.F.length() > 0 ? this.S | 8 : this.S & (-9);
        this.S = this.G.length() > 0 ? this.S | 16 : this.S & (-17);
        this.S = this.H.length() > 0 ? this.S | 32 : this.S & (-33);
        this.S = this.I.length() > 0 ? this.S | 64 : this.S & (-65);
        this.S = this.J.length() > 0 ? this.S | FtdiSerialDriver.FtdiSerialPort.USB_ENDPOINT_IN : this.S & (-129);
        this.S = this.K.length() > 0 ? this.S | 256 : this.S & (-257);
        this.S = this.L.length() > 0 ? this.S | 512 : this.S & (-513);
        this.S = this.M.length() > 0 ? this.S | 1024 : this.S & (-1025);
        this.S = this.N.length() > 0 ? this.S | 2048 : this.S & (-2049);
        this.S = this.O.length() > 0 ? this.S | 4096 : this.S & (-4097);
        this.S = this.P.length() > 0 ? this.S | 8192 : this.S & (-8193);
        this.S = this.Q.length() > 0 ? this.S | 16384 : this.S & (-16385);
        this.S = this.R.length() > 0 ? this.S | 32768 : this.S & (-32769);
        return this.S;
    }

    public String h(int i2) {
        switch (i2) {
            case 0:
                return this.C;
            case 1:
                return this.D;
            case 2:
                return this.E;
            case 3:
                return this.F;
            case 4:
                return this.G;
            case 5:
                return this.H;
            case 6:
                return this.I;
            case 7:
                return this.J;
            case 8:
                return this.K;
            case 9:
                return this.L;
            case 10:
                return this.M;
            case 11:
                return this.N;
            case 12:
                return this.O;
            case 13:
                return this.P;
            case 14:
                return this.Q;
            case 15:
                return this.R;
            default:
                return "";
        }
    }

    public void i(int i2, int i3, int i4, boolean z) {
        setPadding((int) getResources().getDimension(R.dimen.margin_small), 10, 10, 10);
        setBackgroundResource(R.drawable.tab_list);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            f(i4);
        }
        setTextColor(getResources().getColor(R.color.text_black));
        setKey(i4);
        setGravity(19);
        this.f8687i.A(this.f8684f);
    }

    public boolean j() {
        return this.U;
    }

    public boolean k() {
        return this.T;
    }

    public boolean l(int i2) {
        if (g(i2)) {
            this.S = (~(1 << i2)) & this.S;
            return false;
        }
        this.S = (1 << i2) | this.S;
        return true;
    }

    public void m(String str, int i2) {
        switch (i2) {
            case 0:
                this.C = str;
                break;
            case 1:
                this.D = str;
                break;
            case 2:
                this.E = str;
                break;
            case 3:
                this.F = str;
                break;
            case 4:
                this.G = str;
                break;
            case 5:
                this.H = str;
                break;
            case 6:
                this.I = str;
                break;
            case 7:
                this.J = str;
                break;
            case 8:
                this.K = str;
                break;
            case 9:
                this.L = str;
                break;
            case 10:
                this.M = str;
                break;
            case 11:
                this.N = str;
                break;
            case 12:
                this.O = str;
                break;
            case 13:
                this.P = str;
                break;
            case 14:
                this.Q = str;
                break;
            case 15:
                this.R = str;
                break;
        }
        this.S = str.length() > 0 ? this.S | (1 << i2) : this.S & (~(1 << i2));
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8690l) {
            this.o.setColor(-65536);
            this.o.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.o);
        }
        if (this.f8689k && mbCanvas.g1) {
            canvas.drawBitmap(this.f8691m, getWidth() - this.f8691m.getWidth(), getHeight() - this.f8691m.getHeight(), this.f8692n);
        }
        if (this.V) {
            this.o.setColor(-16711936);
            this.o.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.o);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.V;
    }

    public void setBits(boolean[] zArr) {
    }

    public void setCheckNoChange(boolean z) {
        this.U = z;
    }

    public void setConnectionError(boolean z) {
        this.f8690l = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8689k = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.V = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.W = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.a0 = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8685g = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8688j = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.b0 = j2;
    }

    public void setValue(int i2) {
        this.S = i2;
    }

    public void setVisibleInWork(boolean z) {
        this.T = z;
    }
}
