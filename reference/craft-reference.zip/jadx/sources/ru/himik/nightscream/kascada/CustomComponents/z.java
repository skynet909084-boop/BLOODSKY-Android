package ru.himik.nightscream.kascada.CustomComponents;

import org.json.JSONObject;

/* JADX INFO: loaded from: classes2.dex */
public interface z {
    b getConnectionInfo();

    int getCurrentTextColor();

    int getCustomBackground();

    int getCustomHeight();

    int getCustomNumScreen();

    String getCustomText();

    int getCustomWidth();

    float getCustomX();

    float getCustomY();

    int getDiffX();

    int getDiffY();

    int getIdComponent();

    JSONObject getJsonConnectionInfo();

    JSONObject getJsonOther();

    JSONObject getJsonOtherForCopy();

    int getKey();

    String getStringAddress();

    String getStringNameDevice();

    float getTextSize();

    long getTimeZ();

    boolean p();

    void setCustomSelect(boolean z);

    void setCustomVisible(int i2);

    void setDiffX(int i2);

    void setDiffY(int i2);

    void setKey(int i2);

    void setNumScreen(int i2);

    void setTimeZ(long j2);

    void setX(float f2);

    void setY(float f2);
}
