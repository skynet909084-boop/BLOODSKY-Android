package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class w extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    ru.himik.nightscream.kascada.x.a C;
    private boolean D;
    private boolean E;
    Bitmap F;
    Paint G;
    Paint H;
    boolean I;
    boolean J;
    int K;
    int L;
    private long M;
    public Point N;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8918d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8919e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8920f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8921g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8922h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    String f8923i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    String f8924j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public b f8925k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    boolean f8926l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8927m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    int f8928n;
    boolean o;

    public w(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_sms);
        this.f8918d = 10;
        this.f8920f = (byte) 1;
        this.f8921g = new b();
        this.f8923i = "";
        this.f8924j = "";
        this.f8925k = new b();
        this.f8926l = false;
        this.f8927m = 0;
        this.f8928n = 1;
        this.o = false;
        this.C = new ru.himik.nightscream.kascada.x.a();
        this.F = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.G = new Paint();
        this.H = new Paint();
        this.I = false;
        this.J = false;
        this.K = 0;
        this.L = 0;
        this.M = 0L;
        this.N = new Point();
    }

    public void a(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_sms_out);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
        this.f8921g.A(this.f8918d);
    }

    public boolean b() {
        return this.f8926l;
    }

    public void c(String str) {
        mbCanvas.o(this.f8923i, this.f8924j + " " + str);
    }

    public void d(int[] iArr) {
        String str;
        int i2 = this.f8928n;
        int[] iArr2 = new int[i2];
        if (i2 * 2 != iArr.length) {
            mbCanvas.o(this.f8923i, this.f8924j + " ERROR: " + Arrays.toString(iArr));
            return;
        }
        String strReplace = this.f8924j;
        int i3 = 0;
        String str2 = "";
        if (strReplace.contains("%1")) {
            while (i3 < this.f8928n) {
                int i4 = i3 * 2;
                iArr2[i3] = (iArr[i4] * 256) + iArr[i4 + 1];
                StringBuilder sb = new StringBuilder();
                sb.append("%");
                int i5 = i3 + 1;
                sb.append(i5);
                strReplace = strReplace.replace(sb.toString(), iArr2[i3] + "");
                i3 = i5;
            }
            str = this.f8923i;
        } else {
            while (i3 < this.f8928n) {
                int i6 = i3 * 2;
                iArr2[i3] = (iArr[i6] * 256) + iArr[i6 + 1];
                str2 = str2 + " " + iArr2[i3];
                i3++;
            }
            str = this.f8923i;
            strReplace = this.f8924j + str2;
        }
        mbCanvas.o(str, strReplace);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.N.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e(int i2) {
        this.I = i2 == 1;
        if (this.f8923i.length() < 9) {
            return;
        }
        if (i2 == 1 && !this.o) {
            this.o = true;
            if (this.f8926l) {
                b bVar = new b();
                bVar.A(this.f8921g.h());
                bVar.F(this.f8921g.r());
                bVar.E(this.f8921g.l());
                bVar.u(this.f8921g.b());
                bVar.x(this.C.c(bVar, this.f8921g.i()));
                bVar.C(this.f8921g.j());
                bVar.D(this.f8921g.k());
                bVar.v(this.f8927m);
                int i3 = this.f8928n;
                if (i3 >= 1 && i3 <= 8) {
                    bVar.z((byte) i3);
                }
                bVar.L((byte) 3);
                bVar.A(100);
                mbCanvas.F(this.f8921g.k(), bVar);
            } else {
                mbCanvas.o(this.f8923i, this.f8924j);
            }
        }
        if (i2 == 0) {
            this.o = false;
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8921g;
    }

    public b getConnectionInfo2Sms() {
        return this.f8925k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8918d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8922h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8918d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8921g.l());
        jSONObject.put("addressRegister", this.f8921g.c());
        jSONObject.put("addressBit", (int) this.f8921g.a());
        jSONObject.put("typeRequest", (int) this.f8921g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("phone", getPhone());
        jSONObject.put("message", getMessage());
        jSONObject.put("option", b());
        jSONObject.put("optionRegister", getOptionRegister());
        jSONObject.put("optionCountRegister", getOptionCountRegister());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8919e;
    }

    public String getMessage() {
        return this.f8924j;
    }

    public int getNumScreen() {
        return this.f8922h;
    }

    public int getOptionCountRegister() {
        return this.f8928n;
    }

    public int getOptionRegister() {
        return this.f8927m;
    }

    public String getPhone() {
        return this.f8923i;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8921g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8921g.l() >= 100) {
            this.f8921g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8921g.c() + "." + ((int) this.f8921g.a());
        }
        this.f8921g.u((byte) MyApplication.b().E.get(this.f8921g.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8921g.b()) + "#" + this.f8921g.c() + "." + ((int) this.f8921g.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8921g.l() >= 0) {
            if (this.f8921g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8921g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.M;
    }

    public boolean getValue() {
        return this.I;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.E) {
            this.H.setColor(-65536);
            this.H.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.H);
        }
        if (this.D && mbCanvas.g1) {
            canvas.drawBitmap(this.F, getWidth() - this.F.getWidth(), getHeight() - this.F.getHeight(), this.G);
        }
        if (this.J) {
            this.H.setColor(-16711936);
            this.H.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.H);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.J;
    }

    public void setConnectionError(boolean z) {
        if (this.E != z) {
            this.E = z;
            setVisibility(z ? 0 : 4);
            invalidate();
        }
    }

    public void setConnectionInfo2Sms(b bVar) {
        this.f8925k = bVar;
    }

    public void setConnectionTimeOut(boolean z) {
        if (this.D != z) {
            this.D = z;
            setVisibility(z ? 0 : 4);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.J = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.K = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.L = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8919e = i2;
    }

    public void setMessage(String str) {
        this.f8924j = str;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8922h = i2;
    }

    public void setOption(boolean z) {
        this.f8926l = z;
    }

    public void setOptionCountRegister(int i2) {
        this.f8928n = i2;
    }

    public void setOptionRegister(int i2) {
        this.f8927m = i2;
    }

    public void setPhone(String str) {
        this.f8923i = str;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.M = j2;
    }
}
