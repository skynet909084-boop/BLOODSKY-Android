package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.c;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class FB_COMPARE extends c {
    boolean d0;
    int e0;

    public FB_COMPARE(Context context) {
        super(context);
        this.d0 = false;
        this.e0 = 1;
        setName(">");
        s("IN1", 2);
        t("IN2", 2);
        u("Q", 1);
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width_compare_arithmetic));
        this.f8972d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height_compare_arithmetic));
    }

    public FB_COMPARE(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = false;
        this.e0 = 1;
        setName(">");
        s("IN1", 2);
        t("IN2", 2);
        u("Q", 1);
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.c = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width_compare_arithmetic)));
            this.f8972d = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height_compare_arithmetic)));
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.d0 = false;
        invalidate();
    }

    /* JADX WARN: Code duplicated, block: B:18:0x003e  */
    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return;
        }
        try {
            boolean z = true;
            switch (this.e0) {
                case 1:
                    if (((Integer) this.f8975g.getOut()).intValue() <= ((Integer) this.f8976h.getOut()).intValue()) {
                        z = false;
                    }
                    this.d0 = z;
                    break;
                case 2:
                    if (((Integer) this.f8975g.getOut()).intValue() >= ((Integer) this.f8976h.getOut()).intValue()) {
                        z = false;
                    }
                    this.d0 = z;
                    break;
                case 3:
                    if (((Integer) this.f8975g.getOut()).intValue() > ((Integer) this.f8976h.getOut()).intValue()) {
                        z = false;
                    }
                    this.d0 = z;
                    break;
                case 4:
                    if (((Integer) this.f8975g.getOut()).intValue() < ((Integer) this.f8976h.getOut()).intValue()) {
                        z = false;
                    }
                    this.d0 = z;
                    break;
                case 5:
                    if (((Integer) this.f8975g.getOut()).intValue() != ((Integer) this.f8976h.getOut()).intValue()) {
                        z = false;
                    }
                    this.d0 = z;
                    break;
                case 6:
                    if (((Integer) this.f8975g.getOut()).intValue() == ((Integer) this.f8976h.getOut()).intValue()) {
                        z = false;
                    }
                    this.d0 = z;
                    break;
                default:
                    break;
            }
        } catch (Exception unused) {
        }
    }

    public int getActionExecute() {
        return this.e0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("compareAction", getActionExecute());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return null;
        }
        return Boolean.valueOf(this.f8973e ? !this.d0 : this.d0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceSmallPopupMenu;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a l(int i2) {
        if (i2 == 1) {
            return this.f8975g;
        }
        if (i2 != 2) {
            return null;
        }
        return this.f8976h;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.S.setStyle(Paint.Style.FILL);
        this.S.setColor(-7829368);
        this.S.setStrokeWidth(this.U);
        this.V.set(this.T, this.U, getWidth() - this.T, getHeight() - this.U);
        canvas.drawRect(this.V, this.S);
        this.S.setStyle(Paint.Style.STROKE);
        this.S.setColor(-16777216);
        canvas.drawRect(this.V, this.S);
        this.W.setTextAlign(Paint.Align.CENTER);
        this.W.setFlags(1);
        this.W.setTextSize(getHeight() / 3);
        canvas.drawText(this.L, getWidth() / 2, (int) ((getHeight() / 2) - ((this.W.descent() + this.W.ascent()) / 2.0f)), this.W);
        canvas.drawLine(0.0f, getHeight() / 4, this.T, getHeight() / 4, this.S);
        canvas.drawLine(0.0f, (getHeight() / 4) * 3, this.T, (getHeight() / 4) * 3, this.S);
        if (this.f8973e && this.R == 1) {
            canvas.drawCircle((getWidth() - this.T) + this.b0, ((getHeight() / 3) / 2) + (getHeight() / 3), this.b0, this.S);
            width = (getWidth() - this.T) + (this.b0 * 2);
        } else {
            width = getWidth() - this.T;
        }
        canvas.drawLine(width, ((getHeight() / 3) / 2) + (getHeight() / 3), getWidth(), ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        this.f8979k.set((int) getX(), ((int) getY()) + (getHeight() / 4));
        this.f8980l.set((int) getX(), ((int) getY()) + ((getHeight() / 4) * 3));
        this.f8981m.set(((int) getX()) + getWidth(), ((int) getY()) + ((getHeight() / 3) / 2) + (getHeight() / 3));
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
        String str;
        this.e0 = i2;
        switch (i2) {
            case 1:
                str = ">";
                break;
            case 2:
                str = "<";
                break;
            case 3:
                str = "<=";
                break;
            case 4:
                str = ">=";
                break;
            case 5:
                str = "=";
                break;
            case 6:
                str = "<>";
                break;
            default:
                invalidate();
        }
        setName(str);
        invalidate();
    }
}
