package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class CustomSound extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    String C;
    String D;
    String E;
    String F;
    String G;
    String H;
    MediaPlayer I;
    int J;
    boolean[] K;
    boolean[] L;
    int M;
    boolean N;
    int O;
    int P;
    private long Q;
    MediaPlayer.OnCompletionListener R;
    public Point S;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8693d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8694e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8695f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8696g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8697h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f8698i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f8699j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    Bitmap f8700k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    Paint f8701l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    Paint f8702m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8703n;
    String o;

    class a implements MediaPlayer.OnCompletionListener {
        a() {
        }

        @Override // android.media.MediaPlayer.OnCompletionListener
        public void onCompletion(MediaPlayer mediaPlayer) {
            CustomSound customSound = CustomSound.this;
            customSound.L[customSound.M] = true;
            customSound.M = -1;
        }
    }

    public CustomSound(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_sound);
        this.f8693d = 21;
        this.f8695f = (byte) 3;
        this.f8696g = new b();
        this.f8700k = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.f8701l = new Paint();
        this.f8702m = new Paint();
        this.f8703n = "";
        this.o = "";
        this.C = "";
        this.D = "";
        this.E = "";
        this.F = "";
        this.G = "";
        this.H = "";
        this.J = 0;
        this.K = new boolean[8];
        this.L = new boolean[8];
        this.M = -1;
        this.N = false;
        this.O = 0;
        this.P = 0;
        this.Q = 0L;
        this.R = new a();
        this.S = new Point();
    }

    public CustomSound(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.c = getResources().getString(R.string.custom_sound);
        this.f8693d = 21;
        this.f8695f = (byte) 3;
        this.f8696g = new b();
        this.f8700k = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.f8701l = new Paint();
        this.f8702m = new Paint();
        this.f8703n = "";
        this.o = "";
        this.C = "";
        this.D = "";
        this.E = "";
        this.F = "";
        this.G = "";
        this.H = "";
        this.J = 0;
        this.K = new boolean[8];
        this.L = new boolean[8];
        this.M = -1;
        this.N = false;
        this.O = 0;
        this.P = 0;
        this.Q = 0L;
        this.R = new a();
        this.S = new Point();
    }

    private void d(int i2) {
        this.I.setAudioStreamType(3);
        try {
            this.I.prepare();
            this.I.start();
            this.M = i2;
        } catch (Exception unused) {
            this.L[i2] = true;
        }
    }

    public String a(int i2) {
        switch (i2) {
            case 0:
                return this.f8703n;
            case 1:
                return this.o;
            case 2:
                return this.C;
            case 3:
                return this.D;
            case 4:
                return this.E;
            case 5:
                return this.F;
            case 6:
                return this.G;
            case 7:
                return this.H;
            default:
                return "";
        }
    }

    public void b() {
        MediaPlayer mediaPlayer = new MediaPlayer();
        this.I = mediaPlayer;
        mediaPlayer.setOnCompletionListener(this.R);
    }

    public void c(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_sound);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
        this.f8696g.A(this.f8693d);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.S.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e() {
        Arrays.fill(this.K, false);
        Arrays.fill(this.L, false);
        this.M = -1;
        MediaPlayer mediaPlayer = this.I;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.release();
                this.I = null;
            } catch (Exception e2) {
                if (ru.himik.nightscream.kascada.w.a.a) {
                    Log.d("kascada", "[Sound] ERROR sound onCompletion. " + e2.toString());
                }
            }
        }
    }

    public void f(String str, int i2) {
        switch (i2) {
            case 0:
                this.f8703n = str;
                break;
            case 1:
                this.o = str;
                break;
            case 2:
                this.C = str;
                break;
            case 3:
                this.D = str;
                break;
            case 4:
                this.E = str;
                break;
            case 5:
                this.F = str;
                break;
            case 6:
                this.G = str;
                break;
            case 7:
                this.H = str;
                break;
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8696g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8693d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8697h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.O;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8693d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8696g.l());
        jSONObject.put("addressRegister", this.f8696g.c());
        jSONObject.put("addressBit", (int) this.f8696g.a());
        jSONObject.put("typeRequest", (int) this.f8696g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("pathSound_0", a(0));
        jSONObject.put("pathSound_1", a(1));
        jSONObject.put("pathSound_2", a(2));
        jSONObject.put("pathSound_3", a(3));
        jSONObject.put("pathSound_4", a(4));
        jSONObject.put("pathSound_5", a(5));
        jSONObject.put("pathSound_6", a(6));
        jSONObject.put("pathSound_7", a(7));
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8694e;
    }

    public int getNumScreen() {
        return this.f8697h;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.S;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8696g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8696g.l() >= 100) {
            this.f8696g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8696g.c();
        }
        this.f8696g.u((byte) MyApplication.b().E.get(this.f8696g.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8696g.b()) + "#" + this.f8696g.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8696g.l() >= 0) {
            if (this.f8696g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8696g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.Q;
    }

    public int getValue() {
        return this.J;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8699j) {
            this.f8702m.setColor(-65536);
            this.f8702m.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f8702m);
        }
        if (this.f8698i && mbCanvas.g1) {
            canvas.drawBitmap(this.f8700k, getWidth() - this.f8700k.getWidth(), getHeight() - this.f8700k.getHeight(), this.f8701l);
        }
        if (this.N) {
            this.f8702m.setColor(-16711936);
            this.f8702m.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f8702m);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.N;
    }

    public void setConnectionError(boolean z) {
        this.f8699j = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8698i = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.N = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.O = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.P = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8694e = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8697h = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.Q = j2;
    }

    /* JADX WARN: Code duplicated, block: B:66:0x0137  */
    /* JADX WARN: Code duplicated, block: B:85:0x013b A[SYNTHETIC] */
    public void setValue(int i2) {
        MediaPlayer mediaPlayer;
        String str;
        this.J = i2;
        if (this.I == null) {
            return;
        }
        int i3 = 0;
        while (true) {
            boolean z = true;
            if (i3 >= 8) {
                break;
            }
            boolean[] zArr = this.K;
            if (((i2 >> i3) & 1) != 1) {
                z = false;
            }
            zArr[i3] = z;
            i3++;
        }
        for (int i4 = 0; i4 < 8 && !this.I.isPlaying(); i4++) {
            if (this.K[i4] && !this.L[i4]) {
                switch (i4) {
                    case 0:
                        if (this.f8703n.length() == 0) {
                            this.L[i4] = true;
                        } else {
                            this.I.reset();
                            mediaPlayer = this.I;
                            str = this.f8703n;
                            mediaPlayer.setDataSource(str);
                            d(i4);
                            if (!this.K[i4]) {
                                this.L[i4] = false;
                            }
                        }
                        break;
                    case 1:
                        if (this.o.length() == 0) {
                            this.L[i4] = true;
                        } else {
                            this.I.reset();
                            mediaPlayer = this.I;
                            str = this.o;
                            mediaPlayer.setDataSource(str);
                            d(i4);
                            if (!this.K[i4]) {
                                this.L[i4] = false;
                            }
                        }
                        break;
                    case 2:
                        if (this.C.length() == 0) {
                            this.L[i4] = true;
                        } else {
                            this.I.reset();
                            mediaPlayer = this.I;
                            str = this.C;
                            mediaPlayer.setDataSource(str);
                            d(i4);
                            if (!this.K[i4]) {
                                this.L[i4] = false;
                            }
                        }
                        break;
                    case 3:
                        if (this.D.length() == 0) {
                            this.L[i4] = true;
                        } else {
                            this.I.reset();
                            mediaPlayer = this.I;
                            str = this.D;
                            mediaPlayer.setDataSource(str);
                            d(i4);
                            if (!this.K[i4]) {
                                this.L[i4] = false;
                            }
                        }
                        break;
                    case 4:
                        if (this.E.length() == 0) {
                            this.L[i4] = true;
                        } else {
                            this.I.reset();
                            mediaPlayer = this.I;
                            str = this.E;
                            mediaPlayer.setDataSource(str);
                            d(i4);
                            if (!this.K[i4]) {
                                this.L[i4] = false;
                            }
                        }
                        break;
                    case 5:
                        if (this.F.length() == 0) {
                            this.L[i4] = true;
                        } else {
                            this.I.reset();
                            mediaPlayer = this.I;
                            str = this.F;
                            mediaPlayer.setDataSource(str);
                            d(i4);
                            if (!this.K[i4]) {
                                this.L[i4] = false;
                            }
                        }
                        break;
                    case 6:
                        if (this.G.length() == 0) {
                            this.L[i4] = true;
                        } else {
                            this.I.reset();
                            mediaPlayer = this.I;
                            str = this.G;
                            mediaPlayer.setDataSource(str);
                            d(i4);
                            if (!this.K[i4]) {
                                this.L[i4] = false;
                            }
                        }
                        break;
                    case 7:
                        try {
                            if (this.H.length() == 0) {
                                this.L[i4] = true;
                            } else {
                                this.I.reset();
                                mediaPlayer = this.I;
                                str = this.H;
                                mediaPlayer.setDataSource(str);
                                d(i4);
                                if (!this.K[i4]) {
                                    this.L[i4] = false;
                                }
                            }
                        } catch (Exception e2) {
                            this.I.reset();
                            this.L[i4] = true;
                            if (ru.himik.nightscream.kascada.w.a.a) {
                                Log.d("kascada", "[Sound] ERROR setValue.for bool: " + i4 + " err: " + e2.toString());
                                return;
                            }
                            return;
                        }
                        break;
                    default:
                        d(i4);
                        if (!this.K[i4]) {
                            this.L[i4] = false;
                        }
                        break;
                }
                return;
            }
            if (!this.K[i4]) {
                this.L[i4] = false;
            }
        }
    }
}
