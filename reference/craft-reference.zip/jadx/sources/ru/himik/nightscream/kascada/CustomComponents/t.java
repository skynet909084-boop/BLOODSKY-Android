package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class t extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    Paint C;
    boolean D;
    int E;
    int F;
    private long G;
    private boolean H;
    public Point I;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8886d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8887e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8888f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8889g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8890h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    String f8891i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    String f8892j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    String f8893k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f8894l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f8895m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    Bitmap f8896n;
    Paint o;

    public t(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_push_notif);
        this.f8886d = 25;
        this.f8888f = (byte) 1;
        this.f8889g = new b();
        this.f8891i = "";
        this.f8892j = "";
        this.f8893k = "";
        this.f8896n = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.o = new Paint();
        this.C = new Paint();
        this.D = false;
        this.E = 0;
        this.F = 0;
        this.G = 0L;
        this.H = false;
        this.I = new Point();
    }

    public void a(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_push_notif);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
        this.f8889g.A(this.f8886d);
        this.f8889g.L(this.f8888f);
    }

    public void b(int i2) {
        String strReplace = this.f8893k.replace("kascada_news", "");
        this.f8893k = strReplace;
        if (strReplace.length() == 0) {
            return;
        }
        if (i2 == 1 && !this.H) {
            this.H = true;
            ru.himik.nightscream.kascada.Firebase.c.b(getContext()).a(ru.himik.nightscream.kascada.Firebase.b.a(this.f8891i, this.f8892j, "/topics/" + this.f8893k, getContext()));
        }
        if (i2 == 0) {
            this.H = false;
        }
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.I.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public String getBody() {
        return this.f8892j;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8889g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8886d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8890h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.E;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8886d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8889g.l());
        jSONObject.put("addressRegister", this.f8889g.c());
        jSONObject.put("addressBit", (int) this.f8889g.a());
        jSONObject.put("typeRequest", (int) this.f8889g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("title", getTitle());
        jSONObject.put("body", getBody());
        jSONObject.put("to", getTo());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8887e;
    }

    public int getNumScreen() {
        return this.f8890h;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8889g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8889g.l() >= 100) {
            this.f8889g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8889g.c() + "." + ((int) this.f8889g.a());
        }
        this.f8889g.u((byte) MyApplication.b().E.get(this.f8889g.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8889g.b()) + "#" + this.f8889g.c() + "." + ((int) this.f8889g.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8889g.l() >= 0) {
            if (this.f8889g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8889g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.G;
    }

    public String getTitle() {
        return this.f8891i;
    }

    public String getTo() {
        return this.f8893k;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8895m) {
            this.C.setColor(-65536);
            this.C.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.C);
        }
        if (this.f8894l && mbCanvas.g1) {
            canvas.drawBitmap(this.f8896n, getWidth() - this.f8896n.getWidth(), getHeight() - this.f8896n.getHeight(), this.o);
        }
        if (this.D) {
            this.C.setColor(-16711936);
            this.C.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.C);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.D;
    }

    public void setBody(String str) {
        this.f8892j = str;
    }

    public void setConnectionError(boolean z) {
        if (this.f8895m != z) {
            this.f8895m = z;
            setVisibility(z ? 0 : 4);
            invalidate();
        }
    }

    public void setConnectionTimeOut(boolean z) {
        if (this.f8894l != z) {
            this.f8894l = z;
            setVisibility(z ? 0 : 4);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.D = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.E = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.F = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8887e = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8890h = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.G = j2;
    }

    public void setTitle(String str) {
        this.f8891i = str;
    }

    public void setTo(String str) {
        this.f8893k = str;
    }
}
