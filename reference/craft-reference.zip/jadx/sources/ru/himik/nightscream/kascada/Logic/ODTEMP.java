package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import kotlin.b0.c.p;
import kotlin.b0.d.j;
import kotlin.n;
import kotlin.u;
import kotlin.y.j.a.l;
import kotlinx.coroutines.b1;
import kotlinx.coroutines.i;
import kotlinx.coroutines.m0;
import kotlinx.coroutines.n0;
import l.c0;
import l.e0;
import l.h0;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;

/* JADX INFO: loaded from: classes2.dex */
public final class ODTEMP extends f {
    private boolean V;
    private int W;
    private int a0;
    private float b0;
    private long c0;
    private String d0;

    @kotlin.y.j.a.f(c = "ru.himik.nightscream.kascada.Logic.ODTEMP$getOut$1", f = "ODTEMP.kt", l = {}, m = "invokeSuspend")
    static final class a extends l implements p<m0, kotlin.y.d<? super u>, Object> {
        int a;

        a(kotlin.y.d<? super a> dVar) {
            super(2, dVar);
        }

        @Override // kotlin.y.j.a.a
        public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
            return ODTEMP.this.new a(dVar);
        }

        @Override // kotlin.b0.c.p
        public final Object invoke(m0 m0Var, kotlin.y.d<? super u> dVar) {
            return ((a) create(m0Var, dVar)).invokeSuspend(u.a);
        }

        @Override // kotlin.y.j.a.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            kotlin.y.i.d.c();
            if (this.a != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            n.b(obj);
            ODTEMP.this.u();
            return u.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ODTEMP(Context context) {
        super(context);
        j.d(context, "context");
        this.W = 1;
        this.a0 = 1;
        this.d0 = "10.10.0.1";
        this.f9012e = "DT";
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ODTEMP(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        j.d(context, "context");
        this.W = 1;
        this.a0 = 1;
        this.d0 = "10.10.0.1";
        this.f9012e = "DT";
    }

    public final int getActionExecute() {
        return this.W;
    }

    public final String getIp() {
        return this.d0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("ip", this.d0);
        jSONObject.put("typeSensor", this.W);
        jSONObject.put("typeResponse", this.a0);
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.f9012e;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        try {
            if (System.currentTimeMillis() - this.c0 >= 5000) {
                this.c0 = System.currentTimeMillis();
                if (!this.V) {
                    i.d(n0.a(b1.b()), null, null, new a(null), 3, null);
                }
            }
            return Float.valueOf(this.b0);
        } catch (Exception unused) {
            return 0;
        }
    }

    public final long getSaveTimeUpdate() {
        return this.c0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 130;
    }

    public final int getTypeResponse() {
        return this.a0;
    }

    public final int getTypeSensor() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 3;
    }

    public final float getValue() {
        return this.b0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        j.d(canvas, "canvas");
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawRect(this.G, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawRect(this.G, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2)), this.f9014g);
        canvas.drawLine(getWidth() - this.Q, getHeight() / 2.0f, getWidth(), getHeight() / 2.0f, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        this.E = "DT";
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
        this.W = i2;
    }

    public final void setIp(String str) {
        j.d(str, "<set-?>");
        this.d0 = str;
    }

    public final void setSaveTimeUpdate(long j2) {
        this.c0 = j2;
    }

    public final void setTypeResponse(int i2) {
        this.a0 = i2;
    }

    public final void setTypeSensor(int i2) {
        this.W = i2;
    }

    public final void setValue(float f2) {
        this.b0 = f2;
    }

    public final void u() {
        String string;
        this.V = true;
        e0.a aVar = new e0.a();
        aVar.g("http://" + this.d0 + "/state.json");
        try {
            h0 h0VarA = new c0().y(aVar.a()).f().a();
            j.b(h0VarA);
            JSONObject jSONObject = new JSONObject(h0VarA.g());
            try {
                int i2 = this.W;
                if (i2 == 1) {
                    try {
                        String string2 = jSONObject.getString("value");
                        j.c(string2, "json.getString(\"value\")");
                        this.b0 = Float.parseFloat(string2);
                    } catch (Exception unused) {
                        this.b0 = 99.9f;
                        return;
                    }
                } else if (i2 == 2) {
                    JSONObject jSONObject2 = jSONObject.getJSONObject("value");
                    int i3 = this.a0;
                    if (i3 == 1) {
                        string = jSONObject2.getString("t");
                        j.c(string, "jsonVal.getString(\"t\")");
                    } else if (i3 == 2) {
                        string = jSONObject2.getString("h");
                        j.c(string, "jsonVal.getString(\"h\")");
                    }
                    this.b0 = Float.parseFloat(string);
                }
            } catch (Exception unused2) {
                this.V = false;
                this.b0 = 99.9f;
            }
            this.V = false;
        } catch (Exception e2) {
            this.V = false;
            e2.printStackTrace();
            this.b0 = 99.9f;
        }
    }
}
