package ru.himik.nightscream.kascada.t;

import android.content.ClipData;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.himik.nightscream.kascada.r.h0;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b extends Fragment {
    View.OnClickListener k0 = new c();
    View.OnClickListener l0 = new d();
    View.OnClickListener m0 = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.t.a
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.p1(view);
        }
    };
    View.OnLongClickListener n0 = new e();
    View.OnLongClickListener o0 = new f();

    class a extends GestureDetector.SimpleOnGestureListener {
        a() {
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
            try {
                if (Math.abs(motionEvent.getY() - motionEvent2.getY()) > 250.0f) {
                    return false;
                }
                if (motionEvent.getX() - motionEvent2.getX() > 120.0f && Math.abs(f2) > 200.0f) {
                    ((mbCanvas) b.this.h()).x0(true);
                } else if (motionEvent2.getX() - motionEvent.getX() > 120.0f && Math.abs(f2) > 200.0f) {
                    ((mbCanvas) b.this.h()).r(true);
                }
            } catch (Exception unused) {
            }
            return super.onFling(motionEvent, motionEvent2, f2, f3);
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.t.b$b, reason: collision with other inner class name */
    class ViewOnTouchListenerC0308b implements View.OnTouchListener {
        final /* synthetic */ GestureDetector a;

        ViewOnTouchListenerC0308b(b bVar, GestureDetector gestureDetector) {
            this.a = gestureDetector;
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return this.a.onTouchEvent(motionEvent);
        }
    }

    class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            h0.f(b.this.h());
        }
    }

    class d implements View.OnClickListener {
        d() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (view.getId() != R.id.switch_layout) {
                return;
            }
            ((mbCanvas) b.this.h()).r(false);
        }
    }

    class e implements View.OnLongClickListener {
        e() {
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            if (view.getId() == R.id.tab_background) {
                h0.f(b.this.h());
            } else {
                view.startDrag(ClipData.newPlainText("text", "WWW"), new View.DragShadowBuilder(view), view, 0);
            }
            return false;
        }
    }

    class f implements View.OnLongClickListener {
        f() {
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            ((mbCanvas) b.this.h()).x0(true);
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: o1, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void p1(View view) {
        ((mbCanvas) h()).x0(true);
    }

    @Override // androidx.fragment.app.Fragment
    public View e0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate;
        if (MyApplication.b().i0) {
            viewInflate = layoutInflater.inflate(R.layout.fragment_component_bar_portrait, viewGroup, false);
            viewInflate.findViewById(R.id.close).setOnClickListener(this.m0);
        } else {
            viewInflate = layoutInflater.inflate(R.layout.fragment_component_bar, viewGroup, false);
        }
        viewInflate.findViewById(R.id.tab_switch).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_button).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_digital_setters).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_list).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_line_setter).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_voice_recognition).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_text).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_dyn_text).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_digital_indicator).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_lamp).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_alarm).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_line_level).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_round_indicator).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_sound).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_graph).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_gif).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_dyn_pictures).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_archive).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_background).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_background).setOnClickListener(this.k0);
        viewInflate.findViewById(R.id.tab_gateway).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_gateway_bit).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_sms_in).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_sms_out).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_camera).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_push_notif).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_web_view).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.tab_email).setOnLongClickListener(this.n0);
        viewInflate.findViewById(R.id.switch_layout).setOnClickListener(this.l0);
        viewInflate.findViewById(R.id.switch_layout).setOnLongClickListener(this.o0);
        viewInflate.findViewById(R.id.layout_tab_component).setOnTouchListener(new ViewOnTouchListenerC0308b(this, new GestureDetector(h(), new a())));
        return viewInflate;
    }
}
