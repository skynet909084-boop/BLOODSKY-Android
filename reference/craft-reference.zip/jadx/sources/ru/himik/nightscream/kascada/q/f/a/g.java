package ru.himik.nightscream.kascada.q.f.a;

import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class g {
    private final int event;
    private final int id;
    private final int key;
    private final Object obj;

    public g(int i2, int i3, int i4, Object obj) {
        this.event = i2;
        this.id = i3;
        this.key = i4;
        this.obj = obj;
    }

    public static /* synthetic */ g copy$default(g gVar, int i2, int i3, int i4, Object obj, int i5, Object obj2) {
        if ((i5 & 1) != 0) {
            i2 = gVar.event;
        }
        if ((i5 & 2) != 0) {
            i3 = gVar.id;
        }
        if ((i5 & 4) != 0) {
            i4 = gVar.key;
        }
        if ((i5 & 8) != 0) {
            obj = gVar.obj;
        }
        return gVar.copy(i2, i3, i4, obj);
    }

    public final int component1() {
        return this.event;
    }

    public final int component2() {
        return this.id;
    }

    public final int component3() {
        return this.key;
    }

    public final Object component4() {
        return this.obj;
    }

    public final g copy(int i2, int i3, int i4, Object obj) {
        return new g(i2, i3, i4, obj);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g)) {
            return false;
        }
        g gVar = (g) obj;
        return this.event == gVar.event && this.id == gVar.id && this.key == gVar.key && j.a(this.obj, gVar.obj);
    }

    public final int getEvent() {
        return this.event;
    }

    public final int getId() {
        return this.id;
    }

    public final int getKey() {
        return this.key;
    }

    public final Object getObj() {
        return this.obj;
    }

    public int hashCode() {
        int i2 = ((((this.event * 31) + this.id) * 31) + this.key) * 31;
        Object obj = this.obj;
        return i2 + (obj == null ? 0 : obj.hashCode());
    }

    public String toString() {
        return "MessageEventBus(event=" + this.event + ", id=" + this.id + ", key=" + this.key + ", obj=" + this.obj + ')';
    }
}
