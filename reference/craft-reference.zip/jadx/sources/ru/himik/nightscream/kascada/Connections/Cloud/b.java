package ru.himik.nightscream.kascada.Connections.Cloud;

import android.content.Context;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import ru.himik.nightscream.kascada.q.c.c;

/* JADX INFO: loaded from: classes.dex */
public class b extends Thread {
    String b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8644d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private Socket f8646f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    SocketAddress f8649i;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    byte[] f8651k;
    String a = "94.250.249.225";
    int c = 25000;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    boolean f8645e = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f8647g = 500;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f8648h = 2000;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> f8650j = new ArrayList<>();

    public b(boolean z, Context context, String str) {
        this.b = "error0";
        this.f8644d = -1;
        new ArrayList();
        this.f8651k = new byte[100];
        this.b = "kascada" + str;
        this.f8644d = this.f8644d;
        start();
    }

    public void a() {
        this.f8645e = false;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        Socket socket;
        System.currentTimeMillis();
        this.f8649i = new InetSocketAddress(this.a, this.c);
        this.f8650j.size();
        InputStream inputStream = null;
        OutputStream outputStream = null;
        do {
            char c = 0;
            while (true) {
                if (!this.f8645e) {
                    try {
                        Socket socket2 = this.f8646f;
                        if (socket2 != null) {
                            socket2.close();
                        }
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        if (outputStream != null) {
                            outputStream.close();
                            return;
                        }
                        return;
                    } catch (IOException unused) {
                        return;
                    }
                }
                if (c != 0) {
                    if (c == 1) {
                        try {
                            try {
                                this.f8646f.connect(this.f8649i, this.f8647g);
                                this.f8646f.setSoTimeout(this.f8648h);
                                inputStream = this.f8646f.getInputStream();
                                outputStream = this.f8646f.getOutputStream();
                            } catch (IOException | InterruptedException unused2) {
                                c = 4;
                            }
                        } catch (Exception unused3) {
                            Thread.sleep(this.f8647g);
                            this.f8646f.close();
                            this.f8646f = null;
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (outputStream != null) {
                                outputStream.close();
                            }
                            c = 4;
                            socket = this.f8646f;
                            if (socket == null) {
                            }
                        }
                        socket = this.f8646f;
                        if (socket == null && socket.isConnected()) {
                            try {
                                try {
                                    int length = this.b.getBytes().length + 1;
                                    byte[] bArr = new byte[length];
                                    bArr[0] = (byte) this.b.getBytes().length;
                                    System.arraycopy(this.b.getBytes(), 0, bArr, length - ((byte) this.b.getBytes().length), (byte) this.b.getBytes().length);
                                    outputStream.write(bArr);
                                    outputStream.flush();
                                    Thread.sleep(300L);
                                } catch (IOException unused4) {
                                    c = 4;
                                }
                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }
                            c = 3;
                        }
                    } else if (c == 3) {
                        int i2 = inputStream.read(this.f8651k);
                        if (i2 < 6 || this.f8651k[0] != 1) {
                            int[] iArr = new int[i2];
                            for (int i3 = 0; i3 < i2; i3++) {
                                iArr[i3] = this.f8651k[i3] & 255;
                            }
                        } else {
                            int[] iArr2 = new int[i2];
                            for (int i4 = 0; i4 < i2; i4++) {
                                iArr2[i4] = this.f8651k[i4] & 255;
                            }
                            int i5 = iArr2[1];
                            if (i5 == 1) {
                                outputStream.write(c.a(iArr2));
                            } else if (i5 == 3) {
                                outputStream.write(c.b(iArr2));
                            } else if (i5 == 5) {
                                outputStream.write(c.d(iArr2));
                            } else if (i5 == 6) {
                                outputStream.write(c.e(iArr2));
                            } else if (i5 == 15) {
                                outputStream.write(c.g(iArr2));
                            } else if (i5 == 16) {
                                outputStream.write(c.h(iArr2));
                            }
                            outputStream.flush();
                        }
                        if (i2 == -1) {
                            c = 4;
                        }
                        Thread.sleep(5L);
                    } else if (c != 4) {
                        continue;
                    } else {
                        try {
                            Thread.sleep(this.f8647g);
                        } catch (Exception unused5) {
                            Socket socket3 = this.f8646f;
                            if (socket3 != null) {
                                socket3.close();
                            }
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (outputStream != null) {
                                outputStream.close();
                            }
                            c = 4;
                        }
                    }
                } else if (this.b.length() <= 2) {
                    Thread.sleep(3000L);
                    c = 4;
                } else {
                    Socket socket4 = this.f8646f;
                    if (socket4 == null || !socket4.isConnected()) {
                        this.f8646f = new Socket();
                    }
                    c = 1;
                }
            }
            break;
        } while (this.f8645e);
    }
}
