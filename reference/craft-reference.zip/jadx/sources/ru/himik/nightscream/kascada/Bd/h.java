package ru.himik.nightscream.kascada.Bd;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import com.sun.mail.imap.IMAPStore;
import com.yandex.metrica.YandexMetrica;
import i.b.i;
import java.io.File;
import java.util.Objects;
import kotlin.b0.d.j;
import kotlin.u;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.CustomDynText;
import ru.himik.nightscream.kascada.CustomComponents.CustomLabel;
import ru.himik.nightscream.kascada.CustomComponents.CustomList;
import ru.himik.nightscream.kascada.CustomComponents.CustomSound;
import ru.himik.nightscream.kascada.CustomComponents.a0;
import ru.himik.nightscream.kascada.CustomComponents.b0;
import ru.himik.nightscream.kascada.CustomComponents.k;
import ru.himik.nightscream.kascada.CustomComponents.l;
import ru.himik.nightscream.kascada.CustomComponents.m;
import ru.himik.nightscream.kascada.CustomComponents.o;
import ru.himik.nightscream.kascada.CustomComponents.q;
import ru.himik.nightscream.kascada.CustomComponents.r;
import ru.himik.nightscream.kascada.CustomComponents.t;
import ru.himik.nightscream.kascada.CustomComponents.v;
import ru.himik.nightscream.kascada.CustomComponents.w;
import ru.himik.nightscream.kascada.CustomComponents.x;
import ru.himik.nightscream.kascada.CustomComponents.y;
import ru.himik.nightscream.kascada.Logic.FB_ARITHMETIC_FLOAT;
import ru.himik.nightscream.kascada.Logic.FB_ARITHMETIC_INT;
import ru.himik.nightscream.kascada.Logic.FB_COMPARE;
import ru.himik.nightscream.kascada.Logic.FB_COMPARE_FLOAT;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.Logic.FB_TIMER;
import ru.himik.nightscream.kascada.Logic.FB_TRIGGER;
import ru.himik.nightscream.kascada.Logic.MQTT_PUBLISHER;
import ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER;
import ru.himik.nightscream.kascada.Logic.ODTEMP;
import ru.himik.nightscream.kascada.Logic.Sensor_Orientation;
import ru.himik.nightscream.kascada.Logic.Sunrise_GPS;
import ru.himik.nightscream.kascada.Logic.Var;
import ru.himik.nightscream.kascada.Logic.VarFloat;
import ru.himik.nightscream.kascada.Logic.VarInt;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameIn;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameOut;
import ru.himik.nightscream.kascada.Logic.VarOutFloat;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.n;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes.dex */
public final class h {
    public static final a a = new a(null);
    private static final f.f.b.e b = new f.f.b.e();

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(kotlin.b0.d.g gVar) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void d(i.b.g gVar) {
            j.d(gVar, "subscriber");
            try {
                gVar.b(Boolean.valueOf(h.a.e()));
            } catch (Exception e2) {
                YandexMetrica.reportError("Сохранение проекта", e2);
                e2.printStackTrace();
                gVar.a(e2);
            }
        }

        public final f.f.b.e a() {
            return h.b;
        }

        public final i.b.f<Boolean> c() {
            i.b.f<Boolean> fVarB = i.b.f.b(new i() { // from class: ru.himik.nightscream.kascada.Bd.b
                @Override // i.b.i
                public final void a(i.b.g gVar) {
                    h.a.d(gVar);
                }
            });
            j.c(fVarB, "create { subscriber ->\n …          }\n            }");
            return fVarB;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
        public final boolean e() {
            String str;
            int i2;
            String str2;
            int i3;
            String str3;
            JSONException jSONException;
            int i4;
            JSONException jSONException2;
            String str4;
            Context context = MyApplication.b().h0;
            String str5 = MyApplication.b().k0;
            String str6 = MyApplication.b().j0;
            SQLiteDatabase writableDatabase = new e(context).getWritableDatabase();
            j.c(writableDatabase, "dbHelper.writableDatabase");
            try {
                writableDatabase.delete(str5, null, null);
                writableDatabase.delete(str6, null, null);
            } catch (Exception e2) {
                YandexMetrica.reportError("Очистка БД COMPONENT_TABLE: " + ((Object) str5) + " CONNECTIONS_TABLE: " + ((Object) str6), e2);
            }
            new File(j.i(n.a.f(), "kascada_models_file_size.json"));
            int size = MyApplication.b().F.size();
            int size2 = MyApplication.b().G.size();
            int size3 = MyApplication.b().f9036d.size();
            int size4 = MyApplication.b().H.size();
            int size5 = MyApplication.b().I.size();
            int size6 = MyApplication.b().J.size();
            int size7 = MyApplication.b().K.size();
            int size8 = MyApplication.b().L.size();
            int size9 = MyApplication.b().M.size();
            int size10 = MyApplication.b().N.size();
            int size11 = MyApplication.b().O.size();
            String str7 = "screen";
            int size12 = MyApplication.b().P.size();
            int size13 = MyApplication.b().Q.size();
            int size14 = MyApplication.b().R.size();
            int size15 = MyApplication.b().S.size();
            int size16 = MyApplication.b().T.size();
            int size17 = MyApplication.b().U.size();
            int size18 = MyApplication.b().V.size();
            int size19 = MyApplication.b().W.size();
            int size20 = MyApplication.b().X.size();
            int size21 = MyApplication.b().Y.size();
            int size22 = MyApplication.b().Z.size();
            int size23 = MyApplication.b().a0.size();
            int size24 = MyApplication.b().b0.size();
            int size25 = MyApplication.b().c0.size();
            int size26 = MyApplication.b().d0.size();
            int size27 = MyApplication.b().e0.size();
            int size28 = MyApplication.b().f0.size();
            String str8 = IMAPStore.ID_NAME;
            if (size3 > 0) {
                int i5 = 0;
                while (i5 < size3) {
                    int i6 = i5 + 1;
                    int i7 = size3;
                    ContentValues contentValues = new ContentValues();
                    int i8 = size11;
                    int i9 = size10;
                    contentValues.put("connectionsId", Integer.valueOf(MyApplication.b().f9036d.get(i5).c()));
                    contentValues.put(str8, MyApplication.b().f9036d.get(i5).d());
                    int iC = MyApplication.b().f9036d.get(i5).c();
                    String str9 = str8;
                    if (iC == 1) {
                        i4 = size9;
                        JSONObject jSONObject = new JSONObject();
                        try {
                            jSONObject.put("server", MyApplication.b().f9036d.get(i5).h());
                            jSONObject.put("pause", MyApplication.b().f9036d.get(i5).g());
                            contentValues.put("server", jSONObject.toString());
                        } catch (JSONException e3) {
                            jSONException2 = e3;
                            str4 = "Сохранение BluetoothParams";
                            YandexMetrica.reportError(str4, jSONException2);
                            jSONException2.printStackTrace();
                        }
                        u uVar = u.a;
                    } else if (iC == 2) {
                        i4 = size9;
                        JSONObject jSONObject2 = new JSONObject();
                        try {
                            jSONObject2.put("rtu", MyApplication.b().f9036d.get(i5).l());
                            jSONObject2.put("server", MyApplication.b().f9036d.get(i5).h());
                            jSONObject2.put("pause", MyApplication.b().f9036d.get(i5).g());
                            contentValues.put("server", jSONObject2.toString());
                        } catch (JSONException e4) {
                            jSONException2 = e4;
                            str4 = "Сохранение WiFiParams";
                            YandexMetrica.reportError(str4, jSONException2);
                            jSONException2.printStackTrace();
                        }
                        u uVar2 = u.a;
                    } else if (iC == 3) {
                        i4 = size9;
                        JSONObject jSONObject3 = new JSONObject();
                        try {
                            jSONObject3.put("baudRate", MyApplication.b().f9036d.get(i5).a());
                            jSONObject3.put("dataBits", MyApplication.b().f9036d.get(i5).b());
                            jSONObject3.put("stopBits", MyApplication.b().f9036d.get(i5).j());
                            jSONObject3.put("parity", MyApplication.b().f9036d.get(i5).e());
                            jSONObject3.put("pause", MyApplication.b().f9036d.get(i5).g());
                            contentValues.put("server", jSONObject3.toString());
                        } catch (JSONException e5) {
                            jSONException2 = e5;
                            str4 = "Сохранение UsbParams";
                            YandexMetrica.reportError(str4, jSONException2);
                            jSONException2.printStackTrace();
                        }
                        u uVar3 = u.a;
                    } else if (iC != 4) {
                        i4 = size9;
                    } else {
                        JSONObject jSONObject4 = new JSONObject();
                        i4 = size9;
                        try {
                            jSONObject4.put("rtu", MyApplication.b().f9036d.get(i5).l());
                            jSONObject4.put("server", MyApplication.b().f9036d.get(i5).h());
                            jSONObject4.put("pause", MyApplication.b().f9036d.get(i5).g());
                            contentValues.put("server", jSONObject4.toString());
                        } catch (JSONException e6) {
                            jSONException2 = e6;
                            str4 = "Сохранение CloudParams";
                            YandexMetrica.reportError(str4, jSONException2);
                            jSONException2.printStackTrace();
                        }
                        u uVar4 = u.a;
                    }
                    writableDatabase.insert(str6, null, contentValues);
                    i5 = i6;
                    size3 = i7;
                    size11 = i8;
                    size10 = i9;
                    str8 = str9;
                    size9 = i4;
                }
            }
            int i10 = size11;
            String str10 = str8;
            int i11 = size9;
            int i12 = size10;
            String str11 = "text";
            String str12 = "colorText";
            String str13 = "server";
            if (size2 > 0) {
                int i13 = 0;
                while (i13 < size2) {
                    int i14 = i13 + 1;
                    int i15 = size2;
                    ContentValues contentValues2 = new ContentValues();
                    int i16 = size5;
                    Object obj = MyApplication.b().G.get(MyApplication.b().G.keyAt(i13));
                    Objects.requireNonNull(obj, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomLabel");
                    CustomLabel customLabel = (CustomLabel) obj;
                    contentValues2.put("componentId", Integer.valueOf(customLabel.getIdComponent()));
                    contentValues2.put(str11, customLabel.getText().toString());
                    contentValues2.put("width", Integer.valueOf(customLabel.getWidth()));
                    contentValues2.put("height", Integer.valueOf(customLabel.getHeight()));
                    contentValues2.put("x", Integer.valueOf((int) customLabel.getX()));
                    contentValues2.put("y", Integer.valueOf((int) customLabel.getY()));
                    contentValues2.put("textSize", Float.valueOf(customLabel.getTextSize()));
                    contentValues2.put("colorText", Integer.valueOf(customLabel.getCurrentTextColor()));
                    String str14 = str11;
                    contentValues2.put("colorBackground", Integer.valueOf(customLabel.getBackgroundColor_()));
                    try {
                        contentValues2.put("other", customLabel.getJsonOther().toString());
                    } catch (JSONException e7) {
                        YandexMetrica.reportError("Сохранение Label Params", e7);
                        e7.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues2);
                    i13 = i14;
                    size2 = i15;
                    size5 = i16;
                    str11 = str14;
                }
                str = str11;
                i2 = size5;
            } else {
                str = "text";
                i2 = size5;
            }
            if (size4 > 0) {
                int i17 = 0;
                while (i17 < size4) {
                    int i18 = i17 + 1;
                    ContentValues contentValues3 = new ContentValues();
                    int i19 = size4;
                    Object obj2 = MyApplication.b().H.get(MyApplication.b().H.keyAt(i17));
                    Objects.requireNonNull(obj2, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomRegister");
                    ru.himik.nightscream.kascada.CustomComponents.u uVar5 = (ru.himik.nightscream.kascada.CustomComponents.u) obj2;
                    contentValues3.put("componentId", Integer.valueOf(uVar5.getIdComponent()));
                    contentValues3.put("width", Integer.valueOf(uVar5.getWidth()));
                    contentValues3.put("height", Integer.valueOf(uVar5.getHeight()));
                    contentValues3.put("x", Integer.valueOf((int) uVar5.getX()));
                    contentValues3.put("y", Integer.valueOf((int) uVar5.getY()));
                    contentValues3.put("textSize", Float.valueOf(uVar5.getTextSize()));
                    contentValues3.put("colorText", Integer.valueOf(uVar5.getCurrentTextColor()));
                    contentValues3.put("colorBackground", Integer.valueOf(uVar5.getBackgroundColorReg()));
                    try {
                        contentValues3.put("connectionInfo", uVar5.getJsonConnectionInfo().toString());
                        contentValues3.put("other", uVar5.getJsonOther().toString());
                    } catch (JSONException e8) {
                        YandexMetrica.reportError("Сохранение Register Params", e8);
                        e8.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues3);
                    size4 = i19;
                    i17 = i18;
                }
            }
            if (i2 > 0) {
                int i20 = i2;
                int i21 = 0;
                while (i21 < i20) {
                    int i22 = i21 + 1;
                    ContentValues contentValues4 = new ContentValues();
                    int i23 = i20;
                    Object obj3 = MyApplication.b().I.get(MyApplication.b().I.keyAt(i21));
                    Objects.requireNonNull(obj3, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomLamp");
                    q qVar = (q) obj3;
                    contentValues4.put("componentId", Integer.valueOf(qVar.getIdComponent()));
                    contentValues4.put("width", Integer.valueOf(qVar.getWidth()));
                    contentValues4.put("height", Integer.valueOf(qVar.getHeight()));
                    contentValues4.put("x", Integer.valueOf((int) qVar.getX()));
                    contentValues4.put("y", Integer.valueOf((int) qVar.getY()));
                    try {
                        contentValues4.put("connectionInfo", qVar.getJsonConnectionInfo().toString());
                        contentValues4.put("other", qVar.getJsonOther().toString());
                    } catch (JSONException e9) {
                        YandexMetrica.reportError("Сохранение Lamp Params", e9);
                        e9.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues4);
                    i21 = i22;
                    i20 = i23;
                }
            }
            if (size7 > 0) {
                int i24 = size7;
                int i25 = 0;
                while (i25 < i24) {
                    int i26 = i25 + 1;
                    ContentValues contentValues5 = new ContentValues();
                    int i27 = i24;
                    Object obj4 = MyApplication.b().K.get(MyApplication.b().K.keyAt(i25));
                    Objects.requireNonNull(obj4, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomDynText");
                    CustomDynText customDynText = (CustomDynText) obj4;
                    contentValues5.put("componentId", Integer.valueOf(customDynText.getIdComponent()));
                    contentValues5.put("width", Integer.valueOf(customDynText.getWidth()));
                    contentValues5.put("height", Integer.valueOf(customDynText.getHeight()));
                    contentValues5.put("x", Integer.valueOf((int) customDynText.getX()));
                    contentValues5.put("y", Integer.valueOf((int) customDynText.getY()));
                    try {
                        contentValues5.put("connectionInfo", customDynText.getJsonConnectionInfo().toString());
                        contentValues5.put("other", customDynText.getJsonOther().toString());
                    } catch (JSONException e10) {
                        YandexMetrica.reportError("Сохранение DynText Params", e10);
                        e10.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues5);
                    i25 = i26;
                    i24 = i27;
                }
            }
            if (size8 > 0) {
                int i28 = size8;
                int i29 = 0;
                while (i29 < i28) {
                    int i30 = i29 + 1;
                    ContentValues contentValues6 = new ContentValues();
                    int i31 = i28;
                    Object obj5 = MyApplication.b().L.get(MyApplication.b().L.keyAt(i29));
                    Objects.requireNonNull(obj5, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomEditNumber");
                    ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) obj5;
                    contentValues6.put("componentId", Integer.valueOf(iVar.getIdComponent()));
                    String str15 = str;
                    contentValues6.put(str15, iVar.getText().toString());
                    contentValues6.put("width", Integer.valueOf(iVar.getWidth()));
                    contentValues6.put("height", Integer.valueOf(iVar.getHeight()));
                    contentValues6.put("x", Integer.valueOf((int) iVar.getX()));
                    contentValues6.put("y", Integer.valueOf((int) iVar.getY()));
                    contentValues6.put("textSize", Float.valueOf(iVar.getTextSize()));
                    contentValues6.put(str12, Integer.valueOf(iVar.getCurrentTextColor()));
                    String str16 = str12;
                    contentValues6.put("colorBackground", Integer.valueOf(iVar.getBackgroundColorEditNumber()));
                    try {
                        contentValues6.put("connectionInfo", iVar.getJsonConnectionInfo().toString());
                        contentValues6.put("other", iVar.getJsonOther().toString());
                    } catch (JSONException e11) {
                        YandexMetrica.reportError("Сохранение EditNumber Params", e11);
                        e11.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues6);
                    str = str15;
                    i28 = i31;
                    i29 = i30;
                    str12 = str16;
                }
            }
            String str17 = str12;
            String str18 = str;
            if (i11 > 0) {
                int i32 = i11;
                int i33 = 0;
                while (i33 < i32) {
                    int i34 = i33 + 1;
                    ContentValues contentValues7 = new ContentValues();
                    int i35 = i32;
                    Object obj6 = MyApplication.b().M.get(MyApplication.b().M.keyAt(i33));
                    Objects.requireNonNull(obj6, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomAlarm");
                    ru.himik.nightscream.kascada.CustomComponents.c cVar = (ru.himik.nightscream.kascada.CustomComponents.c) obj6;
                    contentValues7.put("componentId", Integer.valueOf(cVar.getIdComponent()));
                    contentValues7.put("x", Integer.valueOf((int) cVar.getX()));
                    contentValues7.put("y", Integer.valueOf((int) cVar.getY()));
                    try {
                        contentValues7.put("connectionInfo", cVar.getJsonConnectionInfo().toString());
                        contentValues7.put("other", cVar.getJsonOther().toString());
                    } catch (JSONException e12) {
                        YandexMetrica.reportError("Сохранение Alarm Params", e12);
                        e12.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues7);
                    i33 = i34;
                    i32 = i35;
                }
            }
            if (i12 > 0) {
                int i36 = i12;
                int i37 = 0;
                while (i37 < i36) {
                    int i38 = i37 + 1;
                    ContentValues contentValues8 = new ContentValues();
                    int i39 = i36;
                    Object obj7 = MyApplication.b().N.get(MyApplication.b().N.keyAt(i37));
                    Objects.requireNonNull(obj7, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSms");
                    w wVar = (w) obj7;
                    contentValues8.put("componentId", Integer.valueOf(wVar.getIdComponent()));
                    contentValues8.put("x", Integer.valueOf((int) wVar.getX()));
                    contentValues8.put("y", Integer.valueOf((int) wVar.getY()));
                    try {
                        contentValues8.put("connectionInfo", wVar.getJsonConnectionInfo().toString());
                        contentValues8.put("other", wVar.getJsonOther().toString());
                    } catch (JSONException e13) {
                        YandexMetrica.reportError("Сохранение Sms Params", e13);
                        e13.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues8);
                    i37 = i38;
                    i36 = i39;
                }
            }
            if (i10 > 0) {
                int i40 = i10;
                int i41 = 0;
                while (i41 < i40) {
                    int i42 = i41 + 1;
                    ContentValues contentValues9 = new ContentValues();
                    int i43 = i40;
                    Object obj8 = MyApplication.b().O.get(MyApplication.b().O.keyAt(i41));
                    Objects.requireNonNull(obj8, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomLineLevel");
                    r rVar = (r) obj8;
                    contentValues9.put("componentId", Integer.valueOf(rVar.getIdComponent()));
                    contentValues9.put("x", Integer.valueOf((int) rVar.getX()));
                    contentValues9.put("y", Integer.valueOf((int) rVar.getY()));
                    contentValues9.put("width", Integer.valueOf(rVar.getWidth()));
                    contentValues9.put("height", Integer.valueOf(rVar.getHeight()));
                    try {
                        contentValues9.put("connectionInfo", rVar.getJsonConnectionInfo().toString());
                        contentValues9.put("other", rVar.getJsonOther().toString());
                    } catch (JSONException e14) {
                        YandexMetrica.reportError("Сохранение LineLevel Params", e14);
                        e14.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues9);
                    i41 = i42;
                    i40 = i43;
                }
            }
            if (size12 > 0) {
                int i44 = size12;
                int i45 = 0;
                while (i45 < i44) {
                    int i46 = i45 + 1;
                    ContentValues contentValues10 = new ContentValues();
                    int i47 = i44;
                    Object obj9 = MyApplication.b().P.get(MyApplication.b().P.keyAt(i45));
                    Objects.requireNonNull(obj9, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomCircleGauge");
                    ru.himik.nightscream.kascada.CustomComponents.g gVar = (ru.himik.nightscream.kascada.CustomComponents.g) obj9;
                    contentValues10.put("componentId", Integer.valueOf(gVar.getIdComponent()));
                    contentValues10.put("x", Integer.valueOf((int) gVar.getX()));
                    contentValues10.put("y", Integer.valueOf((int) gVar.getY()));
                    contentValues10.put("width", Integer.valueOf(gVar.getWidth()));
                    contentValues10.put("height", Integer.valueOf(gVar.getHeight()));
                    try {
                        contentValues10.put("connectionInfo", gVar.getJsonConnectionInfo().toString());
                        contentValues10.put("other", gVar.getJsonOther().toString());
                    } catch (JSONException e15) {
                        YandexMetrica.reportError("Сохранение CircleGauge Params", e15);
                        e15.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues10);
                    i45 = i46;
                    i44 = i47;
                }
            }
            if (size13 > 0) {
                int i48 = size13;
                int i49 = 0;
                while (i49 < i48) {
                    int i50 = i49 + 1;
                    ContentValues contentValues11 = new ContentValues();
                    int i51 = i48;
                    Object obj10 = MyApplication.b().Q.get(MyApplication.b().Q.keyAt(i49));
                    Objects.requireNonNull(obj10, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSeekBar");
                    v vVar = (v) obj10;
                    contentValues11.put("componentId", Integer.valueOf(vVar.getIdComponent()));
                    contentValues11.put("x", Integer.valueOf((int) vVar.getX()));
                    contentValues11.put("y", Integer.valueOf((int) vVar.getY()));
                    contentValues11.put("width", Integer.valueOf(vVar.getWidth()));
                    contentValues11.put("height", Integer.valueOf(vVar.getHeight()));
                    try {
                        contentValues11.put("connectionInfo", vVar.getJsonConnectionInfo().toString());
                        contentValues11.put("other", vVar.getJsonOther().toString());
                    } catch (JSONException e16) {
                        YandexMetrica.reportError("Сохранение SeekBar Params", e16);
                        e16.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues11);
                    i49 = i50;
                    i48 = i51;
                }
            }
            if (size14 > 0) {
                int i52 = size14;
                int i53 = 0;
                while (i53 < i52) {
                    int i54 = i53 + 1;
                    ContentValues contentValues12 = new ContentValues();
                    int i55 = i52;
                    Object obj11 = MyApplication.b().R.get(MyApplication.b().R.keyAt(i53));
                    Objects.requireNonNull(obj11, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomGraph");
                    o oVar = (o) obj11;
                    contentValues12.put("componentId", Integer.valueOf(oVar.getIdComponent()));
                    contentValues12.put("x", Integer.valueOf((int) oVar.getX()));
                    contentValues12.put("y", Integer.valueOf((int) oVar.getY()));
                    contentValues12.put("width", Integer.valueOf(oVar.getWidth()));
                    contentValues12.put("height", Integer.valueOf(oVar.getHeight()));
                    try {
                        contentValues12.put("connectionInfo", oVar.getJsonConnectionInfo().toString());
                        contentValues12.put("other", oVar.getJsonOther().toString());
                    } catch (JSONException e17) {
                        YandexMetrica.reportError("Сохранение Graph Params", e17);
                        e17.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues12);
                    i53 = i54;
                    i52 = i55;
                }
            }
            if (size15 > 0) {
                int i56 = size15;
                int i57 = 0;
                while (i57 < i56) {
                    int i58 = i57 + 1;
                    ContentValues contentValues13 = new ContentValues();
                    int i59 = i56;
                    Object obj12 = MyApplication.b().S.get(MyApplication.b().S.keyAt(i57));
                    Objects.requireNonNull(obj12, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomArchive");
                    ru.himik.nightscream.kascada.CustomComponents.d dVar = (ru.himik.nightscream.kascada.CustomComponents.d) obj12;
                    contentValues13.put("componentId", Integer.valueOf(dVar.getIdComponent()));
                    contentValues13.put("x", Integer.valueOf((int) dVar.getX()));
                    contentValues13.put("y", Integer.valueOf((int) dVar.getY()));
                    try {
                        contentValues13.put("connectionInfo", dVar.getJsonConnectionInfo().toString());
                        contentValues13.put("other", dVar.getJsonOther().toString());
                    } catch (JSONException e18) {
                        YandexMetrica.reportError("Сохранение Archive Params", e18);
                        e18.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues13);
                    i57 = i58;
                    i56 = i59;
                }
            }
            if (size16 > 0) {
                int i60 = size16;
                int i61 = 0;
                while (i61 < i60) {
                    int i62 = i61 + 1;
                    ContentValues contentValues14 = new ContentValues();
                    int i63 = i60;
                    Object obj13 = MyApplication.b().T.get(MyApplication.b().T.keyAt(i61));
                    Objects.requireNonNull(obj13, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomGif");
                    ru.himik.nightscream.kascada.CustomComponents.n nVar = (ru.himik.nightscream.kascada.CustomComponents.n) obj13;
                    contentValues14.put("componentId", Integer.valueOf(nVar.getIdComponent()));
                    contentValues14.put("x", Integer.valueOf((int) nVar.getX()));
                    contentValues14.put("y", Integer.valueOf((int) nVar.getY()));
                    contentValues14.put("width", Integer.valueOf(nVar.getWidth()));
                    contentValues14.put("height", Integer.valueOf(nVar.getHeight()));
                    try {
                        contentValues14.put("connectionInfo", nVar.getJsonConnectionInfo().toString());
                        contentValues14.put("other", nVar.getJsonOther().toString());
                    } catch (JSONException e19) {
                        YandexMetrica.reportError("Сохранение Gif Params", e19);
                        e19.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues14);
                    i61 = i62;
                    i60 = i63;
                }
            }
            if (size17 > 0) {
                int i64 = size17;
                int i65 = 0;
                while (i65 < i64) {
                    int i66 = i65 + 1;
                    ContentValues contentValues15 = new ContentValues();
                    int i67 = i64;
                    Object obj14 = MyApplication.b().U.get(MyApplication.b().U.keyAt(i65));
                    Objects.requireNonNull(obj14, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomDynPictures");
                    ru.himik.nightscream.kascada.CustomComponents.h hVar = (ru.himik.nightscream.kascada.CustomComponents.h) obj14;
                    contentValues15.put("componentId", Integer.valueOf(hVar.getIdComponent()));
                    contentValues15.put("x", Integer.valueOf((int) hVar.getX()));
                    contentValues15.put("y", Integer.valueOf((int) hVar.getY()));
                    contentValues15.put("width", Integer.valueOf(hVar.getWidth()));
                    contentValues15.put("height", Integer.valueOf(hVar.getHeight()));
                    try {
                        contentValues15.put("connectionInfo", hVar.getJsonConnectionInfo().toString());
                        contentValues15.put("other", hVar.getJsonOther().toString());
                    } catch (JSONException e20) {
                        YandexMetrica.reportError("Сохранение DynPic Params", e20);
                        e20.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues15);
                    i65 = i66;
                    i64 = i67;
                }
            }
            if (size21 > 0) {
                int i68 = size21;
                int i69 = 0;
                while (i69 < i68) {
                    int i70 = i69 + 1;
                    ContentValues contentValues16 = new ContentValues();
                    int i71 = i68;
                    Object obj15 = MyApplication.b().Y.get(MyApplication.b().Y.keyAt(i69));
                    Objects.requireNonNull(obj15, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSound");
                    CustomSound customSound = (CustomSound) obj15;
                    contentValues16.put("componentId", Integer.valueOf(customSound.getIdComponent()));
                    contentValues16.put("x", Integer.valueOf((int) customSound.getX()));
                    contentValues16.put("y", Integer.valueOf((int) customSound.getY()));
                    try {
                        contentValues16.put("connectionInfo", customSound.getJsonConnectionInfo().toString());
                        contentValues16.put("other", customSound.getJsonOther().toString());
                    } catch (JSONException e21) {
                        YandexMetrica.reportError("Сохранение Sound Params", e21);
                        e21.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues16);
                    i69 = i70;
                    i68 = i71;
                }
            }
            if (size > 0) {
                int i72 = size;
                int i73 = 0;
                while (i73 < i72) {
                    int i74 = i73 + 1;
                    ContentValues contentValues17 = new ContentValues();
                    int i75 = i72;
                    Object obj16 = MyApplication.b().F.get(MyApplication.b().F.keyAt(i73));
                    Objects.requireNonNull(obj16, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSwitch");
                    y yVar = (y) obj16;
                    contentValues17.put("componentId", Integer.valueOf(yVar.getIdComponent()));
                    contentValues17.put(str18, yVar.getCustomText());
                    contentValues17.put("width", Integer.valueOf(yVar.getWidth()));
                    contentValues17.put("height", Integer.valueOf(yVar.getHeight()));
                    contentValues17.put("x", Integer.valueOf((int) yVar.getX()));
                    contentValues17.put("y", Integer.valueOf((int) yVar.getY()));
                    contentValues17.put("textSize", Float.valueOf(yVar.getTextSize()));
                    String str19 = str17;
                    contentValues17.put(str19, Integer.valueOf(yVar.getCurrentTextColor()));
                    try {
                        contentValues17.put("connectionInfo", yVar.getJsonConnectionInfo().toString());
                        contentValues17.put("other", yVar.getJsonOther().toString());
                    } catch (JSONException e22) {
                        YandexMetrica.reportError("Сохранение Switch Params", e22);
                    }
                    writableDatabase.insert(str5, null, contentValues17);
                    str17 = str19;
                    i72 = i75;
                    i73 = i74;
                }
            }
            String str20 = str17;
            if (size6 > 0) {
                int i76 = size6;
                int i77 = 0;
                while (i77 < i76) {
                    int i78 = i77 + 1;
                    int i79 = i76;
                    ContentValues contentValues18 = new ContentValues();
                    Object obj17 = MyApplication.b().J.get(MyApplication.b().J.keyAt(i77));
                    Objects.requireNonNull(obj17, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomButton");
                    ru.himik.nightscream.kascada.CustomComponents.e eVar = (ru.himik.nightscream.kascada.CustomComponents.e) obj17;
                    contentValues18.put("componentId", Integer.valueOf(eVar.getIdComponent()));
                    contentValues18.put(str18, eVar.getText().toString());
                    contentValues18.put("width", Integer.valueOf(eVar.getWidth()));
                    contentValues18.put("height", Integer.valueOf(eVar.getHeight()));
                    contentValues18.put("x", Integer.valueOf((int) eVar.getX()));
                    contentValues18.put("y", Integer.valueOf((int) eVar.getY()));
                    contentValues18.put("textSize", Float.valueOf(eVar.getTextSize()));
                    contentValues18.put(str20, Integer.valueOf(eVar.getCurrentTextColor()));
                    try {
                        contentValues18.put("connectionInfo", eVar.getJsonConnectionInfo().toString());
                        contentValues18.put("other", eVar.getJsonOther().toString());
                    } catch (JSONException e23) {
                        YandexMetrica.reportError("Сохранение Button Params", e23);
                        e23.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues18);
                    i76 = i79;
                    i77 = i78;
                }
            }
            if (size18 > 0) {
                int i80 = size18;
                int i81 = 0;
                while (i81 < i80) {
                    int i82 = i81 + 1;
                    int i83 = i80;
                    ContentValues contentValues19 = new ContentValues();
                    Object obj18 = MyApplication.b().V.get(MyApplication.b().V.keyAt(i81));
                    Objects.requireNonNull(obj18, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSmsReceive");
                    x xVar = (x) obj18;
                    contentValues19.put("componentId", Integer.valueOf(xVar.getIdComponent()));
                    contentValues19.put("x", Integer.valueOf((int) xVar.getX()));
                    contentValues19.put("y", Integer.valueOf((int) xVar.getY()));
                    try {
                        contentValues19.put("connectionInfo", xVar.getJsonConnectionInfo().toString());
                        contentValues19.put("other", xVar.getJsonOther().toString());
                    } catch (JSONException e24) {
                        YandexMetrica.reportError("Сохранение SmsReceive Params", e24);
                        e24.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues19);
                    i81 = i82;
                    i80 = i83;
                }
            }
            if (size19 > 0) {
                int i84 = size19;
                int i85 = 0;
                while (i85 < i84) {
                    int i86 = i85 + 1;
                    int i87 = i84;
                    ContentValues contentValues20 = new ContentValues();
                    Object obj19 = MyApplication.b().W.get(MyApplication.b().W.keyAt(i85));
                    Objects.requireNonNull(obj19, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomGateway");
                    k kVar = (k) obj19;
                    contentValues20.put("componentId", Integer.valueOf(kVar.getIdComponent()));
                    contentValues20.put("x", Integer.valueOf((int) kVar.getX()));
                    contentValues20.put("y", Integer.valueOf((int) kVar.getY()));
                    try {
                        contentValues20.put("connectionInfo", kVar.getJsonConnectionInfo().toString());
                        contentValues20.put("other", kVar.getJsonOther().toString());
                    } catch (JSONException e25) {
                        YandexMetrica.reportError("Сохранение Gateway Params", e25);
                        e25.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues20);
                    i85 = i86;
                    i84 = i87;
                }
            }
            if (size20 > 0) {
                int i88 = size20;
                int i89 = 0;
                while (i89 < i88) {
                    int i90 = i89 + 1;
                    int i91 = i88;
                    ContentValues contentValues21 = new ContentValues();
                    Object obj20 = MyApplication.b().X.get(MyApplication.b().X.keyAt(i89));
                    Objects.requireNonNull(obj20, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomList");
                    CustomList customList = (CustomList) obj20;
                    contentValues21.put("componentId", Integer.valueOf(customList.getIdComponent()));
                    contentValues21.put(str18, customList.getText().toString());
                    contentValues21.put("width", Integer.valueOf(customList.getWidth()));
                    contentValues21.put("height", Integer.valueOf(customList.getHeight()));
                    contentValues21.put("x", Integer.valueOf((int) customList.getX()));
                    contentValues21.put("y", Integer.valueOf((int) customList.getY()));
                    contentValues21.put("textSize", Float.valueOf(customList.getTextSize()));
                    contentValues21.put(str20, Integer.valueOf(customList.getCurrentTextColor()));
                    try {
                        contentValues21.put("connectionInfo", customList.getJsonConnectionInfo().toString());
                        contentValues21.put("other", customList.getJsonOther().toString());
                    } catch (JSONException e26) {
                        YandexMetrica.reportError("Сохранение List Params", e26);
                        e26.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues21);
                    i89 = i90;
                    i88 = i91;
                }
            }
            if (size22 > 0) {
                int i92 = 0;
                while (i92 < size22) {
                    int i93 = i92 + 1;
                    ContentValues contentValues22 = new ContentValues();
                    Object obj21 = MyApplication.b().Z.get(MyApplication.b().Z.keyAt(i92));
                    Objects.requireNonNull(obj21, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomGatewayBit");
                    l lVar = (l) obj21;
                    contentValues22.put("componentId", Integer.valueOf(lVar.getIdComponent()));
                    contentValues22.put("x", Integer.valueOf((int) lVar.getX()));
                    contentValues22.put("y", Integer.valueOf((int) lVar.getY()));
                    try {
                        contentValues22.put("connectionInfo", lVar.getJsonConnectionInfo().toString());
                        contentValues22.put("other", lVar.getJsonOther().toString());
                    } catch (JSONException e27) {
                        YandexMetrica.reportError("Сохранение GatewayBit Params", e27);
                        e27.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues22);
                    i92 = i93;
                }
            }
            if (size23 > 0) {
                int i94 = 0;
                while (i94 < size23) {
                    int i95 = i94 + 1;
                    ContentValues contentValues23 = new ContentValues();
                    Object obj22 = MyApplication.b().a0.get(MyApplication.b().a0.keyAt(i94));
                    Objects.requireNonNull(obj22, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomCamera");
                    ru.himik.nightscream.kascada.CustomComponents.f fVar = (ru.himik.nightscream.kascada.CustomComponents.f) obj22;
                    contentValues23.put("componentId", Integer.valueOf(fVar.getIdComponent()));
                    contentValues23.put("x", Integer.valueOf((int) fVar.getX()));
                    contentValues23.put("y", Integer.valueOf((int) fVar.getY()));
                    contentValues23.put("width", Integer.valueOf(fVar.getWidth()));
                    contentValues23.put("height", Integer.valueOf(fVar.getHeight()));
                    try {
                        contentValues23.put("connectionInfo", fVar.getJsonConnectionInfo().toString());
                        contentValues23.put("other", fVar.getJsonOther().toString());
                    } catch (JSONException e28) {
                        YandexMetrica.reportError("Сохранение Camera Params", e28);
                        e28.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues23);
                    i94 = i95;
                }
            }
            if (size24 > 0) {
                int i96 = 0;
                while (i96 < size24) {
                    int i97 = i96 + 1;
                    ContentValues contentValues24 = new ContentValues();
                    Object obj23 = MyApplication.b().b0.get(MyApplication.b().b0.keyAt(i96));
                    Objects.requireNonNull(obj23, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomGauge2");
                    m mVar = (m) obj23;
                    contentValues24.put("componentId", Integer.valueOf(mVar.getIdComponent()));
                    contentValues24.put("x", Integer.valueOf((int) mVar.getX()));
                    contentValues24.put("y", Integer.valueOf((int) mVar.getY()));
                    contentValues24.put("width", Integer.valueOf(mVar.getWidth()));
                    contentValues24.put("height", Integer.valueOf(mVar.getHeight()));
                    try {
                        contentValues24.put("connectionInfo", mVar.getJsonConnectionInfo().toString());
                        contentValues24.put("other", mVar.getJsonOther().toString());
                    } catch (JSONException e29) {
                        YandexMetrica.reportError("Сохранение Gauge2 Params", e29);
                        e29.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues24);
                    i96 = i97;
                }
            }
            if (size25 > 0) {
                int i98 = 0;
                while (i98 < size25) {
                    int i99 = i98 + 1;
                    ContentValues contentValues25 = new ContentValues();
                    Object obj24 = MyApplication.b().c0.get(MyApplication.b().c0.keyAt(i98));
                    Objects.requireNonNull(obj24, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomPushNotification");
                    t tVar = (t) obj24;
                    contentValues25.put("componentId", Integer.valueOf(tVar.getIdComponent()));
                    contentValues25.put("x", Integer.valueOf((int) tVar.getX()));
                    contentValues25.put("y", Integer.valueOf((int) tVar.getY()));
                    try {
                        contentValues25.put("connectionInfo", tVar.getJsonConnectionInfo().toString());
                        contentValues25.put("other", tVar.getJsonOther().toString());
                    } catch (JSONException e30) {
                        YandexMetrica.reportError("Сохранение PushNotif Params", e30);
                        e30.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues25);
                    i98 = i99;
                }
            }
            if (size26 > 0) {
                int i100 = 0;
                while (i100 < size26) {
                    int i101 = i100 + 1;
                    ContentValues contentValues26 = new ContentValues();
                    Object obj25 = MyApplication.b().d0.get(MyApplication.b().d0.keyAt(i100));
                    Objects.requireNonNull(obj25, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomWebView");
                    b0 b0Var = (b0) obj25;
                    contentValues26.put("componentId", Integer.valueOf(b0Var.getIdComponent()));
                    contentValues26.put("x", Integer.valueOf((int) b0Var.getX()));
                    contentValues26.put("y", Integer.valueOf((int) b0Var.getY()));
                    contentValues26.put("width", Integer.valueOf(b0Var.getWidth()));
                    contentValues26.put("height", Integer.valueOf(b0Var.getHeight()));
                    try {
                        contentValues26.put("connectionInfo", b0Var.getJsonConnectionInfo().toString());
                        contentValues26.put("other", b0Var.getJsonOther().toString());
                    } catch (JSONException e31) {
                        YandexMetrica.reportError("Сохранение WebView Params", e31);
                        e31.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues26);
                    i100 = i101;
                }
            }
            if (size27 > 0) {
                int i102 = 0;
                while (i102 < size27) {
                    int i103 = i102 + 1;
                    ContentValues contentValues27 = new ContentValues();
                    Object obj26 = MyApplication.b().e0.get(MyApplication.b().e0.keyAt(i102));
                    Objects.requireNonNull(obj26, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomEmail");
                    ru.himik.nightscream.kascada.CustomComponents.j jVar = (ru.himik.nightscream.kascada.CustomComponents.j) obj26;
                    contentValues27.put("componentId", Integer.valueOf(jVar.getIdComponent()));
                    contentValues27.put("x", Integer.valueOf((int) jVar.getX()));
                    contentValues27.put("y", Integer.valueOf((int) jVar.getY()));
                    contentValues27.put("width", Integer.valueOf(jVar.getWidth()));
                    contentValues27.put("height", Integer.valueOf(jVar.getHeight()));
                    try {
                        contentValues27.put("connectionInfo", jVar.getJsonConnectionInfo().toString());
                        contentValues27.put("other", jVar.getJsonOther().toString());
                    } catch (JSONException e32) {
                        YandexMetrica.reportError("Сохранение Email Params", e32);
                        e32.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues27);
                    i102 = i103;
                }
            }
            if (size28 > 0) {
                int i104 = 0;
                while (i104 < size28) {
                    int i105 = i104 + 1;
                    ContentValues contentValues28 = new ContentValues();
                    Object obj27 = MyApplication.b().f0.get(MyApplication.b().f0.keyAt(i104));
                    Objects.requireNonNull(obj27, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomVoiceRecognition");
                    a0 a0Var = (a0) obj27;
                    contentValues28.put("componentId", Integer.valueOf(a0Var.getIdComponent()));
                    contentValues28.put("x", Integer.valueOf((int) a0Var.getX()));
                    contentValues28.put("y", Integer.valueOf((int) a0Var.getY()));
                    contentValues28.put("width", Integer.valueOf(a0Var.getWidth()));
                    contentValues28.put("height", Integer.valueOf(a0Var.getHeight()));
                    try {
                        contentValues28.put("connectionInfo", a0Var.getJsonConnectionInfo().toString());
                        contentValues28.put("other", a0Var.getJsonOther().toString());
                    } catch (JSONException e33) {
                        YandexMetrica.reportError("Сохранение VoiceRecognition Params", e33);
                        e33.printStackTrace();
                    }
                    writableDatabase.insert(str5, null, contentValues28);
                    i104 = i105;
                }
            }
            if (MyApplication.b().D.size() > 0) {
                int i106 = 0;
                for (int size29 = MyApplication.b().D.size(); i106 < size29; size29 = i3) {
                    int i107 = i106 + 1;
                    ContentValues contentValues29 = new ContentValues();
                    ru.himik.nightscream.kascada.Logic.c.a aVar = MyApplication.b().D.get(MyApplication.b().D.keyAt(i106));
                    j.c(aVar, "get().FbCollection.get(key)");
                    ru.himik.nightscream.kascada.Logic.c.a aVar2 = aVar;
                    if (aVar2.getRootUniqueIdMacro() == 0 || (aVar2 instanceof FB_MACRO)) {
                        contentValues29.put("componentId", Integer.valueOf(aVar2.getTypeFb()));
                        View view = (View) aVar2;
                        contentValues29.put("x", Integer.valueOf((int) view.getX()));
                        contentValues29.put("y", Integer.valueOf((int) view.getY()));
                        JSONObject jSONObject5 = new JSONObject();
                        try {
                            if (aVar2 instanceof FB_MACRO) {
                                JSONObject jsonOther = ((FB_MACRO) aVar2).getJsonOther();
                                j.c(jsonOther, "fb.jsonOther");
                                try {
                                    ((FB_MACRO) aVar2).v(MyApplication.b().D, MyApplication.b().m0);
                                    contentValues29.put("other", jsonOther.toString());
                                    writableDatabase.insert(str5, null, contentValues29);
                                    i3 = size29;
                                    str3 = str10;
                                } catch (JSONException e34) {
                                    e = e34;
                                    i3 = size29;
                                    jSONObject5 = jsonOther;
                                    str3 = str10;
                                    jSONException = e;
                                    YandexMetrica.reportError("Сохранение Logic Params", jSONException);
                                    jSONException.printStackTrace();
                                    contentValues29.put("other", jSONObject5.toString());
                                    writableDatabase.insert(str5, null, contentValues29);
                                }
                            } else {
                                jSONObject5.put("numScreen", aVar2.getNumScreen());
                                jSONObject5.put("invertOut", aVar2.getInvertOut());
                                jSONObject5.put("saveKey", aVar2.getKey());
                                jSONObject5.put("numOnIn", aVar2.getNumOnIn());
                                jSONObject5.put("nMcr", aVar2.getRootNameMacro());
                                jSONObject5.put("unIdMcr", aVar2.getRootUniqueIdMacro());
                                jSONObject5.put("macrosOut", aVar2.getJsonMacroOutIfNeed());
                                if (aVar2.q() != null) {
                                    jSONObject5.put("keyOut", aVar2.q().getKey());
                                } else {
                                    jSONObject5.put("keyOut", -1);
                                }
                                if (aVar2 instanceof ru.himik.nightscream.kascada.Logic.e) {
                                    jSONObject5.put("reg", ((ru.himik.nightscream.kascada.Logic.e) aVar2).getReg());
                                    jSONObject5.put("bit", ((ru.himik.nightscream.kascada.Logic.e) aVar2).getBit());
                                }
                                if (aVar2 instanceof FB_COMPARE) {
                                    jSONObject5.put("compareAction", ((FB_COMPARE) aVar2).getActionExecute());
                                }
                                if (aVar2 instanceof FB_ARITHMETIC_INT) {
                                    jSONObject5.put("compareAction", ((FB_ARITHMETIC_INT) aVar2).getActionExecute());
                                }
                                if (aVar2 instanceof Var) {
                                    jSONObject5.put("isConstant", aVar2.g());
                                    jSONObject5.put("constant", aVar2.getVarConstant());
                                }
                                if (aVar2 instanceof VarInt) {
                                    jSONObject5.put("isConstant", aVar2.g());
                                    jSONObject5.put("constant", aVar2.getVarIntConstant());
                                }
                                if (aVar2 instanceof VarFloat) {
                                    try {
                                        jSONObject5.put("isConstant", aVar2.g());
                                        StringBuilder sb = new StringBuilder();
                                        i3 = size29;
                                        try {
                                            sb.append(aVar2.getVarFloatConstant());
                                            sb.append("");
                                            jSONObject5.put("constant", sb.toString());
                                        } catch (JSONException e35) {
                                            e = e35;
                                            jSONException = e;
                                            str3 = str10;
                                        }
                                    } catch (JSONException e36) {
                                        e = e36;
                                        i3 = size29;
                                    }
                                } else {
                                    i3 = size29;
                                }
                                try {
                                    if (aVar2 instanceof VarOutFloat) {
                                        jSONObject5.put("isHighRegister", ((VarOutFloat) aVar2).S);
                                        jSONObject5.put("isHighByte", ((VarOutFloat) aVar2).T);
                                    }
                                    if (aVar2 instanceof FB_ARITHMETIC_FLOAT) {
                                        jSONObject5.put("compareAction", ((FB_ARITHMETIC_FLOAT) aVar2).getActionExecute());
                                    }
                                    if (aVar2 instanceof FB_COMPARE_FLOAT) {
                                        jSONObject5.put("compareAction", ((FB_COMPARE_FLOAT) aVar2).getActionExecute());
                                    }
                                    if (aVar2 instanceof FB_TRIGGER) {
                                        jSONObject5.put("type", ((FB_TRIGGER) aVar2).getActionExecute());
                                    }
                                    if (aVar2 instanceof FB_TIMER) {
                                        jSONObject5.put("type", ((FB_TIMER) aVar2).getTimerType());
                                        jSONObject5.put("typeTime", ((FB_TIMER) aVar2).getTimerTypeTime());
                                    }
                                    if (aVar2 instanceof Sensor_Orientation) {
                                        jSONObject5.put("type", ((Sensor_Orientation) aVar2).getActionExecute());
                                    }
                                    if (aVar2 instanceof Sunrise_GPS) {
                                        jSONObject5.put("type", ((Sunrise_GPS) aVar2).getActionExecute());
                                        jSONObject5.put("latitude", ((Sunrise_GPS) aVar2).getLatitude());
                                        jSONObject5.put("longitude", ((Sunrise_GPS) aVar2).getLongitude());
                                    }
                                    if (aVar2 instanceof ODTEMP) {
                                        jSONObject5.put("ip", ((ODTEMP) aVar2).getIp());
                                        jSONObject5.put("typeSensor", ((ODTEMP) aVar2).getTypeSensor());
                                        jSONObject5.put("typeResponse", ((ODTEMP) aVar2).getTypeResponse());
                                    }
                                    if (!(aVar2 instanceof VarNameIn)) {
                                        str3 = str10;
                                    } else if (((VarNameIn) aVar2).t()) {
                                        str3 = str10;
                                    } else {
                                        jSONObject5.put("typeVar", ((VarNameIn) aVar2).getTypeVar());
                                        jSONObject5.put("typeVarValue", ((VarNameIn) aVar2).getTypeVarValue());
                                        if (((VarNameIn) aVar2).getTypeVarValue() == 2) {
                                            try {
                                                jSONObject5.put("isConstant", aVar2.g());
                                                int typeVar = ((VarNameIn) aVar2).getTypeVar();
                                                if (typeVar == 1) {
                                                    jSONObject5.put("constant", ((VarNameIn) aVar2).getVarConstant());
                                                } else if (typeVar == 2) {
                                                    jSONObject5.put("constant", ((VarNameIn) aVar2).getVarIntConstant());
                                                } else if (typeVar == 3) {
                                                    try {
                                                        jSONObject5.put("constant", ((VarNameIn) aVar2).getVarFloatConstant());
                                                    } catch (JSONException e37) {
                                                        e = e37;
                                                        jSONException = e;
                                                        str3 = str10;
                                                        YandexMetrica.reportError("Сохранение Logic Params", jSONException);
                                                        jSONException.printStackTrace();
                                                    }
                                                }
                                                str3 = str10;
                                            } catch (JSONException e38) {
                                                e = e38;
                                            }
                                        } else {
                                            try {
                                                str3 = str10;
                                                jSONObject5.put(str3, ((VarNameIn) aVar2).getVarName());
                                            } catch (JSONException e39) {
                                                e = e39;
                                                str3 = str10;
                                            }
                                        }
                                    }
                                    try {
                                        if (aVar2 instanceof VarNameOut) {
                                            if (!((VarNameOut) aVar2).t()) {
                                                jSONObject5.put("typeVar", ((VarNameOut) aVar2).getTypeVar());
                                                jSONObject5.put(str3, ((VarNameOut) aVar2).getVarName());
                                            }
                                        }
                                        if (aVar2 instanceof MQTT_SUBSCRIBER) {
                                            jSONObject5.put("topic", ((MQTT_SUBSCRIBER) aVar2).getTopic());
                                            jSONObject5.put("typeQ", ((MQTT_SUBSCRIBER) aVar2).getTypeQ());
                                        }
                                        if (aVar2 instanceof MQTT_PUBLISHER) {
                                            jSONObject5.put("topic", ((MQTT_PUBLISHER) aVar2).getTopic());
                                            jSONObject5.put("typeIn", ((MQTT_PUBLISHER) aVar2).getTypeIn());
                                            jSONObject5.put("numMqttServer", ((MQTT_PUBLISHER) aVar2).getNumMqttServer());
                                            jSONObject5.put("mqttRetain", ((MQTT_PUBLISHER) aVar2).v());
                                        }
                                    } catch (JSONException e40) {
                                        e = e40;
                                        jSONException = e;
                                        YandexMetrica.reportError("Сохранение Logic Params", jSONException);
                                        jSONException.printStackTrace();
                                    }
                                } catch (JSONException e41) {
                                    e = e41;
                                    str3 = str10;
                                }
                                contentValues29.put("other", jSONObject5.toString());
                                writableDatabase.insert(str5, null, contentValues29);
                            }
                        } catch (JSONException e42) {
                            e = e42;
                            i3 = size29;
                        }
                        str3 = str10;
                        jSONException = e;
                        YandexMetrica.reportError("Сохранение Logic Params", jSONException);
                        jSONException.printStackTrace();
                        contentValues29.put("other", jSONObject5.toString());
                        writableDatabase.insert(str5, null, contentValues29);
                    } else {
                        i3 = size29;
                        str3 = str10;
                    }
                    i106 = i107;
                    str10 = str3;
                }
            }
            String str21 = str10;
            ContentValues contentValues30 = new ContentValues();
            JSONObject jSONObject6 = new JSONObject();
            try {
                int i108 = mbCanvas.b1;
                int i109 = 0;
                while (i109 < i108) {
                    int i110 = i109 + 1;
                    StringBuilder sb2 = new StringBuilder();
                    String str22 = str7;
                    sb2.append(str22);
                    sb2.append(i110);
                    sb2.append("IsColor");
                    String string = sb2.toString();
                    Boolean boolA = MyApplication.b().C.get(i109).a();
                    j.c(boolA, "get().backgroundScreen_.get(i).colorOnScreen");
                    jSONObject6.put(string, boolA.booleanValue());
                    jSONObject6.put(str22 + i110 + "PathImage", MyApplication.b().C.get(i109).f());
                    jSONObject6.put(str22 + i110 + "Color", MyApplication.b().C.get(i109).b());
                    jSONObject6.put(str22 + i110 + "Name", MyApplication.b().C.get(i109).d());
                    jSONObject6.put(str22 + i110 + "DefaultBackground", MyApplication.b().C.get(i109).g());
                    jSONObject6.put(str22 + i110 + "Pass", MyApplication.b().C.get(i109).e());
                    i109 = i110;
                    str7 = str22;
                }
            } catch (JSONException e43) {
                YandexMetrica.reportError("Сохранение Screen Params", e43);
                e43.printStackTrace();
            }
            contentValues30.put("screenBackground", jSONObject6.toString());
            writableDatabase.update("TableNameProject", contentValues30, "_id = ?", new String[]{MyApplication.b().l0});
            JSONArray jSONArray = new JSONArray();
            int size30 = MyApplication.b().E.size();
            int i111 = 0;
            while (i111 < size30) {
                int i112 = i111 + 1;
                try {
                    JSONObject jSONObject7 = new JSONObject();
                    jSONObject7.put("num", i111);
                    jSONObject7.put(str21, MyApplication.b().E.get(i111).c());
                    jSONObject7.put(IMAPStore.ID_ADDRESS, MyApplication.b().E.get(i111).a());
                    str2 = str13;
                    try {
                        jSONObject7.put(str2, MyApplication.b().E.get(i111).e());
                        jSONObject7.put("idServer", MyApplication.b().E.get(i111).b());
                        jSONObject7.put("rtu", MyApplication.b().E.get(i111).g());
                        jSONArray.put(jSONObject7);
                    } catch (JSONException e44) {
                        e = e44;
                        JSONException jSONException3 = e;
                        YandexMetrica.reportError("Сохранение NetDevList Params", jSONException3);
                        jSONException3.printStackTrace();
                    }
                } catch (JSONException e45) {
                    e = e45;
                    str2 = str13;
                }
                i111 = i112;
                str13 = str2;
            }
            ContentValues contentValues31 = new ContentValues();
            contentValues31.put("stationMode", Boolean.valueOf(mbCanvas.Z0));
            contentValues31.put("countDevice", Integer.valueOf(MyApplication.b().f9042j));
            contentValues31.put("deviceNetwork", jSONArray.toString());
            if (MyApplication.b().f9043k != null) {
                contentValues31.put("pdfDocument", MyApplication.b().f9043k);
            } else {
                contentValues31.put("pdfDocument", "");
            }
            contentValues31.put("showTimeOut", Boolean.valueOf(mbCanvas.g1));
            JSONArray jSONArray2 = new JSONArray();
            int i113 = 10;
            int length = MyApplication.b().v0.f9265j.length;
            while (i113 < length) {
                int i114 = i113 + 1;
                if (MyApplication.b().v0.f9265j[i113] != 0) {
                    try {
                        JSONObject jSONObject8 = new JSONObject();
                        jSONObject8.put(j.i("reg_", Integer.valueOf(i113)), MyApplication.b().v0.f9265j[i113]);
                        jSONArray2.put(jSONObject8);
                    } catch (JSONException e46) {
                        YandexMetrica.reportError("Сохранение Retain SysReg Params", e46);
                        e46.printStackTrace();
                    }
                }
                i113 = i114;
            }
            contentValues31.put("systemRegisters", jSONArray2.toString());
            JSONObject jSONObject9 = new JSONObject();
            try {
                jSONObject9.put("kascadaCloudSlave", MyApplication.b().f9037e);
                jSONObject9.put("modbusSlavePort", MyApplication.b().f9039g);
                jSONObject9.put("kascadaCloudRemoteControl", MyApplication.b().f9038f);
            } catch (JSONException e47) {
                YandexMetrica.reportError("Сохранение CloudSlave Params", e47);
                e47.printStackTrace();
            }
            contentValues31.put("modbusSlave", jSONObject9.toString());
            writableDatabase.update("TableNameProject", contentValues31, "_id = ?", new String[]{MyApplication.b().l0});
            ContentValues contentValues32 = new ContentValues();
            JSONObject jSONObject10 = new JSONObject();
            try {
                jSONObject10.put("widthDisplay", MyApplication.b().f9040h);
                jSONObject10.put("heightDisplay", MyApplication.b().f9041i);
                jSONObject10.put("portraitMode", MyApplication.b().i0);
                jSONObject10.put("backgroundWork", MyApplication.b().f9046n);
                try {
                    jSONObject10.put("MQTT_Server", a().r(MyApplication.b().o0));
                    jSONObject10.put("MQTT_Server2", a().r(MyApplication.b().p0));
                } catch (Exception e48) {
                    YandexMetrica.reportError("Сохранение MQTT Server Params", e48);
                }
            } catch (JSONException e49) {
                YandexMetrica.reportError("Сохранение other projects Params", e49);
                e49.printStackTrace();
            }
            contentValues32.put("settings", jSONObject10.toString());
            writableDatabase.update("TableNameProject", contentValues32, "_id = ?", new String[]{MyApplication.b().l0});
            return true;
        }
    }
}
