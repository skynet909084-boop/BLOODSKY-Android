package ru.himik.nightscream.kascada.Preference;

import android.text.InputFilter;
import android.text.Spanned;

/* JADX INFO: loaded from: classes2.dex */
public class v0 implements InputFilter {
    private int a;
    private int b;

    public v0(String str, String str2) {
        this.a = Integer.parseInt(str);
        this.b = Integer.parseInt(str2);
    }

    private boolean a(int i2, int i3, int i4) {
        if (i3 > i2) {
            if (i4 >= i2 && i4 <= i3) {
                return true;
            }
        } else if (i4 >= i3 && i4 <= i2) {
            return true;
        }
        return false;
    }

    @Override // android.text.InputFilter
    public CharSequence filter(CharSequence charSequence, int i2, int i3, Spanned spanned, int i4, int i5) {
        try {
            if (a(this.a, this.b, Integer.parseInt(spanned.toString() + charSequence.toString()))) {
                return null;
            }
            return "";
        } catch (NumberFormatException unused) {
            return "";
        }
    }
}
