package ru.himik.nightscream.kascada.Preference.ServerList;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes2.dex */
public class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new C0291a();
    boolean a;
    int b;
    String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    String f9117d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f9118e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f9119f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f9120g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f9121h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    boolean f9122i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f9123j;

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.ServerList.a$a, reason: collision with other inner class name */
    static class C0291a implements Parcelable.Creator<a> {
        C0291a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public a createFromParcel(Parcel parcel) {
            return new a(parcel, null);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public a[] newArray(int i2) {
            return new a[i2];
        }
    }

    public a(int i2, String str, String str2, int i3) {
        this.a = false;
        this.f9118e = 9600;
        this.f9119f = 8;
        this.f9120g = 2;
        this.f9121h = 0;
        this.f9122i = false;
        this.f9123j = 0;
        this.b = i2;
        this.c = str;
        this.f9117d = str2;
        this.f9123j = i3;
    }

    private a(Parcel parcel) {
        this.a = false;
        this.f9118e = 9600;
        this.f9119f = 8;
        this.f9120g = 2;
        this.f9121h = 0;
        this.f9122i = false;
        this.f9123j = 0;
        this.b = parcel.readInt();
        this.c = parcel.readString();
        this.f9117d = parcel.readString();
        this.f9118e = parcel.readInt();
        this.f9119f = parcel.readInt();
        this.f9120g = parcel.readInt();
        this.f9121h = parcel.readInt();
        this.f9122i = parcel.readByte() != 0;
        this.f9123j = parcel.readInt();
    }

    /* synthetic */ a(Parcel parcel, C0291a c0291a) {
        this(parcel);
    }

    public int a() {
        return this.f9118e;
    }

    public int b() {
        return this.f9119f;
    }

    public int c() {
        return this.b;
    }

    public String d() {
        return this.c;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public int e() {
        return this.f9121h;
    }

    public int g() {
        return this.f9123j;
    }

    public String h() {
        if (this.b == 3) {
            this.f9117d = this.f9118e + ", " + this.f9119f + ", " + ru.himik.nightscream.kascada.q.e.b.a.d(this.f9120g) + ", " + ru.himik.nightscream.kascada.q.e.b.a.c(this.f9121h);
        }
        return this.f9117d;
    }

    public String i() {
        return this.c + ":" + this.f9117d;
    }

    public int j() {
        return this.f9120g;
    }

    public boolean k() {
        return this.a;
    }

    public boolean l() {
        return this.f9122i;
    }

    public void m(int i2) {
        this.f9118e = i2;
    }

    public void n(boolean z) {
        this.a = z;
    }

    public void o(int i2) {
        this.f9119f = i2;
    }

    public void p(String str) {
        this.c = str;
    }

    public void q(int i2) {
        this.f9121h = i2;
    }

    public void r(int i2) {
        if (i2 > 1000) {
            i2 = 1000;
        }
        if (i2 < 0) {
            i2 = 0;
        }
        this.f9123j = i2;
    }

    public void s(boolean z) {
        this.f9122i = z;
    }

    public void t(String str) {
        this.f9117d = str;
    }

    public void u(int i2) {
        this.f9120g = i2;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.f9117d);
        parcel.writeInt(this.f9118e);
        parcel.writeInt(this.f9119f);
        parcel.writeInt(this.f9120g);
        parcel.writeInt(this.f9121h);
        parcel.writeByte(this.f9122i ? (byte) 1 : (byte) 0);
        parcel.writeInt(this.f9123j);
    }
}
