package ru.himik.nightscream.kascada.Connections.Usb.driver;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class FtdiSerialDriver implements UsbSerialDriver {
    private final UsbDevice mDevice;
    private final UsbSerialPort mPort;

    private enum DeviceType {
        TYPE_BM,
        TYPE_AM,
        TYPE_2232C,
        TYPE_R,
        TYPE_2232H,
        TYPE_4232H
    }

    private class FtdiSerialPort extends CommonUsbSerialPort {
        private static final boolean ENABLE_ASYNC_READS = false;
        public static final int FTDI_DEVICE_IN_REQTYPE = 192;
        public static final int FTDI_DEVICE_OUT_REQTYPE = 64;
        private static final int MODEM_STATUS_HEADER_LENGTH = 2;
        private static final int SIO_MODEM_CTRL_REQUEST = 1;
        private static final int SIO_RESET_PURGE_RX = 1;
        private static final int SIO_RESET_PURGE_TX = 2;
        private static final int SIO_RESET_REQUEST = 0;
        private static final int SIO_RESET_SIO = 0;
        private static final int SIO_SET_BAUD_RATE_REQUEST = 3;
        private static final int SIO_SET_DATA_REQUEST = 4;
        private static final int SIO_SET_FLOW_CTRL_REQUEST = 2;
        public static final int USB_ENDPOINT_IN = 128;
        public static final int USB_ENDPOINT_OUT = 0;
        public static final int USB_READ_TIMEOUT_MILLIS = 5000;
        public static final int USB_RECIP_DEVICE = 0;
        public static final int USB_RECIP_ENDPOINT = 2;
        public static final int USB_RECIP_INTERFACE = 1;
        public static final int USB_RECIP_OTHER = 3;
        public static final int USB_TYPE_CLASS = 0;
        public static final int USB_TYPE_RESERVED = 0;
        public static final int USB_TYPE_STANDARD = 0;
        public static final int USB_TYPE_VENDOR = 0;
        public static final int USB_WRITE_TIMEOUT_MILLIS = 5000;
        private final String TAG;
        private int mInterface;
        private int mMaxPacketSize;
        private DeviceType mType;

        public FtdiSerialPort(UsbDevice usbDevice, int i2) {
            super(usbDevice, i2);
            this.TAG = FtdiSerialDriver.class.getSimpleName();
            this.mInterface = 0;
            this.mMaxPacketSize = 64;
        }

        private long[] convertBaudrate(int i2) {
            int i3 = 24000000 / i2;
            int[] iArr = {0, 3, 2, 4, 1, 5, 6, 7};
            int i4 = 0;
            int i5 = 0;
            int i6 = 0;
            for (int i7 = 0; i7 < 2; i7++) {
                int i8 = i3 + i7;
                if (i8 <= 8) {
                    i8 = 8;
                } else {
                    DeviceType deviceType = this.mType;
                    DeviceType deviceType2 = DeviceType.TYPE_AM;
                    if (deviceType != deviceType2 && i8 < 12) {
                        i8 = 12;
                    } else if (i3 < 16) {
                        i8 = 16;
                    } else if (deviceType != deviceType2 && i8 > 131071) {
                        i8 = 131071;
                    }
                }
                int i9 = ((i8 / 2) + 24000000) / i8;
                int i10 = i9 < i2 ? i2 - i9 : i9 - i2;
                if (i7 == 0 || i10 < i4) {
                    i6 = i9;
                    if (i10 == 0) {
                        i5 = i8;
                        break;
                    }
                    i4 = i10;
                    i5 = i8;
                }
            }
            long j2 = (i5 >> 3) | (iArr[i5 & 7] << 14);
            if (j2 == 1) {
                j2 = 0;
            } else if (j2 == 16385) {
                j2 = 1;
            }
            long j3 = j2 & 65535;
            DeviceType deviceType3 = this.mType;
            return new long[]{i6, (deviceType3 == DeviceType.TYPE_2232C || deviceType3 == DeviceType.TYPE_2232H || deviceType3 == DeviceType.TYPE_4232H) ? ((j2 >> 8) & 65535 & 65280) | 0 : (j2 >> 16) & 65535, j3};
        }

        private final int filterStatusBytes(byte[] bArr, byte[] bArr2, int i2, int i3) {
            int i4 = i2 % i3;
            int i5 = 0;
            int i6 = (i2 / i3) + (i4 == 0 ? 0 : 1);
            while (i5 < i6) {
                int i7 = i5 == i6 + (-1) ? i4 - 2 : i3 - 2;
                if (i7 > 0) {
                    System.arraycopy(bArr, (i5 * i3) + 2, bArr2, (i3 - 2) * i5, i7);
                }
                i5++;
            }
            return i2 - (i6 * 2);
        }

        private int setBaudRate(int i2) throws IOException {
            long[] jArrConvertBaudrate = convertBaudrate(i2);
            long j2 = jArrConvertBaudrate[0];
            int iControlTransfer = this.mConnection.controlTransfer(64, 3, (int) jArrConvertBaudrate[2], (int) jArrConvertBaudrate[1], null, 0, 5000);
            if (iControlTransfer == 0) {
                return (int) j2;
            }
            throw new IOException("Setting baudrate failed: result=" + iControlTransfer);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void close() throws IOException {
            UsbDeviceConnection usbDeviceConnection = this.mConnection;
            if (usbDeviceConnection == null) {
                throw new IOException("Already closed");
            }
            try {
                usbDeviceConnection.close();
            } finally {
                this.mConnection = null;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCD() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCTS() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDSR() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDTR() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public UsbSerialDriver getDriver() {
            return FtdiSerialDriver.this;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRI() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRTS() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void open(UsbDeviceConnection usbDeviceConnection) throws IOException {
            if (this.mConnection != null) {
                throw new IOException("Already open");
            }
            this.mConnection = usbDeviceConnection;
            for (int i2 = 0; i2 < this.mDevice.getInterfaceCount(); i2++) {
                try {
                    if (!usbDeviceConnection.claimInterface(this.mDevice.getInterface(i2), true)) {
                        throw new IOException("Error claiming interface " + i2);
                    }
                } catch (Throwable th) {
                    close();
                    this.mConnection = null;
                    throw th;
                }
            }
            reset();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean purgeHwBuffers(boolean z, boolean z2) throws IOException {
            int iControlTransfer;
            int iControlTransfer2;
            if (z && (iControlTransfer2 = this.mConnection.controlTransfer(64, 0, 1, 0, null, 0, 5000)) != 0) {
                throw new IOException("Flushing RX failed: result=" + iControlTransfer2);
            }
            if (!z2 || (iControlTransfer = this.mConnection.controlTransfer(64, 0, 2, 0, null, 0, 5000)) == 0) {
                return true;
            }
            throw new IOException("Flushing RX failed: result=" + iControlTransfer);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int read(byte[] bArr, int i2) {
            int iFilterStatusBytes;
            UsbEndpoint endpoint = this.mDevice.getInterface(0).getEndpoint(0);
            synchronized (this.mReadBufferLock) {
                int iBulkTransfer = this.mConnection.bulkTransfer(endpoint, this.mReadBuffer, Math.min(bArr.length, this.mReadBuffer.length), i2);
                if (iBulkTransfer < 2) {
                    throw new IOException("Expected at least 2 bytes");
                }
                iFilterStatusBytes = filterStatusBytes(this.mReadBuffer, bArr, iBulkTransfer, endpoint.getMaxPacketSize());
            }
            return iFilterStatusBytes;
        }

        public void reset() throws IOException {
            int iControlTransfer = this.mConnection.controlTransfer(64, 0, 0, 0, null, 0, 5000);
            if (iControlTransfer == 0) {
                this.mType = DeviceType.TYPE_R;
                return;
            }
            throw new IOException("Reset failed: result=" + iControlTransfer);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setDTR(boolean z) {
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setParameters(int i2, int i3, int i4, int i5) throws IOException {
            int i6;
            int i7;
            setBaudRate(i2);
            if (i5 == 0) {
                i6 = i3 | 0;
            } else if (i5 == 1) {
                i6 = i3 | 256;
            } else if (i5 == 2) {
                i6 = i3 | 512;
            } else if (i5 == 3) {
                i6 = i3 | 768;
            } else {
                if (i5 != 4) {
                    throw new IllegalArgumentException("Unknown parity value: " + i5);
                }
                i6 = i3 | 1024;
            }
            if (i4 == 1) {
                i7 = i6 | 0;
            } else if (i4 == 2) {
                i7 = i6 | 4096;
            } else {
                if (i4 != 3) {
                    throw new IllegalArgumentException("Unknown stopBits value: " + i4);
                }
                i7 = i6 | 2048;
            }
            int iControlTransfer = this.mConnection.controlTransfer(64, 4, i7, 0, null, 0, 5000);
            if (iControlTransfer == 0) {
                return;
            }
            throw new IOException("Setting parameters failed: result=" + iControlTransfer);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setRTS(boolean z) {
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int write(byte[] bArr, int i2) throws IOException {
            int iMin;
            byte[] bArr2;
            int iBulkTransfer;
            UsbEndpoint endpoint = this.mDevice.getInterface(0).getEndpoint(1);
            int i3 = 0;
            while (i3 < bArr.length) {
                synchronized (this.mWriteBufferLock) {
                    iMin = Math.min(bArr.length - i3, this.mWriteBuffer.length);
                    if (i3 == 0) {
                        bArr2 = bArr;
                    } else {
                        System.arraycopy(bArr, i3, this.mWriteBuffer, 0, iMin);
                        bArr2 = this.mWriteBuffer;
                    }
                    iBulkTransfer = this.mConnection.bulkTransfer(endpoint, bArr2, iMin, i2);
                }
                if (iBulkTransfer <= 0) {
                    throw new IOException("Error writing " + iMin + " bytes at offset " + i3 + " length=" + bArr.length);
                }
                i3 += iBulkTransfer;
            }
            return i3;
        }
    }

    public FtdiSerialDriver(UsbDevice usbDevice) {
        this.mDevice = usbDevice;
        this.mPort = new FtdiSerialPort(usbDevice, 0);
    }

    public static Map<Integer, int[]> getSupportedDevices() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_FTDI), new int[]{UsbId.FTDI_FT232R, UsbId.FTDI_FT231X});
        return linkedHashMap;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public UsbDevice getDevice() {
        return this.mDevice;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public List<UsbSerialPort> getPorts() {
        return Collections.singletonList(this.mPort);
    }
}
