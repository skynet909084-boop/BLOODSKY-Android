package ru.himik.nightscream.kascada.Preference.AlarmSelectSound;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.Toolbar;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class PrefActivitySelectAlarmSound extends androidx.appcompat.app.d {
    MediaPlayer a;
    boolean b = false;
    boolean c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    boolean f9048d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    boolean f9049e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f9050f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f9051g = 1;

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PrefActivitySelectAlarmSound.this.onBackPressed();
        }
    }

    class b implements View.OnClickListener {
        b() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PrefActivitySelectAlarmSound.this.g();
        }
    }

    class c implements MediaPlayer.OnCompletionListener {
        c() {
        }

        @Override // android.media.MediaPlayer.OnCompletionListener
        public void onCompletion(MediaPlayer mediaPlayer) {
            PrefActivitySelectAlarmSound prefActivitySelectAlarmSound = PrefActivitySelectAlarmSound.this;
            prefActivitySelectAlarmSound.b = false;
            ((ImageButton) prefActivitySelectAlarmSound.findViewById(R.id.btnPlay1)).setBackgroundResource(R.drawable.start);
        }
    }

    class d implements MediaPlayer.OnCompletionListener {
        d() {
        }

        @Override // android.media.MediaPlayer.OnCompletionListener
        public void onCompletion(MediaPlayer mediaPlayer) {
            PrefActivitySelectAlarmSound prefActivitySelectAlarmSound = PrefActivitySelectAlarmSound.this;
            prefActivitySelectAlarmSound.c = false;
            ((ImageButton) prefActivitySelectAlarmSound.findViewById(R.id.btnPlay2)).setBackgroundResource(R.drawable.start);
        }
    }

    class e implements MediaPlayer.OnCompletionListener {
        e() {
        }

        @Override // android.media.MediaPlayer.OnCompletionListener
        public void onCompletion(MediaPlayer mediaPlayer) {
            PrefActivitySelectAlarmSound prefActivitySelectAlarmSound = PrefActivitySelectAlarmSound.this;
            prefActivitySelectAlarmSound.f9048d = false;
            ((ImageButton) prefActivitySelectAlarmSound.findViewById(R.id.btnPlay3)).setBackgroundResource(R.drawable.start);
        }
    }

    class f implements MediaPlayer.OnCompletionListener {
        f() {
        }

        @Override // android.media.MediaPlayer.OnCompletionListener
        public void onCompletion(MediaPlayer mediaPlayer) {
            PrefActivitySelectAlarmSound prefActivitySelectAlarmSound = PrefActivitySelectAlarmSound.this;
            prefActivitySelectAlarmSound.f9049e = false;
            ((ImageButton) prefActivitySelectAlarmSound.findViewById(R.id.btnPlay4)).setBackgroundResource(R.drawable.start);
        }
    }

    class g implements MediaPlayer.OnCompletionListener {
        g() {
        }

        @Override // android.media.MediaPlayer.OnCompletionListener
        public void onCompletion(MediaPlayer mediaPlayer) {
            PrefActivitySelectAlarmSound prefActivitySelectAlarmSound = PrefActivitySelectAlarmSound.this;
            prefActivitySelectAlarmSound.f9050f = false;
            ((ImageButton) prefActivitySelectAlarmSound.findViewById(R.id.btnPlay5)).setBackgroundResource(R.drawable.start);
        }
    }

    private void f() {
        MediaPlayer mediaPlayer = this.a;
        if (mediaPlayer != null) {
            try {
                mediaPlayer.release();
                this.a = null;
                ((ImageButton) findViewById(R.id.btnPlay1)).setBackgroundResource(R.drawable.start);
                ((ImageButton) findViewById(R.id.btnPlay2)).setBackgroundResource(R.drawable.start);
                ((ImageButton) findViewById(R.id.btnPlay3)).setBackgroundResource(R.drawable.start);
                ((ImageButton) findViewById(R.id.btnPlay4)).setBackgroundResource(R.drawable.start);
                ((ImageButton) findViewById(R.id.btnPlay5)).setBackgroundResource(R.drawable.start);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public void g() {
        Intent intent = getIntent();
        intent.putExtra("POSITION", this.f9051g);
        setResult(-1, intent);
        finish();
    }

    void h(int i2) {
        View viewFindViewById;
        ((RelativeLayout) findViewById(R.id.line1)).setBackgroundColor(getResources().getColor(R.color.second_background));
        ((RelativeLayout) findViewById(R.id.line2)).setBackgroundColor(getResources().getColor(R.color.second_background));
        ((RelativeLayout) findViewById(R.id.line3)).setBackgroundColor(getResources().getColor(R.color.second_background));
        ((RelativeLayout) findViewById(R.id.line4)).setBackgroundColor(getResources().getColor(R.color.second_background));
        ((RelativeLayout) findViewById(R.id.line5)).setBackgroundColor(getResources().getColor(R.color.second_background));
        if (i2 == 1) {
            ((RelativeLayout) findViewById(R.id.line1)).setBackgroundColor(getResources().getColor(R.color.select_line));
            this.f9051g = 1;
            return;
        }
        int i3 = 2;
        if (i2 != 2) {
            i3 = 3;
            if (i2 != 3) {
                i3 = 4;
                if (i2 != 4) {
                    i3 = 5;
                    if (i2 != 5) {
                        return;
                    } else {
                        viewFindViewById = findViewById(R.id.line5);
                    }
                } else {
                    viewFindViewById = findViewById(R.id.line4);
                }
            } else {
                viewFindViewById = findViewById(R.id.line3);
            }
        } else {
            viewFindViewById = findViewById(R.id.line2);
        }
        ((RelativeLayout) viewFindViewById).setBackgroundColor(getResources().getColor(R.color.select_line));
        this.f9051g = i3;
    }

    public void onClickBtnPlay(View view) {
        f();
        switch (view.getId()) {
            case R.id.btnPlay1 /* 2131296446 */:
                if (!this.b) {
                    MediaPlayer mediaPlayerCreate = MediaPlayer.create(getApplicationContext(), R.raw.alarm1mp3);
                    this.a = mediaPlayerCreate;
                    mediaPlayerCreate.start();
                    this.a.setOnCompletionListener(new c());
                    ((ImageButton) findViewById(R.id.btnPlay1)).setBackgroundResource(R.drawable.stop);
                    this.b = true;
                } else {
                    this.b = false;
                }
                break;
            case R.id.btnPlay2 /* 2131296447 */:
                if (!this.c) {
                    MediaPlayer mediaPlayerCreate2 = MediaPlayer.create(this, R.raw.alarm2mp3);
                    this.a = mediaPlayerCreate2;
                    mediaPlayerCreate2.start();
                    this.a.setOnCompletionListener(new d());
                    ((ImageButton) findViewById(R.id.btnPlay2)).setBackgroundResource(R.drawable.stop);
                    this.c = true;
                } else {
                    this.c = false;
                }
                break;
            case R.id.btnPlay3 /* 2131296448 */:
                if (!this.f9048d) {
                    MediaPlayer mediaPlayerCreate3 = MediaPlayer.create(this, R.raw.alarm3mp3);
                    this.a = mediaPlayerCreate3;
                    mediaPlayerCreate3.start();
                    this.a.setOnCompletionListener(new e());
                    ((ImageButton) findViewById(R.id.btnPlay3)).setBackgroundResource(R.drawable.stop);
                    this.f9048d = true;
                } else {
                    this.f9048d = false;
                }
                break;
            case R.id.btnPlay4 /* 2131296449 */:
                if (!this.f9049e) {
                    MediaPlayer mediaPlayerCreate4 = MediaPlayer.create(this, R.raw.alarm4mp3);
                    this.a = mediaPlayerCreate4;
                    mediaPlayerCreate4.start();
                    this.a.setOnCompletionListener(new f());
                    ((ImageButton) findViewById(R.id.btnPlay4)).setBackgroundResource(R.drawable.stop);
                    this.f9049e = true;
                } else {
                    this.f9049e = false;
                }
                break;
            case R.id.btnPlay5 /* 2131296450 */:
                if (!this.f9050f) {
                    MediaPlayer mediaPlayerCreate5 = MediaPlayer.create(this, R.raw.alarm5mp3);
                    this.a = mediaPlayerCreate5;
                    mediaPlayerCreate5.start();
                    this.a.setOnCompletionListener(new g());
                    ((ImageButton) findViewById(R.id.btnPlay5)).setBackgroundResource(R.drawable.stop);
                    this.f9050f = true;
                } else {
                    this.f9050f = false;
                }
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0013  */
    /* JADX WARN: Code duplicated, block: B:6:0x000b  */
    /* JADX WARN: Code duplicated, block: B:7:0x000d  */
    /* JADX WARN: Code duplicated, block: B:8:0x000f  */
    /* JADX WARN: Code duplicated, block: B:9:0x0011  */
    public void onClickLine(View view) {
        int i2;
        int id = view.getId();
        switch (id) {
            case R.id.line1 /* 2131296762 */:
                i2 = 1;
                h(i2);
                break;
            case R.id.line2 /* 2131296763 */:
                i2 = 2;
                h(i2);
                break;
            case R.id.line3 /* 2131296764 */:
                i2 = 3;
                h(i2);
                break;
            case R.id.line4 /* 2131296765 */:
                i2 = 4;
                h(i2);
                break;
            case R.id.line5 /* 2131296766 */:
                i2 = 5;
                h(i2);
                break;
            default:
                switch (id) {
                    case R.id.text1 /* 2131297175 */:
                        i2 = 1;
                        break;
                    case R.id.text2 /* 2131297176 */:
                        i2 = 2;
                        break;
                    case R.id.text3 /* 2131297177 */:
                        i2 = 3;
                        break;
                    case R.id.text4 /* 2131297178 */:
                        i2 = 4;
                        break;
                    case R.id.text5 /* 2131297179 */:
                        i2 = 5;
                        break;
                }
                h(i2);
                break;
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.alarm_sound_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(getApplicationContext().getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getApplicationContext().getResources().getString(R.string.alarm_select));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
        }
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new a());
        }
        h(getIntent().getIntExtra("POSITION", 1));
        findViewById(R.id.selectButton).setOnClickListener(new b());
    }
}
