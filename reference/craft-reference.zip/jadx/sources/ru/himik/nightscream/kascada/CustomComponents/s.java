package ru.himik.nightscream.kascada.CustomComponents;

import java.util.Date;

/* JADX INFO: loaded from: classes2.dex */
public class s {
    float a;
    float b;
    float c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    float f8884d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    Date f8885e;

    public s(float f2, float f3, float f4, float f5, Date date) {
        this.a = 0.0f;
        this.b = 0.0f;
        this.c = 0.0f;
        this.f8884d = 0.0f;
        this.f8885e = new Date(0L);
        this.a = f2;
        this.b = f3;
        this.c = f4;
        this.f8884d = f5;
        this.f8885e = date;
    }

    public Date a() {
        return this.f8885e;
    }

    public float b() {
        return this.a;
    }

    public float c() {
        return this.b;
    }

    public float d() {
        return this.c;
    }

    public float e() {
        return this.f8884d;
    }
}
