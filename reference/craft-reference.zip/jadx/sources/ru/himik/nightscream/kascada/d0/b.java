package ru.himik.nightscream.kascada.d0;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class b {
    private final ConstraintLayout a;
    public final ImageView b;
    public final TextView c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final TextView f9195d;

    private b(ConstraintLayout constraintLayout, ImageView imageView, TextView textView, TextView textView2, View view) {
        this.a = constraintLayout;
        this.b = imageView;
        this.c = textView;
        this.f9195d = textView2;
    }

    public static b a(View view) {
        int i2 = R.id.ivMic;
        ImageView imageView = (ImageView) view.findViewById(R.id.ivMic);
        if (imageView != null) {
            i2 = R.id.textNoBilling;
            TextView textView = (TextView) view.findViewById(R.id.textNoBilling);
            if (textView != null) {
                i2 = R.id.textRecognition;
                TextView textView2 = (TextView) view.findViewById(R.id.textRecognition);
                if (textView2 != null) {
                    i2 = R.id.view;
                    View viewFindViewById = view.findViewById(R.id.view);
                    if (viewFindViewById != null) {
                        return new b((ConstraintLayout) view, imageView, textView, textView2, viewFindViewById);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i2)));
    }

    public static b c(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.bottomsheet_voice_recognition, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return a(viewInflate);
    }

    public ConstraintLayout b() {
        return this.a;
    }
}
