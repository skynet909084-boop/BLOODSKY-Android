package ru.himik.nightscream.kascada.Utils;

/* JADX INFO: loaded from: classes2.dex */
public final class m {
    private final int a;

    public m(int i2) {
        this.a = i2;
    }

    public final int a() {
        return this.a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof m) && this.a == ((m) obj).a;
    }

    public int hashCode() {
        return this.a;
    }

    public String toString() {
        return "CommandForegroundService(command=" + this.a + ')';
    }
}
