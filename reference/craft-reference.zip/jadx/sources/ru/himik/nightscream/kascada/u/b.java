package ru.himik.nightscream.kascada.u;

import android.text.TextUtils;
import com.sun.mail.util.MailSSLSocketFactory;
import j.a.e;
import j.a.g;
import j.c.d0;
import j.c.h0;
import j.c.l0.f;
import j.c.l0.i;
import j.c.l0.j;
import j.c.l0.k;
import j.c.n;
import j.c.t;
import j.c.x;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.Security;
import java.util.Properties;

/* JADX INFO: loaded from: classes2.dex */
public class b extends j.c.c {
    private String a;
    private String b;
    private d0 c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private t f9385d;

    public class a implements g {
        private byte[] a;
        private String b;

        public a(b bVar, byte[] bArr, String str) {
            this.a = bArr;
            this.b = str;
        }

        @Override // j.a.g
        public String getContentType() {
            String str = this.b;
            return str != null ? str : "application/octet-stream";
        }

        @Override // j.a.g
        public InputStream getInputStream() {
            return new ByteArrayInputStream(this.a);
        }

        @Override // j.a.g
        public String getName() {
            return "ByteArrayDataSource";
        }
    }

    static {
        Security.addProvider(new c());
    }

    public b(String str, String str2, boolean z) {
        MailSSLSocketFactory mailSSLSocketFactory;
        GeneralSecurityException e2;
        this.a = str;
        this.b = str2;
        try {
            mailSSLSocketFactory = new MailSSLSocketFactory();
            try {
                mailSSLSocketFactory.setTrustAllHosts(true);
            } catch (GeneralSecurityException e3) {
                e2 = e3;
                e2.printStackTrace();
            }
        } catch (GeneralSecurityException e4) {
            mailSSLSocketFactory = null;
            e2 = e4;
        }
        Properties properties = new Properties();
        properties.setProperty("mail.transport.protocol", "smtp");
        properties.setProperty("mail.host", "smtp.gmail.com");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.socketFactory.port", "465");
        properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        properties.put("mail.smtp.socketFactory.fallback", "false");
        properties.setProperty("mail.smtp.quitwait", "false");
        properties.put("mail.smtps.socketFactory", mailSSLSocketFactory);
        properties.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        this.c = z ? d0.g(properties, this) : d0.i(properties, this);
        this.f9385d = new k();
    }

    public void a(String str) {
        i iVar = new i();
        j.a.i iVar2 = new j.a.i(str);
        iVar.setDataHandler(new e(iVar2));
        iVar.setFileName(iVar2.getName());
        this.f9385d.a(iVar);
    }

    public synchronized void b(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
        j jVar = new j(this.c);
        jVar.setFrom(TextUtils.isEmpty(str4) ? new f(str3) : new f(str3, str4));
        jVar.setSubject(str);
        jVar.setDataHandler(new e(new a(this, str2.getBytes(), str8)));
        jVar.setText(str2);
        if (this.f9385d.d() > 0) {
            i iVar = new i();
            iVar.setText(str2);
            this.f9385d.a(iVar);
            jVar.setContent(this.f9385d);
        }
        if (!TextUtils.isEmpty(str5)) {
            if (str5.indexOf(44) > 0) {
                jVar.setRecipients(n.a.b, f.parse(str5));
            } else {
                jVar.setRecipient(n.a.b, new f(str5));
            }
        }
        if (!TextUtils.isEmpty(str6)) {
            if (str6.indexOf(44) > 0) {
                jVar.setRecipients(n.a.c, f.parse(str6));
            } else {
                jVar.setRecipient(n.a.c, new f(str6));
            }
        }
        if (!TextUtils.isEmpty(str7)) {
            if (str7.indexOf(44) > 0) {
                jVar.setRecipients(n.a.f7493d, f.parse(str7));
            } else {
                jVar.setRecipient(n.a.f7493d, new f(str7));
            }
        }
        h0.send(jVar);
    }

    @Override // j.c.c
    protected x getPasswordAuthentication() {
        return new x(this.a, this.b);
    }
}
