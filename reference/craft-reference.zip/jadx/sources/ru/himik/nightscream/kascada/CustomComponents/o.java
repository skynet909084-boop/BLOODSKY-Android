package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.Random;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class o extends n.a.a implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    private long A0;
    final Runnable B0;
    public Point C0;
    public n.a.f.d F;
    public n.a.g.d G;
    n.a.f.c H;
    n.a.f.c I;
    n.a.f.c J;
    n.a.f.c K;
    n.a.g.e L;
    n.a.g.e M;
    n.a.g.e N;
    n.a.g.e O;
    public String P;
    int Q;
    int R;
    public byte S;
    public ru.himik.nightscream.kascada.CustomComponents.b T;
    int U;
    private d V;
    private Handler W;
    private Runnable a0;
    private Thread b0;
    public boolean c0;
    int d0;
    private String e0;
    private String f0;
    private String g0;
    private String h0;
    private int i0;
    boolean j0;
    int k0;
    boolean l0;
    int m0;
    int n0;
    private boolean o0;
    private boolean p0;
    Bitmap q0;
    Paint r0;
    Paint s0;
    boolean t0;
    long u0;
    int v0;
    byte[] w0;
    boolean x0;
    int y0;
    int z0;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                Thread.sleep(500L);
                Message messageObtainMessage = o.this.W.obtainMessage();
                messageObtainMessage.arg1 = 1;
                messageObtainMessage.sendToTarget();
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            o oVar = o.this;
            if (oVar.l0) {
                oVar.n();
                try {
                    mbCanvas.F(o.this.T.k(), o.this.T);
                } catch (Exception unused) {
                }
            }
        }
    }

    class c extends Handler {
        final /* synthetic */ View a;

        c(View view) {
            this.a = view;
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            o oVar = o.this;
            if (oVar.c0) {
                oVar.V.onLongClick(this.a);
            }
            super.handleMessage(message);
        }
    }

    public interface d {
        boolean onLongClick(View view);
    }

    public o(Context context, n.a.e.a aVar) {
        super(context, aVar);
        this.F = new n.a.f.d();
        this.G = new n.a.g.d();
        this.H = new n.a.f.c("1");
        this.I = new n.a.f.c("2");
        this.J = new n.a.f.c("3");
        this.K = new n.a.f.c("4");
        this.L = new n.a.g.e();
        this.M = new n.a.g.e();
        this.N = new n.a.g.e();
        this.O = new n.a.g.e();
        this.P = getResources().getString(R.string.custom_graph);
        this.Q = 14;
        this.S = (byte) 3;
        this.T = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.c0 = false;
        this.d0 = -16777216;
        this.e0 = "1";
        this.f0 = "2";
        this.g0 = "3";
        this.h0 = "4";
        this.i0 = 1;
        this.j0 = false;
        this.k0 = 500;
        this.l0 = false;
        this.m0 = 300;
        this.n0 = -1;
        this.q0 = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.r0 = new Paint();
        this.s0 = new Paint();
        this.t0 = false;
        this.u0 = 0L;
        this.v0 = 1;
        this.w0 = new byte[4];
        this.x0 = false;
        this.y0 = 0;
        this.z0 = 0;
        this.A0 = 0L;
        this.B0 = new b();
        this.C0 = new Point();
    }

    private void j() {
        n.a.f.c cVar;
        int i2 = this.i0;
        if (i2 != 1) {
            if (i2 == 2) {
                if (this.H.j() > this.m0) {
                    this.H.w(0);
                }
                if (this.I.j() <= this.m0) {
                    return;
                } else {
                    cVar = this.I;
                }
            } else if (i2 == 3) {
                if (this.H.j() > this.m0) {
                    this.H.w(0);
                }
                if (this.I.j() > this.m0) {
                    this.I.w(0);
                }
                if (this.J.j() <= this.m0) {
                    return;
                } else {
                    cVar = this.J;
                }
            } else {
                if (i2 != 4) {
                    return;
                }
                if (this.H.j() > this.m0) {
                    this.H.w(0);
                }
                if (this.I.j() > this.m0) {
                    this.I.w(0);
                }
                if (this.J.j() > this.m0) {
                    this.J.w(0);
                }
                if (this.K.j() <= this.m0) {
                    return;
                } else {
                    cVar = this.K;
                }
            }
        } else if (this.H.j() <= this.m0) {
            return;
        } else {
            cVar = this.H;
        }
        cVar.w(0);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.C0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void g(int[] iArr) {
        n.a.f.c cVar;
        Date date;
        int i2;
        int i3;
        char c2;
        n.a.f.c cVar2;
        Date date2;
        char c3;
        int i4;
        int i5;
        n.a.f.c cVar3;
        Date date3;
        float fH;
        int i6 = this.v0;
        if (i6 == 0) {
            int length = iArr.length;
            if (length == 2) {
                cVar = this.H;
                date = new Date();
                i2 = iArr[0] * 256;
                i3 = iArr[1];
            } else if (length == 4) {
                this.H.z(new Date(), (short) ((iArr[0] * 256) + iArr[1]));
                cVar = this.I;
                date = new Date();
                i2 = iArr[2] * 256;
                i3 = iArr[3];
            } else if (length == 6) {
                this.H.z(new Date(), (short) ((iArr[0] * 256) + iArr[1]));
                this.I.z(new Date(), (short) ((iArr[2] * 256) + iArr[3]));
                cVar = this.J;
                date = new Date();
                i2 = iArr[4] * 256;
                i3 = iArr[5];
            } else if (length == 8) {
                this.H.z(new Date(), (short) ((iArr[0] * 256) + iArr[1]));
                this.I.z(new Date(), (short) ((iArr[2] * 256) + iArr[3]));
                this.J.z(new Date(), (short) ((iArr[4] * 256) + iArr[5]));
                cVar2 = this.K;
                date2 = new Date();
                c3 = (short) ((iArr[6] * 256) + iArr[7]);
                cVar2.z(date2, c3);
            }
            c2 = (short) (i2 + i3);
            cVar.z(date, c2);
        } else if (i6 == 1) {
            int length2 = iArr.length;
            if (length2 == 2) {
                cVar = this.H;
                date = new Date();
                i4 = iArr[0] * 256;
                i5 = iArr[1];
            } else if (length2 == 4) {
                this.H.z(new Date(), (char) ((iArr[0] * 256) + iArr[1]));
                cVar = this.I;
                date = new Date();
                i4 = iArr[2] * 256;
                i5 = iArr[3];
            } else if (length2 == 6) {
                this.H.z(new Date(), (char) ((iArr[0] * 256) + iArr[1]));
                this.I.z(new Date(), (char) ((iArr[2] * 256) + iArr[3]));
                cVar = this.J;
                date = new Date();
                i4 = iArr[4] * 256;
                i5 = iArr[5];
            } else if (length2 == 8) {
                this.H.z(new Date(), (char) ((iArr[0] * 256) + iArr[1]));
                this.I.z(new Date(), (char) ((iArr[2] * 256) + iArr[3]));
                this.J.z(new Date(), (char) ((iArr[4] * 256) + iArr[5]));
                cVar2 = this.K;
                date2 = new Date();
                c3 = (char) ((iArr[6] * 256) + iArr[7]);
                cVar2.z(date2, c3);
            }
            c2 = (char) (i4 + i5);
            cVar.z(date, c2);
        } else if (i6 == 2) {
            int length3 = iArr.length;
            if (length3 == 4) {
                byte[] bArr = this.w0;
                bArr[0] = (byte) iArr[0];
                bArr[1] = (byte) iArr[1];
                bArr[2] = (byte) iArr[2];
                bArr[3] = (byte) iArr[3];
                cVar3 = this.H;
                date3 = new Date();
                fH = h(this.w0);
            } else if (length3 == 8) {
                byte[] bArr2 = this.w0;
                bArr2[0] = (byte) iArr[0];
                bArr2[1] = (byte) iArr[1];
                bArr2[2] = (byte) iArr[2];
                bArr2[3] = (byte) iArr[3];
                this.H.z(new Date(), h(this.w0));
                byte[] bArr3 = this.w0;
                bArr3[0] = (byte) iArr[4];
                bArr3[1] = (byte) iArr[5];
                bArr3[2] = (byte) iArr[6];
                bArr3[3] = (byte) iArr[7];
                cVar3 = this.I;
                date3 = new Date();
                fH = h(this.w0);
            } else if (length3 == 12) {
                byte[] bArr4 = this.w0;
                bArr4[0] = (byte) iArr[0];
                bArr4[1] = (byte) iArr[1];
                bArr4[2] = (byte) iArr[2];
                bArr4[3] = (byte) iArr[3];
                this.H.z(new Date(), h(this.w0));
                byte[] bArr5 = this.w0;
                bArr5[0] = (byte) iArr[4];
                bArr5[1] = (byte) iArr[5];
                bArr5[2] = (byte) iArr[6];
                bArr5[3] = (byte) iArr[7];
                this.I.z(new Date(), h(this.w0));
                byte[] bArr6 = this.w0;
                bArr6[0] = (byte) iArr[8];
                bArr6[1] = (byte) iArr[9];
                bArr6[2] = (byte) iArr[10];
                bArr6[3] = (byte) iArr[11];
                cVar3 = this.J;
                date3 = new Date();
                fH = h(this.w0);
            } else if (length3 == 16) {
                byte[] bArr7 = this.w0;
                bArr7[0] = (byte) iArr[0];
                bArr7[1] = (byte) iArr[1];
                bArr7[2] = (byte) iArr[2];
                bArr7[3] = (byte) iArr[3];
                this.H.z(new Date(), h(this.w0));
                byte[] bArr8 = this.w0;
                bArr8[0] = (byte) iArr[4];
                bArr8[1] = (byte) iArr[5];
                bArr8[2] = (byte) iArr[6];
                bArr8[3] = (byte) iArr[7];
                this.I.z(new Date(), h(this.w0));
                byte[] bArr9 = this.w0;
                bArr9[0] = (byte) iArr[8];
                bArr9[1] = (byte) iArr[9];
                bArr9[2] = (byte) iArr[10];
                bArr9[3] = (byte) iArr[11];
                this.J.z(new Date(), h(this.w0));
                byte[] bArr10 = this.w0;
                bArr10[0] = (byte) iArr[12];
                bArr10[1] = (byte) iArr[13];
                bArr10[2] = (byte) iArr[14];
                bArr10[3] = (byte) iArr[15];
                cVar3 = this.K;
                date3 = new Date();
                fH = h(this.w0);
            }
            cVar3.z(date3, fH);
        }
        if (System.currentTimeMillis() - this.u0 > 5000) {
            this.t0 = false;
        }
        if (this.H.j() > 2 && !this.t0) {
            this.G.b1(this.H.k());
            this.G.d1(this.H.m());
            this.G.g1(Math.max(Math.max(this.H.l(), this.I.l()), Math.max(this.J.l(), this.K.l())));
            this.G.i1(Math.min(Math.min(this.H.n(), this.I.n()), Math.min(this.J.n(), this.K.n())));
        }
        try {
            if (this.H.j() == 2 && !this.j0) {
                this.H.w(0);
                this.I.w(0);
                this.J.w(0);
                this.K.w(0);
                this.j0 = true;
            }
        } catch (Exception unused) {
        }
        j();
        a();
    }

    public int getColorBackground_() {
        return this.d0;
    }

    public int getColorLabelsXY() {
        return this.n0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.T;
    }

    public int getCountGraphChannel() {
        return this.i0;
    }

    public int getCountPoint() {
        return this.m0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.Q;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.U;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.y0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.z0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.Q;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.T.l());
        jSONObject.put("addressRegister", this.T.c());
        jSONObject.put("addressBit", (int) this.T.a());
        jSONObject.put("typeRequest", (int) this.T.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("colorLabelsXY", getColorLabelsXY());
        jSONObject.put("secondPeriod", getSecondPeriod());
        jSONObject.put("countPoint", getCountPoint());
        jSONObject.put("colorBackground", getColorBackground_());
        jSONObject.put("nameSeries1", this.e0);
        jSONObject.put("nameSeries2", this.f0);
        jSONObject.put("nameSeries3", this.g0);
        jSONObject.put("nameSeries4", this.h0);
        jSONObject.put("countGraphChannel", this.i0);
        jSONObject.put("typeGraph", getType());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.R;
    }

    public String getNameSeries1() {
        return this.e0;
    }

    public String getNameSeries2() {
        return this.f0;
    }

    public String getNameSeries3() {
        return this.g0;
    }

    public String getNameSeries4() {
        return this.h0;
    }

    public int getNumScreen() {
        return this.U;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.C0;
    }

    public int getSecondPeriod() {
        return this.k0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.T.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.T.l() >= 100) {
            this.T.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.T.c();
        }
        this.T.u((byte) MyApplication.b().E.get(this.T.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.T.b()) + "#" + this.T.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.T.l() >= 0) {
            if (this.T.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.T.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.A0;
    }

    public int getType() {
        return this.v0;
    }

    public float h(byte[] bArr) {
        return ByteBuffer.wrap(bArr).getFloat();
    }

    public void i() {
        int i2 = this.i0;
        if (i2 != 1) {
            if (i2 == 2) {
                this.L.f(-65536);
                this.M.f(-16711936);
            } else {
                if (i2 != 3) {
                    if (i2 != 4) {
                        return;
                    }
                    this.L.f(-65536);
                    this.M.f(-16711936);
                    this.N.f(-256);
                    this.O.f(-16776961);
                    return;
                }
                this.L.f(-65536);
                this.M.f(-16711936);
                this.N.f(-256);
            }
            this.O.f(0);
        }
        this.L.f(-65536);
        this.M.f(0);
        this.N.f(0);
        this.O.f(0);
    }

    public void k(View view) {
        Thread thread = new Thread(this.a0);
        this.b0 = thread;
        thread.start();
        this.W = l(view);
        this.c0 = true;
    }

    public Handler l(View view) {
        return new c(view);
    }

    public void m(int i2, int i3, int i4, boolean z) {
        this.H.b();
        this.I.b();
        this.J.b();
        this.K.b();
        i();
        this.F.a(this.H);
        this.F.a(this.I);
        this.F.a(this.J);
        this.F.a(this.K);
        this.G.a(this.L);
        this.G.a(this.M);
        this.G.a(this.N);
        this.G.a(this.O);
        this.G.Y(0);
        n.a.g.e eVar = this.L;
        n.a.e.d dVar = n.a.e.d.CIRCLE;
        eVar.w(dVar);
        this.L.v(2.0f);
        this.L.u(true);
        this.M.w(dVar);
        this.M.v(2.0f);
        this.M.u(true);
        this.N.w(dVar);
        this.N.v(2.0f);
        this.N.u(true);
        this.O.w(dVar);
        this.O.v(2.0f);
        this.O.u(true);
        this.G.P(2.0f);
        this.G.X0(-7829368);
        this.G.T(true);
        this.H.a(new Date().getTime(), new Random().nextInt(10));
        this.H.a(new Date().getTime() + 1000, new Random().nextInt(10));
        this.H.a(new Date().getTime() + 2000, new Random().nextInt(10));
        this.H.a(new Date().getTime() + 3000, new Random().nextInt(10));
        this.I.a(new Date().getTime(), new Random().nextInt(10));
        this.I.a(new Date().getTime() + 1000, new Random().nextInt(10));
        this.I.a(new Date().getTime() + 2000, new Random().nextInt(10));
        this.I.a(new Date().getTime() + 3000, new Random().nextInt(10));
        this.J.a(new Date().getTime(), new Random().nextInt(10));
        this.J.a(new Date().getTime() + 1000, new Random().nextInt(10));
        this.J.a(new Date().getTime() + 2000, new Random().nextInt(10));
        this.J.a(new Date().getTime() + 3000, new Random().nextInt(10));
        this.K.a(new Date().getTime(), new Random().nextInt(10));
        this.K.a(new Date().getTime() + 1000, new Random().nextInt(10));
        this.K.a(new Date().getTime() + 2000, new Random().nextInt(10));
        this.K.a(new Date().getTime() + 3000, new Random().nextInt(10));
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width) * 2.0f);
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setBackgroundColor(this.d0);
        setKey(i4);
        this.a0 = new a();
    }

    void n() {
        if (this.k0 < 100) {
            this.k0 = 100;
        }
        postDelayed(this.B0, this.k0);
    }

    public void o() {
        this.c0 = false;
    }

    @Override // n.a.a, android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.p0) {
            this.s0.setColor(-65536);
            this.s0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.s0);
        }
        if (this.o0 && mbCanvas.g1) {
            canvas.drawBitmap(this.q0, (getWidth() / 2) - (this.q0.getWidth() / 2), (getHeight() / 2) - this.q0.getHeight(), this.r0);
        }
        if (this.x0) {
            this.s0.setColor(-16711936);
            this.s0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.s0);
        }
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.x0;
    }

    public void setColorBackground_(int i2) {
        this.d0 = i2;
        setBackgroundColor(i2);
    }

    public void setConnectionError(boolean z) {
        this.p0 = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.o0 = z;
    }

    public void setCountGraphChannel(int i2) {
        this.i0 = i2;
        setType(getType());
        i();
    }

    public void setCountPoint(int i2) {
        this.m0 = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.x0 = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.y0 = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.z0 = i2;
    }

    public void setFont(String str) {
    }

    public void setIdComponent(int i2) {
        this.Q = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.R = i2;
    }

    public void setLockZoom(boolean z) {
        this.t0 = z;
    }

    public void setNameSeries1(String str) {
        this.e0 = str;
        this.H.x(str);
    }

    public void setNameSeries2(String str) {
        this.f0 = str;
        this.I.x(str);
    }

    public void setNameSeries3(String str) {
        this.g0 = str;
        this.J.x(str);
    }

    public void setNameSeries4(String str) {
        this.h0 = str;
        this.K.x(str);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.U = i2;
    }

    public void setOnLongGraphClick(d dVar) {
        this.V = dVar;
    }

    public void setSecondPeriod(int i2) {
        this.k0 = i2;
    }

    public void setTimeLastTouch(long j2) {
        this.u0 = j2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.A0 = j2;
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0018  */
    public void setType(int i2) {
        ru.himik.nightscream.kascada.CustomComponents.b bVar;
        int i3;
        this.v0 = i2;
        if (i2 != 0) {
            i3 = 1;
            if (i2 == 1) {
                this.T.z((byte) this.i0);
                bVar = this.T;
                i3 = 0;
            } else {
                if (i2 != 2) {
                    return;
                }
                this.T.z((byte) (this.i0 * 2));
                bVar = this.T;
            }
        } else {
            this.T.z((byte) this.i0);
            bVar = this.T;
            i3 = 0;
        }
        bVar.K(i3);
    }

    public void setWorkMode(boolean z) {
        this.l0 = z;
        if (!z) {
            removeCallbacks(this.B0);
            return;
        }
        this.j0 = false;
        this.H.b();
        this.I.b();
        this.J.b();
        this.K.b();
        this.H.a(new Date().getTime(), 0.0d);
        this.I.a(new Date().getTime(), 0.0d);
        this.J.a(new Date().getTime(), 0.0d);
        this.K.a(new Date().getTime(), 0.0d);
        n();
    }
}
