package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.z;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameIn;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameOut;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.n;

/* JADX INFO: loaded from: classes2.dex */
public class FB_MACRO extends ru.himik.nightscream.kascada.Logic.c.e {
    public FB_MACRO(Context context) {
        super(context);
        setName("MCR");
    }

    public FB_MACRO(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setName("MACROS");
        this.E.h("I1");
        this.F.h("I2");
        this.G.h("I3");
        this.H.h("I4");
        this.I.h("Q");
        this.f9004n = true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.e, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.e, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.VarName.a aVar;
        String str;
        ru.himik.nightscream.kascada.Logic.c.e.a aVar2;
        int countIn = getCountIn();
        if (countIn != 1) {
            if (countIn == 2) {
                if (this.E.b() != null) {
                    MyApplication.A0.h(this.c + "_" + this.E.a.getVarName(), this.E.b().getOut());
                }
                if (this.F.b() == null) {
                    return;
                }
                aVar = MyApplication.A0;
                str = this.c + "_" + this.F.a.getVarName();
                aVar2 = this.F;
            } else if (countIn == 3) {
                if (this.E.b() != null) {
                    MyApplication.A0.h(this.c + "_" + this.E.a.getVarName(), this.E.b().getOut());
                }
                if (this.F.b() != null) {
                    MyApplication.A0.h(this.c + "_" + this.F.a.getVarName(), this.F.b().getOut());
                }
                if (this.G.b() == null) {
                    return;
                }
                aVar = MyApplication.A0;
                str = this.c + "_" + this.G.a.getVarName();
                aVar2 = this.G;
            } else {
                if (countIn != 4) {
                    return;
                }
                if (this.E.b() != null) {
                    MyApplication.A0.h(this.c + "_" + this.E.a.getVarName(), this.E.b().getOut());
                }
                if (this.F.b() != null) {
                    MyApplication.A0.h(this.c + "_" + this.F.a.getVarName(), this.F.b().getOut());
                }
                if (this.G.b() != null) {
                    MyApplication.A0.h(this.c + "_" + this.G.a.getVarName(), this.G.b().getOut());
                }
                if (this.H.b() == null) {
                    return;
                }
                aVar = MyApplication.A0;
                str = this.c + "_" + this.H.a.getVarName();
                aVar2 = this.H;
            }
        } else {
            if (this.E.b() == null) {
                return;
            }
            aVar = MyApplication.A0;
            str = this.c + "_" + this.E.a.getVarName();
            aVar2 = this.E;
        }
        aVar.h(str, aVar2.b().getOut());
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.e, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("uniqueId", this.c);
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        jSONObject.put(IMAPStore.ID_NAME, getName());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.e, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        if (q() != null) {
            jSONObject.put("keyOut", q().getKey());
        } else {
            jSONObject.put("keyOut", -1);
        }
        jSONObject.put(IMAPStore.ID_NAME, getName());
        jSONObject.put("countIn", getCountIn());
        jSONObject.put("uniqueId", 0);
        jSONObject.put("nameIn1", this.E.c());
        jSONObject.put("typeIn1", this.E.e());
        jSONObject.put("numOnIn1", this.E.a.getNumOnIn());
        if (this.E.a.q() != null) {
            jSONObject.put("keyOutIn1", this.E.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn1", -1);
        }
        jSONObject.put("nameIn2", this.F.c());
        jSONObject.put("typeIn2", this.F.e());
        jSONObject.put("numOnIn2", this.F.a.getNumOnIn());
        if (this.F.a.q() != null) {
            jSONObject.put("keyOutIn2", this.F.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn2", -1);
        }
        jSONObject.put("nameIn3", this.G.c());
        jSONObject.put("typeIn3", this.G.e());
        jSONObject.put("numOnIn3", this.G.a.getNumOnIn());
        if (this.G.a.q() != null) {
            jSONObject.put("keyOutIn3", this.G.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn3", -1);
        }
        jSONObject.put("nameIn4", this.H.c());
        jSONObject.put("typeIn4", this.H.e());
        jSONObject.put("numOnIn4", this.H.a.getNumOnIn());
        if (this.H.a.q() != null) {
            jSONObject.put("keyOutIn4", this.H.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn4", -1);
        }
        jSONObject.put("nameOut", this.I.c());
        jSONObject.put("typeOut", this.I.e());
        jSONObject.put("saveKeyOut", this.I.a.getKey());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.e, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        if (this.I.e() == 1) {
            return Boolean.valueOf(MyApplication.A0.e(this.c + "_" + this.I.a.getVarName()));
        }
        if (this.I.e() == 2) {
            return Integer.valueOf(MyApplication.A0.g(this.c + "_" + this.I.a.getVarName()));
        }
        if (this.I.e() != 3) {
            return null;
        }
        return Float.valueOf(MyApplication.A0.f(this.c + "_" + this.I.a.getVarName()));
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.e, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 135;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void v(SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray, String str) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        for (int i2 = 0; i2 < sparseArray.size(); i2++) {
            int iKeyAt = sparseArray.keyAt(i2);
            if (sparseArray.get(iKeyAt).getRootUniqueIdMacro() == this.c && sparseArray.get(iKeyAt).getTypeFb() != 135) {
                ru.himik.nightscream.kascada.Logic.c.a aVar = sparseArray.get(iKeyAt);
                if ((!(aVar instanceof VarNameIn) || !((VarNameIn) aVar).t()) && (!(aVar instanceof VarNameOut) || !((VarNameOut) aVar).t())) {
                    JSONObject jsonOther = ((z) aVar).getJsonOther();
                    jsonOther.put("componentId", aVar.getTypeFb());
                    View view = (View) aVar;
                    jsonOther.put("x", (int) view.getX());
                    jsonOther.put("y", (int) view.getY());
                    jsonOther.put("nMcr", aVar.getRootNameMacro());
                    jsonOther.put("unIdMcr", aVar.getRootUniqueIdMacro());
                    if (aVar instanceof e) {
                        e eVar = (e) aVar;
                        jsonOther.put("reg", eVar.getReg());
                        jsonOther.put("bit", eVar.getBit());
                    }
                    jSONArray.put(jsonOther);
                }
            }
        }
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("fbInMacros", jSONArray);
        jSONObject.put(IMAPStore.ID_NAME, getName());
        jSONObject.put("countIn", getCountIn());
        jSONObject.put("uniqueId", this.c);
        jSONObject.put("nameIn1", this.E.c());
        jSONObject.put("typeIn1", this.E.e());
        jSONObject.put("numOnIn1", this.E.a.getNumOnIn());
        if (this.E.a.q() != null) {
            jSONObject.put("keyOutIn1", this.E.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn1", -1);
        }
        jSONObject.put("nameIn2", this.F.c());
        jSONObject.put("typeIn2", this.F.e());
        jSONObject.put("numOnIn2", this.F.a.getNumOnIn());
        if (this.F.a.q() != null) {
            jSONObject.put("keyOutIn2", this.F.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn2", -1);
        }
        jSONObject.put("nameIn3", this.G.c());
        jSONObject.put("typeIn3", this.G.e());
        jSONObject.put("numOnIn3", this.G.a.getNumOnIn());
        if (this.G.a.q() != null) {
            jSONObject.put("keyOutIn3", this.G.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn3", -1);
        }
        jSONObject.put("nameIn4", this.H.c());
        jSONObject.put("typeIn4", this.H.e());
        jSONObject.put("numOnIn4", this.H.a.getNumOnIn());
        if (this.H.a.q() != null) {
            jSONObject.put("keyOutIn4", this.H.a.q().getKey());
        } else {
            jSONObject.put("keyOutIn4", -1);
        }
        jSONObject.put("nameOut", this.I.c());
        jSONObject.put("typeOut", this.I.e());
        jSONObject.put("saveKeyOut", this.I.a.getKey());
        n.a.j(jSONObject.toString(), getName(), str);
    }
}
