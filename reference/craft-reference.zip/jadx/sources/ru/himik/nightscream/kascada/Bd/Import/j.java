package ru.himik.nightscream.kascada.Bd.Import;

import com.sun.mail.imap.IMAPStore;

/* JADX INFO: loaded from: classes.dex */
public final class j {
    private k a;
    private String b;
    private String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f8594d;

    public j(k kVar, String str, String str2, String str3) {
        kotlin.b0.d.j.d(kVar, "type");
        kotlin.b0.d.j.d(str, IMAPStore.ID_NAME);
        kotlin.b0.d.j.d(str2, "size");
        kotlin.b0.d.j.d(str3, "dateCreated");
        this.a = kVar;
        this.b = str;
        this.c = str2;
        this.f8594d = str3;
    }

    public /* synthetic */ j(k kVar, String str, String str2, String str3, int i2, kotlin.b0.d.g gVar) {
        this(kVar, str, (i2 & 4) != 0 ? "" : str2, (i2 & 8) != 0 ? "" : str3);
    }

    public final String a() {
        return this.f8594d;
    }

    public final String b() {
        return this.b;
    }

    public final String c() {
        return this.c;
    }

    public final k d() {
        return this.a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return this.a == jVar.a && kotlin.b0.d.j.a(this.b, jVar.b) && kotlin.b0.d.j.a(this.c, jVar.c) && kotlin.b0.d.j.a(this.f8594d, jVar.f8594d);
    }

    public int hashCode() {
        return (((((this.a.hashCode() * 31) + this.b.hashCode()) * 31) + this.c.hashCode()) * 31) + this.f8594d.hashCode();
    }

    public String toString() {
        return "ListItemImportProject(type=" + this.a + ", name=" + this.b + ", size=" + this.c + ", dateCreated=" + this.f8594d + ')';
    }
}
