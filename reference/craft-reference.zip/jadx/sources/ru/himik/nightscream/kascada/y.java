package ru.himik.nightscream.kascada;

import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public final class y {
    public static final int[] a = {R.attr.sv_centerCircleColor};
}
