package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.c;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class FB_ARITHMETIC_INT extends c {
    char d0;
    int e0;

    public FB_ARITHMETIC_INT(Context context) {
        super(context);
        this.d0 = (char) 0;
        this.e0 = 1;
        setName("+");
        s("IN1", 2);
        t("IN2", 2);
        u("Q", 2);
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width_compare_arithmetic));
        this.f8972d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height_compare_arithmetic));
    }

    public FB_ARITHMETIC_INT(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = (char) 0;
        this.e0 = 1;
        setName("+");
        s("IN1", 2);
        t("IN2", 2);
        u("Q", 2);
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.c = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width_compare_arithmetic)));
            this.f8972d = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height_compare_arithmetic)));
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return;
        }
        try {
            int i2 = this.e0;
            if (i2 == 1) {
                this.d0 = (char) (((Integer) this.f8975g.getOut()).intValue() + ((Integer) this.f8976h.getOut()).intValue());
            } else if (i2 == 2) {
                this.d0 = (char) (((Integer) this.f8975g.getOut()).intValue() - ((Integer) this.f8976h.getOut()).intValue());
            } else if (i2 == 3) {
                this.d0 = (char) (((Integer) this.f8975g.getOut()).intValue() * ((Integer) this.f8976h.getOut()).intValue());
            } else if (i2 == 4) {
                this.d0 = (char) (((Integer) this.f8975g.getOut()).intValue() / ((Integer) this.f8976h.getOut()).intValue());
            }
        } catch (Exception unused) {
            this.d0 = (char) 0;
        }
    }

    public int getActionExecute() {
        return this.e0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("compareAction", getActionExecute());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return null;
        }
        return Integer.valueOf(this.d0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return com.karumi.dexter.R.styleable.AppCompatTheme_toolbarNavigationButtonStyle;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.S.setStyle(Paint.Style.FILL);
        this.S.setColor(-7829368);
        this.S.setStrokeWidth(this.U);
        this.V.set(this.T, this.U, getWidth() - this.T, getHeight() - this.U);
        canvas.drawRect(this.V, this.S);
        this.S.setStyle(Paint.Style.STROKE);
        this.S.setColor(-16777216);
        canvas.drawRect(this.V, this.S);
        this.W.setTextAlign(Paint.Align.CENTER);
        this.W.setFlags(1);
        this.W.setTextSize(getHeight() / 3);
        canvas.drawText(this.L, getWidth() / 2, (int) ((getHeight() / 2) - ((this.W.descent() + this.W.ascent()) / 2.0f)), this.W);
        canvas.drawLine(0.0f, getHeight() / 4, this.T, getHeight() / 4, this.S);
        canvas.drawLine(0.0f, (getHeight() / 4) * 3, this.T, (getHeight() / 4) * 3, this.S);
        if (this.f8973e && this.R == 1) {
            canvas.drawCircle((getWidth() - this.T) + this.b0, ((getHeight() / 3) / 2) + (getHeight() / 3), this.b0, this.S);
            width = (getWidth() - this.T) + (this.b0 * 2);
        } else {
            width = getWidth() - this.T;
        }
        canvas.drawLine(width, ((getHeight() / 3) / 2) + (getHeight() / 3), getWidth(), ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        this.f8979k.set((int) getX(), ((int) getY()) + (getHeight() / 4));
        this.f8980l.set((int) getX(), ((int) getY()) + ((getHeight() / 4) * 3));
        this.f8981m.set(((int) getX()) + getWidth(), ((int) getY()) + ((getHeight() / 3) / 2) + (getHeight() / 3));
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
        String str;
        this.e0 = i2;
        if (i2 == 1) {
            str = "+";
        } else if (i2 == 2) {
            str = "-";
        } else {
            if (i2 != 3) {
                if (i2 == 4) {
                    str = "/";
                }
                invalidate();
            }
            str = "*";
        }
        setName(str);
        invalidate();
    }
}
