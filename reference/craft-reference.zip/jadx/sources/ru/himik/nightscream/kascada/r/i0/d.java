package ru.himik.nightscream.kascada.r.i0;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class d extends DialogFragment implements b {
    RecyclerView a;
    EditText b;
    Button c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private c f9354d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    ru.himik.nightscream.kascada.Logic.VarName.b f9355e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    List<String> f9356f = new ArrayList();

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void c(View view) {
        if (this.b.getText().toString().length() > 0) {
            this.f9355e.setVarName(this.b.getText().toString());
            dismiss();
        }
    }

    @Override // ru.himik.nightscream.kascada.r.i0.b
    public void a(String str) {
        this.f9355e.setVarName(str);
        dismiss();
    }

    public void d(List<String> list) {
        this.f9356f = list;
    }

    public void e(ru.himik.nightscream.kascada.Logic.VarName.b bVar) {
        this.f9355e = bVar;
    }

    @Override // android.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        getDialog().getWindow().requestFeature(1);
        getDialog().setCanceledOnTouchOutside(false);
        View viewInflate = layoutInflater.inflate(R.layout.choose_name_bottom_sheet, viewGroup, false);
        c cVar = new c();
        this.f9354d = cVar;
        cVar.x(this.f9356f);
        this.f9354d.w(this);
        return viewInflate;
    }

    @Override // android.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        if (((ru.himik.nightscream.kascada.Logic.c.a) this.f9355e).getNumScreen() != -1) {
            ((mbCanvas) getActivity()).C().c().b(this.f9355e.getVarName(), this.f9355e.getTypeVar());
        }
    }

    @Override // android.app.Fragment
    public void onResume() {
        super.onResume();
    }

    @Override // android.app.DialogFragment, android.app.Fragment
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(-1, -1);
        }
    }

    @Override // android.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (this.f9355e == null) {
            dismiss();
        }
        this.a = (RecyclerView) view.findViewById(R.id.recycler);
        this.b = (EditText) view.findViewById(R.id.eNewName);
        this.c = (Button) view.findViewById(R.id.bOk);
        this.a.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.a.setHasFixedSize(true);
        this.a.setAdapter(this.f9354d);
        this.c.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.i0.a
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.a.c(view2);
            }
        });
    }
}
