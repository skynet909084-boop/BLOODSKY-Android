package ru.himik.nightscream.kascada.Preference.ServerList;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.l0;
import java.util.ArrayList;
import ru.himik.nightscream.kascada.Connections.Bluetooth.DeviceBluetoothList;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class EditServerList extends androidx.appcompat.app.d {
    ru.himik.nightscream.kascada.Preference.ServerList.b b;
    ListView c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9099d;
    ArrayList<ru.himik.nightscream.kascada.Preference.ServerList.a> a = new ArrayList<>();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final AdapterView.OnItemClickListener f9100e = new l();

    class a implements DialogInterface.OnClickListener {
        a(EditServerList editServerList) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class b implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Spinner b;
        final /* synthetic */ Spinner c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Spinner f9101d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ Spinner f9102e;

        b(EditText editText, Spinner spinner, Spinner spinner2, Spinner spinner3, Spinner spinner4) {
            this.a = editText;
            this.b = spinner;
            this.c = spinner2;
            this.f9101d = spinner3;
            this.f9102e = spinner4;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            int i3;
            try {
                i3 = Integer.parseInt(this.a.getText().toString());
            } catch (Exception unused) {
                i3 = 0;
            }
            ru.himik.nightscream.kascada.Preference.ServerList.a aVar = new ru.himik.nightscream.kascada.Preference.ServerList.a(3, "Usb", "usb", i3);
            Boolean bool = Boolean.TRUE;
            int size = EditServerList.this.a.size();
            for (int i4 = 0; i4 < size; i4++) {
                if (aVar.d().equals(EditServerList.this.a.get(i4).d())) {
                    bool = Boolean.FALSE;
                }
            }
            if (!bool.booleanValue()) {
                Toast.makeText(EditServerList.this.getApplicationContext(), EditServerList.this.getResources().getString(R.string.error_usb_only_one), 0).show();
                return;
            }
            aVar.p("Usb");
            aVar.m(Integer.parseInt(this.b.getSelectedItem().toString()));
            aVar.o(Integer.parseInt(this.c.getSelectedItem().toString()));
            aVar.u(ru.himik.nightscream.kascada.q.e.b.a.b(this.f9101d.getSelectedItem().toString()));
            aVar.q(ru.himik.nightscream.kascada.q.e.b.a.a(this.f9102e.getSelectedItem().toString()));
            EditServerList.this.a.add(aVar);
            EditServerList.this.b.notifyDataSetChanged();
        }
    }

    class c implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Preference.ServerList.a b;
        final /* synthetic */ AlertDialog c;

        c(EditText editText, ru.himik.nightscream.kascada.Preference.ServerList.a aVar, AlertDialog alertDialog) {
            this.a = editText;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int i2;
            try {
                i2 = Integer.parseInt(this.a.getText().toString());
            } catch (Exception unused) {
                i2 = 0;
            }
            if (i2 != this.b.g()) {
                EditServerList.this.b.notifyDataSetChanged();
                this.b.r(i2);
                this.c.dismiss();
            }
        }
    }

    class d implements DialogInterface.OnClickListener {
        d(EditServerList editServerList) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class e implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Preference.ServerList.a b;
        final /* synthetic */ CheckBox c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9105d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ EditText f9106e;

        e(EditText editText, ru.himik.nightscream.kascada.Preference.ServerList.a aVar, CheckBox checkBox, EditText editText2, EditText editText3) {
            this.a = editText;
            this.b = aVar;
            this.c = checkBox;
            this.f9105d = editText2;
            this.f9106e = editText3;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            int i3;
            try {
                i3 = Integer.parseInt(this.a.getText().toString());
            } catch (Exception unused) {
                i3 = 0;
            }
            if (i3 != this.b.g()) {
                EditServerList.this.b.notifyDataSetChanged();
                this.b.r(i3);
            }
            if (this.b.l() != this.c.isChecked()) {
                this.b.s(this.c.isChecked());
                EditServerList.this.b.notifyDataSetChanged();
            }
            if (this.b.d().equals(this.f9105d.getText().toString()) && this.b.h().equals(this.f9106e.getText().toString())) {
                return;
            }
            Boolean bool = Boolean.TRUE;
            for (int i4 = 0; i4 < EditServerList.this.a.size(); i4++) {
                if (this.f9106e.getText().toString().equals(EditServerList.this.a.get(i4).h()) && this.f9105d.getText().toString().equals(EditServerList.this.a.get(i4).d())) {
                    Toast.makeText(EditServerList.this.getApplicationContext(), EditServerList.this.getResources().getString(R.string.error_already_exists_server), 0).show();
                    bool = Boolean.FALSE;
                }
            }
            if (bool.booleanValue()) {
                this.b.p(this.f9105d.getText().toString());
                try {
                    int i5 = Integer.parseInt(this.f9106e.getText().toString());
                    if (i5 >= 65535 || i5 <= 0) {
                        Toast.makeText(EditServerList.this.getApplicationContext(), EditServerList.this.getResources().getString(R.string.error_num_port), 0).show();
                    } else {
                        this.b.t(this.f9106e.getText().toString());
                    }
                } catch (Exception unused2) {
                    Toast.makeText(EditServerList.this.getApplicationContext(), EditServerList.this.getResources().getString(R.string.error_num_port), 0).show();
                }
                EditServerList.this.b.notifyDataSetChanged();
            }
        }
    }

    class f implements DialogInterface.OnClickListener {
        f(EditServerList editServerList) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class g implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Preference.ServerList.a b;
        final /* synthetic */ Spinner c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Spinner f9108d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ Spinner f9109e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ Spinner f9110f;

        g(EditText editText, ru.himik.nightscream.kascada.Preference.ServerList.a aVar, Spinner spinner, Spinner spinner2, Spinner spinner3, Spinner spinner4) {
            this.a = editText;
            this.b = aVar;
            this.c = spinner;
            this.f9108d = spinner2;
            this.f9109e = spinner3;
            this.f9110f = spinner4;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            int i3;
            try {
                i3 = Integer.parseInt(this.a.getText().toString());
            } catch (Exception unused) {
                i3 = 0;
            }
            if (i3 != this.b.g()) {
                EditServerList.this.b.notifyDataSetChanged();
                this.b.r(i3);
            }
            if (this.b.h().equals(this.c.getSelectedItem().toString() + ", " + this.f9108d.getSelectedItem().toString() + ", " + this.f9109e.getSelectedItem().toString() + ", " + this.f9110f.getSelectedItem().toString())) {
                return;
            }
            this.b.p("Usb");
            this.b.m(Integer.parseInt(this.c.getSelectedItem().toString()));
            this.b.o(Integer.parseInt(this.f9108d.getSelectedItem().toString()));
            this.b.u(ru.himik.nightscream.kascada.q.e.b.a.b(this.f9109e.getSelectedItem().toString()));
            this.b.q(ru.himik.nightscream.kascada.q.e.b.a.a(this.f9110f.getSelectedItem().toString()));
            EditServerList.this.b.notifyDataSetChanged();
        }
    }

    class h implements DialogInterface.OnClickListener {
        h(EditServerList editServerList) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class i implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Preference.ServerList.a b;
        final /* synthetic */ CheckBox c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9112d;

        i(EditText editText, ru.himik.nightscream.kascada.Preference.ServerList.a aVar, CheckBox checkBox, EditText editText2) {
            this.a = editText;
            this.b = aVar;
            this.c = checkBox;
            this.f9112d = editText2;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            int i3;
            try {
                i3 = Integer.parseInt(this.a.getText().toString());
            } catch (Exception unused) {
                i3 = 0;
            }
            this.b.r(i3);
            this.b.s(this.c.isChecked());
            this.b.t(this.f9112d.getText().toString());
            EditServerList.this.b.notifyDataSetChanged();
        }
    }

    class j implements l0.d {
        j() {
        }

        @Override // androidx.appcompat.widget.l0.d
        public boolean onMenuItemClick(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.delete_item) {
                EditServerList editServerList = EditServerList.this;
                editServerList.a.remove(editServerList.f9099d);
                EditServerList.this.b.notifyDataSetChanged();
                return true;
            }
            if (itemId != R.id.edit_item) {
                return false;
            }
            EditServerList editServerList2 = EditServerList.this;
            editServerList2.k(editServerList2.f9099d);
            return true;
        }
    }

    class k implements View.OnClickListener {
        k() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            EditServerList.this.onBackPressed();
        }
    }

    class l implements AdapterView.OnItemClickListener {
        l() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            EditServerList.this.l(i2);
        }
    }

    class m implements AdapterView.OnItemLongClickListener {
        m() {
        }

        @Override // android.widget.AdapterView.OnItemLongClickListener
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            return EditServerList.this.n(view, i2, j2);
        }
    }

    class n implements View.OnClickListener {
        n() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            EditServerList.this.m();
        }
    }

    class o implements View.OnClickListener {
        o() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            EditServerList.this.h();
        }
    }

    class p implements DialogInterface.OnClickListener {
        p() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            if (i2 == 0) {
                EditServerList.this.j();
                return;
            }
            if (i2 == 1) {
                EditServerList.this.f();
            } else if (i2 == 2) {
                EditServerList.this.i();
            } else {
                if (i2 != 3) {
                    return;
                }
                EditServerList.this.g();
            }
        }
    }

    class q implements DialogInterface.OnClickListener {
        q(EditServerList editServerList) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class r implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ EditText b;
        final /* synthetic */ EditText c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ CheckBox f9114d;

        r(EditText editText, EditText editText2, EditText editText3, CheckBox checkBox) {
            this.a = editText;
            this.b = editText2;
            this.c = editText3;
            this.f9114d = checkBox;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            int i3;
            try {
                i3 = Integer.parseInt(this.a.getText().toString());
            } catch (Exception unused) {
                i3 = 0;
            }
            ru.himik.nightscream.kascada.Preference.ServerList.a aVar = new ru.himik.nightscream.kascada.Preference.ServerList.a(2, this.b.getText().toString(), this.c.getText().toString(), i3);
            aVar.s(this.f9114d.isChecked());
            Boolean bool = Boolean.TRUE;
            int size = EditServerList.this.a.size();
            for (int i4 = 0; i4 < size; i4++) {
                if (aVar.h().equals(EditServerList.this.a.get(i4).h()) && aVar.d().equals(EditServerList.this.a.get(i4).d())) {
                    bool = Boolean.FALSE;
                }
            }
            if (!bool.booleanValue()) {
                Toast.makeText(EditServerList.this.getApplicationContext(), EditServerList.this.getResources().getString(R.string.error_already_exists_server), 0).show();
            } else {
                EditServerList.this.a.add(aVar);
                EditServerList.this.b.notifyDataSetChanged();
            }
        }
    }

    class s implements DialogInterface.OnClickListener {
        s(EditServerList editServerList) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class t implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ EditText b;
        final /* synthetic */ CheckBox c;

        t(EditText editText, EditText editText2, CheckBox checkBox) {
            this.a = editText;
            this.b = editText2;
            this.c = checkBox;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            int i3;
            try {
                i3 = Integer.parseInt(this.a.getText().toString());
            } catch (Exception unused) {
                i3 = 0;
            }
            ru.himik.nightscream.kascada.Preference.ServerList.a aVar = new ru.himik.nightscream.kascada.Preference.ServerList.a(4, "KaScada Cloud", this.b.getText().toString(), i3);
            aVar.s(this.c.isChecked());
            Boolean bool = Boolean.TRUE;
            int size = EditServerList.this.a.size();
            for (int i4 = 0; i4 < size; i4++) {
                if (aVar.h().equals(EditServerList.this.a.get(i4).h()) && aVar.d().equals(EditServerList.this.a.get(i4).d())) {
                    bool = Boolean.FALSE;
                }
            }
            if (!bool.booleanValue()) {
                Toast.makeText(EditServerList.this.getApplicationContext(), EditServerList.this.getResources().getString(R.string.error_already_exists_server), 0).show();
            } else {
                EditServerList.this.a.add(aVar);
                EditServerList.this.b.notifyDataSetChanged();
            }
        }
    }

    private void o(View view) {
        l0 l0Var = new l0(this, view);
        l0Var.b(R.menu.popup_server_list);
        l0Var.c(new j());
        l0Var.d();
    }

    public void f() {
        startActivityForResult(new Intent(this, (Class<?>) DeviceBluetoothList.class), 1);
    }

    public void g() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View viewInflate = getLayoutInflater().inflate(R.layout.alert_dialog_add_cloud, (ViewGroup) null);
        EditText editText = (EditText) viewInflate.findViewById(R.id.identifier);
        CheckBox checkBox = (CheckBox) viewInflate.findViewById(R.id.checkBoxRtu);
        builder.setView(viewInflate).setPositiveButton(getResources().getString(R.string.create), new t((EditText) viewInflate.findViewById(R.id.pause), editText, checkBox)).setNegativeButton(getResources().getString(R.string.dialog_cancel), new s(this));
        builder.show();
    }

    void h() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.new_connection)).setItems(R.array.chooseNewConnection, new p());
        builder.show();
    }

    public void i() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View viewInflate = getLayoutInflater().inflate(R.layout.alert_dialog_add_usb, (ViewGroup) null);
        Spinner spinner = (Spinner) viewInflate.findViewById(R.id.spinnerDataBits);
        spinner.setSelection(1);
        Spinner spinner2 = (Spinner) viewInflate.findViewById(R.id.spinnerBaudRate);
        spinner2.setSelection(5);
        Spinner spinner3 = (Spinner) viewInflate.findViewById(R.id.spinnerStopBits);
        spinner3.setSelection(2);
        Spinner spinner4 = (Spinner) viewInflate.findViewById(R.id.spinnerParity);
        spinner4.setSelection(0);
        EditText editText = (EditText) viewInflate.findViewById(R.id.pause);
        editText.setText("0");
        builder.setView(viewInflate).setPositiveButton(getResources().getString(R.string.create), new b(editText, spinner2, spinner, spinner3, spinner4)).setNegativeButton(getResources().getString(R.string.dialog_cancel), new a(this));
        builder.show();
    }

    public void j() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View viewInflate = getLayoutInflater().inflate(R.layout.alert_dialog_add_wifi, (ViewGroup) null);
        EditText editText = (EditText) viewInflate.findViewById(R.id.ip);
        EditText editText2 = (EditText) viewInflate.findViewById(R.id.port);
        CheckBox checkBox = (CheckBox) viewInflate.findViewById(R.id.checkBoxRtu);
        builder.setView(viewInflate).setPositiveButton(getResources().getString(R.string.create), new r((EditText) viewInflate.findViewById(R.id.pause), editText, editText2, checkBox)).setNegativeButton(getResources().getString(R.string.dialog_cancel), new q(this));
        builder.show();
    }

    public void k(int i2) {
        AlertDialog.Builder positiveButton;
        String string;
        DialogInterface.OnClickListener dVar;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater layoutInflater = getLayoutInflater();
        ru.himik.nightscream.kascada.Preference.ServerList.a aVar = this.a.get(i2);
        aVar.c();
        int iC = aVar.c();
        if (iC == 1) {
            View viewInflate = LayoutInflater.from(this).inflate(R.layout.dialog_set_pause, (ViewGroup) null);
            AlertDialog alertDialogCreate = new AlertDialog.Builder(this).create();
            EditText editText = (EditText) viewInflate.findViewById(R.id.pause);
            editText.setText(aVar.g() + "");
            viewInflate.findViewById(R.id.acceptPause).setOnClickListener(new c(editText, aVar, alertDialogCreate));
            alertDialogCreate.setView(viewInflate);
            alertDialogCreate.show();
            return;
        }
        if (iC == 2) {
            View viewInflate2 = layoutInflater.inflate(R.layout.alert_dialog_add_wifi, (ViewGroup) null);
            EditText editText2 = (EditText) viewInflate2.findViewById(R.id.ip);
            EditText editText3 = (EditText) viewInflate2.findViewById(R.id.port);
            CheckBox checkBox = (CheckBox) viewInflate2.findViewById(R.id.checkBoxRtu);
            EditText editText4 = (EditText) viewInflate2.findViewById(R.id.pause);
            editText2.setText(aVar.d());
            editText3.setText(aVar.h());
            checkBox.setChecked(aVar.l());
            editText4.setText(aVar.g() + "");
            positiveButton = builder.setView(viewInflate2).setPositiveButton("Ок", new e(editText4, aVar, checkBox, editText2, editText3));
            string = getResources().getString(R.string.dialog_cancel);
            dVar = new d(this);
        } else if (iC == 3) {
            View viewInflate3 = layoutInflater.inflate(R.layout.alert_dialog_add_usb, (ViewGroup) null);
            Spinner spinner = (Spinner) viewInflate3.findViewById(R.id.spinnerDataBits);
            spinner.setSelection(1);
            Spinner spinner2 = (Spinner) viewInflate3.findViewById(R.id.spinnerBaudRate);
            spinner2.setSelection(5);
            Spinner spinner3 = (Spinner) viewInflate3.findViewById(R.id.spinnerStopBits);
            spinner3.setSelection(2);
            Spinner spinner4 = (Spinner) viewInflate3.findViewById(R.id.spinnerParity);
            spinner4.setSelection(0);
            EditText editText5 = (EditText) viewInflate3.findViewById(R.id.pause);
            editText5.setText(aVar.g() + "");
            positiveButton = builder.setView(viewInflate3).setPositiveButton("Ок", new g(editText5, aVar, spinner2, spinner, spinner3, spinner4));
            string = getResources().getString(R.string.dialog_cancel);
            dVar = new f(this);
        } else {
            if (iC != 4) {
                return;
            }
            View viewInflate4 = layoutInflater.inflate(R.layout.alert_dialog_add_cloud, (ViewGroup) null);
            EditText editText6 = (EditText) viewInflate4.findViewById(R.id.identifier);
            CheckBox checkBox2 = (CheckBox) viewInflate4.findViewById(R.id.checkBoxRtu);
            EditText editText7 = (EditText) viewInflate4.findViewById(R.id.pause);
            editText7.setText(aVar.g() + "");
            editText6.setText(aVar.h());
            checkBox2.setChecked(aVar.l());
            positiveButton = builder.setView(viewInflate4).setPositiveButton(getResources().getString(R.string.create), new i(editText7, aVar, checkBox2, editText6));
            string = getResources().getString(R.string.dialog_cancel);
            dVar = new h(this);
        }
        positiveButton.setNegativeButton(string, dVar);
        builder.show();
    }

    public void l(int i2) {
        Intent intent = getIntent();
        Bundle bundle = new Bundle();
        bundle.putInt("position", i2);
        bundle.putParcelableArrayList("serverList", this.a);
        if (i2 >= 0) {
            bundle.putInt("idServer", this.a.get(i2).c());
        }
        intent.putExtras(bundle);
        setResult(-1, intent);
        finish();
    }

    void m() {
        l(-1);
    }

    protected boolean n(View view, int i2, long j2) {
        this.f9099d = i2;
        o(view);
        return true;
    }

    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onActivityResult(int i2, int i3, Intent intent) {
        super.onActivityResult(i2, i3, intent);
        if (i2 == 1 && i3 == -1) {
            ru.himik.nightscream.kascada.Preference.ServerList.a aVar = new ru.himik.nightscream.kascada.Preference.ServerList.a(1, intent.getStringExtra("NAME"), intent.getStringExtra("MAC"), 0);
            Boolean bool = Boolean.TRUE;
            int size = this.a.size();
            for (int i4 = 0; i4 < size; i4++) {
                if (aVar.h().equals(this.a.get(i4).h())) {
                    bool = Boolean.FALSE;
                }
            }
            if (!bool.booleanValue()) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_already_exists_server), 0).show();
            } else {
                this.a.add(aVar);
                this.b.notifyDataSetChanged();
            }
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        l(-2);
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.server_list);
        if (getIntent().getBooleanExtra("portraitMode", false)) {
            setRequestedOrientation(1);
        }
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getResources().getString(R.string.edit_server));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
        }
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new k());
        }
        this.a = getIntent().getParcelableArrayListExtra("serverList");
        getIntent().getIntExtra("posDeviceNetwork", 0);
        this.c = (ListView) findViewById(R.id.lvMain);
        ru.himik.nightscream.kascada.Preference.ServerList.b bVar = new ru.himik.nightscream.kascada.Preference.ServerList.b(this, this.a, true);
        this.b = bVar;
        this.c.setAdapter((ListAdapter) bVar);
        this.c.setOnItemClickListener(this.f9100e);
        this.c.setOnItemLongClickListener(new m());
        findViewById(R.id.no_connections).setOnClickListener(new n());
        findViewById(R.id.add_connection).setOnClickListener(new o());
    }
}
