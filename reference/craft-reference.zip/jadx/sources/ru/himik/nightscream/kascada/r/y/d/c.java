package ru.himik.nightscream.kascada.r.y.d;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.util.Objects;
import kotlin.b0.d.j;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public abstract class c extends com.google.android.material.bottomsheet.b {

    public static final class a extends BottomSheetBehavior.f {
        a() {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.f
        public void a(View view, float f2) {
            j.d(view, "bottomSheet");
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.f
        public void b(View view, int i2) {
            j.d(view, "bottomSheet");
            if (i2 == 5) {
                c.this.o1();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void H1(Dialog dialog, c cVar, DialogInterface dialogInterface) {
        j.d(dialog, "$dialog");
        j.d(cVar, "this$0");
        Objects.requireNonNull(dialogInterface, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
        View viewFindViewById = ((com.google.android.material.bottomsheet.a) dialogInterface).findViewById(R.id.design_bottom_sheet);
        FrameLayout frameLayout = viewFindViewById instanceof FrameLayout ? (FrameLayout) viewFindViewById : null;
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
        }
        Objects.requireNonNull(frameLayout, "null cannot be cast to non-null type android.widget.FrameLayout");
        BottomSheetBehavior.W(frameLayout).q0(6);
        BottomSheetBehavior bottomSheetBehaviorW = BottomSheetBehavior.W(frameLayout);
        j.c(bottomSheetBehaviorW, "from(bottomSheet)");
        bottomSheetBehaviorW.M(cVar.new a());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean I1(c cVar, DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
        j.d(cVar, "this$0");
        if (i2 != 4 || keyEvent.getAction() != 1) {
            return false;
        }
        cVar.G1();
        return true;
    }

    public final boolean C1() {
        return B().getConfiguration().orientation == 2;
    }

    public final boolean D1() {
        return B().getBoolean(R.bool.isTablet);
    }

    public abstract void G1();

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void a0(Bundle bundle) {
        super.a0(bundle);
        v1(0, R.style.BottomSheetDialogTheme);
    }

    @Override // com.google.android.material.bottomsheet.b, androidx.fragment.app.c
    public Dialog t1(Bundle bundle) {
        final Dialog dialogT1 = super.t1(bundle);
        j.c(dialogT1, "super.onCreateDialog(savedInstanceState)");
        Window window = dialogT1.getWindow();
        if (window != null) {
            window.setDimAmount(0.35f);
        }
        dialogT1.setOnShowListener(new DialogInterface.OnShowListener() { // from class: ru.himik.nightscream.kascada.r.y.d.b
            @Override // android.content.DialogInterface.OnShowListener
            public final void onShow(DialogInterface dialogInterface) {
                c.H1(dialogT1, this, dialogInterface);
            }
        });
        dialogT1.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: ru.himik.nightscream.kascada.r.y.d.a
            @Override // android.content.DialogInterface.OnKeyListener
            public final boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
                return c.I1(this.a, dialogInterface, i2, keyEvent);
            }
        });
        return dialogT1;
    }

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void x0() {
        Dialog dialogR1;
        Window window;
        super.x0();
        if ((!D1() && !C1()) || (dialogR1 = r1()) == null || (window = dialogR1.getWindow()) == null) {
            return;
        }
        window.setLayout(-2, -1);
    }
}
