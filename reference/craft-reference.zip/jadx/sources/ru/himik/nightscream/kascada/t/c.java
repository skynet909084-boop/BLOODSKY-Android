package ru.himik.nightscream.kascada.t;

import android.content.ClipData;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class c extends Fragment {
    View k0;
    View l0;
    View m0;
    View n0;
    View o0;
    View p0;
    View q0;
    View r0;
    View s0;
    View.OnClickListener t0 = new ViewOnClickListenerC0309c();
    View.OnClickListener u0 = new d();
    View.OnLongClickListener v0 = new e(this);
    View.OnLongClickListener w0 = new f();

    class a extends GestureDetector.SimpleOnGestureListener {
        a() {
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
            try {
                if (Math.abs(motionEvent.getY() - motionEvent2.getY()) > 250.0f) {
                    return false;
                }
                if (motionEvent.getX() - motionEvent2.getX() > 120.0f && Math.abs(f2) > 200.0f) {
                    ((mbCanvas) c.this.h()).x0(true);
                } else if (motionEvent2.getX() - motionEvent.getX() > 120.0f && Math.abs(f2) > 200.0f) {
                    ((mbCanvas) c.this.h()).r(true);
                }
            } catch (Exception unused) {
            }
            return super.onFling(motionEvent, motionEvent2, f2, f3);
        }
    }

    class b implements View.OnTouchListener {
        final /* synthetic */ GestureDetector a;

        b(c cVar, GestureDetector gestureDetector) {
            this.a = gestureDetector;
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return this.a.onTouchEvent(motionEvent);
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.t.c$c, reason: collision with other inner class name */
    class ViewOnClickListenerC0309c implements View.OnClickListener {
        ViewOnClickListenerC0309c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((mbCanvas) c.this.h()).r(false);
        }
    }

    class d implements View.OnClickListener {
        d() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((mbCanvas) c.this.h()).x0(true);
        }
    }

    class e implements View.OnLongClickListener {
        e(c cVar) {
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            view.startDrag(ClipData.newPlainText("text", "WWW"), new View.DragShadowBuilder(view), view, 0);
            return false;
        }
    }

    class f implements View.OnLongClickListener {
        f() {
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            ((mbCanvas) c.this.h()).x0(true);
            return false;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public View e0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate;
        if (MyApplication.b().i0) {
            viewInflate = layoutInflater.inflate(R.layout.fragment_component_logic_bar_portrait, viewGroup, false);
            viewInflate.findViewById(R.id.close).setOnClickListener(this.u0);
        } else {
            viewInflate = layoutInflater.inflate(R.layout.fragment_component_logic_bar, viewGroup, false);
        }
        View viewFindViewById = viewInflate.findViewById(R.id.tab_var);
        this.k0 = viewFindViewById;
        viewFindViewById.setOnLongClickListener(this.v0);
        View viewFindViewById2 = viewInflate.findViewById(R.id.tab_varOut);
        this.l0 = viewFindViewById2;
        viewFindViewById2.setOnLongClickListener(this.v0);
        View viewFindViewById3 = viewInflate.findViewById(R.id.tab_varInt);
        this.m0 = viewFindViewById3;
        viewFindViewById3.setOnLongClickListener(this.v0);
        View viewFindViewById4 = viewInflate.findViewById(R.id.tab_varOutInt);
        this.n0 = viewFindViewById4;
        viewFindViewById4.setOnLongClickListener(this.v0);
        View viewFindViewById5 = viewInflate.findViewById(R.id.tab_varFloat);
        this.o0 = viewFindViewById5;
        viewFindViewById5.setOnLongClickListener(this.v0);
        View viewFindViewById6 = viewInflate.findViewById(R.id.tab_varOutFloat);
        this.p0 = viewFindViewById6;
        viewFindViewById6.setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_var_name_in).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_var_name_out).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_rs).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_ctu).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_move).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_t_trigger).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_timer).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_int_to_float).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_word_to_float).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_float_to_int).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_sensor_orientation).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_dt).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_sin).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_log).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_abs).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_pow).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_xor).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_sel).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_sunrise).setOnLongClickListener(this.v0);
        View viewFindViewById7 = viewInflate.findViewById(R.id.tab_fb_mx);
        this.q0 = viewFindViewById7;
        viewFindViewById7.setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_sensor_light).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_sensor_speed).setOnLongClickListener(this.v0);
        View viewFindViewById8 = viewInflate.findViewById(R.id.tab_fb_macro);
        this.r0 = viewFindViewById8;
        viewFindViewById8.setOnLongClickListener(this.v0);
        View viewFindViewById9 = viewInflate.findViewById(R.id.tab_fb_array);
        this.s0 = viewFindViewById9;
        viewFindViewById9.setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_el_and).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_el_or).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_el_compare_int).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_el_compare_float).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_el_arithmetic_int).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_el_arithmetic_float).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_change_i).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_change_f).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_mqtt_subscriber).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.tab_fb_mqtt_publisher).setOnLongClickListener(this.v0);
        viewInflate.findViewById(R.id.switch_layout).setOnClickListener(this.t0);
        viewInflate.findViewById(R.id.switch_layout).setOnLongClickListener(this.w0);
        viewInflate.findViewById(R.id.layout_tab_component).setOnTouchListener(new b(this, new GestureDetector(h(), new a())));
        return viewInflate;
    }

    public void o1(boolean z) {
        int i2 = z ? 4 : 0;
        View view = this.k0;
        if (view == null) {
            return;
        }
        view.setVisibility(i2);
        this.l0.setVisibility(i2);
        this.m0.setVisibility(i2);
        this.n0.setVisibility(i2);
        this.o0.setVisibility(i2);
        this.p0.setVisibility(i2);
        this.r0.setVisibility(i2);
        this.q0.setVisibility(i2);
        this.s0.setVisibility(i2);
    }
}
