package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.SparseArray;
import android.view.View;
import android.widget.Toast;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class a extends View {
    Paint a;
    Paint b;
    public SparseArray<ru.himik.nightscream.kascada.Logic.c.a> c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    Path f8951d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    Path f8952e;

    public a(Context context) {
        super(context);
        this.c = new SparseArray<>();
        this.f8951d = new Path();
        this.f8952e = new Path();
        int dimension = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        Paint paint = new Paint();
        this.a = paint;
        float f2 = dimension;
        paint.setStrokeWidth(f2);
        this.a.setStyle(Paint.Style.STROKE);
        this.a.setColor(-16777216);
        Paint paint2 = new Paint();
        this.b = paint2;
        paint2.setStrokeWidth(f2);
        this.b.setStyle(Paint.Style.STROKE);
        this.b.setColor(-16776961);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f8951d.reset();
        this.f8952e.reset();
        if (this.c == null) {
            return;
        }
        for (int i2 = 0; i2 < this.c.size(); i2++) {
            SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray = this.c;
            sparseArray.get(sparseArray.keyAt(i2)).r();
        }
        for (int i3 = 0; i3 < this.c.size(); i3++) {
            SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray2 = this.c;
            ru.himik.nightscream.kascada.Logic.c.a aVar = sparseArray2.get(sparseArray2.keyAt(i3));
            if (aVar.q() != null && ((View) aVar).getVisibility() == 0) {
                try {
                    int i4 = aVar.q().n(aVar.getNumOnIn()).x - aVar.getPointOut().x;
                    this.f8951d.moveTo(aVar.getPointOut().x, aVar.getPointOut().y);
                    this.f8951d.lineTo(aVar.getPointOut().x + (i4 / 2), aVar.getPointOut().y);
                    this.f8951d.lineTo(aVar.getPointOut().x + (i4 / 2), aVar.q().n(aVar.getNumOnIn()).y);
                    this.f8951d.lineTo(aVar.q().n(aVar.getNumOnIn()).x, aVar.q().n(aVar.getNumOnIn()).y);
                    canvas.drawPath(this.f8951d, this.a);
                } catch (Exception unused) {
                    Toast.makeText(getContext(), getResources().getString(R.string.line_logic_error_build_connection) + aVar.getName(), 1).show();
                }
            }
        }
    }

    public void setFbCollection(SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray) {
        this.c = sparseArray;
    }

    public void setShow(boolean z) {
    }
}
