package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class v extends SeekBar implements SeekBar.OnSeekBarChangeListener, View.OnTouchListener, z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    protected boolean C;
    private c D;
    private Handler E;
    private Runnable F;
    private Thread G;
    public boolean H;
    boolean I;
    private boolean J;
    private boolean K;
    Bitmap L;
    Paint M;
    Paint N;
    boolean O;
    int P;
    int Q;
    int R;
    int S;
    float T;
    Drawable U;
    Rect V;
    private long W;
    Context a;
    public Point a0;
    public String b;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8907d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public byte f8908e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8909f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8910g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    String f8911h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    Bitmap f8912i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    Bitmap f8913j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    RectF f8914k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    Paint f8915l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8916m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    int f8917n;
    int o;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                Thread.sleep(500L);
                Message messageObtainMessage = v.this.E.obtainMessage();
                messageObtainMessage.arg1 = 1;
                messageObtainMessage.sendToTarget();
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
    }

    class b extends Handler {
        final /* synthetic */ int a;
        final /* synthetic */ View b;

        b(int i2, View view) {
            this.a = i2;
            this.b = view;
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (this.a == 0) {
                v vVar = v.this;
                if (vVar.H) {
                    vVar.D.onLongClick(this.b);
                }
            }
            super.handleMessage(message);
        }
    }

    public interface c {
        boolean onLongClick(View view);
    }

    public v(Context context) {
        super(context);
        this.b = getResources().getString(R.string.custom_seek_bar);
        this.c = 13;
        this.f8908e = (byte) 6;
        this.f8909f = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8911h = "0";
        this.f8914k = new RectF();
        this.f8915l = new Paint();
        this.f8916m = Color.parseColor("#edb03b");
        this.f8917n = Color.parseColor("#2AEC00");
        this.o = Color.parseColor("#9C9C9B");
        this.H = false;
        this.I = false;
        this.L = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.M = new Paint();
        this.N = new Paint();
        this.O = false;
        this.P = 0;
        this.Q = 0;
        this.R = 0;
        this.S = (int) getResources().getDimension(R.dimen.padding_linear);
        this.T = 0.3f;
        this.V = new Rect();
        this.W = 0L;
        this.a0 = new Point();
        this.a = context;
        setEnableOnTouch(true);
        setOnSeekBarChangeListener(this);
        setOnTouchListener(this);
        this.F = new a();
    }

    void c() {
        int textSize;
        this.f8915l.setTextSize((int) (getHeight() * this.T));
        this.f8915l.setTextSize(10.0f);
        int i2 = 1;
        if (!this.I) {
            while (i2 < 100) {
                textSize = (int) this.f8915l.getTextSize();
                Paint paint = this.f8915l;
                paint.setTextSize(paint.getTextSize() + 2.0f);
                Paint paint2 = this.f8915l;
                String str = this.f8911h;
                paint2.getTextBounds(str, 0, str.length(), this.V);
                if (this.V.height() < ((int) (getHeight() * this.T))) {
                    i2++;
                }
            }
            return;
        }
        while (i2 < 100) {
            textSize = (int) this.f8915l.getTextSize();
            Paint paint3 = this.f8915l;
            paint3.setTextSize(paint3.getTextSize() + 2.0f);
            Paint paint4 = this.f8915l;
            String str2 = this.f8911h;
            paint4.getTextBounds(str2, 0, str2.length(), this.V);
            if (this.V.width() < getWidth() && this.V.height() < ((int) (getHeight() * this.T))) {
                i2++;
            }
        }
        return;
        this.f8915l.setTextSize(textSize);
    }

    protected Drawable d(int i2, int i3, boolean z) {
        GradientDrawable gradientDrawable;
        ClipDrawable clipDrawable;
        ClipDrawable clipDrawable2;
        if (Color.alpha(i3) == 0) {
            gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0, 0, 0});
        } else {
            gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{Color.parseColor("#282828"), Color.parseColor("#ffffff"), Color.parseColor("#777777")});
            gradientDrawable.setStroke((int) getResources().getDimension(R.dimen.width_stroke), Color.parseColor("#FF444444"));
        }
        gradientDrawable.setShape(0);
        gradientDrawable.setGradientType(0);
        gradientDrawable.setCornerRadius(getResources().getDimension(R.dimen.corner_radius_seek_bar));
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{gradientDrawable});
        layerDrawable.setLayerInset(0, 0, (int) (getHeight() * this.T), 0, 0);
        if (Build.VERSION.SDK_INT >= 16) {
            setBackground(layerDrawable);
        } else {
            setBackgroundDrawable(layerDrawable);
        }
        GradientDrawable gradientDrawable2 = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{ru.himik.nightscream.kascada.Utils.q.k(i3, 0.7f), i3, ru.himik.nightscream.kascada.Utils.q.k(i3, 0.7f)});
        gradientDrawable2.setShape(0);
        gradientDrawable2.setGradientType(0);
        gradientDrawable2.setCornerRadius(getResources().getDimension(R.dimen.corner_radius_seek_bar));
        GradientDrawable gradientDrawable3 = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{ru.himik.nightscream.kascada.Utils.q.k(i2, 0.7f), i2, ru.himik.nightscream.kascada.Utils.q.k(i2, 0.7f)});
        gradientDrawable3.setShape(0);
        gradientDrawable3.setGradientType(0);
        gradientDrawable3.setCornerRadius(getResources().getDimension(R.dimen.corner_radius_seek_bar));
        gradientDrawable3.setGradientCenter(0.5f, 0.5f);
        ShapeDrawable shapeDrawable = new ShapeDrawable(new RectShape());
        shapeDrawable.getPaint().setColor(0);
        if (z) {
            clipDrawable = new ClipDrawable(gradientDrawable3, 80, 2);
            clipDrawable2 = new ClipDrawable(shapeDrawable, 80, 2);
        } else {
            clipDrawable = new ClipDrawable(gradientDrawable3, 3, 1);
            clipDrawable2 = new ClipDrawable(shapeDrawable, 3, 1);
        }
        LayerDrawable layerDrawable2 = new LayerDrawable(new Drawable[]{gradientDrawable2, clipDrawable2, clipDrawable});
        layerDrawable2.setId(0, android.R.id.background);
        layerDrawable2.setId(1, android.R.id.secondaryProgress);
        layerDrawable2.setId(2, android.R.id.progress);
        int i4 = this.S;
        int height = (int) (getHeight() * this.T);
        int i5 = this.S;
        setPadding(i4, height + i5, i5, i5);
        return layerDrawable2;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.a0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public Handler e(int i2, View view, int i3) {
        return new b(i2, view);
    }

    public void f(int i2, int i3, int i4, boolean z) {
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setKey(i4);
        this.N.setColor(-65536);
        this.N.setAlpha(100);
        this.f8912i = BitmapFactory.decodeResource(this.a.getResources(), R.drawable.thumb);
        this.f8913j = BitmapFactory.decodeResource(this.a.getResources(), R.drawable.thumb_v);
        Drawable drawableD = d(-16776961, Color.parseColor("#9C9C9B"), false);
        this.U = drawableD;
        setProgressDrawable(drawableD);
        this.f8915l.setAntiAlias(true);
        this.f8915l.setColor(this.f8916m);
        this.f8915l.setStyle(Paint.Style.FILL_AND_STROKE);
        this.f8915l.setLinearText(true);
        setThumb(null);
        this.R = (int) getResources().getDimension(R.dimen.width_thumb);
        this.S = (int) getResources().getDimension(R.dimen.padding_linear);
    }

    public boolean g() {
        return this.I;
    }

    public int getAllPadding() {
        return (int) ((getHeight() * this.T) + this.S);
    }

    public int getColorBackground() {
        return this.o;
    }

    public int getColorProgress() {
        return this.f8917n;
    }

    public int getColorText() {
        return this.f8916m;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.f8909f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.c;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8910g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.Q;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.c;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8909f.l());
        jSONObject.put("addressRegister", this.f8909f.c());
        jSONObject.put("typeRequest", (int) this.f8909f.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("colorText", getColorText());
        jSONObject.put("max", getMax());
        jSONObject.put("colorProgress", getColorProgress());
        jSONObject.put("colorBackground", getColorBackground());
        jSONObject.put("isTurn", g());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8907d;
    }

    public int getNumScreen() {
        return this.f8910g;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.a0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8909f.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8909f.l() >= 100) {
            this.f8909f.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8909f.c();
        }
        this.f8909f.u((byte) MyApplication.b().E.get(this.f8909f.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8909f.b()) + "#" + this.f8909f.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8909f.l() >= 0) {
            if (this.f8909f.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8909f.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.W;
    }

    public void h(View view) {
        Thread thread = new Thread(this.F);
        this.G = thread;
        thread.start();
        this.E = e(0, view, 0);
        this.H = true;
    }

    public void i(View view) {
        this.H = false;
    }

    public void j(View view) {
        this.H = false;
    }

    public void k(boolean z, int i2, int i3, boolean z2) {
        this.I = z;
        this.T = z ? 0.1f : 0.3f;
        if (!z2) {
            int x = (int) getX();
            int y = (int) getY();
            getLayoutParams().height = i2;
            getLayoutParams().width = i3;
            setX(x);
            setY((y - i2) + i3);
        }
        setColorText(getColorText());
        c();
        invalidate();
        l();
    }

    public void l() {
        Drawable drawableD = d(this.f8917n, this.o, this.I);
        this.U = drawableD;
        setProgressDrawable(drawableD);
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    protected synchronized void onDraw(Canvas canvas) {
        Bitmap bitmap;
        RectF rectF;
        super.onDraw(canvas);
        this.f8911h = String.valueOf(getProgress());
        float progress = 0.0f;
        if (this.I) {
            if (getProgress() != 0) {
                progress = (getProgress() / getMax()) * 100.0f;
            }
            float height = ((getHeight() - this.S) - ((((getHeight() - this.S) - getAllPadding()) / 100.0f) * progress)) - (this.R / 2);
            if (height <= getAllPadding()) {
                height = getAllPadding();
            }
            if (height >= (getHeight() - (this.S * 2)) - (this.R / 2)) {
                height = (getHeight() - (this.S * 2)) - (this.R / 2);
            }
            this.f8914k.set(this.S, height, getWidth() - this.S, this.R + height);
            bitmap = this.f8913j;
            rectF = this.f8914k;
        } else {
            if (getProgress() != 0) {
                progress = (getProgress() / getMax()) * 100.0f;
            }
            float f2 = this.S;
            int width = getWidth();
            int i2 = this.S;
            float width2 = (((width - i2) - f2) / 100.0f) * progress;
            if (width2 <= i2) {
                width2 = i2;
            }
            if (width2 >= (getWidth() - this.S) - this.R) {
                width2 = (getWidth() - this.S) - this.R;
            }
            this.f8914k.set(width2, getAllPadding(), this.R + width2, getHeight() - this.S);
            bitmap = this.f8912i;
            rectF = this.f8914k;
        }
        canvas.drawBitmap(bitmap, (Rect) null, rectF, (Paint) null);
        canvas.drawText(getProgress() + "", (getWidth() / 2) - (this.f8915l.measureText(this.f8911h) / 2.0f), (int) (getHeight() * this.T), this.f8915l);
        invalidate();
        if (this.K) {
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.N);
        }
        if (this.J && mbCanvas.g1) {
            canvas.drawBitmap(this.L, getWidth() - this.L.getWidth(), getHeight() - this.L.getHeight(), this.M);
        }
        if (this.O) {
            this.N.setColor(-16711936);
            this.N.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.N);
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    protected synchronized void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        c();
        l();
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            h(view);
            return false;
        }
        if (action != 1) {
            if (action == 2) {
                i(view);
                return false;
            }
            if (action != 3) {
                return false;
            }
        }
        j(view);
        return false;
    }

    @Override // android.widget.AbsSeekBar, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        return this.C && super.onTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.O;
    }

    public void setColorBackground(int i2) {
        this.o = i2;
    }

    public void setColorProgress(int i2) {
        this.f8917n = i2;
    }

    public void setColorText(int i2) {
        this.f8916m = i2;
        this.f8915l.setColor(i2);
        invalidate();
    }

    public void setConnectionError(boolean z) {
        this.K = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.J = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.O = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.P = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.Q = i2;
    }

    public void setEnableOnTouch(boolean z) {
        this.C = z;
    }

    public void setFont(String str) {
    }

    public void setIdComponent(int i2) {
        this.c = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8907d = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8910g = i2;
    }

    public void setOnLongSeekBarClick(c cVar) {
        this.D = cVar;
    }

    @Override // android.widget.ProgressBar
    public synchronized void setProgress(int i2) {
        super.setProgress(i2);
    }

    public void setProgressCalc(float f2) {
        setProgress(getMax() - ((int) ((getMax() * (f2 - getAllPadding())) / ((getHeight() - getAllPadding()) - this.S))));
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.W = j2;
    }
}
