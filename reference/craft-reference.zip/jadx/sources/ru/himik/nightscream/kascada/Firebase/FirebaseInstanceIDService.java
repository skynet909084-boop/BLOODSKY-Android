package ru.himik.nightscream.kascada.Firebase;

import android.os.Build;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.s0;
import java.util.function.BiConsumer;

/* JADX INFO: loaded from: classes2.dex */
public class FirebaseInstanceIDService extends FirebaseMessagingService {
    static /* synthetic */ void v(String str, String str2) {
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    public void q(s0 s0Var) {
        if (Build.VERSION.SDK_INT >= 24) {
            s0Var.g().forEach(new BiConsumer() { // from class: ru.himik.nightscream.kascada.Firebase.a
                @Override // java.util.function.BiConsumer
                public final void accept(Object obj, Object obj2) {
                    FirebaseInstanceIDService.v((String) obj, (String) obj2);
                }
            });
        }
        super.q(s0Var);
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    public void s(String str) {
        super.s(str);
    }
}
