package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.c;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class FB_ARITHMETIC_FLOAT extends c {
    float d0;
    int e0;
    Path f0;

    public FB_ARITHMETIC_FLOAT(Context context) {
        super(context);
        this.d0 = 0.0f;
        this.e0 = 1;
        this.f0 = new Path();
        setName("+");
        s("IN1", 3);
        t("IN2", 3);
        u("Q", 3);
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width_compare_arithmetic));
        this.f8972d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height_compare_arithmetic));
    }

    public FB_ARITHMETIC_FLOAT(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = 0.0f;
        this.e0 = 1;
        this.f0 = new Path();
        setName("+");
        s("IN1", 3);
        t("IN2", 3);
        u("Q", 3);
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.c = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width_compare_arithmetic)));
            this.f8972d = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height_compare_arithmetic)));
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.d0 = 0.0f;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return;
        }
        try {
            int i2 = this.e0;
            if (i2 == 1) {
                this.d0 = ((Float) this.f8975g.getOut()).floatValue() + ((Float) this.f8976h.getOut()).floatValue();
            } else if (i2 == 2) {
                this.d0 = ((Float) this.f8975g.getOut()).floatValue() - ((Float) this.f8976h.getOut()).floatValue();
            } else if (i2 == 3) {
                this.d0 = ((Float) this.f8975g.getOut()).floatValue() * ((Float) this.f8976h.getOut()).floatValue();
            } else if (i2 == 4) {
                this.d0 = ((Float) this.f8975g.getOut()).floatValue() / ((Float) this.f8976h.getOut()).floatValue();
            }
        } catch (Exception unused) {
            this.d0 = 0.0f;
        }
    }

    public int getActionExecute() {
        return this.e0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("compareAction", getActionExecute());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return null;
        }
        return Float.valueOf(this.d0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return com.karumi.dexter.R.styleable.AppCompatTheme_toolbarStyle;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.S.setFlags(1);
        this.f0.setFillType(Path.FillType.EVEN_ODD);
        this.S.setStrokeWidth(this.U);
        this.W.setTextAlign(Paint.Align.CENTER);
        this.W.setFlags(1);
        this.W.setTextSize(getHeight() / 3);
        this.f0.reset();
        canvas.drawLine(this.T, getHeight() / 4, 0.0f, getHeight() / 4, this.S);
        canvas.drawLine(this.T, (getHeight() / 4) * 3, 0.0f, (getHeight() / 4) * 3, this.S);
        this.f0.moveTo(this.T, 0.0f);
        this.f0.lineTo(this.T, getHeight());
        this.f0.lineTo(getWidth() - this.T, getHeight() / 2);
        this.f0.lineTo(this.T, 0.0f);
        this.f0.close();
        this.S.setStyle(Paint.Style.FILL);
        this.S.setColor(-7829368);
        canvas.drawPath(this.f0, this.S);
        this.S.setStyle(Paint.Style.STROKE);
        this.S.setColor(-16777216);
        canvas.drawPath(this.f0, this.S);
        if (this.f8973e) {
            canvas.drawCircle((getWidth() - this.T) + this.b0, getHeight() / 2, this.b0, this.S);
            width = (getWidth() - this.T) + (this.b0 * 2);
        } else {
            width = getWidth() - this.T;
        }
        canvas.drawLine(width, getHeight() / 2, getWidth(), getHeight() / 2, this.S);
        canvas.drawText(getName(), this.T * 2, (int) ((getHeight() / 2) - ((this.W.descent() + this.W.ascent()) / 2.0f)), this.W);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        this.f8979k.set((int) getX(), ((int) getY()) + (getHeight() / 4));
        this.f8980l.set((int) getX(), ((int) getY()) + ((getHeight() / 4) * 3));
        this.f8981m.set(((int) getX()) + getWidth(), ((int) getY()) + (getHeight() / 2));
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
        String str;
        this.e0 = i2;
        if (i2 == 1) {
            str = "+";
        } else if (i2 == 2) {
            str = "-";
        } else {
            if (i2 != 3) {
                if (i2 == 4) {
                    str = "/";
                }
                invalidate();
            }
            str = "*";
        }
        setName(str);
        invalidate();
    }
}
