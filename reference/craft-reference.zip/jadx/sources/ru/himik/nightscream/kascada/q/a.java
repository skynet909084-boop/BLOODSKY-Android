package ru.himik.nightscream.kascada.q;

import ru.himik.nightscream.kascada.CustomComponents.b;

/* JADX INFO: loaded from: classes.dex */
public interface a {
    int a();

    String b();

    void c(b bVar);

    void cancel();

    void d();

    void e(b bVar);

    void f(b bVar);
}
