package ru.himik.nightscream.kascada.Logic.VarName;

import android.util.SparseArray;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes2.dex */
public class a {
    public Map<String, Boolean> a = new HashMap();
    public Map<String, Integer> b = new HashMap();
    public Map<String, Float> c = new HashMap();

    public void a(SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray) {
        for (int i2 = 0; i2 < sparseArray.size(); i2++) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = sparseArray.get(sparseArray.keyAt(i2));
            if (aVar.getNumScreen() == -1) {
                if (aVar.getTypeFb() == 133) {
                    VarNameIn varNameIn = (VarNameIn) aVar;
                    if (varNameIn.getTypeVarValue() == 1 && aVar.getRootUniqueIdMacro() > 0) {
                        b(aVar.getRootUniqueIdMacro() + "_" + varNameIn.getVarName(), varNameIn.getTypeVar());
                    }
                }
                if (aVar.getTypeFb() == 134 && aVar.getRootUniqueIdMacro() > 0) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(aVar.getRootUniqueIdMacro());
                    sb.append("_");
                    VarNameOut varNameOut = (VarNameOut) aVar;
                    sb.append(varNameOut.getVarName());
                    b(sb.toString(), varNameOut.getTypeVar());
                }
            }
        }
    }

    public void b(String str, int i2) {
        Map map;
        Object objValueOf;
        if (i2 == 1) {
            map = this.a;
            objValueOf = Boolean.FALSE;
        } else if (i2 == 2) {
            map = this.b;
            objValueOf = 0;
        } else {
            if (i2 != 3) {
                return;
            }
            map = this.c;
            objValueOf = Float.valueOf(0.0f);
        }
        map.put(str, objValueOf);
    }

    public void c() {
        this.a.clear();
        this.b.clear();
        this.c.clear();
    }

    public List<String> d(int i2) {
        if (i2 == 1) {
            return new ArrayList(this.a.keySet());
        }
        if (i2 == 2) {
            return new ArrayList(this.b.keySet());
        }
        if (i2 != 3) {
            return null;
        }
        return new ArrayList(this.c.keySet());
    }

    public boolean e(String str) {
        if (this.a.containsKey(str)) {
            return this.a.get(str).booleanValue();
        }
        return false;
    }

    public float f(String str) {
        if (this.c.containsKey(str)) {
            return this.c.get(str).floatValue();
        }
        return 0.0f;
    }

    public int g(String str) {
        if (this.b.containsKey(str)) {
            return this.b.get(str).intValue();
        }
        return 0;
    }

    public boolean h(String str, Object obj) {
        Map map;
        Object objValueOf;
        if (obj instanceof Boolean) {
            map = this.a;
            objValueOf = Boolean.valueOf(((Boolean) obj).booleanValue());
        } else if (obj instanceof Integer) {
            map = this.b;
            objValueOf = Integer.valueOf(((Integer) obj).intValue());
        } else {
            if (!(obj instanceof Float)) {
                return false;
            }
            map = this.c;
            objValueOf = Float.valueOf(((Float) obj).floatValue());
        }
        map.put(str, objValueOf);
        return true;
    }

    public void i(SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray) {
        c();
        for (int i2 = 0; i2 < sparseArray.size(); i2++) {
            int iKeyAt = sparseArray.keyAt(i2);
            if (sparseArray.get(iKeyAt).getNumScreen() != -1 && (sparseArray.get(iKeyAt).getTypeFb() == 133 || sparseArray.get(iKeyAt).getTypeFb() == 134)) {
                b bVar = (b) sparseArray.get(iKeyAt);
                if (bVar.getTypeVarValue() == 1) {
                    b(bVar.getVarName(), bVar.getTypeVar());
                }
            }
        }
    }
}
