package ru.himik.nightscream.kascada.Preference;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.rarepebble.colorpicker.ColorPreference;
import org.json.JSONException;
import org.json.JSONObject;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class w0 extends PreferenceFragment {
    int G;
    int H;
    int I;
    boolean J;
    boolean Y;
    boolean Z;
    EditTextPreference m1;
    EditTextPreference n1;
    public TextView r1;
    String a = "";
    String b = "";
    String c = "";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    String f9124d = "";

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    String f9125e = "";

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    String f9126f = "";

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    String f9127g = "";

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    String f9128h = "";

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    String f9129i = "";

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    String f9130j = "";

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    String f9131k = "";

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f9132l = "";

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    String f9133m = "";

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f9134n = "";
    String o = "";
    String C = "";
    int D = 30;
    int E = 0;
    String F = "";
    float K = 0.0f;
    float L = 10000.0f;
    int M = 1;
    boolean N = false;
    boolean O = false;
    int P = 0;
    int Q = 0;
    int R = 0;
    boolean S = false;
    String T = "";
    String U = "";
    boolean V = false;
    int W = 0;
    int X = 1;
    int a0 = 0;
    int b0 = 100;
    int c0 = 0;
    int d0 = 0;
    int e0 = 100;
    int f0 = 0;
    int g0 = 100;
    int h0 = 5;
    int i0 = 20;
    int j0 = 75;
    int k0 = 90;
    boolean l0 = false;
    String m0 = "";
    int n0 = 1;
    int o0 = 10;
    String p0 = "";
    String q0 = "";
    String r0 = "";
    String s0 = "";
    int t0 = 1;
    int u0 = 1;
    String v0 = "default";
    String w0 = "FLOAT";
    int x0 = 4;
    int y0 = 0;
    int z0 = 1;
    String A0 = "";
    int B0 = 0;
    int C0 = 0;
    int D0 = 0;
    int E0 = 0;
    boolean F0 = false;
    boolean G0 = false;
    boolean H0 = false;
    String I0 = "ASCII";
    int J0 = 0;
    int K0 = 2;
    String L0 = "";
    String M0 = "";
    String N0 = "";
    boolean O0 = false;
    int P0 = 0;
    int Q0 = 0;
    int R0 = 0;
    String S0 = "";
    String T0 = "";
    String U0 = "";
    String V0 = "";
    String W0 = "";
    String X0 = "";
    String Y0 = "";
    String Z0 = "";
    String a1 = "";
    String b1 = "";
    String c1 = "";
    String d1 = "";
    String e1 = "";
    String f1 = "";
    String g1 = "";
    String h1 = "";
    int i1 = 0;
    int j1 = 0;
    int k1 = 0;
    boolean l1 = false;
    String o1 = "";
    String p1 = "";
    boolean q1 = false;
    int s1 = 0;
    int t1 = 0;
    int u1 = 0;
    int v1 = 0;
    int w1 = 1;
    String x1 = "";
    int y1 = 1;
    int z1 = 1;
    int A1 = 100;
    int B1 = 1;
    boolean C1 = true;
    boolean D1 = false;
    String E1 = "";
    String F1 = "";
    String G1 = "";
    String H1 = "";
    String I1 = "";
    String J1 = "";
    String K1 = "";
    String L1 = "";

    class a implements Preference.OnPreferenceClickListener {

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.w0$a$a, reason: collision with other inner class name */
        class DialogInterfaceOnClickListenerC0292a implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;

            DialogInterfaceOnClickListenerC0292a(EditText editText) {
                this.a = editText;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                try {
                    if (Float.parseFloat(this.a.getText().toString()) > Float.parseFloat(w0.this.n1.getText().toString())) {
                        w0.this.m1.setText(this.a.getText().toString());
                        w0.this.m1.setSummary(w0.this.getResources().getString(R.string.base_max) + " = " + this.a.getText().toString());
                        w0.this.L = Float.parseFloat(this.a.getText().toString());
                    } else {
                        Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.error_max_can_not_be_less_min), 1).show();
                    }
                } catch (Exception unused) {
                    Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.error), 1).show();
                }
            }
        }

        class b implements DialogInterface.OnClickListener {
            b(a aVar) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        a() {
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            EditTextPreference editTextPreference;
            StringBuilder sb;
            w0 w0Var = w0.this;
            if (w0Var.M == 0) {
                w0Var.m1.setText(String.valueOf(Math.round(w0Var.L)));
                editTextPreference = w0.this.m1;
                sb = new StringBuilder();
                sb.append(w0.this.getResources().getString(R.string.base_max));
                sb.append(" = ");
                sb.append((int) w0.this.L);
            } else {
                w0Var.m1.setText(String.valueOf(w0Var.L));
                editTextPreference = w0.this.m1;
                sb = new StringBuilder();
                sb.append(w0.this.getResources().getString(R.string.base_max));
                sb.append(" = ");
                sb.append(w0.this.L);
            }
            editTextPreference.setSummary(sb.toString());
            w0.this.m1.getDialog().dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(w0.this.getActivity());
            builder.setTitle(w0.this.getResources().getString(R.string.base_max));
            EditText editText = new EditText(w0.this.getActivity());
            editText.setInputType(w0.this.M == 0 ? 4098 : 12290);
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});
            editText.setText(w0.this.m1.getText().toString());
            editText.setSelection(editText.length());
            builder.setView(editText);
            builder.setPositiveButton("ОК", new DialogInterfaceOnClickListenerC0292a(editText));
            builder.setNegativeButton(w0.this.getResources().getString(R.string.dialog_cancel), new b(this));
            builder.show();
            return true;
        }
    }

    class a0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        a0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 2);
            return true;
        }
    }

    class a1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        a1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 4);
            return true;
        }
    }

    class a2 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;
        final /* synthetic */ String[] b;

        a2(ListPreference listPreference, String[] strArr) {
            this.a = listPreference;
            this.b = strArr;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            String str;
            w0.this.y1 = Integer.parseInt((String) obj);
            int i2 = w0.this.y1;
            if (i2 == 100) {
                this.a.setValueIndex(0);
                listPreference = this.a;
                str = this.b[0];
            } else {
                this.a.setValueIndex(i2);
                listPreference = this.a;
                str = this.b[w0.this.y1];
            }
            listPreference.setSummary(str);
            return false;
        }
    }

    class b implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        class a implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;

            a(EditText editText) {
                this.a = editText;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                b.this.a.setText(this.a.getText().toString());
                b.this.a.setSummary(this.a.getText().toString());
            }
        }

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.w0$b$b, reason: collision with other inner class name */
        class DialogInterfaceOnClickListenerC0293b implements DialogInterface.OnClickListener {
            DialogInterfaceOnClickListenerC0293b(b bVar) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        b(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(w0.this.getActivity());
            builder.setTitle(w0.this.getResources().getString(R.string.base_password));
            EditText editText = new EditText(w0.this.getActivity());
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
            editText.setText(this.a.getText().toString());
            editText.setSelection(editText.length());
            builder.setView(editText);
            builder.setPositiveButton("ОК", new a(editText));
            builder.setNegativeButton(w0.this.getResources().getString(R.string.dialog_cancel), new DialogInterfaceOnClickListenerC0293b(this));
            builder.show();
            return true;
        }
    }

    class b0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        b0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 3);
            return true;
        }
    }

    class b1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        b1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 5);
            return true;
        }
    }

    class b2 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        b2(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                int i2 = Integer.parseInt(obj + "");
                if (i2 <= 0 || i2 > 16) {
                    Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.count_bit_should_be_1_to_16), 1).show();
                } else {
                    this.a.setSummary(i2 + "");
                    this.a.setText(i2 + "");
                }
                return false;
            } catch (Exception unused) {
                Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.unexcepted_error), 1).show();
                return false;
            }
        }
    }

    class c implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;

        c(ListPreference listPreference) {
            this.a = listPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            Resources resources;
            int i2;
            int i3 = Integer.parseInt((String) obj);
            if (i3 != 0) {
                if (i3 == 1) {
                    listPreference = this.a;
                    resources = w0.this.getResources();
                    i2 = R.string.int_signed;
                }
                return true;
            }
            listPreference = this.a;
            resources = w0.this.getResources();
            i2 = R.string.int_unsigned;
            listPreference.setSummary(resources.getString(i2));
            return true;
        }
    }

    class c0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        c0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 4);
            return true;
        }
    }

    class c1 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;
        final /* synthetic */ ListPreference b;
        final /* synthetic */ ListPreference c;

        c1(ListPreference listPreference, ListPreference listPreference2, ListPreference listPreference3) {
            this.a = listPreference;
            this.b = listPreference2;
            this.c = listPreference3;
        }

        /* JADX WARN: Code duplicated, block: B:16:0x0051  */
        /* JADX WARN: Code duplicated, block: B:17:0x0053  */
        /* JADX WARN: Code duplicated, block: B:20:0x005f  */
        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            Resources resources;
            int i2;
            boolean z;
            String str = (String) obj;
            int i3 = Integer.parseInt(str);
            if (i3 == 0) {
                listPreference = this.a;
                resources = w0.this.getResources();
                i2 = R.string.int_signed;
            } else if (i3 == 1) {
                listPreference = this.a;
                resources = w0.this.getResources();
                i2 = R.string.int_unsigned;
            } else {
                if (i3 != 2) {
                    if (i3 == 3) {
                        listPreference = this.a;
                        resources = w0.this.getResources();
                        i2 = R.string.int32_;
                    }
                    ListPreference listPreference2 = this.b;
                    if (Integer.parseInt(str) < 3) {
                        z = true;
                    } else {
                        z = false;
                    }
                    listPreference2.setEnabled(z);
                    this.c.setEnabled(Integer.parseInt(str) < 3);
                    return true;
                }
                listPreference = this.a;
                resources = w0.this.getResources();
                i2 = R.string.float_;
            }
            listPreference.setSummary(resources.getString(i2));
            ListPreference listPreference3 = this.b;
            if (Integer.parseInt(str) < 3) {
                z = true;
            } else {
                z = false;
            }
            listPreference3.setEnabled(z);
            this.c.setEnabled(Integer.parseInt(str) < 3);
            return true;
        }
    }

    class c2 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ EditTextPreference b;
        final /* synthetic */ ListPreference c;

        c2(EditTextPreference editTextPreference, EditTextPreference editTextPreference2, ListPreference listPreference) {
            this.a = editTextPreference;
            this.b = editTextPreference2;
            this.c = listPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            int i2 = Integer.parseInt((String) obj);
            if (i2 == 0) {
                this.a.setEnabled(false);
                this.b.setEnabled(false);
                this.c.setEnabled(false);
            } else if (i2 == 1) {
                this.a.setEnabled(true);
                this.b.setEnabled(true);
                this.c.setEnabled(true);
            } else if (i2 == 2) {
                this.a.setEnabled(false);
                this.b.setEnabled(false);
                this.c.setEnabled(false);
                w0.this.w1 = 1;
            }
            return true;
        }
    }

    class d implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;
        final /* synthetic */ ListPreference b;
        final /* synthetic */ ListPreference c;

        d(ListPreference listPreference, ListPreference listPreference2, ListPreference listPreference3) {
            this.a = listPreference;
            this.b = listPreference2;
            this.c = listPreference3;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            EditTextPreference editTextPreference;
            StringBuilder sb;
            int i2 = Integer.parseInt((String) obj);
            if (i2 != 0) {
                if (i2 == 1) {
                    this.a.setSummary(w0.this.getResources().getString(R.string.float_));
                    this.b.setEnabled(false);
                    this.c.setEnabled(true);
                    w0 w0Var = w0.this;
                    w0Var.M = 1;
                    w0Var.m1.setSummary(w0.this.getResources().getString(R.string.base_max) + " = " + w0.this.L);
                    editTextPreference = w0.this.n1;
                    sb = new StringBuilder();
                    sb.append(w0.this.getResources().getString(R.string.base_min));
                    sb.append(" = ");
                    sb.append(w0.this.K);
                }
                return true;
            }
            this.a.setSummary(w0.this.getResources().getString(R.string.int_));
            this.b.setEnabled(true);
            this.c.setEnabled(false);
            w0 w0Var2 = w0.this;
            w0Var2.M = 0;
            w0Var2.m1.setSummary(w0.this.getResources().getString(R.string.base_max) + " = " + ((int) w0.this.L));
            editTextPreference = w0.this.n1;
            sb = new StringBuilder();
            sb.append(w0.this.getResources().getString(R.string.base_min));
            sb.append(" = ");
            sb.append((int) w0.this.K);
            editTextPreference.setSummary(sb.toString());
            return true;
        }
    }

    class d0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        d0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 5);
            return true;
        }
    }

    class d1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        d1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 6);
            return true;
        }
    }

    class d2 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        class a implements ru.himik.nightscream.kascada.r.z {
            a() {
            }

            @Override // ru.himik.nightscream.kascada.r.z
            public void a(String str) {
                d2.this.a.setText(str);
                d2.this.a.setSummary(str);
            }
        }

        d2(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            ru.himik.nightscream.kascada.r.a0 a0Var = new ru.himik.nightscream.kascada.r.a0();
            a0Var.x1(((PrefActivity) w0.this.getActivity()).getSupportFragmentManager(), "");
            a0Var.A1(new a());
            return false;
        }
    }

    class e implements Preference.OnPreferenceClickListener {
        final /* synthetic */ ColorPreference a;
        final /* synthetic */ CheckBoxPreference b;

        e(w0 w0Var, ColorPreference colorPreference, CheckBoxPreference checkBoxPreference) {
            this.a = colorPreference;
            this.b = checkBoxPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(!this.b.isChecked());
            return true;
        }
    }

    class e0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        e0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 6);
            return true;
        }
    }

    class e1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        e1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 7);
            return true;
        }
    }

    class e2 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        e2(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                w0.this.i0 = Integer.parseInt((String) obj);
            } catch (Exception unused) {
            }
            this.a.setSummary(w0.this.i0 + "");
            return true;
        }
    }

    class f implements Preference.OnPreferenceClickListener {
        final /* synthetic */ CheckBoxPreference a;
        final /* synthetic */ EditTextPreference b;
        final /* synthetic */ EditTextPreference c;

        f(w0 w0Var, CheckBoxPreference checkBoxPreference, EditTextPreference editTextPreference, EditTextPreference editTextPreference2) {
            this.a = checkBoxPreference;
            this.b = editTextPreference;
            this.c = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            if (this.a.isChecked()) {
                this.b.setEnabled(true);
                this.c.setEnabled(true);
            } else {
                this.b.setEnabled(false);
                this.c.setEnabled(false);
            }
            return true;
        }
    }

    class f0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        f0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 7);
            return true;
        }
    }

    class f1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        f1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 8);
            return true;
        }
    }

    class f2 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        f2(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                w0.this.h0 = Integer.parseInt((String) obj);
            } catch (Exception unused) {
            }
            w0 w0Var = w0.this;
            if (w0Var.h0 > w0Var.g0) {
                Toast.makeText(w0Var.getActivity(), R.string.toast_count_must_be_less_max_value, 1).show();
            } else {
                this.a.setSummary(w0.this.h0 + "");
            }
            return true;
        }
    }

    class g implements Preference.OnPreferenceClickListener {
        final /* synthetic */ CheckBoxPreference a;
        final /* synthetic */ ColorPreference b;
        final /* synthetic */ EditTextPreference c;

        g(w0 w0Var, CheckBoxPreference checkBoxPreference, ColorPreference colorPreference, EditTextPreference editTextPreference) {
            this.a = checkBoxPreference;
            this.b = colorPreference;
            this.c = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            if (this.a.isChecked()) {
                this.b.setEnabled(true);
                this.c.setEnabled(true);
            } else {
                this.b.setEnabled(false);
                this.c.setEnabled(false);
            }
            return true;
        }
    }

    class g0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ CheckBoxPreference b;

        g0(w0 w0Var, EditTextPreference editTextPreference, CheckBoxPreference checkBoxPreference) {
            this.a = editTextPreference;
            this.b = checkBoxPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(!this.b.isChecked());
            return true;
        }
    }

    class g1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        g1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 9);
            return true;
        }
    }

    class g2 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ EditTextPreference b;

        g2(EditTextPreference editTextPreference, EditTextPreference editTextPreference2) {
            this.a = editTextPreference;
            this.b = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                w0.this.f0 = Integer.parseInt((String) obj);
            } catch (Exception unused) {
            }
            this.a.setSummary(w0.this.f0 + "");
            this.b.setSummary(w0.this.getResources().getString(R.string.green_) + ": " + w0.this.f0 + "-" + w0.this.j0 + " " + w0.this.getResources().getString(R.string.yellow_) + " : " + w0.this.j0 + "-" + w0.this.k0 + " " + w0.this.getResources().getString(R.string.red_) + " : " + w0.this.k0 + "-" + w0.this.g0);
            return true;
        }
    }

    class h implements Preference.OnPreferenceClickListener {
        final /* synthetic */ CheckBoxPreference a;
        final /* synthetic */ EditTextPreference b;
        final /* synthetic */ ColorPreference c;

        h(w0 w0Var, CheckBoxPreference checkBoxPreference, EditTextPreference editTextPreference, ColorPreference colorPreference) {
            this.a = checkBoxPreference;
            this.b = editTextPreference;
            this.c = colorPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            if (this.a.isChecked()) {
                this.b.setEnabled(true);
                this.c.setEnabled(true);
            } else {
                this.b.setEnabled(false);
                this.c.setEnabled(false);
            }
            return true;
        }
    }

    class h0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        h0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 8);
            return true;
        }
    }

    class h1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        h1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 10);
            return true;
        }
    }

    class h2 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ EditTextPreference b;

        h2(EditTextPreference editTextPreference, EditTextPreference editTextPreference2) {
            this.a = editTextPreference;
            this.b = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                w0.this.g0 = Integer.parseInt((String) obj);
            } catch (Exception unused) {
            }
            this.a.setSummary(w0.this.g0 + "");
            this.b.setSummary(w0.this.getResources().getString(R.string.green_) + ": " + w0.this.f0 + "-" + w0.this.j0 + " " + w0.this.getResources().getString(R.string.yellow_) + " : " + w0.this.j0 + "-" + w0.this.k0 + " " + w0.this.getResources().getString(R.string.red_) + " : " + w0.this.k0 + "-" + w0.this.g0);
            return true;
        }
    }

    class i implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        class a implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;
            final /* synthetic */ EditText b;

            a(EditText editText, EditText editText2) {
                this.a = editText;
                this.b = editText2;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                if (this.a.getText().toString().length() > 0) {
                    w0.this.c0 = Integer.parseInt(this.a.getText().toString());
                } else {
                    w0.this.c0 = 0;
                }
                if (this.b.getText().toString().length() > 0) {
                    w0.this.d0 = Integer.parseInt(this.b.getText().toString());
                } else {
                    w0.this.d0 = 0;
                }
                w0 w0Var = w0.this;
                if (w0Var.c0 > w0Var.L) {
                    Toast.makeText(w0Var.getActivity(), w0.this.getResources().getString(R.string.error_val_first_point), 1).show();
                    w0.this.c0 = 0;
                }
                w0 w0Var2 = w0.this;
                if (w0Var2.d0 > w0Var2.L) {
                    Toast.makeText(w0Var2.getActivity(), w0.this.getResources().getString(R.string.error_val_second_point), 1).show();
                    w0.this.d0 = 0;
                }
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(w0.this.getActivity());
                defaultSharedPreferences.edit().putInt("firstPoint", w0.this.c0).apply();
                defaultSharedPreferences.edit().putInt("secondPoint", w0.this.d0).apply();
                i.this.a.setSummary(w0.this.getResources().getString(R.string.green_) + ": 0-" + w0.this.c0 + " " + w0.this.getResources().getString(R.string.yellow_) + " : " + w0.this.c0 + "-" + w0.this.d0 + " " + w0.this.getResources().getString(R.string.red_) + " : " + w0.this.d0 + "-" + w0.this.e0);
            }
        }

        class b implements DialogInterface.OnClickListener {
            b(i iVar) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        i(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(w0.this.getActivity());
            builder.setTitle(w0.this.getResources().getString(R.string.range));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
            layoutParams.gravity = 3;
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.gravity = 17;
            TextView textView = new TextView(w0.this.getActivity());
            textView.setText(w0.this.getResources().getString(R.string.boundary));
            textView.setBackgroundColor(-256);
            textView.setGravity(17);
            textView.setLayoutParams(layoutParams);
            EditText editText = new EditText(w0.this.getActivity());
            editText.setInputType(2);
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(5)});
            editText.setText(w0.this.c0 + "");
            editText.setSelection(editText.length());
            editText.setLayoutParams(layoutParams2);
            TextView textView2 = new TextView(w0.this.getActivity());
            textView2.setText(w0.this.getResources().getString(R.string.boundary));
            textView2.setBackgroundColor(-65536);
            textView2.setGravity(17);
            textView2.setLayoutParams(layoutParams);
            EditText editText2 = new EditText(w0.this.getActivity());
            editText2.setInputType(2);
            editText2.setFilters(new InputFilter[]{new InputFilter.LengthFilter(5)});
            editText2.setText(w0.this.d0 + "");
            editText2.setSelection(editText2.length());
            editText2.setLayoutParams(layoutParams2);
            LinearLayout linearLayout = new LinearLayout(w0.this.getActivity());
            linearLayout.setOrientation(0);
            linearLayout.addView(textView2);
            linearLayout.addView(editText2);
            LinearLayout linearLayout2 = new LinearLayout(w0.this.getActivity());
            linearLayout2.setOrientation(0);
            linearLayout2.addView(textView);
            linearLayout2.addView(editText);
            LinearLayout linearLayout3 = new LinearLayout(w0.this.getActivity());
            linearLayout3.setOrientation(1);
            linearLayout3.addView(linearLayout2);
            linearLayout3.addView(linearLayout);
            builder.setView(linearLayout3);
            builder.setPositiveButton("ОК", new a(editText, editText2));
            builder.setNegativeButton(w0.this.getResources().getString(R.string.dialog_cancel), new b(this));
            builder.show();
            return true;
        }
    }

    class i0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        i0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 9);
            return true;
        }
    }

    class i1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        i1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 11);
            return true;
        }
    }

    class i2 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        class a implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;
            final /* synthetic */ EditText b;

            a(EditText editText, EditText editText2) {
                this.a = editText;
                this.b = editText2;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                try {
                    w0.this.j0 = Integer.parseInt(this.a.getText().toString());
                } catch (Exception unused) {
                }
                try {
                    w0.this.k0 = Integer.parseInt(this.b.getText().toString());
                } catch (Exception unused2) {
                }
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(w0.this.getActivity());
                defaultSharedPreferences.edit().putInt("gauge_percentLowScale", w0.this.j0).apply();
                defaultSharedPreferences.edit().putInt("gauge_percentMediumScale", w0.this.k0).apply();
                i2.this.a.setSummary(w0.this.getResources().getString(R.string.green_) + ": " + w0.this.f0 + "-" + w0.this.j0 + " " + w0.this.getResources().getString(R.string.yellow_) + " : " + w0.this.j0 + "-" + w0.this.k0 + " " + w0.this.getResources().getString(R.string.red_) + " : " + w0.this.k0 + "-" + w0.this.g0);
            }
        }

        class b implements DialogInterface.OnClickListener {
            b(i2 i2Var) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        i2(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(w0.this.getActivity());
            builder.setTitle(w0.this.getResources().getString(R.string.range));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
            layoutParams.gravity = 3;
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.gravity = 17;
            TextView textView = new TextView(w0.this.getActivity());
            textView.setText(w0.this.getResources().getString(R.string.boundary));
            textView.setBackgroundColor(-256);
            textView.setGravity(17);
            textView.setLayoutParams(layoutParams);
            EditText editText = new EditText(w0.this.getActivity());
            editText.setInputType(2);
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(5)});
            editText.setText(w0.this.j0 + "");
            editText.setSelection(editText.length());
            editText.setLayoutParams(layoutParams2);
            TextView textView2 = new TextView(w0.this.getActivity());
            textView2.setText(w0.this.getResources().getString(R.string.boundary));
            textView2.setBackgroundColor(-65536);
            textView2.setGravity(17);
            textView2.setLayoutParams(layoutParams);
            EditText editText2 = new EditText(w0.this.getActivity());
            editText2.setInputType(2);
            editText2.setFilters(new InputFilter[]{new InputFilter.LengthFilter(5)});
            editText2.setText(w0.this.k0 + "");
            editText2.setSelection(editText2.length());
            editText2.setLayoutParams(layoutParams2);
            LinearLayout linearLayout = new LinearLayout(w0.this.getActivity());
            linearLayout.setOrientation(0);
            linearLayout.addView(textView2);
            linearLayout.addView(editText2);
            LinearLayout linearLayout2 = new LinearLayout(w0.this.getActivity());
            linearLayout2.setOrientation(0);
            linearLayout2.addView(textView);
            linearLayout2.addView(editText);
            LinearLayout linearLayout3 = new LinearLayout(w0.this.getActivity());
            linearLayout3.setOrientation(1);
            linearLayout3.addView(linearLayout2);
            linearLayout3.addView(linearLayout);
            builder.setView(linearLayout3);
            builder.setPositiveButton("ОК", new a(editText, editText2));
            builder.setNegativeButton(w0.this.getResources().getString(R.string.dialog_cancel), new b(this));
            builder.show();
            return true;
        }
    }

    class j implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;

        j(ListPreference listPreference) {
            this.a = listPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            Resources resources;
            int i2;
            int i3 = Integer.parseInt((String) obj);
            if (i3 == 0) {
                listPreference = this.a;
                resources = w0.this.getResources();
                i2 = R.string.int_signed;
            } else {
                if (i3 != 1) {
                    if (i3 == 2) {
                        listPreference = this.a;
                        resources = w0.this.getResources();
                        i2 = R.string.float_;
                    }
                    return true;
                }
                listPreference = this.a;
                resources = w0.this.getResources();
                i2 = R.string.int_unsigned;
            }
            listPreference.setSummary(resources.getString(i2));
            return true;
        }
    }

    class j0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        j0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 18);
            return true;
        }
    }

    class j1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        j1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 12);
            return true;
        }
    }

    class j2 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ ColorPreference a;
        final /* synthetic */ CheckBoxPreference b;
        final /* synthetic */ ColorPreference c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9138d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9139e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9140f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9141g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9142h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9143i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9144j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9145k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9146l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9147m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        final /* synthetic */ ColorPreference f9148n;
        final /* synthetic */ ColorPreference o;
        final /* synthetic */ ColorPreference p;
        final /* synthetic */ ColorPreference q;

        j2(w0 w0Var, ColorPreference colorPreference, CheckBoxPreference checkBoxPreference, ColorPreference colorPreference2, ColorPreference colorPreference3, ColorPreference colorPreference4, ColorPreference colorPreference5, ColorPreference colorPreference6, ColorPreference colorPreference7, ColorPreference colorPreference8, ColorPreference colorPreference9, ColorPreference colorPreference10, ColorPreference colorPreference11, ColorPreference colorPreference12, ColorPreference colorPreference13, ColorPreference colorPreference14, ColorPreference colorPreference15, ColorPreference colorPreference16) {
            this.a = colorPreference;
            this.b = checkBoxPreference;
            this.c = colorPreference2;
            this.f9138d = colorPreference3;
            this.f9139e = colorPreference4;
            this.f9140f = colorPreference5;
            this.f9141g = colorPreference6;
            this.f9142h = colorPreference7;
            this.f9143i = colorPreference8;
            this.f9144j = colorPreference9;
            this.f9145k = colorPreference10;
            this.f9146l = colorPreference11;
            this.f9147m = colorPreference12;
            this.f9148n = colorPreference13;
            this.o = colorPreference14;
            this.p = colorPreference15;
            this.q = colorPreference16;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(!this.b.isChecked());
            this.c.setEnabled(!this.b.isChecked());
            this.f9138d.setEnabled(!this.b.isChecked());
            this.f9139e.setEnabled(!this.b.isChecked());
            this.f9140f.setEnabled(!this.b.isChecked());
            this.f9141g.setEnabled(!this.b.isChecked());
            this.f9142h.setEnabled(!this.b.isChecked());
            this.f9143i.setEnabled(!this.b.isChecked());
            this.f9144j.setEnabled(!this.b.isChecked());
            this.f9145k.setEnabled(!this.b.isChecked());
            this.f9146l.setEnabled(!this.b.isChecked());
            this.f9147m.setEnabled(!this.b.isChecked());
            this.f9148n.setEnabled(!this.b.isChecked());
            this.o.setEnabled(!this.b.isChecked());
            this.p.setEnabled(!this.b.isChecked());
            this.q.setEnabled(!this.b.isChecked());
            return true;
        }
    }

    class k implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ CheckBoxPreference b;

        k(w0 w0Var, EditTextPreference editTextPreference, CheckBoxPreference checkBoxPreference) {
            this.a = editTextPreference;
            this.b = checkBoxPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(!this.b.isChecked());
            return true;
        }
    }

    class k0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        k0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 19);
            return true;
        }
    }

    class k1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        k1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 13);
            return true;
        }
    }

    class k2 implements Preference.OnPreferenceClickListener {

        class a implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;

            a(EditText editText) {
                this.a = editText;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                try {
                    if (Float.parseFloat(this.a.getText().toString()) < Float.parseFloat(w0.this.m1.getText().toString())) {
                        w0.this.n1.setText(this.a.getText().toString());
                        w0.this.n1.setSummary(w0.this.getResources().getString(R.string.base_min) + " = " + this.a.getText().toString());
                        w0.this.K = Float.parseFloat(this.a.getText().toString());
                    } else {
                        Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.error_min_can_not_be_more_max), 1).show();
                    }
                } catch (Exception unused) {
                    Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.error), 1).show();
                }
            }
        }

        class b implements DialogInterface.OnClickListener {
            b(k2 k2Var) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        k2() {
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            EditTextPreference editTextPreference;
            StringBuilder sb;
            w0 w0Var = w0.this;
            if (w0Var.M == 0) {
                w0Var.n1.setText(String.valueOf(Math.round(w0Var.K)));
                editTextPreference = w0.this.n1;
                sb = new StringBuilder();
                sb.append(w0.this.getResources().getString(R.string.base_min));
                sb.append(" = ");
                sb.append((int) w0.this.K);
            } else {
                w0Var.n1.setText(String.valueOf(w0Var.K));
                editTextPreference = w0.this.n1;
                sb = new StringBuilder();
                sb.append(w0.this.getResources().getString(R.string.base_min));
                sb.append(" = ");
                sb.append(w0.this.K);
            }
            editTextPreference.setSummary(sb.toString());
            w0.this.n1.getDialog().dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(w0.this.getActivity());
            builder.setTitle(w0.this.getResources().getString(R.string.base_min));
            EditText editText = new EditText(w0.this.getActivity());
            editText.setInputType(w0.this.M == 0 ? 4098 : 12290);
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});
            editText.setText(w0.this.n1.getText().toString());
            editText.setSelection(editText.length());
            builder.setView(editText);
            builder.setPositiveButton("ОК", new a(editText));
            builder.setNegativeButton(w0.this.getResources().getString(R.string.dialog_cancel), new b(this));
            builder.show();
            return true;
        }
    }

    class l implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ SharedPreferences b;

        class a implements DialogInterface.OnShowListener {
            final /* synthetic */ AlertDialog a;
            final /* synthetic */ EditText b;

            /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.w0$l$a$a, reason: collision with other inner class name */
            class ViewOnClickListenerC0294a implements View.OnClickListener {
                ViewOnClickListenerC0294a() {
                }

                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    int i2 = Integer.parseInt(a.this.b.getText().toString());
                    if (i2 < 2 || i2 > 1000) {
                        Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.incorrect_val), 1).show();
                        return;
                    }
                    l.this.a.setSummary(i2 + "");
                    l lVar = l.this;
                    w0.this.o0 = i2;
                    lVar.b.edit().putString("graphCountPoint", w0.this.o0 + "").apply();
                    a.this.a.dismiss();
                }
            }

            a(AlertDialog alertDialog, EditText editText) {
                this.a = alertDialog;
                this.b = editText;
            }

            @Override // android.content.DialogInterface.OnShowListener
            public void onShow(DialogInterface dialogInterface) {
                this.a.getButton(-1).setOnClickListener(new ViewOnClickListenerC0294a());
            }
        }

        l(EditTextPreference editTextPreference, SharedPreferences sharedPreferences) {
            this.a = editTextPreference;
            this.b = sharedPreferences;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            EditText editText = new EditText(w0.this.getActivity());
            editText.setInputType(2);
            editText.setText(w0.this.o0 + "");
            AlertDialog alertDialogCreate = new AlertDialog.Builder(w0.this.getActivity()).setView(editText).setTitle(w0.this.getResources().getString(R.string.set_count_point)).setPositiveButton(android.R.string.ok, (DialogInterface.OnClickListener) null).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).create();
            alertDialogCreate.setOnShowListener(new a(alertDialogCreate, editText));
            alertDialogCreate.show();
            return true;
        }
    }

    class l0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        l0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 20);
            return true;
        }
    }

    class l1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        l1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 14);
            return true;
        }
    }

    class l2 implements DialogInterface.OnClickListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ EditText b;
        final /* synthetic */ int c;

        l2(EditTextPreference editTextPreference, EditText editText, int i2) {
            this.a = editTextPreference;
            this.b = editText;
            this.c = i2;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            w0 w0Var;
            int i3;
            this.a.setText(this.b.getText().toString());
            this.a.setSummary(this.b.getText().toString());
            if (this.b.getText().toString().length() > 0) {
                w0Var = w0.this;
                i3 = (1 << this.c) | w0Var.s1;
            } else {
                w0Var = w0.this;
                i3 = (~(1 << this.c)) & w0Var.s1;
            }
            w0Var.s1 = i3;
            w0.this.r1.setText(w0.this.s1 + "");
        }
    }

    class m implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ SharedPreferences b;

        m(EditTextPreference editTextPreference, SharedPreferences sharedPreferences) {
            this.a = editTextPreference;
            this.b = sharedPreferences;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                int i2 = Integer.parseInt((String) obj);
                if (i2 < 100) {
                    Toast.makeText(w0.this.getActivity(), "Минимум 100 мс", 1).show();
                    return true;
                }
                this.a.setSummary(i2 + "");
                this.b.edit().putString("secondPeriod", (String) obj).apply();
                return true;
            } catch (Exception unused) {
                this.a.setSummary("err");
                this.a.setText("err");
            }
        }
    }

    class m0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        m0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 21);
            return true;
        }
    }

    class m1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        m1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 15);
            return true;
        }
    }

    class m2 implements DialogInterface.OnClickListener {
        m2(w0 w0Var) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class n implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;
        final /* synthetic */ String[] b;

        n(ListPreference listPreference, String[] strArr) {
            this.a = listPreference;
            this.b = strArr;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            String str;
            w0.this.z0 = Integer.parseInt((String) obj);
            int i2 = w0.this.z0;
            if (i2 == 100) {
                this.a.setValueIndex(0);
                listPreference = this.a;
                str = this.b[0];
            } else {
                this.a.setValueIndex(i2);
                listPreference = this.a;
                str = this.b[w0.this.z0];
            }
            listPreference.setSummary(str);
            return false;
        }
    }

    class n0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        n0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 22);
            return true;
        }
    }

    class n1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ ColorPreference a;
        final /* synthetic */ CheckBoxPreference b;

        n1(w0 w0Var, ColorPreference colorPreference, CheckBoxPreference checkBoxPreference) {
            this.a = colorPreference;
            this.b = checkBoxPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(!this.b.isChecked());
            return true;
        }
    }

    class o implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        o(w0 w0Var, EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                Integer.parseInt((String) obj);
                this.a.setSummary((String) obj);
                return true;
            } catch (Exception unused) {
                this.a.setSummary("0");
                this.a.setText("0");
                return true;
            }
        }
    }

    class o0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        o0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 23);
            return true;
        }
    }

    class o1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        o1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 10);
            return true;
        }
    }

    class p implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        p(w0 w0Var, EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                if (Integer.parseInt((String) obj) < 0 || Integer.parseInt((String) obj) > 15) {
                    this.a.setSummary("0");
                    this.a.setText("0");
                } else {
                    this.a.setSummary((String) obj);
                }
                return true;
            } catch (Exception unused) {
                return true;
            }
        }
    }

    class p0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        p0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 24);
            return true;
        }
    }

    class p1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        p1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 11);
            return true;
        }
    }

    class q implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ CheckBoxPreference b;
        final /* synthetic */ EditTextPreference c;

        q(w0 w0Var, EditTextPreference editTextPreference, CheckBoxPreference checkBoxPreference, EditTextPreference editTextPreference2) {
            this.a = editTextPreference;
            this.b = checkBoxPreference;
            this.c = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(this.b.isChecked());
            this.c.setEnabled(this.b.isChecked());
            return true;
        }
    }

    class q0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        q0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 25);
            return true;
        }
    }

    class q1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        q1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 12);
            return true;
        }
    }

    class r implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        r(w0 w0Var, EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                Integer.parseInt((String) obj);
                this.a.setText((String) obj);
                this.a.setSummary((String) obj);
                return true;
            } catch (Exception unused) {
                this.a.setText("0");
                this.a.setSummary("0");
                return true;
            }
        }
    }

    class r0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ ColorPreference a;
        final /* synthetic */ CheckBoxPreference b;

        r0(w0 w0Var, ColorPreference colorPreference, CheckBoxPreference checkBoxPreference) {
            this.a = colorPreference;
            this.b = checkBoxPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(!this.b.isChecked());
            return true;
        }
    }

    class r1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        r1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 13);
            return true;
        }
    }

    class s implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        s(w0 w0Var, EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                if (Integer.parseInt((String) obj) <= 100 && Integer.parseInt((String) obj) > 0) {
                    this.a.setText((String) obj);
                    this.a.setSummary((String) obj);
                    return true;
                }
                this.a.setText("2");
                this.a.setSummary("2");
                return true;
            } catch (Exception unused) {
                this.a.setText("2");
                this.a.setSummary("2");
            }
        }
    }

    class s0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ CheckBoxPreference a;
        final /* synthetic */ EditTextPreference b;
        final /* synthetic */ EditTextPreference c;

        s0(w0 w0Var, CheckBoxPreference checkBoxPreference, EditTextPreference editTextPreference, EditTextPreference editTextPreference2) {
            this.a = checkBoxPreference;
            this.b = editTextPreference;
            this.c = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            if (this.a.isChecked()) {
                this.b.setEnabled(true);
                this.c.setEnabled(true);
            } else {
                this.b.setEnabled(false);
                this.c.setEnabled(false);
            }
            return true;
        }
    }

    class s1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        s1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 14);
            return true;
        }
    }

    class t implements Preference.OnPreferenceClickListener {
        final /* synthetic */ ListPreference a;
        final /* synthetic */ CheckBoxPreference b;
        final /* synthetic */ EditTextPreference c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditTextPreference f9150d;

        t(ListPreference listPreference, CheckBoxPreference checkBoxPreference, EditTextPreference editTextPreference, EditTextPreference editTextPreference2) {
            this.a = listPreference;
            this.b = checkBoxPreference;
            this.c = editTextPreference;
            this.f9150d = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(this.b.isChecked());
            this.c.setEnabled(this.b.isChecked());
            if (this.b.isChecked() && w0.this.I0.equals("ASCII")) {
                this.f9150d.setEnabled(true);
            } else {
                this.f9150d.setEnabled(false);
            }
            return true;
        }
    }

    class t0 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ CheckBoxPreference a;
        final /* synthetic */ EditTextPreference b;
        final /* synthetic */ EditTextPreference c;

        t0(w0 w0Var, CheckBoxPreference checkBoxPreference, EditTextPreference editTextPreference, EditTextPreference editTextPreference2) {
            this.a = checkBoxPreference;
            this.b = editTextPreference;
            this.c = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            int i2 = Integer.parseInt((String) obj);
            if (i2 == 0) {
                this.a.setEnabled(true);
                if (this.a.isChecked()) {
                    this.b.setEnabled(true);
                    this.c.setEnabled(true);
                }
            } else if (i2 == 1) {
                this.a.setChecked(false);
                this.a.setEnabled(false);
                this.b.setEnabled(false);
                this.c.setEnabled(false);
            }
            return true;
        }
    }

    class t1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        t1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 15);
            return true;
        }
    }

    class u implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;
        final /* synthetic */ EditTextPreference b;

        u(w0 w0Var, ListPreference listPreference, EditTextPreference editTextPreference) {
            this.a = listPreference;
            this.b = editTextPreference;
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            String str = (String) obj;
            this.a.setSummary(str);
            str.hashCode();
            switch (str) {
                case "INT":
                case "FLOAT":
                    this.b.setEnabled(false);
                    return true;
                case "ASCII":
                    this.b.setEnabled(true);
                    return true;
                default:
                    return true;
            }
        }
    }

    class u0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        class a implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;

            a(EditText editText) {
                this.a = editText;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                u0.this.a.setText(this.a.getText().toString());
                u0.this.a.setSummary(this.a.getText().toString());
            }
        }

        class b implements DialogInterface.OnClickListener {
            b(u0 u0Var) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        u0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(w0.this.getActivity());
            builder.setTitle(w0.this.getResources().getString(R.string.text));
            EditText editText = new EditText(w0.this.getActivity());
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(25)});
            editText.setText(this.a.getText().toString());
            editText.setSelection(editText.length());
            builder.setView(editText);
            builder.setPositiveButton("ОК", new a(editText));
            builder.setNegativeButton(w0.this.getResources().getString(R.string.dialog_cancel), new b(this));
            builder.show();
            return true;
        }
    }

    class u1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        u1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 16);
            return true;
        }
    }

    class v implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;

        v(w0 w0Var, ListPreference listPreference) {
            this.a = listPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            String str;
            int i2 = Integer.parseInt((String) obj);
            if (i2 != 1) {
                if (i2 == 2) {
                    listPreference = this.a;
                    str = "Discrete Inputs (2)";
                }
                return true;
            }
            listPreference = this.a;
            str = "Coils (1)";
            listPreference.setSummary(str);
            return true;
        }
    }

    class v0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        class a implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;

            a(EditText editText) {
                this.a = editText;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                v0.this.a.setText(this.a.getText().toString());
                v0.this.a.setSummary(this.a.getText().toString());
            }
        }

        class b implements DialogInterface.OnClickListener {
            b(v0 v0Var) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        v0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(w0.this.getActivity());
            builder.setTitle(w0.this.getResources().getString(R.string.size_text));
            EditText editText = new EditText(w0.this.getActivity());
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
            editText.setText(this.a.getText().toString());
            editText.setSelection(editText.length());
            builder.setView(editText);
            builder.setPositiveButton("ОК", new a(editText));
            builder.setNegativeButton(w0.this.getResources().getString(R.string.dialog_cancel), new b(this));
            builder.show();
            return true;
        }
    }

    class v1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        v1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("audio/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("audio/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 17);
            return true;
        }
    }

    class w implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        w(w0 w0Var, EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                Integer.parseInt((String) obj);
                this.a.setSummary((String) obj);
                return true;
            } catch (Exception unused) {
                this.a.setSummary("0");
                this.a.setText("0");
                return true;
            }
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.w0$w0, reason: collision with other inner class name */
    class C0295w0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        C0295w0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 0);
            return true;
        }
    }

    class w1 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ ListPreference a;
        final /* synthetic */ String[] b;

        w1(ListPreference listPreference, String[] strArr) {
            this.a = listPreference;
            this.b = strArr;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            String str;
            w0.this.y1 = Integer.parseInt((String) obj);
            int i2 = w0.this.y1;
            if (i2 == 100) {
                this.a.setValueIndex(0);
                listPreference = this.a;
                str = this.b[0];
            } else {
                this.a.setValueIndex(i2);
                listPreference = this.a;
                str = this.b[w0.this.y1];
            }
            listPreference.setSummary(str);
            return false;
        }
    }

    class x implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        x(w0 w0Var, EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                if (Integer.parseInt((String) obj) < 0 || Integer.parseInt((String) obj) > 15) {
                    this.a.setSummary("0");
                    this.a.setText("0");
                } else {
                    this.a.setSummary((String) obj);
                }
                return true;
            } catch (Exception unused) {
                return true;
            }
        }
    }

    class x0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        x0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 1);
            return true;
        }
    }

    class x1 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;

        x1(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            try {
                int i2 = Integer.parseInt(obj + "");
                if (i2 <= 0 || i2 >= ru.himik.nightscream.kascada.q.d.b.E) {
                    Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.error_input_num_sys_reg), 1).show();
                } else {
                    this.a.setSummary(i2 + "");
                    this.a.setText(i2 + "");
                }
                return false;
            } catch (Exception unused) {
                Toast.makeText(w0.this.getActivity(), w0.this.getResources().getString(R.string.unexcepted_error), 1).show();
                return false;
            }
        }
    }

    class y implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ CheckBoxPreference b;
        final /* synthetic */ EditTextPreference c;

        y(w0 w0Var, EditTextPreference editTextPreference, CheckBoxPreference checkBoxPreference, EditTextPreference editTextPreference2) {
            this.a = editTextPreference;
            this.b = checkBoxPreference;
            this.c = editTextPreference2;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(this.b.isChecked());
            this.c.setEnabled(this.b.isChecked());
            return true;
        }
    }

    class y0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        y0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 2);
            return true;
        }
    }

    class y1 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ CheckBoxPreference b;

        y1(w0 w0Var, EditTextPreference editTextPreference, CheckBoxPreference checkBoxPreference) {
            this.a = editTextPreference;
            this.b = checkBoxPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.setEnabled(!this.b.isChecked());
            return true;
        }
    }

    class z implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        z(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            this.a.getDialog().dismiss();
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            Intent intentCreateChooser = Intent.createChooser(intent, w0.this.getResources().getString(R.string.choose_image));
            intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
            w0.this.startActivityForResult(intentCreateChooser, 1);
            return true;
        }
    }

    class z0 implements Preference.OnPreferenceClickListener {
        final /* synthetic */ EditTextPreference a;

        z0(EditTextPreference editTextPreference) {
            this.a = editTextPreference;
        }

        @Override // android.preference.Preference.OnPreferenceClickListener
        public boolean onPreferenceClick(Preference preference) {
            w0.this.Y(this.a, 3);
            return true;
        }
    }

    class z1 implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ EditTextPreference b;
        final /* synthetic */ ListPreference c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditTextPreference f9152d;

        z1(EditTextPreference editTextPreference, EditTextPreference editTextPreference2, ListPreference listPreference, EditTextPreference editTextPreference3) {
            this.a = editTextPreference;
            this.b = editTextPreference2;
            this.c = listPreference;
            this.f9152d = editTextPreference3;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            int i2 = Integer.parseInt((String) obj);
            if (i2 != 0) {
                if (i2 == 1) {
                    this.a.setEnabled(true);
                    this.b.setEnabled(true);
                    this.c.setEnabled(true);
                } else if (i2 == 2) {
                    this.f9152d.setEnabled(false);
                    this.a.setEnabled(false);
                    this.b.setEnabled(false);
                    this.c.setEnabled(false);
                    w0.this.w1 = 1;
                    this.f9152d.setSummary(w0.this.w1 + "");
                    this.f9152d.setText(w0.this.w1 + "");
                }
                return true;
            }
            this.a.setEnabled(false);
            this.b.setEnabled(false);
            this.c.setEnabled(false);
            this.f9152d.setEnabled(true);
            return true;
        }
    }

    static /* synthetic */ boolean A(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean B(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean C(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean D(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean E(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean F(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean G(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean H(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: I, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ boolean J(EditTextPreference editTextPreference, Preference preference, Object obj) {
        try {
            int i3 = Integer.parseInt(obj + "");
            if (i3 <= 0 || i3 >= ru.himik.nightscream.kascada.q.d.b.E) {
                Toast.makeText(getActivity(), getResources().getString(R.string.error_input_num_sys_reg), 1).show();
            } else {
                editTextPreference.setSummary(i3 + "");
                editTextPreference.setText(i3 + "");
            }
            return false;
        } catch (Exception unused) {
            Toast.makeText(getActivity(), getResources().getString(R.string.unexcepted_error), 1).show();
            return false;
        }
    }

    static /* synthetic */ boolean K(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean L(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean M(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean N(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean O(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean P(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: Q, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ boolean R(EditTextPreference editTextPreference, Preference preference) {
        editTextPreference.getDialog().dismiss();
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://myaccount.google.com/u/0/lesssecureapps?utm_source=google-account")));
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: S, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ boolean T(EditTextPreference editTextPreference, Preference preference, Object obj) {
        try {
            int i3 = Integer.parseInt(obj + "");
            if (i3 <= 0 || i3 >= ru.himik.nightscream.kascada.q.d.b.E) {
                Toast.makeText(getActivity(), getResources().getString(R.string.error_input_num_sys_reg), 1).show();
            } else {
                editTextPreference.setSummary(i3 + "");
                editTextPreference.setText(i3 + "");
            }
            return false;
        } catch (Exception unused) {
            Toast.makeText(getActivity(), getResources().getString(R.string.unexcepted_error), 1).show();
            return false;
        }
    }

    static /* synthetic */ boolean U(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean V(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean W(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean X(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean a(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean b(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean c(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean d(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean e(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean f(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean g(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean h(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean i(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean j(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean k(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean l(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean m(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean n(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean o(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean p(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean q(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean r(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean s(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean t(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean u(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean v(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean w(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean x(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setSummary(obj + "");
        editTextPreference.setText(obj + "");
        return false;
    }

    static /* synthetic */ boolean y(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    static /* synthetic */ boolean z(EditTextPreference editTextPreference, Preference preference, Object obj) {
        editTextPreference.setText(obj + "");
        editTextPreference.setSummary(obj + "");
        return false;
    }

    public void Y(EditTextPreference editTextPreference, int i3) {
        editTextPreference.getDialog().dismiss();
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getResources().getString(R.string.val));
        EditText editText = new EditText(getActivity());
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(40)});
        editText.setText(editTextPreference.getText().toString());
        editText.setSelection(editText.length());
        builder.setView(editText);
        builder.setPositiveButton("ОК", new l2(editTextPreference, editText, i3));
        builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new m2(this));
        builder.show();
    }

    public void Z(String str) {
        this.L0 = str;
        EditTextPreference editTextPreference = (EditTextPreference) findPreference("EditGifPath");
        editTextPreference.setText(str);
        editTextPreference.setSummary(str);
    }

    public void a0(String str, int i3) {
        String str2;
        switch (i3) {
            case 0:
                str2 = "EditPathPicture_0";
                break;
            case 1:
                str2 = "EditPathPicture_1";
                break;
            case 2:
                str2 = "EditPathPicture_2";
                break;
            case 3:
                str2 = "EditPathPicture_3";
                break;
            case 4:
                str2 = "EditPathPicture_4";
                break;
            case 5:
                str2 = "EditPathPicture_5";
                break;
            case 6:
                str2 = "EditPathPicture_6";
                break;
            case 7:
                str2 = "EditPathPicture_7";
                break;
            case 8:
                str2 = "EditPathPicture_8";
                break;
            case 9:
                str2 = "EditPathPicture_9";
                break;
            case 10:
                str2 = "EditPathPicture_10";
                break;
            case 11:
                str2 = "EditPathPicture_11";
                break;
            case 12:
                str2 = "EditPathPicture_12";
                break;
            case 13:
                str2 = "EditPathPicture_13";
                break;
            case 14:
                str2 = "EditPathPicture_14";
                break;
            case 15:
                str2 = "EditPathPicture_15";
                break;
            default:
                return;
        }
        EditTextPreference editTextPreference = (EditTextPreference) findPreference(str2);
        editTextPreference.setText(str);
        editTextPreference.setSummary(str);
    }

    @Override // android.preference.PreferenceFragment, android.app.Fragment
    public void onActivityResult(int i3, int i4, Intent intent) {
        String strF;
        int i5;
        String str;
        super.onActivityResult(i3, i4, intent);
        getActivity();
        if (i4 == -1) {
            switch (i3) {
                case 1:
                    Z(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 2:
                    try {
                        a0(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()), 0);
                    } catch (Exception e3) {
                        e3.printStackTrace();
                        return;
                    }
                    break;
                case 3:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 1;
                    a0(strF, i5);
                    break;
                case 4:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 2;
                    a0(strF, i5);
                    break;
                case 5:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 3;
                    a0(strF, i5);
                    break;
                case 6:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 4;
                    a0(strF, i5);
                    break;
                case 7:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 5;
                    a0(strF, i5);
                    break;
                case 8:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 6;
                    a0(strF, i5);
                    break;
                case 9:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 7;
                    a0(strF, i5);
                    break;
                case 10:
                    str = "EditPathSound_0";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 11:
                    str = "EditPathSound_1";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 12:
                    str = "EditPathSound_2";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 13:
                    str = "EditPathSound_3";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 14:
                    str = "EditPathSound_4";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 15:
                    str = "EditPathSound_5";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 16:
                    str = "EditPathSound_6";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 17:
                    str = "EditPathSound_7";
                    ((EditTextPreference) findPreference(str)).setText(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    ((EditTextPreference) findPreference(str)).setSummary(ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData()));
                    break;
                case 18:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 8;
                    a0(strF, i5);
                    break;
                case 19:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 9;
                    a0(strF, i5);
                    break;
                case 20:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 10;
                    a0(strF, i5);
                    break;
                case 21:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 11;
                    a0(strF, i5);
                    break;
                case 22:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 12;
                    a0(strF, i5);
                    break;
                case 23:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 13;
                    a0(strF, i5);
                    break;
                case 24:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 14;
                    a0(strF, i5);
                    break;
                case 25:
                    strF = ru.himik.nightscream.kascada.Utils.q.f(getActivity(), intent.getData());
                    i5 = 15;
                    a0(strF, i5);
                    break;
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:231:0x1877  */
    /* JADX WARN: Code duplicated, block: B:234:0x187b  */
    /* JADX WARN: Code duplicated, block: B:235:0x1891  */
    @Override // android.preference.PreferenceFragment, android.app.Fragment
    public void onCreate(Bundle bundle) {
        CheckBoxPreference checkBoxPreference;
        Preference.OnPreferenceClickListener r0Var;
        Resources resources;
        int i3;
        String str;
        EditTextPreference editTextPreference;
        StringBuilder sb;
        EditTextPreference editTextPreference2;
        StringBuilder sb2;
        Resources resources2;
        int i4;
        ListPreference listPreference;
        int i5;
        SharedPreferences.Editor editorPutInt;
        Resources resources3;
        int i6;
        int i7;
        int i8;
        String str2;
        final EditTextPreference editTextPreference3;
        Preference.OnPreferenceClickListener zVar;
        int i9;
        boolean z2;
        int i10;
        String str3;
        String str4;
        final EditTextPreference editTextPreference4;
        Preference.OnPreferenceChangeListener onPreferenceChangeListener;
        super.onCreate(bundle);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        switch (this.G) {
            case 1:
                addPreferencesFromResource(R.xml.base_preference_switch);
                ((CheckBoxPreference) findPreference("checkVisible")).setChecked(this.J);
                break;
            case 2:
                addPreferencesFromResource(R.xml.base_preference);
                ((EditTextPreference) findPreference("base_pref_edit_text")).setText(this.F);
                CheckBoxPreference checkBoxPreference2 = (CheckBoxPreference) findPreference("AutoResizeText");
                checkBoxPreference2.setChecked(this.C1);
                EditTextPreference editTextPreference5 = (EditTextPreference) findPreference("base_pref_edit_height_text");
                editTextPreference5.setText(String.valueOf(this.D));
                editTextPreference5.setEnabled(!this.C1);
                checkBoxPreference2.setOnPreferenceClickListener(new g0(this, editTextPreference5, checkBoxPreference2));
                ColorPreference colorPreference = (ColorPreference) findPreference("colorBackground");
                checkBoxPreference = (CheckBoxPreference) findPreference("enableFrameLabel");
                checkBoxPreference.setChecked(this.D1);
                colorPreference.setEnabled(!checkBoxPreference.isChecked());
                r0Var = new r0(this, colorPreference, checkBoxPreference);
                checkBoxPreference.setOnPreferenceClickListener(r0Var);
                break;
            case 3:
            case 9:
            case 23:
            default:
                break;
            case 4:
                addPreferencesFromResource(R.xml.base_preference_register);
                ListPreference listPreference2 = (ListPreference) findPreference("listDigit");
                listPreference2.setValueIndex(this.H - 1);
                ListPreference listPreference3 = (ListPreference) findPreference("listDivisor");
                listPreference3.setValueIndex(this.I);
                listPreference2.setEnabled(this.M < 3);
                listPreference3.setEnabled(this.M < 3);
                ListPreference listPreference4 = (ListPreference) findPreference("listTypeRegister");
                listPreference4.setValueIndex(this.M);
                int i11 = this.M;
                if (i11 == 0) {
                    resources = getResources();
                    i3 = R.string.int_signed;
                } else if (i11 == 1) {
                    resources = getResources();
                    i3 = R.string.int_unsigned;
                } else if (i11 != 2) {
                    if (i11 == 3) {
                        resources = getResources();
                        i3 = R.string.int32_;
                    }
                    listPreference4.setOnPreferenceChangeListener(new c1(listPreference4, listPreference2, listPreference3));
                    ((CheckBoxPreference) findPreference("checkFontChangeRegister")).setChecked(this.N);
                    ColorPreference colorPreference2 = (ColorPreference) findPreference("colorBackground");
                    checkBoxPreference = (CheckBoxPreference) findPreference("enableFrameRegister");
                    checkBoxPreference.setChecked(this.O);
                    colorPreference2.setEnabled(!checkBoxPreference.isChecked());
                    r0Var = new n1(this, colorPreference2, checkBoxPreference);
                    checkBoxPreference.setOnPreferenceClickListener(r0Var);
                } else {
                    resources = getResources();
                    i3 = R.string.float_;
                }
                listPreference4.setSummary(resources.getString(i3));
                listPreference4.setOnPreferenceChangeListener(new c1(listPreference4, listPreference2, listPreference3));
                ((CheckBoxPreference) findPreference("checkFontChangeRegister")).setChecked(this.N);
                ColorPreference colorPreference3 = (ColorPreference) findPreference("colorBackground");
                checkBoxPreference = (CheckBoxPreference) findPreference("enableFrameRegister");
                checkBoxPreference.setChecked(this.O);
                colorPreference3.setEnabled(!checkBoxPreference.isChecked());
                r0Var = new n1(this, colorPreference3, checkBoxPreference);
                checkBoxPreference.setOnPreferenceClickListener(r0Var);
                break;
            case 5:
                addPreferencesFromResource(R.xml.base_preference_lamp);
                ListPreference listPreference5 = (ListPreference) findPreference("listTypeLamp");
                listPreference5.setValueIndex(this.z1 - 1);
                int i12 = this.z1;
                if (i12 != 1) {
                    str = i12 == 2 ? "Discrete Inputs (2)" : "Coils (1)";
                    listPreference5.setOnPreferenceChangeListener(new v(this, listPreference5));
                    break;
                }
                listPreference5.setSummary(str);
                listPreference5.setOnPreferenceChangeListener(new v(this, listPreference5));
                break;
            case 6:
                addPreferencesFromResource(R.xml.base_preference_button);
                ((EditTextPreference) findPreference("base_pref_edit_text")).setText(this.F);
                EditTextPreference editTextPreference6 = (EditTextPreference) findPreference("base_pref_edit_height_text");
                editTextPreference6.setText(String.valueOf(this.D));
                editTextPreference6.setEnabled(!this.C1);
                ((CheckBoxPreference) findPreference("checkVisible")).setChecked(this.J);
                ((ListPreference) findPreference("list_button_mode")).setValueIndex(this.P);
                checkBoxPreference = (CheckBoxPreference) findPreference("AutoResizeText");
                checkBoxPreference.setChecked(this.C1);
                r0Var = new k(this, editTextPreference6, checkBoxPreference);
                checkBoxPreference.setOnPreferenceClickListener(r0Var);
                break;
            case 7:
                addPreferencesFromResource(R.xml.base_preference_dyn_text);
                ((ListPreference) findPreference("listTypeCommandDynText")).setValueIndex(this.E);
                ((EditTextPreference) findPreference("base_pref_edit_text0")).setText(this.a);
                ((EditTextPreference) findPreference("base_pref_edit_text1")).setText(this.b);
                ((EditTextPreference) findPreference("base_pref_edit_text2")).setText(this.c);
                ((EditTextPreference) findPreference("base_pref_edit_text3")).setText(this.f9124d);
                ((EditTextPreference) findPreference("base_pref_edit_text4")).setText(this.f9125e);
                ((EditTextPreference) findPreference("base_pref_edit_text5")).setText(this.f9126f);
                ((EditTextPreference) findPreference("base_pref_edit_text6")).setText(this.f9127g);
                ((EditTextPreference) findPreference("base_pref_edit_text7")).setText(this.f9128h);
                ((EditTextPreference) findPreference("base_pref_edit_text8")).setText(this.f9129i);
                ((EditTextPreference) findPreference("base_pref_edit_text9")).setText(this.f9130j);
                ((EditTextPreference) findPreference("base_pref_edit_text10")).setText(this.f9131k);
                ((EditTextPreference) findPreference("base_pref_edit_text11")).setText(this.f9132l);
                ((EditTextPreference) findPreference("base_pref_edit_text12")).setText(this.f9133m);
                ((EditTextPreference) findPreference("base_pref_edit_text13")).setText(this.f9134n);
                ((EditTextPreference) findPreference("base_pref_edit_text14")).setText(this.o);
                ((EditTextPreference) findPreference("base_pref_edit_text15")).setText(this.C);
                CheckBoxPreference checkBoxPreference3 = (CheckBoxPreference) findPreference("AutoResizeText");
                checkBoxPreference3.setChecked(this.C1);
                EditTextPreference editTextPreference7 = (EditTextPreference) findPreference("base_pref_edit_height_text");
                editTextPreference7.setText(String.valueOf(this.D));
                editTextPreference7.setEnabled(!this.C1);
                checkBoxPreference3.setOnPreferenceClickListener(new y1(this, editTextPreference7, checkBoxPreference3));
                ColorPreference colorPreference4 = (ColorPreference) findPreference("colorBackground0");
                ColorPreference colorPreference5 = (ColorPreference) findPreference("colorBackground1");
                ColorPreference colorPreference6 = (ColorPreference) findPreference("colorBackground2");
                ColorPreference colorPreference7 = (ColorPreference) findPreference("colorBackground3");
                ColorPreference colorPreference8 = (ColorPreference) findPreference("colorBackground4");
                ColorPreference colorPreference9 = (ColorPreference) findPreference("colorBackground5");
                ColorPreference colorPreference10 = (ColorPreference) findPreference("colorBackground6");
                ColorPreference colorPreference11 = (ColorPreference) findPreference("colorBackground7");
                ColorPreference colorPreference12 = (ColorPreference) findPreference("colorBackground8");
                ColorPreference colorPreference13 = (ColorPreference) findPreference("colorBackground9");
                ColorPreference colorPreference14 = (ColorPreference) findPreference("colorBackground10");
                ColorPreference colorPreference15 = (ColorPreference) findPreference("colorBackground11");
                ColorPreference colorPreference16 = (ColorPreference) findPreference("colorBackground12");
                ColorPreference colorPreference17 = (ColorPreference) findPreference("colorBackground13");
                ColorPreference colorPreference18 = (ColorPreference) findPreference("colorBackground14");
                ColorPreference colorPreference19 = (ColorPreference) findPreference("colorBackground15");
                CheckBoxPreference checkBoxPreference4 = (CheckBoxPreference) findPreference("enableFrameDynText");
                checkBoxPreference4.setChecked(this.l1);
                colorPreference4.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference5.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference6.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference7.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference8.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference9.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference10.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference11.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference12.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference13.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference14.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference15.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference16.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference17.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference18.setEnabled(!checkBoxPreference4.isChecked());
                colorPreference19.setEnabled(!checkBoxPreference4.isChecked());
                checkBoxPreference4.setOnPreferenceClickListener(new j2(this, colorPreference4, checkBoxPreference4, colorPreference5, colorPreference6, colorPreference7, colorPreference8, colorPreference9, colorPreference10, colorPreference11, colorPreference12, colorPreference13, colorPreference14, colorPreference15, colorPreference16, colorPreference17, colorPreference18, colorPreference19));
                break;
            case 8:
                addPreferencesFromResource(R.xml.base_preference_edit_number);
                ListPreference listPreference6 = (ListPreference) findPreference("listCountNumAfterPointEditNumber");
                listPreference6.setValueIndex(this.R);
                EditTextPreference editTextPreference8 = (EditTextPreference) findPreference("min");
                this.n1 = editTextPreference8;
                if (this.M == 0) {
                    editTextPreference8.setText(String.valueOf(Math.round(this.K)));
                    editTextPreference = this.n1;
                    sb = new StringBuilder();
                    sb.append(getResources().getString(R.string.base_min));
                    sb.append(" = ");
                    sb.append((int) this.K);
                } else {
                    editTextPreference8.setText(String.valueOf(this.K));
                    editTextPreference = this.n1;
                    sb = new StringBuilder();
                    sb.append(getResources().getString(R.string.base_min));
                    sb.append(" = ");
                    sb.append(this.K);
                }
                editTextPreference.setSummary(sb.toString());
                this.n1.setOnPreferenceClickListener(new k2());
                EditTextPreference editTextPreference9 = (EditTextPreference) findPreference("max");
                this.m1 = editTextPreference9;
                if (this.M == 0) {
                    editTextPreference9.setText(String.valueOf(Math.round(this.L)));
                    editTextPreference2 = this.m1;
                    sb2 = new StringBuilder();
                    sb2.append(getResources().getString(R.string.base_max));
                    sb2.append(" = ");
                    sb2.append((int) this.L);
                } else {
                    editTextPreference9.setText(String.valueOf(this.L));
                    editTextPreference2 = this.m1;
                    sb2 = new StringBuilder();
                    sb2.append(getResources().getString(R.string.base_max));
                    sb2.append(" = ");
                    sb2.append(this.L);
                }
                editTextPreference2.setSummary(sb2.toString());
                this.m1.setOnPreferenceClickListener(new a());
                EditTextPreference editTextPreference10 = (EditTextPreference) findPreference("edit_number_pass");
                editTextPreference10.setText(String.valueOf(this.o1));
                editTextPreference10.setSummary(this.o1);
                editTextPreference10.setOnPreferenceClickListener(new b(editTextPreference10));
                ListPreference listPreference7 = (ListPreference) findPreference("listTypeIntEditNumber");
                listPreference7.setValueIndex(this.Q);
                int i13 = this.Q;
                if (i13 != 0) {
                    if (i13 == 1) {
                        resources2 = getResources();
                        i4 = R.string.int_signed;
                    }
                    listPreference7.setOnPreferenceChangeListener(new c(listPreference7));
                    listPreference = (ListPreference) findPreference("listTypeEditNumber");
                    listPreference.setValueIndex(this.M);
                    i5 = this.M;
                    if (i5 != 0) {
                        listPreference.setSummary(getResources().getString(R.string.int_));
                        listPreference7.setEnabled(true);
                        listPreference6.setEnabled(false);
                    } else if (i5 == 1) {
                        listPreference.setSummary(getResources().getString(R.string.float_));
                        listPreference7.setEnabled(false);
                        listPreference6.setEnabled(true);
                    }
                    listPreference.setOnPreferenceChangeListener(new d(listPreference, listPreference7, listPreference6));
                    ((CheckBoxPreference) findPreference("checkFontChangeEditNumber")).setChecked(this.N);
                    ColorPreference colorPreference20 = (ColorPreference) findPreference("colorBackground");
                    CheckBoxPreference checkBoxPreference5 = (CheckBoxPreference) findPreference("enableFrameEditNumber");
                    checkBoxPreference5.setChecked(this.S);
                    colorPreference20.setEnabled(!checkBoxPreference5.isChecked());
                    checkBoxPreference5.setOnPreferenceClickListener(new e(this, colorPreference20, checkBoxPreference5));
                } else {
                    resources2 = getResources();
                    i4 = R.string.int_unsigned;
                }
                listPreference7.setSummary(resources2.getString(i4));
                listPreference7.setOnPreferenceChangeListener(new c(listPreference7));
                listPreference = (ListPreference) findPreference("listTypeEditNumber");
                listPreference.setValueIndex(this.M);
                i5 = this.M;
                if (i5 != 0) {
                    listPreference.setSummary(getResources().getString(R.string.int_));
                    listPreference7.setEnabled(true);
                    listPreference6.setEnabled(false);
                } else if (i5 == 1) {
                    listPreference.setSummary(getResources().getString(R.string.float_));
                    listPreference7.setEnabled(false);
                    listPreference6.setEnabled(true);
                }
                listPreference.setOnPreferenceChangeListener(new d(listPreference, listPreference7, listPreference6));
                ((CheckBoxPreference) findPreference("checkFontChangeEditNumber")).setChecked(this.N);
                ColorPreference colorPreference21 = (ColorPreference) findPreference("colorBackground");
                CheckBoxPreference checkBoxPreference6 = (CheckBoxPreference) findPreference("enableFrameEditNumber");
                checkBoxPreference6.setChecked(this.S);
                colorPreference21.setEnabled(!checkBoxPreference6.isChecked());
                checkBoxPreference6.setOnPreferenceClickListener(new e(this, colorPreference21, checkBoxPreference6));
                break;
            case 10:
                addPreferencesFromResource(R.xml.preference_sms);
                ((EditTextPreference) findPreference("pref_edit_sms_phone")).setText(this.T);
                ((EditTextPreference) findPreference("pref_edit_sms_message")).setText(this.U);
                CheckBoxPreference checkBoxPreference7 = (CheckBoxPreference) getPreferenceManager().findPreference("chOption");
                checkBoxPreference7.setChecked(this.V);
                EditTextPreference editTextPreference11 = (EditTextPreference) findPreference("optionRegister");
                editTextPreference11.setText(this.W + "");
                EditTextPreference editTextPreference12 = (EditTextPreference) findPreference("optionCountRegister");
                editTextPreference12.setText(this.X + "");
                boolean z3 = this.V;
                editTextPreference11.setEnabled(z3);
                editTextPreference12.setEnabled(z3);
                checkBoxPreference7.setOnPreferenceClickListener(new f(this, checkBoxPreference7, editTextPreference11, editTextPreference12));
                break;
            case 11:
                addPreferencesFromResource(R.xml.preference_line_level);
                EditTextPreference editTextPreference13 = (EditTextPreference) findPreference("editSizeText");
                editTextPreference13.setText(this.D + "");
                ColorPreference colorPreference22 = (ColorPreference) findPreference("colorText");
                CheckBoxPreference checkBoxPreference8 = (CheckBoxPreference) getPreferenceManager().findPreference("chShowText");
                checkBoxPreference8.setChecked(this.Y);
                boolean z4 = this.Y;
                colorPreference22.setEnabled(z4);
                editTextPreference13.setEnabled(z4);
                checkBoxPreference8.setOnPreferenceClickListener(new g(this, checkBoxPreference8, colorPreference22, editTextPreference13));
                ((EditTextPreference) findPreference("lineLevelEditMin")).setText(this.a0 + "");
                ((EditTextPreference) findPreference("lineLevelEditMax")).setText(this.b0 + "");
                ((CheckBoxPreference) getPreferenceManager().findPreference("chShowScale")).setChecked(this.Z);
                break;
            case 12:
                addPreferencesFromResource(R.xml.preference_circle_gauge);
                EditTextPreference editTextPreference14 = (EditTextPreference) findPreference("gauge_sizeText");
                editTextPreference14.setText(this.D + "");
                ColorPreference colorPreference23 = (ColorPreference) findPreference("gauge_textColor");
                CheckBoxPreference checkBoxPreference9 = (CheckBoxPreference) getPreferenceManager().findPreference("gauge_showText");
                checkBoxPreference9.setChecked(this.Y);
                boolean z5 = this.Y;
                editTextPreference14.setEnabled(z5);
                colorPreference23.setEnabled(z5);
                checkBoxPreference9.setOnPreferenceClickListener(new h(this, checkBoxPreference9, editTextPreference14, colorPreference23));
                ((EditTextPreference) findPreference("max_gauge")).setText(this.e0 + "");
                EditTextPreference editTextPreference15 = (EditTextPreference) findPreference("range_gauge");
                editTextPreference15.setSummary(getResources().getString(R.string.green_) + ": 0-" + this.c0 + " " + getResources().getString(R.string.yellow_) + " : " + this.c0 + "-" + this.d0 + " " + getResources().getString(R.string.red_) + " : " + this.d0 + "-" + this.e0);
                editTextPreference15.setOnPreferenceClickListener(new i(editTextPreference15));
                SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(getActivity());
                defaultSharedPreferences2.edit().putInt("firstPoint", this.c0).apply();
                editorPutInt = defaultSharedPreferences2.edit().putInt("secondPoint", this.d0);
                editorPutInt.apply();
                break;
            case 13:
                addPreferencesFromResource(R.xml.preference_seek_bar);
                ((EditTextPreference) findPreference("seekBarEditMax")).setText(this.A1 + "");
                break;
            case 14:
                addPreferencesFromResource(R.xml.preference_graph);
                ((ListPreference) findPreference("graphCountChannel")).setValueIndex(this.t0 - 1);
                final EditTextPreference editTextPreference16 = (EditTextPreference) findPreference("graphNameSeries1");
                editTextPreference16.setText(this.p0);
                editTextPreference16.setSummary(this.p0);
                editTextPreference16.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.v
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.a(editTextPreference16, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference17 = (EditTextPreference) findPreference("graphNameSeries2");
                editTextPreference17.setText(this.q0);
                editTextPreference17.setSummary(this.q0);
                editTextPreference17.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.r
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.b(editTextPreference17, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference18 = (EditTextPreference) findPreference("graphNameSeries3");
                editTextPreference18.setText(this.r0);
                editTextPreference18.setSummary(this.r0);
                editTextPreference18.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.b
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.m(editTextPreference18, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference19 = (EditTextPreference) findPreference("graphNameSeries4");
                editTextPreference19.setText(this.s0);
                editTextPreference19.setSummary(this.s0);
                editTextPreference19.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.s0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.x(editTextPreference19, preference, obj);
                    }
                });
                ListPreference listPreference8 = (ListPreference) findPreference("listTypeGraph");
                listPreference8.setValueIndex(this.u0);
                int i14 = this.u0;
                if (i14 == 0) {
                    resources3 = getResources();
                    i6 = R.string.int_signed;
                } else if (i14 != 1) {
                    if (i14 == 2) {
                        resources3 = getResources();
                        i6 = R.string.float_;
                    }
                    listPreference8.setOnPreferenceChangeListener(new j(listPreference8));
                    EditTextPreference editTextPreference20 = (EditTextPreference) findPreference("EditGraphCountPointPref");
                    editTextPreference20.setSummary(this.o0 + "");
                    editTextPreference20.setOnPreferenceClickListener(new l(editTextPreference20, defaultSharedPreferences));
                    EditTextPreference editTextPreference21 = (EditTextPreference) findPreference("EditGraphPeriodPref");
                    editTextPreference21.setSummary(this.n0 + "");
                    editTextPreference21.setOnPreferenceChangeListener(new m(editTextPreference21, defaultSharedPreferences));
                    defaultSharedPreferences.edit().putString("graphCountPoint", this.o0 + "").apply();
                    editorPutInt = defaultSharedPreferences.edit().putString("secondPeriod", this.n0 + "");
                    editorPutInt.apply();
                } else {
                    resources3 = getResources();
                    i6 = R.string.int_unsigned;
                }
                listPreference8.setSummary(resources3.getString(i6));
                listPreference8.setOnPreferenceChangeListener(new j(listPreference8));
                EditTextPreference editTextPreference22 = (EditTextPreference) findPreference("EditGraphCountPointPref");
                editTextPreference22.setSummary(this.o0 + "");
                editTextPreference22.setOnPreferenceClickListener(new l(editTextPreference22, defaultSharedPreferences));
                EditTextPreference editTextPreference23 = (EditTextPreference) findPreference("EditGraphPeriodPref");
                editTextPreference23.setSummary(this.n0 + "");
                editTextPreference23.setOnPreferenceChangeListener(new m(editTextPreference23, defaultSharedPreferences));
                defaultSharedPreferences.edit().putString("graphCountPoint", this.o0 + "").apply();
                editorPutInt = defaultSharedPreferences.edit().putString("secondPeriod", this.n0 + "");
                editorPutInt.apply();
                break;
            case 15:
                addPreferencesFromResource(R.xml.preference_archive);
                ((EditTextPreference) findPreference("ArchiveFileName")).setText(this.v0);
                ListPreference listPreference9 = (ListPreference) findPreference("listArchiveConnections");
                try {
                    JSONObject jSONObject = new JSONObject(this.A0);
                    if (this.z0 == -1) {
                        i8 = 1;
                        this.z0 = 1;
                    } else {
                        i8 = 1;
                    }
                    int i15 = jSONObject.getInt("countActiveDevice");
                    if (i15 < i8 || i15 > 16) {
                        i15 = 1;
                    }
                    int i16 = i15 + 1;
                    String[] strArr = new String[i16];
                    String[] strArr2 = new String[17];
                    String[] strArr3 = new String[i16];
                    for (int i17 = 0; i17 < 17; i17++) {
                        strArr2[i17] = jSONObject.getString("dev" + i17 + "Name");
                    }
                    for (int i18 = 0; i18 < i16; i18++) {
                        strArr[i18] = jSONObject.getString("dev" + i18 + "Name");
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(i18);
                        sb3.append("");
                        strArr3[i18] = sb3.toString();
                    }
                    listPreference9.setEntries(strArr);
                    listPreference9.setEntryValues(strArr3);
                    int i19 = this.z0;
                    if (i19 == 100) {
                        listPreference9.setValueIndex(0);
                        str2 = strArr[0];
                    } else if (i19 > i15) {
                        str2 = strArr2[i19];
                    } else {
                        listPreference9.setValueIndex(i19);
                        str2 = strArr[this.z0];
                    }
                    listPreference9.setSummary(str2);
                    listPreference9.setOnPreferenceChangeListener(new n(listPreference9, strArr));
                } catch (Exception unused) {
                    Toast.makeText(getActivity(), getResources().getString(R.string.error_open_list_device_in_archive), 1).show();
                }
                ListPreference listPreference10 = (ListPreference) findPreference("ArchiveType");
                if (this.w0.equals("FLOAT")) {
                    listPreference10.setValueIndex(0);
                    i7 = 1;
                } else {
                    i7 = 1;
                    listPreference10.setValueIndex(1);
                }
                ((ListPreference) findPreference("ArchiveCountChannel")).setValueIndex(this.x0 - i7);
                ((EditTextPreference) findPreference("ArchiveRegister")).setText(this.y0 + "");
                EditTextPreference editTextPreference24 = (EditTextPreference) findPreference("ArchiveRegisterReset");
                editTextPreference24.setText(this.B0 + "");
                editTextPreference24.setSummary(this.B0 + "");
                editTextPreference24.setOnPreferenceChangeListener(new o(this, editTextPreference24));
                EditTextPreference editTextPreference25 = (EditTextPreference) findPreference("ArchiveBitReset");
                editTextPreference25.setText(this.D0 + "");
                editTextPreference25.setSummary(this.D0 + "");
                editTextPreference25.setOnPreferenceChangeListener(new p(this, editTextPreference25));
                CheckBoxPreference checkBoxPreference10 = (CheckBoxPreference) findPreference("ArchiveIsReset");
                checkBoxPreference10.setChecked(this.F0);
                editTextPreference24.setEnabled(checkBoxPreference10.isChecked());
                editTextPreference25.setEnabled(checkBoxPreference10.isChecked());
                checkBoxPreference10.setOnPreferenceClickListener(new q(this, editTextPreference24, checkBoxPreference10, editTextPreference25));
                CheckBoxPreference checkBoxPreference11 = (CheckBoxPreference) findPreference("ArchiveOptionChannel");
                ListPreference listPreference11 = (ListPreference) findPreference("ArchiveTypeOptionChannel");
                EditTextPreference editTextPreference26 = (EditTextPreference) findPreference("ArchiveRegisterOptionChannel");
                EditTextPreference editTextPreference27 = (EditTextPreference) findPreference("ArchiveLengthOptionChannel");
                checkBoxPreference11.setChecked(this.H0);
                if (this.I0.equals("ASCII")) {
                    listPreference11.setValueIndex(0);
                    listPreference11.setSummary("ASCII");
                }
                if (this.I0.equals("FLOAT")) {
                    listPreference11.setValueIndex(1);
                    listPreference11.setSummary("FLOAT");
                }
                if (this.I0.equals("INT")) {
                    listPreference11.setValueIndex(2);
                    listPreference11.setSummary("INT");
                }
                editTextPreference26.setText(this.J0 + "");
                editTextPreference26.setSummary(this.J0 + "");
                editTextPreference26.setOnPreferenceChangeListener(new r(this, editTextPreference26));
                editTextPreference27.setText(this.K0 + "");
                editTextPreference27.setSummary(this.K0 + "");
                editTextPreference27.setOnPreferenceChangeListener(new s(this, editTextPreference27));
                listPreference11.setEnabled(checkBoxPreference11.isChecked());
                editTextPreference26.setEnabled(checkBoxPreference11.isChecked());
                editTextPreference27.setEnabled(checkBoxPreference11.isChecked() && this.I0.equals("ASCII"));
                checkBoxPreference11.setOnPreferenceClickListener(new t(listPreference11, checkBoxPreference11, editTextPreference26, editTextPreference27));
                listPreference11.setOnPreferenceChangeListener(new u(this, listPreference11, editTextPreference27));
                EditTextPreference editTextPreference28 = (EditTextPreference) findPreference("ArchiveRegisterSendToCloudArchive");
                editTextPreference28.setText(this.C0 + "");
                editTextPreference28.setSummary(this.C0 + "");
                editTextPreference28.setOnPreferenceChangeListener(new w(this, editTextPreference28));
                EditTextPreference editTextPreference29 = (EditTextPreference) findPreference("ArchiveBitSendToCloudArchive");
                editTextPreference29.setText(this.E0 + "");
                editTextPreference29.setSummary(this.E0 + "");
                editTextPreference29.setOnPreferenceChangeListener(new x(this, editTextPreference29));
                CheckBoxPreference checkBoxPreference12 = (CheckBoxPreference) findPreference("archiveSendToCloudArchive");
                checkBoxPreference12.setChecked(this.G0);
                editTextPreference28.setEnabled(checkBoxPreference12.isChecked());
                editTextPreference29.setEnabled(checkBoxPreference12.isChecked());
                checkBoxPreference12.setOnPreferenceClickListener(new y(this, editTextPreference28, checkBoxPreference12, editTextPreference29));
                break;
            case 16:
                addPreferencesFromResource(R.xml.preference_gif);
                editTextPreference3 = (EditTextPreference) findPreference("EditGifPath");
                editTextPreference3.setText(this.L0);
                editTextPreference3.setSummary(this.L0);
                zVar = new z(editTextPreference3);
                editTextPreference3.setOnPreferenceClickListener(zVar);
                break;
            case 17:
                addPreferencesFromResource(R.xml.preference_dyn_pictures);
                ((ListPreference) findPreference("listTypeCommandDynPicture")).setValueIndex(this.i1);
                final EditTextPreference editTextPreference30 = (EditTextPreference) findPreference("prefEditTouchX");
                editTextPreference30.setSummary(this.j1 + "");
                editTextPreference30.setText(this.j1 + "");
                editTextPreference30.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.h
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return this.a.J(editTextPreference30, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference31 = (EditTextPreference) findPreference("prefEditTouchY");
                editTextPreference31.setSummary(this.k1 + "");
                editTextPreference31.setText(this.k1 + "");
                editTextPreference31.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.f0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return this.a.T(editTextPreference31, preference, obj);
                    }
                });
                EditTextPreference editTextPreference32 = (EditTextPreference) findPreference("EditPathPicture_0");
                editTextPreference32.setText(this.S0);
                editTextPreference32.setSummary(this.S0);
                editTextPreference32.setOnPreferenceClickListener(new a0(editTextPreference32));
                EditTextPreference editTextPreference33 = (EditTextPreference) findPreference("EditPathPicture_1");
                editTextPreference33.setText(this.T0);
                editTextPreference33.setSummary(this.T0);
                editTextPreference33.setOnPreferenceClickListener(new b0(editTextPreference33));
                EditTextPreference editTextPreference34 = (EditTextPreference) findPreference("EditPathPicture_2");
                editTextPreference34.setText(this.U0);
                editTextPreference34.setSummary(this.U0);
                editTextPreference34.setOnPreferenceClickListener(new c0(editTextPreference34));
                EditTextPreference editTextPreference35 = (EditTextPreference) findPreference("EditPathPicture_3");
                editTextPreference35.setText(this.V0);
                editTextPreference35.setSummary(this.V0);
                editTextPreference35.setOnPreferenceClickListener(new d0(editTextPreference35));
                EditTextPreference editTextPreference36 = (EditTextPreference) findPreference("EditPathPicture_4");
                editTextPreference36.setText(this.W0);
                editTextPreference36.setSummary(this.W0);
                editTextPreference36.setOnPreferenceClickListener(new e0(editTextPreference36));
                EditTextPreference editTextPreference37 = (EditTextPreference) findPreference("EditPathPicture_5");
                editTextPreference37.setText(this.X0);
                editTextPreference37.setSummary(this.X0);
                editTextPreference37.setOnPreferenceClickListener(new f0(editTextPreference37));
                EditTextPreference editTextPreference38 = (EditTextPreference) findPreference("EditPathPicture_6");
                editTextPreference38.setText(this.Y0);
                editTextPreference38.setSummary(this.Y0);
                editTextPreference38.setOnPreferenceClickListener(new h0(editTextPreference38));
                EditTextPreference editTextPreference39 = (EditTextPreference) findPreference("EditPathPicture_7");
                editTextPreference39.setText(this.Z0);
                editTextPreference39.setSummary(this.Z0);
                editTextPreference39.setOnPreferenceClickListener(new i0(editTextPreference39));
                EditTextPreference editTextPreference40 = (EditTextPreference) findPreference("EditPathPicture_8");
                editTextPreference40.setText(this.a1);
                editTextPreference40.setSummary(this.a1);
                editTextPreference40.setOnPreferenceClickListener(new j0(editTextPreference40));
                EditTextPreference editTextPreference41 = (EditTextPreference) findPreference("EditPathPicture_9");
                editTextPreference41.setText(this.b1);
                editTextPreference41.setSummary(this.b1);
                editTextPreference41.setOnPreferenceClickListener(new k0(editTextPreference41));
                EditTextPreference editTextPreference42 = (EditTextPreference) findPreference("EditPathPicture_10");
                editTextPreference42.setText(this.c1);
                editTextPreference42.setSummary(this.c1);
                editTextPreference42.setOnPreferenceClickListener(new l0(editTextPreference42));
                EditTextPreference editTextPreference43 = (EditTextPreference) findPreference("EditPathPicture_11");
                editTextPreference43.setText(this.d1);
                editTextPreference43.setSummary(this.d1);
                editTextPreference43.setOnPreferenceClickListener(new m0(editTextPreference43));
                EditTextPreference editTextPreference44 = (EditTextPreference) findPreference("EditPathPicture_12");
                editTextPreference44.setText(this.e1);
                editTextPreference44.setSummary(this.e1);
                editTextPreference44.setOnPreferenceClickListener(new n0(editTextPreference44));
                EditTextPreference editTextPreference45 = (EditTextPreference) findPreference("EditPathPicture_13");
                editTextPreference45.setText(this.f1);
                editTextPreference45.setSummary(this.f1);
                editTextPreference45.setOnPreferenceClickListener(new o0(editTextPreference45));
                EditTextPreference editTextPreference46 = (EditTextPreference) findPreference("EditPathPicture_14");
                editTextPreference46.setText(this.g1);
                editTextPreference46.setSummary(this.g1);
                editTextPreference46.setOnPreferenceClickListener(new p0(editTextPreference46));
                editTextPreference3 = (EditTextPreference) findPreference("EditPathPicture_15");
                editTextPreference3.setText(this.h1);
                editTextPreference3.setSummary(this.h1);
                zVar = new q0(editTextPreference3);
                editTextPreference3.setOnPreferenceClickListener(zVar);
                break;
            case 18:
                addPreferencesFromResource(R.xml.preference_sms_receive);
                ListPreference listPreference12 = (ListPreference) findPreference("listTypeCommandSmsReceive");
                listPreference12.setValueIndex(this.R0);
                ((EditTextPreference) findPreference("SmsReceivePhone")).setText(this.N0);
                ((EditTextPreference) findPreference("SmsReceiveTextCommand")).setText(this.M0);
                CheckBoxPreference checkBoxPreference13 = (CheckBoxPreference) findPreference("smsRecCheckStrob");
                checkBoxPreference13.setChecked(this.O0);
                EditTextPreference editTextPreference47 = (EditTextPreference) findPreference("smsRecReg");
                editTextPreference47.setText(String.valueOf(this.P0));
                EditTextPreference editTextPreference48 = (EditTextPreference) findPreference("smsRecBit");
                editTextPreference48.setText(String.valueOf(this.Q0));
                if (this.O0) {
                    i9 = 1;
                    editTextPreference47.setEnabled(true);
                    editTextPreference48.setEnabled(true);
                    z2 = false;
                } else {
                    i9 = 1;
                    z2 = false;
                    editTextPreference47.setEnabled(false);
                    editTextPreference48.setEnabled(false);
                }
                checkBoxPreference13.setOnPreferenceClickListener(new s0(this, checkBoxPreference13, editTextPreference47, editTextPreference48));
                if (this.R0 == i9) {
                    checkBoxPreference13.setEnabled(z2);
                    editTextPreference47.setEnabled(z2);
                    editTextPreference48.setEnabled(z2);
                }
                listPreference12.setOnPreferenceChangeListener(new t0(this, checkBoxPreference13, editTextPreference47, editTextPreference48));
                break;
            case 19:
                addPreferencesFromResource(R.xml.preference_gateway);
                ListPreference listPreference13 = (ListPreference) findPreference("listModeGateway");
                EditTextPreference editTextPreference49 = (EditTextPreference) findPreference("gatewayReg");
                EditTextPreference editTextPreference50 = (EditTextPreference) findPreference("gatewayBit");
                ListPreference listPreference14 = (ListPreference) findPreference("listGatewayConnections");
                try {
                    JSONObject jSONObject2 = new JSONObject(this.x1);
                    if (this.y1 == -1) {
                        i10 = 1;
                        this.y1 = 1;
                    } else {
                        i10 = 1;
                    }
                    int i20 = jSONObject2.getInt("countActiveDevice");
                    if (i20 < i10 || i20 > 16) {
                        i20 = 1;
                    }
                    int i21 = i20 + 1;
                    String[] strArr4 = new String[i21];
                    String[] strArr5 = new String[17];
                    String[] strArr6 = new String[i21];
                    int i22 = 0;
                    for (int i23 = 17; i22 < i23; i23 = 17) {
                        strArr5[i22] = jSONObject2.getString("dev" + i22 + "Name");
                        i22++;
                    }
                    for (int i24 = 0; i24 < i21; i24++) {
                        strArr4[i24] = jSONObject2.getString("dev" + i24 + "Name");
                        StringBuilder sb4 = new StringBuilder();
                        sb4.append(i24);
                        sb4.append("");
                        strArr6[i24] = sb4.toString();
                    }
                    listPreference14.setEntries(strArr4);
                    listPreference14.setEntryValues(strArr6);
                    int i25 = this.y1;
                    if (i25 == 100) {
                        listPreference14.setValueIndex(0);
                        str3 = strArr4[0];
                    } else if (i25 > i20) {
                        str3 = strArr5[i25];
                    } else {
                        listPreference14.setValueIndex(i25);
                        str3 = strArr4[this.y1];
                    }
                    listPreference14.setSummary(str3);
                    listPreference14.setOnPreferenceChangeListener(new w1(listPreference14, strArr4));
                } catch (Exception unused2) {
                    Toast.makeText(getActivity(), getResources().getString(R.string.error_open_list_device_in_gateway), 1).show();
                }
                EditTextPreference editTextPreference51 = (EditTextPreference) findPreference("editGatewayCountRegister");
                editTextPreference51.setSummary(this.w1 + "");
                editTextPreference51.setText(this.w1 + "");
                editTextPreference51.setOnPreferenceChangeListener(new x1(editTextPreference51));
                listPreference13.setValueIndex(this.t1);
                int i26 = this.t1;
                if (i26 == 1) {
                    editTextPreference49.setEnabled(true);
                    editTextPreference50.setEnabled(true);
                    listPreference14.setEnabled(true);
                } else if (i26 == 2) {
                    editTextPreference51.setEnabled(false);
                }
                editTextPreference49.setText(String.valueOf(this.u1));
                editTextPreference50.setText(String.valueOf(this.v1));
                listPreference13.setOnPreferenceChangeListener(new z1(editTextPreference49, editTextPreference50, listPreference14, editTextPreference51));
                break;
            case 20:
                addPreferencesFromResource(R.xml.preference_list);
                this.r1.setText(this.s1 + "");
                EditTextPreference editTextPreference52 = (EditTextPreference) findPreference("base_pref_edit_text");
                editTextPreference52.setText(this.F);
                editTextPreference52.setSummary(this.F);
                editTextPreference52.setOnPreferenceClickListener(new u0(editTextPreference52));
                EditTextPreference editTextPreference53 = (EditTextPreference) findPreference("base_pref_edit_height_text");
                editTextPreference53.setText(String.valueOf(this.D));
                editTextPreference53.setSummary(String.valueOf(this.D));
                editTextPreference53.setOnPreferenceClickListener(new v0(editTextPreference53));
                ((CheckBoxPreference) findPreference("checkVisible")).setChecked(this.J);
                ((CheckBoxPreference) findPreference("checkNoChange")).setChecked(this.q1);
                String[] strArr7 = new String[16];
                try {
                    JSONObject jSONObject3 = new JSONObject(this.p1);
                    for (int i27 = 0; i27 < 16; i27++) {
                        strArr7[i27] = jSONObject3.getString("textBit" + i27);
                    }
                } catch (JSONException unused3) {
                    for (int i28 = 0; i28 < 16; i28++) {
                        strArr7[i28] = "";
                    }
                }
                EditTextPreference editTextPreference54 = (EditTextPreference) findPreference("base_pref_list_text_0");
                editTextPreference54.setText(strArr7[0]);
                editTextPreference54.setSummary(strArr7[0]);
                editTextPreference54.setOnPreferenceClickListener(new C0295w0(editTextPreference54));
                EditTextPreference editTextPreference55 = (EditTextPreference) findPreference("base_pref_list_text_1");
                editTextPreference55.setText(strArr7[1]);
                editTextPreference55.setSummary(strArr7[1]);
                editTextPreference55.setOnPreferenceClickListener(new x0(editTextPreference55));
                EditTextPreference editTextPreference56 = (EditTextPreference) findPreference("base_pref_list_text_2");
                editTextPreference56.setText(strArr7[2]);
                editTextPreference56.setSummary(strArr7[2]);
                editTextPreference56.setOnPreferenceClickListener(new y0(editTextPreference56));
                EditTextPreference editTextPreference57 = (EditTextPreference) findPreference("base_pref_list_text_3");
                editTextPreference57.setText(strArr7[3]);
                editTextPreference57.setSummary(strArr7[3]);
                editTextPreference57.setOnPreferenceClickListener(new z0(editTextPreference57));
                EditTextPreference editTextPreference58 = (EditTextPreference) findPreference("base_pref_list_text_4");
                editTextPreference58.setText(strArr7[4]);
                editTextPreference58.setSummary(strArr7[4]);
                editTextPreference58.setOnPreferenceClickListener(new a1(editTextPreference58));
                EditTextPreference editTextPreference59 = (EditTextPreference) findPreference("base_pref_list_text_5");
                editTextPreference59.setText(strArr7[5]);
                editTextPreference59.setSummary(strArr7[5]);
                editTextPreference59.setOnPreferenceClickListener(new b1(editTextPreference59));
                EditTextPreference editTextPreference60 = (EditTextPreference) findPreference("base_pref_list_text_6");
                editTextPreference60.setText(strArr7[6]);
                editTextPreference60.setSummary(strArr7[6]);
                editTextPreference60.setOnPreferenceClickListener(new d1(editTextPreference60));
                EditTextPreference editTextPreference61 = (EditTextPreference) findPreference("base_pref_list_text_7");
                editTextPreference61.setText(strArr7[7]);
                editTextPreference61.setSummary(strArr7[7]);
                editTextPreference61.setOnPreferenceClickListener(new e1(editTextPreference61));
                EditTextPreference editTextPreference62 = (EditTextPreference) findPreference("base_pref_list_text_8");
                editTextPreference62.setText(strArr7[8]);
                editTextPreference62.setSummary(strArr7[8]);
                editTextPreference62.setOnPreferenceClickListener(new f1(editTextPreference62));
                EditTextPreference editTextPreference63 = (EditTextPreference) findPreference("base_pref_list_text_9");
                editTextPreference63.setText(strArr7[9]);
                editTextPreference63.setSummary(strArr7[9]);
                editTextPreference63.setOnPreferenceClickListener(new g1(editTextPreference63));
                EditTextPreference editTextPreference64 = (EditTextPreference) findPreference("base_pref_list_text_10");
                editTextPreference64.setText(strArr7[10]);
                editTextPreference64.setSummary(strArr7[10]);
                editTextPreference64.setOnPreferenceClickListener(new h1(editTextPreference64));
                EditTextPreference editTextPreference65 = (EditTextPreference) findPreference("base_pref_list_text_11");
                editTextPreference65.setText(strArr7[11]);
                editTextPreference65.setSummary(strArr7[11]);
                editTextPreference65.setOnPreferenceClickListener(new i1(editTextPreference65));
                EditTextPreference editTextPreference66 = (EditTextPreference) findPreference("base_pref_list_text_12");
                editTextPreference66.setText(strArr7[12]);
                editTextPreference66.setSummary(strArr7[12]);
                editTextPreference66.setOnPreferenceClickListener(new j1(editTextPreference66));
                EditTextPreference editTextPreference67 = (EditTextPreference) findPreference("base_pref_list_text_13");
                editTextPreference67.setText(strArr7[13]);
                editTextPreference67.setSummary(strArr7[13]);
                editTextPreference67.setOnPreferenceClickListener(new k1(editTextPreference67));
                EditTextPreference editTextPreference68 = (EditTextPreference) findPreference("base_pref_list_text_14");
                editTextPreference68.setText(strArr7[14]);
                editTextPreference68.setSummary(strArr7[14]);
                editTextPreference68.setOnPreferenceClickListener(new l1(editTextPreference68));
                EditTextPreference editTextPreference69 = (EditTextPreference) findPreference("base_pref_list_text_15");
                editTextPreference69.setText(strArr7[15]);
                editTextPreference69.setSummary(strArr7[15]);
                editTextPreference69.setOnPreferenceClickListener(new m1(editTextPreference69));
                break;
            case 21:
                addPreferencesFromResource(R.xml.preference_sound);
                EditTextPreference editTextPreference70 = (EditTextPreference) findPreference("EditPathSound_0");
                editTextPreference70.setText(this.S0);
                editTextPreference70.setSummary(this.S0);
                editTextPreference70.setOnPreferenceClickListener(new o1(editTextPreference70));
                EditTextPreference editTextPreference71 = (EditTextPreference) findPreference("EditPathSound_1");
                editTextPreference71.setText(this.T0);
                editTextPreference71.setSummary(this.T0);
                editTextPreference71.setOnPreferenceClickListener(new p1(editTextPreference71));
                EditTextPreference editTextPreference72 = (EditTextPreference) findPreference("EditPathSound_2");
                editTextPreference72.setText(this.U0);
                editTextPreference72.setSummary(this.U0);
                editTextPreference72.setOnPreferenceClickListener(new q1(editTextPreference72));
                EditTextPreference editTextPreference73 = (EditTextPreference) findPreference("EditPathSound_3");
                editTextPreference73.setText(this.V0);
                editTextPreference73.setSummary(this.V0);
                editTextPreference73.setOnPreferenceClickListener(new r1(editTextPreference73));
                EditTextPreference editTextPreference74 = (EditTextPreference) findPreference("EditPathSound_4");
                editTextPreference74.setText(this.W0);
                editTextPreference74.setSummary(this.W0);
                editTextPreference74.setOnPreferenceClickListener(new s1(editTextPreference74));
                EditTextPreference editTextPreference75 = (EditTextPreference) findPreference("EditPathSound_5");
                editTextPreference75.setText(this.X0);
                editTextPreference75.setSummary(this.X0);
                editTextPreference75.setOnPreferenceClickListener(new t1(editTextPreference75));
                EditTextPreference editTextPreference76 = (EditTextPreference) findPreference("EditPathSound_6");
                editTextPreference76.setText(this.Y0);
                editTextPreference76.setSummary(this.Y0);
                editTextPreference76.setOnPreferenceClickListener(new u1(editTextPreference76));
                editTextPreference3 = (EditTextPreference) findPreference("EditPathSound_7");
                editTextPreference3.setText(this.Z0);
                editTextPreference3.setSummary(this.Z0);
                zVar = new v1(editTextPreference3);
                editTextPreference3.setOnPreferenceClickListener(zVar);
                break;
            case 22:
                addPreferencesFromResource(R.xml.preference_gateway_bit);
                ListPreference listPreference15 = (ListPreference) findPreference("listModeGateway");
                EditTextPreference editTextPreference77 = (EditTextPreference) findPreference("gatewayReg");
                EditTextPreference editTextPreference78 = (EditTextPreference) findPreference("gatewayBit");
                ListPreference listPreference16 = (ListPreference) findPreference("listGatewayConnections");
                try {
                    JSONObject jSONObject4 = new JSONObject(this.x1);
                    if (this.y1 == -1) {
                        this.y1 = 1;
                    }
                    int i29 = jSONObject4.getInt("countActiveDevice");
                    if (i29 < 1 || i29 > 16) {
                        i29 = 1;
                    }
                    int i30 = i29 + 1;
                    String[] strArr8 = new String[i30];
                    String[] strArr9 = new String[17];
                    String[] strArr10 = new String[i30];
                    int i31 = 0;
                    for (int i32 = 17; i31 < i32; i32 = 17) {
                        strArr9[i31] = jSONObject4.getString("dev" + i31 + "Name");
                        i31++;
                    }
                    for (int i33 = 0; i33 < i30; i33++) {
                        strArr8[i33] = jSONObject4.getString("dev" + i33 + "Name");
                        StringBuilder sb5 = new StringBuilder();
                        sb5.append(i33);
                        sb5.append("");
                        strArr10[i33] = sb5.toString();
                    }
                    listPreference16.setEntries(strArr8);
                    listPreference16.setEntryValues(strArr10);
                    int i34 = this.y1;
                    if (i34 == 100) {
                        listPreference16.setValueIndex(0);
                        str4 = strArr8[0];
                    } else if (i34 > i29) {
                        str4 = strArr9[i34];
                    } else {
                        listPreference16.setValueIndex(i34);
                        str4 = strArr8[this.y1];
                    }
                    listPreference16.setSummary(str4);
                    listPreference16.setOnPreferenceChangeListener(new a2(listPreference16, strArr8));
                } catch (Exception unused4) {
                    Toast.makeText(getActivity(), getResources().getString(R.string.error_open_list_device_in_gateway), 1).show();
                }
                EditTextPreference editTextPreference79 = (EditTextPreference) findPreference("editGatewayBitCountBit");
                editTextPreference79.setSummary(this.B1 + "");
                editTextPreference79.setText(this.B1 + "");
                editTextPreference79.setOnPreferenceChangeListener(new b2(editTextPreference79));
                listPreference15.setValueIndex(this.t1);
                if (this.t1 == 1) {
                    editTextPreference77.setEnabled(true);
                    editTextPreference78.setEnabled(true);
                    listPreference16.setEnabled(true);
                }
                editTextPreference77.setText(String.valueOf(this.u1));
                editTextPreference78.setText(String.valueOf(this.v1));
                listPreference15.setOnPreferenceChangeListener(new c2(editTextPreference77, editTextPreference78, listPreference16));
                break;
            case 24:
                addPreferencesFromResource(R.xml.preference_gauge2);
                ((CheckBoxPreference) findPreference("hideBackground")).setChecked(this.l0);
                editTextPreference3 = (EditTextPreference) findPreference("gauge_range");
                EditTextPreference editTextPreference80 = (EditTextPreference) findPreference("gaugeIndicator");
                editTextPreference80.setSummary(this.m0 + "");
                editTextPreference80.setOnPreferenceClickListener(new d2(editTextPreference80));
                EditTextPreference editTextPreference81 = (EditTextPreference) findPreference("gauge_sizeText");
                editTextPreference81.setText(this.i0 + "");
                editTextPreference81.setSummary(this.i0 + "");
                editTextPreference81.setOnPreferenceChangeListener(new e2(editTextPreference81));
                EditTextPreference editTextPreference82 = (EditTextPreference) findPreference("gauge_countTextScale");
                editTextPreference82.setText(this.h0 + "");
                editTextPreference82.setSummary(this.h0 + "");
                editTextPreference82.setOnPreferenceChangeListener(new f2(editTextPreference82));
                EditTextPreference editTextPreference83 = (EditTextPreference) findPreference("gauge_min");
                editTextPreference83.setText(this.f0 + "");
                editTextPreference83.setSummary(this.f0 + "");
                editTextPreference83.setOnPreferenceChangeListener(new g2(editTextPreference83, editTextPreference3));
                EditTextPreference editTextPreference84 = (EditTextPreference) findPreference("gauge_max");
                editTextPreference84.setText(this.g0 + "");
                editTextPreference84.setSummary(this.g0 + "");
                editTextPreference84.setOnPreferenceChangeListener(new h2(editTextPreference84, editTextPreference3));
                editTextPreference3.setSummary(getResources().getString(R.string.green_) + ": " + this.f0 + "-" + this.j0 + " " + getResources().getString(R.string.yellow_) + " : " + this.j0 + "-" + this.k0 + " " + getResources().getString(R.string.red_) + " : " + this.k0 + "-" + this.g0);
                zVar = new i2(editTextPreference3);
                editTextPreference3.setOnPreferenceClickListener(zVar);
                break;
            case 25:
                addPreferencesFromResource(R.xml.preference_push_notif);
                final EditTextPreference editTextPreference85 = (EditTextPreference) findPreference("pref_edit_push_to");
                editTextPreference85.setText(this.G1);
                editTextPreference85.setSummary(this.G1);
                editTextPreference85.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.x
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.U(editTextPreference85, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference86 = (EditTextPreference) findPreference("pref_edit_push_title");
                editTextPreference86.setText(this.E1);
                editTextPreference86.setSummary(this.E1);
                editTextPreference86.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.g
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.V(editTextPreference86, preference, obj);
                    }
                });
                editTextPreference4 = (EditTextPreference) findPreference("pref_edit_push_body");
                editTextPreference4.setText(this.F1);
                editTextPreference4.setSummary(this.F1);
                onPreferenceChangeListener = new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.e
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.W(editTextPreference4, preference, obj);
                    }
                };
                editTextPreference4.setOnPreferenceChangeListener(onPreferenceChangeListener);
                break;
            case 26:
                addPreferencesFromResource(R.xml.base_preference_web_view);
                final EditTextPreference editTextPreference87 = (EditTextPreference) findPreference("web_view_link_bit_0");
                editTextPreference87.setText(this.a);
                editTextPreference87.setSummary(this.a);
                editTextPreference87.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.d0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.X(editTextPreference87, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference88 = (EditTextPreference) findPreference("web_view_link_bit_1");
                editTextPreference88.setText(this.b);
                editTextPreference88.setSummary(this.b);
                editTextPreference88.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.e0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.c(editTextPreference88, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference89 = (EditTextPreference) findPreference("web_view_link_bit_2");
                editTextPreference89.setText(this.c);
                editTextPreference89.setSummary(this.c);
                editTextPreference89.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.f
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.d(editTextPreference89, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference90 = (EditTextPreference) findPreference("web_view_link_bit_3");
                editTextPreference90.setText(this.f9124d);
                editTextPreference90.setSummary(this.f9124d);
                editTextPreference90.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.m
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.e(editTextPreference90, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference91 = (EditTextPreference) findPreference("web_view_link_bit_4");
                editTextPreference91.setText(this.f9125e);
                editTextPreference91.setSummary(this.f9125e);
                editTextPreference91.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.n
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.f(editTextPreference91, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference92 = (EditTextPreference) findPreference("web_view_link_bit_5");
                editTextPreference92.setText(this.f9126f);
                editTextPreference92.setSummary(this.f9126f);
                editTextPreference92.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.t
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.g(editTextPreference92, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference93 = (EditTextPreference) findPreference("web_view_link_bit_6");
                editTextPreference93.setText(this.f9127g);
                editTextPreference93.setSummary(this.f9127g);
                editTextPreference93.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.c
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.h(editTextPreference93, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference94 = (EditTextPreference) findPreference("web_view_link_bit_7");
                editTextPreference94.setText(this.f9128h);
                editTextPreference94.setSummary(this.f9128h);
                editTextPreference94.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.k
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.i(editTextPreference94, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference95 = (EditTextPreference) findPreference("web_view_link_bit_8");
                editTextPreference95.setText(this.f9129i);
                editTextPreference95.setSummary(this.f9129i);
                editTextPreference95.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.y
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.j(editTextPreference95, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference96 = (EditTextPreference) findPreference("web_view_link_bit_9");
                editTextPreference96.setText(this.f9130j);
                editTextPreference96.setSummary(this.f9130j);
                editTextPreference96.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.l
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.k(editTextPreference96, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference97 = (EditTextPreference) findPreference("web_view_link_bit_10");
                editTextPreference97.setText(this.f9131k);
                editTextPreference97.setSummary(this.f9131k);
                editTextPreference97.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.i
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.l(editTextPreference97, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference98 = (EditTextPreference) findPreference("web_view_link_bit_11");
                editTextPreference98.setText(this.f9132l);
                editTextPreference98.setSummary(this.f9132l);
                editTextPreference98.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.m0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.n(editTextPreference98, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference99 = (EditTextPreference) findPreference("web_view_link_bit_12");
                editTextPreference99.setText(this.f9133m);
                editTextPreference99.setSummary(this.f9133m);
                editTextPreference99.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.h0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.o(editTextPreference99, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference100 = (EditTextPreference) findPreference("web_view_link_bit_13");
                editTextPreference100.setText(this.f9134n);
                editTextPreference100.setSummary(this.f9134n);
                editTextPreference100.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.i0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.p(editTextPreference100, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference101 = (EditTextPreference) findPreference("web_view_link_bit_14");
                editTextPreference101.setText(this.o);
                editTextPreference101.setSummary(this.o);
                editTextPreference101.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.g0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.q(editTextPreference101, preference, obj);
                    }
                });
                editTextPreference4 = (EditTextPreference) findPreference("web_view_link_bit_15");
                editTextPreference4.setText(this.C);
                editTextPreference4.setSummary(this.C);
                onPreferenceChangeListener = new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.o0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.r(editTextPreference4, preference, obj);
                    }
                };
                editTextPreference4.setOnPreferenceChangeListener(onPreferenceChangeListener);
                break;
            case 27:
                addPreferencesFromResource(R.xml.base_preference_voice_recognition);
                final EditTextPreference editTextPreference102 = (EditTextPreference) findPreference("voice_rec_text_bit_0");
                editTextPreference102.setText(this.a);
                editTextPreference102.setSummary(this.a);
                editTextPreference102.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.l0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.s(editTextPreference102, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference103 = (EditTextPreference) findPreference("voice_rec_text_bit_1");
                ru.himik.nightscream.kascada.Utils.l lVar = ru.himik.nightscream.kascada.Utils.l.a;
                editTextPreference103.setEnabled(lVar.l());
                editTextPreference103.setText(this.b);
                editTextPreference103.setSummary(this.b);
                if (!lVar.l()) {
                    editTextPreference103.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference103.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.k0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.t(editTextPreference103, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference104 = (EditTextPreference) findPreference("voice_rec_text_bit_2");
                editTextPreference104.setEnabled(lVar.l());
                editTextPreference104.setText(this.c);
                editTextPreference104.setSummary(this.c);
                if (!lVar.l()) {
                    editTextPreference104.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference104.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.a0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.u(editTextPreference104, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference105 = (EditTextPreference) findPreference("voice_rec_text_bit_3");
                editTextPreference105.setEnabled(lVar.l());
                editTextPreference105.setText(this.f9124d);
                editTextPreference105.setSummary(this.f9124d);
                if (!lVar.l()) {
                    editTextPreference105.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference105.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.j0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.v(editTextPreference105, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference106 = (EditTextPreference) findPreference("voice_rec_text_bit_4");
                editTextPreference106.setEnabled(lVar.l());
                editTextPreference106.setText(this.f9125e);
                editTextPreference106.setSummary(this.f9125e);
                if (!lVar.l()) {
                    editTextPreference106.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference106.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.q0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.w(editTextPreference106, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference107 = (EditTextPreference) findPreference("voice_rec_text_bit_5");
                editTextPreference107.setEnabled(lVar.l());
                editTextPreference107.setText(this.f9126f);
                editTextPreference107.setSummary(this.f9126f);
                if (!lVar.l()) {
                    editTextPreference107.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference107.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.u0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.y(editTextPreference107, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference108 = (EditTextPreference) findPreference("voice_rec_text_bit_6");
                editTextPreference108.setEnabled(lVar.l());
                editTextPreference108.setText(this.f9127g);
                editTextPreference108.setSummary(this.f9127g);
                if (!lVar.l()) {
                    editTextPreference108.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference108.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.p
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.z(editTextPreference108, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference109 = (EditTextPreference) findPreference("voice_rec_text_bit_7");
                editTextPreference109.setEnabled(lVar.l());
                editTextPreference109.setText(this.f9128h);
                editTextPreference109.setSummary(this.f9128h);
                if (!lVar.l()) {
                    editTextPreference109.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference109.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.n0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.A(editTextPreference109, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference110 = (EditTextPreference) findPreference("voice_rec_text_bit_8");
                editTextPreference110.setEnabled(lVar.l());
                editTextPreference110.setText(this.f9129i);
                editTextPreference110.setSummary(this.f9129i);
                if (!lVar.l()) {
                    editTextPreference110.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference110.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.c0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.B(editTextPreference110, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference111 = (EditTextPreference) findPreference("voice_rec_text_bit_9");
                editTextPreference111.setEnabled(lVar.l());
                editTextPreference111.setText(this.f9130j);
                editTextPreference111.setSummary(this.f9130j);
                if (!lVar.l()) {
                    editTextPreference111.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference111.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.s
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.C(editTextPreference111, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference112 = (EditTextPreference) findPreference("voice_rec_text_bit_10");
                editTextPreference112.setEnabled(lVar.l());
                editTextPreference112.setText(this.f9131k);
                editTextPreference112.setSummary(this.f9131k);
                if (!lVar.l()) {
                    editTextPreference112.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference112.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.o
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.D(editTextPreference112, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference113 = (EditTextPreference) findPreference("voice_rec_text_bit_11");
                editTextPreference113.setEnabled(lVar.l());
                editTextPreference113.setText(this.f9132l);
                editTextPreference113.setSummary(this.f9132l);
                if (!lVar.l()) {
                    editTextPreference113.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference113.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.w
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.E(editTextPreference113, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference114 = (EditTextPreference) findPreference("voice_rec_text_bit_12");
                editTextPreference114.setEnabled(lVar.l());
                editTextPreference114.setText(this.f9133m);
                editTextPreference114.setSummary(this.f9133m);
                if (!lVar.l()) {
                    editTextPreference114.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference114.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.p0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.F(editTextPreference114, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference115 = (EditTextPreference) findPreference("voice_rec_text_bit_13");
                editTextPreference115.setEnabled(lVar.l());
                editTextPreference115.setText(this.f9134n);
                editTextPreference115.setSummary(this.f9134n);
                if (!lVar.l()) {
                    editTextPreference115.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference115.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.q
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.G(editTextPreference115, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference116 = (EditTextPreference) findPreference("voice_rec_text_bit_14");
                editTextPreference116.setEnabled(lVar.l());
                editTextPreference116.setText(this.o);
                editTextPreference116.setSummary(this.o);
                if (!lVar.l()) {
                    editTextPreference116.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                editTextPreference116.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.z
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.H(editTextPreference116, preference, obj);
                    }
                });
                editTextPreference4 = (EditTextPreference) findPreference("voice_rec_text_bit_15");
                editTextPreference4.setEnabled(lVar.l());
                editTextPreference4.setText(this.C);
                editTextPreference4.setSummary(this.C);
                if (!lVar.l()) {
                    editTextPreference4.setSummary(R.string.bottomsheet_voice_rec_no_billing);
                }
                onPreferenceChangeListener = new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.a
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.K(editTextPreference4, preference, obj);
                    }
                };
                editTextPreference4.setOnPreferenceChangeListener(onPreferenceChangeListener);
                break;
            case 28:
                addPreferencesFromResource(R.xml.preference_email);
                final EditTextPreference editTextPreference117 = (EditTextPreference) findPreference("email_login");
                editTextPreference117.setText(this.J1);
                editTextPreference117.setSummary(this.J1);
                editTextPreference117.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.t0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.L(editTextPreference117, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference118 = (EditTextPreference) findPreference("email_password");
                editTextPreference118.setText(this.K1);
                editTextPreference118.setSummary(this.K1);
                editTextPreference118.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.j
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.M(editTextPreference118, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference119 = (EditTextPreference) findPreference("email_to");
                editTextPreference119.setText(this.L1);
                editTextPreference119.setSummary(this.L1);
                editTextPreference119.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.b0
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.N(editTextPreference119, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference120 = (EditTextPreference) findPreference("email_title");
                editTextPreference120.setText(this.H1);
                editTextPreference120.setSummary(this.H1);
                editTextPreference120.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.u
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.O(editTextPreference120, preference, obj);
                    }
                });
                final EditTextPreference editTextPreference121 = (EditTextPreference) findPreference("email_body");
                editTextPreference121.setText(this.I1);
                editTextPreference121.setSummary(this.I1);
                editTextPreference121.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() { // from class: ru.himik.nightscream.kascada.Preference.d
                    @Override // android.preference.Preference.OnPreferenceChangeListener
                    public final boolean onPreferenceChange(Preference preference, Object obj) {
                        return w0.P(editTextPreference121, preference, obj);
                    }
                });
                editTextPreference3 = (EditTextPreference) findPreference("email_info");
                zVar = new Preference.OnPreferenceClickListener() { // from class: ru.himik.nightscream.kascada.Preference.r0
                    @Override // android.preference.Preference.OnPreferenceClickListener
                    public final boolean onPreferenceClick(Preference preference) {
                        return this.a.R(editTextPreference3, preference);
                    }
                };
                editTextPreference3.setOnPreferenceClickListener(zVar);
                break;
        }
    }
}
