package ru.himik.nightscream.kascada.Connections.Usb.driver;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.util.Log;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.KotlinVersion;

/* JADX INFO: loaded from: classes.dex */
public class ProlificSerialDriver implements UsbSerialDriver {
    private final String TAG = ProlificSerialDriver.class.getSimpleName();
    private final UsbDevice mDevice;
    private final UsbSerialPort mPort;

    class ProlificSerialPort extends CommonUsbSerialPort {
        private static final int CONTROL_DTR = 1;
        private static final int CONTROL_RTS = 2;
        private static final int DEVICE_TYPE_0 = 1;
        private static final int DEVICE_TYPE_1 = 2;
        private static final int DEVICE_TYPE_HX = 0;
        private static final int FLUSH_RX_REQUEST = 8;
        private static final int FLUSH_TX_REQUEST = 9;
        private static final int INTERRUPT_ENDPOINT = 129;
        private static final int PROLIFIC_CTRL_OUT_REQTYPE = 33;
        private static final int PROLIFIC_VENDOR_IN_REQTYPE = 192;
        private static final int PROLIFIC_VENDOR_OUT_REQTYPE = 64;
        private static final int PROLIFIC_VENDOR_READ_REQUEST = 1;
        private static final int PROLIFIC_VENDOR_WRITE_REQUEST = 1;
        private static final int READ_ENDPOINT = 131;
        private static final int SET_CONTROL_REQUEST = 34;
        private static final int SET_LINE_REQUEST = 32;
        private static final int STATUS_BUFFER_SIZE = 10;
        private static final int STATUS_BYTE_IDX = 8;
        private static final int STATUS_FLAG_CD = 1;
        private static final int STATUS_FLAG_CTS = 128;
        private static final int STATUS_FLAG_DSR = 2;
        private static final int STATUS_FLAG_RI = 8;
        private static final int USB_READ_TIMEOUT_MILLIS = 1000;
        private static final int USB_RECIP_INTERFACE = 1;
        private static final int USB_WRITE_TIMEOUT_MILLIS = 5000;
        private static final int WRITE_ENDPOINT = 2;
        private int mBaudRate;
        private int mControlLinesValue;
        private int mDataBits;
        private int mDeviceType;
        private UsbEndpoint mInterruptEndpoint;
        private int mParity;
        private UsbEndpoint mReadEndpoint;
        private IOException mReadStatusException;
        private volatile Thread mReadStatusThread;
        private final Object mReadStatusThreadLock;
        private int mStatus;
        private int mStopBits;
        boolean mStopReadStatusThread;
        private UsbEndpoint mWriteEndpoint;

        public ProlificSerialPort(UsbDevice usbDevice, int i2) {
            super(usbDevice, i2);
            this.mDeviceType = 0;
            this.mControlLinesValue = 0;
            this.mBaudRate = -1;
            this.mDataBits = -1;
            this.mStopBits = -1;
            this.mParity = -1;
            this.mStatus = 0;
            this.mReadStatusThread = null;
            this.mReadStatusThreadLock = new Object();
            this.mStopReadStatusThread = false;
            this.mReadStatusException = null;
        }

        private final void ctrlOut(int i2, int i3, int i4, byte[] bArr) throws IOException {
            outControlTransfer(33, i2, i3, i4, bArr);
        }

        private void doBlackMagic() throws IOException {
            vendorIn(33924, 0, 1);
            vendorOut(1028, 0, null);
            vendorIn(33924, 0, 1);
            vendorIn(33667, 0, 1);
            vendorIn(33924, 0, 1);
            vendorOut(1028, 1, null);
            vendorIn(33924, 0, 1);
            vendorIn(33667, 0, 1);
            vendorOut(0, 1, null);
            vendorOut(1, 0, null);
            vendorOut(2, this.mDeviceType == 0 ? 68 : 36, null);
        }

        private final int getStatus() throws IOException {
            if (this.mReadStatusThread == null && this.mReadStatusException == null) {
                synchronized (this.mReadStatusThreadLock) {
                    if (this.mReadStatusThread == null) {
                        byte[] bArr = new byte[10];
                        if (this.mConnection.bulkTransfer(this.mInterruptEndpoint, bArr, 10, 100) != 10) {
                            Log.w(ProlificSerialDriver.this.TAG, "Could not read initial CTS / DSR / CD / RI status");
                        } else {
                            this.mStatus = bArr[8] & 255;
                        }
                        this.mReadStatusThread = new Thread(new Runnable() { // from class: ru.himik.nightscream.kascada.Connections.Usb.driver.ProlificSerialDriver.ProlificSerialPort.1
                            @Override // java.lang.Runnable
                            public void run() {
                                ProlificSerialPort.this.readStatusThreadFunction();
                            }
                        });
                        this.mReadStatusThread.setDaemon(true);
                        this.mReadStatusThread.start();
                    }
                }
            }
            IOException iOException = this.mReadStatusException;
            if (iOException == null) {
                return this.mStatus;
            }
            this.mReadStatusException = null;
            throw iOException;
        }

        private final byte[] inControlTransfer(int i2, int i3, int i4, int i5, int i6) throws IOException {
            byte[] bArr = new byte[i6];
            int iControlTransfer = this.mConnection.controlTransfer(i2, i3, i4, i5, bArr, i6, 1000);
            if (iControlTransfer == i6) {
                return bArr;
            }
            throw new IOException(String.format("ControlTransfer with value 0x%x failed: %d", Integer.valueOf(i4), Integer.valueOf(iControlTransfer)));
        }

        private final void outControlTransfer(int i2, int i3, int i4, int i5, byte[] bArr) throws IOException {
            int length = bArr == null ? 0 : bArr.length;
            int iControlTransfer = this.mConnection.controlTransfer(i2, i3, i4, i5, bArr, length, 5000);
            if (iControlTransfer != length) {
                throw new IOException(String.format("ControlTransfer with value 0x%x failed: %d", Integer.valueOf(i4), Integer.valueOf(iControlTransfer)));
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final void readStatusThreadFunction() {
            while (!this.mStopReadStatusThread) {
                try {
                    byte[] bArr = new byte[10];
                    int iBulkTransfer = this.mConnection.bulkTransfer(this.mInterruptEndpoint, bArr, 10, 500);
                    if (iBulkTransfer > 0) {
                        if (iBulkTransfer != 10) {
                            throw new IOException(String.format("Invalid CTS / DSR / CD / RI status buffer received, expected %d bytes, but received %d", 10, Integer.valueOf(iBulkTransfer)));
                        }
                        this.mStatus = bArr[8] & 255;
                    }
                } catch (IOException e2) {
                    this.mReadStatusException = e2;
                    return;
                }
            }
        }

        private void resetDevice() throws IOException {
            purgeHwBuffers(true, true);
        }

        private void setControlLines(int i2) throws IOException {
            ctrlOut(34, i2, 0, null);
            this.mControlLinesValue = i2;
        }

        private final boolean testStatusFlag(int i2) {
            return (getStatus() & i2) == i2;
        }

        private final byte[] vendorIn(int i2, int i3, int i4) {
            return inControlTransfer(192, 1, i2, i3, i4);
        }

        private final void vendorOut(int i2, int i3, byte[] bArr) throws IOException {
            outControlTransfer(64, 1, i2, i3, bArr);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void close() throws IOException {
            if (this.mConnection == null) {
                throw new IOException("Already closed");
            }
            try {
                this.mStopReadStatusThread = true;
                synchronized (this.mReadStatusThreadLock) {
                    if (this.mReadStatusThread != null) {
                        try {
                            this.mReadStatusThread.join();
                        } catch (Exception e2) {
                            Log.w(ProlificSerialDriver.this.TAG, "An error occured while waiting for status read thread", e2);
                        }
                    }
                }
                resetDevice();
                try {
                    this.mConnection.releaseInterface(this.mDevice.getInterface(0));
                } finally {
                    this.mConnection = null;
                }
            } catch (Throwable th) {
                try {
                    this.mConnection.releaseInterface(this.mDevice.getInterface(0));
                    throw th;
                } finally {
                    this.mConnection = null;
                }
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCD() {
            return testStatusFlag(1);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCTS() {
            return testStatusFlag(128);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDSR() {
            return testStatusFlag(2);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDTR() {
            return (this.mControlLinesValue & 1) == 1;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public UsbSerialDriver getDriver() {
            return ProlificSerialDriver.this;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRI() {
            return testStatusFlag(8);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRTS() {
            return (this.mControlLinesValue & 2) == 2;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void open(UsbDeviceConnection usbDeviceConnection) throws IOException {
            if (this.mConnection != null) {
                throw new IOException("Already open");
            }
            UsbInterface usbInterface = this.mDevice.getInterface(0);
            if (!usbDeviceConnection.claimInterface(usbInterface, true)) {
                throw new IOException("Error claiming Prolific interface 0");
            }
            this.mConnection = usbDeviceConnection;
            for (int i2 = 0; i2 < usbInterface.getEndpointCount(); i2++) {
                try {
                    UsbEndpoint endpoint = usbInterface.getEndpoint(i2);
                    int address = endpoint.getAddress();
                    if (address == 2) {
                        this.mWriteEndpoint = endpoint;
                    } else if (address == INTERRUPT_ENDPOINT) {
                        this.mInterruptEndpoint = endpoint;
                    } else if (address == READ_ENDPOINT) {
                        this.mReadEndpoint = endpoint;
                    }
                } catch (Throwable th) {
                    this.mConnection = null;
                    usbDeviceConnection.releaseInterface(usbInterface);
                    throw th;
                }
            }
            if (this.mDevice.getDeviceClass() == 2) {
                this.mDeviceType = 1;
            } else {
                try {
                    if (((byte[]) this.mConnection.getClass().getMethod("getRawDescriptors", new Class[0]).invoke(this.mConnection, new Object[0]))[7] == 64) {
                        this.mDeviceType = 0;
                    } else if (this.mDevice.getDeviceClass() == 0 || this.mDevice.getDeviceClass() == 255) {
                        this.mDeviceType = 2;
                    } else {
                        Log.w(ProlificSerialDriver.this.TAG, "Could not detect PL2303 subtype, Assuming that it is a HX device");
                        this.mDeviceType = 0;
                    }
                } catch (NoSuchMethodException unused) {
                    Log.w(ProlificSerialDriver.this.TAG, "Method UsbDeviceConnection.getRawDescriptors, required for PL2303 subtype detection, not available! Assuming that it is a HX device");
                    this.mDeviceType = 0;
                } catch (Exception e2) {
                    Log.e(ProlificSerialDriver.this.TAG, "An unexpected exception occured while trying to detect PL2303 subtype", e2);
                }
            }
            setControlLines(this.mControlLinesValue);
            resetDevice();
            doBlackMagic();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean purgeHwBuffers(boolean z, boolean z2) throws IOException {
            if (z) {
                vendorOut(8, 0, null);
            }
            if (z2) {
                vendorOut(9, 0, null);
            }
            return z || z2;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int read(byte[] bArr, int i2) {
            synchronized (this.mReadBufferLock) {
                int iBulkTransfer = this.mConnection.bulkTransfer(this.mReadEndpoint, this.mReadBuffer, Math.min(bArr.length, this.mReadBuffer.length), i2);
                if (iBulkTransfer < 0) {
                    return 0;
                }
                System.arraycopy(this.mReadBuffer, 0, bArr, 0, iBulkTransfer);
                return iBulkTransfer;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setDTR(boolean z) throws IOException {
            setControlLines(z ? this.mControlLinesValue | 1 : this.mControlLinesValue & (-2));
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setParameters(int i2, int i3, int i4, int i5) throws IOException {
            if (this.mBaudRate == i2 && this.mDataBits == i3 && this.mStopBits == i4 && this.mParity == i5) {
                return;
            }
            byte[] bArr = new byte[7];
            bArr[0] = (byte) (i2 & KotlinVersion.MAX_COMPONENT_VALUE);
            bArr[1] = (byte) ((i2 >> 8) & KotlinVersion.MAX_COMPONENT_VALUE);
            bArr[2] = (byte) ((i2 >> 16) & KotlinVersion.MAX_COMPONENT_VALUE);
            bArr[3] = (byte) ((i2 >> 24) & KotlinVersion.MAX_COMPONENT_VALUE);
            if (i4 == 1) {
                bArr[4] = 0;
            } else if (i4 == 2) {
                bArr[4] = 2;
            } else {
                if (i4 != 3) {
                    throw new IllegalArgumentException("Unknown stopBits value: " + i4);
                }
                bArr[4] = 1;
            }
            if (i5 == 0) {
                bArr[5] = 0;
            } else if (i5 == 1) {
                bArr[5] = 1;
            } else if (i5 == 2) {
                bArr[5] = 2;
            } else if (i5 == 3) {
                bArr[5] = 3;
            } else {
                if (i5 != 4) {
                    throw new IllegalArgumentException("Unknown parity value: " + i5);
                }
                bArr[5] = 4;
            }
            bArr[6] = (byte) i3;
            ctrlOut(32, 0, 0, bArr);
            resetDevice();
            this.mBaudRate = i2;
            this.mDataBits = i3;
            this.mStopBits = i4;
            this.mParity = i5;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setRTS(boolean z) throws IOException {
            setControlLines(z ? this.mControlLinesValue | 2 : this.mControlLinesValue & (-3));
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int write(byte[] bArr, int i2) throws IOException {
            int iMin;
            byte[] bArr2;
            int iBulkTransfer;
            int i3 = 0;
            while (i3 < bArr.length) {
                synchronized (this.mWriteBufferLock) {
                    iMin = Math.min(bArr.length - i3, this.mWriteBuffer.length);
                    if (i3 == 0) {
                        bArr2 = bArr;
                    } else {
                        System.arraycopy(bArr, i3, this.mWriteBuffer, 0, iMin);
                        bArr2 = this.mWriteBuffer;
                    }
                    iBulkTransfer = this.mConnection.bulkTransfer(this.mWriteEndpoint, bArr2, iMin, i2);
                }
                if (iBulkTransfer <= 0) {
                    throw new IOException("Error writing " + iMin + " bytes at offset " + i3 + " length=" + bArr.length);
                }
                i3 += iBulkTransfer;
            }
            return i3;
        }
    }

    public ProlificSerialDriver(UsbDevice usbDevice) {
        this.mDevice = usbDevice;
        this.mPort = new ProlificSerialPort(usbDevice, 0);
    }

    public static Map<Integer, int[]> getSupportedDevices() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_PROLIFIC), new int[]{UsbId.PROLIFIC_PL2303});
        return linkedHashMap;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public UsbDevice getDevice() {
        return this.mDevice;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public List<UsbSerialPort> getPorts() {
        return Collections.singletonList(this.mPort);
    }
}
