package ru.himik.nightscream.kascada.Bd;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class c extends ArrayAdapter<g> {
    private final Context a;
    ArrayList<g> b;

    public c(Context context, ArrayList<g> arrayList) {
        super(context, R.layout.item_project_, arrayList);
        this.b = new ArrayList<>();
        this.a = context;
        this.b = arrayList;
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        View viewInflate = ((LayoutInflater) this.a.getSystemService("layout_inflater")).inflate(R.layout.item_project_, viewGroup, false);
        TextView textView = (TextView) viewInflate.findViewById(R.id.nameProject);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.countScreenInProject);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.createdDate);
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.createdTime);
        TextView textView5 = (TextView) viewInflate.findViewById(R.id.countDevice);
        textView.setText(this.b.get(i2).e());
        textView2.setText(this.b.get(i2).b() + "");
        textView3.setText(this.b.get(i2).c());
        textView4.setText(this.b.get(i2).f());
        textView5.setText(this.b.get(i2).a() + "");
        return viewInflate;
    }
}
