package ru.himik.nightscream.kascada.Connections.Bluetooth;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class c {
    private static final Map<String, String> a;

    static {
        HashMap map = new HashMap();
        a = map;
        map.put("0001", "SDP");
        map.put("0002", "UDP");
        map.put("0003", "RFCOMM");
        map.put("0004", "TCP");
        map.put("0005", "TCS-BIN");
        map.put("0006", "TCS-AT");
        map.put("0007", "ATT");
        map.put("0008", "OBEX");
        map.put("0009", "IP");
        map.put("000A", "FTP");
        map.put("000C", "HTTP");
        map.put("000E", "WSP");
        map.put("000F", "BNEP");
        map.put("0010", "UPNP");
        map.put("0011", "HIDP");
        map.put("0012", "HardcopyControlChannel");
        map.put("0014", "HardcopyDataChannel");
        map.put("0016", "HardcopyNotification");
        map.put("0017", "AVCTP");
        map.put("0019", "AVDTP");
        map.put("001B", "CMTP");
        map.put("001E", "MCAPControlChannel");
        map.put("001F", "MCAPDataChannel");
        map.put("0100", "L2CAP");
        map.put("1000", "ServiceDiscoveryServerService");
        map.put("1001", "BrowseGroupDescriptorService");
        map.put("1002", "PublicBrowseGroupService");
        map.put("1101", "SerialPortService");
        map.put("1102", "LANAccessUsingPPPService");
        map.put("1103", "DialupNetworkingService");
        map.put("1104", "IrMCSyncService");
        map.put("1105", "OBEXObjectPushService");
        map.put("1106", "OBEXFileTransferService");
        map.put("1107", "IrMCSyncCommandService");
        map.put("1108", "HeadsetService");
        map.put("1109", "CordlessTelephonyService");
        map.put("110A", "AudioSourceService");
        map.put("110B", "AudioSinkService");
        map.put("110C", "AVRemoteControlTargetService");
        map.put("110D", "AdvancedAudioDistributionService");
        map.put("110E", "AVRemoteControlService");
        map.put("110F", "VideoConferencingService");
        map.put("1110", "IntercomService");
        map.put("1111", "FaxService");
        map.put("1112", "HeadsetAudioGatewayService");
        map.put("1113", "WAPService");
        map.put("1114", "WAPClientService");
        map.put("1115", "PANUService");
        map.put("1116", "NAPService");
        map.put("1117", "GNService");
        map.put("1118", "DirectPrintingService");
        map.put("1119", "ReferencePrintingService");
        map.put("111A", "ImagingService");
        map.put("111B", "ImagingResponderService");
        map.put("111C", "ImagingAutomaticArchiveService");
        map.put("111D", "ImagingReferenceObjectsService");
        map.put("111E", "HandsfreeService");
        map.put("111F", "HandsfreeAudioGatewayService");
        map.put("1120", "DirectPrintingReferenceObjectsService");
        map.put("1121", "ReflectedUIService");
        map.put("1122", "BasicPringingService");
        map.put("1123", "PrintingStatusService");
        map.put("1124", "HumanInterfaceDeviceService");
        map.put("1125", "HardcopyCableReplacementService");
        map.put("1126", "HCRPrintService");
        map.put("1127", "HCRScanService");
        map.put("1128", "CommonISDNAccessService");
        map.put("1129", "VideoConferencingGWService");
        map.put("112A", "UDIMTService");
        map.put("112B", "UDITAService");
        map.put("112C", "AudioVideoService");
        map.put("112D", "SIMAccessService");
        map.put("112E", "Phonebook Access - PCE");
        map.put("112F", "Phonebook Access - PSE");
        map.put("1130", "Phonebook Access");
        map.put("1131", "Headset - HS");
        map.put("1132", "Message Access Server");
        map.put("1133", "Message Notification Server");
        map.put("1134", "Message Access Profile");
        map.put("1135", "GNSS");
        map.put("1136", "GNSS_Server");
        map.put("1200", "PnPInformationService");
        map.put("1201", "GenericNetworkingService");
        map.put("1202", "GenericFileTransferService");
        map.put("1203", "GenericAudioService");
        map.put("1204", "GenericTelephonyService");
    }

    public static BluetoothSocket a(BluetoothDevice bluetoothDevice) {
        Throwable th;
        try {
            return (BluetoothSocket) bluetoothDevice.getClass().getMethod("createRfcommSocket", Integer.TYPE).invoke(bluetoothDevice, 1);
        } catch (IllegalAccessException e2) {
            e2.printStackTrace();
            th = e2;
            Log.e("BluetoothUtils", "createRfcommSocket() failed", th);
            return null;
        } catch (NoSuchMethodException e3) {
            e3.printStackTrace();
            th = e3;
            Log.e("BluetoothUtils", "createRfcommSocket() failed", th);
            return null;
        } catch (InvocationTargetException e4) {
            e4.printStackTrace();
            th = e4;
            Log.e("BluetoothUtils", "createRfcommSocket() failed", th);
            return null;
        }
    }
}
