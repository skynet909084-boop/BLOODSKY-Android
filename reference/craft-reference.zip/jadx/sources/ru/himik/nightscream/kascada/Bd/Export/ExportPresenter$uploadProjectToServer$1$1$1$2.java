package ru.himik.nightscream.kascada.Bd.Export;

import kotlin.b0.c.p;
import kotlin.n;
import kotlin.u;
import kotlin.y.d;
import kotlin.y.j.a.f;
import kotlin.y.j.a.l;
import kotlinx.coroutines.m0;

/* JADX INFO: loaded from: classes.dex */
@f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$uploadProjectToServer$1$1$1$2", f = "ExportPresenter.kt", l = {}, m = "invokeSuspend")
final class ExportPresenter$uploadProjectToServer$1$1$1$2 extends l implements p<m0, d<? super u>, Object> {
    final /* synthetic */ ExportPresenter.ResponseUploadProject $responseUploadProject;
    int label;
    final /* synthetic */ ExportPresenter this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    ExportPresenter$uploadProjectToServer$1$1$1$2(ExportPresenter exportPresenter, ExportPresenter.ResponseUploadProject responseUploadProject, d<? super ExportPresenter$uploadProjectToServer$1$1$1$2> dVar) {
        super(2, dVar);
        this.this$0 = exportPresenter;
        this.$responseUploadProject = responseUploadProject;
    }

    @Override // kotlin.y.j.a.a
    public final d<u> create(Object obj, d<?> dVar) {
        return new ExportPresenter$uploadProjectToServer$1$1$1$2(this.this$0, this.$responseUploadProject, dVar);
    }

    @Override // kotlin.b0.c.p
    public final Object invoke(m0 m0Var, d<? super u> dVar) {
        return ((ExportPresenter$uploadProjectToServer$1$1$1$2) create(m0Var, dVar)).invokeSuspend(u.a);
    }

    @Override // kotlin.y.j.a.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        kotlin.y.i.d.c();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        n.b(obj);
        this.this$0.getInterfaceCallbackExport().showUploadSuccessful(this.$responseUploadProject.getUrl());
        return u.a;
    }
}
