package ru.himik.nightscream.kascada.q.d;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import kotlin.KotlinVersion;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes.dex */
public class b implements ru.himik.nightscream.kascada.q.a {
    public static int E = 2000;
    public static int F = 2000 - 1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private Handler f9262g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private Context f9263h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Calendar f9264i;
    public boolean a = true;
    private ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> b = new ArrayList<>();
    private ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> c = new ArrayList<>();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f9259d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f9260e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private ru.himik.nightscream.kascada.CustomComponents.b f9261f = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int[] f9265j = new int[E];

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    ru.himik.nightscream.kascada.CustomComponents.b f9266k = new ru.himik.nightscream.kascada.CustomComponents.b();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f9267l = 999;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f9268m = false;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private long f9269n = 0;
    private long o = 0;
    Runnable C = new a();
    byte[] D = new byte[4];

    class a implements Runnable {
        a() {
        }

        /* JADX WARN: Code duplicated, block: B:176:0x073f  */
        /* JADX WARN: Code duplicated, block: B:200:0x07da  */
        /* JADX WARN: Code duplicated, block: B:201:0x07e5  */
        /* JADX WARN: Code duplicated, block: B:235:0x0a59  */
        /* JADX WARN: Code duplicated, block: B:236:0x0a5f  */
        /* JADX WARN: Code duplicated, block: B:248:0x0aff  */
        /* JADX WARN: Code duplicated, block: B:251:0x0b16  */
        /* JADX WARN: Code duplicated, block: B:75:0x028d  */
        /* JADX WARN: Code duplicated, block: B:76:0x0298  */
        @Override // java.lang.Runnable
        public void run() {
            Message messageObtainMessage;
            Message messageObtainMessage2;
            b bVar = b.this;
            bVar.f9259d = bVar.b.size();
            while (true) {
                b bVar2 = b.this;
                if (!bVar2.a) {
                    bVar2.b.clear();
                    b.this.c.clear();
                    b.this.f9260e = 0;
                    return;
                }
                if (bVar2.c.size() > 0) {
                    b bVar3 = b.this;
                    bVar3.f9261f = (ru.himik.nightscream.kascada.CustomComponents.b) bVar3.c.get(0);
                    b.this.c.remove(0);
                    if (b.this.f9261f != null) {
                        if (b.this.f9261f.c() > b.F) {
                            b.this.f9262g.obtainMessage(2, b.this.f9261f.h(), b.this.f9261f.j()).sendToTarget();
                        }
                        if (b.this.f9261f.c() < 0 || b.this.f9261f.c() > b.F) {
                            b.this.f9262g.obtainMessage(2, b.this.f9261f.h(), b.this.f9261f.j()).sendToTarget();
                        } else {
                            byte bQ = b.this.f9261f.q();
                            try {
                                try {
                                    if (bQ != 1) {
                                        if (bQ != 3) {
                                            if (bQ != 5) {
                                                if (bQ != 6) {
                                                    if (bQ != 15) {
                                                        if (bQ != 16) {
                                                            messageObtainMessage = b.this.f9262g.obtainMessage(2, b.this.f9261f.h(), b.this.f9261f.j());
                                                        } else if (b.this.f9261f.c() >= 10) {
                                                            if (b.this.f9261f.p() == 1) {
                                                                if (b.this.f9261f.c() + b.this.f9261f.g() <= b.F - 1) {
                                                                    byte[] bArrC = ru.himik.nightscream.kascada.x.b.c(b.this.f9261f.o());
                                                                    int[] iArr = new int[4];
                                                                    for (int i2 = 0; i2 < 4; i2++) {
                                                                        iArr[i2] = bArrC[i2] & 255;
                                                                    }
                                                                    b bVar4 = b.this;
                                                                    bVar4.T(bVar4.f9261f.c(), (iArr[0] * 256) + iArr[1]);
                                                                    b bVar5 = b.this;
                                                                    bVar5.T(bVar5.f9261f.c() + 1, (iArr[2] * 256) + iArr[3]);
                                                                }
                                                            } else if (b.this.f9261f.c() + b.this.f9261f.d().length <= b.F) {
                                                                for (int i3 = 0; i3 < b.this.f9261f.d().length; i3++) {
                                                                    b bVar6 = b.this;
                                                                    bVar6.T(bVar6.f9261f.c() + i3, b.this.f9261f.d()[i3]);
                                                                }
                                                            }
                                                        } else if (b.this.f9261f.p() == 0) {
                                                            for (int i4 = 0; i4 < b.this.f9261f.d().length; i4++) {
                                                                b bVar7 = b.this;
                                                                bVar7.f9266k.v(bVar7.f9261f.c() + i4);
                                                                b bVar8 = b.this;
                                                                bVar8.f9266k.H(bVar8.f9261f.d()[i4]);
                                                                b bVar9 = b.this;
                                                                bVar9.a0(bVar9.f9266k);
                                                            }
                                                        }
                                                    } else if (b.this.f9261f.h() == 22 && b.this.f9261f.s()) {
                                                        b bVar10 = b.this;
                                                        bVar10.J(bVar10.f9261f.c(), b.this.f9261f.e());
                                                    }
                                                } else if (b.this.f9261f.c() < 10) {
                                                    b bVar11 = b.this;
                                                    bVar11.a0(bVar11.f9261f);
                                                } else {
                                                    b bVar12 = b.this;
                                                    bVar12.T(bVar12.f9261f.c(), b.this.f9261f.n());
                                                }
                                            } else if (b.this.f9261f.h() == 22) {
                                                if (b.this.f9261f.s()) {
                                                    b.this.f9261f.J(b.this.f9261f.e()[0] % 2 == 1);
                                                    if (b.this.f9261f.c() < 10) {
                                                        b bVar13 = b.this;
                                                        bVar13.M(bVar13.f9261f);
                                                    } else {
                                                        b bVar14 = b.this;
                                                        bVar14.K(bVar14.f9261f.c(), b.this.f9261f.a(), b.this.f9261f.s());
                                                    }
                                                }
                                            } else if (b.this.f9261f.c() < 10) {
                                                b bVar15 = b.this;
                                                bVar15.M(bVar15.f9261f);
                                            } else {
                                                b bVar16 = b.this;
                                                bVar16.K(bVar16.f9261f.c(), b.this.f9261f.a(), b.this.f9261f.s());
                                            }
                                            Thread.sleep(10L);
                                            b.this.f9264i = Calendar.getInstance();
                                            b bVar17 = b.this;
                                            bVar17.N(bVar17.f9264i.get(5), b.this.f9264i.get(2) + 1);
                                            b bVar18 = b.this;
                                            bVar18.Z(bVar18.f9264i.get(12), b.this.f9264i.get(11));
                                            b bVar19 = b.this;
                                            bVar19.W(bVar19.f9264i.get(13) % 2 == 1);
                                            if (b.this.f9267l != b.this.f9264i.get(7)) {
                                                b bVar20 = b.this;
                                                bVar20.O(bVar20.f9264i.get(7));
                                                b bVar21 = b.this;
                                                bVar21.f9267l = bVar21.f9264i.get(7);
                                            }
                                            b bVar22 = b.this;
                                            bVar22.f9265j[5] = Settings.System.getInt(bVar22.f9263h.getContentResolver(), "screen_brightness");
                                        } else if (b.this.f9261f.h() != 152 && b.this.f9261f.h() != 153 && b.this.f9261f.h() != 100 && b.this.f9261f.h() != 4 && b.this.f9261f.h() != 8 && b.this.f9261f.h() != 14 && b.this.f9261f.h() != 19) {
                                            Handler handler = b.this.f9262g;
                                            int iH = b.this.f9261f.h();
                                            int iJ = b.this.f9261f.j();
                                            b bVar23 = b.this;
                                            messageObtainMessage = handler.obtainMessage(1, iH, iJ, Integer.valueOf(bVar23.f9265j[bVar23.f9261f.c()]));
                                        } else if (b.this.f9261f.p() == 1) {
                                            if (b.this.f9261f.h() == 152 || b.this.f9261f.h() == 153 || b.this.f9261f.h() == 14) {
                                                int[] iArr2 = new int[b.this.f9261f.g() * 2];
                                                for (int i5 = 0; i5 < b.this.f9261f.g(); i5++) {
                                                    int i6 = i5 * 2;
                                                    b bVar24 = b.this;
                                                    iArr2[i6] = bVar24.f9265j[bVar24.f9261f.c() + i5] / 256;
                                                    b bVar25 = b.this;
                                                    int i7 = bVar25.f9265j[bVar25.f9261f.c() + i5];
                                                    b bVar26 = b.this;
                                                    iArr2[i6 + 1] = i7 - ((bVar26.f9265j[bVar26.f9261f.c() + i5] / 256) * 256);
                                                }
                                                messageObtainMessage = b.this.f9262g.obtainMessage(1, b.this.f9261f.h(), b.this.f9261f.j(), iArr2);
                                            } else {
                                                b bVar27 = b.this;
                                                b bVar28 = b.this;
                                                int i8 = bVar28.f9265j[bVar28.f9261f.c()];
                                                b bVar29 = b.this;
                                                b bVar30 = b.this;
                                                b bVar31 = b.this;
                                                int i9 = bVar31.f9265j[bVar31.f9261f.c() + 1];
                                                b bVar32 = b.this;
                                                messageObtainMessage = b.this.f9262g.obtainMessage(1, b.this.f9261f.h(), b.this.f9261f.j(), new int[]{bVar27.f9265j[bVar27.f9261f.c()] / 256, i8 - ((bVar29.f9265j[bVar29.f9261f.c()] / 256) * 256), bVar30.f9265j[bVar30.f9261f.c() + 1] / 256, i9 - ((bVar32.f9265j[bVar32.f9261f.c() + 1] / 256) * 256)});
                                            }
                                        } else if (b.this.f9261f.c() + b.this.f9261f.g() <= b.F) {
                                            int[] iArr3 = new int[b.this.f9261f.g() * 2];
                                            for (int i10 = 0; i10 < b.this.f9261f.g(); i10++) {
                                                b bVar33 = b.this;
                                                iArr3[(i10 * 2) + 1] = bVar33.f9265j[bVar33.f9261f.c() + i10];
                                            }
                                            messageObtainMessage = b.this.f9262g.obtainMessage(1, b.this.f9261f.h(), b.this.f9261f.j(), iArr3);
                                        }
                                    } else if (b.this.f9261f.h() != 22) {
                                        Handler handler2 = b.this.f9262g;
                                        int iH2 = b.this.f9261f.h();
                                        int iJ2 = b.this.f9261f.j();
                                        b bVar34 = b.this;
                                        messageObtainMessage = handler2.obtainMessage(1, iH2, iJ2, Integer.valueOf(bVar34.G(bVar34.f9261f.c(), b.this.f9261f.a())));
                                    } else if (b.this.f9261f.f() > 1) {
                                        Handler handler3 = b.this.f9262g;
                                        int iH3 = b.this.f9261f.h();
                                        int iJ3 = b.this.f9261f.j();
                                        b bVar35 = b.this;
                                        messageObtainMessage = handler3.obtainMessage(1, iH3, iJ3, bVar35.E(bVar35.f9261f.c(), b.this.f9261f.f()));
                                    } else {
                                        Handler handler4 = b.this.f9262g;
                                        int iH4 = b.this.f9261f.h();
                                        int iJ4 = b.this.f9261f.j();
                                        b bVar36 = b.this;
                                        messageObtainMessage = handler4.obtainMessage(1, iH4, iJ4, bVar36.F(bVar36.f9261f.c(), b.this.f9261f.a()));
                                    }
                                    Thread.sleep(10L);
                                } catch (InterruptedException e2) {
                                    b.this.D(e2.getMessage());
                                }
                                b bVar210 = b.this;
                                bVar210.f9265j[5] = Settings.System.getInt(bVar210.f9263h.getContentResolver(), "screen_brightness");
                            } catch (Settings.SettingNotFoundException e3) {
                                b.this.D(e3.getMessage());
                            }
                            messageObtainMessage.sendToTarget();
                            b.this.f9264i = Calendar.getInstance();
                            b bVar110 = b.this;
                            bVar110.N(bVar110.f9264i.get(5), b.this.f9264i.get(2) + 1);
                            b bVar111 = b.this;
                            bVar111.Z(bVar111.f9264i.get(12), b.this.f9264i.get(11));
                            b bVar112 = b.this;
                            bVar112.W(bVar112.f9264i.get(13) % 2 == 1);
                            if (b.this.f9267l != b.this.f9264i.get(7)) {
                                b bVar211 = b.this;
                                bVar211.O(bVar211.f9264i.get(7));
                                b bVar212 = b.this;
                                bVar212.f9267l = bVar212.f9264i.get(7);
                            }
                        }
                    }
                } else {
                    if (b.this.f9259d > 0) {
                        b bVar37 = b.this;
                        bVar37.f9261f = (ru.himik.nightscream.kascada.CustomComponents.b) bVar37.b.get(b.this.f9260e);
                        if (b.this.f9261f.m() > 0 && mbCanvas.a1 != b.this.f9261f.m()) {
                            if (b.this.f9260e != b.this.f9259d - 1) {
                                b.z(b.this);
                            } else {
                                b.this.f9260e = 0;
                            }
                            try {
                                Thread.sleep(1L);
                            } catch (Exception unused) {
                            }
                        } else if (b.this.f9261f.c() < 0 || b.this.f9261f.c() > b.F) {
                            b.this.f9262g.obtainMessage(2, b.this.f9261f.h(), b.this.f9261f.j()).sendToTarget();
                            if (b.this.f9260e != b.this.f9259d - 1) {
                                b.z(b.this);
                            } else {
                                b.this.f9260e = 0;
                            }
                        } else {
                            byte bQ2 = b.this.f9261f.q();
                            if (bQ2 != 1) {
                                if (bQ2 != 3) {
                                    if (bQ2 != 5) {
                                        if (bQ2 != 6) {
                                            if (bQ2 != 15) {
                                                if (bQ2 != 16) {
                                                    messageObtainMessage2 = b.this.f9262g.obtainMessage(2, b.this.f9261f.h(), b.this.f9261f.j());
                                                } else {
                                                    try {
                                                        if ((b.this.f9261f.h() != 19 || b.this.f9261f.s()) && b.this.f9261f.c() >= 10 && b.this.f9261f.c() + b.this.f9261f.d().length <= b.F) {
                                                            for (int i11 = 0; i11 < b.this.f9261f.d().length; i11++) {
                                                                b bVar38 = b.this;
                                                                bVar38.T(bVar38.f9261f.c() + i11, b.this.f9261f.d()[i11]);
                                                            }
                                                        }
                                                    } catch (Exception unused2) {
                                                    }
                                                }
                                            } else if (b.this.f9261f.h() == 22 && b.this.f9261f.s()) {
                                                b bVar39 = b.this;
                                                bVar39.J(bVar39.f9261f.c(), b.this.f9261f.e());
                                            }
                                        } else if (b.this.f9261f.c() < 10) {
                                            b bVar40 = b.this;
                                            bVar40.a0(bVar40.f9261f);
                                        } else if (b.this.f9261f.h() == 19) {
                                            if (b.this.f9261f.c() < 10) {
                                                b bVar41 = b.this;
                                                bVar41.a0(bVar41.f9261f);
                                            } else {
                                                b bVar42 = b.this;
                                                bVar42.T(bVar42.f9261f.c(), b.this.f9261f.n());
                                            }
                                        }
                                    } else if (b.this.f9261f.h() == 22) {
                                        if (b.this.f9261f.s() && b.this.f9261f.e() != null) {
                                            b.this.f9261f.J(b.this.f9261f.e()[0] % 2 == 1);
                                            if (b.this.f9261f.c() < 10) {
                                                b bVar43 = b.this;
                                                bVar43.M(bVar43.f9261f);
                                            } else {
                                                b bVar44 = b.this;
                                                bVar44.K(bVar44.f9261f.c(), b.this.f9261f.a(), b.this.f9261f.s());
                                            }
                                        }
                                    } else if (b.this.f9261f.c() < 10) {
                                        b bVar45 = b.this;
                                        bVar45.M(bVar45.f9261f);
                                    } else {
                                        b bVar46 = b.this;
                                        bVar46.K(bVar46.f9261f.c(), b.this.f9261f.a(), b.this.f9261f.s());
                                    }
                                    if (b.this.f9260e != b.this.f9259d - 1) {
                                        b.z(b.this);
                                    } else {
                                        b.this.f9260e = 0;
                                    }
                                } else if (b.this.f9261f.h() != 152 && b.this.f9261f.h() != 153 && b.this.f9261f.h() != 100 && b.this.f9261f.h() != 4 && b.this.f9261f.h() != 8 && b.this.f9261f.h() != 14 && b.this.f9261f.h() != 19) {
                                    Handler handler5 = b.this.f9262g;
                                    int iH5 = b.this.f9261f.h();
                                    int iJ5 = b.this.f9261f.j();
                                    b bVar47 = b.this;
                                    messageObtainMessage2 = handler5.obtainMessage(1, iH5, iJ5, Integer.valueOf(bVar47.f9265j[bVar47.f9261f.c()]));
                                } else if (b.this.f9261f.p() == 1) {
                                    b bVar48 = b.this;
                                    b bVar49 = b.this;
                                    int i12 = bVar49.f9265j[bVar49.f9261f.c()];
                                    b bVar50 = b.this;
                                    b bVar51 = b.this;
                                    b bVar52 = b.this;
                                    int i13 = bVar52.f9265j[bVar52.f9261f.c() + 1];
                                    b bVar53 = b.this;
                                    messageObtainMessage2 = b.this.f9262g.obtainMessage(1, b.this.f9261f.h(), b.this.f9261f.j(), new int[]{bVar48.f9265j[bVar48.f9261f.c()] / 256, i12 - ((bVar50.f9265j[bVar50.f9261f.c()] / 256) * 256), bVar51.f9265j[bVar51.f9261f.c() + 1] / 256, i13 - ((bVar53.f9265j[bVar53.f9261f.c() + 1] / 256) * 256)});
                                } else {
                                    int[] iArr4 = new int[b.this.f9261f.g() * 2];
                                    for (int i14 = 0; i14 < b.this.f9261f.g(); i14++) {
                                        b bVar54 = b.this;
                                        iArr4[(i14 * 2) + 1] = bVar54.f9265j[bVar54.f9261f.c() + i14];
                                    }
                                    messageObtainMessage2 = b.this.f9262g.obtainMessage(1, b.this.f9261f.h(), b.this.f9261f.j(), iArr4);
                                }
                            } else if (b.this.f9261f.h() != 22) {
                                Handler handler6 = b.this.f9262g;
                                int iH6 = b.this.f9261f.h();
                                int iJ6 = b.this.f9261f.j();
                                b bVar55 = b.this;
                                messageObtainMessage2 = handler6.obtainMessage(1, iH6, iJ6, Integer.valueOf(bVar55.G(bVar55.f9261f.c(), b.this.f9261f.a())));
                            } else if (b.this.f9261f.f() > 1) {
                                Handler handler7 = b.this.f9262g;
                                int iH7 = b.this.f9261f.h();
                                int iJ7 = b.this.f9261f.j();
                                b bVar56 = b.this;
                                messageObtainMessage2 = handler7.obtainMessage(1, iH7, iJ7, bVar56.E(bVar56.f9261f.c(), b.this.f9261f.f()));
                            } else {
                                Handler handler8 = b.this.f9262g;
                                int iH8 = b.this.f9261f.h();
                                int iJ8 = b.this.f9261f.j();
                                b bVar57 = b.this;
                                messageObtainMessage2 = handler8.obtainMessage(1, iH8, iJ8, bVar57.F(bVar57.f9261f.c(), b.this.f9261f.a()));
                            }
                            messageObtainMessage2.sendToTarget();
                            if (b.this.f9260e != b.this.f9259d - 1) {
                                b.z(b.this);
                            } else {
                                b.this.f9260e = 0;
                            }
                        }
                    }
                    Thread.sleep(10L);
                    b.this.f9264i = Calendar.getInstance();
                    b bVar113 = b.this;
                    bVar113.N(bVar113.f9264i.get(5), b.this.f9264i.get(2) + 1);
                    b bVar114 = b.this;
                    bVar114.Z(bVar114.f9264i.get(12), b.this.f9264i.get(11));
                    b bVar115 = b.this;
                    bVar115.W(bVar115.f9264i.get(13) % 2 == 1);
                    if (b.this.f9267l != b.this.f9264i.get(7)) {
                        b bVar213 = b.this;
                        bVar213.O(bVar213.f9264i.get(7));
                        b bVar214 = b.this;
                        bVar214.f9267l = bVar214.f9264i.get(7);
                    }
                    b bVar215 = b.this;
                    bVar215.f9265j[5] = Settings.System.getInt(bVar215.f9263h.getContentResolver(), "screen_brightness");
                }
            }
        }
    }

    public b(Context context) {
        this.f9263h = context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void J(int i2, byte[] bArr) {
        if (i2 > F) {
            return;
        }
        try {
            if (bArr.length == 1) {
                this.f9265j[i2] = bArr[0] & 255;
            }
            if (bArr.length == 2) {
                this.f9265j[i2] = (bArr[0] & 255) | ((bArr[1] & 255) << 8);
            }
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        Message messageObtainMessage;
        Handler handler;
        int iA;
        int iC = bVar.c();
        int i2 = 10;
        if (iC != 4) {
            if (iC == 5) {
                if (bVar.a() > 7) {
                    return;
                }
                K(5, bVar.a(), bVar.s());
                return;
            }
            if (iC != 7) {
                if (iC == 8) {
                    int i3 = this.f9265j[8];
                    K(8, bVar.a(), bVar.s());
                    int[] iArr = this.f9265j;
                    if (i3 == iArr[8]) {
                        return;
                    }
                    handler = this.f9262g;
                    i2 = 12;
                    iA = iArr[8];
                    messageObtainMessage = handler.obtainMessage(i2, Integer.valueOf(iA));
                } else {
                    if (iC != 9) {
                        return;
                    }
                    K(9, bVar.a(), bVar.s());
                    if (G(9, 15) == 1) {
                        this.f9262g.obtainMessage(13, 1).sendToTarget();
                    }
                    if (G(9, 14) != 1) {
                        this.f9268m = false;
                    } else if (!this.f9268m) {
                        this.f9268m = true;
                        if (System.currentTimeMillis() - this.f9269n >= 10000) {
                            this.f9269n = System.currentTimeMillis();
                            this.f9262g.obtainMessage(13, 2).sendToTarget();
                        }
                    }
                    if (G(9, 13) == 1 && System.currentTimeMillis() - this.o >= 1000) {
                        this.o = System.currentTimeMillis();
                        this.f9262g.obtainMessage(13, 3).sendToTarget();
                    }
                    if (G(9, 10) == 1) {
                        this.f9262g.obtainMessage(13, 4).sendToTarget();
                    }
                    if (G(9, 11) != 1) {
                        return;
                    } else {
                        messageObtainMessage = this.f9262g.obtainMessage(13, 5);
                    }
                }
            } else {
                if (bVar.a() < 0 || bVar.a() > 16 || !bVar.s() || this.f9265j[7] == bVar.a()) {
                    return;
                }
                this.f9265j[7] = bVar.a();
                messageObtainMessage = this.f9262g.obtainMessage(11, Integer.valueOf(bVar.a()));
            }
        } else if (bVar.a() < 1 || bVar.a() > mbCanvas.b1) {
            messageObtainMessage = this.f9262g.obtainMessage(2, this.f9261f.h(), this.f9261f.j());
        } else {
            if (this.f9265j[4] == bVar.a() || !bVar.s()) {
                return;
            }
            this.f9265j[4] = bVar.a();
            handler = this.f9262g;
            iA = bVar.a();
            messageObtainMessage = handler.obtainMessage(i2, Integer.valueOf(iA));
        }
        messageObtainMessage.sendToTarget();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void N(int i2, int i3) {
        this.f9265j[2] = (i2 * 100) + i3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void O(int i2) {
        switch (i2) {
            case 1:
                K(9, 0, true);
                K(9, 1, true);
                K(9, 2, true);
                break;
            case 2:
                K(9, 0, true);
                K(9, 1, false);
                K(9, 2, false);
                break;
            case 3:
                K(9, 0, false);
                K(9, 1, true);
                K(9, 2, false);
                break;
            case 4:
                K(9, 0, true);
                K(9, 1, true);
                K(9, 2, false);
                break;
            case 5:
                K(9, 0, false);
                K(9, 1, false);
                K(9, 2, true);
                break;
            case 6:
                K(9, 0, true);
                K(9, 1, false);
                K(9, 2, true);
                break;
            case 7:
                K(9, 0, false);
                K(9, 1, true);
                K(9, 2, true);
                break;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void W(boolean z) {
        K(9, 8, z);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Z(int i2, int i3) {
        this.f9265j[3] = (i3 * 100) + i2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a0(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        Handler handler;
        int i2;
        int iN;
        Message messageObtainMessage;
        int iC = bVar.c();
        if (iC == 4) {
            int[] iArr = this.f9265j;
            int i3 = iArr[4];
            iArr[4] = bVar.n();
            int[] iArr2 = this.f9265j;
            if (iArr2[4] < 1 || iArr2[4] > mbCanvas.b1) {
                iArr2[4] = i3;
                return;
            } else {
                if (i3 == iArr2[4]) {
                    return;
                }
                handler = this.f9262g;
                i2 = 10;
                iN = iArr2[4];
            }
        } else {
            if (iC == 5) {
                if (bVar.n() > 255) {
                    return;
                }
                this.f9265j[5] = bVar.n();
                return;
            }
            if (iC != 7) {
                if (iC != 8) {
                    if (iC != 9) {
                        return;
                    }
                    this.f9265j[9] = bVar.n();
                    if (G(9, 15) != 1) {
                        return;
                    } else {
                        messageObtainMessage = this.f9262g.obtainMessage(13, 1);
                    }
                } else {
                    if (this.f9265j[8] == bVar.n()) {
                        return;
                    }
                    handler = this.f9262g;
                    i2 = 12;
                }
                messageObtainMessage.sendToTarget();
            }
            if (bVar.n() < 0 || bVar.n() > 16 || this.f9265j[7] == bVar.n()) {
                return;
            }
            this.f9265j[7] = bVar.n();
            handler = this.f9262g;
            i2 = 11;
            iN = bVar.n();
        }
        messageObtainMessage = handler.obtainMessage(i2, Integer.valueOf(iN));
        messageObtainMessage.sendToTarget();
    }

    static /* synthetic */ int z(b bVar) {
        int i2 = bVar.f9260e;
        bVar.f9260e = i2 + 1;
        return i2;
    }

    public void C() {
        this.f9265j = new int[E];
    }

    public void D(String str) {
    }

    public byte[] E(int i2, int i3) {
        if (i2 > F) {
            return new byte[2];
        }
        int i4 = this.f9265j[i2] & ((1 << i3) - 1);
        return new byte[]{(byte) (i4 & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((i4 >> 8) & KotlinVersion.MAX_COMPONENT_VALUE)};
    }

    byte[] F(int i2, int i3) {
        if (i2 > F) {
            return new byte[2];
        }
        byte[] bArr = new byte[2];
        if (G(i2, i3) == 1) {
            bArr[0] = 1;
        }
        return bArr;
    }

    public int G(int i2, int i3) {
        return (this.f9265j[i2] >> i3) & 1;
    }

    public float H(int i2) {
        try {
            byte[] bArr = this.D;
            int[] iArr = this.f9265j;
            bArr[0] = (byte) (iArr[i2] / 256);
            bArr[1] = (byte) (iArr[i2] - ((iArr[this.f9261f.c()] / 256) * 256));
            byte[] bArr2 = this.D;
            int[] iArr2 = this.f9265j;
            int i3 = i2 + 1;
            bArr2[2] = (byte) (iArr2[i3] / 256);
            bArr2[3] = (byte) (iArr2[i3] - ((iArr2[this.f9261f.c() + 1] / 256) * 256));
        } catch (Exception unused) {
        }
        return ByteBuffer.wrap(this.D).getFloat();
    }

    public int I(int i2) {
        if (i2 > F) {
            return 0;
        }
        return this.f9265j[i2];
    }

    public void K(int i2, int i3, boolean z) {
        if (z) {
            int[] iArr = this.f9265j;
            iArr[i2] = iArr[i2] | (1 << i3);
        }
        if (z) {
            return;
        }
        int[] iArr2 = this.f9265j;
        iArr2[i2] = (~(1 << i3)) & iArr2[i2];
    }

    public void L(int i2, int i3, boolean z) {
        if (i2 > F) {
            return;
        }
        this.f9266k.v(i2);
        this.f9266k.t((byte) i3);
        this.f9266k.J(z);
        if (i2 < 10) {
            M(this.f9266k);
            return;
        }
        if (z) {
            int[] iArr = this.f9265j;
            iArr[i2] = iArr[i2] | (1 << i3);
        }
        if (z) {
            return;
        }
        int[] iArr2 = this.f9265j;
        iArr2[i2] = (~(1 << i3)) & iArr2[i2];
    }

    public void P(Handler handler) {
        this.f9262g = handler;
    }

    public void Q(int i2) {
        this.f9265j[4] = i2;
    }

    public void R(boolean z) {
        K(9, 9, z);
    }

    public void S(int i2) {
        this.f9265j[6] = i2;
    }

    public void T(int i2, int i3) {
        if (i2 > F) {
            return;
        }
        this.f9265j[i2] = i3;
    }

    public void U(int i2, int i3) {
        if (i2 > F) {
            return;
        }
        this.f9266k.v(i2);
        this.f9266k.H(i3);
        if (i2 < 10) {
            a0(this.f9266k);
        } else {
            this.f9265j[i2] = i3;
        }
    }

    public void V(int i2) {
        this.f9265j[4] = i2;
    }

    public void X(boolean z) {
        K(0, 15, !z);
    }

    public void Y(int i2, boolean z) {
        K(0, i2, z);
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public int a() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public String b() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void c(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        if (bVar != null) {
            this.c.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void cancel() {
        this.a = false;
        this.f9267l = 999;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void d() {
        if (this.a) {
            return;
        }
        this.a = true;
        new Thread(this.C).start();
        this.f9265j[1] = MyApplication.b().c;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void e(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        if (bVar != null) {
            this.c.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void f(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        this.b.add(bVar);
    }
}
