package ru.himik.nightscream.kascada.s;

import android.graphics.Canvas;
import android.graphics.Point;
import android.view.View;
import ru.himik.nightscream.kascada.CustomComponents.f;

/* JADX INFO: loaded from: classes2.dex */
public class c extends View.DragShadowBuilder {
    Point a;

    public c(View view) {
        super(view);
        this.a = new Point();
    }

    public void a(Point point) {
        this.a = point;
    }

    @Override // android.view.View.DragShadowBuilder
    public void onDrawShadow(Canvas canvas) {
        super.onDrawShadow(canvas);
        if (getView() instanceof f) {
            canvas.drawColor(-16711936);
        }
    }

    @Override // android.view.View.DragShadowBuilder
    public void onProvideShadowMetrics(Point point, Point point2) {
        point.set(getView().getWidth(), getView().getHeight());
        Point point3 = this.a;
        point2.set(point3.x, point3.y);
    }
}
