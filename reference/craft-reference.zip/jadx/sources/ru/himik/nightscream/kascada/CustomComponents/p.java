package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import java.util.Date;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class p extends n.a.a implements z {
    public n.a.f.d F;
    public n.a.g.d G;
    n.a.f.c H;
    n.a.f.c I;
    n.a.f.c J;
    n.a.f.c K;
    n.a.g.e L;
    n.a.g.e M;
    n.a.g.e N;
    n.a.g.e O;
    int P;
    int Q;
    public b R;
    int S;
    int T;
    int U;
    int V;
    int W;
    int a0;
    private boolean b0;
    private boolean c0;
    Bitmap d0;
    Paint e0;
    Paint f0;
    int g0;
    int h0;
    private long i0;

    public p(Context context, n.a.e.a aVar) {
        super(context, aVar);
        this.F = new n.a.f.d();
        this.G = new n.a.g.d();
        this.H = new n.a.f.c(getResources().getString(R.string.custom_graph_channel) + " 1");
        this.I = new n.a.f.c(getResources().getString(R.string.custom_graph_channel) + " 2");
        this.J = new n.a.f.c(getResources().getString(R.string.custom_graph_channel) + " 3");
        this.K = new n.a.f.c(getResources().getString(R.string.custom_graph_channel) + " 4");
        this.L = new n.a.g.e();
        this.M = new n.a.g.e();
        this.N = new n.a.g.e();
        this.O = new n.a.g.e();
        getResources().getString(R.string.custom_graph);
        this.P = 14;
        this.R = new b();
        this.T = -16777216;
        this.U = -16776961;
        this.V = 1;
        this.W = 10;
        this.a0 = -1;
        this.d0 = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.e0 = new Paint();
        this.f0 = new Paint();
        this.g0 = 0;
        this.h0 = 0;
        this.i0 = 0L;
    }

    public void e() {
        this.G.b1(this.H.k());
        this.G.d1(this.H.m());
        this.G.g1(Math.max(Math.max(this.H.l(), this.I.l()), Math.max(this.J.l(), this.K.l())));
        this.G.i1(Math.min(Math.min(this.H.n(), this.I.n()), Math.min(this.J.n(), this.K.n())));
    }

    public void f(float f2, Date date) {
        this.H.z(date, f2);
    }

    public void g(float f2, Date date) {
        this.I.z(date, f2);
    }

    public int getColorBackground_() {
        return this.T;
    }

    public int getColorLabelsXY() {
        return this.a0;
    }

    public int getColorSeries() {
        return this.U;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.R;
    }

    public int getCountPoint() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.S;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.g0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.h0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.Q;
    }

    public int getNumScreen() {
        return this.S;
    }

    public int getSecondPeriod() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.i0;
    }

    public void h(float f2, Date date) {
        this.J.z(date, f2);
    }

    public void i(float f2, Date date) {
        this.K.z(date, f2);
    }

    public void j(boolean[] zArr) {
        if (zArr != null) {
            if (!zArr[0]) {
                this.L.f(0);
            }
            if (!zArr[1]) {
                this.M.f(0);
            }
            if (!zArr[2]) {
                this.N.f(0);
            }
            if (zArr[3]) {
                return;
            }
            this.O.f(0);
        }
    }

    public void k() {
        this.L.f(-65536);
        this.M.f(-16711936);
        this.N.f(-256);
        this.O.f(-7829368);
    }

    public void l() {
        this.H.d();
        this.I.d();
        this.J.d();
        this.K.d();
    }

    public void m(int i2, int i3, int i4, boolean z) {
        this.F.a(this.H);
        this.F.a(this.I);
        this.F.a(this.J);
        this.F.a(this.K);
        this.G.a(this.L);
        this.G.a(this.M);
        this.G.a(this.N);
        this.G.a(this.O);
        this.G.Y(-16777216);
        setColorBackground_(-16777216);
        this.G.Q(20.0f);
        this.G.X(false);
        n.a.g.e eVar = this.L;
        n.a.e.d dVar = n.a.e.d.CIRCLE;
        eVar.w(dVar);
        this.L.v(2.0f);
        this.L.u(true);
        this.L.f(-65536);
        this.M.w(dVar);
        this.M.v(2.0f);
        this.M.u(true);
        this.M.f(-16711936);
        this.N.w(dVar);
        this.N.v(2.0f);
        this.N.u(true);
        this.N.f(-256);
        this.O.w(dVar);
        this.O.v(2.0f);
        this.O.u(true);
        this.O.f(-16776961);
        this.G.P(2.0f);
        this.G.X0(-7829368);
        this.G.T(true);
        this.G.X(true);
        if (!z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_width);
            getLayoutParams().width = ((int) getResources().getDimension(R.dimen.view_base_width)) * 2;
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_width)) / 2));
            setBackgroundColor(this.T);
            setColorLabelsXY(-1);
        }
        setKey(i4);
    }

    @Override // n.a.a, android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.c0) {
            this.f0.setColor(-65536);
            this.f0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f0);
        }
        if (this.b0 && mbCanvas.g1) {
            canvas.drawBitmap(this.d0, (getWidth() / 2) - (this.d0.getWidth() / 2), (getHeight() / 2) - this.d0.getHeight(), this.e0);
        }
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return false;
    }

    public void setColorBackground_(int i2) {
        this.T = i2;
        setBackgroundColor(i2);
    }

    public void setColorLabelsXY(int i2) {
        this.a0 = i2;
        this.G.k1(0, i2);
        this.G.f1(i2);
        a();
    }

    public void setColorSeries(int i2) {
        this.U = i2;
    }

    public void setConnectionError(boolean z) {
        this.c0 = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.b0 = z;
    }

    public void setCountPoint(int i2) {
        this.W = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.g0 = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.h0 = i2;
    }

    public void setFont(String str) {
    }

    public void setIdComponent(int i2) {
        this.P = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.Q = i2;
    }

    public void setLockZoom(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.S = i2;
    }

    public void setSecondPeriod(int i2) {
        this.V = i2;
    }

    public void setTimeLastTouch(long j2) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.i0 = j2;
    }

    public void setWorkMode(boolean z) {
    }
}
