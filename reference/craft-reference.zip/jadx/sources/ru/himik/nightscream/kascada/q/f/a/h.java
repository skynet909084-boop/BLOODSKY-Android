package ru.himik.nightscream.kascada.q.f.a;

import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class h {
    private final int clientType;
    private final int commandType;
    private final String other;
    private final String uid;

    public h(int i2, int i3, String str, String str2) {
        j.d(str, "uid");
        j.d(str2, "other");
        this.commandType = i2;
        this.clientType = i3;
        this.uid = str;
        this.other = str2;
    }

    public /* synthetic */ h(int i2, int i3, String str, String str2, int i4, kotlin.b0.d.g gVar) {
        this(i2, (i4 & 2) != 0 ? b.KASCADA.getI() : i3, (i4 & 4) != 0 ? "" : str, (i4 & 8) != 0 ? "" : str2);
    }

    public static /* synthetic */ h copy$default(h hVar, int i2, int i3, String str, String str2, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i2 = hVar.commandType;
        }
        if ((i4 & 2) != 0) {
            i3 = hVar.clientType;
        }
        if ((i4 & 4) != 0) {
            str = hVar.uid;
        }
        if ((i4 & 8) != 0) {
            str2 = hVar.other;
        }
        return hVar.copy(i2, i3, str, str2);
    }

    public final int component1() {
        return this.commandType;
    }

    public final int component2() {
        return this.clientType;
    }

    public final String component3() {
        return this.uid;
    }

    public final String component4() {
        return this.other;
    }

    public final h copy(int i2, int i3, String str, String str2) {
        j.d(str, "uid");
        j.d(str2, "other");
        return new h(i2, i3, str, str2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof h)) {
            return false;
        }
        h hVar = (h) obj;
        return this.commandType == hVar.commandType && this.clientType == hVar.clientType && j.a(this.uid, hVar.uid) && j.a(this.other, hVar.other);
    }

    public final int getClientType() {
        return this.clientType;
    }

    public final int getCommandType() {
        return this.commandType;
    }

    public final String getOther() {
        return this.other;
    }

    public final String getUid() {
        return this.uid;
    }

    public int hashCode() {
        return (((((this.commandType * 31) + this.clientType) * 31) + this.uid.hashCode()) * 31) + this.other.hashCode();
    }

    public String toString() {
        return "Msg(commandType=" + this.commandType + ", clientType=" + this.clientType + ", uid=" + this.uid + ", other=" + this.other + ')';
    }
}
