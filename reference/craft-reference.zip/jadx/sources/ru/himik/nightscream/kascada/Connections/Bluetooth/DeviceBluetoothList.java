package ru.himik.nightscream.kascada.Connections.Bluetooth;

import android.app.ListActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Set;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class DeviceBluetoothList extends ListActivity {
    private BluetoothAdapter a;
    ArrayList<ru.himik.nightscream.kascada.Preference.ServerList.a> b;

    public void a() {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        this.a = defaultAdapter;
        if (defaultAdapter != null && !defaultAdapter.isEnabled()) {
            startActivityForResult(new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE"), 0);
            return;
        }
        BluetoothAdapter bluetoothAdapter = this.a;
        if (bluetoothAdapter != null) {
            bluetoothAdapter.isEnabled();
        }
    }

    public void discoveryDevice(View view) {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.bluetooth_list);
        this.b = new ArrayList<>();
        a();
    }

    @Override // android.app.ListActivity
    protected void onListItemClick(ListView listView, View view, int i2, long j2) {
        ru.himik.nightscream.kascada.Preference.ServerList.a aVar = (ru.himik.nightscream.kascada.Preference.ServerList.a) getListAdapter().getItem(i2);
        Intent intent = new Intent();
        intent.putExtra("NAME", aVar.d());
        intent.putExtra("MAC", aVar.h());
        setResult(-1, intent);
        finish();
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        Set<BluetoothDevice> bondedDevices = this.a.getBondedDevices();
        if (bondedDevices != null && !bondedDevices.isEmpty()) {
            for (BluetoothDevice bluetoothDevice : bondedDevices) {
                this.b.add(new ru.himik.nightscream.kascada.Preference.ServerList.a(1, bluetoothDevice.getName(), bluetoothDevice.getAddress(), 0));
            }
        }
        setListAdapter(new ru.himik.nightscream.kascada.Preference.ServerList.b(getApplicationContext(), this.b, false));
    }
}
