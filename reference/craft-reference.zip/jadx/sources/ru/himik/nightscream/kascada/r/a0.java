package ru.himik.nightscream.kascada.r;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class a0 extends androidx.fragment.app.c {
    z v0;

    @SuppressLint({"NonConstantResourceId"})
    View.OnClickListener w0 = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.a
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.z1(view);
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: y1, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void z1(View view) {
        z zVar;
        String str;
        switch (view.getId()) {
            case R.id.halfLineIndicator /* 2131296683 */:
                zVar = this.v0;
                str = "HalfLineIndicator";
                break;
            case R.id.kiteIndicator /* 2131296738 */:
                zVar = this.v0;
                str = "KiteIndicator";
                break;
            case R.id.lineIndicator /* 2131296767 */:
                zVar = this.v0;
                str = "LineIndicator";
                break;
            case R.id.needleIndicator /* 2131296887 */:
                zVar = this.v0;
                str = "NeedleIndicator";
                break;
            case R.id.normalIndicator /* 2131296896 */:
                zVar = this.v0;
                str = "NormalIndicator";
                break;
            case R.id.normalSmallIndicator /* 2131296897 */:
                zVar = this.v0;
                str = "NormalSmallIndicator";
                break;
            case R.id.quarterLineIndicator /* 2131296956 */:
                zVar = this.v0;
                str = "QuarterLineIndicator";
                break;
            case R.id.spindleIndicator /* 2131297039 */:
                zVar = this.v0;
                str = "SpindleIndicator";
                break;
            case R.id.triangleIndicator /* 2131297320 */:
                zVar = this.v0;
                str = "TriangleIndicator";
                break;
            default:
                o1();
        }
        zVar.a(str);
        o1();
    }

    public void A1(z zVar) {
        this.v0 = zVar;
    }

    @Override // androidx.fragment.app.Fragment
    public View e0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        r1().getWindow().requestFeature(1);
        r1().setCanceledOnTouchOutside(true);
        return layoutInflater.inflate(R.layout.alert_choose_indicator, viewGroup, false);
    }

    @Override // androidx.fragment.app.c, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
    }

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void x0() {
        super.x0();
        Dialog dialogR1 = r1();
        if (dialogR1 != null) {
            dialogR1.getWindow().setLayout(-2, -1);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void z0(View view, Bundle bundle) {
        super.z0(view, bundle);
        view.findViewById(R.id.normalIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.normalSmallIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.triangleIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.spindleIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.lineIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.halfLineIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.quarterLineIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.kiteIndicator).setOnClickListener(this.w0);
        view.findViewById(R.id.needleIndicator).setOnClickListener(this.w0);
    }
}
