package ru.himik.nightscream.kascada.q.f.a;

import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class e {
    private final int id;
    private final int key;
    private final String pass;
    private final String value;

    public e() {
        this(0, 0, null, null, 15, null);
    }

    public e(int i2, int i3, String str, String str2) {
        j.d(str, "value");
        j.d(str2, "pass");
        this.id = i2;
        this.key = i3;
        this.value = str;
        this.pass = str2;
    }

    public /* synthetic */ e(int i2, int i3, String str, String str2, int i4, kotlin.b0.d.g gVar) {
        this((i4 & 1) != 0 ? 0 : i2, (i4 & 2) != 0 ? 0 : i3, (i4 & 4) != 0 ? "" : str, (i4 & 8) != 0 ? "" : str2);
    }

    public static /* synthetic */ e copy$default(e eVar, int i2, int i3, String str, String str2, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i2 = eVar.id;
        }
        if ((i4 & 2) != 0) {
            i3 = eVar.key;
        }
        if ((i4 & 4) != 0) {
            str = eVar.value;
        }
        if ((i4 & 8) != 0) {
            str2 = eVar.pass;
        }
        return eVar.copy(i2, i3, str, str2);
    }

    public final int component1() {
        return this.id;
    }

    public final int component2() {
        return this.key;
    }

    public final String component3() {
        return this.value;
    }

    public final String component4() {
        return this.pass;
    }

    public final e copy(int i2, int i3, String str, String str2) {
        j.d(str, "value");
        j.d(str2, "pass");
        return new e(i2, i3, str, str2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        return this.id == eVar.id && this.key == eVar.key && j.a(this.value, eVar.value) && j.a(this.pass, eVar.pass);
    }

    public final int getId() {
        return this.id;
    }

    public final int getKey() {
        return this.key;
    }

    public final String getPass() {
        return this.pass;
    }

    public final String getValue() {
        return this.value;
    }

    public int hashCode() {
        return (((((this.id * 31) + this.key) * 31) + this.value.hashCode()) * 31) + this.pass.hashCode();
    }

    public String toString() {
        return "ControlClick(id=" + this.id + ", key=" + this.key + ", value=" + this.value + ", pass=" + this.pass + ')';
    }
}
