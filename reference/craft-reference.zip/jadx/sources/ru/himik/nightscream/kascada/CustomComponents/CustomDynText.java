package ru.himik.nightscream.kascada.CustomComponents;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class CustomDynText extends androidx.appcompat.widget.y implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    private float A0;
    private float B0;
    String C;
    private int C0;
    String D;
    private int D0;
    String E;
    private boolean E0;
    String F;
    private boolean F0;
    String G;
    private final b G0;
    String H;
    public Point H0;
    String I;
    String J;
    String K;
    String L;
    String M;
    String N;
    int O;
    int P;
    int Q;
    int R;
    int S;
    int T;
    int U;
    int V;
    int W;
    int a0;
    int b0;
    int c0;
    int d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f8663e;
    int e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8664f;
    int f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8665g;
    int g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public byte f8666h;
    int h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8667i;
    int i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f8668j;
    private boolean j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f8669k;
    private boolean k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f8670l;
    Bitmap l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    String f8671m;
    Paint m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8672n;
    Paint n0;
    String o;
    boolean o0;
    int p0;
    int q0;
    boolean r0;
    boolean s0;
    private long t0;
    private RectF u0;
    private RectF v0;
    private SparseIntArray w0;
    private TextPaint x0;
    private float y0;
    private float z0;

    class a implements b {
        a() {
        }

        @Override // ru.himik.nightscream.kascada.CustomComponents.CustomDynText.b
        @TargetApi(16)
        public int a(int i2, RectF rectF) {
            RectF rectF2;
            float fMeasureText;
            CustomDynText.this.x0.setTextSize(i2);
            String string = CustomDynText.this.getText().toString();
            if (CustomDynText.this.getMaxLines() == 1) {
                CustomDynText.this.u0.bottom = CustomDynText.this.x0.getFontSpacing();
                rectF2 = CustomDynText.this.u0;
                fMeasureText = CustomDynText.this.x0.measureText(string);
            } else {
                StaticLayout staticLayout = new StaticLayout(string, CustomDynText.this.x0, CustomDynText.this.C0, Layout.Alignment.ALIGN_NORMAL, CustomDynText.this.z0, CustomDynText.this.A0, true);
                if (CustomDynText.this.getMaxLines() != -1 && staticLayout.getLineCount() > CustomDynText.this.getMaxLines()) {
                    return 1;
                }
                CustomDynText.this.u0.bottom = staticLayout.getHeight();
                int lineWidth = -1;
                for (int i3 = 0; i3 < staticLayout.getLineCount(); i3++) {
                    if (lineWidth < staticLayout.getLineWidth(i3)) {
                        lineWidth = (int) staticLayout.getLineWidth(i3);
                    }
                }
                rectF2 = CustomDynText.this.u0;
                fMeasureText = lineWidth;
            }
            rectF2.right = fMeasureText;
            CustomDynText.this.u0.offsetTo(0.0f, 0.0f);
            return rectF.contains(CustomDynText.this.u0) ? -1 : 1;
        }
    }

    private interface b {
        int a(int i2, RectF rectF);
    }

    public CustomDynText(Context context) {
        super(context);
        this.f8663e = getResources().getString(R.string.custom_dyn_text);
        this.f8664f = 7;
        this.f8666h = (byte) 3;
        this.f8667i = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8669k = 587202559;
        this.f8670l = "Т0";
        this.f8671m = "Т1";
        this.f8672n = "Т2";
        this.o = "Т3";
        this.C = "Т4";
        this.D = "Т5";
        this.E = "Т6";
        this.F = "Т7";
        this.G = "Т8";
        this.H = "Т9";
        this.I = "Т10";
        this.J = "Т11";
        this.K = "Т12";
        this.L = "Т13";
        this.M = "Т14";
        this.N = "Т15";
        this.O = 0;
        this.P = 0;
        this.Q = 0;
        this.R = 0;
        this.S = 0;
        this.T = 0;
        this.U = 0;
        this.V = 0;
        this.W = 0;
        this.a0 = 0;
        this.b0 = 0;
        this.c0 = 0;
        this.d0 = 0;
        this.e0 = 0;
        this.f0 = 0;
        this.g0 = 0;
        this.h0 = 0;
        this.i0 = 0;
        this.l0 = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.m0 = new Paint();
        this.n0 = new Paint();
        this.o0 = false;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = true;
        this.s0 = false;
        this.t0 = 0L;
        this.u0 = new RectF();
        this.v0 = new RectF();
        this.w0 = new SparseIntArray();
        this.x0 = new TextPaint(getPaint());
        this.y0 = 500.0f;
        this.z0 = 1.0f;
        this.A0 = 0.0f;
        this.B0 = getResources().getDimension(R.dimen.text_size_dyn_text);
        this.E0 = true;
        this.G0 = new a();
        this.H0 = new Point();
        if (this.r0) {
            k();
        }
    }

    public CustomDynText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f8663e = getResources().getString(R.string.custom_dyn_text);
        this.f8664f = 7;
        this.f8666h = (byte) 3;
        this.f8667i = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8669k = 587202559;
        this.f8670l = "Т0";
        this.f8671m = "Т1";
        this.f8672n = "Т2";
        this.o = "Т3";
        this.C = "Т4";
        this.D = "Т5";
        this.E = "Т6";
        this.F = "Т7";
        this.G = "Т8";
        this.H = "Т9";
        this.I = "Т10";
        this.J = "Т11";
        this.K = "Т12";
        this.L = "Т13";
        this.M = "Т14";
        this.N = "Т15";
        this.O = 0;
        this.P = 0;
        this.Q = 0;
        this.R = 0;
        this.S = 0;
        this.T = 0;
        this.U = 0;
        this.V = 0;
        this.W = 0;
        this.a0 = 0;
        this.b0 = 0;
        this.c0 = 0;
        this.d0 = 0;
        this.e0 = 0;
        this.f0 = 0;
        this.g0 = 0;
        this.h0 = 0;
        this.i0 = 0;
        this.l0 = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.m0 = new Paint();
        this.n0 = new Paint();
        this.o0 = false;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = true;
        this.s0 = false;
        this.t0 = 0L;
        this.u0 = new RectF();
        this.v0 = new RectF();
        this.w0 = new SparseIntArray();
        this.x0 = new TextPaint(getPaint());
        this.y0 = 500.0f;
        this.z0 = 1.0f;
        this.A0 = 0.0f;
        this.B0 = getResources().getDimension(R.dimen.text_size_dyn_text);
        this.E0 = true;
        this.G0 = new a();
        this.H0 = new Point();
        if (this.r0) {
            k();
        }
    }

    private void k() {
        if (this.F0) {
            int i2 = (int) this.B0;
            int measuredHeight = (getMeasuredHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop();
            int measuredWidth = (getMeasuredWidth() - getCompoundPaddingLeft()) - getCompoundPaddingRight();
            this.C0 = measuredWidth;
            RectF rectF = this.v0;
            rectF.right = measuredWidth;
            rectF.bottom = measuredHeight;
            super.setTextSize(0, this.r0 ? m(i2, (int) this.y0, this.G0, rectF) : this.y0);
        }
    }

    private static int l(int i2, int i3, b bVar, RectF rectF) {
        int i4 = i3 - 1;
        int i5 = i2;
        while (i2 <= i4) {
            i5 = (i2 + i4) >>> 1;
            int iA = bVar.a(i5, rectF);
            if (iA >= 0) {
                if (iA <= 0) {
                    break;
                }
                i5--;
                i4 = i5;
            } else {
                int i6 = i5 + 1;
                i5 = i2;
                i2 = i6;
            }
        }
        return i5;
    }

    private int m(int i2, int i3, b bVar, RectF rectF) {
        if (!this.E0) {
            return l(i2, i3, bVar, rectF);
        }
        int length = getText().toString().length();
        int i4 = this.w0.get(length);
        if (i4 != 0) {
            return i4;
        }
        int iL = l(i2, i3, bVar, rectF);
        this.w0.put(length, iL);
        return iL;
    }

    private int o(int i2) {
        if (this.i0 == 0) {
            switch (i2) {
                case 0:
                    return this.O;
                case 1:
                    return this.P;
                case 2:
                    return this.Q;
                case 3:
                    return this.R;
                case 4:
                    return this.S;
                case 5:
                    return this.T;
                case 6:
                    return this.U;
                case 7:
                    return this.V;
                case 8:
                    return this.W;
                case 9:
                    return this.a0;
                case 10:
                    return this.b0;
                case 11:
                    return this.c0;
                case 12:
                    return this.d0;
                case 13:
                    return this.e0;
                case 14:
                    return this.f0;
                case 15:
                    return this.g0;
            }
        }
        if (i2 == 0) {
            return this.O;
        }
        for (int i3 = 0; i3 < 16; i3++) {
            if (((i2 >> i3) & 1) == 1) {
                switch (i3) {
                    case 0:
                        return this.O;
                    case 1:
                        return this.P;
                    case 2:
                        return this.Q;
                    case 3:
                        return this.R;
                    case 4:
                        return this.S;
                    case 5:
                        return this.T;
                    case 6:
                        return this.U;
                    case 7:
                        return this.V;
                    case 8:
                        return this.W;
                    case 9:
                        return this.a0;
                    case 10:
                        return this.b0;
                    case 11:
                        return this.c0;
                    case 12:
                        return this.d0;
                    case 13:
                        return this.e0;
                    case 14:
                        return this.f0;
                    case 15:
                        return this.g0;
                }
            }
        }
        return this.O;
    }

    private String r(int i2) {
        if (this.i0 == 0) {
            switch (i2) {
                case 0:
                    return this.f8670l;
                case 1:
                    return this.f8671m;
                case 2:
                    return this.f8672n;
                case 3:
                    return this.o;
                case 4:
                    return this.C;
                case 5:
                    return this.D;
                case 6:
                    return this.E;
                case 7:
                    return this.F;
                case 8:
                    return this.G;
                case 9:
                    return this.H;
                case 10:
                    return this.I;
                case 11:
                    return this.J;
                case 12:
                    return this.K;
                case 13:
                    return this.L;
                case 14:
                    return this.M;
                case 15:
                    return this.N;
            }
        }
        if (i2 == 0) {
            return this.f8670l;
        }
        for (int i3 = 0; i3 < 16; i3++) {
            if (((i2 >> i3) & 1) == 1) {
                switch (i3) {
                    case 0:
                        return this.f8670l;
                    case 1:
                        return this.f8671m;
                    case 2:
                        return this.f8672n;
                    case 3:
                        return this.o;
                    case 4:
                        return this.C;
                    case 5:
                        return this.D;
                    case 6:
                        return this.E;
                    case 7:
                        return this.F;
                    case 8:
                        return this.G;
                    case 9:
                        return this.H;
                    case 10:
                        return this.I;
                    case 11:
                        return this.J;
                    case 12:
                        return this.K;
                    case 13:
                        return this.L;
                    case 14:
                        return this.M;
                    case 15:
                        return this.N;
                }
            }
        }
        return getText().toString();
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.H0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public int getColorText() {
        return this.f8669k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.f8667i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8664f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8668j;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.p0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.q0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8664f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8667i.l());
        jSONObject.put("addressRegister", this.f8667i.c());
        jSONObject.put("addressBit", (int) this.f8667i.a());
        jSONObject.put("typeRequest", (int) this.f8667i.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("sizeText", getTextSize());
        jSONObject.put("colorText", getColorText());
        jSONObject.put("text0", q(0));
        jSONObject.put("text1", q(1));
        jSONObject.put("text2", q(2));
        jSONObject.put("text3", q(3));
        jSONObject.put("text4", q(4));
        jSONObject.put("text5", q(5));
        jSONObject.put("text6", q(6));
        jSONObject.put("text7", q(7));
        jSONObject.put("text8", q(8));
        jSONObject.put("text9", q(9));
        jSONObject.put("text10", q(10));
        jSONObject.put("text11", q(11));
        jSONObject.put("text12", q(12));
        jSONObject.put("text13", q(13));
        jSONObject.put("text14", q(14));
        jSONObject.put("text15", q(15));
        jSONObject.put("colorBackground0", n(0));
        jSONObject.put("colorBackground1", n(1));
        jSONObject.put("colorBackground2", n(2));
        jSONObject.put("colorBackground3", n(3));
        jSONObject.put("colorBackground4", n(4));
        jSONObject.put("colorBackground5", n(5));
        jSONObject.put("colorBackground6", n(6));
        jSONObject.put("colorBackground7", n(7));
        jSONObject.put("colorBackground8", n(8));
        jSONObject.put("colorBackground9", n(9));
        jSONObject.put("colorBackground10", n(10));
        jSONObject.put("colorBackground11", n(11));
        jSONObject.put("colorBackground12", n(12));
        jSONObject.put("colorBackground13", n(13));
        jSONObject.put("colorBackground14", n(14));
        jSONObject.put("colorBackground15", n(15));
        jSONObject.put("typeCommand", getTypeCommand());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("autoResizeText", t());
        jSONObject.put("enableFrameDynText", u());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8665g;
    }

    @Override // android.widget.TextView
    public int getMaxLines() {
        return this.D0;
    }

    public int getNumScreen() {
        return this.f8668j;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.H0;
    }

    public int getState() {
        return this.h0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8667i.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8667i.l() >= 100) {
            this.f8667i.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8667i.c();
        }
        this.f8667i.u((byte) MyApplication.b().E.get(this.f8667i.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8667i.b()) + "#" + this.f8667i.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8667i.l() >= 0) {
            if (this.f8667i.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8667i.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.t0;
    }

    public int getTypeCommand() {
        return this.i0;
    }

    public int getValue() {
        return this.h0;
    }

    public int n(int i2) {
        switch (i2) {
            case 0:
                return this.O;
            case 1:
                return this.P;
            case 2:
                return this.Q;
            case 3:
                return this.R;
            case 4:
                return this.S;
            case 5:
                return this.T;
            case 6:
                return this.U;
            case 7:
                return this.V;
            case 8:
                return this.W;
            case 9:
                return this.a0;
            case 10:
                return this.b0;
            case 11:
                return this.c0;
            case 12:
                return this.d0;
            case 13:
                return this.e0;
            case 14:
                return this.f0;
            case 15:
                return this.g0;
            default:
                return 0;
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.k0) {
            this.n0.setColor(-65536);
            this.n0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.n0);
        }
        if (this.j0 && mbCanvas.g1) {
            canvas.drawBitmap(this.l0, getWidth() - this.l0.getWidth(), getHeight() - this.l0.getHeight(), this.m0);
        }
        if (this.o0) {
            this.n0.setColor(-16711936);
            this.n0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.n0);
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        this.F0 = true;
        this.w0.clear();
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        k();
    }

    @Override // androidx.appcompat.widget.y, android.widget.TextView
    protected void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        k();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.o0;
    }

    public String q(int i2) {
        switch (i2) {
            case 0:
                return this.f8670l;
            case 1:
                return this.f8671m;
            case 2:
                return this.f8672n;
            case 3:
                return this.o;
            case 4:
                return this.C;
            case 5:
                return this.D;
            case 6:
                return this.E;
            case 7:
                return this.F;
            case 8:
                return this.G;
            case 9:
                return this.H;
            case 10:
                return this.I;
            case 11:
                return this.J;
            case 12:
                return this.K;
            case 13:
                return this.L;
            case 14:
                return this.M;
            case 15:
                return this.N;
            default:
                return "";
        }
    }

    public void s(int i2, int i3, int i4, boolean z) {
        setTextColor(-1);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            setText(this.f8670l);
            setColorText(getCurrentTextColor());
            setBackgroundColor(0);
        }
        setKey(i4);
        this.f8667i.A(this.f8664f);
        setGravity(17);
        if (this.D0 == 0) {
            this.D0 = -1;
        }
        this.B0 = getResources().getDimension(R.dimen.text_size_small);
    }

    public void setAutoResizeText(boolean z) {
        this.r0 = z;
        if (z) {
            this.y0 = 500.0f;
        }
    }

    public void setColorText(int i2) {
        this.f8669k = i2;
        setTextColor(i2);
    }

    public void setConnectionError(boolean z) {
        this.k0 = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.j0 = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.o0 = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.p0 = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.q0 = i2;
    }

    public void setEnableFrameDynText(boolean z) {
        this.s0 = z;
        if (z) {
            int i2 = Build.VERSION.SDK_INT;
            Drawable drawable = i2 >= 21 ? getResources().getDrawable(R.drawable.bg_text, null) : getResources().getDrawable(R.drawable.bg_text);
            if (i2 < 16) {
                setBackgroundDrawable(drawable);
            } else {
                setBackground(drawable);
            }
        } else {
            setBackgroundColor(o(this.h0));
        }
        setText(r(this.h0));
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8665g = i2;
    }

    @Override // android.widget.TextView
    public void setLineSpacing(float f2, float f3) {
        super.setLineSpacing(f2, f3);
        this.z0 = f3;
        this.A0 = f2;
    }

    @Override // android.widget.TextView
    public void setLines(int i2) {
        super.setLines(i2);
        this.D0 = i2;
        k();
    }

    @Override // android.widget.TextView
    public void setMaxLines(int i2) {
        super.setMaxLines(i2);
        this.D0 = i2;
        k();
    }

    public void setMinTextSize(float f2) {
        this.B0 = f2;
        k();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8667i.G(i2);
        this.f8668j = i2;
    }

    @Override // android.widget.TextView
    public void setSingleLine() {
        super.setSingleLine();
        this.D0 = 1;
        k();
    }

    @Override // android.widget.TextView
    public void setSingleLine(boolean z) {
        super.setSingleLine(z);
        this.D0 = z ? 1 : -1;
        k();
    }

    public void setState(int i2) {
        if (this.h0 != i2) {
            if (this.i0 != 0 || (i2 >= 0 && i2 <= 15)) {
                this.h0 = i2;
                setText(r(i2));
                setBackgroundColor(o(i2));
            }
        }
    }

    @Override // android.widget.TextView
    public void setTextSize(float f2) {
        this.y0 = f2;
        this.w0.clear();
        k();
    }

    @Override // androidx.appcompat.widget.y, android.widget.TextView
    public void setTextSize(int i2, float f2) {
        Context context = getContext();
        this.y0 = TypedValue.applyDimension(i2, f2, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        this.w0.clear();
        k();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.t0 = j2;
    }

    public void setTypeCommand(int i2) {
        this.i0 = i2;
    }

    public boolean t() {
        return this.r0;
    }

    public boolean u() {
        return this.s0;
    }

    public void v(int i2, int i3) {
        switch (i2) {
            case 0:
                this.O = i3;
                break;
            case 1:
                this.P = i3;
                break;
            case 2:
                this.Q = i3;
                break;
            case 3:
                this.R = i3;
                break;
            case 4:
                this.S = i3;
                break;
            case 5:
                this.T = i3;
                break;
            case 6:
                this.U = i3;
                break;
            case 7:
                this.V = i3;
                break;
            case 8:
                this.W = i3;
                break;
            case 9:
                this.a0 = i3;
                break;
            case 10:
                this.b0 = i3;
                break;
            case 11:
                this.c0 = i3;
                break;
            case 12:
                this.d0 = i3;
                break;
            case 13:
                this.e0 = i3;
                break;
            case 14:
                this.f0 = i3;
                break;
            case 15:
                this.g0 = i3;
                break;
        }
    }

    public void w(int i2, String str) {
        switch (i2) {
            case 0:
                this.f8670l = str;
                break;
            case 1:
                this.f8671m = str;
                break;
            case 2:
                this.f8672n = str;
                break;
            case 3:
                this.o = str;
                break;
            case 4:
                this.C = str;
                break;
            case 5:
                this.D = str;
                break;
            case 6:
                this.E = str;
                break;
            case 7:
                this.F = str;
                break;
            case 8:
                this.G = str;
                break;
            case 9:
                this.H = str;
                break;
            case 10:
                this.I = str;
                break;
            case 11:
                this.J = str;
                break;
            case 12:
                this.K = str;
                break;
            case 13:
                this.L = str;
                break;
            case 14:
                this.M = str;
                break;
            case 15:
                this.N = str;
                break;
        }
    }
}
