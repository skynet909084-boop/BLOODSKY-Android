package ru.himik.nightscream.kascada.Logic.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.z;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class f extends View implements a, ru.himik.nightscream.kascada.s.a, z {
    public int C;
    public int D;
    public String E;
    public Rect F;
    public RectF G;
    public int H;
    public int I;
    public boolean J;
    public int K;
    public int L;
    public Paint M;
    public int N;
    public int O;
    public int P;
    public int Q;
    public int R;
    public int S;
    private long T;
    public Point U;
    boolean a;
    String b;
    long c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public a f9011d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f9012e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Paint f9013f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Paint f9014g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Point f9015h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f9016i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f9017j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f9018k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f9019l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f9020m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f9021n;
    public boolean o;

    public f(Context context) {
        super(context);
        this.a = false;
        this.b = "";
        this.c = 0L;
        this.f9012e = "RootVarIn";
        this.f9013f = new Paint();
        this.f9014g = new Paint();
        this.f9015h = new Point(0, 0);
        this.f9017j = 0;
        this.f9018k = false;
        this.f9019l = 1;
        this.f9020m = 0;
        this.f9021n = -1;
        this.o = false;
        this.C = 0;
        this.D = 0;
        this.E = "0";
        this.F = new Rect();
        this.G = new RectF();
        this.H = Math.round(getResources().getDimension(R.dimen.view_root_var_in_width));
        this.I = Math.round(getResources().getDimension(R.dimen.view_root_var_in_height));
        this.J = false;
        this.K = 0;
        this.L = 0;
        this.M = new Paint();
        this.N = -1;
        this.O = -1;
        this.P = -1;
        this.Q = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.R = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.S = (int) getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.T = 0L;
        this.U = new Point();
        this.H = Math.round(getResources().getDimension(R.dimen.view_root_var_in_width));
        this.I = Math.round(getResources().getDimension(R.dimen.view_root_var_in_height));
    }

    public f(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = false;
        this.b = "";
        this.c = 0L;
        this.f9012e = "RootVarIn";
        this.f9013f = new Paint();
        this.f9014g = new Paint();
        this.f9015h = new Point(0, 0);
        this.f9017j = 0;
        this.f9018k = false;
        this.f9019l = 1;
        this.f9020m = 0;
        this.f9021n = -1;
        this.o = false;
        this.C = 0;
        this.D = 0;
        this.E = "0";
        this.F = new Rect();
        this.G = new RectF();
        this.H = Math.round(getResources().getDimension(R.dimen.view_root_var_in_width));
        this.I = Math.round(getResources().getDimension(R.dimen.view_root_var_in_height));
        this.J = false;
        this.K = 0;
        this.L = 0;
        this.M = new Paint();
        this.N = -1;
        this.O = -1;
        this.P = -1;
        this.Q = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.R = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.S = (int) getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.T = 0L;
        this.U = new Point();
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.H = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_root_var_in_width)));
            this.I = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_root_var_in_height)));
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void a() {
        a aVar = this.f9011d;
        if (aVar != null) {
            aVar.k(this.f9017j);
        }
    }

    public void b() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void c() {
        a aVar = this.f9011d;
        if (aVar != null) {
            aVar.k(this.f9017j);
            this.f9011d = null;
            this.f9017j = 0;
        }
        this.f9021n = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void d(a aVar, int i2) {
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.U.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void e(a aVar) {
        this.f9011d = aVar;
        this.f9021n = aVar.getKey();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
    }

    public boolean g() {
        return this.o;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return getTypeFb();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return getNumScreen();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getFreeIn() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return getTypeFb();
    }

    public Object getIn() {
        return Boolean.FALSE;
    }

    public a getIn1() {
        return null;
    }

    public a getIn2() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getInvertOut() {
        return this.f9018k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getJsonMacroOutIfNeed() {
        if (q() == null || q().getTypeFb() != 135) {
            return "";
        }
        FB_MACRO fb_macro = (FB_MACRO) q();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(IMAPStore.ID_NAME, fb_macro.getName());
            jSONObject.put("x", (int) fb_macro.getX());
            jSONObject.put("y", (int) fb_macro.getY());
            jSONObject.put("numScreen", fb_macro.getNumScreen());
            return jSONObject.toString();
        } catch (JSONException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public JSONObject getJsonOther() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a, ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f9016i;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getKeyOut() {
        return this.f9021n;
    }

    public String getName() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumOnIn() {
        return this.f9017j;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumScreen() {
        return this.f9019l;
    }

    public Object getOut() {
        return null;
    }

    public Point getPointIn1() {
        return null;
    }

    public Point getPointIn2() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point getPointOut() {
        return this.f9015h;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.U;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getRootNameMacro() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public long getRootUniqueIdMacro() {
        return this.c;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdBeforeCopy() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdOutBeforeCopy() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveKey() {
        return this.f9020m;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveNumInBeforeCopy() {
        return this.O;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.T;
    }

    public int getTypeFb() {
        return 0;
    }

    public int getTypeVarOut() {
        return 0;
    }

    public boolean getVarConstant() {
        return false;
    }

    public float getVarFloatConstant() {
        return 0.0f;
    }

    public int getVarIntConstant() {
        return 0;
    }

    public boolean h() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void i() {
        this.f9018k = !this.f9018k;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void k(int i2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public a l(int i2) {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void m() {
        this.f9011d = null;
        this.f9017j = 0;
        this.f9021n = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point n(int i2) {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        return 0;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.J) {
            this.M.setColor(-16711936);
            this.M.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.M);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        this.f9013f.setFlags(1);
        this.f9013f.setStrokeWidth(this.R);
        this.f9014g.setFlags(1);
        this.f9014g.setTextAlign(Paint.Align.CENTER);
        this.f9014g.setTextSize(this.I - (this.Q / 2));
        Paint paint = this.f9014g;
        String str = this.E;
        paint.getTextBounds(str, 0, str.length(), this.F);
        this.f9014g.setColor(getResources().getColor(R.color.text_color_logic));
        this.H = this.F.width() + (this.Q * 3);
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        int i4 = this.H;
        layoutParams.width = i4;
        setMeasuredDimension(i4, this.I);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public a q() {
        return this.f9011d;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        this.f9015h.set(getWidth() + ((int) getX()), (getHeight() / 2) + ((int) getY()));
    }

    public void s(int i2, int i3, int i4, boolean z) {
        getLayoutParams().height = this.I;
        getLayoutParams().width = this.H;
        setY(i3 - (this.I / 2));
        setX(i2 - (this.H / 2));
        setKey(i4);
        setBackgroundColor(0);
    }

    public void setActionExecute(int i2) {
    }

    public void setConstant(boolean z) {
        this.o = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.J = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.K = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.L = i2;
    }

    public void setFont(String str) {
    }

    public void setIn(Object obj) {
    }

    public void setInMacro(boolean z) {
        this.a = z;
    }

    public void setInvert(boolean z) {
        this.f9018k = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f9016i = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setKeyOut(int i2) {
        if (i2 == this.f9020m) {
            i2 = -1;
        }
        this.f9021n = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setNumOnIn(int i2) {
        this.f9017j = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f9019l = i2;
    }

    public void setOut(Object obj) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootNameMacro(String str) {
        this.b = str;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootUniqueIdMacro(long j2) {
        this.c = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdBeforeCopy(int i2) {
        this.N = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdOutBeforeCopy(int i2) {
        this.P = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveKey(int i2) {
        this.f9020m = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveNumInBeforeCopy(int i2) {
        this.O = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.T = j2;
    }

    public void setVarConstant(boolean z) {
    }

    public void setVarFloatConstant(float f2) {
    }

    public void setVarIntConstant(int i2) {
    }

    public boolean t() {
        return this.a;
    }
}
