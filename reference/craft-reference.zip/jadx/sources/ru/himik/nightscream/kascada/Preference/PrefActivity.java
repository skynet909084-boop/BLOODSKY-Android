package ru.himik.nightscream.kascada.Preference;

import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class PrefActivity extends androidx.appcompat.app.d {
    TextView a;
    boolean b = false;

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PrefActivity.this.onBackPressed();
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.layout_preference);
        w0 w0Var = new w0();
        TextView textView = (TextView) findViewById(R.id.textListValue);
        this.a = textView;
        w0Var.r1 = textView;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getResources().getString(R.string.pref_component));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
            toolbar.setNavigationOnClickListener(new a());
        }
        Intent intent = getIntent();
        int i2 = 0;
        boolean booleanExtra = intent.getBooleanExtra("portraitMode", false);
        this.b = booleanExtra;
        if (booleanExtra) {
            setRequestedOrientation(1);
        }
        int intExtra = intent.getIntExtra("idComponent", 0);
        if (intExtra == 7) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            try {
                JSONObject jSONObject = new JSONObject(intent.getStringExtra("params"));
                w0Var.a = jSONObject.get("text0").toString();
                w0Var.b = jSONObject.get("text1").toString();
                w0Var.c = jSONObject.get("text2").toString();
                w0Var.f9124d = jSONObject.get("text3").toString();
                w0Var.f9125e = jSONObject.get("text4").toString();
                w0Var.f9126f = jSONObject.get("text5").toString();
                w0Var.f9127g = jSONObject.get("text6").toString();
                w0Var.f9128h = jSONObject.get("text7").toString();
                w0Var.f9129i = jSONObject.get("text8").toString();
                w0Var.f9130j = jSONObject.get("text9").toString();
                w0Var.f9131k = jSONObject.get("text10").toString();
                w0Var.f9132l = jSONObject.get("text11").toString();
                w0Var.f9133m = jSONObject.get("text12").toString();
                w0Var.f9134n = jSONObject.get("text13").toString();
                w0Var.o = jSONObject.get("text14").toString();
                w0Var.C = jSONObject.get("text15").toString();
                w0Var.D = ((Integer) jSONObject.get("sizeText")).intValue();
                w0Var.E = ((Integer) jSONObject.get("typeCommandDynText")).intValue();
                w0Var.C1 = intent.getBooleanExtra("autoResizeText", true);
                w0Var.l1 = intent.getBooleanExtra("enableFrameDynText", false);
            } catch (JSONException unused) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_pref_dyn_text), 0).show();
            }
        } else if (intExtra == 14) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.n0 = intent.getIntExtra("EditGraphPeriodPref", 1);
            w0Var.o0 = intent.getIntExtra("EditGraphCountPointPref", 10);
            w0Var.u0 = intent.getIntExtra("typeGraph", 1);
            w0Var.p0 = intent.getStringExtra("nameSeries1");
            w0Var.q0 = intent.getStringExtra("nameSeries2");
            w0Var.r0 = intent.getStringExtra("nameSeries3");
            w0Var.s0 = intent.getStringExtra("nameSeries4");
            w0Var.t0 = intent.getIntExtra("countGraphChannel", 1);
        } else if (intExtra == 5) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.z1 = intent.getIntExtra("typeRequest", 1);
        } else if (intExtra == 15) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.v0 = intent.getStringExtra("fileName");
            w0Var.w0 = intent.getStringExtra("typeRecord");
            w0Var.x0 = intent.getIntExtra("countChannel", 0);
            w0Var.y0 = intent.getIntExtra("registerArchive", 0);
            w0Var.A0 = intent.getStringExtra("connectionDevices");
            w0Var.z0 = intent.getIntExtra("selectPositionDevTriggerDataArchive", 1);
            intent.getStringExtra("ArchiveEmailLogin_Val");
            intent.getStringExtra("ArchiveEmailPassword_Val");
            intent.getStringExtra("ArchiveEmailTo_Val");
            intent.getIntExtra("ArchiveRegisterSendMail_Val", 0);
            intent.getIntExtra("ArchiveBitSendMail_Val", 0);
            w0Var.B0 = intent.getIntExtra("ArchiveRegisterReset_Val", 0);
            w0Var.D0 = intent.getIntExtra("ArchiveBitReset_Val", 0);
            w0Var.F0 = intent.getBooleanExtra("ArchiveIsReset_Val", false);
            w0Var.H0 = intent.getBooleanExtra("optionChannel", false);
            w0Var.I0 = intent.getStringExtra("typeRecordOptionChannel");
            w0Var.J0 = intent.getIntExtra("regArchiveOptionalChannel", 0);
            w0Var.K0 = intent.getIntExtra("countArchiveOptionalChannelASCII", 2);
            w0Var.G0 = intent.getBooleanExtra("isSendToCloudArchive", false);
            w0Var.C0 = intent.getIntExtra("ArchiveRegisterSendToCloudArchive_Val", 0);
            w0Var.E0 = intent.getIntExtra("ArchiveBitSendToCloudArchive_Val", 0);
        } else if (intExtra == 10) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.T = intent.getStringExtra("phone");
            w0Var.U = intent.getStringExtra("message");
            w0Var.V = intent.getBooleanExtra("option", false);
            w0Var.W = intent.getIntExtra("optionRegister", 0);
            w0Var.X = intent.getIntExtra("optionCountRegister", 0);
        } else if (intExtra == 18) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.N0 = intent.getStringExtra("smsRecPhone");
            w0Var.M0 = intent.getStringExtra(IMAPStore.ID_COMMAND);
            w0Var.O0 = intent.getBooleanExtra("strob", false);
            w0Var.P0 = intent.getIntExtra("regStrob", 0);
            w0Var.Q0 = intent.getIntExtra("bitStrob", 0);
            w0Var.R0 = intent.getIntExtra("listTypeCommandSmsReceive", 0);
        } else if (intExtra == 11) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.Y = intent.getBooleanExtra("showText", false);
            w0Var.D = intent.getIntExtra("sizeText", 50);
            w0Var.Z = intent.getBooleanExtra("showScale", true);
            w0Var.b0 = intent.getIntExtra("max", 100);
            w0Var.a0 = intent.getIntExtra("min", 0);
        } else if (intExtra == 12) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.e0 = intent.getIntExtra("gaugeMax", 100);
            w0Var.D = intent.getIntExtra("sizeText", 50);
            w0Var.Y = intent.getBooleanExtra("showText", true);
            w0Var.c0 = intent.getIntExtra("firstPoint", 0);
            w0Var.d0 = intent.getIntExtra("secondPoint", 0);
        } else if (intExtra == 13) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.A1 = intent.getIntExtra("seekMax", 100);
        } else if (intExtra == 16) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.L0 = intent.getStringExtra("pathGif");
        } else if (intExtra == 17) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            w0Var.i1 = intent.getIntExtra("typeCommandDynPicture", 0);
            w0Var.j1 = intent.getIntExtra("editTouchX", 0);
            w0Var.k1 = intent.getIntExtra("editTouchY", 0);
            w0Var.S0 = intent.getStringExtra("pathPic_0");
            w0Var.T0 = intent.getStringExtra("pathPic_1");
            w0Var.U0 = intent.getStringExtra("pathPic_2");
            w0Var.V0 = intent.getStringExtra("pathPic_3");
            w0Var.W0 = intent.getStringExtra("pathPic_4");
            w0Var.X0 = intent.getStringExtra("pathPic_5");
            w0Var.Y0 = intent.getStringExtra("pathPic_6");
            w0Var.Z0 = intent.getStringExtra("pathPic_7");
            w0Var.a1 = intent.getStringExtra("pathPic_8");
            w0Var.b1 = intent.getStringExtra("pathPic_9");
            w0Var.c1 = intent.getStringExtra("pathPic_10");
            w0Var.d1 = intent.getStringExtra("pathPic_11");
            w0Var.e1 = intent.getStringExtra("pathPic_12");
            w0Var.f1 = intent.getStringExtra("pathPic_13");
            w0Var.g1 = intent.getStringExtra("pathPic_14");
            w0Var.h1 = intent.getStringExtra("pathPic_15");
        } else {
            if (intExtra == 8) {
                w0Var.F = intent.getStringExtra("text");
                w0Var.D = intent.getIntExtra("sizeText", 30);
                w0Var.G = intent.getIntExtra("idComponent", 0);
                w0Var.K = intent.getFloatExtra("min", 0.0f);
                w0Var.L = intent.getFloatExtra("max", 65535.0f);
                w0Var.o1 = intent.getStringExtra("editPassword");
                w0Var.M = intent.getIntExtra("type", 0);
                w0Var.Q = intent.getIntExtra("typeInt", 0);
                w0Var.R = intent.getIntExtra("countNumAfterPointEditNumber", 0);
                w0Var.N = intent.getBooleanExtra("fontChange", false);
                w0Var.S = intent.getBooleanExtra("enableFrameEditNumber", false);
            } else if (intExtra == 20) {
                w0Var.F = intent.getStringExtra("text");
                w0Var.D = intent.getIntExtra("sizeText", 30);
                w0Var.G = intent.getIntExtra("idComponent", 0);
                w0Var.p1 = intent.getStringExtra("textValue");
                w0Var.q1 = intent.getBooleanExtra("checkNoChange", false);
                w0Var.J = intent.getBooleanExtra("checkVisible", false);
                w0Var.s1 = intent.getIntExtra("listValue", 0);
                this.a.setVisibility(0);
            } else if (intExtra == 1) {
                w0Var.G = intent.getIntExtra("idComponent", 0);
                w0Var.J = intent.getBooleanExtra("checkVisible", false);
            } else if (intExtra == 6) {
                w0Var.G = intent.getIntExtra("idComponent", 0);
                w0Var.F = intent.getStringExtra("text");
                w0Var.D = intent.getIntExtra("sizeText", 30);
                w0Var.J = intent.getBooleanExtra("checkVisible", false);
                w0Var.P = intent.getIntExtra("typeButtonMode", 0);
                w0Var.C1 = intent.getBooleanExtra("autoResizeText", true);
            } else if (intExtra == 21) {
                w0Var.G = intent.getIntExtra("idComponent", 0);
                w0Var.S0 = intent.getStringExtra("pathSound_0");
                w0Var.T0 = intent.getStringExtra("pathSound_1");
                w0Var.U0 = intent.getStringExtra("pathSound_2");
                w0Var.V0 = intent.getStringExtra("pathSound_3");
                w0Var.W0 = intent.getStringExtra("pathSound_4");
                w0Var.X0 = intent.getStringExtra("pathSound_5");
                w0Var.Y0 = intent.getStringExtra("pathSound_6");
                w0Var.Z0 = intent.getStringExtra("pathSound_7");
            } else {
                if (intExtra == 19) {
                    w0Var.G = intent.getIntExtra("idComponent", 0);
                    w0Var.t1 = intent.getIntExtra("mode", 0);
                    w0Var.u1 = intent.getIntExtra("regMode", 0);
                    w0Var.v1 = intent.getIntExtra("bitMode", 0);
                } else if (intExtra == 4) {
                    w0Var.F = intent.getStringExtra("text");
                    w0Var.D = intent.getIntExtra("sizeText", 30);
                    w0Var.G = intent.getIntExtra("idComponent", 0);
                    w0Var.H = intent.getIntExtra("digit", 4);
                    w0Var.I = intent.getIntExtra("divisor", 0);
                    w0Var.M = intent.getIntExtra("type", 1);
                    w0Var.N = intent.getBooleanExtra("fontChange", false);
                    w0Var.O = intent.getBooleanExtra("enableFrameRegister", false);
                } else if (intExtra == 22) {
                    w0Var.G = intExtra;
                    w0Var.B1 = intent.getIntExtra("countBit", 1);
                    w0Var.t1 = intent.getIntExtra("mode", 0);
                    w0Var.u1 = intent.getIntExtra("regMode", 0);
                    w0Var.v1 = intent.getIntExtra("bitMode", 0);
                } else if (intExtra == 24) {
                    w0Var.G = intExtra;
                    w0Var.f0 = intent.getIntExtra("gaugeMin", 0);
                    w0Var.g0 = intent.getIntExtra("gaugeMax", 100);
                    w0Var.i0 = intent.getIntExtra("sizeText", 50);
                    w0Var.h0 = intent.getIntExtra("countTextScale", 5);
                    w0Var.j0 = intent.getIntExtra("percentLowScale", 0);
                    w0Var.k0 = intent.getIntExtra("percentMediumScale", 0);
                    w0Var.m0 = intent.getStringExtra("gaugeIndicatorName");
                    w0Var.l0 = intent.getBooleanExtra("hideBackground", false);
                } else if (intExtra == 2) {
                    w0Var.G = intExtra;
                    w0Var.F = intent.getStringExtra("text");
                    w0Var.D = intent.getIntExtra("sizeText", 30);
                    w0Var.C1 = intent.getBooleanExtra("autoResizeText", true);
                    w0Var.D1 = intent.getBooleanExtra("enableFrameLabel", false);
                } else if (intExtra == 25) {
                    w0Var.G = intExtra;
                    w0Var.F = intent.getStringExtra("text");
                    w0Var.E1 = intent.getStringExtra("title");
                    w0Var.F1 = intent.getStringExtra("body");
                    w0Var.G1 = intent.getStringExtra("to");
                } else {
                    w0Var.F = intent.getStringExtra("text");
                    w0Var.D = intent.getIntExtra("sizeText", 30);
                    i2 = 0;
                    w0Var.G = intent.getIntExtra("idComponent", 0);
                    w0Var.H = intent.getIntExtra("digit", 4);
                    w0Var.I = intent.getIntExtra("divisor", 0);
                    w0Var.J = intent.getBooleanExtra("checkVisible", false);
                    w0Var.K = intent.getIntExtra("min", 0);
                    w0Var.L = intent.getIntExtra("max", 65535);
                }
                w0Var.w1 = intent.getByteExtra("gatewayCountReg", (byte) 1);
                w0Var.x1 = intent.getStringExtra("connectionDevices");
                w0Var.y1 = intent.getIntExtra("selectPositionDevTrigger", 1);
            }
            i2 = 0;
        }
        if (intExtra == 26) {
            w0Var.G = intent.getIntExtra("idComponent", i2);
            try {
                JSONObject jSONObject2 = new JSONObject(intent.getStringExtra("params"));
                w0Var.a = jSONObject2.get("link0").toString();
                w0Var.b = jSONObject2.get("link1").toString();
                w0Var.c = jSONObject2.get("link2").toString();
                w0Var.f9124d = jSONObject2.get("link3").toString();
                w0Var.f9125e = jSONObject2.get("link4").toString();
                w0Var.f9126f = jSONObject2.get("link5").toString();
                w0Var.f9127g = jSONObject2.get("link6").toString();
                w0Var.f9128h = jSONObject2.get("link7").toString();
                w0Var.f9129i = jSONObject2.get("link8").toString();
                w0Var.f9130j = jSONObject2.get("link9").toString();
                w0Var.f9131k = jSONObject2.get("link10").toString();
                w0Var.f9132l = jSONObject2.get("link11").toString();
                w0Var.f9133m = jSONObject2.get("link12").toString();
                w0Var.f9134n = jSONObject2.get("link13").toString();
                w0Var.o = jSONObject2.get("link14").toString();
                w0Var.C = jSONObject2.get("link15").toString();
            } catch (JSONException unused2) {
                Toast.makeText(getApplicationContext(), "error web view pref", 0).show();
            }
        } else if (intExtra == 28) {
            w0Var.G = intExtra;
            w0Var.H1 = intent.getStringExtra("titleEmail");
            w0Var.I1 = intent.getStringExtra("bodyEmail");
            w0Var.J1 = intent.getStringExtra("emailLogin");
            w0Var.K1 = intent.getStringExtra("emailPassword");
            w0Var.L1 = intent.getStringExtra("emailTo");
        }
        if (intExtra == 27) {
            w0Var.G = intent.getIntExtra("idComponent", 0);
            try {
                JSONObject jSONObject3 = new JSONObject(intent.getStringExtra("params"));
                w0Var.a = jSONObject3.get("textVoice0").toString();
                w0Var.b = jSONObject3.get("textVoice1").toString();
                w0Var.c = jSONObject3.get("textVoice2").toString();
                w0Var.f9124d = jSONObject3.get("textVoice3").toString();
                w0Var.f9125e = jSONObject3.get("textVoice4").toString();
                w0Var.f9126f = jSONObject3.get("textVoice5").toString();
                w0Var.f9127g = jSONObject3.get("textVoice6").toString();
                w0Var.f9128h = jSONObject3.get("textVoice7").toString();
                w0Var.f9129i = jSONObject3.get("textVoice8").toString();
                w0Var.f9130j = jSONObject3.get("textVoice9").toString();
                w0Var.f9131k = jSONObject3.get("textVoice10").toString();
                w0Var.f9132l = jSONObject3.get("textVoice11").toString();
                w0Var.f9133m = jSONObject3.get("textVoice12").toString();
                w0Var.f9134n = jSONObject3.get("textVoice13").toString();
                w0Var.o = jSONObject3.get("textVoice14").toString();
                w0Var.C = jSONObject3.get("textVoice15").toString();
            } catch (JSONException unused3) {
                Toast.makeText(getApplicationContext(), "error voice recognition pref", 0).show();
            }
        }
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame, w0Var).commit();
        fragmentManager.executePendingTransactions();
    }
}
