package ru.himik.nightscream.kascada.Preference.y0;

import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import org.videolan.libvlc.media.MediaPlayer;
import ru.himik.nightscream.kascada.CustomComponents.y;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b extends DialogFragment {
    y c;
    int a = 1000;
    int b = MediaPlayer.MEDIA_INFO_BAD_INTERLEAVING;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    View.OnClickListener f9159d = new a();

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            y yVar;
            int i2;
            switch (view.getId()) {
                case R.id.r1 /* 2131296957 */:
                    yVar = b.this.c;
                    i2 = 1;
                    break;
                case R.id.r2 /* 2131296958 */:
                    yVar = b.this.c;
                    i2 = 2;
                    break;
                case R.id.r3 /* 2131296959 */:
                    yVar = b.this.c;
                    i2 = 3;
                    break;
                case R.id.r4 /* 2131296960 */:
                    yVar = b.this.c;
                    i2 = 4;
                    break;
                case R.id.r5 /* 2131296961 */:
                    yVar = b.this.c;
                    i2 = 5;
                    break;
                case R.id.r6 /* 2131296962 */:
                    yVar = b.this.c;
                    i2 = 6;
                    break;
                case R.id.r7 /* 2131296963 */:
                    yVar = b.this.c;
                    i2 = 7;
                    break;
                case R.id.r8 /* 2131296964 */:
                    yVar = b.this.c;
                    i2 = 8;
                    break;
                default:
                    return;
            }
            yVar.setImageState(i2);
            b.this.getDialog().dismiss();
        }
    }

    public void a(y yVar) {
        this.c = yVar;
    }

    public void b(int i2, int i3) {
        this.a = i2;
        this.b = i3;
    }

    @Override // android.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        getDialog().setTitle(getActivity().getResources().getString(R.string.dialog_choose_image));
        getDialog().setCanceledOnTouchOutside(true);
        View viewInflate = layoutInflater.inflate(R.layout.select_image_switch, viewGroup, false);
        viewInflate.findViewById(R.id.r1).setOnClickListener(this.f9159d);
        viewInflate.findViewById(R.id.r2).setOnClickListener(this.f9159d);
        viewInflate.findViewById(R.id.r3).setOnClickListener(this.f9159d);
        viewInflate.findViewById(R.id.r4).setOnClickListener(this.f9159d);
        viewInflate.findViewById(R.id.r5).setOnClickListener(this.f9159d);
        viewInflate.findViewById(R.id.r6).setOnClickListener(this.f9159d);
        viewInflate.findViewById(R.id.r7).setOnClickListener(this.f9159d);
        viewInflate.findViewById(R.id.r8).setOnClickListener(this.f9159d);
        return viewInflate;
    }

    @Override // android.app.Fragment
    public void onResume() {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout((int) (((double) this.a) * 0.75d), this.b);
        window.setGravity(17);
    }
}
