package ru.himik.nightscream.kascada.Logic;

/* JADX INFO: loaded from: classes2.dex */
public interface e {
    int getBit();

    int getReg();

    void j(int i2, int i3);
}
