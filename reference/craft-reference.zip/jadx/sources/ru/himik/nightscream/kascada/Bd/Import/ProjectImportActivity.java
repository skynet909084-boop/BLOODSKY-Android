package ru.himik.nightscream.kascada.Bd.Import;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import com.yandex.metrica.YandexMetrica;
import f.c.a.m;
import java.io.File;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import kotlin.i0.r;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.n;
import ru.himik.nightscream.kascada.r.c0;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public final class ProjectImportActivity extends androidx.appcompat.app.d implements i {
    private final h a;
    private final g b;
    public AlertDialog c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f8587d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ru.himik.nightscream.kascada.d0.c f8588e;

    public static final class a extends f.c.a.a {
        final /* synthetic */ c0 b;
        final /* synthetic */ ProjectImportActivity c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ String f8589d;

        a(c0 c0Var, ProjectImportActivity projectImportActivity, String str) {
            this.b = c0Var;
            this.c = projectImportActivity;
            this.f8589d = str;
        }

        @Override // f.c.a.a
        public void a(int i2, int i3, String str) {
            super.a(i2, i3, str);
            this.b.dismiss();
            ProjectImportActivity projectImportActivity = this.c;
            String string = projectImportActivity.getString(R.string.error_download_zip);
            kotlin.b0.d.j.c(string, "getString(R.string.error_download_zip)");
            projectImportActivity.c(string);
        }

        @Override // f.c.a.a
        public void b(int i2, long j2, long j3) {
            super.b(i2, j2, j3);
            TextView textViewA = this.b.a();
            if (textViewA == null) {
                return;
            }
            textViewA.setText(this.c.getString(R.string.download_file_wait) + ' ' + ((int) ((j2 / j3) * 100.0f)) + '%');
        }

        @Override // f.c.a.a
        public void c(int i2) {
            super.c(i2);
            TextView textViewA = this.b.a();
            if (textViewA == null) {
                return;
            }
            textViewA.setText(this.c.getString(R.string.download_file_retry));
        }

        @Override // f.c.a.a
        public void d(int i2, long j2) {
            super.d(i2, j2);
            TextView textViewA = this.b.a();
            if (textViewA == null) {
                return;
            }
            textViewA.setText(this.c.getString(R.string.download_file_wait));
        }

        @Override // f.c.a.a
        public void e(int i2, String str) {
            super.e(i2, str);
            this.c.getString(R.string.download_file_unpack);
            this.b.dismiss();
            this.c.a.k(new File(kotlin.b0.d.j.i(n.a.e(), r.z0(this.f8589d, "/", null, 2, null))), this.f8589d);
        }
    }

    public ProjectImportActivity() {
        h hVar = new h();
        this.a = hVar;
        this.b = new g(this, hVar.e());
        this.f8587d = "";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void h(String str) {
        Log.d("NS", str);
    }

    private final void k() {
        View viewFindViewById = findViewById(R.id.toolbar);
        Objects.requireNonNull(viewFindViewById, "null cannot be cast to non-null type androidx.appcompat.widget.Toolbar");
        Toolbar toolbar = (Toolbar) viewFindViewById;
        toolbar.setTitle(getResources().getString(R.string.kascada));
        toolbar.setSubtitle(getResources().getString(R.string.import_project));
        setSupportActionBar(toolbar);
        androidx.appcompat.app.a supportActionBar = getSupportActionBar();
        kotlin.b0.d.j.b(supportActionBar);
        supportActionBar.s(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Import.e
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ProjectImportActivity.l(this.a, view);
            }
        });
        i().f9198f.setAdapter((ListAdapter) this.b);
        this.a.i(this);
        i().f9198f.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Import.d
            @Override // android.widget.AdapterView.OnItemClickListener
            public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                ProjectImportActivity.m(this.a, adapterView, view, i2, j2);
            }
        });
        if (this.f8587d.length() == 0) {
            y();
        }
        i().c.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Import.f
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ProjectImportActivity.n(this.a, view);
            }
        });
        i().b.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Import.b
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ProjectImportActivity.o(this.a, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void l(ProjectImportActivity projectImportActivity, View view) {
        kotlin.b0.d.j.d(projectImportActivity, "this$0");
        projectImportActivity.onBackPressed();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void m(ProjectImportActivity projectImportActivity, AdapterView adapterView, View view, int i2, long j2) {
        kotlin.b0.d.j.d(projectImportActivity, "this$0");
        projectImportActivity.a.h(i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void n(ProjectImportActivity projectImportActivity, View view) {
        kotlin.b0.d.j.d(projectImportActivity, "this$0");
        new f.f.c.a0.a.a(projectImportActivity).i("QR_CODE");
        new f.f.c.a0.a.a(projectImportActivity).e();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void o(ProjectImportActivity projectImportActivity, View view) {
        kotlin.b0.d.j.d(projectImportActivity, "this$0");
        if (projectImportActivity.i().f9196d.getText().toString().length() == 0) {
            g.a.a.e.c(MyApplication.b().h0, projectImportActivity.getString(R.string.link_empty), 0, true).show();
        } else {
            projectImportActivity.v(projectImportActivity.i().f9196d.getText().toString());
        }
    }

    private final void y() {
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(this).create();
        alertDialogCreate.setCancelable(false);
        View viewInflate = getLayoutInflater().inflate(R.layout.dialog_choose_import_source, (ViewGroup) null);
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Import.a
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ProjectImportActivity.z(this.a, alertDialogCreate, view);
            }
        };
        viewInflate.findViewById(R.id.ll_download).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.ll_local_import).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.ll_local_import_old).setOnClickListener(onClickListener);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void z(ProjectImportActivity projectImportActivity, AlertDialog alertDialog, View view) {
        kotlin.b0.d.j.d(projectImportActivity, "this$0");
        switch (view.getId()) {
            case R.id.ll_download /* 2131296778 */:
                projectImportActivity.i().f9197e.setVisibility(0);
                projectImportActivity.i().f9198f.setVisibility(8);
                break;
            case R.id.ll_local_import /* 2131296779 */:
                projectImportActivity.i().f9197e.setVisibility(8);
                projectImportActivity.i().f9198f.setVisibility(0);
                break;
            case R.id.ll_local_import_old /* 2131296780 */:
                alertDialog.dismiss();
                Intent intent = new Intent();
                intent.putExtra("old_load", true);
                projectImportActivity.setResult(-1, intent);
                projectImportActivity.finish();
                return;
            default:
                return;
        }
        alertDialog.dismiss();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Import.i
    public void a() {
        Intent intent = new Intent();
        intent.putExtra("autostart", true);
        setResult(-1, intent);
        finish();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Import.i
    public void b() {
        g.a.a.e.b(this, getString(R.string.error_while_unzipping), 1).show();
        j().cancel();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Import.i
    public void c(String str) {
        kotlin.b0.d.j.d(str, "strError");
        g.a.a.e.b(this, str, 1).show();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Import.i
    public void d(String str) {
        kotlin.b0.d.j.d(str, "fileName");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.project_importing_msg));
        builder.setMessage(getString(R.string.it_will_take_a_while_wait));
        builder.setCancelable(false);
        AlertDialog alertDialogCreate = builder.create();
        kotlin.b0.d.j.c(alertDialogCreate, "builderUnzipDialog.create()");
        x(alertDialogCreate);
        j().show();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Import.i
    public void e() {
        j().cancel();
    }

    public final void g(f.c.a.a aVar, String str) {
        kotlin.b0.d.j.d(aVar, "callback");
        kotlin.b0.d.j.d(str, "url");
        l.c0 c0Var = new l.c0();
        f.c.a.e.a aVar2 = new f.c.a.e.a();
        aVar2.f(MyApplication.b().h0);
        aVar2.g(f.c.a.k.g(c0Var));
        aVar2.i(3);
        aVar2.h(new f.c.a.j() { // from class: ru.himik.nightscream.kascada.Bd.Import.c
            @Override // f.c.a.j
            public final void a(String str2) {
                ProjectImportActivity.h(str2);
            }
        });
        f.c.a.e eVarE = aVar2.e();
        kotlin.b0.d.j.c(eVarE, "Builder().context(MyAppl…\n                .build()");
        n.a aVar3 = n.a;
        File file = new File(aVar3.e());
        if (!file.exists()) {
            file.mkdirs();
        }
        String strI = kotlin.b0.d.j.i(aVar3.e(), r.z0(str, "/", null, 2, null));
        try {
            File file2 = new File(kotlin.b0.d.j.i(strI, ".tmp"));
            if (file2.exists()) {
                file2.delete();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            YandexMetrica.reportError("ProjectImportActivity delete .tmp", "Не удалось удалить временный файл", e2);
        }
        f.c.a.f.b bVar = new f.c.a.f.b();
        bVar.t(str);
        bVar.r(3);
        TimeUnit timeUnit = TimeUnit.SECONDS;
        bVar.q(2L, timeUnit);
        bVar.p(1L, timeUnit);
        bVar.o(m.HIGH);
        bVar.k(2);
        bVar.m(strI);
        bVar.n(aVar);
        f.c.a.f fVarL = bVar.l();
        kotlin.b0.d.j.c(fVarL, "Builder()\n              …\n                .build()");
        eVarE.a(fVarL);
    }

    public final ru.himik.nightscream.kascada.d0.c i() {
        ru.himik.nightscream.kascada.d0.c cVar = this.f8588e;
        if (cVar != null) {
            return cVar;
        }
        kotlin.b0.d.j.m("binding");
        throw null;
    }

    public final AlertDialog j() {
        AlertDialog alertDialog = this.c;
        if (alertDialog != null) {
            return alertDialog;
        }
        kotlin.b0.d.j.m("dialogUnzip");
        throw null;
    }

    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onActivityResult(int i2, int i3, Intent intent) {
        f.f.c.a0.a.b bVarG = f.f.c.a0.a.a.g(i2, i3, intent);
        if (bVarG == null) {
            super.onActivityResult(i2, i3, intent);
        } else if (bVarG.a() == null) {
            Toast.makeText(this, getString(R.string.cancelled), 1).show();
        } else {
            i().f9196d.setText(bVarG.a());
            v(i().f9196d.getText().toString());
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ru.himik.nightscream.kascada.d0.c cVarC = ru.himik.nightscream.kascada.d0.c.c(getLayoutInflater());
        kotlin.b0.d.j.c(cVarC, "inflate(layoutInflater)");
        w(cVarC);
        LinearLayout linearLayoutB = i().b();
        kotlin.b0.d.j.c(linearLayoutB, "binding.root");
        setContentView(linearLayoutB);
        getWindow().setFlags(1024, 1024);
        if (getIntent().hasExtra("urlUpdate")) {
            MyApplication.b().f9045m = "";
            String stringExtra = getIntent().getStringExtra("urlUpdate");
            String str = stringExtra != null ? stringExtra : "";
            this.f8587d = str;
            v(str);
        }
        k();
        File file = new File(n.a.e());
        if (file.exists()) {
            return;
        }
        file.mkdirs();
    }

    public final void v(String str) {
        kotlin.b0.d.j.d(str, "url");
        c0 c0Var = new c0(this);
        a aVar = new a(c0Var, this, str);
        c0Var.show();
        g(aVar, str);
    }

    public final void w(ru.himik.nightscream.kascada.d0.c cVar) {
        kotlin.b0.d.j.d(cVar, "<set-?>");
        this.f8588e = cVar;
    }

    public final void x(AlertDialog alertDialog) {
        kotlin.b0.d.j.d(alertDialog, "<set-?>");
        this.c = alertDialog;
    }
}
