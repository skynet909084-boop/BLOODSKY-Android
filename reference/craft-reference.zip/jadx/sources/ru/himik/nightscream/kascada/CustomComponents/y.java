package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class y extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    Drawable C;
    Drawable D;
    int E;
    boolean F;
    int G;
    int H;
    private long I;
    public Point J;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8940d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8941e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8942f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8943g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f8944h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f8945i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    boolean f8946j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f8947k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f8948l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    Bitmap f8949m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    Paint f8950n;
    Paint o;

    public y(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_switch);
        this.f8940d = 1;
        this.f8942f = (byte) 5;
        this.f8943g = new b();
        this.f8944h = false;
        this.f8949m = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.f8950n = new Paint();
        this.o = new Paint();
        this.E = 1;
        this.F = false;
        this.G = 0;
        this.H = 0;
        this.I = 0L;
        this.J = new Point();
    }

    public void a(int i2) {
        setText(this.c + " " + i2);
    }

    public void b(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setImageState(this.E);
        if (Build.VERSION.SDK_INT < 16) {
            setBackgroundDrawable(this.D);
        } else {
            setBackground(this.D);
        }
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            a(i4);
        }
        setKey(i4);
        this.f8943g.A(this.f8940d);
    }

    public void c(int i2, int i3, int i4, boolean z, int i5) {
        setPadding(10, 10, 10, 10);
        setImageState(this.E);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_height)) * 2;
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i6 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i6) * i6);
            setX(((i2 - (iRound / 2)) / i6) * i6);
        }
        setKey(i4);
        this.f8943g.A(this.f8940d);
    }

    public boolean d() {
        return this.f8946j;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.J.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e() {
        setBackground(this.f8944h ? this.C : this.D);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8943g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8940d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8945i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.G;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8940d;
    }

    public int getImagePosition() {
        return this.E;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8943g.l());
        jSONObject.put("addressRegister", this.f8943g.c());
        jSONObject.put("addressBit", (int) this.f8943g.a());
        jSONObject.put("typeRequest", (int) this.f8943g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("visibleInWork", d());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("imagePosition", getImagePosition());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8941e;
    }

    public int getNumScreen() {
        return this.f8945i;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8943g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8943g.l() >= 100) {
            this.f8943g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8943g.c() + "." + ((int) this.f8943g.a());
        }
        this.f8943g.u((byte) MyApplication.b().E.get(this.f8943g.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8943g.b()) + "#" + this.f8943g.c() + "." + ((int) this.f8943g.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8943g.l() >= 0) {
            if (this.f8943g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8943g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.I;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8948l) {
            this.o.setColor(-65536);
            this.o.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.o);
        }
        if (this.f8947k && mbCanvas.g1) {
            canvas.drawBitmap(this.f8949m, getWidth() - this.f8949m.getWidth(), getHeight() - this.f8949m.getHeight(), this.f8950n);
        }
        if (this.F) {
            this.o.setColor(-16711936);
            this.o.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.o);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.F;
    }

    public void setConnectionError(boolean z) {
        this.f8948l = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8947k = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.F = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.G = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.H = i2;
    }

    public void setFont(String str) {
    }

    /* JADX WARN: Code duplicated, block: B:27:0x0077 A[PHI: r0 r1
      0x0077: PHI (r0v7 int) = (r0v1 int), (r0v2 int), (r0v3 int), (r0v4 int), (r0v5 int), (r0v6 int), (r0v9 int) binds: [B:26:0x0075, B:23:0x0067, B:20:0x0059, B:17:0x004b, B:14:0x003d, B:11:0x002f, B:8:0x0021] A[DONT_GENERATE, DONT_INLINE]
      0x0077: PHI (r1v7 int) = (r1v1 int), (r1v2 int), (r1v3 int), (r1v4 int), (r1v5 int), (r1v6 int), (r1v9 int) binds: [B:26:0x0075, B:23:0x0067, B:20:0x0059, B:17:0x004b, B:14:0x003d, B:11:0x002f, B:8:0x0021] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:28:0x008a A[PHI: r0 r1
      0x008a: PHI (r0v8 int) = (r0v1 int), (r0v2 int), (r0v3 int), (r0v4 int), (r0v5 int), (r0v6 int), (r0v9 int) binds: [B:26:0x0075, B:23:0x0067, B:20:0x0059, B:17:0x004b, B:14:0x003d, B:11:0x002f, B:8:0x0021] A[DONT_GENERATE, DONT_INLINE]
      0x008a: PHI (r1v8 int) = (r1v1 int), (r1v2 int), (r1v3 int), (r1v4 int), (r1v5 int), (r1v6 int), (r1v9 int) binds: [B:26:0x0075, B:23:0x0067, B:20:0x0059, B:17:0x004b, B:14:0x003d, B:11:0x002f, B:8:0x0021] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:31:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:32:0x00b6  */
    /* JADX WARN: Failed to find 'out' block for switch in B:3:0x000a. Please report as an issue. */
    public void setImageState(int i2) {
        int i3;
        int i4;
        Drawable drawable;
        switch (i2) {
            case 1:
                this.E = 1;
                if (Build.VERSION.SDK_INT < 21) {
                    this.C = getResources().getDrawable(R.drawable.switch1_on);
                    drawable = getResources().getDrawable(R.drawable.switch1_off);
                } else {
                    this.C = getResources().getDrawable(R.drawable.switch1_on, null);
                    drawable = getResources().getDrawable(R.drawable.switch1_off, null);
                }
                break;
            case 2:
                this.E = 2;
                int i5 = Build.VERSION.SDK_INT;
                i3 = R.drawable.switch2_off;
                i4 = R.drawable.switch2_on;
                if (i5 < 21) {
                    this.C = getResources().getDrawable(i4);
                    drawable = getResources().getDrawable(i3);
                } else {
                    this.C = getResources().getDrawable(i4, null);
                    drawable = getResources().getDrawable(i3, null);
                }
                break;
            case 3:
                this.E = 3;
                int i6 = Build.VERSION.SDK_INT;
                i3 = R.drawable.switch3_off;
                i4 = R.drawable.switch3_on;
                if (i6 < 21) {
                    this.C = getResources().getDrawable(i4);
                    drawable = getResources().getDrawable(i3);
                } else {
                    this.C = getResources().getDrawable(i4, null);
                    drawable = getResources().getDrawable(i3, null);
                }
                break;
            case 4:
                this.E = 4;
                int i7 = Build.VERSION.SDK_INT;
                i3 = R.drawable.switch4_off;
                i4 = R.drawable.switch4_on;
                if (i7 < 21) {
                    this.C = getResources().getDrawable(i4);
                    drawable = getResources().getDrawable(i3);
                } else {
                    this.C = getResources().getDrawable(i4, null);
                    drawable = getResources().getDrawable(i3, null);
                }
                break;
            case 5:
                this.E = 5;
                int i8 = Build.VERSION.SDK_INT;
                i3 = R.drawable.switch5_off;
                i4 = R.drawable.switch5_on;
                if (i8 < 21) {
                    this.C = getResources().getDrawable(i4);
                    drawable = getResources().getDrawable(i3);
                } else {
                    this.C = getResources().getDrawable(i4, null);
                    drawable = getResources().getDrawable(i3, null);
                }
                break;
            case 6:
                this.E = 6;
                int i9 = Build.VERSION.SDK_INT;
                i3 = R.drawable.switch6_off;
                i4 = R.drawable.switch6_on;
                if (i9 < 21) {
                    this.C = getResources().getDrawable(i4);
                    drawable = getResources().getDrawable(i3);
                } else {
                    this.C = getResources().getDrawable(i4, null);
                    drawable = getResources().getDrawable(i3, null);
                }
                break;
            case 7:
                this.E = 7;
                int i10 = Build.VERSION.SDK_INT;
                i3 = R.drawable.switch7_off;
                i4 = R.drawable.switch7_on;
                if (i10 < 21) {
                    this.C = getResources().getDrawable(i4);
                    drawable = getResources().getDrawable(i3);
                } else {
                    this.C = getResources().getDrawable(i4, null);
                    drawable = getResources().getDrawable(i3, null);
                }
                break;
            case 8:
                this.E = 8;
                int i11 = Build.VERSION.SDK_INT;
                i3 = R.drawable.switch8_off;
                i4 = R.drawable.switch8_on;
                if (i11 < 21) {
                    this.C = getResources().getDrawable(i4);
                    drawable = getResources().getDrawable(i3);
                } else {
                    this.C = getResources().getDrawable(i4, null);
                    drawable = getResources().getDrawable(i3, null);
                }
                break;
            default:
                this.E = 1;
                if (Build.VERSION.SDK_INT < 21) {
                    this.C = getResources().getDrawable(R.drawable.switch1_on);
                    drawable = getResources().getDrawable(R.drawable.switch1_off);
                } else {
                    this.C = getResources().getDrawable(R.drawable.switch1_on, null);
                    drawable = getResources().getDrawable(R.drawable.switch1_off, null);
                }
                break;
        }
        this.D = drawable;
        setBackground(this.f8944h ? this.C : this.D);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8941e = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8945i = i2;
    }

    public void setState(boolean z) {
        if (this.f8944h != z) {
            this.f8944h = z;
            this.f8943g.J(z);
            if (d()) {
                setBackgroundColor(0);
            } else {
                setBackground(this.f8944h ? this.C : this.D);
            }
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.I = j2;
    }

    public void setVisibleInWork(boolean z) {
        this.f8946j = z;
    }
}
