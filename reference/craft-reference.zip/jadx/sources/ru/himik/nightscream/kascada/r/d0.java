package ru.himik.nightscream.kascada.r;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.core.widget.ContentLoadingProgressBar;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class d0 extends Dialog {
    public TextView a;
    public ContentLoadingProgressBar b;

    public static final class a extends f.c.a.a {

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.r.d0$a$a, reason: collision with other inner class name */
        public static final class C0304a implements ru.himik.nightscream.kascada.b0.d.b {
            final /* synthetic */ d0 a;

            C0304a(d0 d0Var) {
                this.a = d0Var;
            }

            @Override // ru.himik.nightscream.kascada.b0.d.b
            public void a() {
            }

            @Override // ru.himik.nightscream.kascada.b0.d.b
            public void d() {
                this.a.dismiss();
            }
        }

        a() {
        }

        @Override // f.c.a.a
        public void a(int i2, int i3, String str) {
            kotlin.b0.d.j.d(str, "errMsg");
            g.a.a.e.b(MyApplication.b().h0, "Error download file", 1).show();
            d0.this.dismiss();
        }

        @Override // f.c.a.a
        public void b(int i2, long j2, long j3) {
            int i3 = (int) ((j2 / j3) * 100.0f);
            d0.this.a().setProgress(i3);
            d0.this.b().setText(MyApplication.b().getResources().getString(R.string.download_file_wait) + ' ' + i3 + '%');
        }

        @Override // f.c.a.a
        public void c(int i2) {
            d0.this.b().setText(MyApplication.b().getResources().getString(R.string.download_file_retry));
        }

        @Override // f.c.a.a
        public void d(int i2, long j2) {
        }

        @Override // f.c.a.a
        public void e(int i2, String str) {
            kotlin.b0.d.j.d(str, "filePath");
            d0 d0Var = d0.this;
            C0304a c0304a = new C0304a(d0Var);
            d0Var.b().setText(MyApplication.b().getResources().getString(R.string.download_file_unpack));
            new ru.himik.nightscream.kascada.b0.d.a(c0304a).execute(str, ru.himik.nightscream.kascada.Utils.n.a.f());
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d0(Context context) {
        super(context);
        kotlin.b0.d.j.d(context, "context");
        setCancelable(false);
    }

    public final ContentLoadingProgressBar a() {
        ContentLoadingProgressBar contentLoadingProgressBar = this.b;
        if (contentLoadingProgressBar != null) {
            return contentLoadingProgressBar;
        }
        kotlin.b0.d.j.m("progressFileDownload");
        throw null;
    }

    public final TextView b() {
        TextView textView = this.a;
        if (textView != null) {
            return textView;
        }
        kotlin.b0.d.j.m("title");
        throw null;
    }

    public final void c(ContentLoadingProgressBar contentLoadingProgressBar) {
        kotlin.b0.d.j.d(contentLoadingProgressBar, "<set-?>");
        this.b = contentLoadingProgressBar;
    }

    public final void d(TextView textView) {
        kotlin.b0.d.j.d(textView, "<set-?>");
        this.a = textView;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.dialog_load_voice_model);
        View viewFindViewById = findViewById(R.id.title);
        kotlin.b0.d.j.c(viewFindViewById, "findViewById(R.id.title)");
        d((TextView) viewFindViewById);
        View viewFindViewById2 = findViewById(R.id.progressFileDownload);
        kotlin.b0.d.j.c(viewFindViewById2, "findViewById(R.id.progressFileDownload)");
        c((ContentLoadingProgressBar) viewFindViewById2);
        ru.himik.nightscream.kascada.b0.d.a.j(new a());
    }
}
