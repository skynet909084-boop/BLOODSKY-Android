package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class Var extends f implements e {
    private boolean V;
    boolean W;
    public String a0;

    public Var(Context context) {
        super(context);
        this.V = false;
        this.W = false;
        this.a0 = "VAR";
    }

    public Var(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = false;
        this.W = false;
        this.a0 = "VAR";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.V = false;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getBit() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("reg", 0);
        jSONObject.put("bit", 0);
        jSONObject.put("isConstant", g());
        jSONObject.put("constant", getVarConstant());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.a0 + " " + this.C + "." + this.D;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        boolean z;
        boolean z2;
        if (!this.o) {
            if (MyApplication.b().v0 != null && MyApplication.b().v0.a) {
                this.V = MyApplication.b().v0.G(this.C, this.D) == 1;
            }
            if (this.f9018k) {
                z2 = this.V;
                z = !z2;
            } else {
                z = this.V;
            }
        } else if (this.f9018k) {
            z2 = this.W;
            z = !z2;
        } else {
            z = this.W;
        }
        return Boolean.valueOf(z);
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getReg() {
        return this.C;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_textAppearanceListItem;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean getVarConstant() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public void j(int i2, int i3) {
        if (i2 < 0 || i2 > ru.himik.nightscream.kascada.q.d.b.F || i3 < 0 || i3 > 15) {
            return;
        }
        this.C = i2;
        this.D = i3;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawRect(this.G, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawRect(this.G, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        if (this.f9018k) {
            canvas.drawCircle((getWidth() - this.Q) + this.S, getHeight() / 2, this.S, this.f9013f);
            width = (getWidth() - this.Q) + (this.S * 2);
        } else {
            width = getWidth() - this.Q;
        }
        canvas.drawLine(width, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        StringBuilder sb;
        if (this.o) {
            sb = new StringBuilder();
            sb.append(this.W);
            sb.append("");
        } else {
            sb = new StringBuilder();
            sb.append("S#");
            sb.append(this.C);
            sb.append(".");
            sb.append(this.D);
        }
        this.E = sb.toString();
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setVarConstant(boolean z) {
        this.W = z;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }
}
