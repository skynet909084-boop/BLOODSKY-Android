package ru.himik.nightscream.kascada.Bd;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import ru.himik.nightscream.kascada.Bd.Export.ProjectExportActivity;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class d extends ArrayAdapter<g> {
    private final Context a;
    ArrayList<g> b;
    ProjectExportActivity.OnClickUploadQr c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f8598d;

    public d(Context context, ArrayList<g> arrayList) {
        super(context, R.layout.item_project_, arrayList);
        this.b = new ArrayList<>();
        this.f8598d = false;
        this.a = context;
        this.b = arrayList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void b(int i2, View view) {
        this.c.onClickQR(this.b.get(i2).e());
    }

    public void c(ProjectExportActivity.OnClickUploadQr onClickUploadQr) {
        this.c = onClickUploadQr;
    }

    public void d() {
        this.f8598d = true;
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(final int i2, View view, ViewGroup viewGroup) {
        View viewInflate = ((LayoutInflater) this.a.getSystemService("layout_inflater")).inflate(R.layout.item_project_export, viewGroup, false);
        if (this.f8598d) {
            LinearLayout linearLayout = (LinearLayout) viewInflate.findViewById(R.id.ll_upload_to_server);
            linearLayout.setVisibility(0);
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Bd.a
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.a.b(i2, view2);
                }
            });
        }
        TextView textView = (TextView) viewInflate.findViewById(R.id.nameProject);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.countScreenInProject);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.createdDate);
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.createdTime);
        TextView textView5 = (TextView) viewInflate.findViewById(R.id.countDevice);
        textView.setText(this.b.get(i2).e());
        textView2.setText(this.b.get(i2).b() + "");
        textView3.setText(this.b.get(i2).c());
        textView4.setText(this.b.get(i2).f());
        textView5.setText(this.b.get(i2).a() + "");
        return viewInflate;
    }
}
