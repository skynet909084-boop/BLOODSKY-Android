package ru.himik.nightscream.kascada.Firebase;

import android.content.Context;
import f.a.b.n;
import f.a.b.o;
import f.a.b.x.p;

/* JADX INFO: loaded from: classes2.dex */
public class c {
    private static c c;
    private o a = c();
    private Context b;

    private c(Context context) {
        this.b = context;
    }

    public static synchronized c b(Context context) {
        if (c == null) {
            c = new c(context);
        }
        return c;
    }

    public <T> void a(n<T> nVar) {
        c().a(nVar);
    }

    public o c() {
        if (this.a == null) {
            this.a = p.a(this.b.getApplicationContext());
        }
        return this.a;
    }
}
