package ru.himik.nightscream.kascada.CustomComponents;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatButton;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import kotlin.KotlinVersion;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class d extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    int C;
    boolean D;
    ru.himik.nightscream.kascada.x.a E;
    ru.himik.nightscream.kascada.Bd.f F;
    SQLiteDatabase G;
    DateFormat H;
    DateFormat I;
    String J;
    String K;
    String L;
    String M;
    String N;
    String O;
    String P;
    boolean Q;
    int R;
    int S;
    String T;
    String U;
    String V;
    int W;
    int a0;
    boolean b0;
    Context c;
    int c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f8749d;
    int d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8750e;
    boolean e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8751f;
    boolean f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public byte f8752g;
    Handler g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8753h;
    Paint h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8754i;
    boolean i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8755j;
    String j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f8756k;
    int k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f8757l;
    int l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    String f8758m;
    private boolean m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    int f8759n;
    private long n0;
    int o;
    private boolean o0;
    private int p0;
    private int q0;
    private ArrayList<c> r0;
    private boolean s0;
    private boolean t0;
    private long u0;
    int[] v0;
    public Point w0;

    class a extends Handler {
        a() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == 2) {
                if (d.this.s0) {
                    ru.himik.nightscream.kascada.w.b.a("Archive", "[ARCHIVE] SEND_ARCHIVE_SUCCESSFUL");
                }
                d.this.m0 = false;
                if (DatabaseUtils.queryNumEntries(d.this.G, "Archive") > 0) {
                    d.this.G.execSQL("delete from Archive");
                }
            } else {
                if (i2 != 3) {
                    return;
                }
                if (d.this.s0) {
                    ru.himik.nightscream.kascada.w.b.a("Archive", "[ARCHIVE] HANDLER_SEND_ARCHIVE_ERROR");
                }
                d.this.m0 = false;
            }
            d.this.t();
        }
    }

    class b implements Runnable {
        final /* synthetic */ String a;

        b(String str) {
            this.a = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            BufferedWriter bufferedWriter = null;
            Cursor cursorRawQuery = d.this.getDb().rawQuery("SELECT * FROM Archive", null);
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath() + "/KaScada//Archive//" + MyApplication.b().m0 + "//");
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(file.getPath() + "//" + this.a + ".csv");
            if (!file2.exists()) {
                try {
                    file2.createNewFile();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
            try {
                bufferedWriter = new BufferedWriter(new FileWriter(file2, false));
            } catch (IOException e3) {
                e3.printStackTrace();
            }
            if (bufferedWriter == null) {
                return;
            }
            try {
                try {
                    if (cursorRawQuery.moveToFirst()) {
                        do {
                            bufferedWriter.write(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var1")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var2")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var3")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var4")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var5")) + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("_time")) + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("_date")));
                            bufferedWriter.newLine();
                        } while (cursorRawQuery.moveToNext());
                    }
                } catch (Exception unused) {
                    bufferedWriter.close();
                }
            } catch (IOException e4) {
                e4.printStackTrace();
            }
            try {
                bufferedWriter.flush();
                bufferedWriter.close();
            } catch (IOException e5) {
                e5.printStackTrace();
            }
            d.this.g0.obtainMessage(1).sendToTarget();
        }
    }

    class c {
        String a;
        String b;
        String c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        String f8760d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        String f8761e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        String f8762f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        String f8763g;

        public c(d dVar, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
            this.a = str;
            this.b = str2;
            this.c = str3;
            this.f8760d = str4;
            this.f8761e = str5;
            this.f8762f = str6;
            this.f8763g = str7;
        }
    }

    public d(Context context) {
        super(context);
        this.f8749d = getResources().getString(R.string.custom_archive);
        this.f8750e = 15;
        this.f8752g = (byte) 1;
        this.f8753h = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8754i = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8755j = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8757l = "default";
        this.f8758m = "FLOAT";
        this.f8759n = 4;
        this.o = 0;
        this.C = 0;
        this.D = false;
        this.E = new ru.himik.nightscream.kascada.x.a();
        this.H = new SimpleDateFormat("HH:mm:ss");
        this.I = new SimpleDateFormat("yyyy-MM-dd");
        this.J = "2020";
        this.K = "01";
        this.L = "01";
        this.M = "12";
        this.N = "00";
        this.O = "00";
        this.P = "default";
        this.Q = false;
        this.R = 0;
        this.S = 0;
        this.T = "";
        this.U = "";
        this.V = "";
        this.W = 0;
        this.a0 = 0;
        this.b0 = false;
        this.c0 = 0;
        this.d0 = 0;
        this.e0 = false;
        this.f0 = false;
        this.h0 = new Paint();
        this.i0 = false;
        this.j0 = "ASCII";
        this.k0 = 0;
        this.l0 = 2;
        this.m0 = false;
        this.o0 = false;
        this.p0 = 0;
        this.q0 = 0;
        this.r0 = new ArrayList<>();
        this.s0 = false;
        this.t0 = false;
        this.u0 = 0L;
        this.w0 = new Point();
        this.c = context;
        this.g0 = new a();
    }

    private void w(int[] iArr, String str) {
        if (!this.f8758m.equals("FLOAT")) {
            int length = iArr.length;
            if (length == 2) {
                int[] iArr2 = new int[4];
                iArr2[0] = (iArr[0] * 256) + iArr[1];
                v(iArr2, str);
                return;
            } else if (length == 4) {
                v(new int[]{(iArr[0] * 256) + iArr[1], (iArr[2] * 256) + iArr[3], 0, 0}, str);
                return;
            } else if (length == 6) {
                v(new int[]{(iArr[0] * 256) + iArr[1], (iArr[2] * 256) + iArr[3], (iArr[4] * 256) + iArr[5], 0}, str);
                return;
            } else {
                if (length != 8) {
                    return;
                }
                v(new int[]{(iArr[0] * 256) + iArr[1], (iArr[2] * 256) + iArr[3], (iArr[4] * 256) + iArr[5], (iArr[6] * 256) + iArr[7]}, str);
                return;
            }
        }
        int length2 = iArr.length;
        if (length2 == 4) {
            float[] fArr = new float[4];
            fArr[0] = c(new byte[]{(byte) iArr[0], (byte) iArr[1], (byte) iArr[2], (byte) iArr[3]});
            u(fArr, str);
            return;
        }
        if (length2 == 8) {
            byte[] bArr = {(byte) iArr[0], (byte) iArr[1], (byte) iArr[2], (byte) iArr[3]};
            float fC = c(bArr);
            bArr[0] = (byte) iArr[4];
            bArr[1] = (byte) iArr[5];
            bArr[2] = (byte) iArr[6];
            bArr[3] = (byte) iArr[7];
            u(new float[]{fC, c(bArr), 0.0f, 0.0f}, str);
            return;
        }
        if (length2 == 12) {
            byte[] bArr2 = {(byte) iArr[0], (byte) iArr[1], (byte) iArr[2], (byte) iArr[3]};
            float fC2 = c(bArr2);
            bArr2[0] = (byte) iArr[4];
            bArr2[1] = (byte) iArr[5];
            bArr2[2] = (byte) iArr[6];
            bArr2[3] = (byte) iArr[7];
            float fC3 = c(bArr2);
            bArr2[0] = (byte) iArr[8];
            bArr2[1] = (byte) iArr[9];
            bArr2[2] = (byte) iArr[10];
            bArr2[3] = (byte) iArr[11];
            u(new float[]{fC2, fC3, c(bArr2), 0.0f}, str);
            return;
        }
        if (length2 != 16) {
            return;
        }
        byte[] bArr3 = {(byte) iArr[0], (byte) iArr[1], (byte) iArr[2], (byte) iArr[3]};
        float fC4 = c(bArr3);
        bArr3[0] = (byte) iArr[4];
        bArr3[1] = (byte) iArr[5];
        bArr3[2] = (byte) iArr[6];
        bArr3[3] = (byte) iArr[7];
        float fC5 = c(bArr3);
        bArr3[0] = (byte) iArr[8];
        bArr3[1] = (byte) iArr[9];
        bArr3[2] = (byte) iArr[10];
        bArr3[3] = (byte) iArr[11];
        float fC6 = c(bArr3);
        bArr3[0] = (byte) iArr[12];
        bArr3[1] = (byte) iArr[13];
        bArr3[2] = (byte) iArr[14];
        bArr3[3] = (byte) iArr[15];
        u(new float[]{fC4, fC5, fC6, c(bArr3)}, str);
    }

    public float c(byte[] bArr) {
        return o(ByteBuffer.wrap(bArr).getFloat(), 2);
    }

    void d() {
        ru.himik.nightscream.kascada.CustomComponents.b bVar = new ru.himik.nightscream.kascada.CustomComponents.b();
        bVar.A(999);
        bVar.F(this.f8753h.r());
        bVar.E(this.f8753h.l());
        bVar.u(this.f8753h.b());
        bVar.v(this.f8753h.c());
        bVar.t(this.f8753h.a());
        bVar.J(false);
        bVar.C(getKey());
        bVar.D(this.f8753h.k());
        bVar.L((byte) 5);
        mbCanvas.F(this.f8753h.k(), bVar);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.w0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e() {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsoluteFile());
        String str = File.separator;
        sb.append(str);
        sb.append("KaScada");
        sb.append(str);
        sb.append("Archive");
        sb.append(str);
        sb.append(this.P);
        sb.append(str);
        File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, this.f8757l + ".db");
        if (file2.exists()) {
            return;
        }
        try {
            file2.createNewFile();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public void f(int i2) {
        if (i2 == 0) {
            this.f0 = false;
        }
        if (i2 != 1 || this.f0) {
            return;
        }
        this.f0 = true;
        if ("mounted".equals(Environment.getExternalStorageState())) {
            new Thread(new b(getFileName())).start();
        } else {
            "mounted_ro".equals(Environment.getExternalStorageState());
        }
    }

    public void g(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_archive);
        Calendar calendar = Calendar.getInstance();
        s(calendar.get(1) + "", (calendar.get(2) + 1) + "", calendar.get(5) + "", calendar.get(11) + "", calendar.get(12) + "", "00");
        getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        Resources resources = getResources();
        if (z) {
            layoutParams.width = (int) resources.getDimension(R.dimen.view_base_height);
        } else {
            layoutParams.width = (int) resources.getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
        this.f8753h.A(this.f8750e);
        this.f8754i.A(this.f8750e);
    }

    public int getBitResetArchive() {
        return this.d0;
    }

    public int getBitSendEmail() {
        return this.a0;
    }

    public int getBitSendToCloudArchive() {
        return this.q0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.f8753h;
    }

    public int getCountArchiveOptionalChannelASCII() {
        return this.l0;
    }

    public int getCountChannel() {
        return this.f8759n;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8750e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8756k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    public SQLiteDatabase getDb() {
        e();
        ru.himik.nightscream.kascada.Bd.f fVar = new ru.himik.nightscream.kascada.Bd.f(this.c, this.P, this.f8757l);
        this.F = fVar;
        SQLiteDatabase writableDatabase = fVar.getWritableDatabase();
        this.G = writableDatabase;
        return writableDatabase;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.R;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.S;
    }

    public String getEmailLogin() {
        return this.T;
    }

    public String getEmailPassword() {
        return this.U;
    }

    public String getEmailTo() {
        return this.V;
    }

    public String getFileName() {
        return this.f8757l;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8750e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8753h.l());
        jSONObject.put("addressRegister", this.f8753h.c());
        jSONObject.put("addressBit", (int) this.f8753h.a());
        jSONObject.put("typeRequest", (int) this.f8753h.q());
        jSONObject.put("posDeviceNetworkInList_triggerData", this.f8754i.l());
        jSONObject.put("addressRegister_triggerData", this.f8754i.c());
        jSONObject.put("addressBit_triggerData", (int) this.f8754i.a());
        jSONObject.put("typeRequest_triggerData", (int) this.f8754i.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("fileName", getFileName());
        jSONObject.put("typeRecord", getTypeRecord());
        jSONObject.put("countChannel", getCountChannel());
        jSONObject.put("registerArchive", getRegisterArchive());
        jSONObject.put("emailLogin", getEmailLogin());
        jSONObject.put("emailPassword", getEmailPassword());
        jSONObject.put("emailTo", getEmailTo());
        jSONObject.put("regSendEmail", getRegSendEmail());
        jSONObject.put("bitSendEmail", getBitSendEmail());
        jSONObject.put("isResetArchive", i());
        jSONObject.put("regResetArchive", getRegResetArchive());
        jSONObject.put("bitResetArchive", getBitResetArchive());
        jSONObject.put("optionChannel", h());
        jSONObject.put("typeRecordOptionChannel", getTypeRecordOptionChannel());
        jSONObject.put("regArchiveOptionalChannel", getRegArchiveOptionalChannel());
        jSONObject.put("countArchiveOptionalChannelASCII", getCountArchiveOptionalChannelASCII());
        jSONObject.put("isSendToCloudArchive", j());
        jSONObject.put("regSendToCloudArchive", getRegSendToCloudArchive());
        jSONObject.put("bitSendToCloudArchive", getBitSendToCloudArchive());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8751f;
    }

    public String getLastDay() {
        return this.L;
    }

    public String getLastHour() {
        return this.M;
    }

    public String getLastMin() {
        return this.N;
    }

    public String getLastMonth() {
        return this.K;
    }

    public String getLastSek() {
        return this.O;
    }

    public String getLastYear() {
        return this.J;
    }

    public int getNumScreen() {
        return this.f8756k;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.w0;
    }

    public String getProjectName() {
        return this.P;
    }

    public int getRegArchiveOptionalChannel() {
        return this.k0;
    }

    public int getRegResetArchive() {
        return this.c0;
    }

    public int getRegSendEmail() {
        return this.W;
    }

    public int getRegSendToCloudArchive() {
        return this.p0;
    }

    public int getRegisterArchive() {
        return this.o;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8753h.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8753h.l() >= 100) {
            this.f8753h.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8753h.c() + "." + ((int) this.f8753h.a());
        }
        this.f8753h.u((byte) MyApplication.b().E.get(this.f8753h.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8753h.b()) + "#" + this.f8753h.c() + "." + ((int) this.f8753h.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8753h.l() >= 0) {
            if (this.f8753h.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8753h.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.u0;
    }

    public String getTypeRecord() {
        return this.f8758m;
    }

    public String getTypeRecordOptionChannel() {
        return this.j0;
    }

    public int getValue() {
        return this.C;
    }

    public boolean h() {
        return this.i0;
    }

    public boolean i() {
        return this.b0;
    }

    public boolean j() {
        return this.o0;
    }

    public void k() {
        if (DatabaseUtils.queryNumEntries(this.G, "Archive") > 100000) {
            this.G.execSQL("delete from Archive where _id in (select _id from Archive order by _id LIMIT 1000);");
        }
    }

    public void l(int i2) {
        if (i2 == 0) {
            this.e0 = false;
        }
        if (i2 != 1 || this.e0) {
            return;
        }
        this.e0 = true;
        long jQueryNumEntries = DatabaseUtils.queryNumEntries(this.G, "Archive");
        if (this.s0) {
            ru.himik.nightscream.kascada.w.b.a("Archive", "[ARCHIVE] Очистка архива, было: " + jQueryNumEntries);
        }
        if (jQueryNumEntries > 0) {
            this.G.execSQL("delete from Archive");
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public void m(int[] iArr) {
        String str = this.j0;
        str.hashCode();
        byte b2 = -1;
        switch (str.hashCode()) {
            case 72655:
                if (str.equals("INT")) {
                    b2 = 0;
                }
                break;
            case 62568241:
                if (str.equals("ASCII")) {
                    b2 = 1;
                }
                break;
            case 66988604:
                if (str.equals("FLOAT")) {
                    b2 = 2;
                }
                break;
        }
        String str2 = "";
        switch (b2) {
            case 0:
                str2 = ((iArr[0] * 256) + iArr[1]) + "";
                break;
            case 1:
                int i2 = this.l0;
                int i3 = i2 % 2;
                int i4 = i2 / 2;
                if (i3 > 0) {
                    i4++;
                }
                int[] iArr2 = new int[i4];
                if (iArr.length / 2 == i4) {
                    for (int i5 = 0; i5 < i4; i5++) {
                        int i6 = i5 * 2;
                        iArr2[i5] = (iArr[i6] * 256) + iArr[i6 + 1];
                    }
                    int i7 = this.l0;
                    byte[] bArr = new byte[i7];
                    for (int i8 = 0; i8 < i7; i8 += 2) {
                        int i9 = i8 / 2;
                        bArr[i8] = (byte) (iArr2[i9] & KotlinVersion.MAX_COMPONENT_VALUE);
                        int i10 = i8 + 1;
                        if (i10 <= i7 - 1) {
                            bArr[i10] = (byte) ((iArr2[i9] >> 8) & KotlinVersion.MAX_COMPONENT_VALUE);
                        }
                    }
                    try {
                        str2 = new String(bArr, "KOI8_R");
                    } catch (UnsupportedEncodingException e2) {
                        e2.printStackTrace();
                    }
                }
                break;
            case 2:
                str2 = c(new byte[]{(byte) iArr[0], (byte) iArr[1], (byte) iArr[2], (byte) iArr[3]}) + "";
                break;
        }
        w(this.v0, str2);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:6:0x001a  */
    public void n(int[] iArr) {
        if (!this.i0) {
            w(iArr, "");
            return;
        }
        this.v0 = iArr;
        this.f8755j = this.f8754i;
        String str = this.j0;
        str.hashCode();
        switch (str) {
            case "INT":
                this.f8755j.z((byte) 1);
                this.f8755j.K(0);
                break;
            case "ASCII":
                int i2 = this.l0;
                int i3 = i2 % 2;
                int i4 = i2 / 2;
                if (i3 > 0) {
                    i4++;
                }
                this.f8755j.z((byte) i4);
                this.f8755j.K(0);
                break;
            case "FLOAT":
                this.f8755j.z((byte) 2);
                this.f8755j.K(1);
                break;
        }
        this.f8755j.v(this.k0);
        ru.himik.nightscream.kascada.CustomComponents.b bVar = this.f8755j;
        bVar.x(this.E.c(bVar, bVar.i()));
        this.f8755j.A(153);
        if (this.f8755j.k() != -1 || this.f8755j.l() == 100) {
            mbCanvas.F(this.f8755j.k(), this.f8755j);
        }
    }

    public float o(float f2, int i2) {
        return BigDecimal.valueOf(f2).setScale(i2, 4).floatValue();
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.Q) {
            this.h0.setColor(-16711936);
            this.h0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.h0);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.Q;
    }

    public void q(boolean z) {
        e();
        if (z) {
            ru.himik.nightscream.kascada.Bd.f fVar = new ru.himik.nightscream.kascada.Bd.f(this.c, this.P, this.f8757l);
            this.F = fVar;
            this.G = fVar.getWritableDatabase();
        } else {
            SQLiteDatabase sQLiteDatabase = this.G;
            if (sQLiteDatabase != null) {
                sQLiteDatabase.close();
            }
        }
    }

    public void r(int i2) {
        String str;
        if (i2 == 0) {
            this.t0 = false;
        }
        if (i2 != 1 || this.t0) {
            return;
        }
        if (this.s0) {
            ru.himik.nightscream.kascada.w.b.a("Archive", "[ARCHIVE] Отправка архива в облако");
        }
        this.t0 = true;
        long jCurrentTimeMillis = System.currentTimeMillis();
        Cursor cursorRawQuery = getDb().rawQuery("SELECT * FROM Archive", null);
        if (this.s0) {
            ru.himik.nightscream.kascada.w.b.a("Archive", "[ARCHIVE] Запрос данных занял: " + (System.currentTimeMillis() - jCurrentTimeMillis) + "мс. Кол-во: " + cursorRawQuery.getCount());
        }
        if (cursorRawQuery.getCount() != 0 && System.currentTimeMillis() - this.n0 > 3000) {
            this.n0 = System.currentTimeMillis();
            this.m0 = true;
            if (!MyApplication.b().f9044l.equals("")) {
                new ru.himik.nightscream.kascada.Connections.Cloud.a(MyApplication.b().f9044l, cursorRawQuery, this.g0, this.f8757l, this.s0).start();
                return;
            } else {
                if (this.s0) {
                    ru.himik.nightscream.kascada.w.b.a("Archive", "[ARCHIVE] Отправка на сервер не разрешается, нет ключа");
                    return;
                }
                return;
            }
        }
        if (System.currentTimeMillis() - this.n0 <= 3000) {
            if (!this.s0) {
                return;
            } else {
                str = "[ARCHIVE] Отправка не разрешается. Прошло менее 3сек";
            }
        } else {
            if (!this.s0) {
                return;
            }
            str = "[ARCHIVE] Отправка не разрешается. cursor.getCount() = 0 (" + cursorRawQuery.getCount() + ")";
        }
        ru.himik.nightscream.kascada.w.b.a("Archive", str);
    }

    public void s(String str, String str2, String str3, String str4, String str5, String str6) {
        this.J = str;
        this.K = str2;
        this.L = str3;
        this.M = str4;
        this.N = str5;
        this.O = str6;
    }

    public void setBitResetArchive(int i2) {
        this.d0 = i2;
    }

    public void setBitSendEmail(int i2) {
        this.a0 = i2;
    }

    public void setBitSendToCloudArchive(int i2) {
        this.q0 = i2;
    }

    public void setCountArchiveOptionalChannelASCII(int i2) {
        this.l0 = i2;
    }

    public void setCountChannel(int i2) {
        this.f8759n = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.Q = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.R = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.S = i2;
    }

    public void setEmailLogin(String str) {
        this.T = str;
    }

    public void setEmailPassword(String str) {
        this.U = str;
    }

    public void setEmailTo(String str) {
        this.V = str;
    }

    public void setFileName(String str) {
        this.f8757l = str;
        this.s0 = str.equals("log");
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8751f = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8756k = i2;
    }

    public void setOptionChannel(boolean z) {
        this.i0 = z;
    }

    public void setProjectName(String str) {
        this.P = str;
    }

    public void setRegArchiveOptionalChannel(int i2) {
        this.k0 = i2;
    }

    public void setRegResetArchive(int i2) {
        this.c0 = i2;
    }

    public void setRegSendEmail(int i2) {
        this.W = i2;
    }

    public void setRegSendToCloudArchive(int i2) {
        this.p0 = i2;
    }

    public void setRegisterArchive(int i2) {
        this.o = i2;
    }

    public void setResetArchive(boolean z) {
        this.b0 = z;
    }

    public void setSendToCloudArchive(boolean z) {
        if (z && !this.o0) {
            for (int i2 = 0; i2 < MyApplication.b().S.size(); i2++) {
                if (((d) MyApplication.b().S.get(MyApplication.b().S.keyAt(i2))).o0) {
                    Toast.makeText(this.c, R.string.only_one_archive_can_send_data_to_the_server, 1).show();
                    return;
                }
            }
        }
        this.o0 = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.u0 = j2;
    }

    public void setTypeRecord(String str) {
        this.f8758m = str;
    }

    public void setTypeRecordOptionChannel(String str) {
        this.j0 = str;
    }

    public void setValue(int i2) {
        this.C = i2;
        if (i2 == 1 && !this.D) {
            this.D = true;
            if (this.f8758m.equals("FLOAT")) {
                this.f8754i.z((byte) (this.f8759n * 2));
                this.f8754i.K(1);
            }
            if (this.f8758m.equals("INT")) {
                this.f8754i.z((byte) this.f8759n);
                this.f8754i.K(0);
            }
            this.f8754i.v(this.o);
            this.f8754i.L((byte) 3);
            ru.himik.nightscream.kascada.CustomComponents.b bVar = this.f8754i;
            bVar.x(this.E.c(bVar, bVar.i()));
            this.f8754i.A(152);
            if (this.f8754i.k() != -1 || this.f8754i.l() == 100) {
                mbCanvas.F(this.f8754i.k(), this.f8754i);
            }
        }
        if (i2 == 0) {
            this.D = false;
        }
    }

    public void t() {
        if (this.r0.size() > 0) {
            if (this.s0) {
                ru.himik.nightscream.kascada.w.b.a("Archive", "[ARCHIVE] Данные в буфере, переписываем в архив: " + this.r0.size());
            }
            ContentValues contentValues = new ContentValues();
            for (c cVar : this.r0) {
                contentValues.put("var1", cVar.a);
                contentValues.put("var2", cVar.b);
                contentValues.put("var3", cVar.c);
                contentValues.put("var4", cVar.f8760d);
                contentValues.put("var5", cVar.f8761e);
                contentValues.put("_time", cVar.f8762f);
                contentValues.put("_date", cVar.f8763g);
                this.G.insert("Archive", null, contentValues);
            }
            this.r0.clear();
        }
    }

    /* JADX WARN: Code duplicated, block: B:22:0x018b  */
    /* JADX WARN: Instruction removed from duplicated block: B:22:0x018b, please report this as an issue */
    public void u(float[] fArr, String str) {
        if (this.m0) {
            Date date = new Date();
            this.r0.add(new c(this, fArr[0] + "", fArr[1] + "", fArr[2] + "", fArr[3] + "", str, this.H.format(date), this.I.format(date)));
            return;
        }
        ContentValues contentValues = new ContentValues();
        int i2 = this.f8759n;
        if (i2 == 1) {
            contentValues.put("var1", fArr[0] + "");
        } else if (i2 == 2) {
            contentValues.put("var1", fArr[0] + "");
            contentValues.put("var2", fArr[1] + "");
        } else {
            if (i2 != 3) {
                if (i2 == 4) {
                    contentValues.put("var1", fArr[0] + "");
                    contentValues.put("var2", fArr[1] + "");
                    contentValues.put("var3", fArr[2] + "");
                    contentValues.put("var4", fArr[3] + "");
                }
                Date date2 = new Date();
                contentValues.put("_time", this.H.format(date2));
                contentValues.put("_date", this.I.format(date2));
                if (this.G.insert("Archive", null, contentValues) <= 0) {
                    Toast.makeText(this.c, getResources().getString(R.string.custom_archive_insert_error) + " " + this.f8757l, 1).show();
                }
                k();
                d();
            }
            contentValues.put("var1", fArr[0] + "");
            contentValues.put("var2", fArr[1] + "");
            contentValues.put("var3", fArr[2] + "");
        }
        contentValues.put("var5", str);
        Date date3 = new Date();
        contentValues.put("_time", this.H.format(date3));
        contentValues.put("_date", this.I.format(date3));
        if (this.G.insert("Archive", null, contentValues) <= 0) {
            Toast.makeText(this.c, getResources().getString(R.string.custom_archive_insert_error) + " " + this.f8757l, 1).show();
        }
        k();
        d();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x011c  */
    /* JADX WARN: Instruction removed from duplicated block: B:22:0x011c, please report this as an issue */
    public void v(int[] iArr, String str) {
        if (this.m0) {
            Date date = new Date();
            this.r0.add(new c(this, iArr[0] + "", iArr[1] + "", iArr[2] + "", iArr[3] + "", str, this.H.format(date), this.I.format(date)));
            return;
        }
        ContentValues contentValues = new ContentValues();
        int i2 = this.f8759n;
        if (i2 == 1) {
            contentValues.put("var1", Integer.valueOf(iArr[0]));
        } else if (i2 == 2) {
            contentValues.put("var1", Integer.valueOf(iArr[0]));
            contentValues.put("var2", Integer.valueOf(iArr[1]));
        } else {
            if (i2 != 3) {
                if (i2 == 4) {
                    contentValues.put("var1", Integer.valueOf(iArr[0]));
                    contentValues.put("var2", Integer.valueOf(iArr[1]));
                    contentValues.put("var3", Integer.valueOf(iArr[2]));
                    contentValues.put("var4", Integer.valueOf(iArr[3]));
                }
                Date date2 = new Date();
                contentValues.put("_time", this.H.format(date2));
                contentValues.put("_date", this.I.format(date2));
                if (this.G.insert("Archive", null, contentValues) <= 0) {
                    Toast.makeText(this.c, getResources().getString(R.string.custom_archive_insert_error) + " " + this.f8757l, 1).show();
                }
                k();
                d();
            }
            contentValues.put("var1", Integer.valueOf(iArr[0]));
            contentValues.put("var2", Integer.valueOf(iArr[1]));
            contentValues.put("var3", Integer.valueOf(iArr[2]));
        }
        contentValues.put("var5", str);
        Date date3 = new Date();
        contentValues.put("_time", this.H.format(date3));
        contentValues.put("_date", this.I.format(date3));
        if (this.G.insert("Archive", null, contentValues) <= 0) {
            Toast.makeText(this.c, getResources().getString(R.string.custom_archive_insert_error) + " " + this.f8757l, 1).show();
        }
        k();
        d();
    }
}
