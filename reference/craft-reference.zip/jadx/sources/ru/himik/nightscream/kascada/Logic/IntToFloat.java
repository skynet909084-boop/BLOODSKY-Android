package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes2.dex */
public class IntToFloat extends ru.himik.nightscream.kascada.Logic.c.b {
    String Q;

    public IntToFloat(Context context) {
        super(context);
        this.Q = "INT->FL";
    }

    public IntToFloat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.Q = "INT->FL";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.Q;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.c;
        if (aVar == null || aVar.getOut() == null) {
            return null;
        }
        try {
            return Float.valueOf((short) ((Integer) this.c.getOut()).intValue());
        } catch (Exception unused) {
            return null;
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_windowFixedHeightMajor;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 3;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        return i2 != 1 ? 0 : 2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, android.view.View
    protected void onDraw(Canvas canvas) {
        canvas.drawLine(getWidth() - this.M, getHeight() / 2, getWidth(), getHeight() / 2, this.f8962e);
        canvas.drawLine(this.N, getHeight() / 2, this.M, getHeight() / 2, this.f8962e);
        this.C.set(this.M, this.N, getWidth() - this.M, getHeight() - this.N);
        this.f8962e.setStyle(Paint.Style.FILL);
        this.f8962e.setColor(-7829368);
        canvas.drawRect(this.C, this.f8962e);
        this.f8962e.setStyle(Paint.Style.STROKE);
        this.f8962e.setColor(-16777216);
        canvas.drawRect(this.C, this.f8962e);
        canvas.drawText(this.f8971n, getWidth() / 2, (int) ((getHeight() / 2) - ((this.f8963f.descent() + this.f8963f.ascent()) / 2.0f)), this.f8963f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.b, android.view.View
    protected void onMeasure(int i2, int i3) {
        this.f8971n = "INT->FL";
        super.onMeasure(i2, i3);
    }
}
