package ru.himik.nightscream.kascada.d0;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class c {
    private final LinearLayout a;
    public final Button b;
    public final Button c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final EditText f9196d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final RelativeLayout f9197e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ListView f9198f;

    private c(LinearLayout linearLayout, Button button, Button button2, EditText editText, RelativeLayout relativeLayout, View view, ListView listView, Toolbar toolbar, TextView textView, TextView textView2) {
        this.a = linearLayout;
        this.b = button;
        this.c = button2;
        this.f9196d = editText;
        this.f9197e = relativeLayout;
        this.f9198f = listView;
    }

    public static c a(View view) {
        int i2 = R.id.btn_download_and_import;
        Button button = (Button) view.findViewById(R.id.btn_download_and_import);
        if (button != null) {
            i2 = R.id.btn_scan_qr;
            Button button2 = (Button) view.findViewById(R.id.btn_scan_qr);
            if (button2 != null) {
                i2 = R.id.et_url;
                EditText editText = (EditText) view.findViewById(R.id.et_url);
                if (editText != null) {
                    i2 = R.id.layout_download;
                    RelativeLayout relativeLayout = (RelativeLayout) view.findViewById(R.id.layout_download);
                    if (relativeLayout != null) {
                        i2 = R.id.line;
                        View viewFindViewById = view.findViewById(R.id.line);
                        if (viewFindViewById != null) {
                            i2 = R.id.lvMain;
                            ListView listView = (ListView) view.findViewById(R.id.lvMain);
                            if (listView != null) {
                                i2 = R.id.toolbar;
                                Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
                                if (toolbar != null) {
                                    i2 = R.id.tv_info;
                                    TextView textView = (TextView) view.findViewById(R.id.tv_info);
                                    if (textView != null) {
                                        i2 = R.id.tv_or;
                                        TextView textView2 = (TextView) view.findViewById(R.id.tv_or);
                                        if (textView2 != null) {
                                            return new c((LinearLayout) view, button, button2, editText, relativeLayout, viewFindViewById, listView, toolbar, textView, textView2);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i2)));
    }

    public static c c(LayoutInflater layoutInflater) {
        return d(layoutInflater, null, false);
    }

    public static c d(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.project_list_import, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return a(viewInflate);
    }

    public LinearLayout b() {
        return this.a;
    }
}
