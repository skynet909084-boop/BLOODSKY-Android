package ru.himik.nightscream.kascada.Utils;

import android.os.Handler;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/* JADX INFO: loaded from: classes2.dex */
public class o extends Thread {
    boolean a = true;
    Handler b;

    public o(Handler handler) {
        this.b = handler;
        start();
    }

    public void a() {
        this.a = false;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        while (this.a) {
            try {
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress("8.8.8.8", 53), 1500);
                socket.close();
                this.b.obtainMessage(16, Boolean.TRUE).sendToTarget();
            } catch (IOException unused) {
                this.b.obtainMessage(16, Boolean.FALSE).sendToTarget();
            }
            try {
                Thread.sleep(5000L);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
    }
}
