package ru.himik.nightscream.kascada.t.d;

import android.content.ClipData;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.sun.mail.imap.IMAPStore;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.n;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b extends Fragment {
    View.OnClickListener k0 = new ViewOnClickListenerC0310b();
    View.OnLongClickListener l0 = new c(this);
    View.OnLongClickListener m0 = new d();

    class a extends GestureDetector.SimpleOnGestureListener {
        a() {
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent motionEvent) {
            return true;
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
            try {
                if (Math.abs(motionEvent.getY() - motionEvent2.getY()) > 250.0f) {
                    return false;
                }
                if (motionEvent.getX() - motionEvent2.getX() > 120.0f && Math.abs(f2) > 200.0f) {
                    ((mbCanvas) b.this.h()).x0(true);
                } else if (motionEvent2.getX() - motionEvent.getX() > 120.0f && Math.abs(f2) > 200.0f) {
                    ((mbCanvas) b.this.h()).r(true);
                }
            } catch (Exception unused) {
            }
            return super.onFling(motionEvent, motionEvent2, f2, f3);
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.t.d.b$b, reason: collision with other inner class name */
    class ViewOnClickListenerC0310b implements View.OnClickListener {
        ViewOnClickListenerC0310b() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((mbCanvas) b.this.h()).r(false);
        }
    }

    class c implements View.OnLongClickListener {
        c(b bVar) {
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            view.startDrag(ClipData.newPlainText(IMAPStore.ID_NAME, ((FB_MACRO) view.findViewById(R.id.fb_macro)).getName()), new View.DragShadowBuilder(view), view, 0);
            return false;
        }
    }

    class d implements View.OnLongClickListener {
        d() {
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            ((mbCanvas) b.this.h()).x0(true);
            return false;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public View e0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_tile_macros, viewGroup, false);
        ru.himik.nightscream.kascada.t.d.c cVar = new ru.himik.nightscream.kascada.t.d.c(this.l0);
        RecyclerView recyclerView = (RecyclerView) viewInflate.findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(MyApplication.b().h0, o1()));
        recyclerView.setAdapter(cVar);
        n.a aVar = n.a;
        cVar.w(aVar.d(".mcr", aVar.e() + MyApplication.b().m0 + "/"));
        if (cVar.c() == 0) {
            viewInflate.findViewById(R.id.tvEmptyLibrary).setVisibility(0);
        }
        viewInflate.findViewById(R.id.switch_layout).setOnClickListener(this.k0);
        viewInflate.findViewById(R.id.switch_layout).setOnLongClickListener(this.m0);
        final GestureDetector gestureDetector = new GestureDetector(h(), new a());
        recyclerView.setOnTouchListener(new View.OnTouchListener() { // from class: ru.himik.nightscream.kascada.t.d.a
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return gestureDetector.onTouchEvent(motionEvent);
            }
        });
        return viewInflate;
    }

    int o1() {
        DisplayMetrics displayMetrics = MyApplication.b().h0.getResources().getDisplayMetrics();
        return (int) ((displayMetrics.widthPixels / displayMetrics.density) / 180.0f);
    }
}
