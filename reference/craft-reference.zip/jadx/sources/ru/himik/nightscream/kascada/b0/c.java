package ru.himik.nightscream.kascada.b0;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import java.util.Objects;
import kotlin.b0.d.j;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class c {
    public static final c a = new c();
    private static SoundPool b = null;
    private static int c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static int f9173d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static int f9174e = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static float f9175f = 0.0f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static AudioManager f9176g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static int f9177h = 3;

    static {
        a aVar = new SoundPool.OnLoadCompleteListener() { // from class: ru.himik.nightscream.kascada.b0.a
            @Override // android.media.SoundPool.OnLoadCompleteListener
            public final void onLoadComplete(SoundPool soundPool, int i2, int i3) {
                c.a(soundPool, i2, i3);
            }
        };
        AudioAttributes audioAttributesBuild = new AudioAttributes.Builder().setUsage(14).setContentType(4).build();
        SoundPool.Builder builder = new SoundPool.Builder();
        builder.setAudioAttributes(audioAttributesBuild).setMaxStreams(2);
        SoundPool soundPoolBuild = builder.build();
        j.c(soundPoolBuild, "builder.build()");
        b = soundPoolBuild;
        soundPoolBuild.setOnLoadCompleteListener(aVar);
        c = b.load(MyApplication.b().h0, R.raw.voice_recognition_show, 1);
        f9173d = b.load(MyApplication.b().h0, R.raw.voice_recognition_ok, 1);
        f9174e = b.load(MyApplication.b().h0, R.raw.voice_recognition_error, 1);
        Object systemService = MyApplication.b().h0.getSystemService("audio");
        Objects.requireNonNull(systemService, "null cannot be cast to non-null type android.media.AudioManager");
        AudioManager audioManager = (AudioManager) systemService;
        f9176g = audioManager;
        f9175f = audioManager.getStreamVolume(f9177h) / f9176g.getStreamMaxVolume(f9177h);
    }

    private c() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void a(SoundPool soundPool, int i2, int i3) {
    }

    public final void c() {
        SoundPool soundPool = b;
        int i2 = f9174e;
        float f2 = f9175f;
        soundPool.play(i2, f2, f2, 1, 0, 1.0f);
    }

    public final void d() {
        SoundPool soundPool = b;
        int i2 = f9173d;
        float f2 = f9175f;
        soundPool.play(i2, f2, f2, 1, 0, 1.0f);
    }

    public final void e() {
        SoundPool soundPool = b;
        int i2 = c;
        float f2 = f9175f;
        soundPool.play(i2, f2, f2, 1, 0, 1.0f);
    }
}
