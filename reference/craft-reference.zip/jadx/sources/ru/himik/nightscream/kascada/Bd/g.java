package ru.himik.nightscream.kascada.Bd;

/* JADX INFO: loaded from: classes.dex */
public class g {
    public String a;
    public int b;
    public int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f8599d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f8600e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8601f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f8602g;

    public g(String str, int i2, int i3, String str2, String str3, int i4, boolean z) {
        this.f8602g = false;
        this.a = str;
        this.b = i2;
        this.c = i3;
        this.f8599d = str3;
        this.f8600e = str2;
        this.f8601f = i4;
        this.f8602g = z;
    }

    public int a() {
        return this.f8601f;
    }

    public int b() {
        return this.c;
    }

    public String c() {
        return this.f8599d;
    }

    public int d() {
        return this.b;
    }

    public String e() {
        return this.a;
    }

    public String f() {
        return this.f8600e;
    }

    public boolean g() {
        return this.f8602g;
    }
}
