package ru.himik.nightscream.kascada.CustomComponents.c0;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import f.e.a.a.c;
import f.e.a.a.d.a.f;
import ru.himik.nightscream.kascada.y;

/* JADX INFO: loaded from: classes2.dex */
public class a extends c {
    private Paint A0;
    private Paint B0;
    private Paint C0;
    private RectF D0;
    private boolean E0;
    private Path z0;

    public a(Context context) {
        this(context, null);
    }

    public a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public a(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.z0 = new Path();
        this.A0 = new Paint(1);
        this.B0 = new Paint(1);
        this.C0 = new Paint(1);
        this.D0 = new RectF();
        this.E0 = false;
        o();
        q(context, attributeSet);
    }

    private void R() {
        this.B0.setStrokeWidth(getSpeedometerWidth());
        this.C0.setColor(getMarkColor());
    }

    private void o() {
        this.B0.setStyle(Paint.Style.STROKE);
        this.C0.setStyle(Paint.Style.STROKE);
        this.A0.setColor(-12303292);
    }

    private void q(Context context, AttributeSet attributeSet) {
        if (attributeSet == null) {
            return;
        }
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, y.a, 0, 0);
        Paint paint = this.A0;
        paint.setColor(typedArrayObtainStyledAttributes.getColor(0, paint.getColor()));
        typedArrayObtainStyledAttributes.recycle();
    }

    @Override // f.e.a.a.a
    protected void C() {
        boolean z;
        Canvas canvasH = H();
        R();
        float viewSizePa = getViewSizePa() / 28.0f;
        this.z0.reset();
        this.z0.moveTo(getSize() * 0.5f, getPadding());
        this.z0.lineTo(getSize() * 0.5f, getPadding() + viewSizePa);
        float f2 = viewSizePa / 3.0f;
        this.C0.setStrokeWidth(f2);
        float speedometerWidth = (getSpeedometerWidth() * 0.5f) + getPadding();
        this.D0.set(speedometerWidth, speedometerWidth, getSize() - speedometerWidth, getSize() - speedometerWidth);
        int i2 = 0;
        if (this.E0) {
            this.B0.setColor(0);
            z = false;
            canvasH.drawArc(this.D0, getStartDegree(), getEndDegree() - getStartDegree(), false, this.B0);
            canvasH.drawArc(this.D0, getStartDegree(), getMediumSpeedOffset() * (getEndDegree() - getStartDegree()), false, this.B0);
        } else {
            this.B0.setColor(getHighSpeedColor());
            z = false;
            canvasH.drawArc(this.D0, getStartDegree(), getEndDegree() - getStartDegree(), false, this.B0);
            this.B0.setColor(getMediumSpeedColor());
            canvasH.drawArc(this.D0, getStartDegree(), getMediumSpeedOffset() * (getEndDegree() - getStartDegree()), false, this.B0);
            this.B0.setColor(getLowSpeedColor());
        }
        canvasH.drawArc(this.D0, getStartDegree(), getLowSpeedOffset() * (getEndDegree() - getStartDegree()), z, this.B0);
        canvasH.save();
        canvasH.rotate(getStartDegree() + 90.0f, getSize() * 0.5f, getSize() * 0.5f);
        for (float startDegree = getStartDegree(); startDegree < getEndDegree() - 21.6f; startDegree += 10.8f) {
            i2++;
            canvasH.rotate(10.8f, getSize() * 0.5f, getSize() * 0.5f);
            if (i2 % 5 != 0) {
                this.C0.setStrokeWidth(f2 / 2.0f);
            } else {
                this.C0.setStrokeWidth(f2);
            }
            canvasH.drawPath(this.z0, this.C0);
        }
        canvasH.restore();
        if (getTickNumber() > 0) {
            M(canvasH);
        } else {
            J(canvasH);
        }
    }

    @Override // f.e.a.a.c
    protected void I() {
        super.setIndicator(new f(getContext()));
        super.setBackgroundCircleColor(0);
    }

    public boolean S() {
        return this.E0;
    }

    public int getCenterCircleColor() {
        return this.A0.getColor();
    }

    @Override // f.e.a.a.a
    protected void l() {
    }

    @Override // f.e.a.a.c, f.e.a.a.a, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        n(canvas);
        K(canvas);
        canvas.drawCircle(getSize() * 0.5f, getSize() * 0.5f, getWidthPa() / 12.0f, this.A0);
        L(canvas);
    }

    @Override // f.e.a.a.c, f.e.a.a.a, android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        C();
    }

    public void setCenterCircleColor(int i2) {
        this.A0.setColor(i2);
        if (isAttachedToWindow()) {
            invalidate();
        }
    }

    public void setHideBackground(boolean z) {
        this.E0 = z;
        C();
    }
}
