package ru.himik.nightscream.kascada.Preference.Address;

import android.content.res.Resources;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class a extends PreferenceFragment {
    int a;
    int b;
    int c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f9047d = 0;

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.Address.a$a, reason: collision with other inner class name */
    class C0289a implements Preference.OnPreferenceChangeListener {
        final /* synthetic */ EditTextPreference a;
        final /* synthetic */ ListPreference b;

        C0289a(EditTextPreference editTextPreference, ListPreference listPreference) {
            this.a = editTextPreference;
            this.b = listPreference;
        }

        @Override // android.preference.Preference.OnPreferenceChangeListener
        public boolean onPreferenceChange(Preference preference, Object obj) {
            ListPreference listPreference;
            Resources resources;
            int i2;
            if (obj.equals("0")) {
                this.a.setEnabled(false);
                listPreference = this.b;
                resources = a.this.getResources();
                i2 = R.string.pref_sms_receive_count_reg;
            } else {
                this.a.setEnabled(true);
                listPreference = this.b;
                resources = a.this.getResources();
                i2 = R.string.bit;
            }
            listPreference.setSummary(resources.getString(i2));
            return true;
        }
    }

    @Override // android.preference.PreferenceFragment, android.app.Fragment
    public void onCreate(Bundle bundle) {
        EditTextPreference editTextPreference;
        int i2;
        Resources resources;
        int i3;
        super.onCreate(bundle);
        int i4 = this.c;
        if (i4 == 1) {
            addPreferencesFromResource(R.xml.base_address_connection);
            ((EditTextPreference) findPreference("address_register")).setText(String.valueOf(this.a));
            editTextPreference = (EditTextPreference) findPreference("address_bit");
            i2 = this.b;
        } else {
            if (i4 != 4) {
                if (i4 != 5) {
                    switch (i4) {
                        case 7:
                        case 8:
                        case 11:
                        case 12:
                        case 13:
                        case 14:
                        case 17:
                        case 19:
                        case 20:
                        case 21:
                            break;
                        case 9:
                        case 10:
                        case 15:
                        case 16:
                            break;
                        case 18:
                            addPreferencesFromResource(R.xml.base_address_connection_sms_receive);
                            ((EditTextPreference) findPreference("address_register")).setText(String.valueOf(this.a));
                            EditTextPreference editTextPreference2 = (EditTextPreference) findPreference("address_bit");
                            editTextPreference2.setText(String.valueOf(this.b));
                            ListPreference listPreference = (ListPreference) findPreference("SmsReceiveTypeCommand");
                            if (this.f9047d == 0) {
                                editTextPreference2.setEnabled(false);
                                resources = getResources();
                                i3 = R.string.pref_sms_receive_count_reg;
                            } else {
                                editTextPreference2.setEnabled(true);
                                resources = getResources();
                                i3 = R.string.bit;
                            }
                            listPreference.setSummary(resources.getString(i3));
                            listPreference.setValueIndex(this.f9047d);
                            listPreference.setOnPreferenceChangeListener(new C0289a(editTextPreference2, listPreference));
                            return;
                        default:
                            return;
                    }
                }
                addPreferencesFromResource(R.xml.base_address_connection);
                ((EditTextPreference) findPreference("address_register")).setText(String.valueOf(this.a));
                editTextPreference = (EditTextPreference) findPreference("address_bit");
                i2 = this.b;
            }
            addPreferencesFromResource(R.xml.register_address_connection);
            editTextPreference = (EditTextPreference) findPreference("address_register");
            i2 = this.a;
        }
        editTextPreference.setText(String.valueOf(i2));
    }
}
