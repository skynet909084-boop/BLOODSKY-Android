package ru.himik.nightscream.kascada.Logic.VarName;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class VarNameIn extends f implements b {
    String V;
    int W;
    int a0;
    Path b0;
    private int c0;
    private boolean d0;
    private float e0;

    public VarNameIn(Context context) {
        super(context);
        this.V = "VAR_NAME_IN";
        this.W = 1;
        this.a0 = 1;
        this.b0 = new Path();
        this.c0 = 0;
        this.d0 = false;
        this.e0 = 0.0f;
        this.E = "var name";
    }

    public VarNameIn(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = "VAR_NAME_IN";
        this.W = 1;
        this.a0 = 1;
        this.b0 = new Path();
        this.c0 = 0;
        this.d0 = false;
        this.e0 = 0.0f;
        this.E = "var name";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean g() {
        return this.o;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("typeVar", getTypeVar());
        jSONObject.put("typeVarValue", getTypeVarValue());
        jSONObject.put("invertOut", getInvertOut());
        if (getTypeVarValue() == 2) {
            jSONObject.put("isConstant", g());
            int typeVar = getTypeVar();
            if (typeVar == 1) {
                jSONObject.put("constant", getVarConstant());
            } else if (typeVar == 2) {
                jSONObject.put("constant", getVarIntConstant());
            } else if (typeVar == 3) {
                jSONObject.put("constant", getVarFloatConstant());
            }
        } else {
            jSONObject.put(IMAPStore.ID_NAME, getVarName());
        }
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        int i2 = this.W;
        if (i2 == 1) {
            if (this.o) {
                return Boolean.valueOf(this.d0);
            }
            long rootUniqueIdMacro = getRootUniqueIdMacro();
            a aVar = MyApplication.A0;
            if (rootUniqueIdMacro <= 0) {
                return Boolean.valueOf(aVar.e(getVarName()));
            }
            return Boolean.valueOf(aVar.e(getRootUniqueIdMacro() + "_" + getVarName()));
        }
        if (i2 == 2) {
            if (this.o) {
                return Integer.valueOf(this.c0);
            }
            long rootUniqueIdMacro2 = getRootUniqueIdMacro();
            a aVar2 = MyApplication.A0;
            if (rootUniqueIdMacro2 <= 0) {
                return Integer.valueOf(aVar2.g(getVarName()));
            }
            return Integer.valueOf(aVar2.g(getRootUniqueIdMacro() + "_" + getVarName()));
        }
        if (i2 != 3) {
            return null;
        }
        if (this.o) {
            return Float.valueOf(this.e0);
        }
        long rootUniqueIdMacro3 = getRootUniqueIdMacro();
        a aVar3 = MyApplication.A0;
        if (rootUniqueIdMacro3 <= 0) {
            return Float.valueOf(aVar3.f(getVarName()));
        }
        return Float.valueOf(aVar3.f(getRootUniqueIdMacro() + "_" + getVarName()));
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 133;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public int getTypeVar() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public int getTypeVarValue() {
        return this.a0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean getVarConstant() {
        return this.d0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public float getVarFloatConstant() {
        return this.e0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getVarIntConstant() {
        return this.c0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public String getVarName() {
        return this.E;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.b0.setFillType(Path.FillType.EVEN_ODD);
        this.f9013f.setStrokeWidth(this.R);
        this.b0.reset();
        Path path = this.b0;
        int i2 = this.R;
        path.moveTo(i2, i2);
        this.b0.lineTo(getWidth() - (this.Q * 2), this.R);
        this.b0.lineTo(getWidth() - this.Q, getHeight() / 2);
        this.b0.lineTo(getWidth() - (this.Q * 2), getHeight() - this.R);
        this.b0.lineTo(this.R, getHeight() - this.R);
        this.b0.lineTo(this.R, getHeight() - this.R);
        Path path2 = this.b0;
        int i3 = this.R;
        path2.lineTo(i3, i3);
        this.b0.close();
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawPath(this.b0, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawPath(this.b0, this.f9013f);
        if (this.f9018k && this.W == 1) {
            canvas.drawCircle((getWidth() - this.Q) + this.S, getHeight() / 2, this.S, this.f9013f);
            width = (getWidth() - this.Q) + (this.S * 2);
        } else {
            width = getWidth() - this.Q;
        }
        canvas.drawLine(width, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - this.Q, (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        super.onDraw(canvas);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x004c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:18:0x004e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:20:0x0051  */
    /* JADX WARN: Code duplicated, block: B:21:0x0057  */
    /* JADX WARN: Code duplicated, block: B:22:0x005d  */
    /* JADX WARN: Code duplicated, block: B:25:? A[RETURN, SYNTHETIC] */
    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        String string;
        int i4;
        Paint paint;
        int color;
        StringBuilder sb;
        if (this.o) {
            int i5 = this.W;
            if (i5 == 1) {
                sb = new StringBuilder();
                sb.append("#");
                sb.append(this.d0);
            } else {
                if (i5 != 2) {
                    if (i5 == 3) {
                        sb = new StringBuilder();
                        sb.append("#");
                        sb.append(this.e0);
                    }
                    super.onMeasure(i2, i3);
                    i4 = this.W;
                    if (i4 != 1) {
                        paint = this.f9014g;
                        color = getResources().getColor(R.color.text_color_logic);
                    } else if (i4 != 2) {
                        paint = this.f9014g;
                        color = -16711936;
                    } else {
                        if (i4 != 3) {
                            return;
                        }
                        paint = this.f9014g;
                        color = -16776961;
                    }
                    paint.setColor(color);
                }
                sb = new StringBuilder();
                sb.append("#");
                sb.append(this.c0);
            }
            string = sb.toString();
        } else {
            string = this.E;
        }
        setVarName(string);
        super.onMeasure(i2, i3);
        i4 = this.W;
        if (i4 != 1) {
            paint = this.f9014g;
            color = getResources().getColor(R.color.text_color_logic);
        } else if (i4 != 2) {
            paint = this.f9014g;
            color = -16711936;
        } else {
            if (i4 != 3) {
                return;
            }
            paint = this.f9014g;
            color = -16776961;
        }
        paint.setColor(color);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setConstant(boolean z) {
        this.o = z;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public void setTypeVar(int i2) {
        this.W = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public void setTypeVarValue(int i2) {
        this.a0 = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setVarConstant(boolean z) {
        this.d0 = z;
        requestLayout();
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setVarFloatConstant(float f2) {
        this.e0 = f2;
        requestLayout();
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setVarIntConstant(int i2) {
        this.c0 = i2;
        requestLayout();
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public void setVarName(String str) {
        this.E = str;
        requestLayout();
        invalidate();
        r();
    }
}
