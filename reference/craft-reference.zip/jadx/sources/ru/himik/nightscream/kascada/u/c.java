package ru.himik.nightscream.kascada.u;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.Provider;

/* JADX INFO: loaded from: classes2.dex */
public final class c extends Provider {

    class a implements PrivilegedAction<Void> {
        a() {
        }

        @Override // java.security.PrivilegedAction
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Void run() {
            c.this.put("SSLContext.TLS", "org.apache.harmony.xnet.provider.jsse.SSLContextImpl");
            c.this.put("Alg.Alias.SSLContext.TLSv1", "TLS");
            c.this.put("KeyManagerFactory.X509", "org.apache.harmony.xnet.provider.jsse.KeyManagerFactoryImpl");
            c.this.put("TrustManagerFactory.X509", "org.apache.harmony.xnet.provider.jsse.TrustManagerFactoryImpl");
            return null;
        }
    }

    public c() {
        super("HarmonyJSSE", 1.0d, "Harmony JSSE Provider");
        AccessController.doPrivileged(new a());
    }
}
