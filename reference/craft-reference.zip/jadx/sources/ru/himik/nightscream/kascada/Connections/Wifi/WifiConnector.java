package ru.himik.nightscream.kascada.Connections.Wifi;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import com.karumi.dexter.R;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import kotlin.KotlinVersion;
import ru.himik.nightscream.kascada.CustomComponents.b;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.himik.nightscream.kascada.q.a;

/* JADX INFO: loaded from: classes.dex */
public class WifiConnector extends Thread implements a {
    Context M;
    int N;
    String a;
    int b;
    Handler c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8652d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private Socket f8655g;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    SocketAddress f8658j;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8653e = 2;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f8654f = true;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f8656h = 3000;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f8657i = 5000;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    ArrayList<b> f8659k = new ArrayList<>();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    int f8660l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8661m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    int f8662n = 0;
    public ArrayList<b> o = new ArrayList<>();
    b C = null;
    ru.himik.nightscream.kascada.x.a D = new ru.himik.nightscream.kascada.x.a();
    long E = 0;
    long F = 2000;
    int G = 0;
    byte[] H = new byte[KotlinVersion.MAX_COMPONENT_VALUE];
    byte[] I = new byte[KotlinVersion.MAX_COMPONENT_VALUE];
    int J = 0;
    int K = 0;
    int L = 0;
    private boolean O = false;

    static {
        System.loadLibrary("modbus");
    }

    public WifiConnector(String str, int i2, Handler handler, int i3, boolean z, Context context, int i4) {
        this.a = "127.0.0.1";
        this.b = 502;
        this.f8652d = -1;
        this.N = 0;
        this.a = str;
        this.b = i2;
        this.c = handler;
        this.f8652d = i3;
        this.M = context;
        this.N = i4;
    }

    private void g(b bVar, byte[] bArr) {
        Handler handler;
        int iH;
        int iJ;
        int i2;
        Message messageObtainMessage;
        int i3;
        Integer numValueOf;
        int i4;
        int i5;
        if (bVar == null) {
            return;
        }
        int length = bArr.length;
        int[] iArr = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            iArr[i6] = bArr[i6] & 255;
        }
        byte bQ = bVar.q();
        if (bQ == 1) {
            int iH2 = bVar.h();
            if (iH2 == 19) {
                handler = this.c;
                iH = R.styleable.AppCompatTheme_textAppearanceListItemSecondary;
                iJ = bVar.j();
                i2 = iArr[3];
            } else if (iH2 != 22) {
                handler = this.c;
                iH = bVar.h();
                iJ = bVar.j();
                i2 = iArr[3];
            } else if (bVar.f() > 8) {
                byte[] bArr2 = new byte[2];
                System.arraycopy(bArr, 3, bArr2, 0, 2);
                messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr2);
            } else {
                byte[] bArr3 = new byte[1];
                System.arraycopy(bArr, 3, bArr3, 0, 1);
                messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr3);
            }
            i3 = (i2 >> 0) & 1;
            numValueOf = Integer.valueOf(i3);
            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
        } else if (bQ != 2) {
            if (bQ != 3) {
                if (bQ != 4) {
                    if (bQ != 5 || bVar.h() == 22) {
                        return;
                    }
                    handler = this.c;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i3 = iArr[4];
                    numValueOf = Integer.valueOf(i3);
                    messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                    int[] iArr2 = new int[bVar.g() * 2];
                    System.arraycopy(iArr, 3, iArr2, 0, bVar.g() * 2);
                    messageObtainMessage = this.c.obtainMessage(1, bVar.h(), bVar.j(), iArr2);
                } else {
                    handler = this.c;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i4 = iArr[3] * 256;
                    i5 = iArr[4];
                    numValueOf = Integer.valueOf(i4 + i5);
                    messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                }
            } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                int[] iArr3 = new int[bVar.g() * 2];
                System.arraycopy(iArr, 3, iArr3, 0, bVar.g() * 2);
                messageObtainMessage = this.c.obtainMessage(1, bVar.h(), bVar.j(), iArr3);
            } else {
                handler = this.c;
                iH = bVar.h();
                iJ = bVar.j();
                i4 = iArr[3] * 256;
                i5 = iArr[4];
                numValueOf = Integer.valueOf(i4 + i5);
                messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
            }
        } else if (bVar.h() != 22) {
            handler = this.c;
            iH = bVar.h();
            iJ = bVar.j();
            i2 = iArr[3];
            i3 = (i2 >> 0) & 1;
            numValueOf = Integer.valueOf(i3);
            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
        } else if (bVar.f() > 8) {
            byte[] bArr4 = new byte[2];
            System.arraycopy(bArr, 3, bArr4, 0, 2);
            messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr4);
        } else {
            byte[] bArr5 = new byte[1];
            System.arraycopy(bArr, 3, bArr5, 0, 1);
            messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr5);
        }
        messageObtainMessage.sendToTarget();
    }

    private void h(b bVar, byte[] bArr) {
        Message messageObtainMessage;
        Handler handler;
        int iH;
        int iJ;
        int i2;
        int i3;
        Integer numValueOf;
        int i4;
        int i5;
        if (bVar == null) {
            return;
        }
        int length = bArr.length;
        int[] iArr = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            iArr[i6] = bArr[i6] & 255;
        }
        if (length >= 10) {
            if (bVar.b() == iArr[6] && bVar.q() == iArr[7]) {
                byte bQ = bVar.q();
                if (bQ == 1) {
                    int iH2 = bVar.h();
                    if (iH2 != 22) {
                        if (iH2 != 102) {
                            handler = this.c;
                            iH = bVar.h();
                            iJ = bVar.j();
                            i2 = iArr[9];
                            i3 = (i2 >> 0) & 1;
                            numValueOf = Integer.valueOf(i3);
                            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                        } else {
                            messageObtainMessage = this.c.obtainMessage(1, R.styleable.AppCompatTheme_textAppearanceListItemSecondary, bVar.j(), Integer.valueOf((iArr[9] >> 0) & 1));
                        }
                    } else if (bVar.f() > 8) {
                        byte[] bArr2 = new byte[2];
                        System.arraycopy(bArr, 9, bArr2, 0, 2);
                        messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr2);
                    } else {
                        byte[] bArr3 = new byte[1];
                        System.arraycopy(bArr, 9, bArr3, 0, 1);
                        messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr3);
                    }
                } else if (bQ != 2) {
                    if (bQ != 3) {
                        if (bQ != 4) {
                            if (bQ != 5 || bVar.h() == 22) {
                                return;
                            }
                            handler = this.c;
                            iH = bVar.h();
                            iJ = bVar.j();
                            i3 = iArr[10];
                            numValueOf = Integer.valueOf(i3);
                            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                        } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                            int[] iArr2 = new int[bVar.g() * 2];
                            System.arraycopy(iArr, 9, iArr2, 0, bVar.g() * 2);
                            messageObtainMessage = this.c.obtainMessage(1, bVar.h(), bVar.j(), iArr2);
                        } else {
                            handler = this.c;
                            iH = bVar.h();
                            iJ = bVar.j();
                            i4 = iArr[9] * 256;
                            i5 = iArr[10];
                            numValueOf = Integer.valueOf(i4 + i5);
                            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                        }
                    } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                        int[] iArr3 = new int[bVar.g() * 2];
                        System.arraycopy(iArr, 9, iArr3, 0, bVar.g() * 2);
                        messageObtainMessage = this.c.obtainMessage(1, bVar.h(), bVar.j(), iArr3);
                    } else {
                        handler = this.c;
                        iH = bVar.h();
                        iJ = bVar.j();
                        i4 = iArr[9] * 256;
                        i5 = iArr[10];
                        numValueOf = Integer.valueOf(i4 + i5);
                        messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                    }
                } else if (bVar.h() != 22 && bVar.h() != 103) {
                    handler = this.c;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i2 = iArr[9];
                    i3 = (i2 >> 0) & 1;
                    numValueOf = Integer.valueOf(i3);
                    messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                } else if (bVar.f() > 8) {
                    byte[] bArr4 = new byte[2];
                    System.arraycopy(bArr, 9, bArr4, 0, 2);
                    messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr4);
                } else {
                    byte[] bArr5 = new byte[1];
                    System.arraycopy(bArr, 9, bArr5, 0, 1);
                    messageObtainMessage = this.c.obtainMessage(1, 22, bVar.j(), bArr5);
                }
            } else if (bVar.b() == 0) {
                return;
            }
            messageObtainMessage.sendToTarget();
        }
        if (bVar.b() == 0) {
            return;
        }
        messageObtainMessage = this.c.obtainMessage(2, bVar.h(), bVar.j());
        messageObtainMessage.sendToTarget();
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public int a() {
        return this.f8652d;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public String b() {
        return this.a + ":" + this.b;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void c(b bVar) {
        if (bVar != null) {
            this.o.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void cancel() {
        this.f8654f = false;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void d() {
        start();
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void e(b bVar) {
        if (bVar != null) {
            this.o.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void f(b bVar) {
        this.f8659k.add(bVar);
    }

    public native int getSomeValue();

    public native void init(Context context);

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:101:0x01ef A[Catch: Exception -> 0x02e4, TryCatch #9 {Exception -> 0x02e4, blocks: (B:14:0x0033, B:40:0x00ae, B:44:0x00c0, B:45:0x00de, B:46:0x00e5, B:48:0x00f2, B:49:0x00f4, B:51:0x0100, B:53:0x010c, B:55:0x012a, B:56:0x0134, B:61:0x0145, B:103:0x01f6, B:105:0x01fa, B:107:0x0202, B:110:0x020c, B:112:0x0210, B:113:0x021d, B:115:0x0225, B:116:0x0229, B:117:0x022c, B:118:0x022f, B:121:0x0239, B:123:0x023d, B:124:0x0240, B:125:0x024d, B:127:0x0255, B:128:0x025a, B:130:0x0260, B:132:0x0269, B:134:0x0274, B:137:0x0280, B:62:0x014c, B:64:0x0150, B:66:0x0162, B:68:0x016c, B:70:0x0170, B:71:0x0173, B:73:0x017a, B:74:0x017f, B:78:0x0188, B:80:0x0192, B:86:0x01ac, B:88:0x01b4, B:90:0x01bb, B:91:0x01c1, B:94:0x01c7, B:99:0x01e8, B:101:0x01ef, B:102:0x01f4, B:82:0x019a, B:84:0x01a4, B:139:0x0283, B:147:0x02b8, B:149:0x02bc, B:151:0x02c2, B:141:0x02a0, B:143:0x02af, B:145:0x02b4, B:152:0x02cf, B:154:0x02d3, B:156:0x02d9), top: B:197:0x0033 }] */
    /* JADX WARN: Code duplicated, block: B:102:0x01f4 A[Catch: Exception -> 0x02e4, TryCatch #9 {Exception -> 0x02e4, blocks: (B:14:0x0033, B:40:0x00ae, B:44:0x00c0, B:45:0x00de, B:46:0x00e5, B:48:0x00f2, B:49:0x00f4, B:51:0x0100, B:53:0x010c, B:55:0x012a, B:56:0x0134, B:61:0x0145, B:103:0x01f6, B:105:0x01fa, B:107:0x0202, B:110:0x020c, B:112:0x0210, B:113:0x021d, B:115:0x0225, B:116:0x0229, B:117:0x022c, B:118:0x022f, B:121:0x0239, B:123:0x023d, B:124:0x0240, B:125:0x024d, B:127:0x0255, B:128:0x025a, B:130:0x0260, B:132:0x0269, B:134:0x0274, B:137:0x0280, B:62:0x014c, B:64:0x0150, B:66:0x0162, B:68:0x016c, B:70:0x0170, B:71:0x0173, B:73:0x017a, B:74:0x017f, B:78:0x0188, B:80:0x0192, B:86:0x01ac, B:88:0x01b4, B:90:0x01bb, B:91:0x01c1, B:94:0x01c7, B:99:0x01e8, B:101:0x01ef, B:102:0x01f4, B:82:0x019a, B:84:0x01a4, B:139:0x0283, B:147:0x02b8, B:149:0x02bc, B:151:0x02c2, B:141:0x02a0, B:143:0x02af, B:145:0x02b4, B:152:0x02cf, B:154:0x02d3, B:156:0x02d9), top: B:197:0x0033 }] */
    /* JADX WARN: Code duplicated, block: B:116:0x0229 A[Catch: Exception -> 0x02e4, TryCatch #9 {Exception -> 0x02e4, blocks: (B:14:0x0033, B:40:0x00ae, B:44:0x00c0, B:45:0x00de, B:46:0x00e5, B:48:0x00f2, B:49:0x00f4, B:51:0x0100, B:53:0x010c, B:55:0x012a, B:56:0x0134, B:61:0x0145, B:103:0x01f6, B:105:0x01fa, B:107:0x0202, B:110:0x020c, B:112:0x0210, B:113:0x021d, B:115:0x0225, B:116:0x0229, B:117:0x022c, B:118:0x022f, B:121:0x0239, B:123:0x023d, B:124:0x0240, B:125:0x024d, B:127:0x0255, B:128:0x025a, B:130:0x0260, B:132:0x0269, B:134:0x0274, B:137:0x0280, B:62:0x014c, B:64:0x0150, B:66:0x0162, B:68:0x016c, B:70:0x0170, B:71:0x0173, B:73:0x017a, B:74:0x017f, B:78:0x0188, B:80:0x0192, B:86:0x01ac, B:88:0x01b4, B:90:0x01bb, B:91:0x01c1, B:94:0x01c7, B:99:0x01e8, B:101:0x01ef, B:102:0x01f4, B:82:0x019a, B:84:0x01a4, B:139:0x0283, B:147:0x02b8, B:149:0x02bc, B:151:0x02c2, B:141:0x02a0, B:143:0x02af, B:145:0x02b4, B:152:0x02cf, B:154:0x02d3, B:156:0x02d9), top: B:197:0x0033 }] */
    /* JADX WARN: Code duplicated, block: B:117:0x022c A[Catch: Exception -> 0x02e4, TryCatch #9 {Exception -> 0x02e4, blocks: (B:14:0x0033, B:40:0x00ae, B:44:0x00c0, B:45:0x00de, B:46:0x00e5, B:48:0x00f2, B:49:0x00f4, B:51:0x0100, B:53:0x010c, B:55:0x012a, B:56:0x0134, B:61:0x0145, B:103:0x01f6, B:105:0x01fa, B:107:0x0202, B:110:0x020c, B:112:0x0210, B:113:0x021d, B:115:0x0225, B:116:0x0229, B:117:0x022c, B:118:0x022f, B:121:0x0239, B:123:0x023d, B:124:0x0240, B:125:0x024d, B:127:0x0255, B:128:0x025a, B:130:0x0260, B:132:0x0269, B:134:0x0274, B:137:0x0280, B:62:0x014c, B:64:0x0150, B:66:0x0162, B:68:0x016c, B:70:0x0170, B:71:0x0173, B:73:0x017a, B:74:0x017f, B:78:0x0188, B:80:0x0192, B:86:0x01ac, B:88:0x01b4, B:90:0x01bb, B:91:0x01c1, B:94:0x01c7, B:99:0x01e8, B:101:0x01ef, B:102:0x01f4, B:82:0x019a, B:84:0x01a4, B:139:0x0283, B:147:0x02b8, B:149:0x02bc, B:151:0x02c2, B:141:0x02a0, B:143:0x02af, B:145:0x02b4, B:152:0x02cf, B:154:0x02d3, B:156:0x02d9), top: B:197:0x0033 }] */
    /* JADX WARN: Code duplicated, block: B:123:0x023d A[Catch: Exception -> 0x02e4, TryCatch #9 {Exception -> 0x02e4, blocks: (B:14:0x0033, B:40:0x00ae, B:44:0x00c0, B:45:0x00de, B:46:0x00e5, B:48:0x00f2, B:49:0x00f4, B:51:0x0100, B:53:0x010c, B:55:0x012a, B:56:0x0134, B:61:0x0145, B:103:0x01f6, B:105:0x01fa, B:107:0x0202, B:110:0x020c, B:112:0x0210, B:113:0x021d, B:115:0x0225, B:116:0x0229, B:117:0x022c, B:118:0x022f, B:121:0x0239, B:123:0x023d, B:124:0x0240, B:125:0x024d, B:127:0x0255, B:128:0x025a, B:130:0x0260, B:132:0x0269, B:134:0x0274, B:137:0x0280, B:62:0x014c, B:64:0x0150, B:66:0x0162, B:68:0x016c, B:70:0x0170, B:71:0x0173, B:73:0x017a, B:74:0x017f, B:78:0x0188, B:80:0x0192, B:86:0x01ac, B:88:0x01b4, B:90:0x01bb, B:91:0x01c1, B:94:0x01c7, B:99:0x01e8, B:101:0x01ef, B:102:0x01f4, B:82:0x019a, B:84:0x01a4, B:139:0x0283, B:147:0x02b8, B:149:0x02bc, B:151:0x02c2, B:141:0x02a0, B:143:0x02af, B:145:0x02b4, B:152:0x02cf, B:154:0x02d3, B:156:0x02d9), top: B:197:0x0033 }] */
    /* JADX WARN: Code duplicated, block: B:187:0x01c7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:97:0x01e6  */
    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        Socket socket;
        char c;
        int i2;
        char c2;
        int i3;
        System.currentTimeMillis();
        this.f8658j = new InetSocketAddress(this.a, this.b);
        this.f8660l = this.f8659k.size();
        char c3 = 4;
        InputStream inputStream = null;
        OutputStream outputStream = null;
        char c4 = 0;
        while (true) {
            byte b = 0;
            while (true) {
                if (!this.f8654f) {
                    try {
                        Socket socket2 = this.f8655g;
                        if (socket2 != null) {
                            socket2.close();
                        }
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        if (outputStream != null) {
                            outputStream.close();
                            return;
                        }
                        return;
                    } catch (IOException unused) {
                        return;
                    }
                }
                if (c4 == 0) {
                    Socket socket3 = this.f8655g;
                    if (socket3 == null || !socket3.isConnected()) {
                        this.f8655g = new Socket();
                    }
                    c4 = 1;
                } else if (c4 == 1) {
                    try {
                        try {
                            this.f8655g.connect(this.f8658j, this.f8656h);
                            this.f8655g.setSoTimeout(this.f8657i);
                            inputStream = this.f8655g.getInputStream();
                            outputStream = this.f8655g.getOutputStream();
                        } catch (IOException | InterruptedException unused2) {
                            c4 = 4;
                        }
                    } catch (IOException unused3) {
                        Thread.sleep(this.f8656h);
                        this.f8655g.close();
                        this.f8655g = null;
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        if (outputStream != null) {
                            outputStream.close();
                        }
                        c4 = 4;
                        socket = this.f8655g;
                        if (socket != null) {
                            this.c.obtainMessage(6, 1, this.f8652d).sendToTarget();
                            c4 = 2;
                        }
                        c3 = 4;
                    }
                    socket = this.f8655g;
                    if (socket != null && socket.isConnected()) {
                        this.c.obtainMessage(6, 1, this.f8652d).sendToTarget();
                        c4 = 2;
                    }
                } else if (c4 == 2) {
                    if (System.currentTimeMillis() - this.E >= 1500) {
                        this.O = true;
                    }
                    if (this.o.size() > 0) {
                        b bVar = this.o.get(0);
                        this.C = bVar;
                        if (outputStream != null) {
                            try {
                                outputStream.write(this.D.c(bVar, this.f8653e));
                                outputStream.flush();
                                byte[] bArrC = this.D.c(this.C, this.f8653e);
                                int length = bArrC.length;
                                int[] iArr = new int[length];
                                for (int i4 = 0; i4 < length; i4++) {
                                    iArr[i4] = bArrC[i4] & 255;
                                }
                                this.J++;
                                this.E = System.currentTimeMillis();
                                c2 = 3;
                            } catch (IOException unused4) {
                                c4 = 4;
                            }
                        } else {
                            c2 = 4;
                        }
                        c4 = c2;
                        this.o.remove(0);
                    } else if (this.f8660l > 0) {
                        b bVar2 = this.f8659k.get(this.f8661m);
                        this.C = bVar2;
                        if (bVar2.m() <= 0 || mbCanvas.a1 == this.C.m()) {
                            if (((this.C.h() == 19 || this.C.q() != 16) && !(this.C.h() == 22 && this.C.q() == 15)) || this.C.s()) {
                                if (outputStream != null) {
                                    try {
                                        outputStream.write(this.D.c(this.C, this.f8653e));
                                        outputStream.flush();
                                        this.J++;
                                        this.E = System.currentTimeMillis();
                                        c = 3;
                                    } catch (IOException unused5) {
                                        c4 = 4;
                                    }
                                } else {
                                    c = 4;
                                }
                                c4 = c;
                                i2 = this.f8661m;
                                if (i2 != this.f8660l - 1) {
                                    this.f8661m = i2 + 1;
                                } else {
                                    this.f8661m = 0;
                                }
                            } else {
                                int i5 = this.f8661m;
                                if (i5 != this.f8660l - 1) {
                                    this.f8661m = i5 + 1;
                                } else {
                                    this.f8661m = 0;
                                }
                            }
                        } else if (this.O) {
                            this.O = false;
                            if (this.C.h() == 19) {
                            }
                            if (outputStream != null) {
                                outputStream.write(this.D.c(this.C, this.f8653e));
                                outputStream.flush();
                                this.J++;
                                this.E = System.currentTimeMillis();
                                c = 3;
                            } else {
                                c = 4;
                            }
                            c4 = c;
                            i2 = this.f8661m;
                            if (i2 != this.f8660l - 1) {
                                this.f8661m = i2 + 1;
                            } else {
                                this.f8661m = 0;
                            }
                        } else {
                            int i6 = this.f8661m;
                            if (i6 != this.f8660l - 1) {
                                this.f8661m = i6 + 1;
                            } else {
                                this.f8661m = 0;
                            }
                            try {
                                Thread.sleep(1L);
                            } catch (Exception unused6) {
                            }
                        }
                    }
                    b bVar3 = this.C;
                    if (bVar3 != null) {
                        if (bVar3.r()) {
                            byte bQ = this.C.q();
                            if (bQ == 15) {
                                this.f8662n = 8;
                            } else if (bQ != 16) {
                                switch (bQ) {
                                    case 1:
                                    case 2:
                                        if (this.C.f() > 8) {
                                            this.f8662n = 7;
                                        } else {
                                            this.f8662n = 6;
                                        }
                                        break;
                                    case 3:
                                    case 4:
                                        this.f8662n = (this.C.g() * 2) + 5;
                                        break;
                                    case 5:
                                    case 6:
                                        this.f8662n = 8;
                                        break;
                                }
                            } else {
                                this.f8662n = 6;
                            }
                        } else {
                            byte bQ2 = this.C.q();
                            if (bQ2 != 16) {
                                switch (bQ2) {
                                    case 1:
                                    case 2:
                                        if (this.C.f() > 8) {
                                            this.f8662n = 11;
                                        } else {
                                            this.f8662n = 10;
                                        }
                                        break;
                                    case 3:
                                    case 4:
                                        this.f8662n = (this.C.g() * 2) + 9;
                                        break;
                                    case 5:
                                    case 6:
                                        this.f8662n = 10;
                                        break;
                                }
                            } else {
                                this.f8662n = 12;
                            }
                        }
                    }
                    try {
                        Thread.sleep(10L);
                        if (this.J % 2000 == 0) {
                            init(this.M);
                            if (getSomeValue() == 0) {
                                this.f8655g.close();
                                Thread.sleep(5000L);
                            }
                        }
                    } catch (InterruptedException unused7) {
                        c4 = 4;
                    }
                    this.G = 0;
                } else if (c4 == 3) {
                    try {
                        int iAvailable = inputStream.available();
                        if (iAvailable > 0) {
                            try {
                                inputStream.read(this.H);
                                System.arraycopy(this.H, 0, this.I, this.G, iAvailable);
                                int i7 = this.G + iAvailable;
                                this.G = i7;
                                int i8 = this.f8662n;
                                if (i7 == i8) {
                                    this.L++;
                                    if (this.C.r()) {
                                        g(this.C, this.I);
                                    } else {
                                        h(this.C, this.I);
                                    }
                                    i3 = this.N;
                                    if (i3 > 0) {
                                        Thread.sleep(i3);
                                    }
                                    c4 = 2;
                                } else if (i7 > i8) {
                                    int length2 = this.I.length;
                                    int[] iArr2 = new int[length2];
                                    for (int i9 = 0; i9 < length2; i9++) {
                                        iArr2[i9] = this.I[i9] & 255;
                                    }
                                    i3 = this.N;
                                    if (i3 > 0) {
                                        Thread.sleep(i3);
                                    }
                                    c4 = 2;
                                }
                                b = 0;
                            } catch (Exception unused8) {
                                b = 0;
                                c4 = 4;
                            }
                        }
                    } catch (Exception unused9) {
                    }
                    if (System.currentTimeMillis() - this.E >= this.F) {
                        if (b >= 3) {
                            break;
                        }
                        b = (byte) (b + 1);
                        this.c.obtainMessage(2, this.C.h(), this.C.j()).sendToTarget();
                        this.K++;
                        c4 = 2;
                    }
                    Thread.sleep(5L);
                } else if (c4 == c3) {
                    try {
                        this.f8661m = 0;
                        this.c.obtainMessage(6, 2, this.f8652d).sendToTarget();
                        Thread.sleep(this.f8656h);
                        if (!this.f8654f) {
                            return;
                        } else {
                            c4 = 0;
                        }
                    } catch (Exception unused10) {
                        this.c.obtainMessage(6, 2, this.f8652d).sendToTarget();
                        try {
                            Socket socket4 = this.f8655g;
                            if (socket4 != null) {
                                socket4.close();
                            }
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (outputStream != null) {
                                outputStream.close();
                            }
                        } catch (IOException unused11) {
                        }
                        c3 = 4;
                        c4 = 4;
                    }
                }
                c3 = 4;
            }
            c4 = 4;
        }
    }
}
