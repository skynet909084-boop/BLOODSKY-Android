package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class q extends androidx.appcompat.widget.n implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    private boolean C;
    private boolean D;
    Bitmap E;
    Paint F;
    Paint G;
    boolean H;
    int I;
    int J;
    public int K;
    private long L;
    Handler M;
    public Point N;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8862d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8863e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8864f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8865g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f8866h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f8867i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Bitmap[] f8868j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Bitmap[] f8869k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    boolean f8870l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    boolean f8871m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8872n;
    String o;

    class a extends Handler {
        a() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what == 1) {
                Toast.makeText(q.this.getContext(), q.this.getResources().getString(R.string.custom_dyn_pictures_error_load_pictures), 1).show();
                q.this.d(true, false, "green");
            }
            if (message.what == 2) {
                Toast.makeText(q.this.getContext(), q.this.getResources().getString(R.string.custom_dyn_pictures_error_load_pictures), 1).show();
                q.this.d(false, false, "off");
            }
            q.this.e();
        }
    }

    class b extends Thread {
        final /* synthetic */ boolean a;

        b(boolean z) {
            this.a = z;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            Handler handler;
            int i2;
            if (this.a) {
                try {
                    q qVar = q.this;
                    qVar.f8868j[0] = f.b.a.i.v(qVar.getContext()).u(q.this.f8872n).K().l(q.this.getWidth() == 0 ? q.this.K : q.this.getWidth(), q.this.getHeight() == 0 ? q.this.K : q.this.getHeight()).get();
                } catch (Exception unused) {
                    handler = q.this.M;
                    i2 = 1;
                    handler.obtainMessage(i2).sendToTarget();
                }
            } else {
                try {
                    q qVar2 = q.this;
                    qVar2.f8869k[0] = f.b.a.i.v(qVar2.getContext()).u(q.this.o).K().l(q.this.getWidth() == 0 ? q.this.K : q.this.getWidth(), q.this.getHeight() == 0 ? q.this.K : q.this.getHeight()).get();
                } catch (Exception unused2) {
                    handler = q.this.M;
                    i2 = 2;
                    handler.obtainMessage(i2).sendToTarget();
                }
            }
            q.this.M.obtainMessage(0).sendToTarget();
        }
    }

    public q(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_label);
        this.f8862d = 5;
        this.f8864f = (byte) 1;
        this.f8865g = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8866h = false;
        this.f8868j = new Bitmap[]{null};
        this.f8869k = new Bitmap[]{null};
        this.f8870l = false;
        this.f8871m = false;
        this.f8872n = "green";
        this.o = "off";
        this.E = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.F = new Paint();
        this.G = new Paint();
        this.H = false;
        this.I = 0;
        this.J = 0;
        this.K = 0;
        this.L = 0L;
        this.M = new a();
        this.N = new Point();
    }

    public void c(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setScaleType(ImageView.ScaleType.FIT_XY);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            d(true, false, "green");
            d(false, false, "off");
            e();
        }
        setKey(i4);
        this.f8865g.A(this.f8862d);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:12:0x003c  */
    public void d(boolean z, boolean z2, String str) {
        if (z) {
            this.f8870l = z2;
            this.f8872n = str;
        } else {
            this.f8871m = z2;
            this.o = str;
        }
        if (z2) {
            try {
                new b(z).start();
                return;
            } catch (Exception unused) {
                Toast.makeText(getContext(), getResources().getString(R.string.custom_dyn_pictures_error_load_pictures), 1).show();
                return;
            }
        }
        str.hashCode();
        switch (str) {
            case "yellow":
                if (!z) {
                    this.f8869k[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_yellow);
                    break;
                } else {
                    this.f8868j[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_yellow);
                    break;
                }
                break;
            case "off":
                if (!z) {
                    this.f8869k[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_off);
                    break;
                } else {
                    this.f8868j[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_off);
                    break;
                }
                break;
            case "red":
                if (!z) {
                    this.f8869k[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_red);
                    break;
                } else {
                    this.f8868j[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_red);
                    break;
                }
                break;
            case "blue":
                if (!z) {
                    this.f8869k[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_blue);
                    break;
                } else {
                    this.f8868j[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_blue);
                    break;
                }
                break;
            case "green":
                if (!z) {
                    this.f8869k[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_green);
                    break;
                } else {
                    this.f8868j[0] = BitmapFactory.decodeResource(getResources(), R.drawable.lamp_green);
                    break;
                }
                break;
        }
        e();
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.N.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e() {
        setImageBitmap(this.f8866h ? this.f8868j[0] : this.f8869k[0]);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.f8865g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8862d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8867i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8862d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8865g.l());
        jSONObject.put("addressRegister", this.f8865g.c());
        jSONObject.put("addressBit", (int) this.f8865g.a());
        jSONObject.put("typeRequest", (int) this.f8865g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("isImageUserOn", this.f8870l);
        jSONObject.put("pathOrNameOn", this.f8872n);
        jSONObject.put("isImageUserOff", this.f8871m);
        jSONObject.put("pathOrNameOff", this.o);
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8863e;
    }

    public int getNumScreen() {
        return this.f8867i;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8865g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8865g.l() >= 100) {
            this.f8865g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8865g.c() + "." + ((int) this.f8865g.a());
        }
        this.f8865g.u((byte) MyApplication.b().E.get(this.f8865g.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8865g.b()) + "#" + this.f8865g.c() + "." + ((int) this.f8865g.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8865g.l() >= 0) {
            if (this.f8865g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8865g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.L;
    }

    public byte getTypeRequest() {
        return this.f8864f;
    }

    public boolean getValue() {
        return this.f8866h;
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.D) {
            this.G.setColor(-65536);
            this.G.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.G);
        }
        if (this.C && mbCanvas.g1) {
            canvas.drawBitmap(this.E, getWidth() - this.E.getWidth(), getHeight() - this.E.getHeight(), this.F);
        }
        if (this.H) {
            this.G.setColor(-16711936);
            this.G.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.G);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.H;
    }

    public void setConnectionError(boolean z) {
        this.D = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.C = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.H = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.I = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.J = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8863e = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8865g.G(i2);
        this.f8867i = i2;
    }

    public void setStateOn(boolean z) {
        this.f8866h = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.L = j2;
    }

    public void setTypeRequest(byte b2) {
        this.f8864f = b2;
        this.f8865g.L(b2);
    }

    public void setValue(int i2) {
        if (i2 == 1 && this.f8866h) {
            return;
        }
        if (i2 != 0 || this.f8866h) {
            if (i2 == 1) {
                setImageBitmap(this.f8868j[0]);
                this.f8866h = true;
            } else {
                setImageBitmap(this.f8869k[0]);
                this.f8866h = false;
            }
        }
    }
}
