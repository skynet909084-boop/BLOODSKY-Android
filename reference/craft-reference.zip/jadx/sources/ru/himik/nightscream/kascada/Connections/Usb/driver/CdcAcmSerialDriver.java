package ru.himik.nightscream.kascada.Connections.Usb.driver;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.os.Build;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.KotlinVersion;

/* JADX INFO: loaded from: classes.dex */
public class CdcAcmSerialDriver implements UsbSerialDriver {
    private final String TAG = CdcAcmSerialDriver.class.getSimpleName();
    private final UsbDevice mDevice;
    private final UsbSerialPort mPort;

    class CdcAcmSerialPort extends CommonUsbSerialPort {
        private static final int GET_LINE_CODING = 33;
        private static final int SEND_BREAK = 35;
        private static final int SET_CONTROL_LINE_STATE = 34;
        private static final int SET_LINE_CODING = 32;
        private static final int USB_RECIP_INTERFACE = 1;
        private static final int USB_RT_ACM = 33;
        private UsbEndpoint mControlEndpoint;
        private UsbInterface mControlInterface;
        private UsbInterface mDataInterface;
        private boolean mDtr;
        private final boolean mEnableAsyncReads;
        private UsbEndpoint mReadEndpoint;
        private boolean mRts;
        private UsbEndpoint mWriteEndpoint;

        public CdcAcmSerialPort(UsbDevice usbDevice, int i2) {
            super(usbDevice, i2);
            this.mRts = false;
            this.mDtr = false;
            this.mEnableAsyncReads = Build.VERSION.SDK_INT >= 17;
        }

        private int sendAcmControlMessage(int i2, int i3, byte[] bArr) {
            return this.mConnection.controlTransfer(33, i2, i3, 0, bArr, bArr != null ? bArr.length : 0, 5000);
        }

        private void setDtrRts() {
            sendAcmControlMessage(34, (this.mRts ? 2 : 0) | (this.mDtr ? 1 : 0), null);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void close() throws IOException {
            UsbDeviceConnection usbDeviceConnection = this.mConnection;
            if (usbDeviceConnection == null) {
                throw new IOException("Already closed");
            }
            usbDeviceConnection.close();
            this.mConnection = null;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCD() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCTS() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDSR() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDTR() {
            return this.mDtr;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public UsbSerialDriver getDriver() {
            return CdcAcmSerialDriver.this;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRI() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRTS() {
            return this.mRts;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void open(UsbDeviceConnection usbDeviceConnection) throws IOException {
            if (this.mConnection != null) {
                throw new IOException("Already open");
            }
            this.mConnection = usbDeviceConnection;
            try {
                UsbInterface usbInterface = this.mDevice.getInterface(0);
                this.mControlInterface = usbInterface;
                if (!this.mConnection.claimInterface(usbInterface, true)) {
                    throw new IOException("Could not claim control interface.");
                }
                this.mControlEndpoint = this.mControlInterface.getEndpoint(0);
                UsbInterface usbInterface2 = this.mDevice.getInterface(1);
                this.mDataInterface = usbInterface2;
                if (!this.mConnection.claimInterface(usbInterface2, true)) {
                    throw new IOException("Could not claim data interface.");
                }
                this.mReadEndpoint = this.mDataInterface.getEndpoint(1);
                this.mWriteEndpoint = this.mDataInterface.getEndpoint(0);
            } catch (Throwable th) {
                this.mConnection = null;
                throw th;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int read(byte[] bArr, int i2) {
            synchronized (this.mReadBufferLock) {
                int iBulkTransfer = this.mConnection.bulkTransfer(this.mReadEndpoint, this.mReadBuffer, Math.min(bArr.length, this.mReadBuffer.length), i2);
                if (iBulkTransfer < 0) {
                    return i2 == Integer.MAX_VALUE ? -1 : 0;
                }
                System.arraycopy(this.mReadBuffer, 0, bArr, 0, iBulkTransfer);
                return iBulkTransfer;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setDTR(boolean z) {
            this.mDtr = z;
            setDtrRts();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setParameters(int i2, int i3, int i4, int i5) {
            byte b;
            byte b2;
            if (i4 == 1) {
                b = 0;
            } else if (i4 == 2) {
                b = 2;
            } else {
                if (i4 != 3) {
                    throw new IllegalArgumentException("Bad value for stopBits: " + i4);
                }
                b = 1;
            }
            if (i5 == 0) {
                b2 = 0;
            } else if (i5 == 1) {
                b2 = 1;
            } else if (i5 == 2) {
                b2 = 2;
            } else if (i5 == 3) {
                b2 = 3;
            } else {
                if (i5 != 4) {
                    throw new IllegalArgumentException("Bad value for parity: " + i5);
                }
                b2 = 4;
            }
            sendAcmControlMessage(32, 0, new byte[]{(byte) (i2 & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((i2 >> 8) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((i2 >> 16) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((i2 >> 24) & KotlinVersion.MAX_COMPONENT_VALUE), b, b2, (byte) i3});
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setRTS(boolean z) {
            this.mRts = z;
            setDtrRts();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int write(byte[] bArr, int i2) throws IOException {
            int iMin;
            byte[] bArr2;
            int iBulkTransfer;
            int i3 = 0;
            while (i3 < bArr.length) {
                synchronized (this.mWriteBufferLock) {
                    iMin = Math.min(bArr.length - i3, this.mWriteBuffer.length);
                    if (i3 == 0) {
                        bArr2 = bArr;
                    } else {
                        System.arraycopy(bArr, i3, this.mWriteBuffer, 0, iMin);
                        bArr2 = this.mWriteBuffer;
                    }
                    iBulkTransfer = this.mConnection.bulkTransfer(this.mWriteEndpoint, bArr2, iMin, i2);
                }
                if (iBulkTransfer <= 0) {
                    throw new IOException("Error writing " + iMin + " bytes at offset " + i3 + " length=" + bArr.length);
                }
                i3 += iBulkTransfer;
            }
            return i3;
        }
    }

    public CdcAcmSerialDriver(UsbDevice usbDevice) {
        this.mDevice = usbDevice;
        this.mPort = new CdcAcmSerialPort(usbDevice, 0);
    }

    public static Map<Integer, int[]> getSupportedDevices() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_ARDUINO), new int[]{1, 67, 16, 66, 59, 68, 63, 68, UsbId.ARDUINO_LEONARDO});
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_VAN_OOIJEN_TECH), new int[]{UsbId.VAN_OOIJEN_TECH_TEENSYDUINO_SERIAL});
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_ATMEL), new int[]{UsbId.ATMEL_LUFA_CDC_DEMO_APP});
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_LEAFLABS), new int[]{4});
        return linkedHashMap;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public UsbDevice getDevice() {
        return this.mDevice;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public List<UsbSerialPort> getPorts() {
        return Collections.singletonList(this.mPort);
    }
}
