package ru.himik.nightscream.kascada;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.SmsManager;
import android.widget.Toast;
import java.util.ArrayList;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class a0 {
    Context a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    boolean f9166d;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    PendingIntent f9170h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    PendingIntent f9171i;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    ArrayList<c> f9167e = new ArrayList<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    String f9168f = "SMS_SENT";

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    String f9169g = "SMS_DELIVERED";

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    long f9172j = 0;
    BroadcastReceiver b = new b();
    BroadcastReceiver c = new a(this);

    class a extends BroadcastReceiver {
        a(a0 a0Var) {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String str;
            int resultCode = getResultCode();
            if (resultCode == -1) {
                Toast.makeText(context, context.getResources().getString(R.string.sms_delivered), 0).show();
                str = "[SMS SENDER] Смс доставлено.";
            } else {
                if (resultCode != 0) {
                    return;
                }
                Toast.makeText(context, context.getResources().getString(R.string.sms_no_delivered), 0).show();
                str = "[SMS SENDER] Смс не доставлено.";
            }
            ru.himik.nightscream.kascada.w.b.a("SMS_OUT", str);
        }
    }

    class b extends BroadcastReceiver {
        b() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String str;
            a0.this.f9166d = false;
            int resultCode = getResultCode();
            if (resultCode == -1) {
                Toast.makeText(context, context.getResources().getString(R.string.sms_sent), 0).show();
                str = "[SMS SENDER] Смс отправлено.";
            } else if (resultCode == 1) {
                Toast.makeText(context, context.getResources().getString(R.string.sms_unknown_error), 0).show();
                str = "[SMS SENDER] Неизвестная ошибка.";
            } else if (resultCode == 2) {
                Toast.makeText(context, context.getResources().getString(R.string.sms_error_air_mode), 0).show();
                str = "[SMS SENDER] Нет связи. Режим самолёта?";
            } else if (resultCode == 3) {
                Toast.makeText(context, context.getResources().getString(R.string.sms_error_pdu), 0).show();
                str = "[SMS SENDER] Ошибка PDU.";
            } else {
                if (resultCode != 4) {
                    return;
                }
                Toast.makeText(context, context.getResources().getString(R.string.sms_no_connection), 0).show();
                str = "[SMS SENDER] Нет связи.";
            }
            ru.himik.nightscream.kascada.w.b.a("SMS_OUT", str);
        }
    }

    class c {
        String a;
        String b;

        public c(a0 a0Var, String str, String str2) {
            this.a = "";
            this.b = "";
            this.a = str2;
            this.b = str;
        }

        public String a() {
            return this.a;
        }

        public String b() {
            return this.b;
        }
    }

    a0(Context context) {
        this.a = context;
        this.f9170h = PendingIntent.getBroadcast(context, 0, new Intent(this.f9168f), 0);
        this.f9171i = PendingIntent.getBroadcast(context, 0, new Intent(this.f9169g), 0);
        context.registerReceiver(this.b, new IntentFilter(this.f9168f));
        context.registerReceiver(this.c, new IntentFilter(this.f9169g));
    }

    public void a(String str, String str2) {
        this.f9167e.add(new c(this, str, str2));
        ru.himik.nightscream.kascada.w.b.a("SMS_OUT", "[SMS SENDER] В очередь добавлен: " + str + " " + str2 + ". Очередь = " + this.f9167e.size());
    }

    public void b() {
        try {
            this.a.unregisterReceiver(this.b);
            this.a.unregisterReceiver(this.c);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public void c() {
        this.f9167e.clear();
        if (this.f9167e.size() > 0) {
            ru.himik.nightscream.kascada.w.b.a("SMS_OUT", "[SMS SENDER] Очередь очищена.");
        }
    }

    public void d() {
        if (this.f9167e.size() <= 0 || System.currentTimeMillis() - this.f9172j < 20000) {
            return;
        }
        this.f9172j = System.currentTimeMillis();
        String strA = this.f9167e.get(0).a();
        String strB = this.f9167e.get(0).b();
        this.f9167e.remove(0);
        ru.himik.nightscream.kascada.w.b.a("SMS_OUT", "[SMS SENDER] Отправка " + strB + " " + strA + ". Очередь = " + this.f9167e.size());
        try {
            SmsManager.getDefault().sendTextMessage(strB, null, strA, this.f9170h, this.f9171i);
        } catch (Exception e2) {
            Context context = this.a;
            Toast.makeText(context, context.getResources().getString(R.string.error_sms_send), 1).show();
            ru.himik.nightscream.kascada.w.b.a("SMS_OUT", "[SMS SENDER] Произошла критическая ошибка: " + e2.getMessage());
            e2.printStackTrace();
        }
    }
}
