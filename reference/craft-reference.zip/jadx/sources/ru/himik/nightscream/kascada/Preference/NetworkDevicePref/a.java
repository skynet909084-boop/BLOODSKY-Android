package ru.himik.nightscream.kascada.Preference.NetworkDevicePref;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes2.dex */
public class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new C0290a();
    String a;
    int b;
    String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    String f9093d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    String f9094e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f9095f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f9096g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f9097h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    boolean f9098i;

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a$a, reason: collision with other inner class name */
    static class C0290a implements Parcelable.Creator<a> {
        C0290a() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public a createFromParcel(Parcel parcel) {
            return new a(parcel, null);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public a[] newArray(int i2) {
            return new a[i2];
        }
    }

    private a(Parcel parcel) {
        this.f9096g = false;
        this.f9097h = -1;
        this.f9098i = false;
        this.a = parcel.readString();
        this.b = parcel.readInt();
        this.c = parcel.readString();
        this.f9093d = parcel.readString();
        this.f9094e = parcel.readString();
        this.f9095f = parcel.readInt();
        this.f9098i = parcel.readByte() != 0;
    }

    /* synthetic */ a(Parcel parcel, C0290a c0290a) {
        this(parcel);
    }

    public a(String str, int i2, String str2, String str3, String str4, int i3) {
        this.f9096g = false;
        this.f9097h = -1;
        this.f9098i = false;
        this.a = str;
        this.b = i2;
        this.c = str4;
        this.f9093d = str2;
        this.f9094e = str3;
        this.f9095f = i3;
    }

    public int a() {
        return this.b;
    }

    public int b() {
        return this.f9095f;
    }

    public String c() {
        return this.a;
    }

    public int d() {
        return this.f9097h;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String e() {
        return this.f9093d;
    }

    public boolean g() {
        return this.f9098i;
    }

    public boolean h() {
        return this.f9096g;
    }

    public void i(int i2) {
        this.b = i2;
    }

    public void j(int i2) {
        this.f9095f = i2;
    }

    public void k(String str) {
        this.a = str;
    }

    public void l(int i2) {
        this.f9097h = i2;
    }

    public void m(boolean z) {
        this.f9098i = z;
    }

    public void n(String str) {
        this.f9093d = str;
    }

    public void o(boolean z) {
        this.f9096g = z;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.a);
        parcel.writeInt(this.b);
        parcel.writeString(this.c);
        parcel.writeString(this.f9093d);
        parcel.writeString(this.f9094e);
        parcel.writeInt(this.f9095f);
        parcel.writeByte(this.f9098i ? (byte) 1 : (byte) 0);
    }
}
