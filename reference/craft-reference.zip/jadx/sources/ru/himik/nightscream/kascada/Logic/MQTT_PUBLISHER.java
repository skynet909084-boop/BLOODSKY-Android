package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.c;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.p;

/* JADX INFO: loaded from: classes2.dex */
public class MQTT_PUBLISHER extends c {
    Boolean d0;
    int e0;
    float f0;
    int g0;
    String h0;
    boolean i0;
    int j0;
    boolean k0;

    public MQTT_PUBLISHER(Context context) {
        super(context);
        this.d0 = Boolean.FALSE;
        this.e0 = 0;
        this.f0 = 0.0f;
        this.g0 = 1;
        this.h0 = "";
        this.i0 = false;
        this.j0 = 1;
        this.k0 = false;
        setName("MQTT_P");
        s("EN", 1);
        t("IN", this.g0);
    }

    public MQTT_PUBLISHER(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = Boolean.FALSE;
        this.e0 = 0;
        this.f0 = 0.0f;
        this.g0 = 1;
        this.h0 = "";
        this.i0 = false;
        this.j0 = 1;
        this.k0 = false;
        setName("MQTT_P");
        s("EN", 1);
        t("IN", this.g0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.q.b.b bVar;
        String str;
        StringBuilder sb;
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return;
        }
        if (!((Boolean) this.f8975g.getOut()).booleanValue()) {
            this.i0 = false;
            return;
        }
        if (this.i0) {
            return;
        }
        this.i0 = true;
        int i2 = this.g0;
        if (i2 == 1) {
            this.d0 = Boolean.valueOf(((Boolean) this.f8976h.getOut()).booleanValue());
            if (this.j0 == 1) {
                MyApplication.b().q0.e(this.h0, this.d0 + "", this.k0);
            }
            if (this.j0 != 2) {
                return;
            }
            bVar = MyApplication.b().r0;
            str = this.h0;
            sb = new StringBuilder();
            sb.append(this.d0);
        } else if (i2 == 2) {
            this.e0 = ((Integer) this.f8976h.getOut()).intValue();
            if (this.j0 == 1) {
                MyApplication.b().q0.e(this.h0, this.e0 + "", this.k0);
            }
            if (this.j0 != 2) {
                return;
            }
            bVar = MyApplication.b().r0;
            str = this.h0;
            sb = new StringBuilder();
            sb.append(this.e0);
        } else {
            if (i2 != 3) {
                return;
            }
            this.f0 = ((Float) this.f8976h.getOut()).floatValue();
            if (this.j0 == 1) {
                MyApplication.b().q0.e(this.h0, this.f0 + "", this.k0);
            }
            if (this.j0 != 2) {
                return;
            }
            bVar = MyApplication.b().r0;
            str = this.h0;
            sb = new StringBuilder();
            sb.append(this.f0);
        }
        sb.append("");
        bVar.e(str, sb.toString(), this.k0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("topic", this.h0);
        jSONObject.put("typeIn", this.g0);
        jSONObject.put("numMqttServer", this.j0);
        jSONObject.put("mqttRetain", this.k0);
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    public int getNumMqttServer() {
        return this.j0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        return null;
    }

    public String getTopic() {
        return this.h0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 140;
    }

    public int getTypeIn() {
        return this.g0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a l(int i2) {
        if (i2 == 1) {
            return this.f8975g;
        }
        if (i2 != 2) {
            return null;
        }
        return this.f8976h;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.S.setStyle(Paint.Style.FILL);
        this.S.setColor(-7829368);
        this.S.setStrokeWidth(this.U);
        this.V.set(this.T, this.U, getWidth() - this.T, getHeight() - this.U);
        canvas.drawRect(this.V, this.S);
        this.S.setStyle(Paint.Style.STROKE);
        this.S.setColor(-16777216);
        canvas.drawRect(this.V, this.S);
        this.W.setTextAlign(Paint.Align.CENTER);
        canvas.drawLine(this.T, getHeight() / 3, (getWidth() - this.T) - (this.U / 2), getHeight() / 3, this.S);
        canvas.drawLine(getWidth() / 2, getHeight() / 3, getWidth() / 2, getHeight() - this.U, this.S);
        canvas.drawText(this.L, getWidth() / 2, ((getHeight() / 3) - ((getHeight() / 3) / 2)) + this.a0, this.W);
        if (this.M.length() > 0) {
            String str = this.M;
            int width2 = getWidth() / 2;
            int i2 = this.T;
            canvas.drawText(str, ((width2 - i2) / 2) + i2, ((getHeight() / 3) / 2) + (getHeight() / 3) + this.a0, this.W);
            canvas.drawLine(0.0f, ((getHeight() / 3) / 2) + (getHeight() / 3), this.T, ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        }
        if (this.O.length() > 0) {
            String str2 = this.O;
            int width3 = getWidth() / 2;
            int i3 = this.T;
            canvas.drawText(str2, ((width3 - i3) / 2) + i3, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2) + this.a0, this.W);
            canvas.drawLine(0.0f, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2), this.T, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2), this.S);
        }
        if (this.Q.length() > 0) {
            canvas.drawText(this.Q, (getWidth() / 2) + (((getWidth() / 2) - this.T) / 2), ((getHeight() / 3) / 2) + (getHeight() / 3) + this.a0, this.W);
            if (this.f8973e && this.R == 1) {
                canvas.drawCircle((getWidth() - this.T) + this.b0, ((getHeight() / 3) / 2) + (getHeight() / 3), this.b0, this.S);
                width = (getWidth() - this.T) + (this.b0 * 2);
            } else {
                width = getWidth() - this.T;
            }
            canvas.drawLine(width, ((getHeight() / 3) / 2) + (getHeight() / 3), getWidth(), ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        }
        super.onDraw(canvas);
    }

    public void setMqttRetain(boolean z) {
        this.k0 = z;
    }

    public void setNumMqttServer(int i2) {
        this.j0 = i2;
    }

    public void setTopic(String str) {
        this.h0 = str;
    }

    public void setTypeIn(int i2) {
        if (this.g0 != i2) {
            this.g0 = i2;
            t("IN", i2);
            ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8976h;
            if (aVar == null || aVar.getOut() == null) {
                return;
            }
            this.f8976h.c();
            org.greenrobot.eventbus.c.c().k(new p("UPDATE_LINE_LOGIC"));
        }
    }

    public boolean v() {
        return this.k0;
    }
}
