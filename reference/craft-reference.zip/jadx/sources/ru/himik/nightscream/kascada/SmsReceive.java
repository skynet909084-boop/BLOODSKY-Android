package ru.himik.nightscream.kascada;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;

/* JADX INFO: loaded from: classes.dex */
public class SmsReceive extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        SmsMessage[] smsMessageArr = new SmsMessage[0];
        if (intent != null && intent.getAction() != null && "android.provider.Telephony.SMS_RECEIVED".compareToIgnoreCase(intent.getAction()) == 0) {
            Object[] objArr = (Object[]) intent.getExtras().get("pdus");
            smsMessageArr = new SmsMessage[objArr.length];
            for (int i2 = 0; i2 < objArr.length; i2++) {
                smsMessageArr[i2] = SmsMessage.createFromPdu((byte[]) objArr[i2]);
            }
        }
        String displayOriginatingAddress = smsMessageArr[0].getDisplayOriginatingAddress();
        StringBuilder sb = new StringBuilder();
        for (SmsMessage smsMessage : smsMessageArr) {
            sb.append(smsMessage.getMessageBody());
        }
        String string = sb.toString();
        Intent intent2 = new Intent();
        intent2.setAction("SMS_RECEIVED_ACTION");
        intent2.putExtra("from", displayOriginatingAddress);
        intent2.putExtra("sms", string);
        context.sendBroadcast(intent2);
    }
}
