package ru.himik.nightscream.kascada.Logic.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.z;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b extends View implements a, ru.himik.nightscream.kascada.s.a, z {
    public RectF C;
    public int D;
    public int E;
    public boolean F;
    public int G;
    public int H;
    public Paint I;
    public int J;
    public int K;
    public int L;
    public int M;
    public int N;
    private long O;
    public Point P;
    String a;
    long b;
    public a c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public a f8961d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Paint f8962e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Paint f8963f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Point f8964g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Point f8965h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8966i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8967j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f8968k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f8969l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f8970m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public String f8971n;
    public Rect o;

    public b(Context context) {
        super(context);
        this.a = "";
        this.b = 0L;
        this.f8962e = new Paint();
        this.f8963f = new Paint();
        this.f8964g = new Point(0, 0);
        this.f8965h = new Point(0, 0);
        this.f8967j = 0;
        this.f8968k = 1;
        this.f8969l = 0;
        this.f8970m = -1;
        this.f8971n = "0";
        this.o = new Rect();
        this.C = new RectF();
        this.D = Math.round(getResources().getDimension(R.dimen.view_root_var_in_width));
        this.E = Math.round(getResources().getDimension(R.dimen.view_root_var_in_height));
        this.F = false;
        this.G = 0;
        this.H = 0;
        this.I = new Paint();
        this.J = -1;
        this.K = -1;
        this.L = -1;
        this.M = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.N = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.O = 0L;
        this.P = new Point();
        this.D = Math.round(getResources().getDimension(R.dimen.view_root_var_in_width));
        this.E = Math.round(getResources().getDimension(R.dimen.view_root_var_in_height));
    }

    public b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = "";
        this.b = 0L;
        this.f8962e = new Paint();
        this.f8963f = new Paint();
        this.f8964g = new Point(0, 0);
        this.f8965h = new Point(0, 0);
        this.f8967j = 0;
        this.f8968k = 1;
        this.f8969l = 0;
        this.f8970m = -1;
        this.f8971n = "0";
        this.o = new Rect();
        this.C = new RectF();
        this.D = Math.round(getResources().getDimension(R.dimen.view_root_var_in_width));
        this.E = Math.round(getResources().getDimension(R.dimen.view_root_var_in_height));
        this.F = false;
        this.G = 0;
        this.H = 0;
        this.I = new Paint();
        this.J = -1;
        this.K = -1;
        this.L = -1;
        this.M = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.N = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.O = 0L;
        this.P = new Point();
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.D = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_root_var_in_width)));
            this.E = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_root_var_in_height)));
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void a() {
        a aVar = this.f8961d;
        if (aVar != null) {
            aVar.k(this.f8967j);
        }
        a aVar2 = this.c;
        if (aVar2 != null) {
            aVar2.m();
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void c() {
        a aVar = this.f8961d;
        if (aVar != null) {
            aVar.k(this.f8967j);
            this.f8961d = null;
            this.f8967j = 0;
        }
        this.f8970m = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void d(a aVar, int i2) {
        this.c = aVar;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.P.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void e(a aVar) {
        this.f8961d = aVar;
        this.f8970m = aVar.getKey();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean g() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 1;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return getTypeFb();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return getNumScreen();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.G;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getFreeIn() {
        return this.c == null ? 1 : 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return getTypeFb();
    }

    public Object getIn() {
        return 0;
    }

    public a getIn1() {
        return this.c;
    }

    public a getIn2() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getInvertOut() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getJsonMacroOutIfNeed() {
        if (q() == null || q().getTypeFb() != 135) {
            return "";
        }
        FB_MACRO fb_macro = (FB_MACRO) q();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(IMAPStore.ID_NAME, fb_macro.getName());
            jSONObject.put("x", (int) fb_macro.getX());
            jSONObject.put("y", (int) fb_macro.getY());
            jSONObject.put("numScreen", fb_macro.getNumScreen());
            return jSONObject.toString();
        } catch (JSONException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public JSONObject getJsonOther() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a, ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8966i;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getKeyOut() {
        return this.f8970m;
    }

    public String getName() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumOnIn() {
        return this.f8967j;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumScreen() {
        return this.f8968k;
    }

    public Object getOut() {
        return null;
    }

    public Point getPointIn1() {
        return null;
    }

    public Point getPointIn2() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point getPointOut() {
        return this.f8964g;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getRootNameMacro() {
        return this.a;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public long getRootUniqueIdMacro() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdBeforeCopy() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdOutBeforeCopy() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveKey() {
        return this.f8969l;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveNumInBeforeCopy() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.O;
    }

    public int getTypeFb() {
        return 0;
    }

    public int getTypeVarOut() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getVarConstant() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public float getVarFloatConstant() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getVarIntConstant() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void i() {
    }

    public void j(int i2, int i3, int i4, boolean z) {
        getLayoutParams().height = this.E;
        getLayoutParams().width = this.D;
        setY(i3 - (this.E / 2));
        setX(i2 - (this.D / 2));
        setKey(i4);
        setBackgroundColor(0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void k(int i2) {
        this.c = null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public a l(int i2) {
        if (i2 != 1) {
            return null;
        }
        return this.c;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void m() {
        this.f8961d = null;
        this.f8967j = 0;
        this.f8970m = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point n(int i2) {
        return this.f8965h;
    }

    public int o(int i2) {
        return 0;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.F) {
            this.I.setColor(-16711936);
            this.I.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.I);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        this.f8962e.setFlags(1);
        this.f8962e.setStrokeWidth(this.N);
        this.f8963f.setFlags(1);
        this.f8963f.setTextAlign(Paint.Align.CENTER);
        this.f8963f.setTextSize(this.E - (this.M / 2));
        Paint paint = this.f8963f;
        String str = this.f8971n;
        paint.getTextBounds(str, 0, str.length(), this.o);
        this.f8963f.setColor(getResources().getColor(R.color.text_color_logic));
        this.D = this.o.width() + (this.M * 3);
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        int i4 = this.D;
        layoutParams.width = i4;
        setMeasuredDimension(i4, this.E);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public a q() {
        return this.f8961d;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        this.f8964g.set(getWidth() + ((int) getX()), (getHeight() / 2) + ((int) getY()));
        this.f8965h.set((int) getX(), (getHeight() / 2) + ((int) getY()));
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.F = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.G = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.H = i2;
    }

    public void setFont(String str) {
    }

    public void setIn(Object obj) {
    }

    public void setInvert(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8966i = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setKeyOut(int i2) {
        if (i2 == this.f8969l) {
            i2 = -1;
        }
        this.f8970m = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setNumOnIn(int i2) {
        this.f8967j = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8968k = i2;
    }

    public void setOut(Object obj) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootNameMacro(String str) {
        this.a = str;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootUniqueIdMacro(long j2) {
        this.b = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdBeforeCopy(int i2) {
        this.J = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdOutBeforeCopy(int i2) {
        this.L = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveKey(int i2) {
        this.f8969l = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveNumInBeforeCopy(int i2) {
        this.K = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.O = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarFloatConstant(float f2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarIntConstant(int i2) {
    }
}
