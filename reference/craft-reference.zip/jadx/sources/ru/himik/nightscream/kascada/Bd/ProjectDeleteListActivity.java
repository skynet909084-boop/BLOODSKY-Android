package ru.himik.nightscream.kascada.Bd;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import com.sun.mail.imap.IMAPStore;
import java.util.ArrayList;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class ProjectDeleteListActivity extends androidx.appcompat.app.d {
    e b;
    ListView c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    c f8595d;
    ArrayList<g> a = new ArrayList<>();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final AdapterView.OnItemClickListener f8596e = new b();

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ProjectDeleteListActivity.this.onBackPressed();
        }
    }

    class b implements AdapterView.OnItemClickListener {

        class a implements DialogInterface.OnClickListener {
            final /* synthetic */ String a;

            a(String str) {
                this.a = str;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                try {
                    SQLiteDatabase writableDatabase = ProjectDeleteListActivity.this.b.getWritableDatabase();
                    Cursor cursorRawQuery = writableDatabase.rawQuery("select _id from TableNameProject where name = '" + this.a + "'", null);
                    cursorRawQuery.moveToFirst();
                    int i3 = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("_id"));
                    int iDelete = writableDatabase.delete("TableNameProject", "name = '" + this.a + "'", null);
                    writableDatabase.execSQL("DROP TABLE IF EXISTS pro_" + i3 + "_component");
                    writableDatabase.execSQL("DROP TABLE IF EXISTS pro_" + i3 + "_connections");
                    if (iDelete > 0) {
                        Toast.makeText(ProjectDeleteListActivity.this.getApplicationContext(), ProjectDeleteListActivity.this.getResources().getString(R.string.project) + " " + this.a + " " + ProjectDeleteListActivity.this.getResources().getString(R.string.project_was_deleted), 1).show();
                        ProjectDeleteListActivity.this.getProjectFromBd();
                    } else {
                        Toast.makeText(ProjectDeleteListActivity.this.getApplicationContext(), ProjectDeleteListActivity.this.getResources().getString(R.string.toast_error_delete_project), 1).show();
                    }
                } catch (Exception e2) {
                    Toast.makeText(ProjectDeleteListActivity.this.getApplicationContext(), e2.toString(), 1).show();
                }
            }
        }

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.ProjectDeleteListActivity$b$b, reason: collision with other inner class name */
        class DialogInterfaceOnClickListenerC0286b implements DialogInterface.OnClickListener {
            DialogInterfaceOnClickListenerC0286b(b bVar) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
            }
        }

        b() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            String str = ((TextView) view.findViewById(R.id.nameProject)).getText().toString() + "";
            Toast.makeText(ProjectDeleteListActivity.this.getApplicationContext(), str, 0).show();
            AlertDialog.Builder builder = new AlertDialog.Builder(ProjectDeleteListActivity.this);
            builder.setTitle(ProjectDeleteListActivity.this.getResources().getString(R.string.confirm_delete_projects));
            builder.setPositiveButton(ProjectDeleteListActivity.this.getResources().getString(R.string.yes), new a(str));
            builder.setNegativeButton(ProjectDeleteListActivity.this.getResources().getString(R.string.no), new DialogInterfaceOnClickListenerC0286b(this));
            builder.show();
        }
    }

    public void getProjectFromBd() {
        this.a.clear();
        e eVar = new e(this);
        this.b = eVar;
        SQLiteDatabase writableDatabase = eVar.getWritableDatabase();
        Cursor cursorQuery = writableDatabase.query("TableNameProject", null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            do {
                String string = cursorQuery.getString(cursorQuery.getColumnIndex(IMAPStore.ID_NAME));
                int i2 = cursorQuery.getInt(cursorQuery.getColumnIndex("_id"));
                int i3 = cursorQuery.getInt(cursorQuery.getColumnIndex("countScreen"));
                int i4 = cursorQuery.getInt(cursorQuery.getColumnIndex("countDevice"));
                this.a.add(new g(string, i2, i3, cursorQuery.getString(cursorQuery.getColumnIndex("createdTime")), cursorQuery.getString(cursorQuery.getColumnIndex("createdDate")), i4, false));
            } while (cursorQuery.moveToNext());
        } else {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.not_found_projects), 1).show();
            finish();
        }
        cursorQuery.close();
        writableDatabase.close();
        this.c = (ListView) findViewById(R.id.lvMain);
        c cVar = new c(this, this.a);
        this.f8595d = cVar;
        this.c.setAdapter((ListAdapter) cVar);
        this.c.setOnItemClickListener(this.f8596e);
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.project_list);
        getWindow().setFlags(1024, 1024);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getResources().getString(R.string.delete_project));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
        }
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new a());
        }
        getProjectFromBd();
    }
}
