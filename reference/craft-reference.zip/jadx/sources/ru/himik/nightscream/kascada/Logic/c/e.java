package ru.himik.nightscream.kascada.Logic.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.z;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameIn;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameOut;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class e extends View implements ru.himik.nightscream.kascada.Logic.c.a, ru.himik.nightscream.kascada.s.a, z {
    public int C;
    public int D;
    public a E;
    public a F;
    public a G;
    public a H;
    public b I;
    public int J;
    public int K;
    public int L;
    public int M;
    public boolean N;
    public int O;
    public int P;
    public Paint Q;
    public int R;
    public int S;
    public int T;
    private long U;
    public Point V;
    Context a;
    int b;
    public long c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    String f8994d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    Paint f8995e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8996f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8997g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8998h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    RectF f8999i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    TextPaint f9000j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    float f9001k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    Rect f9002l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f9003m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f9004n;
    public int o;

    public static class a {
        public VarNameIn a;
        private String b = "";
        private int c = 1;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private Point f9005d = new Point(0, 0);

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private ru.himik.nightscream.kascada.Logic.c.a f9006e = null;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        Rect f9007f = new Rect();

        public a(Context context) {
            VarNameIn varNameIn = new VarNameIn(context);
            this.a = varNameIn;
            varNameIn.setInMacro(true);
        }

        public ru.himik.nightscream.kascada.Logic.c.a b() {
            return this.f9006e;
        }

        public String c() {
            return this.b;
        }

        public Point d() {
            return this.f9005d;
        }

        public int e() {
            return this.c;
        }

        public int f(Paint paint) {
            String str = this.b;
            paint.getTextBounds(str, 0, str.length(), this.f9007f);
            return this.f9007f.width();
        }

        public void g(ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.f9006e = aVar;
        }

        public void h(String str) {
            this.b = str;
            this.a.setVarName(str);
        }

        public void i(int i2) {
            this.c = i2;
            this.a.setTypeVar(i2);
        }
    }

    public static class b {
        public VarNameOut a;
        private String b = "";
        private int c = 1;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private Point f9008d = new Point(0, 0);

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private ru.himik.nightscream.kascada.Logic.c.a f9009e = null;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        Rect f9010f = new Rect();

        public b(Context context) {
            VarNameOut varNameOut = new VarNameOut(context);
            this.a = varNameOut;
            varNameOut.setInMacro(true);
        }

        public ru.himik.nightscream.kascada.Logic.c.a b() {
            return this.f9009e;
        }

        public String c() {
            return this.b;
        }

        public Point d() {
            return this.f9008d;
        }

        public int e() {
            return this.c;
        }

        public int f(Paint paint) {
            String str = this.b;
            paint.getTextBounds(str, 0, str.length(), this.f9010f);
            return this.f9010f.width();
        }

        public void g(ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.f9009e = aVar;
        }

        public void h(String str) {
            this.b = str;
            this.a.setVarName(str);
        }

        public void i(int i2) {
            this.c = i2;
            this.a.setTypeVar(i2);
        }
    }

    public e(Context context) {
        super(context);
        this.b = 4;
        this.c = 0L;
        this.f8994d = IMAPStore.ID_NAME;
        this.f8995e = new Paint();
        this.f8996f = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.f8997g = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.f8998h = (int) getResources().getDimension(R.dimen.view_root_macro_in_height);
        this.f8999i = new RectF();
        this.f9000j = new TextPaint();
        this.f9001k = 0.0f;
        getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.f9002l = new Rect();
        this.f9003m = 5;
        this.f9004n = false;
        this.o = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width));
        this.C = Math.round(getResources().getDimension(R.dimen.view_root_macro_4in_height));
        this.J = 0;
        this.K = 1;
        this.L = 0;
        this.M = -1;
        this.N = false;
        this.O = 0;
        this.P = 0;
        this.Q = new Paint();
        this.R = -1;
        this.S = -1;
        this.T = -1;
        this.U = 0L;
        this.V = new Point();
        this.o = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width));
        this.C = Math.round(getResources().getDimension(R.dimen.view_root_macro_4in_height));
        this.a = context;
        this.E = new a(context);
        this.F = new a(context);
        this.G = new a(context);
        this.H = new a(context);
        this.I = new b(context);
    }

    public e(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = 4;
        this.c = 0L;
        this.f8994d = IMAPStore.ID_NAME;
        this.f8995e = new Paint();
        this.f8996f = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.f8997g = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.f8998h = (int) getResources().getDimension(R.dimen.view_root_macro_in_height);
        this.f8999i = new RectF();
        this.f9000j = new TextPaint();
        this.f9001k = 0.0f;
        getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.f9002l = new Rect();
        this.f9003m = 5;
        this.f9004n = false;
        this.o = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width));
        this.C = Math.round(getResources().getDimension(R.dimen.view_root_macro_4in_height));
        this.J = 0;
        this.K = 1;
        this.L = 0;
        this.M = -1;
        this.N = false;
        this.O = 0;
        this.P = 0;
        this.Q = new Paint();
        this.R = -1;
        this.S = -1;
        this.T = -1;
        this.U = 0L;
        this.V = new Point();
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.o = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width)));
            this.C = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_root_macro_4in_height)));
        } catch (Exception unused) {
        }
        this.E = new a(context);
        this.F = new a(context);
        this.G = new a(context);
        this.H = new a(context);
        this.I = new b(context);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void a() {
        if (this.E.b() != null) {
            this.E.b().m();
        }
        if (this.F.b() != null) {
            this.F.b().m();
        }
        if (this.G.b() != null) {
            this.G.b().m();
        }
        if (this.H.b() != null) {
            this.H.b().m();
        }
        if (this.I.b() != null) {
            this.I.b().k(this.J);
        }
        ((mbCanvas) this.a).y(this.f8994d, this.c);
    }

    public void b() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void c() {
        if (this.I.b() != null) {
            this.I.b().k(this.J);
            this.I.g(null);
        }
        this.M = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void d(ru.himik.nightscream.kascada.Logic.c.a aVar, int i2) {
        if (i2 == 1) {
            this.E.g(aVar);
        }
        if (i2 == 2) {
            this.F.g(aVar);
        }
        if (i2 == 3) {
            this.G.g(aVar);
        }
        if (i2 == 4) {
            this.H.g(aVar);
        }
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.V.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void e(ru.himik.nightscream.kascada.Logic.c.a aVar) {
        this.I.g(aVar);
        this.M = aVar.getKey();
    }

    public void f() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean g() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return getTypeFb();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return getNumScreen();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.O;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getFreeIn() {
        if (this.E.b() == null) {
            return 1;
        }
        if (this.F.b() == null) {
            return 2;
        }
        if (this.G.b() == null) {
            return 3;
        }
        return this.H.b() == null ? 4 : 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return getTypeFb();
    }

    public Object getIn() {
        return null;
    }

    public ru.himik.nightscream.kascada.Logic.c.a getIn1() {
        return null;
    }

    public ru.himik.nightscream.kascada.Logic.c.a getIn2() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getInvertOut() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getJsonMacroOutIfNeed() {
        if (q() == null || q().getTypeFb() != 135) {
            return "";
        }
        FB_MACRO fb_macro = (FB_MACRO) q();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(IMAPStore.ID_NAME, fb_macro.getName());
            jSONObject.put("x", (int) fb_macro.getX());
            jSONObject.put("y", (int) fb_macro.getY());
            jSONObject.put("numScreen", fb_macro.getNumScreen());
            return jSONObject.toString();
        } catch (JSONException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public JSONObject getJsonOther() {
        return new JSONObject();
    }

    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a, ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getKeyOut() {
        return this.M;
    }

    int getMaxWeightText() {
        a aVar = this.E;
        int iF = (aVar == null || aVar.f(this.f9000j) <= 0) ? 0 : this.E.f(this.f9000j);
        a aVar2 = this.F;
        if (aVar2 != null && aVar2.f(this.f9000j) > iF) {
            iF = this.F.f(this.f9000j);
        }
        a aVar3 = this.G;
        if (aVar3 != null && aVar3.f(this.f9000j) > iF) {
            iF = this.G.f(this.f9000j);
        }
        a aVar4 = this.H;
        return (aVar4 == null || aVar4.f(this.f9000j) <= iF) ? iF : this.H.f(this.f9000j);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.f8994d;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumOnIn() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumScreen() {
        return this.K;
    }

    public Object getOut() {
        return null;
    }

    public Point getPointIn1() {
        return null;
    }

    public Point getPointIn2() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point getPointOut() {
        return this.I.d();
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getRootNameMacro() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public long getRootUniqueIdMacro() {
        return 0L;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdBeforeCopy() {
        return this.R;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdOutBeforeCopy() {
        return this.T;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveKey() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveNumInBeforeCopy() {
        return this.S;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.U;
    }

    public int getTypeFb() {
        return 135;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return this.I.e();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getVarConstant() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public float getVarFloatConstant() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getVarIntConstant() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void i() {
        invalidate();
    }

    int j() {
        int maxWeightText = getMaxWeightText();
        int iF = this.I.f(this.f9000j);
        int iWidth = this.f9002l.width();
        int i2 = maxWeightText + iF;
        return i2 < iWidth ? iWidth + (this.f8996f * 4) : i2 + (this.f8996f * 4);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void k(int i2) {
        if (i2 == 1) {
            this.E.g(null);
        }
        if (i2 == 2) {
            this.F.g(null);
        }
        if (i2 == 3) {
            this.G.g(null);
        }
        if (i2 == 4) {
            this.H.g(null);
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a l(int i2) {
        a aVar;
        if (i2 == 1) {
            aVar = this.E;
        } else if (i2 == 2) {
            aVar = this.F;
        } else if (i2 == 3) {
            aVar = this.G;
        } else {
            if (i2 != 4) {
                return null;
            }
            aVar = this.H;
        }
        return aVar.b();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void m() {
        this.I.g(null);
        this.J = 0;
        this.M = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point n(int i2) {
        if (i2 == 1) {
            return this.E.d();
        }
        if (i2 == 2) {
            return this.F.d();
        }
        if (i2 == 3) {
            return this.G.d();
        }
        return i2 == 4 ? this.H.d() : new Point((int) getX(), (int) getY());
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        a aVar;
        if (i2 == 1) {
            aVar = this.E;
        } else if (i2 == 2) {
            aVar = this.F;
        } else if (i2 == 3) {
            aVar = this.G;
        } else {
            if (i2 != 4) {
                return 0;
            }
            aVar = this.H;
        }
        return aVar.e();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        float maxWeightText;
        float f2;
        int maxWeightText2;
        super.onDraw(canvas);
        this.f8995e.setStyle(Paint.Style.FILL);
        this.f8995e.setColor(-7829368);
        this.f8995e.setStrokeWidth(this.f8997g);
        this.f8999i.set(this.f8996f, this.f8997g, getWidth() - this.f8996f, getHeight() - this.f8997g);
        canvas.drawRect(this.f8999i, this.f8995e);
        this.f8995e.setStyle(Paint.Style.STROKE);
        this.f8995e.setColor(-16777216);
        canvas.drawRect(this.f8999i, this.f8995e);
        this.f9003m = this.b == 0 ? getHeight() / 2 : getHeight() / (this.b + 1);
        canvas.drawLine(this.f8996f, this.f9003m, (getWidth() - this.f8996f) - this.f8997g, this.f9003m, this.f8995e);
        if (this.f9004n) {
            maxWeightText = getWidth() / 2;
            f2 = this.f9003m;
            maxWeightText2 = getWidth() / 2;
        } else {
            maxWeightText = getMaxWeightText() + (this.f8996f * 2);
            f2 = this.f9003m;
            maxWeightText2 = getMaxWeightText() + (this.f8996f * 2);
        }
        canvas.drawLine(maxWeightText, f2, maxWeightText2, getHeight() - this.f8997g, this.f8995e);
        this.f9000j.setTextAlign(Paint.Align.CENTER);
        this.f9000j.setColor(getResources().getColor(R.color.text_color_logic));
        String str = this.f8994d;
        float width = getWidth() / 2;
        int i2 = this.f9003m;
        canvas.drawText(str, width, (i2 - (i2 / 2)) + this.f9001k, this.f9000j);
        this.f9000j.setTextAlign(Paint.Align.LEFT);
        if (this.b >= 1) {
            setColorOfType(this.E.e());
            String strC = this.E.c();
            int i3 = this.f8996f;
            int i4 = this.f9003m;
            canvas.drawText(strC, i3 + (i3 / 2), (i4 / 2) + i4 + this.f9001k, this.f9000j);
            int i5 = this.f9003m;
            canvas.drawLine(0.0f, (i5 / 2) + i5, this.f8996f, (i5 / 2) + i5, this.f8995e);
        }
        if (this.b >= 2) {
            setColorOfType(this.F.e());
            String strC2 = this.F.c();
            int i6 = this.f8996f;
            int i7 = this.f9003m;
            canvas.drawText(strC2, i6 + (i6 / 2), (i7 / 2) + (i7 * 2) + this.f9001k, this.f9000j);
            int i8 = this.f9003m;
            canvas.drawLine(0.0f, (i8 / 2) + (i8 * 2), this.f8996f, (i8 / 2) + (i8 * 2), this.f8995e);
        }
        if (this.b >= 3) {
            setColorOfType(this.G.e());
            String strC3 = this.G.c();
            int i9 = this.f8996f;
            int i10 = this.f9003m;
            canvas.drawText(strC3, i9 + (i9 / 2), (i10 / 2) + (i10 * 3) + this.f9001k, this.f9000j);
            int i11 = this.f9003m;
            canvas.drawLine(0.0f, (i11 / 2) + (i11 * 3), this.f8996f, (i11 / 2) + (i11 * 3), this.f8995e);
        }
        if (this.b >= 4) {
            setColorOfType(this.H.e());
            String strC4 = this.H.c();
            int i12 = this.f8996f;
            int i13 = this.f9003m;
            canvas.drawText(strC4, i12 + (i12 / 2), (i13 / 2) + (i13 * 4) + this.f9001k, this.f9000j);
            int i14 = this.f9003m;
            canvas.drawLine(0.0f, (i14 / 2) + (i14 * 4), this.f8996f, (i14 / 2) + (i14 * 4), this.f8995e);
        }
        setColorOfType(this.I.e());
        this.f9000j.setTextAlign(Paint.Align.RIGHT);
        if (this.b > 1) {
            String strC5 = this.I.c();
            int width2 = getWidth();
            int i15 = this.f8996f;
            canvas.drawText(strC5, (width2 - i15) - (i15 / 2), (getHeight() / 2) + this.f9001k, this.f9000j);
            canvas.drawLine(getWidth() - this.f8996f, getHeight() / 2, getWidth(), getHeight() / 2, this.f8995e);
        } else {
            String strC6 = this.I.c();
            int width3 = getWidth();
            int i16 = this.f8996f;
            int i17 = this.f9003m;
            canvas.drawText(strC6, (width3 - i16) - (i16 / 2), (i17 / 2) + i17 + this.f9001k, this.f9000j);
            float width4 = getWidth() - this.f8996f;
            int i18 = this.f9003m;
            float f3 = (i18 / 2) + i18;
            float width5 = getWidth();
            int i19 = this.f9003m;
            canvas.drawLine(width4, f3, width5, (i19 / 2) + i19, this.f8995e);
        }
        if (this.N) {
            this.Q.setColor(-16711936);
            this.Q.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.Q);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        int i4;
        super.onMeasure(i2, i3);
        this.f9000j.setColor(-16777216);
        this.f9000j.setTextAlign(Paint.Align.CENTER);
        this.f9000j.setFlags(1);
        this.f9000j.setTextSize(getResources().getDimension(R.dimen.text_size_root_fb_4in));
        this.f9001k = ((this.f9000j.descent() - this.f9000j.ascent()) / 2.0f) - this.f9000j.descent();
        TextPaint textPaint = this.f9000j;
        String str = this.f8994d;
        textPaint.getTextBounds(str, 0, str.length(), this.f9002l);
        this.o = j();
        getLayoutParams().width = this.o;
        int i5 = this.b;
        if (i5 == 0) {
            int i6 = this.f8998h;
            i4 = i6 + i6;
        } else {
            int i7 = this.f8998h;
            i4 = (i5 * i7) + i7;
        }
        this.C = i4;
        getLayoutParams().height = this.C;
        this.f9003m = this.b == 0 ? getHeight() / 2 : getHeight() / (this.b + 1);
        setMeasuredDimension(this.o, this.C);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a q() {
        return this.I.b();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        Point point;
        float height;
        if (this.b >= 1) {
            this.E.f9005d.x = (int) getX();
            Point point2 = this.E.f9005d;
            int i2 = this.f9003m;
            point2.y = (int) ((i2 / 2) + i2 + getY());
        }
        if (this.b >= 2) {
            this.F.f9005d.x = (int) getX();
            Point point3 = this.F.f9005d;
            int i3 = this.f9003m;
            point3.y = (int) ((i3 / 2) + (i3 * 2) + getY());
        }
        if (this.b >= 3) {
            this.G.f9005d.x = (int) getX();
            Point point4 = this.G.f9005d;
            int i4 = this.f9003m;
            point4.y = (int) ((i4 / 2) + (i4 * 3) + getY());
        }
        if (this.b >= 4) {
            this.H.f9005d.x = (int) getX();
            Point point5 = this.H.f9005d;
            int i5 = this.f9003m;
            point5.y = (int) ((i5 / 2) + (i5 * 4) + getY());
        }
        this.I.f9008d.x = (int) (getX() + getWidth());
        if (this.b > 1) {
            point = this.I.f9008d;
            height = getHeight() / 2;
        } else {
            point = this.I.f9008d;
            int i6 = this.f9003m;
            height = (i6 / 2) + i6;
        }
        point.y = (int) (height + getY());
    }

    public void s(int i2, int i3, int i4, boolean z) {
        getLayoutParams().height = this.C;
        getLayoutParams().width = this.o;
        setY(i3 - (this.C / 2));
        setX(i2 - (this.o / 2));
        setBackgroundColor(0);
        setKey(i4);
        if (!z) {
            this.c = System.currentTimeMillis();
        } else if (this.c == 0) {
            try {
                Thread.sleep(5L);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
            this.c = System.currentTimeMillis();
        }
        this.E.a.setRootUniqueIdMacro(this.c);
        this.F.a.setRootUniqueIdMacro(this.c);
        this.G.a.setRootUniqueIdMacro(this.c);
        this.H.a.setRootUniqueIdMacro(this.c);
        this.I.a.setRootUniqueIdMacro(this.c);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
    }

    void setColorOfType(int i2) {
        TextPaint textPaint;
        int color;
        if (i2 == 1) {
            textPaint = this.f9000j;
            color = getResources().getColor(R.color.text_color_logic);
        } else if (i2 == 2) {
            textPaint = this.f9000j;
            color = -16711936;
        } else {
            if (i2 != 3) {
                return;
            }
            textPaint = this.f9000j;
            color = -16776961;
        }
        textPaint.setColor(color);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.N = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.O = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.P = i2;
    }

    public void setFont(String str) {
    }

    public void setIn(Object obj) {
    }

    public void setInvert(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.D = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setKeyOut(int i2) {
        if (i2 == this.L) {
            i2 = -1;
        }
        this.M = i2;
    }

    public void setName(String str) {
        this.f8994d = str;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setNumOnIn(int i2) {
        this.J = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.K = i2;
    }

    public void setOut(Object obj) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootNameMacro(String str) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootUniqueIdMacro(long j2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdBeforeCopy(int i2) {
        this.R = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdOutBeforeCopy(int i2) {
        this.T = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveKey(int i2) {
        this.L = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveNumInBeforeCopy(int i2) {
        this.S = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.U = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarFloatConstant(float f2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarIntConstant(int i2) {
    }

    public void t(int i2, boolean z) {
        mbCanvas mbcanvas;
        a aVar;
        this.b = i2;
        if (i2 == 1) {
            this.E.a.setY((MyApplication.b().f9041i / 2) - (this.E.a.getHeight() / 2));
            this.E.a.setX(0.0f);
            this.E.a.setNumScreen(-1);
            this.E.a.setRootNameMacro(this.f8994d);
            if (z) {
                mbcanvas = (mbCanvas) this.a;
                aVar = this.E;
                mbcanvas.n(aVar.a);
            }
        } else if (i2 == 2) {
            this.E.a.setY(((MyApplication.b().f9041i / 3) * 1) - (this.E.a.getHeight() / 2));
            this.E.a.setX(0.0f);
            this.E.a.setNumScreen(-1);
            this.E.a.setRootNameMacro(this.f8994d);
            if (z) {
                ((mbCanvas) this.a).n(this.E.a);
            }
            this.F.a.setY(((MyApplication.b().f9041i / 3) * 2) - (this.F.a.getHeight() / 2));
            this.F.a.setX(0.0f);
            this.F.a.setNumScreen(-1);
            this.F.a.setRootNameMacro(this.f8994d);
            if (z) {
                mbcanvas = (mbCanvas) this.a;
                aVar = this.F;
                mbcanvas.n(aVar.a);
            }
        } else if (i2 == 3) {
            this.E.a.setY(((MyApplication.b().f9041i / 4) * 1) - (this.E.a.getHeight() / 2));
            this.E.a.setX(0.0f);
            this.E.a.setNumScreen(-1);
            this.E.a.setRootNameMacro(this.f8994d);
            if (z) {
                ((mbCanvas) this.a).n(this.E.a);
            }
            this.F.a.setY(((MyApplication.b().f9041i / 4) * 2) - (this.F.a.getHeight() / 2));
            this.F.a.setX(0.0f);
            this.F.a.setNumScreen(-1);
            this.F.a.setRootNameMacro(this.f8994d);
            if (z) {
                ((mbCanvas) this.a).n(this.F.a);
            }
            this.G.a.setY(((MyApplication.b().f9041i / 4) * 3) - (this.G.a.getHeight() / 2));
            this.G.a.setX(0.0f);
            this.G.a.setNumScreen(-1);
            this.G.a.setRootNameMacro(this.f8994d);
            if (z) {
                mbcanvas = (mbCanvas) this.a;
                aVar = this.G;
                mbcanvas.n(aVar.a);
            }
        } else if (i2 == 4) {
            this.E.a.setY(((MyApplication.b().f9041i / 5) * 1) - (this.E.a.getHeight() / 2));
            this.E.a.setX(0.0f);
            this.E.a.setNumScreen(-1);
            this.E.a.setRootNameMacro(this.f8994d);
            if (z) {
                ((mbCanvas) this.a).n(this.E.a);
            }
            this.F.a.setY(((MyApplication.b().f9041i / 5) * 2) - (this.F.a.getHeight() / 2));
            this.F.a.setX(0.0f);
            this.F.a.setNumScreen(-1);
            this.F.a.setRootNameMacro(this.f8994d);
            if (z) {
                ((mbCanvas) this.a).n(this.F.a);
            }
            this.G.a.setY(((MyApplication.b().f9041i / 5) * 3) - (this.G.a.getHeight() / 2));
            this.G.a.setX(0.0f);
            this.G.a.setNumScreen(-1);
            this.G.a.setRootNameMacro(this.f8994d);
            if (z) {
                ((mbCanvas) this.a).n(this.G.a);
            }
            this.H.a.setY(((MyApplication.b().f9041i / 5) * 4) - (this.G.a.getHeight() / 2));
            this.H.a.setX(0.0f);
            this.H.a.setNumScreen(-1);
            this.H.a.setRootNameMacro(this.f8994d);
            if (z) {
                mbcanvas = (mbCanvas) this.a;
                aVar = this.H;
                mbcanvas.n(aVar.a);
            }
        }
        this.I.a.setY((MyApplication.b().f9041i / 2) - (this.I.a.getHeight() / 2));
        this.I.a.setX(MyApplication.b().f9040h - (this.I.a.getWidth() * 2));
        this.I.a.setNumScreen(-1);
        this.I.a.setRootNameMacro(this.f8994d);
        if (z) {
            ((mbCanvas) this.a).n(this.I.a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0166  */
    /* JADX WARN: Code duplicated, block: B:18:0x019a  */
    public void u() {
        a aVar;
        VarNameOut varNameOut;
        int i2;
        int width;
        int i3 = this.b;
        if (i3 == 1) {
            this.E.a.setY((MyApplication.b().f9041i / 2) - (this.E.a.getHeight() / 2));
            aVar = this.E;
        } else if (i3 == 2) {
            this.E.a.setY(((MyApplication.b().f9041i / 3) * 1) - (this.E.a.getHeight() / 2));
            this.E.a.setX(0.0f);
            this.F.a.setY(((MyApplication.b().f9041i / 3) * 2) - (this.F.a.getHeight() / 2));
            aVar = this.F;
        } else {
            if (i3 != 3) {
                if (i3 == 4) {
                    this.E.a.setY(((MyApplication.b().f9041i / 5) * 1) - (this.E.a.getHeight() / 2));
                    this.E.a.setX(0.0f);
                    this.F.a.setY(((MyApplication.b().f9041i / 5) * 2) - (this.F.a.getHeight() / 2));
                    this.F.a.setX(0.0f);
                    this.G.a.setY(((MyApplication.b().f9041i / 5) * 3) - (this.G.a.getHeight() / 2));
                    this.G.a.setX(0.0f);
                    this.H.a.setY(((MyApplication.b().f9041i / 5) * 4) - (this.G.a.getHeight() / 2));
                    aVar = this.H;
                }
                if (this.I.a.getHeight() == 0) {
                    this.I.a.measure(0, 0);
                    this.I.a.setY((MyApplication.b().f9041i / 2) - (this.I.a.getMeasuredHeight() / 2));
                    varNameOut = this.I.a;
                    i2 = MyApplication.b().f9040h;
                    width = this.I.a.getMeasuredWidth();
                } else {
                    this.I.a.setY((MyApplication.b().f9041i / 2) - (this.I.a.getHeight() / 2));
                    varNameOut = this.I.a;
                    i2 = MyApplication.b().f9040h;
                    width = this.I.a.getWidth();
                }
                varNameOut.setX(i2 - (width * 2));
            }
            this.E.a.setY(((MyApplication.b().f9041i / 4) * 1) - (this.E.a.getHeight() / 2));
            this.E.a.setX(0.0f);
            this.F.a.setY(((MyApplication.b().f9041i / 4) * 2) - (this.F.a.getHeight() / 2));
            this.F.a.setX(0.0f);
            this.G.a.setY(((MyApplication.b().f9041i / 4) * 3) - (this.G.a.getHeight() / 2));
            aVar = this.G;
        }
        aVar.a.setX(0.0f);
        if (this.I.a.getHeight() == 0) {
            this.I.a.measure(0, 0);
            this.I.a.setY((MyApplication.b().f9041i / 2) - (this.I.a.getMeasuredHeight() / 2));
            varNameOut = this.I.a;
            i2 = MyApplication.b().f9040h;
            width = this.I.a.getMeasuredWidth();
        } else {
            this.I.a.setY((MyApplication.b().f9041i / 2) - (this.I.a.getHeight() / 2));
            varNameOut = this.I.a;
            i2 = MyApplication.b().f9040h;
            width = this.I.a.getWidth();
        }
        varNameOut.setX(i2 - (width * 2));
    }
}
