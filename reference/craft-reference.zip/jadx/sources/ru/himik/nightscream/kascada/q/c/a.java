package ru.himik.nightscream.kascada.q.c;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class a extends Thread {
    Socket a;
    DataInputStream b;
    DataOutputStream c;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f9252f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f9250d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private long f9251e = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    byte[] f9253g = new byte[100];

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    boolean f9254h = false;

    public a(Socket socket, int i2, String str, boolean z) {
        this.f9252f = false;
        setName("ModbusSlaveClient Поток " + i2);
        this.a = socket;
        try {
            this.b = new DataInputStream(socket.getInputStream());
            this.c = new DataOutputStream(socket.getOutputStream());
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        this.f9252f = z;
        start();
    }

    public void a() {
        this.f9250d = true;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        DataOutputStream dataOutputStream;
        while (!this.f9250d) {
            try {
                try {
                    if (this.f9251e != 0 && System.currentTimeMillis() - this.f9251e > 10000) {
                        this.f9250d = true;
                        break;
                    }
                    int i2 = 0;
                    this.f9254h = false;
                    int i3 = this.b.read(this.f9253g);
                    if (i3 < 6) {
                        int[] iArr = new int[i3];
                        while (i2 < i3) {
                            iArr[i2] = this.f9253g[i2] & 255;
                            i2++;
                        }
                        if (this.f9252f) {
                            ru.himik.nightscream.kascada.w.b.a("ModbusSlave", "!ERROR! " + Arrays.toString(iArr));
                        }
                    } else {
                        if (i3 >= 12 && i3 - 6 == this.f9253g[5]) {
                            this.f9254h = true;
                        }
                        if (this.f9254h) {
                            int[] iArr2 = new int[i3];
                            while (i2 < i3) {
                                iArr2[i2] = this.f9253g[i2] & 255;
                                i2++;
                            }
                            if (this.f9252f) {
                                ru.himik.nightscream.kascada.w.b.a("ModbusSlave", Arrays.toString(iArr2));
                            }
                            int i4 = iArr2[7];
                            if (i4 == 3) {
                                this.c.write(c.c(iArr2));
                            } else if (i4 == 6) {
                                this.c.write(c.f(iArr2));
                            } else if (i4 == 16) {
                                this.c.write(c.i(iArr2));
                            }
                            dataOutputStream = this.c;
                        } else if (this.f9253g[0] == 1) {
                            this.f9251e = System.currentTimeMillis();
                            int[] iArr3 = new int[i3];
                            while (i2 < i3) {
                                iArr3[i2] = this.f9253g[i2] & 255;
                                i2++;
                            }
                            if (this.f9252f) {
                                ru.himik.nightscream.kascada.w.b.a("ModbusSlave", Arrays.toString(iArr3));
                            }
                            int i5 = iArr3[1];
                            if (i5 == 1) {
                                this.c.write(c.a(iArr3));
                            } else if (i5 == 3) {
                                this.c.write(c.b(iArr3));
                            } else if (i5 == 5) {
                                this.c.write(c.d(iArr3));
                            } else if (i5 == 6) {
                                this.c.write(c.e(iArr3));
                            } else if (i5 == 15) {
                                this.c.write(c.g(iArr3));
                            } else if (i5 == 16) {
                                this.c.write(c.h(iArr3));
                            }
                            dataOutputStream = this.c;
                        }
                        dataOutputStream.flush();
                    }
                    if (i3 == -1) {
                        this.f9250d = true;
                    }
                    Thread.sleep(5L);
                } catch (IOException e2) {
                    e2.printStackTrace();
                    return;
                }
            } catch (Exception unused) {
                this.a.close();
                return;
            } catch (Throwable th) {
                try {
                    this.a.close();
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                throw th;
            }
        }
        this.a.close();
    }
}
