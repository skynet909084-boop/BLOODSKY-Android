package ru.himik.nightscream.kascada.x;

/* JADX INFO: loaded from: classes2.dex */
public class a {
    public byte[] a(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        if (bVar.f() <= 8) {
            byte[] bArr = new byte[8];
            byte[] bArr2 = {bVar.b(), bVar.q(), b.a((bVar.c() * 16) + bVar.a()), b.b((bVar.c() * 16) + bVar.a()), 0, (byte) bVar.f(), 1, bVar.e()[0], b.b(iD), b.a(iD)};
            System.arraycopy(bArr2, 0, bArr, 0, 8);
            int iD = b.d(bArr);
            return bArr2;
        }
        byte[] bArr3 = new byte[9];
        byte[] bArr4 = {bVar.b(), bVar.q(), b.a((bVar.c() * 16) + bVar.a()), b.b((bVar.c() * 16) + bVar.a()), 0, (byte) bVar.f(), 2, bVar.e()[0], bVar.e()[1], b.b(iD), b.a(iD)};
        System.arraycopy(bArr4, 0, bArr3, 0, 9);
        int iD2 = b.d(bArr3);
        return bArr4;
    }

    public byte[] b(ru.himik.nightscream.kascada.CustomComponents.b bVar, boolean z) {
        byte[] bArr = new byte[8];
        byte[] bArr2 = new byte[6];
        bArr[0] = bVar.b();
        bArr[1] = bVar.q();
        bArr[2] = b.a((bVar.c() * 16) + bVar.a());
        bArr[3] = b.b((bVar.c() * 16) + bVar.a());
        byte b = -1;
        if (bVar.h() == 22) {
            try {
                if (bVar.e()[0] % 2 != 1) {
                    b = 0;
                }
                bArr[4] = b;
            } catch (Exception unused) {
            }
        } else {
            bArr[4] = z ? (byte) -1 : (byte) 0;
        }
        bArr[5] = 0;
        System.arraycopy(bArr, 0, bArr2, 0, 6);
        int iD = b.d(bArr2);
        bArr[6] = b.b(iD);
        bArr[7] = b.a(iD);
        return bArr;
    }

    public byte[] c(ru.himik.nightscream.kascada.CustomComponents.b bVar, int i2) {
        if (i2 != 1) {
            if (i2 == 2) {
                if (bVar.r()) {
                    byte bQ = bVar.q();
                    if (bQ == 15) {
                        return a(bVar);
                    }
                    if (bQ == 16) {
                        return bVar.p() == 1 ? e(bVar) : f(bVar);
                    }
                    switch (bQ) {
                        case 1:
                            return g(bVar);
                        case 2:
                            return h(bVar);
                        case 3:
                            return i(bVar);
                        case 4:
                            return j(bVar);
                        case 5:
                            return b(bVar, bVar.s());
                        case 6:
                            return d(bVar);
                        default:
                            return null;
                    }
                }
                byte bQ2 = bVar.q();
                if (bQ2 == 15) {
                    return k(bVar);
                }
                if (bQ2 == 16) {
                    return bVar.p() == 1 ? n(bVar) : o(bVar);
                }
                switch (bQ2) {
                    case 1:
                        return p(bVar);
                    case 2:
                        return q(bVar);
                    case 3:
                        return r(bVar);
                    case 4:
                        return s(bVar);
                    case 5:
                        return l(bVar, bVar.s());
                    case 6:
                        return m(bVar);
                    default:
                        return null;
                }
            }
            if (i2 != 3) {
                return null;
            }
        }
        byte bQ3 = bVar.q();
        if (bQ3 == 15) {
            return a(bVar);
        }
        if (bQ3 == 16) {
            return bVar.p() == 1 ? e(bVar) : f(bVar);
        }
        switch (bQ3) {
            case 1:
                return g(bVar);
            case 2:
                return h(bVar);
            case 3:
                return i(bVar);
            case 4:
                return j(bVar);
            case 5:
                return b(bVar, bVar.s());
            case 6:
                return d(bVar);
            default:
                return null;
        }
    }

    public byte[] d(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[6];
        byte[] bArr2 = {bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), b.a(bVar.n()), b.b(bVar.n()), b.b(iD), b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 6);
        int iD = b.d(bArr);
        return bArr2;
    }

    public byte[] e(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[11];
        byte[] bArrC = b.c(bVar.o());
        byte[] bArr2 = {bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), 0, 2, 4, bArrC[0], bArrC[1], bArrC[2], bArrC[3], b.b(iD), b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 11);
        int iD = b.d(bArr);
        return bArr2;
    }

    public byte[] f(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        int length = ((byte) (bVar.d().length * 2)) + 9;
        byte[] bArr = new byte[length];
        bArr[0] = bVar.b();
        bArr[1] = bVar.q();
        bArr[2] = b.a(bVar.c());
        bArr[3] = b.b(bVar.c());
        bArr[4] = 0;
        bArr[5] = (byte) bVar.d().length;
        bArr[6] = (byte) (bVar.d().length * 2);
        for (int i2 = 0; i2 < bVar.d().length; i2++) {
            int i3 = (i2 * 2) + 7;
            bArr[i3] = b.e(bVar.d()[i2])[2];
            bArr[i3 + 1] = b.e(bVar.d()[i2])[3];
        }
        int i4 = length - 2;
        byte[] bArr2 = new byte[i4];
        System.arraycopy(bArr, 0, bArr2, 0, i4);
        int iD = b.d(bArr2);
        bArr[i4] = b.b(iD);
        bArr[length - 1] = b.a(iD);
        return bArr;
    }

    public byte[] g(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[6];
        byte[] bArr2 = {bVar.b(), bVar.q(), b.a((bVar.c() * 16) + bVar.a()), b.b((bVar.c() * 16) + bVar.a()), 0, (byte) bVar.f(), b.b(iD), b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 6);
        int iD = b.d(bArr);
        return bArr2;
    }

    public byte[] h(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[6];
        byte[] bArr2 = {bVar.b(), bVar.q(), b.a((bVar.c() * 16) + bVar.a()), b.b((bVar.c() * 16) + bVar.a()), 0, (byte) bVar.f(), b.b(iD), b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 6);
        int iD = b.d(bArr);
        return bArr2;
    }

    public byte[] i(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[6];
        byte[] bArr2 = {bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), 0, bVar.g(), b.b(iD), b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 6);
        int iD = b.d(bArr);
        return bArr2;
    }

    public byte[] j(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[6];
        byte[] bArr2 = {bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), 0, bVar.g(), b.b(iD), b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 6);
        int iD = b.d(bArr);
        return bArr2;
    }

    public byte[] k(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[15];
        bArr[0] = 0;
        bArr[1] = 0;
        bArr[2] = 0;
        bArr[3] = 0;
        bArr[4] = 0;
        if (bVar.f() <= 8) {
            bArr[5] = 8;
        } else {
            bArr[5] = 9;
        }
        bArr[6] = bVar.b();
        bArr[7] = bVar.q();
        bArr[8] = b.a((bVar.c() * 16) + bVar.a());
        bArr[9] = b.b((bVar.c() * 16) + bVar.a());
        bArr[10] = 0;
        bArr[11] = (byte) bVar.f();
        if (bVar.f() <= 8) {
            bArr[12] = 1;
            bArr[13] = bVar.e()[0];
        } else {
            bArr[12] = 2;
            bArr[13] = bVar.e()[0];
            bArr[14] = bVar.e()[1];
        }
        return bArr;
    }

    public byte[] l(ru.himik.nightscream.kascada.CustomComponents.b bVar, boolean z) {
        byte[] bArr = new byte[12];
        bArr[0] = 0;
        bArr[1] = 0;
        bArr[2] = 0;
        bArr[3] = 0;
        bArr[4] = 0;
        bArr[5] = 6;
        bArr[6] = bVar.b();
        bArr[7] = bVar.q();
        bArr[8] = b.a((bVar.c() * 16) + bVar.a());
        bArr[9] = b.b((bVar.c() * 16) + bVar.a());
        byte b = -1;
        if (bVar.h() == 22) {
            try {
                if (bVar.e()[0] % 2 != 1) {
                    b = 0;
                }
                bArr[10] = b;
            } catch (Exception unused) {
            }
        } else {
            bArr[10] = z ? (byte) -1 : (byte) 0;
        }
        bArr[11] = 0;
        return bArr;
    }

    public byte[] m(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        return new byte[]{0, 0, 0, 0, 0, 6, bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), b.e(bVar.n())[2], b.e(bVar.n())[3]};
    }

    public byte[] n(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArrC = b.c(bVar.o());
        return new byte[]{0, 0, 0, 0, 0, 11, bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), 0, 2, 4, bArrC[0], bArrC[1], bArrC[2], bArrC[3]};
    }

    public byte[] o(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        byte[] bArr = new byte[((byte) (bVar.d().length * 2)) + 13];
        bArr[0] = 0;
        bArr[1] = 0;
        bArr[2] = 0;
        bArr[3] = 0;
        bArr[4] = 0;
        bArr[5] = (byte) (((byte) (bVar.d().length * 2)) + 7);
        bArr[6] = bVar.b();
        bArr[7] = bVar.q();
        bArr[8] = b.a(bVar.c());
        bArr[9] = b.b(bVar.c());
        bArr[10] = 0;
        bArr[11] = (byte) bVar.d().length;
        bArr[12] = (byte) (bVar.d().length * 2);
        for (int i2 = 0; i2 < bVar.d().length; i2++) {
            int i3 = (i2 * 2) + 13;
            bArr[i3] = b.e(bVar.d()[i2])[2];
            bArr[i3 + 1] = b.e(bVar.d()[i2])[3];
        }
        return bArr;
    }

    public byte[] p(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        return new byte[]{0, 0, 0, 0, 0, 6, bVar.b(), bVar.q(), b.a((bVar.c() * 16) + bVar.a()), b.b((bVar.c() * 16) + bVar.a()), 0, (byte) bVar.f()};
    }

    public byte[] q(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        return new byte[]{0, 0, 0, 0, 0, 6, bVar.b(), bVar.q(), b.a((bVar.c() * 16) + bVar.a()), b.b((bVar.c() * 16) + bVar.a()), 0, (byte) bVar.f()};
    }

    public byte[] r(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        return new byte[]{0, 0, 0, 0, 0, 6, bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), 0, bVar.g()};
    }

    public byte[] s(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        return new byte[]{0, 0, 0, 0, 0, 6, bVar.b(), bVar.q(), b.a(bVar.c()), b.b(bVar.c()), 0, bVar.g()};
    }
}
