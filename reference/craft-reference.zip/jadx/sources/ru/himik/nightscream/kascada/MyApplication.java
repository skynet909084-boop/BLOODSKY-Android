package ru.himik.nightscream.kascada;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.SparseArray;
import com.yandex.metrica.YandexMetrica;
import com.yandex.metrica.YandexMetricaConfig;
import java.util.ArrayList;
import java.util.Iterator;
import l.c0;
import ru.himik.nightscream.kascada.CustomComponents.CustomDynText;
import ru.himik.nightscream.kascada.CustomComponents.CustomList;
import ru.himik.nightscream.kascada.CustomComponents.CustomSound;
import ru.himik.nightscream.kascada.CustomComponents.q;
import ru.himik.nightscream.kascada.CustomComponents.r;
import ru.himik.nightscream.kascada.CustomComponents.t;
import ru.himik.nightscream.kascada.CustomComponents.u;
import ru.himik.nightscream.kascada.CustomComponents.w;
import ru.himik.nightscream.kascada.CustomComponents.x;
import ru.himik.nightscream.kascada.Preference.x0;
import ru.himik.nightscream.kascada.Utils.ForegroundService;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class MyApplication extends Application {
    public static ru.himik.nightscream.kascada.Logic.VarName.a A0;
    private static MyApplication B0;
    public ArrayList<x0> C;
    public SparseArray<ru.himik.nightscream.kascada.Logic.c.a> D;
    public ArrayList<ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a> E;
    public SparseArray F;
    public SparseArray G;
    public SparseArray H;
    public SparseArray I;
    public SparseArray J;
    public SparseArray K;
    public SparseArray L;
    public SparseArray M;
    public SparseArray N;
    public SparseArray O;
    public SparseArray P;
    public SparseArray Q;
    public SparseArray R;
    public SparseArray S;
    public SparseArray T;
    public SparseArray U;
    public SparseArray V;
    public SparseArray W;
    public SparseArray X;
    public SparseArray Y;
    public SparseArray Z;
    public SparseArray a0;
    public SparseArray b0;
    public char c;
    public SparseArray c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList<ru.himik.nightscream.kascada.Preference.ServerList.a> f9036d;
    public SparseArray d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f9037e;
    public SparseArray e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f9038f;
    public SparseArray f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f9039g;
    public SharedPreferences g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f9040h;
    public Context h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f9041i;
    public boolean i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f9042j;
    public String j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public String f9043k;
    public String k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public String f9044l;
    public String l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public String f9045m;
    public String m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f9046n;
    public Boolean n0;
    public int o;
    public ru.himik.nightscream.kascada.q.b.a o0;
    public ru.himik.nightscream.kascada.q.b.a p0;
    public ru.himik.nightscream.kascada.q.b.b q0;
    public ru.himik.nightscream.kascada.q.b.b r0;
    public LocationManager s0;
    public SensorManager t0;
    public ru.himik.nightscream.kascada.Logic.b u0;
    public ru.himik.nightscream.kascada.q.d.b v0;
    public ru.himik.nightscream.kascada.q.c.b w0;
    public ru.himik.nightscream.kascada.q.f.b x0;
    public f.d.a.a.b y0;
    public String z0;
    public i.b.q.b<ru.himik.nightscream.kascada.Utils.m> a = i.b.q.b.q();
    public i.b.q.b<String> b = i.b.q.b.q();

    public MyApplication() {
        new c0();
        this.c = (char) 0;
        this.f9036d = new ArrayList<>();
        this.f9037e = false;
        this.f9038f = false;
        this.f9039g = 1502;
        this.f9040h = 0;
        this.f9041i = 0;
        this.f9042j = 16;
        this.f9043k = "";
        this.f9044l = "";
        this.f9045m = "";
        this.f9046n = false;
        this.o = 1;
        this.C = new ArrayList<>();
        this.D = new SparseArray<>();
        this.E = new ArrayList<>();
        this.F = new SparseArray();
        this.G = new SparseArray();
        this.H = new SparseArray();
        this.I = new SparseArray();
        this.J = new SparseArray();
        this.K = new SparseArray();
        this.L = new SparseArray();
        this.M = new SparseArray();
        this.N = new SparseArray();
        this.O = new SparseArray();
        this.P = new SparseArray();
        this.Q = new SparseArray();
        this.R = new SparseArray();
        this.S = new SparseArray();
        this.T = new SparseArray();
        this.U = new SparseArray();
        this.V = new SparseArray();
        this.W = new SparseArray();
        this.X = new SparseArray();
        this.Y = new SparseArray();
        this.Z = new SparseArray();
        this.a0 = new SparseArray();
        this.b0 = new SparseArray();
        this.c0 = new SparseArray();
        this.d0 = new SparseArray();
        this.e0 = new SparseArray();
        this.f0 = new SparseArray();
        this.h0 = this;
        this.i0 = false;
        this.j0 = "";
        this.k0 = "";
        this.l0 = "";
        this.m0 = "";
        this.n0 = Boolean.FALSE;
        this.o0 = new ru.himik.nightscream.kascada.q.b.a("", 0, "", "");
        this.p0 = new ru.himik.nightscream.kascada.q.b.a("", 0, "", "");
        this.q0 = new ru.himik.nightscream.kascada.q.b.b(1);
        this.r0 = new ru.himik.nightscream.kascada.q.b.b(2);
        this.s0 = null;
        this.t0 = null;
        this.u0 = new ru.himik.nightscream.kascada.Logic.b();
        this.v0 = new ru.himik.nightscream.kascada.q.d.b(this);
        this.w0 = new ru.himik.nightscream.kascada.q.c.b();
        this.x0 = new ru.himik.nightscream.kascada.q.f.b();
        this.z0 = "";
    }

    public static MyApplication b() {
        return B0;
    }

    private boolean d() {
        Iterator<ActivityManager.RunningServiceInfo> it = ((ActivityManager) getSystemService("activity")).getRunningServices(Integer.MAX_VALUE).iterator();
        while (it.hasNext()) {
            if ("ru.himik.nightscream.kascada.Utils.ForegroundService".equals(it.next().service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void a() {
        Log.d("NS", "MyApplication.exitFromProject: ");
        this.b.d("");
        this.a.d(new ru.himik.nightscream.kascada.Utils.m(0));
        this.o0 = new ru.himik.nightscream.kascada.q.b.a("", 0, "", "");
        this.p0 = new ru.himik.nightscream.kascada.q.b.a("", 0, "", "");
        h();
        this.C.clear();
        this.E.clear();
        this.f9036d.clear();
        this.D.clear();
        this.F.clear();
        this.G.clear();
        this.H.clear();
        this.I.clear();
        this.J.clear();
        this.K.clear();
        this.L.clear();
        this.M.clear();
        this.N.clear();
        this.O.clear();
        this.P.clear();
        this.Q.clear();
        this.R.clear();
        this.S.clear();
        this.T.clear();
        this.U.clear();
        this.V.clear();
        this.W.clear();
        this.X.clear();
        this.Y.clear();
        this.Z.clear();
        this.a0.clear();
        this.b0.clear();
        this.c0.clear();
        this.d0.clear();
        this.e0.clear();
        this.f0.clear();
        A0.c();
        this.u0.b();
        this.v0.cancel();
        this.v0.C();
        ru.himik.nightscream.kascada.q.c.b bVar = this.w0;
        if (bVar != null) {
            bVar.c();
        }
    }

    public ru.himik.nightscream.kascada.Logic.VarName.a c() {
        return A0;
    }

    public void e() {
        if (d()) {
            return;
        }
        g();
    }

    public void f() {
        if (this.n0.booleanValue()) {
            return;
        }
        this.n0 = Boolean.TRUE;
        this.u0.a();
        this.v0.d();
        this.w0.b();
    }

    public void g() {
        Intent intent = new Intent(this, (Class<?>) ForegroundService.class);
        intent.setAction("ACTION_START_FOREGROUND_SERVICE");
        e.g.e.a.i(getApplicationContext(), intent);
    }

    void h() {
        for (int i2 = 0; i2 < b().F.size(); i2++) {
            int iKeyAt = b().F.keyAt(i2);
            ((ru.himik.nightscream.kascada.CustomComponents.y) b().F.get(iKeyAt)).e();
            ((ru.himik.nightscream.kascada.CustomComponents.y) b().F.get(iKeyAt)).f8943g.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.y) b().F.get(iKeyAt)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.y) b().F.get(iKeyAt)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.y) b().F.get(iKeyAt)).invalidate();
        }
        for (int i3 = 0; i3 < b().H.size(); i3++) {
            int iKeyAt2 = b().H.keyAt(i3);
            ((u) b().H.get(iKeyAt2)).f8903k.D(-1);
            ((u) b().H.get(iKeyAt2)).setConnectionError(false);
            ((u) b().H.get(iKeyAt2)).setConnectionTimeOut(false);
            ((u) b().H.get(iKeyAt2)).invalidate();
        }
        for (int i4 = 0; i4 < b().I.size(); i4++) {
            int iKeyAt3 = b().I.keyAt(i4);
            ((q) b().I.get(iKeyAt3)).f8865g.D(-1);
            ((q) b().I.get(iKeyAt3)).setConnectionError(false);
            ((q) b().I.get(iKeyAt3)).setConnectionTimeOut(false);
            ((q) b().I.get(iKeyAt3)).invalidate();
        }
        for (int i5 = 0; i5 < b().J.size(); i5++) {
            int iKeyAt4 = b().J.keyAt(i5);
            ((ru.himik.nightscream.kascada.CustomComponents.e) b().J.get(iKeyAt4)).f8769i.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.e) b().J.get(iKeyAt4)).setOnTouchListener(null);
            if (((ru.himik.nightscream.kascada.CustomComponents.e) b().J.get(iKeyAt4)).m()) {
                ((ru.himik.nightscream.kascada.CustomComponents.e) b().J.get(iKeyAt4)).setBackgroundResource(R.drawable.button);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.e) b().J.get(iKeyAt4)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.e) b().J.get(iKeyAt4)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.e) b().J.get(iKeyAt4)).invalidate();
        }
        for (int i6 = 0; i6 < b().K.size(); i6++) {
            int iKeyAt5 = b().K.keyAt(i6);
            ((CustomDynText) b().K.get(iKeyAt5)).f8667i.D(-1);
            ((CustomDynText) b().K.get(iKeyAt5)).setConnectionError(false);
            ((CustomDynText) b().K.get(iKeyAt5)).setConnectionTimeOut(false);
            ((CustomDynText) b().K.get(iKeyAt5)).invalidate();
        }
        for (int i7 = 0; i7 < b().L.size(); i7++) {
            int iKeyAt6 = b().L.keyAt(i7);
            ((ru.himik.nightscream.kascada.CustomComponents.i) b().L.get(iKeyAt6)).f8813j.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.i) b().L.get(iKeyAt6)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.i) b().L.get(iKeyAt6)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.i) b().L.get(iKeyAt6)).invalidate();
        }
        for (int i8 = 0; i8 < b().M.size(); i8++) {
            int iKeyAt7 = b().M.keyAt(i8);
            ((ru.himik.nightscream.kascada.CustomComponents.c) b().M.get(iKeyAt7)).f8742h.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.c) b().M.get(iKeyAt7)).c(0);
            ((ru.himik.nightscream.kascada.CustomComponents.c) b().M.get(iKeyAt7)).d();
            ((ru.himik.nightscream.kascada.CustomComponents.c) b().M.get(iKeyAt7)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.c) b().M.get(iKeyAt7)).setConnectionTimeOut(false);
        }
        for (int i9 = 0; i9 < b().N.size(); i9++) {
            int iKeyAt8 = b().N.keyAt(i9);
            ((w) b().N.get(iKeyAt8)).f8921g.D(-1);
            ((w) b().N.get(iKeyAt8)).setConnectionError(false);
            ((w) b().N.get(iKeyAt8)).setConnectionTimeOut(false);
        }
        for (int i10 = 0; i10 < b().O.size(); i10++) {
            int iKeyAt9 = b().O.keyAt(i10);
            ((r) b().O.get(iKeyAt9)).setConnectionError(false);
            ((r) b().O.get(iKeyAt9)).setConnectionTimeOut(false);
            ((r) b().O.get(iKeyAt9)).f8874e.D(-1);
            ((r) b().O.get(iKeyAt9)).invalidate();
        }
        for (int i11 = 0; i11 < b().P.size(); i11++) {
            int iKeyAt10 = b().P.keyAt(i11);
            ((ru.himik.nightscream.kascada.CustomComponents.g) b().P.get(iKeyAt10)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.g) b().P.get(iKeyAt10)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.g) b().P.get(iKeyAt10)).I.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.g) b().P.get(iKeyAt10)).invalidate();
        }
        for (int i12 = 0; i12 < b().Q.size(); i12++) {
            int iKeyAt11 = b().Q.keyAt(i12);
            ((ru.himik.nightscream.kascada.CustomComponents.v) b().Q.get(iKeyAt11)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.v) b().Q.get(iKeyAt11)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.v) b().Q.get(iKeyAt11)).f8909f.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.v) b().Q.get(iKeyAt11)).setEnableOnTouch(false);
            ((ru.himik.nightscream.kascada.CustomComponents.v) b().Q.get(iKeyAt11)).invalidate();
        }
        for (int i13 = 0; i13 < b().R.size(); i13++) {
            int iKeyAt12 = b().R.keyAt(i13);
            ((ru.himik.nightscream.kascada.CustomComponents.o) b().R.get(iKeyAt12)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.o) b().R.get(iKeyAt12)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.o) b().R.get(iKeyAt12)).T.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.o) b().R.get(iKeyAt12)).setWorkMode(false);
            ((ru.himik.nightscream.kascada.CustomComponents.o) b().R.get(iKeyAt12)).invalidate();
        }
        for (int i14 = 0; i14 < b().S.size(); i14++) {
            int iKeyAt13 = b().S.keyAt(i14);
            ((ru.himik.nightscream.kascada.CustomComponents.d) b().S.get(iKeyAt13)).f8753h.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.d) b().S.get(iKeyAt13)).invalidate();
            ((ru.himik.nightscream.kascada.CustomComponents.d) b().S.get(iKeyAt13)).t();
            ((ru.himik.nightscream.kascada.CustomComponents.d) b().S.get(iKeyAt13)).q(false);
        }
        for (int i15 = 0; i15 < b().T.size(); i15++) {
            int iKeyAt14 = b().T.keyAt(i15);
            ((ru.himik.nightscream.kascada.CustomComponents.n) b().T.get(iKeyAt14)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.n) b().T.get(iKeyAt14)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.n) b().T.get(iKeyAt14)).f8854g.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.n) b().T.get(iKeyAt14)).setValue(0);
            ((ru.himik.nightscream.kascada.CustomComponents.n) b().T.get(iKeyAt14)).invalidate();
        }
        for (int i16 = 0; i16 < b().U.size(); i16++) {
            int iKeyAt15 = b().U.keyAt(i16);
            ((ru.himik.nightscream.kascada.CustomComponents.h) b().U.get(iKeyAt15)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.h) b().U.get(iKeyAt15)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.h) b().U.get(iKeyAt15)).f8798e.D(-1);
        }
        for (int i17 = 0; i17 < b().V.size(); i17++) {
            int iKeyAt16 = b().V.keyAt(i17);
            ((x) b().V.get(iKeyAt16)).f8932g.D(-1);
            ((x) b().V.get(iKeyAt16)).setConnectionError(false);
            ((x) b().V.get(iKeyAt16)).setConnectionTimeOut(false);
        }
        for (int i18 = 0; i18 < b().W.size(); i18++) {
            int iKeyAt17 = b().W.keyAt(i18);
            ((ru.himik.nightscream.kascada.CustomComponents.k) b().W.get(iKeyAt17)).f8832g.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.k) b().W.get(iKeyAt17)).f8833h.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.k) b().W.get(iKeyAt17)).f8833h.J(false);
            ((ru.himik.nightscream.kascada.CustomComponents.k) b().W.get(iKeyAt17)).setConnectionErrorSource(false);
            ((ru.himik.nightscream.kascada.CustomComponents.k) b().W.get(iKeyAt17)).setConnectionErrorReceive(false);
            ((ru.himik.nightscream.kascada.CustomComponents.k) b().W.get(iKeyAt17)).setConnectionTimeOut(false);
        }
        for (int i19 = 0; i19 < b().X.size(); i19++) {
            int iKeyAt18 = b().X.keyAt(i19);
            ((CustomList) b().X.get(iKeyAt18)).f8687i.D(-1);
            ((CustomList) b().X.get(iKeyAt18)).setConnectionError(false);
            ((CustomList) b().X.get(iKeyAt18)).setConnectionTimeOut(false);
            if (((CustomList) b().X.get(iKeyAt18)).k()) {
                ((CustomList) b().X.get(iKeyAt18)).setBackgroundResource(R.drawable.tab_list);
            }
            ((CustomList) b().X.get(iKeyAt18)).invalidate();
        }
        for (int i20 = 0; i20 < b().Y.size(); i20++) {
            int iKeyAt19 = b().Y.keyAt(i20);
            ((CustomSound) b().Y.get(iKeyAt19)).f8696g.D(-1);
            ((CustomSound) b().Y.get(iKeyAt19)).setConnectionError(false);
            ((CustomSound) b().Y.get(iKeyAt19)).setConnectionTimeOut(false);
            ((CustomSound) b().Y.get(iKeyAt19)).e();
        }
        for (int i21 = 0; i21 < b().Z.size(); i21++) {
            int iKeyAt20 = b().Z.keyAt(i21);
            ((ru.himik.nightscream.kascada.CustomComponents.l) b().Z.get(iKeyAt20)).f8842f.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.l) b().Z.get(iKeyAt20)).f8843g.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.l) b().Z.get(iKeyAt20)).f8843g.J(false);
            ((ru.himik.nightscream.kascada.CustomComponents.l) b().Z.get(iKeyAt20)).setConnectionErrorSource(false);
            ((ru.himik.nightscream.kascada.CustomComponents.l) b().Z.get(iKeyAt20)).setConnectionErrorReceive(false);
            ((ru.himik.nightscream.kascada.CustomComponents.l) b().Z.get(iKeyAt20)).setConnectionTimeOut(false);
        }
        for (int i22 = 0; i22 < b().a0.size(); i22++) {
            ((ru.himik.nightscream.kascada.CustomComponents.f) b().a0.get(b().a0.keyAt(i22))).f();
        }
        for (int i23 = 0; i23 < b().b0.size(); i23++) {
            int iKeyAt21 = b().b0.keyAt(i23);
            ((ru.himik.nightscream.kascada.CustomComponents.m) b().b0.get(iKeyAt21)).setConnectionError(false);
            ((ru.himik.nightscream.kascada.CustomComponents.m) b().b0.get(iKeyAt21)).setConnectionTimeOut(false);
            ((ru.himik.nightscream.kascada.CustomComponents.m) b().b0.get(iKeyAt21)).J0.D(-1);
            ((ru.himik.nightscream.kascada.CustomComponents.m) b().b0.get(iKeyAt21)).invalidate();
        }
        for (int i24 = 0; i24 < b().c0.size(); i24++) {
            int iKeyAt22 = b().c0.keyAt(i24);
            ((t) b().c0.get(iKeyAt22)).f8889g.D(-1);
            ((t) b().c0.get(iKeyAt22)).setConnectionError(false);
            ((t) b().c0.get(iKeyAt22)).setConnectionTimeOut(false);
        }
        for (int i25 = 0; i25 < this.f9036d.size(); i25++) {
            this.f9036d.get(i25).n(false);
        }
    }

    public void i() {
        this.n0 = Boolean.FALSE;
        this.u0.b();
        this.v0.cancel();
        this.w0.c();
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        B0 = this;
        YandexMetrica.activate(getApplicationContext(), YandexMetricaConfig.newConfigBuilder("3c4619b7-3264-4ab0-8bcb-e32da92237e6").build());
        YandexMetrica.enableActivityAutoTracking(this);
        ru.himik.nightscream.kascada.b0.c.a.d();
        this.g0 = PreferenceManager.getDefaultSharedPreferences(this);
        A0 = new ru.himik.nightscream.kascada.Logic.VarName.a();
        this.s0 = (LocationManager) getSystemService("location");
        this.t0 = (SensorManager) getSystemService("sensor");
        this.y0 = f.d.a.a.c.w(this, new f.d.a.a.a(3));
    }

    @Override // android.app.Application
    public void onTerminate() {
        super.onTerminate();
    }
}
