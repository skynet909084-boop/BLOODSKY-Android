package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes2.dex */
public class FB_CTU extends ru.himik.nightscream.kascada.Logic.c.d {
    private char h0;
    boolean i0;
    boolean j0;

    public FB_CTU(Context context) {
        super(context);
        this.h0 = (char) 0;
        this.i0 = false;
        this.j0 = false;
        setName("CTU");
        s("+", 1);
        t("-", 1);
        u("R", 1);
        v("Q", 2);
    }

    public FB_CTU(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.h0 = (char) 0;
        this.i0 = false;
        this.j0 = false;
        setName("CTU");
        s("+", 1);
        t("-", 1);
        u("R", 1);
        v("Q", 2);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.h0 = (char) 0;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8986g;
        if (aVar == null || this.f8987h == null || this.f8988i == null || aVar.getOut() == null || this.f8987h.getOut() == null || this.f8988i.getOut() == null) {
            return;
        }
        try {
            if (!((Boolean) this.f8986g.getOut()).booleanValue()) {
                this.i0 = false;
            } else if (!this.i0) {
                this.i0 = true;
                this.h0 = (char) (this.h0 + 1);
            }
            if (!((Boolean) this.f8987h.getOut()).booleanValue()) {
                this.j0 = false;
            } else if (!this.j0) {
                this.j0 = true;
                this.h0 = (char) (this.h0 - 1);
            }
            if (((Boolean) this.f8988i.getOut()).booleanValue()) {
                this.h0 = (char) 0;
            }
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 3;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8986g;
        if (aVar == null || this.f8987h == null || this.f8988i == null || aVar.getOut() == null || this.f8987h.getOut() == null || this.f8988i.getOut() == null) {
            return null;
        }
        return Integer.valueOf(this.h0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_windowActionBarOverlay;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a l(int i2) {
        if (i2 == 1) {
            return this.f8986g;
        }
        if (i2 == 2) {
            return this.f8987h;
        }
        if (i2 != 3) {
            return null;
        }
        return this.f8988i;
    }
}
