package ru.himik.nightscream.kascada.t.d;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.sun.mail.imap.IMAPStore;
import java.util.List;
import kotlin.b0.d.j;
import kotlin.w.o;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.n;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class c extends RecyclerView.f<a> {
    private final View.OnLongClickListener c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private List<String> f9362d;

    public static final class a extends RecyclerView.c0 {
        private FB_MACRO t;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(View view) {
            super(view);
            j.d(view, "itemView");
            View viewFindViewById = view.findViewById(R.id.fb_macro);
            j.c(viewFindViewById, "itemView.findViewById(R.id.fb_macro)");
            this.t = (FB_MACRO) viewFindViewById;
        }

        public final void M(String str) {
            j.d(str, IMAPStore.ID_NAME);
            ((TextView) this.a.findViewById(R.id.item_title_device)).setText(str);
            n.a aVar = n.a;
            String str2 = MyApplication.b().m0;
            j.c(str2, "get().PROJECT_NAME");
            FB_MACRO fb_macroH = aVar.h(str, str2);
            this.t.t(fb_macroH.getCountIn(), false);
            this.t.E.h(fb_macroH.E.c());
            this.t.F.h(fb_macroH.F.c());
            this.t.G.h(fb_macroH.G.c());
            this.t.H.h(fb_macroH.H.c());
            this.t.setName(str);
            this.t.invalidate();
        }
    }

    public c(View.OnLongClickListener onLongClickListener) {
        j.d(onLongClickListener, "onLong");
        this.c = onLongClickListener;
        this.f9362d = o.g();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.f
    public int c() {
        return this.f9362d.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.f
    /* JADX INFO: renamed from: u, reason: merged with bridge method [inline-methods] */
    public void j(a aVar, int i2) {
        j.d(aVar, "holder");
        aVar.M(this.f9362d.get(i2));
        aVar.a.setOnLongClickListener(this.c);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.f
    /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
    public a l(ViewGroup viewGroup, int i2) {
        j.d(viewGroup, "parent");
        View viewInflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_tile_add_new_macros, viewGroup, false);
        j.c(viewInflate, "view");
        return new a(viewInflate);
    }

    public final void w(List<String> list) {
        j.d(list, "items");
        this.f9362d = list;
        h();
    }
}
