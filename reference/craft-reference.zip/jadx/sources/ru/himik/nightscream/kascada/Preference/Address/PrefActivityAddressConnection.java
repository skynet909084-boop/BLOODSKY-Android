package ru.himik.nightscream.kascada.Preference.Address;

import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.d;
import androidx.appcompat.widget.Toolbar;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class PrefActivityAddressConnection extends d {

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PrefActivityAddressConnection.this.onBackPressed();
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        ru.himik.nightscream.kascada.Preference.Address.a aVar = new ru.himik.nightscream.kascada.Preference.Address.a();
        setContentView(R.layout.pref_activity_adress_connection);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getResources().getString(R.string.pref_connection));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
        }
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new a());
        }
        Intent intent = getIntent();
        int intExtra = intent.getIntExtra("idComponent", 0);
        aVar.c = intExtra;
        if (intExtra == 18) {
            aVar.f9047d = intent.getIntExtra("SmsReceiveTypeCommand", 0);
        }
        intent.getIntExtra("addressPLC", 0);
        aVar.a = intent.getIntExtra("addressRegister", 0);
        aVar.b = intent.getIntExtra("addressBit", 0);
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frameLayout, aVar).commit();
        fragmentManager.executePendingTransactions();
    }
}
