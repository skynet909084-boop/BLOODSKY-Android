package ru.himik.nightscream.kascada.Preference.y0;

import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import org.videolan.libvlc.media.MediaPlayer;
import ru.himik.nightscream.kascada.CustomComponents.e;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class a extends DialogFragment {
    e c;
    int a = 1000;
    int b = MediaPlayer.MEDIA_INFO_BAD_INTERLEAVING;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    View.OnClickListener f9158d = new ViewOnClickListenerC0296a();

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Preference.y0.a$a, reason: collision with other inner class name */
    class ViewOnClickListenerC0296a implements View.OnClickListener {
        ViewOnClickListenerC0296a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            e eVar;
            int i2;
            switch (view.getId()) {
                case R.id.r1 /* 2131296957 */:
                    eVar = a.this.c;
                    i2 = 1;
                    break;
                case R.id.r2 /* 2131296958 */:
                    eVar = a.this.c;
                    i2 = 2;
                    break;
                case R.id.r3 /* 2131296959 */:
                    eVar = a.this.c;
                    i2 = 3;
                    break;
                case R.id.r4 /* 2131296960 */:
                    eVar = a.this.c;
                    i2 = 4;
                    break;
                default:
                    return;
            }
            eVar.setImageState(i2);
            a.this.getDialog().dismiss();
        }
    }

    public void a(e eVar) {
        this.c = eVar;
    }

    public void b(int i2, int i3) {
        this.a = i2;
        this.b = i3;
    }

    @Override // android.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        getDialog().setTitle(getActivity().getResources().getString(R.string.dialog_choose_image));
        getDialog().setCanceledOnTouchOutside(true);
        View viewInflate = layoutInflater.inflate(R.layout.select_image_button, viewGroup, false);
        viewInflate.findViewById(R.id.r1).setOnClickListener(this.f9158d);
        viewInflate.findViewById(R.id.r2).setOnClickListener(this.f9158d);
        viewInflate.findViewById(R.id.r3).setOnClickListener(this.f9158d);
        viewInflate.findViewById(R.id.r4).setOnClickListener(this.f9158d);
        return viewInflate;
    }

    @Override // android.app.Fragment
    public void onResume() {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout((int) (((double) this.a) * 0.75d), this.b);
        window.setGravity(17);
    }
}
