package ru.himik.nightscream.kascada.Logic.VarName;

/* JADX INFO: loaded from: classes2.dex */
public interface b {
    int getTypeVar();

    int getTypeVarValue();

    String getVarName();

    void setTypeVar(int i2);

    void setTypeVarValue(int i2);

    void setVarName(String str);
}
