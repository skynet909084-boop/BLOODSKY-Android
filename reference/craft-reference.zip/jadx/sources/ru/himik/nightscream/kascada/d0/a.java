package ru.himik.nightscream.kascada.d0;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class a {
    private final ConstraintLayout a;
    public final Button b;
    public final ImageView c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final TextView f9194d;

    private a(ConstraintLayout constraintLayout, Button button, ImageView imageView, Toolbar toolbar, TextView textView) {
        this.a = constraintLayout;
        this.b = button;
        this.c = imageView;
        this.f9194d = textView;
    }

    public static a a(View view) {
        int i2 = R.id.btnCopyToBuffer;
        Button button = (Button) view.findViewById(R.id.btnCopyToBuffer);
        if (button != null) {
            i2 = R.id.ivQr;
            ImageView imageView = (ImageView) view.findViewById(R.id.ivQr);
            if (imageView != null) {
                i2 = R.id.toolbar;
                Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
                if (toolbar != null) {
                    i2 = R.id.tvUrl;
                    TextView textView = (TextView) view.findViewById(R.id.tvUrl);
                    if (textView != null) {
                        return new a((ConstraintLayout) view, button, imageView, toolbar, textView);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i2)));
    }

    public static a c(LayoutInflater layoutInflater) {
        return d(layoutInflater, null, false);
    }

    public static a d(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_qr, viewGroup, false);
        if (z) {
            viewGroup.addView(viewInflate);
        }
        return a(viewInflate);
    }

    public ConstraintLayout b() {
        return this.a;
    }
}
