package ru.himik.nightscream.kascada.Utils;

/* JADX INFO: loaded from: classes2.dex */
public final class p {
    private final String a;

    public p(String str) {
        kotlin.b0.d.j.d(str, "msg");
        this.a = str;
    }

    public final String a() {
        return this.a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof p) && kotlin.b0.d.j.a(this.a, ((p) obj).a);
    }

    public int hashCode() {
        return this.a.hashCode();
    }

    public String toString() {
        return "MessageEvent(msg=" + this.a + ')';
    }
}
