package ru.himik.nightscream.kascada.Preference.ServerList;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b extends ArrayAdapter<a> {
    private final Context a;
    LinearLayout b;
    ArrayList<a> c;

    public b(Context context, ArrayList<a> arrayList, boolean z) {
        super(context, R.layout.item_server, arrayList);
        this.c = new ArrayList<>();
        this.a = context;
        this.c = arrayList;
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        int i3;
        View viewInflate = ((LayoutInflater) this.a.getSystemService("layout_inflater")).inflate(R.layout.item_server, viewGroup, false);
        this.b = (LinearLayout) viewInflate.findViewById(R.id.serverListRowItem);
        TextView textView = (TextView) viewInflate.findViewById(R.id.name);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.pause);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.server);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.logo);
        textView.setText(this.c.get(i2).d());
        textView2.setText(getContext().getResources().getString(R.string.pause) + "(" + this.c.get(i2).g() + ")");
        textView3.setText(this.c.get(i2).h());
        int iC = this.c.get(i2).c();
        if (iC != 0) {
            if (iC == 1) {
                i3 = R.drawable.bluetooth;
            } else if (iC == 2) {
                i3 = this.c.get(i2).l() ? R.drawable.wifi_rtu : R.drawable.wifi;
            } else if (iC == 3) {
                i3 = R.drawable.usb;
            } else if (iC == 4) {
                i3 = this.c.get(i2).l() ? R.drawable.cloud_rtu : R.drawable.cloud;
            }
            imageView.setImageResource(i3);
        } else {
            imageView.setImageResource(R.drawable.disable);
            this.b.setBackgroundColor(Color.rgb(216, 216, 216));
            imageView.getLayoutParams().height = 50;
            imageView.getLayoutParams().width = 50;
        }
        return viewInflate;
    }
}
