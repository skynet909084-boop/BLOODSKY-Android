package ru.himik.nightscream.kascada.Connections.Usb.driver;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;

/* JADX INFO: loaded from: classes.dex */
abstract class CommonUsbSerialPort implements UsbSerialPort {
    public static final int DEFAULT_READ_BUFFER_SIZE = 16384;
    public static final int DEFAULT_WRITE_BUFFER_SIZE = 16384;
    protected final UsbDevice mDevice;
    protected final int mPortNumber;
    protected UsbDeviceConnection mConnection = null;
    protected final Object mReadBufferLock = new Object();
    protected final Object mWriteBufferLock = new Object();
    protected byte[] mReadBuffer = new byte[16384];
    protected byte[] mWriteBuffer = new byte[16384];

    public CommonUsbSerialPort(UsbDevice usbDevice, int i2) {
        this.mDevice = usbDevice;
        this.mPortNumber = i2;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract void close();

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract boolean getCD();

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract boolean getCTS();

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract boolean getDSR();

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract boolean getDTR();

    public final UsbDevice getDevice() {
        return this.mDevice;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public int getPortNumber() {
        return this.mPortNumber;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract boolean getRI();

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract boolean getRTS();

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public String getSerial() {
        return this.mConnection.getSerial();
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract void open(UsbDeviceConnection usbDeviceConnection);

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public boolean purgeHwBuffers(boolean z, boolean z2) {
        return (z || z2) ? false : true;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract int read(byte[] bArr, int i2);

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract void setDTR(boolean z);

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract void setParameters(int i2, int i3, int i4, int i5);

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract void setRTS(boolean z);

    public final void setReadBufferSize(int i2) {
        synchronized (this.mReadBufferLock) {
            if (i2 == this.mReadBuffer.length) {
                return;
            }
            this.mReadBuffer = new byte[i2];
        }
    }

    public final void setWriteBufferSize(int i2) {
        synchronized (this.mWriteBufferLock) {
            if (i2 == this.mWriteBuffer.length) {
                return;
            }
            this.mWriteBuffer = new byte[i2];
        }
    }

    public String toString() {
        return String.format("<%s device_name=%s device_id=%s port_number=%s>", getClass().getSimpleName(), this.mDevice.getDeviceName(), Integer.valueOf(this.mDevice.getDeviceId()), Integer.valueOf(this.mPortNumber));
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
    public abstract int write(byte[] bArr, int i2);
}
