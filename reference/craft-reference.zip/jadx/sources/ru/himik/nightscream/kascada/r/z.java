package ru.himik.nightscream.kascada.r;

/* JADX INFO: loaded from: classes2.dex */
public interface z {
    void a(String str);
}
