package ru.himik.nightscream.kascada.r.y;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.b0.d.g;
import kotlin.b0.d.j;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.l;

/* JADX INFO: loaded from: classes2.dex */
public final class c extends ru.himik.nightscream.kascada.r.y.d.c {
    public static final a y0 = new a(null);
    public i.b.l.b w0;
    private ru.himik.nightscream.kascada.d0.b x0;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        public final c a() {
            return new c();
        }
    }

    private final ru.himik.nightscream.kascada.d0.b J1() {
        ru.himik.nightscream.kascada.d0.b bVar = this.x0;
        j.b(bVar);
        return bVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void M1(c cVar, String str) {
        j.d(cVar, "this$0");
        if (j.a(str, "закрыть окно")) {
            cVar.o1();
        } else {
            cVar.J1().f9195d.setText(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void N1(Throwable th) {
    }

    @Override // ru.himik.nightscream.kascada.r.y.d.c
    public void G1() {
        o1();
    }

    public final i.b.l.b K1() {
        i.b.l.b bVar = this.w0;
        if (bVar != null) {
            return bVar;
        }
        j.m("disposableBottomVoice");
        throw null;
    }

    public final void L1() {
        if (!l.a.l()) {
            J1().c.setVisibility(0);
        }
        i.b.l.b bVarJ = MyApplication.b().b.n(i.b.k.b.a.a()).j(new i.b.n.c() { // from class: ru.himik.nightscream.kascada.r.y.b
            @Override // i.b.n.c
            public final void a(Object obj) {
                c.M1(this.a, (String) obj);
            }
        }, new i.b.n.c() { // from class: ru.himik.nightscream.kascada.r.y.a
            @Override // i.b.n.c
            public final void a(Object obj) {
                c.N1((Throwable) obj);
            }
        });
        j.c(bVarJ, "get().commandVoice\n     …age}\")\n                })");
        Q1(bVarJ);
        RotateAnimation rotateAnimation = new RotateAnimation(-20.0f, 20.0f, 1, 0.5f, 1, 0.5f);
        rotateAnimation.setRepeatCount(-1);
        rotateAnimation.setRepeatMode(2);
        rotateAnimation.setDuration(500L);
        rotateAnimation.setFillAfter(true);
        J1().b.startAnimation(rotateAnimation);
    }

    public final void Q1(i.b.l.b bVar) {
        j.d(bVar, "<set-?>");
        this.w0 = bVar;
    }

    @Override // androidx.fragment.app.Fragment
    public View e0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        j.d(layoutInflater, "inflater");
        this.x0 = ru.himik.nightscream.kascada.d0.b.c(layoutInflater, viewGroup, false);
        ConstraintLayout constraintLayoutB = J1().b();
        j.c(constraintLayoutB, "binding.root");
        return constraintLayoutB;
    }

    @Override // androidx.fragment.app.Fragment
    public void f0() {
        K1().i();
        super.f0();
    }

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void h0() {
        super.h0();
        this.x0 = null;
    }

    @Override // androidx.fragment.app.Fragment
    public void z0(View view, Bundle bundle) {
        j.d(view, "view");
        super.z0(view, bundle);
        L1();
    }
}
