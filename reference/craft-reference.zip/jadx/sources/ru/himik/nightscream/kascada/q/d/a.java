package ru.himik.nightscream.kascada.q.d;

/* JADX INFO: loaded from: classes.dex */
public class a {
    public static int[] a = {0, -16777216, -65536, -8388608, -256, -8355840, -16711936, -16744448, -16711681, -16744320, -16776961, -16777088, -65281, -8388480, -4144960, -8355712, -1};
}
