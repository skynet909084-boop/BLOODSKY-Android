package ru.himik.nightscream.kascada.r.i0;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class c extends RecyclerView.f<a> {
    private List<String> c = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private b f9353d;

    static class a extends RecyclerView.c0 {
        TextView t;

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.r.i0.c$a$a, reason: collision with other inner class name */
        class ViewOnClickListenerC0307a implements View.OnClickListener {
            final /* synthetic */ b a;
            final /* synthetic */ String b;

            ViewOnClickListenerC0307a(a aVar, b bVar, String str) {
                this.a = bVar;
                this.b = str;
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                b bVar = this.a;
                if (bVar != null) {
                    bVar.a(this.b);
                }
            }
        }

        a(View view) {
            super(view);
            this.t = (TextView) view.findViewById(R.id.name);
        }

        private void N(String str) {
            this.t.setText(str);
        }

        void M(String str, b bVar) {
            N(str);
            this.a.setOnClickListener(new ViewOnClickListenerC0307a(this, bVar, str));
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.f
    public int c() {
        return this.c.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.f
    /* JADX INFO: renamed from: u, reason: merged with bridge method [inline-methods] */
    public void j(a aVar, int i2) {
        aVar.M(this.c.get(i2), this.f9353d);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.f
    /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
    public a l(ViewGroup viewGroup, int i2) {
        return new a(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_name_object, viewGroup, false));
    }

    public void w(b bVar) {
        this.f9353d = bVar;
    }

    public void x(List<String> list) {
        this.c = list;
        h();
    }
}
