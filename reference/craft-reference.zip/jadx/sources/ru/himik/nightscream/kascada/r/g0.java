package ru.himik.nightscream.kascada.r;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class g0 extends androidx.fragment.app.c {
    private CheckBox v0 = null;
    private CheckBox w0 = null;
    private EditText x0 = null;

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void a0(Bundle bundle) {
        super.a0(bundle);
    }

    @Override // androidx.fragment.app.Fragment
    public View e0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.bottomsheet_remote_control, viewGroup);
        r1().getWindow().requestFeature(1);
        EditText editText = (EditText) viewInflate.findViewById(R.id.modbus_port);
        this.x0 = editText;
        editText.setText(MyApplication.b().f9039g + "");
        CheckBox checkBox = (CheckBox) viewInflate.findViewById(R.id.chKaScadaCloud);
        this.v0 = checkBox;
        checkBox.setChecked(MyApplication.b().f9037e);
        CheckBox checkBox2 = (CheckBox) viewInflate.findViewById(R.id.chKaScadaCloudWebSocket);
        this.w0 = checkBox2;
        checkBox2.setChecked(MyApplication.b().f9038f);
        ((TextView) viewInflate.findViewById(R.id.textKey)).setText(h().getString(R.string.key) + ": " + MyApplication.b().f9044l);
        TextView textView = (TextView) viewInflate.findViewById(R.id.textSubsWeb);
        if (ru.himik.nightscream.kascada.Utils.l.a.k()) {
            textView.setVisibility(8);
            this.w0.setVisibility(0);
        } else {
            textView.setText("Требуется полная версия");
            this.w0.setVisibility(8);
        }
        return viewInflate;
    }

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void h0() {
        super.h0();
        MyApplication.b().f9037e = this.v0.isChecked();
        MyApplication.b().f9038f = this.w0.isChecked();
        try {
            int i2 = Integer.parseInt(this.x0.getText().toString());
            if (i2 >= 1000 && i2 <= 65535) {
                MyApplication.b().f9039g = i2;
                return;
            }
            Toast.makeText(h(), h().getResources().getString(R.string.dialog_modbus_slave_error_port), 0).show();
        } catch (Exception unused) {
            Toast.makeText(h(), h().getResources().getString(R.string.dialog_modbus_slave_error_port), 0).show();
        }
    }

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void x0() {
        super.x0();
        r1().getWindow().setLayout(-2, -2);
        r1().setCanceledOnTouchOutside(true);
    }
}
