package ru.himik.nightscream.kascada.Bd.Import;

/* JADX INFO: loaded from: classes.dex */
public enum k {
    ZIP_FILE,
    FOLDER
}
