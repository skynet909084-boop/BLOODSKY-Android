package ru.himik.nightscream.kascada.Bd.Import;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Objects;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public final class g extends BaseAdapter {
    private final Context a;
    private final ArrayList<j> b;

    public /* synthetic */ class a {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[k.values().length];
            iArr[k.FOLDER.ordinal()] = 1;
            iArr[k.ZIP_FILE.ordinal()] = 2;
            a = iArr;
        }
    }

    public g(Context context, ArrayList<j> arrayList) {
        kotlin.b0.d.j.d(context, "context");
        kotlin.b0.d.j.d(arrayList, "list");
        this.a = context;
        this.b = arrayList;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.b.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i2) {
        j jVar = this.b.get(i2);
        kotlin.b0.d.j.c(jVar, "list[pos]");
        return jVar;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        Object systemService = this.a.getSystemService("layout_inflater");
        Objects.requireNonNull(systemService, "null cannot be cast to non-null type android.view.LayoutInflater");
        LayoutInflater layoutInflater = (LayoutInflater) systemService;
        int i3 = a.a[this.b.get(i2).d().ordinal()];
        if (i3 == 1) {
            View viewInflate = layoutInflater.inflate(R.layout.list_item_import_folder, viewGroup, false);
            kotlin.b0.d.j.c(viewInflate, "inflater.inflate(R.layou…rt_folder, parent, false)");
            View viewFindViewById = viewInflate.findViewById(R.id.text);
            Objects.requireNonNull(viewFindViewById, "null cannot be cast to non-null type android.widget.TextView");
            ((TextView) viewFindViewById).setText(this.b.get(i2).b());
            return viewInflate;
        }
        if (i3 != 2) {
            throw new kotlin.j();
        }
        View viewInflate2 = layoutInflater.inflate(R.layout.list_item_import_zipfiles, viewGroup, false);
        kotlin.b0.d.j.c(viewInflate2, "inflater.inflate(R.layou…_zipfiles, parent, false)");
        View viewFindViewById2 = viewInflate2.findViewById(R.id.text);
        Objects.requireNonNull(viewFindViewById2, "null cannot be cast to non-null type android.widget.TextView");
        View viewFindViewById3 = viewInflate2.findViewById(R.id.textSize);
        Objects.requireNonNull(viewFindViewById3, "null cannot be cast to non-null type android.widget.TextView");
        View viewFindViewById4 = viewInflate2.findViewById(R.id.textDate);
        Objects.requireNonNull(viewFindViewById4, "null cannot be cast to non-null type android.widget.TextView");
        ((TextView) viewFindViewById2).setText(this.b.get(i2).b());
        ((TextView) viewFindViewById3).setText(this.b.get(i2).c());
        ((TextView) viewFindViewById4).setText(this.b.get(i2).a());
        return viewInflate2;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return 2;
    }
}
