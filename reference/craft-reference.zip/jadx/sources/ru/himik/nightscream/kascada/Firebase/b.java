package ru.himik.nightscream.kascada.Firebase;

import android.content.Context;
import f.a.b.p;
import f.a.b.u;
import f.a.b.x.k;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Utils.q;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b {

    static class a implements p.b<JSONObject> {
        a() {
        }

        @Override // f.a.b.p.b
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(JSONObject jSONObject) {
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Firebase.b$b, reason: collision with other inner class name */
    static class C0287b implements p.a {
        C0287b() {
        }

        @Override // f.a.b.p.a
        public void a(u uVar) {
        }
    }

    static class c extends k {
        final /* synthetic */ Context H;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        c(String str, JSONObject jSONObject, p.b bVar, p.a aVar, Context context) {
            super(str, jSONObject, bVar, aVar);
            this.H = context;
        }

        @Override // f.a.b.n
        public Map<String, String> p() {
            HashMap map = new HashMap();
            map.put("Authorization", q.b(this.H.getResources().getString(R.string.sk), this.H));
            map.put("Content-Type", "application/json");
            return map;
        }
    }

    public static k a(String str, String str2, String str3, Context context) {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        try {
            jSONObject2.put("title", str);
            jSONObject2.put("body", str2);
            jSONObject.put("to", str3);
            jSONObject.put("data", jSONObject2);
        } catch (JSONException unused) {
        }
        return new c("https://fcm.googleapis.com/fcm/send", jSONObject, new a(), new C0287b(), context);
    }
}
