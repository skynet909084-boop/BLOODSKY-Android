package ru.himik.nightscream.kascada.r.i0;

/* JADX INFO: loaded from: classes2.dex */
public interface b {
    void a(String str);
}
