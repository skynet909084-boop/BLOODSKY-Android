package ru.himik.nightscream.kascada.Bd.Import;

/* JADX INFO: loaded from: classes.dex */
public interface i {
    void a();

    void b();

    void c(String str);

    void d(String str);

    void e();
}
