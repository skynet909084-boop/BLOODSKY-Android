package ru.himik.nightscream.kascada.Connections.Usb.driver;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.KotlinVersion;

/* JADX INFO: loaded from: classes.dex */
public class Ch34xSerialDriver implements UsbSerialDriver {
    private static final String TAG = "Ch34xSerialDriver";
    private final UsbDevice mDevice;
    private final UsbSerialPort mPort;

    public class Ch340SerialPort extends CommonUsbSerialPort {
        private static final int USB_TIMEOUT_MILLIS = 5000;
        private final int DEFAULT_BAUD_RATE;
        private boolean dtr;
        private UsbEndpoint mReadEndpoint;
        private UsbEndpoint mWriteEndpoint;
        private boolean rts;

        public Ch340SerialPort(UsbDevice usbDevice, int i2) {
            super(usbDevice, i2);
            this.DEFAULT_BAUD_RATE = 9600;
            this.dtr = false;
            this.rts = false;
        }

        private void checkState(String str, int i2, int i3, int[] iArr) throws IOException {
            int i4;
            byte[] bArr = new byte[iArr.length];
            int iControlIn = controlIn(i2, i3, 0, bArr);
            if (iControlIn < 0) {
                throw new IOException("Faild send cmd [" + str + "]");
            }
            if (iControlIn != iArr.length) {
                throw new IOException("Expected " + iArr.length + " bytes, but get " + iControlIn + " [" + str + "]");
            }
            for (int i5 = 0; i5 < iArr.length; i5++) {
                if (iArr[i5] != -1 && iArr[i5] != (i4 = bArr[i5] & 255)) {
                    throw new IOException("Expected 0x" + Integer.toHexString(iArr[i5]) + " bytes, but get 0x" + Integer.toHexString(i4) + " [" + str + "]");
                }
            }
        }

        private int controlIn(int i2, int i3, int i4, byte[] bArr) {
            return this.mConnection.controlTransfer(FtdiSerialDriver.FtdiSerialPort.FTDI_DEVICE_IN_REQTYPE, i2, i3, i4, bArr, bArr.length, 5000);
        }

        private int controlOut(int i2, int i3, int i4) {
            return this.mConnection.controlTransfer(65, i2, i3, i4, null, 0, 5000);
        }

        private void initialize() throws IOException {
            checkState("init #1", 95, 0, new int[]{-1, 0});
            if (controlOut(161, 0, 0) < 0) {
                throw new IOException("init failed! #2");
            }
            setBaudRate(9600);
            checkState("init #4", 149, 9496, new int[]{-1, 0});
            if (controlOut(154, 9496, 80) < 0) {
                throw new IOException("init failed! #5");
            }
            checkState("init #6", 149, 1798, new int[]{KotlinVersion.MAX_COMPONENT_VALUE, 238});
            if (controlOut(161, 20511, 55562) < 0) {
                throw new IOException("init failed! #7");
            }
            setBaudRate(9600);
            writeHandshakeByte();
            checkState("init #10", 149, 1798, new int[]{-1, 238});
        }

        private void setBaudRate(int i2) throws IOException {
            int[] iArr = {2400, 55553, 56, 4800, 25602, 31, 9600, 45570, 19, 19200, 55554, 13, 38400, 25603, 10, 115200, 52227, 8};
            for (int i3 = 0; i3 < 6; i3++) {
                int i4 = i3 * 3;
                if (iArr[i4] == i2) {
                    if (controlOut(154, 4882, iArr[i4 + 1]) < 0) {
                        throw new IOException("Error setting baud rate. #1");
                    }
                    if (controlOut(154, 3884, iArr[i4 + 2]) < 0) {
                        throw new IOException("Error setting baud rate. #1");
                    }
                    return;
                }
            }
            throw new IOException("Baud rate " + i2 + " currently not supported");
        }

        private void writeHandshakeByte() throws IOException {
            if (controlOut(164, ~((this.dtr ? 32 : 0) | (this.rts ? 64 : 0)), 0) < 0) {
                throw new IOException("Faild to set handshake byte");
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void close() throws IOException {
            UsbDeviceConnection usbDeviceConnection = this.mConnection;
            if (usbDeviceConnection == null) {
                throw new IOException("Already closed");
            }
            try {
                usbDeviceConnection.close();
            } finally {
                this.mConnection = null;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCD() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCTS() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDSR() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDTR() {
            return this.dtr;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public UsbSerialDriver getDriver() {
            return Ch34xSerialDriver.this;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public /* bridge */ /* synthetic */ int getPortNumber() {
            return super.getPortNumber();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRI() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRTS() {
            return this.rts;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public /* bridge */ /* synthetic */ String getSerial() {
            return super.getSerial();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void open(UsbDeviceConnection usbDeviceConnection) throws IOException {
            if (this.mConnection != null) {
                throw new IOException("Already opened.");
            }
            this.mConnection = usbDeviceConnection;
            for (int i2 = 0; i2 < this.mDevice.getInterfaceCount(); i2++) {
                try {
                    this.mConnection.claimInterface(this.mDevice.getInterface(i2), true);
                } catch (Throwable th) {
                    try {
                        close();
                    } catch (IOException unused) {
                    }
                    throw th;
                }
            }
            UsbDevice usbDevice = this.mDevice;
            UsbInterface usbInterface = usbDevice.getInterface(usbDevice.getInterfaceCount() - 1);
            for (int i3 = 0; i3 < usbInterface.getEndpointCount(); i3++) {
                UsbEndpoint endpoint = usbInterface.getEndpoint(i3);
                if (endpoint.getType() == 2) {
                    if (endpoint.getDirection() == 128) {
                        this.mReadEndpoint = endpoint;
                    } else {
                        this.mWriteEndpoint = endpoint;
                    }
                }
            }
            initialize();
            setBaudRate(9600);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean purgeHwBuffers(boolean z, boolean z2) {
            return true;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int read(byte[] bArr, int i2) {
            synchronized (this.mReadBufferLock) {
                int iBulkTransfer = this.mConnection.bulkTransfer(this.mReadEndpoint, this.mReadBuffer, Math.min(bArr.length, this.mReadBuffer.length), i2);
                if (iBulkTransfer < 0) {
                    return 0;
                }
                System.arraycopy(this.mReadBuffer, 0, bArr, 0, iBulkTransfer);
                return iBulkTransfer;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setDTR(boolean z) throws IOException {
            this.dtr = z;
            writeHandshakeByte();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setParameters(int i2, int i3, int i4, int i5) throws IOException {
            setBaudRate(i2);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setRTS(boolean z) throws IOException {
            this.rts = z;
            writeHandshakeByte();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort
        public /* bridge */ /* synthetic */ String toString() {
            return super.toString();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int write(byte[] bArr, int i2) throws IOException {
            int iMin;
            byte[] bArr2;
            int iBulkTransfer;
            int i3 = 0;
            while (i3 < bArr.length) {
                synchronized (this.mWriteBufferLock) {
                    iMin = Math.min(bArr.length - i3, this.mWriteBuffer.length);
                    if (i3 == 0) {
                        bArr2 = bArr;
                    } else {
                        System.arraycopy(bArr, i3, this.mWriteBuffer, 0, iMin);
                        bArr2 = this.mWriteBuffer;
                    }
                    iBulkTransfer = this.mConnection.bulkTransfer(this.mWriteEndpoint, bArr2, iMin, i2);
                }
                if (iBulkTransfer <= 0) {
                    throw new IOException("Error writing " + iMin + " bytes at offset " + i3 + " length=" + bArr.length);
                }
                i3 += iBulkTransfer;
            }
            return i3;
        }
    }

    public Ch34xSerialDriver(UsbDevice usbDevice) {
        this.mDevice = usbDevice;
        this.mPort = new Ch340SerialPort(usbDevice, 0);
    }

    public static Map<Integer, int[]> getSupportedDevices() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_QINHENG), new int[]{UsbId.QINHENG_HL340});
        return linkedHashMap;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public UsbDevice getDevice() {
        return this.mDevice;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public List<UsbSerialPort> getPorts() {
        return Collections.singletonList(this.mPort);
    }
}
