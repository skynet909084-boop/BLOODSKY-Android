package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatButton;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class j extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    private boolean C;
    Bitmap D;
    Paint E;
    Paint F;
    boolean G;
    int H;
    int I;
    private long J;
    private boolean K;
    long L;
    public Point M;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    Context f8818d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8819e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8820f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public byte f8821g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8822h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f8823i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    String f8824j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    String f8825k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f8826l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    String f8827m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8828n;
    private boolean o;

    class a implements ru.himik.nightscream.kascada.u.a.c {
        a() {
        }

        @Override // ru.himik.nightscream.kascada.u.a.c
        public void a() {
            j jVar = j.this;
            Toast.makeText(jVar.f8818d, jVar.getResources().getString(R.string.send_email_error), 1).show();
        }
    }

    class b implements ru.himik.nightscream.kascada.u.a.d {
        b() {
        }

        @Override // ru.himik.nightscream.kascada.u.a.d
        public void a() {
            j jVar = j.this;
            Toast.makeText(jVar.f8818d, jVar.getResources().getString(R.string.send_email_successful), 1).show();
        }
    }

    public j(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_email);
        this.f8819e = 28;
        this.f8821g = (byte) 1;
        this.f8822h = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8824j = "";
        this.f8825k = "";
        this.f8826l = "";
        this.f8827m = "";
        this.f8828n = "";
        this.D = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.E = new Paint();
        this.F = new Paint();
        this.G = false;
        this.H = 0;
        this.I = 0;
        this.J = 0L;
        this.K = false;
        this.L = 0L;
        this.M = new Point();
        this.f8818d = context;
    }

    public void a(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_email);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
        this.f8822h.A(this.f8819e);
        this.f8822h.L(this.f8821g);
    }

    public void b(int i2) {
        if (i2 == 1) {
            if (System.currentTimeMillis() - this.L < 10000) {
                return;
            }
            this.L = System.currentTimeMillis();
            if (!this.K) {
                this.K = true;
                ru.himik.nightscream.kascada.u.a.b bVarS = ru.himik.nightscream.kascada.u.a.s(this.f8818d);
                bVarS.D(this.f8826l);
                bVarS.y(this.f8827m);
                bVarS.A("KaScada");
                bVarS.v(this.f8828n);
                bVarS.C("text/plain");
                bVarS.B(this.f8824j);
                bVarS.u(this.f8825k);
                bVarS.z(false);
                bVarS.x(new b());
                bVarS.w(new a());
                bVarS.t();
            }
        }
        if (i2 == 0) {
            this.K = false;
        }
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.M.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public String getBody() {
        return this.f8825k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.f8822h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8819e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8823i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.I;
    }

    public String getEmailLogin() {
        return this.f8826l;
    }

    public String getEmailPassword() {
        return this.f8827m;
    }

    public String getEmailTo() {
        return this.f8828n;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8819e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8822h.l());
        jSONObject.put("addressRegister", this.f8822h.c());
        jSONObject.put("addressBit", (int) this.f8822h.a());
        jSONObject.put("typeRequest", (int) this.f8822h.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("title", this.f8824j);
        jSONObject.put("body", this.f8825k);
        jSONObject.put("emailTo", this.f8828n);
        jSONObject.put("emailLogin", this.f8826l);
        jSONObject.put("emailPassword", this.f8827m);
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8820f;
    }

    public int getNumScreen() {
        return this.f8823i;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.M;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8822h.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8822h.l() >= 100) {
            this.f8822h.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8822h.c() + "." + ((int) this.f8822h.a());
        }
        this.f8822h.u((byte) MyApplication.b().E.get(this.f8822h.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8822h.b()) + "#" + this.f8822h.c() + "." + ((int) this.f8822h.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8822h.l() >= 0) {
            if (this.f8822h.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8822h.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.J;
    }

    public String getTitle() {
        return this.f8824j;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.C) {
            this.F.setColor(-65536);
            this.F.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.F);
        }
        if (this.o && mbCanvas.g1) {
            canvas.drawBitmap(this.D, getWidth() - this.D.getWidth(), getHeight() - this.D.getHeight(), this.E);
        }
        if (this.G) {
            this.F.setColor(-16711936);
            this.F.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.F);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.G;
    }

    public void setBody(String str) {
        this.f8825k = str;
    }

    public void setConnectionError(boolean z) {
        if (this.C != z) {
            this.C = z;
            setVisibility(z ? 0 : 4);
            invalidate();
        }
    }

    public void setConnectionTimeOut(boolean z) {
        if (this.o != z) {
            this.o = z;
            setVisibility(z ? 0 : 4);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.G = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.H = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.I = i2;
    }

    public void setEmailLogin(String str) {
        this.f8826l = str;
    }

    public void setEmailPassword(String str) {
        this.f8827m = str;
    }

    public void setEmailTo(String str) {
        this.f8828n = str;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8820f = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8823i = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.J = j2;
    }

    public void setTitle(String str) {
        this.f8824j = str;
    }
}
