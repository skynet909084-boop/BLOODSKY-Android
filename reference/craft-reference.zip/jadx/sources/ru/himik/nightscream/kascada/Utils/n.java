package ru.himik.nightscream.kascada.Utils;

import android.os.Environment;
import com.sun.mail.imap.IMAPStore;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import kotlin.b0.d.v;
import kotlin.i0.r;
import kotlin.u;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class n {
    public static final a a = new a(null);
    private static final String b;
    private static final String c;

    public static final class a {

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Utils.n$a$a, reason: collision with other inner class name */
        public static final class C0297a<T> implements Comparator {
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                return kotlin.x.b.a(Boolean.valueOf(((File) t).isFile()), Boolean.valueOf(((File) t2).isFile()));
            }
        }

        static final class b extends kotlin.b0.d.k implements kotlin.b0.c.l<File, Boolean> {
            final /* synthetic */ String b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            b(String str) {
                super(1);
                this.b = str;
            }

            @Override // kotlin.b0.c.l
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Boolean l(File file) {
                kotlin.b0.d.j.d(file, "it");
                String name = file.getName();
                kotlin.b0.d.j.c(name, "it.name");
                return Boolean.valueOf(kotlin.i0.q.m(name, this.b, false));
            }
        }

        static final class c extends kotlin.b0.d.k implements kotlin.b0.c.l<String, u> {
            final /* synthetic */ v<String> b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            c(v<String> vVar) {
                super(1);
                this.b = vVar;
            }

            /* JADX WARN: Type inference failed for: r3v1, types: [T, java.lang.String] */
            public final void a(String str) {
                kotlin.b0.d.j.d(str, "it");
                v<String> vVar = this.b;
                vVar.a = kotlin.b0.d.j.i(vVar.a, str);
            }

            @Override // kotlin.b0.c.l
            public /* bridge */ /* synthetic */ u l(String str) {
                a(str);
                return u.a;
            }
        }

        static final class d extends kotlin.b0.d.k implements kotlin.b0.c.l<String, u> {
            final /* synthetic */ v<String> b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            d(v<String> vVar) {
                super(1);
                this.b = vVar;
            }

            /* JADX WARN: Type inference failed for: r3v1, types: [T, java.lang.String] */
            public final void a(String str) {
                kotlin.b0.d.j.d(str, "it");
                v<String> vVar = this.b;
                vVar.a = kotlin.b0.d.j.i(vVar.a, str);
            }

            @Override // kotlin.b0.c.l
            public /* bridge */ /* synthetic */ u l(String str) {
                a(str);
                return u.a;
            }
        }

        static final class e extends kotlin.b0.d.k implements kotlin.b0.c.l<String, u> {
            final /* synthetic */ v<String> b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            e(v<String> vVar) {
                super(1);
                this.b = vVar;
            }

            /* JADX WARN: Type inference failed for: r3v1, types: [T, java.lang.String] */
            public final void a(String str) {
                kotlin.b0.d.j.d(str, "it");
                v<String> vVar = this.b;
                vVar.a = kotlin.b0.d.j.i(vVar.a, str);
            }

            @Override // kotlin.b0.c.l
            public /* bridge */ /* synthetic */ u l(String str) {
                a(str);
                return u.a;
            }
        }

        private a() {
        }

        public /* synthetic */ a(kotlin.b0.d.g gVar) {
            this();
        }

        public final boolean a(String str) {
            kotlin.b0.d.j.d(str, IMAPStore.ID_NAME);
            return new File(e(), kotlin.b0.d.j.i(str, ".mcr")).exists();
        }

        public final String b() {
            a aVar = n.a;
            File file = new File(kotlin.b0.d.j.i(aVar.f(), "kascada_models_file_size.json"));
            if (!file.exists()) {
                String string = MyApplication.b().getResources().getString(R.string.dialog_voice_rec_check_model_error4);
                kotlin.b0.d.j.c(string, "get().resources.getStrin…e_rec_check_model_error4)");
                return string;
            }
            f.f.b.e eVar = new f.f.b.e();
            String path = file.getPath();
            kotlin.b0.d.j.c(path, "fileJsonSize.path");
            Object objI = eVar.i(aVar.i(path), Map.class);
            Objects.requireNonNull(objI, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
            for (Map.Entry entry : ((Map) objI).entrySet()) {
                String str = (String) entry.getKey();
                String str2 = (String) entry.getValue();
                File file2 = new File(kotlin.b0.d.j.i(n.a.f(), str));
                if (!file2.exists()) {
                    return "Файла " + str + " не существует в модели, скачайте заного модель.";
                }
                if (file2.length() != Long.parseLong(str2)) {
                    return "Файл " + str + " имеет не верный размер в модели распознавания голоса.";
                }
            }
            return "";
        }

        public final void c() {
            File file = new File(f());
            if (file.exists()) {
                return;
            }
            file.mkdirs();
        }

        public final List<String> d(String str, String str2) {
            kotlin.b0.d.j.d(str, "ext");
            kotlin.b0.d.j.d(str2, "pathFolder");
            ArrayList arrayList = new ArrayList();
            for (File file : kotlin.h0.o.l(kotlin.h0.o.g(kotlin.a0.l.e(new File(str2), kotlin.a0.h.BOTTOM_UP), new b(str)), new C0297a())) {
                if (file.getName().length() > 4) {
                    String name = file.getName();
                    kotlin.b0.d.j.c(name, "it.name");
                    arrayList.add(r.D0(name, str, null, 2, null));
                }
            }
            return arrayList;
        }

        public final String e() {
            return n.b;
        }

        public final String f() {
            return n.c;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public final String g(String str, String str2) throws IOException {
            kotlin.b0.d.j.d(str, IMAPStore.ID_NAME);
            kotlin.b0.d.j.d(str2, "projectName");
            File file = new File(e() + '/' + str2);
            v vVar = new v();
            vVar.a = "";
            File file2 = new File(file + '/' + str + ".mcr");
            if (file2.exists()) {
                kotlin.a0.k.b(file2, null, new c(vVar), 1, null);
            } else {
                File file3 = new File(kotlin.b0.d.j.i(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath(), "/KaScada/Library/Macros/") + str + ".mcr");
                if (file3.exists()) {
                    kotlin.a0.k.b(file3, null, new d(vVar), 1, null);
                    kotlin.a0.i.g(file3, file2, true, 0, 4, null);
                }
            }
            return (String) vVar.a;
        }

        public final FB_MACRO h(String str, String str2) {
            kotlin.b0.d.j.d(str, IMAPStore.ID_NAME);
            kotlin.b0.d.j.d(str2, "projectName");
            String str3 = e() + str + ".mcr";
            JSONObject jSONObject = new JSONObject(g(str, str2));
            FB_MACRO fb_macro = new FB_MACRO(MyApplication.b().h0);
            fb_macro.t(jSONObject.getInt("countIn"), false);
            fb_macro.E.h(jSONObject.getString("nameIn1"));
            fb_macro.F.h(jSONObject.getString("nameIn2"));
            fb_macro.G.h(jSONObject.getString("nameIn3"));
            fb_macro.H.h(jSONObject.getString("nameIn4"));
            return fb_macro;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public final String i(String str) {
            kotlin.b0.d.j.d(str, "pathAndFileName");
            v vVar = new v();
            vVar.a = "";
            kotlin.a0.k.b(new File(str), null, new e(vVar), 1, null);
            return (String) vVar.a;
        }

        public final void j(String str, String str2, String str3) {
            kotlin.b0.d.j.d(str, "data");
            kotlin.b0.d.j.d(str2, IMAPStore.ID_NAME);
            kotlin.b0.d.j.d(str3, "projectName");
            File file = new File(e() + '/' + str3 + '/');
            if (!file.exists()) {
                file.mkdirs();
            }
            try {
                PrintWriter printWriter = new PrintWriter(new File(file, kotlin.b0.d.j.i(str2, ".mcr")));
                try {
                    printWriter.println(str);
                    u uVar = u.a;
                    kotlin.a0.c.a(printWriter, null);
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        kotlin.a0.c.a(printWriter, th);
                        throw th2;
                    }
                }
            } catch (Exception unused) {
            }
        }
    }

    static {
        kotlin.b0.d.j.i(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath(), "/KaScada/Export/");
        kotlin.b0.d.j.i(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath(), "/KaScada/");
        b = kotlin.b0.d.j.i(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath(), "/KaScada/Projects/");
        c = kotlin.b0.d.j.i(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath(), "/KaScada/RecognitionLibrary/");
    }
}
