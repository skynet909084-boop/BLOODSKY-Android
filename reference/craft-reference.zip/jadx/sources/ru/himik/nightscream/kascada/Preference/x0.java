package ru.himik.nightscream.kascada.Preference;

import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: classes2.dex */
public class x0 {
    Boolean a;
    String b;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    Drawable f9154d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    String f9155e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f9156f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    String f9157g;

    public x0(Boolean bool, String str, int i2, String str2, String str3) {
        this.f9155e = "Экран";
        this.f9157g = "";
        this.a = bool;
        this.b = str;
        this.c = i2;
        this.f9157g = str2;
        this.f9155e = str3;
    }

    public Boolean a() {
        return this.a;
    }

    public int b() {
        return this.c;
    }

    public Drawable c() {
        return this.f9154d;
    }

    public String d() {
        return this.f9155e;
    }

    public String e() {
        return this.f9157g;
    }

    public String f() {
        return this.b;
    }

    public boolean g() {
        return this.f9156f;
    }

    public void h(Boolean bool) {
        this.a = bool;
        this.f9156f = false;
    }

    public void i(int i2) {
        this.c = i2;
    }

    public void j(boolean z) {
        this.f9156f = z;
    }

    public void k(Drawable drawable) {
        this.f9154d = drawable;
    }

    public void l(String str) {
        this.f9155e = str;
    }

    public void m(String str) {
        this.f9157g = str;
    }

    public void n(String str) {
        this.b = str;
        this.f9156f = false;
    }
}
