package ru.himik.nightscream.kascada.r;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.CustomDynText;
import ru.himik.nightscream.kascada.CustomComponents.CustomLabel;
import ru.himik.nightscream.kascada.CustomComponents.CustomList;
import ru.himik.nightscream.kascada.CustomComponents.CustomSound;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Preference.Address.PrefActivityAddressConnection;
import ru.himik.nightscream.kascada.Preference.AlarmSelectSound.PrefActivitySelectAlarmSound;
import ru.himik.nightscream.kascada.Preference.PrefActivity;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class h0 {

    static class a implements View.OnClickListener {
        final /* synthetic */ EditText a;

        a(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class a0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        a0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class a1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9321d;

        a1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9321d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    ((ru.himik.nightscream.kascada.CustomComponents.k) this.c).f8832g.v(i2);
                    int i3 = Integer.parseInt(this.f9321d.getText().toString());
                    if (i3 >= 0 && i3 <= 65535) {
                        ((ru.himik.nightscream.kascada.CustomComponents.k) this.c).f8833h.v(i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class a2 implements DialogInterface.OnClickListener {
        a2() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.dismiss();
        }
    }

    static class b implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9322d;

        b(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9322d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9322d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class b0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        b0(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class b1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        b1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("text", this.b.getCustomText());
                intent.putExtra("sizeText", (int) this.b.getTextSize());
                intent.putExtra("textValue", ((CustomList) this.b).getTextValue());
                intent.putExtra("checkVisible", ((CustomList) this.b).k());
                intent.putExtra("checkNoChange", ((CustomList) this.b).j());
                intent.putExtra("listValue", ((CustomList) this.b).getValueCheckNoChange());
                PreferenceManager.getDefaultSharedPreferences(this.a).edit().putInt("colorText", this.b.getCurrentTextColor()).apply();
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class b2 implements DialogInterface.OnShowListener {
        final /* synthetic */ Spinner[] a;
        final /* synthetic */ View b;
        final /* synthetic */ EditText[] c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText[] f9323d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ boolean f9324e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z f9325f;

        class a implements View.OnClickListener {
            a() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                b2.this.f9323d[0].selectAll();
            }
        }

        class b implements View.OnClickListener {
            b() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                b2.this.c[0].selectAll();
            }
        }

        b2(Spinner[] spinnerArr, View view, EditText[] editTextArr, EditText[] editTextArr2, boolean z, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = spinnerArr;
            this.b = view;
            this.c = editTextArr;
            this.f9323d = editTextArr2;
            this.f9324e = z;
            this.f9325f = zVar;
        }

        @Override // android.content.DialogInterface.OnShowListener
        public void onShow(DialogInterface dialogInterface) {
            EditText editText;
            StringBuilder sb;
            ru.himik.nightscream.kascada.CustomComponents.b bVar;
            this.a[0] = (Spinner) this.b.findViewById(R.id.spinnerFunctionModbus);
            this.c[0] = (EditText) this.b.findViewById(R.id.reg);
            this.f9323d[0] = (EditText) this.b.findViewById(R.id.bit);
            if (this.f9324e) {
                byte bQ = ((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8842f.q();
                if (bQ == 1 || bQ != 2) {
                    Spinner spinner = this.a[0];
                    spinner.setSelection(0);
                } else {
                    this.a[0].setSelection(1);
                }
                this.c[0].setText(((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8842f.c() + "");
                if (((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8842f.l() == 100) {
                    if (((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8842f.f() != 1) {
                        this.f9323d[0].setText("0");
                        this.f9323d[0].setEnabled(false);
                    } else {
                        this.f9323d[0].setText(((int) ((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8842f.a()) + "");
                    }
                    this.a[0].setSelection(0);
                    this.a[0].setEnabled(false);
                } else {
                    editText = this.f9323d[0];
                    sb = new StringBuilder();
                    bVar = ((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8842f;
                    sb.append((int) bVar.a());
                    sb.append("");
                    editText.setText(sb.toString());
                }
            } else {
                this.a[0].setSelection(0);
                this.a[0].setEnabled(false);
                this.c[0].setText(((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8843g.c() + "");
                if (((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8843g.l() != 100 || ((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8843g.f() == 1) {
                    editText = this.f9323d[0];
                    sb = new StringBuilder();
                    bVar = ((ru.himik.nightscream.kascada.CustomComponents.l) this.f9325f).f8843g;
                    sb.append((int) bVar.a());
                    sb.append("");
                    editText.setText(sb.toString());
                } else {
                    this.f9323d[0].setText("0");
                    this.f9323d[0].setEnabled(false);
                }
            }
            this.f9323d[0].setOnClickListener(new a());
            this.c[0].setOnClickListener(new b());
        }
    }

    static class c implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        c(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.dialog_change_image /* 2131296568 */:
                    FragmentManager fragmentManager = ((mbCanvas) this.a).getFragmentManager();
                    ru.himik.nightscream.kascada.Preference.y0.a aVar = new ru.himik.nightscream.kascada.Preference.y0.a();
                    aVar.b(MyApplication.b().f9040h, MyApplication.b().f9041i);
                    aVar.a((ru.himik.nightscream.kascada.CustomComponents.e) this.b);
                    aVar.show(fragmentManager, "");
                    break;
                case R.id.dialog_preference /* 2131296572 */:
                    Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                    intent.putExtra("portraitMode", MyApplication.b().i0);
                    intent.putExtra("idComponent", this.b.getIdComponent());
                    intent.putExtra("text", this.b.getCustomText());
                    intent.putExtra("sizeText", (int) this.b.getTextSize());
                    intent.putExtra("checkVisible", ((ru.himik.nightscream.kascada.CustomComponents.e) this.b).m());
                    intent.putExtra("typeButtonMode", ((ru.himik.nightscream.kascada.CustomComponents.e) this.b).getMode());
                    intent.putExtra("autoResizeText", ((ru.himik.nightscream.kascada.CustomComponents.e) this.b).l());
                    PreferenceManager.getDefaultSharedPreferences(this.a).edit().putInt("colorText", this.b.getCurrentTextColor()).apply();
                    ((mbCanvas) this.a).startActivityForResult(intent, 1);
                    break;
                case R.id.dialog_set_address /* 2131296574 */:
                    h0.g(this.a, this.b);
                    break;
                case R.id.dialog_set_network_device /* 2131296577 */:
                    h0.h(this.a, this.b);
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class c0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        c0(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Intent intent;
            mbCanvas mbcanvas;
            int i2;
            int id = view.getId();
            if (id != R.id.dialog_preference) {
                if (id == R.id.dialog_set_address) {
                    intent = new Intent(this.a, (Class<?>) PrefActivityAddressConnection.class);
                    intent.putExtra("idComponent", this.b.getIdComponent());
                    intent.putExtra("addressPLC", this.b.getConnectionInfo().b());
                    intent.putExtra("addressRegister", this.b.getConnectionInfo().c());
                    mbcanvas = (mbCanvas) this.a;
                    i2 = 3;
                } else if (id != R.id.dialog_set_network_device) {
                    return;
                } else {
                    h0.h(this.a, this.b);
                }
                this.c.dismiss();
            }
            intent = new Intent(this.a, (Class<?>) PrefActivity.class);
            intent.putExtra("portraitMode", MyApplication.b().i0);
            intent.putExtra("idComponent", this.b.getIdComponent());
            intent.putExtra("EditGraphPeriodPref", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getSecondPeriod());
            intent.putExtra("EditGraphCountPointPref", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getCountPoint());
            intent.putExtra("typeGraph", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getType());
            intent.putExtra("nameSeries1", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getNameSeries1());
            intent.putExtra("nameSeries2", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getNameSeries2());
            intent.putExtra("nameSeries3", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getNameSeries3());
            intent.putExtra("nameSeries4", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getNameSeries4());
            intent.putExtra("countGraphChannel", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getCountGraphChannel());
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
            defaultSharedPreferences.edit().putInt("graphColorBackground", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getColorBackground_()).apply();
            defaultSharedPreferences.edit().putInt("graphColorLabelsXY", ((ru.himik.nightscream.kascada.CustomComponents.o) this.b).getColorLabelsXY()).apply();
            mbcanvas = (mbCanvas) this.a;
            i2 = 1;
            mbcanvas.startActivityForResult(intent, i2);
            this.c.dismiss();
        }
    }

    static class c1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        c1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("text", this.b.getCustomText());
                intent.putExtra("sizeText", (int) this.b.getTextSize());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
                defaultSharedPreferences.edit().putInt("colorText", this.b.getCurrentTextColor()).apply();
                defaultSharedPreferences.edit().putInt("colorBackground", ((ru.himik.nightscream.kascada.CustomComponents.u) this.b).getBackgroundColorReg()).apply();
                intent.putExtra("digit", ((ru.himik.nightscream.kascada.CustomComponents.u) this.b).getDigit());
                try {
                    intent.putExtra("divisor", ((ru.himik.nightscream.kascada.CustomComponents.u) this.b).getDivisor());
                } catch (Exception unused) {
                }
                intent.putExtra("type", ((ru.himik.nightscream.kascada.CustomComponents.u) this.b).getType());
                intent.putExtra("fontChange", ((ru.himik.nightscream.kascada.CustomComponents.u) this.b).m());
                intent.putExtra("enableFrameRegister", ((ru.himik.nightscream.kascada.CustomComponents.u) this.b).l());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class c2 implements DialogInterface.OnDismissListener {
        final /* synthetic */ boolean a;
        final /* synthetic */ EditText[] b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText[] f9326d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ Spinner[] f9327e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ Context f9328f;

        c2(boolean z, EditText[] editTextArr, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText[] editTextArr2, Spinner[] spinnerArr, Context context) {
            this.a = z;
            this.b = editTextArr;
            this.c = zVar;
            this.f9326d = editTextArr2;
            this.f9327e = spinnerArr;
            this.f9328f = context;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            ru.himik.nightscream.kascada.CustomComponents.b bVar;
            try {
                if (this.a) {
                    byte bByteValue = Byte.valueOf(this.b[0].getText().toString()).byteValue();
                    if (bByteValue >= 0 && bByteValue <= 15) {
                        ((ru.himik.nightscream.kascada.CustomComponents.l) this.c).f8842f.t(bByteValue);
                    }
                    ((ru.himik.nightscream.kascada.CustomComponents.l) this.c).f8842f.v(Integer.valueOf(this.f9326d[0].getText().toString()).intValue());
                    int selectedItemPosition = this.f9327e[0].getSelectedItemPosition();
                    byte b = 1;
                    if (selectedItemPosition == 0) {
                        bVar = ((ru.himik.nightscream.kascada.CustomComponents.l) this.c).f8842f;
                    } else if (selectedItemPosition == 1) {
                        bVar = ((ru.himik.nightscream.kascada.CustomComponents.l) this.c).f8842f;
                        b = 2;
                    }
                    bVar.L(b);
                } else {
                    ((ru.himik.nightscream.kascada.CustomComponents.l) this.c).f8843g.L((byte) 15);
                    byte bByteValue2 = Byte.valueOf(this.b[0].getText().toString()).byteValue();
                    if (bByteValue2 >= 0 && bByteValue2 <= 15) {
                        ((ru.himik.nightscream.kascada.CustomComponents.l) this.c).f8843g.t(Byte.valueOf(this.b[0].getText().toString()).byteValue());
                    }
                    ((ru.himik.nightscream.kascada.CustomComponents.l) this.c).f8843g.v(Integer.valueOf(this.f9326d[0].getText().toString()).intValue());
                }
            } catch (Exception unused) {
            }
            h0.l(this.f9328f, this.c);
        }
    }

    static class d implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        d(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("autoResizeText", ((CustomDynText) this.b).t());
                intent.putExtra("enableFrameDynText", ((CustomDynText) this.b).u());
                JSONObject jSONObject = new JSONObject();
                try {
                    jSONObject.put("sizeText", (int) this.b.getTextSize());
                    jSONObject.put("text0", ((CustomDynText) this.b).q(0));
                    jSONObject.put("text1", ((CustomDynText) this.b).q(1));
                    jSONObject.put("text2", ((CustomDynText) this.b).q(2));
                    jSONObject.put("text3", ((CustomDynText) this.b).q(3));
                    jSONObject.put("text4", ((CustomDynText) this.b).q(4));
                    jSONObject.put("text5", ((CustomDynText) this.b).q(5));
                    jSONObject.put("text6", ((CustomDynText) this.b).q(6));
                    jSONObject.put("text7", ((CustomDynText) this.b).q(7));
                    jSONObject.put("text8", ((CustomDynText) this.b).q(8));
                    jSONObject.put("text9", ((CustomDynText) this.b).q(9));
                    jSONObject.put("text10", ((CustomDynText) this.b).q(10));
                    jSONObject.put("text11", ((CustomDynText) this.b).q(11));
                    jSONObject.put("text12", ((CustomDynText) this.b).q(12));
                    jSONObject.put("text13", ((CustomDynText) this.b).q(13));
                    jSONObject.put("text14", ((CustomDynText) this.b).q(14));
                    jSONObject.put("text15", ((CustomDynText) this.b).q(15));
                    jSONObject.put("colorBackground0", ((CustomDynText) this.b).n(0));
                    jSONObject.put("colorBackground1", ((CustomDynText) this.b).n(1));
                    jSONObject.put("colorBackground2", ((CustomDynText) this.b).n(2));
                    jSONObject.put("colorBackground3", ((CustomDynText) this.b).n(3));
                    jSONObject.put("colorBackground4", ((CustomDynText) this.b).n(4));
                    jSONObject.put("colorBackground5", ((CustomDynText) this.b).n(5));
                    jSONObject.put("colorBackground6", ((CustomDynText) this.b).n(6));
                    jSONObject.put("colorBackground7", ((CustomDynText) this.b).n(7));
                    jSONObject.put("colorBackground8", ((CustomDynText) this.b).n(8));
                    jSONObject.put("colorBackground9", ((CustomDynText) this.b).n(9));
                    jSONObject.put("colorBackground10", ((CustomDynText) this.b).n(10));
                    jSONObject.put("colorBackground11", ((CustomDynText) this.b).n(11));
                    jSONObject.put("colorBackground12", ((CustomDynText) this.b).n(12));
                    jSONObject.put("colorBackground13", ((CustomDynText) this.b).n(13));
                    jSONObject.put("colorBackground14", ((CustomDynText) this.b).n(14));
                    jSONObject.put("colorBackground15", ((CustomDynText) this.b).n(15));
                    jSONObject.put("typeCommandDynText", ((CustomDynText) this.b).getTypeCommand());
                } catch (JSONException unused) {
                    Context context = this.a;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_dyn_text_error_pref), 0).show();
                }
                intent.putExtra("params", jSONObject.toString());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
                defaultSharedPreferences.edit().putInt("colorText", ((CustomDynText) this.b).getColorText()).apply();
                defaultSharedPreferences.edit().putInt("colorBackground0", ((CustomDynText) this.b).n(0)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground1", ((CustomDynText) this.b).n(1)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground2", ((CustomDynText) this.b).n(2)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground3", ((CustomDynText) this.b).n(3)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground4", ((CustomDynText) this.b).n(4)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground5", ((CustomDynText) this.b).n(5)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground6", ((CustomDynText) this.b).n(6)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground7", ((CustomDynText) this.b).n(7)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground8", ((CustomDynText) this.b).n(8)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground9", ((CustomDynText) this.b).n(9)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground10", ((CustomDynText) this.b).n(10)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground11", ((CustomDynText) this.b).n(11)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground12", ((CustomDynText) this.b).n(12)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground13", ((CustomDynText) this.b).n(13)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground14", ((CustomDynText) this.b).n(14)).apply();
                defaultSharedPreferences.edit().putInt("colorBackground15", ((CustomDynText) this.b).n(15)).apply();
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class d0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        d0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class d1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        d1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class d2 implements DialogInterface.OnClickListener {
        d2() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.dismiss();
        }
    }

    static class e implements View.OnClickListener {
        final /* synthetic */ EditText a;

        e(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class e0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        e0(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class e1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        e1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class e2 implements DialogInterface.OnShowListener {
        final /* synthetic */ View a;
        final /* synthetic */ Spinner[] b;
        final /* synthetic */ EditText[] c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText[] f9329d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ EditText[] f9330e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ EditText[] f9331f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final /* synthetic */ EditText[] f9332g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z f9333h;

        class a implements View.OnClickListener {
            a() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                e2.this.f9330e[0].selectAll();
            }
        }

        class b implements View.OnClickListener {
            b() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                e2.this.f9331f[0].selectAll();
            }
        }

        class c implements View.OnClickListener {
            c() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                e2.this.f9332g[0].selectAll();
            }
        }

        class d implements View.OnClickListener {
            d() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                e2.this.c[0].selectAll();
            }
        }

        class e implements View.OnClickListener {
            e() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                e2.this.f9329d[0].selectAll();
            }
        }

        e2(View view, Spinner[] spinnerArr, EditText[] editTextArr, EditText[] editTextArr2, EditText[] editTextArr3, EditText[] editTextArr4, EditText[] editTextArr5, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = view;
            this.b = spinnerArr;
            this.c = editTextArr;
            this.f9329d = editTextArr2;
            this.f9330e = editTextArr3;
            this.f9331f = editTextArr4;
            this.f9332g = editTextArr5;
            this.f9333h = zVar;
        }

        @Override // android.content.DialogInterface.OnShowListener
        public void onShow(DialogInterface dialogInterface) {
            LinearLayout linearLayout = (LinearLayout) this.a.findViewById(R.id.layoutChooseType);
            LinearLayout linearLayout2 = (LinearLayout) this.a.findViewById(R.id.layoutSetBit);
            LinearLayout linearLayout3 = (LinearLayout) this.a.findViewById(R.id.layoutSetScreen);
            LinearLayout linearLayout4 = (LinearLayout) this.a.findViewById(R.id.layoutSetRegisterConstant);
            LinearLayout linearLayout5 = (LinearLayout) this.a.findViewById(R.id.layoutSetConstant);
            this.b[0] = (Spinner) this.a.findViewById(R.id.spinnerChooseType);
            this.c[0] = (EditText) this.a.findViewById(R.id.editRegister);
            this.f9329d[0] = (EditText) this.a.findViewById(R.id.editBit);
            this.f9330e[0] = (EditText) this.a.findViewById(R.id.editChangeScreen);
            this.f9331f[0] = (EditText) this.a.findViewById(R.id.editConstantRegister);
            this.f9332g[0] = (EditText) this.a.findViewById(R.id.editConstant);
            int mode = ((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).getMode();
            if (mode == 0) {
                linearLayout.setVisibility(8);
                linearLayout2.setVisibility(0);
                linearLayout3.setVisibility(8);
                linearLayout4.setVisibility(8);
                linearLayout5.setVisibility(8);
            } else if (mode == 1) {
                linearLayout.setVisibility(8);
                linearLayout2.setVisibility(8);
                linearLayout3.setVisibility(0);
                linearLayout4.setVisibility(8);
                linearLayout5.setVisibility(8);
            } else if (mode != 2) {
                ((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).setMode(0);
                linearLayout.setVisibility(8);
                linearLayout2.setVisibility(0);
                linearLayout3.setVisibility(8);
                linearLayout4.setVisibility(8);
                linearLayout5.setVisibility(8);
            } else {
                linearLayout.setVisibility(0);
                linearLayout2.setVisibility(8);
                linearLayout3.setVisibility(8);
                linearLayout4.setVisibility(0);
                linearLayout5.setVisibility(0);
            }
            this.b[0].setSelection(((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).getTypeRegister());
            this.c[0].setText(((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).f8769i.c() + "");
            this.f9329d[0].setText(((int) ((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).f8769i.a()) + "");
            this.f9330e[0].setText(((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).getChangeScreen() + "");
            this.f9331f[0].setText(((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).getConstantRegister() + "");
            this.f9332g[0].setText(((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).getConstant() + "");
            int mode2 = ((ru.himik.nightscream.kascada.CustomComponents.e) this.f9333h).getMode();
            if (mode2 != 0) {
                if (mode2 == 1) {
                    linearLayout.setVisibility(8);
                    linearLayout2.setVisibility(8);
                    linearLayout3.setVisibility(0);
                } else if (mode2 == 2) {
                    linearLayout.setVisibility(0);
                    linearLayout2.setVisibility(8);
                    linearLayout3.setVisibility(8);
                    linearLayout4.setVisibility(0);
                    linearLayout5.setVisibility(0);
                }
                this.f9330e[0].setOnClickListener(new a());
                this.f9331f[0].setOnClickListener(new b());
                this.f9332g[0].setOnClickListener(new c());
                this.c[0].setOnClickListener(new d());
                this.f9329d[0].setOnClickListener(new e());
            }
            linearLayout.setVisibility(8);
            linearLayout2.setVisibility(0);
            linearLayout3.setVisibility(8);
            linearLayout4.setVisibility(8);
            linearLayout5.setVisibility(8);
            this.f9330e[0].setOnClickListener(new a());
            this.f9331f[0].setOnClickListener(new b());
            this.f9332g[0].setOnClickListener(new c());
            this.c[0].setOnClickListener(new d());
            this.f9329d[0].setOnClickListener(new e());
        }
    }

    static class f implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        f(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class f0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        f0(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            String str;
            String string;
            int id = view.getId();
            if (id != R.id.dialog_set_network_device) {
                switch (id) {
                    case R.id.dialog_export_csv /* 2131296570 */:
                        ((mbCanvas) this.a).B();
                        break;
                    case R.id.dialog_graph /* 2131296571 */:
                        ((mbCanvas) this.a).p0();
                        break;
                    case R.id.dialog_preference /* 2131296572 */:
                        Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                        intent.putExtra("portraitMode", MyApplication.b().i0);
                        intent.putExtra("idComponent", this.b.getIdComponent());
                        intent.putExtra("fileName", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getFileName());
                        intent.putExtra("typeRecord", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getTypeRecord());
                        intent.putExtra("countChannel", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getCountChannel());
                        intent.putExtra("registerArchive", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getRegisterArchive());
                        intent.putExtra("ArchiveEmailLogin_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getEmailLogin());
                        intent.putExtra("ArchiveEmailPassword_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getEmailPassword());
                        intent.putExtra("ArchiveEmailTo_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getEmailTo());
                        intent.putExtra("ArchiveRegisterSendMail_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getRegSendEmail());
                        intent.putExtra("ArchiveBitSendMail_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getBitSendEmail());
                        intent.putExtra("ArchiveRegisterReset_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getRegResetArchive());
                        intent.putExtra("ArchiveBitReset_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getBitResetArchive());
                        intent.putExtra("ArchiveIsReset_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).i());
                        intent.putExtra("optionChannel", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).h());
                        intent.putExtra("typeRecordOptionChannel", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getTypeRecordOptionChannel());
                        intent.putExtra("regArchiveOptionalChannel", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getRegArchiveOptionalChannel());
                        intent.putExtra("countArchiveOptionalChannelASCII", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getCountArchiveOptionalChannelASCII());
                        intent.putExtra("isSendToCloudArchive", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).j());
                        intent.putExtra("ArchiveRegisterSendToCloudArchive_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getRegSendToCloudArchive());
                        intent.putExtra("ArchiveBitSendToCloudArchive_Val", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).getBitSendToCloudArchive());
                        JSONObject jSONObject = new JSONObject();
                        try {
                            jSONObject.put("countActiveDevice", MyApplication.b().f9042j);
                            for (int i2 = 0; i2 < MyApplication.b().E.size() + 1; i2++) {
                                if (i2 == 0) {
                                    str = "dev" + i2 + "Name";
                                    string = this.a.getString(R.string.system);
                                } else {
                                    str = "dev" + i2 + "Name";
                                    string = i2 + "." + MyApplication.b().E.get(i2 - 1).c();
                                }
                                jSONObject.put(str, string);
                            }
                        } catch (JSONException unused) {
                            Toast.makeText(this.a, R.string.error_create_list_devices_for_archive, 1).show();
                        }
                        intent.putExtra("connectionDevices", jSONObject.toString());
                        intent.putExtra("selectPositionDevTriggerDataArchive", ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).f8754i.l() == 100 ? ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).f8754i.l() : ((ru.himik.nightscream.kascada.CustomComponents.d) this.b).f8754i.l() + 1);
                        ((mbCanvas) this.a).startActivityForResult(intent, 1);
                        break;
                    default:
                        return;
                }
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class f1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        f1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("pathSound_0", ((CustomSound) this.b).a(0));
                intent.putExtra("pathSound_1", ((CustomSound) this.b).a(1));
                intent.putExtra("pathSound_2", ((CustomSound) this.b).a(2));
                intent.putExtra("pathSound_3", ((CustomSound) this.b).a(3));
                intent.putExtra("pathSound_4", ((CustomSound) this.b).a(4));
                intent.putExtra("pathSound_5", ((CustomSound) this.b).a(5));
                intent.putExtra("pathSound_6", ((CustomSound) this.b).a(6));
                intent.putExtra("pathSound_7", ((CustomSound) this.b).a(7));
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class f2 implements DialogInterface.OnDismissListener {
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z a;
        final /* synthetic */ Spinner[] b;
        final /* synthetic */ EditText[] c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText[] f9334d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ EditText[] f9335e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ EditText[] f9336f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final /* synthetic */ EditText[] f9337g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        final /* synthetic */ Context f9338h;

        f2(ru.himik.nightscream.kascada.CustomComponents.z zVar, Spinner[] spinnerArr, EditText[] editTextArr, EditText[] editTextArr2, EditText[] editTextArr3, EditText[] editTextArr4, EditText[] editTextArr5, Context context) {
            this.a = zVar;
            this.b = spinnerArr;
            this.c = editTextArr;
            this.f9334d = editTextArr2;
            this.f9335e = editTextArr3;
            this.f9336f = editTextArr4;
            this.f9337g = editTextArr5;
            this.f9338h = context;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            ru.himik.nightscream.kascada.CustomComponents.z zVar;
            try {
                if (((ru.himik.nightscream.kascada.CustomComponents.e) this.a).getMode() == 1) {
                    ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).f8769i.E(100);
                }
                ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).setTypeRegister(this.b[0].getSelectedItemPosition());
                ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).f8769i.v(Integer.parseInt(this.c[0].getText().toString()));
                if (Byte.valueOf(this.f9334d[0].getText().toString()).byteValue() >= 0 && Byte.valueOf(this.f9334d[0].getText().toString()).byteValue() <= 15) {
                    ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).f8769i.t(Byte.valueOf(this.f9334d[0].getText().toString()).byteValue());
                }
                ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).setChangeScreen(Integer.parseInt(this.f9335e[0].getText().toString()));
                ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).setConstantRegister(Integer.parseInt(this.f9336f[0].getText().toString()));
                int selectedItemPosition = this.b[0].getSelectedItemPosition();
                if (selectedItemPosition == 0) {
                    try {
                        int i2 = Integer.parseInt(this.f9337g[0].getText().toString());
                        if (i2 < -32768 || i2 > 65535) {
                            Context context = this.f9338h;
                            Toast.makeText(context, context.getResources().getString(R.string.dialog_button_error_input), 1).show();
                        } else {
                            ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).setConstant(i2 + "");
                        }
                    } catch (Exception unused) {
                        Context context2 = this.f9338h;
                        Toast.makeText(context2, context2.getResources().getString(R.string.dialog_button_error_input), 1).show();
                        zVar = this.a;
                        ((ru.himik.nightscream.kascada.CustomComponents.e) zVar).setConstant("0");
                    }
                } else if (selectedItemPosition == 1) {
                    try {
                        float f2 = Float.parseFloat(this.f9337g[0].getText().toString());
                        ((ru.himik.nightscream.kascada.CustomComponents.e) this.a).setConstant(f2 + "");
                    } catch (Exception unused2) {
                        Context context3 = this.f9338h;
                        Toast.makeText(context3, context3.getResources().getString(R.string.dialog_button_error_input), 1).show();
                        zVar = this.a;
                        ((ru.himik.nightscream.kascada.CustomComponents.e) zVar).setConstant("0");
                    }
                }
            } catch (Exception unused3) {
            }
            h0.l(this.f9338h, this.a);
        }
    }

    static class g implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        g(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("text", this.b.getCustomText());
                intent.putExtra("sizeText", (int) this.b.getTextSize());
                intent.putExtra("fontChange", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).l());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
                defaultSharedPreferences.edit().putInt("colorText", this.b.getCurrentTextColor()).apply();
                defaultSharedPreferences.edit().putInt("colorBackground", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).getBackgroundColorEditNumber()).apply();
                intent.putExtra("min", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).getMinValue());
                intent.putExtra("max", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).getMaxValue());
                intent.putExtra("editPassword", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).getPassword());
                intent.putExtra("type", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).getType());
                intent.putExtra("typeInt", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).getTypeInt());
                intent.putExtra("countNumAfterPointEditNumber", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).getCountNumAfterPointEditNumber() - 1);
                intent.putExtra("enableFrameEditNumber", ((ru.himik.nightscream.kascada.CustomComponents.i) this.b).k());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class g0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        g0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class g1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        g1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class g2 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ AlertDialog b;

        g2(Context context, AlertDialog alertDialog) {
            this.a = context;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.set_color_on_background /* 2131297022 */:
                    ((mbCanvas) this.a).j0();
                    break;
                case R.id.set_image_on_background /* 2131297023 */:
                    ((mbCanvas) this.a).k0();
                    break;
                default:
                    return;
            }
            this.b.dismiss();
        }
    }

    static class h implements View.OnClickListener {
        final /* synthetic */ EditText a;

        h(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.r.h0$h0, reason: collision with other inner class name */
    static class ViewOnClickListenerC0306h0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        ViewOnClickListenerC0306h0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class h1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        h1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class h2 implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z a;
        final /* synthetic */ Context b;
        final /* synthetic */ AlertDialog c;

        h2(ru.himik.nightscream.kascada.CustomComponents.z zVar, Context context, AlertDialog alertDialog) {
            this.a = zVar;
            this.b = context;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.CustomComponents.b connectionInfo;
            int i2;
            switch (view.getId()) {
                case R.id.d1 /* 2131296520 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 0;
                    break;
                case R.id.d10 /* 2131296521 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 9;
                    break;
                case R.id.d11 /* 2131296523 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 10;
                    break;
                case R.id.d12 /* 2131296525 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 11;
                    break;
                case R.id.d13 /* 2131296527 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 12;
                    break;
                case R.id.d14 /* 2131296529 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 13;
                    break;
                case R.id.d15 /* 2131296531 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 14;
                    break;
                case R.id.d16 /* 2131296533 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 15;
                    break;
                case R.id.d2 /* 2131296536 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 1;
                    break;
                case R.id.d3 /* 2131296538 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 2;
                    break;
                case R.id.d4 /* 2131296540 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 3;
                    break;
                case R.id.d5 /* 2131296542 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 4;
                    break;
                case R.id.d6 /* 2131296544 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 5;
                    break;
                case R.id.d7 /* 2131296546 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 6;
                    break;
                case R.id.d8 /* 2131296548 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 7;
                    break;
                case R.id.d9 /* 2131296550 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 8;
                    break;
                case R.id.sys /* 2131297074 */:
                    connectionInfo = this.a.getConnectionInfo();
                    i2 = 100;
                    break;
                default:
                    return;
            }
            connectionInfo.E(i2);
            h0.l(this.b, this.a);
            this.c.dismiss();
        }
    }

    static class i implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        i(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class i0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        i0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class i1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        i1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            String str;
            String string;
            switch (view.getId()) {
                case R.id.dialog_preference /* 2131296572 */:
                    Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                    intent.putExtra("portraitMode", MyApplication.b().i0);
                    intent.putExtra("idComponent", this.b.getIdComponent());
                    intent.putExtra("countBit", ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f.f());
                    intent.putExtra("mode", ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).getMode());
                    intent.putExtra("regMode", ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).getRegMode());
                    intent.putExtra("bitMode", ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).getBitMode());
                    JSONObject jSONObject = new JSONObject();
                    try {
                        jSONObject.put("countActiveDevice", MyApplication.b().f9042j);
                        for (int i2 = 0; i2 < MyApplication.b().E.size() + 1; i2++) {
                            if (i2 == 0) {
                                str = "dev" + i2 + "Name";
                                string = this.a.getString(R.string.system);
                            } else {
                                str = "dev" + i2 + "Name";
                                string = i2 + "." + MyApplication.b().E.get(i2 - 1).c();
                            }
                            jSONObject.put(str, string);
                        }
                    } catch (JSONException unused) {
                        Context context = this.a;
                        Toast.makeText(context, context.getResources().getString(R.string.dialog_gateway_error), 1).show();
                    }
                    intent.putExtra("connectionDevices", jSONObject.toString());
                    intent.putExtra("selectPositionDevTrigger", ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8844h.l() == 100 ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8844h.l() : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8844h.l() + 1);
                    ((mbCanvas) this.a).startActivityForResult(intent, 1);
                    break;
                case R.id.dialog_resize /* 2131296573 */:
                case R.id.dialog_set_address /* 2131296574 */:
                case R.id.dialog_set_network_device /* 2131296577 */:
                default:
                    return;
                case R.id.dialog_set_address_receive /* 2131296575 */:
                    ru.himik.nightscream.kascada.CustomComponents.z zVar = this.b;
                    ((ru.himik.nightscream.kascada.CustomComponents.l) zVar).f8846j = false;
                    h0.m(this.a, zVar, false);
                    break;
                case R.id.dialog_set_address_source /* 2131296576 */:
                    ru.himik.nightscream.kascada.CustomComponents.z zVar2 = this.b;
                    ((ru.himik.nightscream.kascada.CustomComponents.l) zVar2).f8846j = false;
                    h0.m(this.a, zVar2, true);
                    break;
                case R.id.dialog_set_network_receive /* 2131296578 */:
                    ru.himik.nightscream.kascada.CustomComponents.z zVar3 = this.b;
                    ((ru.himik.nightscream.kascada.CustomComponents.l) zVar3).f8846j = false;
                    h0.j(this.a, zVar3, false);
                    break;
                case R.id.dialog_set_network_source /* 2131296579 */:
                    ru.himik.nightscream.kascada.CustomComponents.z zVar4 = this.b;
                    ((ru.himik.nightscream.kascada.CustomComponents.l) zVar4).f8846j = true;
                    h0.j(this.a, zVar4, true);
                    break;
            }
            this.c.dismiss();
        }
    }

    static class i2 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        i2(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_change_image) {
                h0.o(this.a, this.b);
            } else if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("typeRequest", (int) ((ru.himik.nightscream.kascada.CustomComponents.q) this.b).getTypeRequest());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class j implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        j(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_set_network_device) {
                h0.h(this.a, this.b);
            } else {
                if (id != R.id.dialog_sound_alarm) {
                    return;
                }
                Intent intent = new Intent(this.a, (Class<?>) PrefActivitySelectAlarmSound.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("POSITION", ((ru.himik.nightscream.kascada.CustomComponents.c) this.b).getPosSound());
                ((mbCanvas) this.a).startActivityForResult(intent, 7);
            }
            this.c.dismiss();
        }
    }

    static class j0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9339d;

        j0(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9339d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9339d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class j1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z a;
        final /* synthetic */ EditText b;

        j1(ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText) {
            this.a = zVar;
            this.b = editText;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            ((ru.himik.nightscream.kascada.CustomComponents.f) this.a).setRtsp(this.b.getText().toString());
        }
    }

    static class j2 implements View.OnClickListener {
        final /* synthetic */ boolean a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ Context c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9340d;

        j2(boolean z, ru.himik.nightscream.kascada.CustomComponents.z zVar, Context context, AlertDialog alertDialog) {
            this.a = z;
            this.b = zVar;
            this.c = context;
            this.f9340d = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int i2;
            ru.himik.nightscream.kascada.CustomComponents.b bVar;
            switch (view.getId()) {
                case R.id.d1 /* 2131296520 */:
                    i2 = 0;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d10 /* 2131296521 */:
                    i2 = 9;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d11 /* 2131296523 */:
                    i2 = 10;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d12 /* 2131296525 */:
                    i2 = 11;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d13 /* 2131296527 */:
                    i2 = 12;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d14 /* 2131296529 */:
                    i2 = 13;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d15 /* 2131296531 */:
                    i2 = 14;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d16 /* 2131296533 */:
                    i2 = 15;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d2 /* 2131296536 */:
                    i2 = 1;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d3 /* 2131296538 */:
                    i2 = 2;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d4 /* 2131296540 */:
                    i2 = 3;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d5 /* 2131296542 */:
                    i2 = 4;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d6 /* 2131296544 */:
                    i2 = 5;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d7 /* 2131296546 */:
                    i2 = 6;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d8 /* 2131296548 */:
                    i2 = 7;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.d9 /* 2131296550 */:
                    i2 = 8;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                case R.id.sys /* 2131297074 */:
                    i2 = 100;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8833h : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g;
                    break;
                default:
                    return;
            }
            bVar.E(i2);
            h0.l(this.c, this.b);
            this.f9340d.dismiss();
        }
    }

    static class k implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        k(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_change_image) {
                FragmentManager fragmentManager = ((mbCanvas) this.a).getFragmentManager();
                ru.himik.nightscream.kascada.Preference.y0.b bVar = new ru.himik.nightscream.kascada.Preference.y0.b();
                bVar.b(MyApplication.b().f9040h, MyApplication.b().f9041i);
                bVar.a((ru.himik.nightscream.kascada.CustomComponents.y) this.b);
                bVar.show(fragmentManager, "");
            } else if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("checkVisible", ((ru.himik.nightscream.kascada.CustomComponents.y) this.b).d());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class k0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        k0(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("pathGif", ((ru.himik.nightscream.kascada.CustomComponents.n) this.b).getPathGif());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class k1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        k1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("gaugeMax", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getMaxGauge());
                intent.putExtra("gaugeMin", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getMinGauge());
                intent.putExtra("countTextScale", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getCountTextScale());
                intent.putExtra("sizeText", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getSizeText());
                intent.putExtra("percentLowScale", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getPercentLowScale());
                intent.putExtra("percentMediumScale", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getPercentMediumScale());
                intent.putExtra("hideBackground", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).S());
                intent.putExtra("gaugeIndicatorName", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getIndicatorName());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
                defaultSharedPreferences.edit().putInt("gauge_colorTextValue", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getColorTextValue()).apply();
                defaultSharedPreferences.edit().putInt("gauge_colorTextScale", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getColorTextScale()).apply();
                defaultSharedPreferences.edit().putInt("gauge_colorCenterCircle", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getColorCenterCircle()).apply();
                defaultSharedPreferences.edit().putInt("gauge_colorIndicator", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getColorIndicator()).apply();
                defaultSharedPreferences.edit().putInt("gauge_colorMark", ((ru.himik.nightscream.kascada.CustomComponents.m) this.b).getColorMark()).apply();
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class k2 implements View.OnClickListener {
        final /* synthetic */ boolean a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ Context c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9341d;

        k2(boolean z, ru.himik.nightscream.kascada.CustomComponents.z zVar, Context context, AlertDialog alertDialog) {
            this.a = z;
            this.b = zVar;
            this.c = context;
            this.f9341d = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.CustomComponents.b bVar;
            ru.himik.nightscream.kascada.CustomComponents.b bVar2;
            int i2 = 0;
            switch (view.getId()) {
                case R.id.d1 /* 2131296520 */:
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d10 /* 2131296521 */:
                    i2 = 9;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d11 /* 2131296523 */:
                    i2 = 10;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d12 /* 2131296525 */:
                    i2 = 11;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d13 /* 2131296527 */:
                    i2 = 12;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d14 /* 2131296529 */:
                    i2 = 13;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d15 /* 2131296531 */:
                    i2 = 14;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d16 /* 2131296533 */:
                    i2 = 15;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d2 /* 2131296536 */:
                    i2 = 1;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d3 /* 2131296538 */:
                    i2 = 2;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d4 /* 2131296540 */:
                    i2 = 3;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d5 /* 2131296542 */:
                    i2 = 4;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d6 /* 2131296544 */:
                    i2 = 5;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d7 /* 2131296546 */:
                    i2 = 6;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d8 /* 2131296548 */:
                    i2 = 7;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.d9 /* 2131296550 */:
                    i2 = 8;
                    bVar = !this.a ? ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g : ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    break;
                case R.id.sys /* 2131297074 */:
                    if (this.a) {
                        ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f.E(100);
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8842f;
                    } else {
                        ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g.E(100);
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.l) this.b).f8843g;
                    }
                    bVar2.t((byte) 0);
                    h0.l(this.c, this.b);
                    this.f9341d.dismiss();
                default:
                    return;
            }
            bVar.E(i2);
            h0.l(this.c, this.b);
            this.f9341d.dismiss();
        }
    }

    static class l implements View.OnClickListener {
        final /* synthetic */ EditText a;

        l(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class l0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        l0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class l1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        l1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class l2 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ View b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9342d;

        l2(Context context, View view, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = view;
            this.c = zVar;
            this.f9342d = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Context context;
            ImageView imageView;
            ru.himik.nightscream.kascada.CustomComponents.z zVar;
            boolean z;
            switch (view.getId()) {
                case R.id.imageOff /* 2131296703 */:
                    context = this.a;
                    imageView = (ImageView) this.b.findViewById(R.id.imageOff);
                    zVar = this.c;
                    z = false;
                    break;
                case R.id.imageOn /* 2131296704 */:
                    context = this.a;
                    imageView = (ImageView) this.b.findViewById(R.id.imageOn);
                    zVar = this.c;
                    z = true;
                    break;
                default:
                    return;
            }
            h0.k(context, imageView, zVar, z, this.f9342d);
        }
    }

    static class m implements View.OnClickListener {
        final /* synthetic */ EditText a;

        m(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class m0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        m0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class m1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        m1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class m2 implements DialogInterface.OnDismissListener {
        m2() {
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
        }
    }

    static class n implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9343d;

        n(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9343d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9343d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class n0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9344d;

        n0(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9344d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9344d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class n1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        n1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class n2 implements View.OnClickListener {
        final /* synthetic */ ImageView a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ boolean f9345d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9346e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9347f;

        n2(ImageView imageView, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, boolean z, AlertDialog alertDialog, AlertDialog alertDialog2) {
            this.a = imageView;
            this.b = context;
            this.c = zVar;
            this.f9345d = z;
            this.f9346e = alertDialog;
            this.f9347f = alertDialog2;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.CustomComponents.q qVar;
            boolean z;
            String str;
            switch (view.getId()) {
                case R.id.buttonChoosePath /* 2131296457 */:
                    ((mbCanvas) this.b).v(this.f9345d);
                    this.f9347f.dismiss();
                    this.f9346e.dismiss();
                case R.id.imageBlue /* 2131296701 */:
                    this.a.setImageBitmap(BitmapFactory.decodeResource(this.b.getResources(), R.drawable.lamp_blue));
                    qVar = (ru.himik.nightscream.kascada.CustomComponents.q) this.c;
                    z = this.f9345d;
                    str = "blue";
                    break;
                case R.id.imageGreen /* 2131296702 */:
                    this.a.setImageBitmap(BitmapFactory.decodeResource(this.b.getResources(), R.drawable.lamp_green));
                    qVar = (ru.himik.nightscream.kascada.CustomComponents.q) this.c;
                    z = this.f9345d;
                    str = "green";
                    break;
                case R.id.imageOff /* 2131296703 */:
                    this.a.setImageBitmap(BitmapFactory.decodeResource(this.b.getResources(), R.drawable.lamp_off));
                    qVar = (ru.himik.nightscream.kascada.CustomComponents.q) this.c;
                    z = this.f9345d;
                    str = "off";
                    break;
                case R.id.imageRed /* 2131296705 */:
                    this.a.setImageBitmap(BitmapFactory.decodeResource(this.b.getResources(), R.drawable.lamp_red));
                    qVar = (ru.himik.nightscream.kascada.CustomComponents.q) this.c;
                    z = this.f9345d;
                    str = "red";
                    break;
                case R.id.imageYellow /* 2131296718 */:
                    this.a.setImageBitmap(BitmapFactory.decodeResource(this.b.getResources(), R.drawable.lamp_yellow));
                    qVar = (ru.himik.nightscream.kascada.CustomComponents.q) this.c;
                    z = this.f9345d;
                    str = "yellow";
                    break;
                default:
                    return;
            }
            qVar.d(z, false, str);
            this.f9346e.dismiss();
        }
    }

    static class o implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        o(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("phone", ((ru.himik.nightscream.kascada.CustomComponents.w) this.b).getPhone());
                intent.putExtra("message", ((ru.himik.nightscream.kascada.CustomComponents.w) this.b).getMessage());
                intent.putExtra("option", ((ru.himik.nightscream.kascada.CustomComponents.w) this.b).b());
                intent.putExtra("optionRegister", ((ru.himik.nightscream.kascada.CustomComponents.w) this.b).getOptionRegister());
                intent.putExtra("optionCountRegister", ((ru.himik.nightscream.kascada.CustomComponents.w) this.b).getOptionCountRegister());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class o0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        o0(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("pathPic_0", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(0));
                intent.putExtra("pathPic_1", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(1));
                intent.putExtra("pathPic_2", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(2));
                intent.putExtra("pathPic_3", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(3));
                intent.putExtra("pathPic_4", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(4));
                intent.putExtra("pathPic_5", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(5));
                intent.putExtra("pathPic_6", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(6));
                intent.putExtra("pathPic_7", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(7));
                intent.putExtra("pathPic_8", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(8));
                intent.putExtra("pathPic_9", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(9));
                intent.putExtra("pathPic_10", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(10));
                intent.putExtra("pathPic_11", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(11));
                intent.putExtra("pathPic_12", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(12));
                intent.putExtra("pathPic_13", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(13));
                intent.putExtra("pathPic_14", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(14));
                intent.putExtra("pathPic_15", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).c(15));
                intent.putExtra("typeCommandDynPicture", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).getTypeCommand());
                intent.putExtra("editTouchX", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).getRegTouchX());
                intent.putExtra("editTouchY", ((ru.himik.nightscream.kascada.CustomComponents.h) this.b).getRegTouchY());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class o1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        o1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("title", ((ru.himik.nightscream.kascada.CustomComponents.t) this.b).getTitle());
                intent.putExtra("body", ((ru.himik.nightscream.kascada.CustomComponents.t) this.b).getBody());
                intent.putExtra("to", ((ru.himik.nightscream.kascada.CustomComponents.t) this.b).getTo());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class o2 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        o2(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class p implements View.OnClickListener {
        final /* synthetic */ EditText a;

        p(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class p0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        p0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class p1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        p1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class q implements View.OnClickListener {
        final /* synthetic */ EditText a;

        q(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class q0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        q0(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class q1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        q1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class r implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9348d;

        r(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9348d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9348d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class r0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9349d;

        r0(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9349d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9349d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class r1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9350d;

        r1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9350d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9350d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class s implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        s(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("showText", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).d());
                intent.putExtra("sizeText", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).getSizeText());
                intent.putExtra("showScale", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).c());
                intent.putExtra("max", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).getValueMax());
                intent.putExtra("min", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).getValueMin());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
                defaultSharedPreferences.edit().putInt("colorText", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).getColorText()).apply();
                defaultSharedPreferences.edit().putInt("colorProgress", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).getColorProgress()).apply();
                defaultSharedPreferences.edit().putInt("colorBackground", ((ru.himik.nightscream.kascada.CustomComponents.r) this.b).getColorBackground()).apply();
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class s0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        s0(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("smsRecPhone", ((ru.himik.nightscream.kascada.CustomComponents.x) this.b).getPhone());
                intent.putExtra(IMAPStore.ID_COMMAND, ((ru.himik.nightscream.kascada.CustomComponents.x) this.b).getCommand());
                intent.putExtra("strob", ((ru.himik.nightscream.kascada.CustomComponents.x) this.b).b());
                intent.putExtra("regStrob", ((ru.himik.nightscream.kascada.CustomComponents.x) this.b).getRegStrob());
                intent.putExtra("bitStrob", ((ru.himik.nightscream.kascada.CustomComponents.x) this.b).getBitStrob());
                intent.putExtra("listTypeCommandSmsReceive", ((ru.himik.nightscream.kascada.CustomComponents.x) this.b).getTypeCommand());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class s1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        s1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                JSONObject jSONObject = new JSONObject();
                try {
                    jSONObject.put("link0", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(0));
                    jSONObject.put("link1", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(1));
                    jSONObject.put("link2", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(2));
                    jSONObject.put("link3", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(3));
                    jSONObject.put("link4", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(4));
                    jSONObject.put("link5", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(5));
                    jSONObject.put("link6", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(6));
                    jSONObject.put("link7", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(7));
                    jSONObject.put("link8", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(8));
                    jSONObject.put("link9", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(9));
                    jSONObject.put("link10", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(10));
                    jSONObject.put("link11", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(11));
                    jSONObject.put("link12", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(12));
                    jSONObject.put("link13", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(13));
                    jSONObject.put("link14", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(14));
                    jSONObject.put("link15", ((ru.himik.nightscream.kascada.CustomComponents.b0) this.b).b(15));
                } catch (JSONException unused) {
                    Toast.makeText(this.a, "error web view", 0).show();
                }
                intent.putExtra("params", jSONObject.toString());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class t implements View.OnClickListener {
        final /* synthetic */ EditText a;

        t(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class t0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        t0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class t1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        t1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class u implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        u(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class u0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        u0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class u1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        u1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class v implements View.OnClickListener {
        final /* synthetic */ EditText a;

        v(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class v0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9351d;

        v0(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9351d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9351d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class v1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        v1(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("titleEmail", ((ru.himik.nightscream.kascada.CustomComponents.j) this.b).getTitle());
                intent.putExtra("bodyEmail", ((ru.himik.nightscream.kascada.CustomComponents.j) this.b).getBody());
                intent.putExtra("emailTo", ((ru.himik.nightscream.kascada.CustomComponents.j) this.b).getEmailTo());
                intent.putExtra("emailLogin", ((ru.himik.nightscream.kascada.CustomComponents.j) this.b).getEmailLogin());
                intent.putExtra("emailPassword", ((ru.himik.nightscream.kascada.CustomComponents.j) this.b).getEmailPassword());
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class w implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        w(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("gaugeMax", (int) ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getMaxSpeed());
                intent.putExtra("sizeText", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getLabelTextSize());
                intent.putExtra("showText", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).i());
                intent.putExtra("firstPoint", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getFirstColorPoint());
                intent.putExtra("secondPoint", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getSecondColorPoint());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
                defaultSharedPreferences.edit().putInt("gauge_outColor", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getOutColor()).apply();
                defaultSharedPreferences.edit().putInt("gauge_inColor", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getInColor()).apply();
                defaultSharedPreferences.edit().putInt("gauge_centerColor", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getCenterColor()).apply();
                defaultSharedPreferences.edit().putInt("gauge_textColor", ((ru.himik.nightscream.kascada.CustomComponents.g) this.b).getColorText()).apply();
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else if (id != R.id.dialog_set_network_device) {
                return;
            } else {
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class w0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        w0(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            String str;
            String string;
            switch (view.getId()) {
                case R.id.dialog_preference /* 2131296572 */:
                    Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                    intent.putExtra("portraitMode", MyApplication.b().i0);
                    intent.putExtra("idComponent", this.b.getIdComponent());
                    intent.putExtra("mode", ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).getMode());
                    intent.putExtra("regMode", ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).getRegMode());
                    intent.putExtra("bitMode", ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).getBitMode());
                    intent.putExtra("gatewayCountReg", ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8832g.g());
                    JSONObject jSONObject = new JSONObject();
                    try {
                        jSONObject.put("countActiveDevice", MyApplication.b().f9042j);
                        for (int i2 = 0; i2 < MyApplication.b().E.size() + 1; i2++) {
                            if (i2 == 0) {
                                str = "dev" + i2 + "Name";
                                string = this.a.getString(R.string.system);
                            } else {
                                str = "dev" + i2 + "Name";
                                string = i2 + "." + MyApplication.b().E.get(i2 - 1).c();
                            }
                            jSONObject.put(str, string);
                        }
                    } catch (JSONException unused) {
                        Context context = this.a;
                        Toast.makeText(context, context.getResources().getString(R.string.dialog_gateway_error), 1).show();
                    }
                    intent.putExtra("connectionDevices", jSONObject.toString());
                    intent.putExtra("selectPositionDevTrigger", ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8834i.l() == 100 ? ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8834i.l() : ((ru.himik.nightscream.kascada.CustomComponents.k) this.b).f8834i.l() + 1);
                    ((mbCanvas) this.a).startActivityForResult(intent, 1);
                    break;
                case R.id.dialog_set_network_receive /* 2131296578 */:
                    ru.himik.nightscream.kascada.CustomComponents.z zVar = this.b;
                    ((ru.himik.nightscream.kascada.CustomComponents.k) zVar).f8836k = false;
                    h0.i(this.a, zVar, false);
                    break;
                case R.id.dialog_set_network_source /* 2131296579 */:
                    ru.himik.nightscream.kascada.CustomComponents.z zVar2 = this.b;
                    ((ru.himik.nightscream.kascada.CustomComponents.k) zVar2).f8836k = true;
                    h0.i(this.a, zVar2, true);
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class w1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        w1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class x implements View.OnClickListener {
        final /* synthetic */ EditText a;

        x(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class x0 implements AdapterView.OnItemSelectedListener {
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z a;

        x0(ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = zVar;
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            if (i2 == 0) {
                ((ru.himik.nightscream.kascada.CustomComponents.k) this.a).setTypeRequestSource((byte) 3);
            }
            if (i2 == 1) {
                ((ru.himik.nightscream.kascada.CustomComponents.k) this.a).setTypeRequestSource((byte) 4);
            }
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    static class x1 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        x1(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class y implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        y(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class y0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        y0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class y1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        y1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    return;
                }
                Context context = this.b;
                Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static class z implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z b;
        final /* synthetic */ AlertDialog c;

        z(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = zVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id == R.id.dialog_preference) {
                Intent intent = new Intent(this.a, (Class<?>) PrefActivity.class);
                intent.putExtra("portraitMode", MyApplication.b().i0);
                intent.putExtra("idComponent", this.b.getIdComponent());
                intent.putExtra("seekMax", ((ru.himik.nightscream.kascada.CustomComponents.v) this.b).getMax());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.a);
                defaultSharedPreferences.edit().putInt("colorText", ((ru.himik.nightscream.kascada.CustomComponents.v) this.b).getColorText()).apply();
                defaultSharedPreferences.edit().putInt("colorProgress", ((ru.himik.nightscream.kascada.CustomComponents.v) this.b).getColorProgress()).apply();
                defaultSharedPreferences.edit().putInt("colorBackground", ((ru.himik.nightscream.kascada.CustomComponents.v) this.b).getColorBackground()).apply();
                ((mbCanvas) this.a).startActivityForResult(intent, 1);
            } else {
                if (id != R.id.dialog_set_network_device) {
                    if (id != R.id.dialog_turn) {
                        return;
                    }
                    ru.himik.nightscream.kascada.CustomComponents.z zVar = this.b;
                    ((ru.himik.nightscream.kascada.CustomComponents.v) zVar).k(!((ru.himik.nightscream.kascada.CustomComponents.v) zVar).g(), ((ru.himik.nightscream.kascada.CustomComponents.v) this.b).getWidth(), ((ru.himik.nightscream.kascada.CustomComponents.v) this.b).getHeight(), false);
                    ((ru.himik.nightscream.kascada.CustomComponents.v) this.b).invalidate();
                    return;
                }
                h0.h(this.a, this.b);
            }
            this.c.dismiss();
        }
    }

    static class z0 implements View.OnClickListener {
        final /* synthetic */ EditText a;

        z0(EditText editText) {
            this.a = editText;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.selectAll();
        }
    }

    static class z1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ Context b;
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.z c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9352d;

        z1(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, EditText editText2) {
            this.a = editText;
            this.b = context;
            this.c = zVar;
            this.f9352d = editText2;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            try {
                int i2 = Integer.parseInt(this.a.getText().toString());
                if (i2 >= 0 && i2 <= 65535) {
                    this.c.getConnectionInfo().v(i2);
                    int i3 = Integer.parseInt(this.f9352d.getText().toString());
                    if (i3 >= 0 && i3 <= 15) {
                        this.c.getConnectionInfo().t((byte) i3);
                        return;
                    }
                    Context context = this.b;
                    Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
                    return;
                }
                Context context2 = this.b;
                Toast.makeText(context2, context2.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            } catch (Exception unused) {
                Context context3 = this.b;
                Toast.makeText(context3, context3.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
            }
        }
    }

    static /* synthetic */ void a(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, AlertDialog alertDialog, View view) {
        int id = view.getId();
        if (id != R.id.dialog_preference) {
            if (id != R.id.dialog_set_network_device) {
                return;
            }
            zVar.getConnectionInfo().E(100);
            Toast.makeText(context, context.getResources().getString(R.string.voice_sys_reg_only), 1).show();
            return;
        }
        Intent intent = new Intent(context, (Class<?>) PrefActivity.class);
        intent.putExtra("portraitMode", MyApplication.b().i0);
        intent.putExtra("idComponent", zVar.getIdComponent());
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("textVoice0", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(0));
            jSONObject.put("textVoice1", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(1));
            jSONObject.put("textVoice2", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(2));
            jSONObject.put("textVoice3", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(3));
            jSONObject.put("textVoice4", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(4));
            jSONObject.put("textVoice5", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(5));
            jSONObject.put("textVoice6", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(6));
            jSONObject.put("textVoice7", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(7));
            jSONObject.put("textVoice8", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(8));
            jSONObject.put("textVoice9", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(9));
            jSONObject.put("textVoice10", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(10));
            jSONObject.put("textVoice11", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(11));
            jSONObject.put("textVoice12", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(12));
            jSONObject.put("textVoice13", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(13));
            jSONObject.put("textVoice14", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(14));
            jSONObject.put("textVoice15", ((ru.himik.nightscream.kascada.CustomComponents.a0) zVar).a(15));
        } catch (JSONException unused) {
            Toast.makeText(context, "error voice recognition", 0).show();
        }
        intent.putExtra("params", jSONObject.toString());
        ((mbCanvas) context).startActivityForResult(intent, 1);
        alertDialog.dismiss();
    }

    static /* synthetic */ void c(EditText editText, Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, DialogInterface dialogInterface) {
        try {
            int i3 = Integer.parseInt(editText.getText().toString());
            if (i3 >= 0 && i3 <= 65535) {
                zVar.getConnectionInfo().v(i3);
                return;
            }
            Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
        } catch (Exception unused) {
            Toast.makeText(context, context.getResources().getString(R.string.dialog_reg_bit_error_input), 0).show();
        }
    }

    static /* synthetic */ void d(Context context, AlertDialog alertDialog, View view) {
        ((mbCanvas) context).alignSelectView(view);
        alertDialog.dismiss();
    }

    public static void f(Context context) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_background, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        g2 g2Var = new g2(context, alertDialogCreate);
        viewInflate.findViewById(R.id.set_image_on_background).setOnClickListener(g2Var);
        viewInflate.findViewById(R.id.set_color_on_background).setOnClickListener(g2Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void g(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.button_dialog_type, (ViewGroup) null);
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(viewInflate);
        builder.setTitle(context.getResources().getString(R.string.dialog_button_pref));
        Spinner[] spinnerArr = new Spinner[1];
        EditText[] editTextArr = new EditText[1];
        EditText[] editTextArr2 = new EditText[1];
        EditText[] editTextArr3 = new EditText[1];
        EditText[] editTextArr4 = new EditText[1];
        EditText[] editTextArr5 = new EditText[1];
        builder.setPositiveButton(context.getResources().getString(R.string.dialog_accept), new d2());
        AlertDialog alertDialogCreate = builder.create();
        alertDialogCreate.setOnShowListener(new e2(viewInflate, spinnerArr, editTextArr, editTextArr2, editTextArr3, editTextArr4, editTextArr5, zVar));
        alertDialogCreate.setOnDismissListener(new f2(zVar, spinnerArr, editTextArr, editTextArr2, editTextArr3, editTextArr4, editTextArr5, context));
        alertDialogCreate.show();
    }

    static void h(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
        View viewFindViewById;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_choose_devices, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        alertDialogCreate.setTitle(context.getResources().getString(R.string.choose_device));
        h2 h2Var = new h2(zVar, context, alertDialogCreate);
        switch (MyApplication.b().f9042j) {
            case 1:
                viewInflate.findViewById(R.id.d2).setVisibility(8);
            case 2:
                viewInflate.findViewById(R.id.d3).setVisibility(8);
            case 3:
                viewInflate.findViewById(R.id.d4).setVisibility(8);
            case 4:
                viewInflate.findViewById(R.id.d5).setVisibility(8);
                viewInflate.findViewById(R.id.d6).setVisibility(8);
                viewInflate.findViewById(R.id.d7).setVisibility(8);
                viewInflate.findViewById(R.id.d8).setVisibility(8);
                viewInflate.findViewById(R.id.d9).setVisibility(8);
                viewInflate.findViewById(R.id.d10).setVisibility(8);
                viewInflate.findViewById(R.id.d11).setVisibility(8);
                viewInflate.findViewById(R.id.d12).setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 5:
                viewInflate.findViewById(R.id.d6).setVisibility(8);
            case 6:
                viewInflate.findViewById(R.id.d7).setVisibility(8);
            case 7:
                viewInflate.findViewById(R.id.d8).setVisibility(8);
            case 8:
                viewInflate.findViewById(R.id.d9).setVisibility(8);
            case 9:
                viewInflate.findViewById(R.id.d10).setVisibility(8);
            case 10:
                viewInflate.findViewById(R.id.d11).setVisibility(8);
                viewFindViewById = viewInflate.findViewById(R.id.d12);
                viewFindViewById.setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 11:
                viewInflate.findViewById(R.id.d12).setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewFindViewById = viewInflate.findViewById(R.id.d16);
                viewFindViewById.setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 12:
                viewInflate.findViewById(R.id.d13).setVisibility(8);
            case 13:
                viewInflate.findViewById(R.id.d14).setVisibility(8);
            case 14:
                viewInflate.findViewById(R.id.d15).setVisibility(8);
            case 15:
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
        }
        ((TextView) viewInflate.findViewById(R.id.d1Text)).setText(MyApplication.b().E.get(0).c());
        ((TextView) viewInflate.findViewById(R.id.d2Text)).setText(MyApplication.b().E.get(1).c());
        ((TextView) viewInflate.findViewById(R.id.d3Text)).setText(MyApplication.b().E.get(2).c());
        ((TextView) viewInflate.findViewById(R.id.d4Text)).setText(MyApplication.b().E.get(3).c());
        ((TextView) viewInflate.findViewById(R.id.d5Text)).setText(MyApplication.b().E.get(4).c());
        ((TextView) viewInflate.findViewById(R.id.d6Text)).setText(MyApplication.b().E.get(5).c());
        ((TextView) viewInflate.findViewById(R.id.d7Text)).setText(MyApplication.b().E.get(6).c());
        ((TextView) viewInflate.findViewById(R.id.d8Text)).setText(MyApplication.b().E.get(7).c());
        ((TextView) viewInflate.findViewById(R.id.d9Text)).setText(MyApplication.b().E.get(8).c());
        ((TextView) viewInflate.findViewById(R.id.d10Text)).setText(MyApplication.b().E.get(9).c());
        ((TextView) viewInflate.findViewById(R.id.d11Text)).setText(MyApplication.b().E.get(10).c());
        ((TextView) viewInflate.findViewById(R.id.d12Text)).setText(MyApplication.b().E.get(11).c());
        ((TextView) viewInflate.findViewById(R.id.d13Text)).setText(MyApplication.b().E.get(12).c());
        ((TextView) viewInflate.findViewById(R.id.d14Text)).setText(MyApplication.b().E.get(13).c());
        ((TextView) viewInflate.findViewById(R.id.d15Text)).setText(MyApplication.b().E.get(14).c());
        ((TextView) viewInflate.findViewById(R.id.d16Text)).setText(MyApplication.b().E.get(15).c());
        viewInflate.findViewById(R.id.sys).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d1).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d2).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d3).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d4).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d5).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d6).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d7).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d8).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d9).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d10).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d11).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d12).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d13).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d14).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d15).setOnClickListener(h2Var);
        viewInflate.findViewById(R.id.d16).setOnClickListener(h2Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void i(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, boolean z2) {
        View viewFindViewById;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_choose_devices, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        alertDialogCreate.setTitle(context.getResources().getString(R.string.choose_device));
        j2 j2Var = new j2(z2, zVar, context, alertDialogCreate);
        switch (MyApplication.b().f9042j) {
            case 1:
                viewInflate.findViewById(R.id.d2).setVisibility(8);
            case 2:
                viewInflate.findViewById(R.id.d3).setVisibility(8);
            case 3:
                viewInflate.findViewById(R.id.d4).setVisibility(8);
            case 4:
                viewInflate.findViewById(R.id.d5).setVisibility(8);
                viewInflate.findViewById(R.id.d6).setVisibility(8);
                viewInflate.findViewById(R.id.d7).setVisibility(8);
                viewInflate.findViewById(R.id.d8).setVisibility(8);
                viewInflate.findViewById(R.id.d9).setVisibility(8);
                viewInflate.findViewById(R.id.d10).setVisibility(8);
                viewInflate.findViewById(R.id.d11).setVisibility(8);
                viewInflate.findViewById(R.id.d12).setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 5:
                viewInflate.findViewById(R.id.d6).setVisibility(8);
            case 6:
                viewInflate.findViewById(R.id.d7).setVisibility(8);
            case 7:
                viewInflate.findViewById(R.id.d8).setVisibility(8);
            case 8:
                viewInflate.findViewById(R.id.d9).setVisibility(8);
            case 9:
                viewInflate.findViewById(R.id.d10).setVisibility(8);
            case 10:
                viewInflate.findViewById(R.id.d11).setVisibility(8);
                viewFindViewById = viewInflate.findViewById(R.id.d12);
                viewFindViewById.setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 11:
                viewInflate.findViewById(R.id.d12).setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewFindViewById = viewInflate.findViewById(R.id.d16);
                viewFindViewById.setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 12:
                viewInflate.findViewById(R.id.d13).setVisibility(8);
            case 13:
                viewInflate.findViewById(R.id.d14).setVisibility(8);
            case 14:
                viewInflate.findViewById(R.id.d15).setVisibility(8);
            case 15:
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
        }
        ((TextView) viewInflate.findViewById(R.id.d1Text)).setText(MyApplication.b().E.get(0).c());
        ((TextView) viewInflate.findViewById(R.id.d2Text)).setText(MyApplication.b().E.get(1).c());
        ((TextView) viewInflate.findViewById(R.id.d3Text)).setText(MyApplication.b().E.get(2).c());
        ((TextView) viewInflate.findViewById(R.id.d4Text)).setText(MyApplication.b().E.get(3).c());
        ((TextView) viewInflate.findViewById(R.id.d5Text)).setText(MyApplication.b().E.get(4).c());
        ((TextView) viewInflate.findViewById(R.id.d6Text)).setText(MyApplication.b().E.get(5).c());
        ((TextView) viewInflate.findViewById(R.id.d7Text)).setText(MyApplication.b().E.get(6).c());
        ((TextView) viewInflate.findViewById(R.id.d8Text)).setText(MyApplication.b().E.get(7).c());
        ((TextView) viewInflate.findViewById(R.id.d9Text)).setText(MyApplication.b().E.get(8).c());
        ((TextView) viewInflate.findViewById(R.id.d10Text)).setText(MyApplication.b().E.get(9).c());
        ((TextView) viewInflate.findViewById(R.id.d11Text)).setText(MyApplication.b().E.get(10).c());
        ((TextView) viewInflate.findViewById(R.id.d12Text)).setText(MyApplication.b().E.get(11).c());
        ((TextView) viewInflate.findViewById(R.id.d13Text)).setText(MyApplication.b().E.get(12).c());
        ((TextView) viewInflate.findViewById(R.id.d14Text)).setText(MyApplication.b().E.get(13).c());
        ((TextView) viewInflate.findViewById(R.id.d15Text)).setText(MyApplication.b().E.get(14).c());
        ((TextView) viewInflate.findViewById(R.id.d16Text)).setText(MyApplication.b().E.get(15).c());
        viewInflate.findViewById(R.id.sys).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d1).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d2).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d3).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d4).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d5).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d6).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d7).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d8).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d9).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d10).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d11).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d12).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d13).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d14).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d15).setOnClickListener(j2Var);
        viewInflate.findViewById(R.id.d16).setOnClickListener(j2Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void j(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, boolean z2) {
        View viewFindViewById;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_choose_devices, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        alertDialogCreate.setTitle(context.getResources().getString(R.string.choose_device));
        k2 k2Var = new k2(z2, zVar, context, alertDialogCreate);
        switch (MyApplication.b().f9042j) {
            case 1:
                viewInflate.findViewById(R.id.d2).setVisibility(8);
            case 2:
                viewInflate.findViewById(R.id.d3).setVisibility(8);
            case 3:
                viewInflate.findViewById(R.id.d4).setVisibility(8);
            case 4:
                viewInflate.findViewById(R.id.d5).setVisibility(8);
                viewInflate.findViewById(R.id.d6).setVisibility(8);
                viewInflate.findViewById(R.id.d7).setVisibility(8);
                viewInflate.findViewById(R.id.d8).setVisibility(8);
                viewInflate.findViewById(R.id.d9).setVisibility(8);
                viewInflate.findViewById(R.id.d10).setVisibility(8);
                viewInflate.findViewById(R.id.d11).setVisibility(8);
                viewInflate.findViewById(R.id.d12).setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 5:
                viewInflate.findViewById(R.id.d6).setVisibility(8);
            case 6:
                viewInflate.findViewById(R.id.d7).setVisibility(8);
            case 7:
                viewInflate.findViewById(R.id.d8).setVisibility(8);
            case 8:
                viewInflate.findViewById(R.id.d9).setVisibility(8);
            case 9:
                viewInflate.findViewById(R.id.d10).setVisibility(8);
            case 10:
                viewInflate.findViewById(R.id.d11).setVisibility(8);
                viewFindViewById = viewInflate.findViewById(R.id.d12);
                viewFindViewById.setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 11:
                viewInflate.findViewById(R.id.d12).setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewFindViewById = viewInflate.findViewById(R.id.d16);
                viewFindViewById.setVisibility(8);
                viewInflate.findViewById(R.id.d13).setVisibility(8);
                viewInflate.findViewById(R.id.d14).setVisibility(8);
                viewInflate.findViewById(R.id.d15).setVisibility(8);
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
            case 12:
                viewInflate.findViewById(R.id.d13).setVisibility(8);
            case 13:
                viewInflate.findViewById(R.id.d14).setVisibility(8);
            case 14:
                viewInflate.findViewById(R.id.d15).setVisibility(8);
            case 15:
                viewInflate.findViewById(R.id.d16).setVisibility(8);
                break;
        }
        ((TextView) viewInflate.findViewById(R.id.d1Text)).setText(MyApplication.b().E.get(0).c());
        ((TextView) viewInflate.findViewById(R.id.d2Text)).setText(MyApplication.b().E.get(1).c());
        ((TextView) viewInflate.findViewById(R.id.d3Text)).setText(MyApplication.b().E.get(2).c());
        ((TextView) viewInflate.findViewById(R.id.d4Text)).setText(MyApplication.b().E.get(3).c());
        ((TextView) viewInflate.findViewById(R.id.d5Text)).setText(MyApplication.b().E.get(4).c());
        ((TextView) viewInflate.findViewById(R.id.d6Text)).setText(MyApplication.b().E.get(5).c());
        ((TextView) viewInflate.findViewById(R.id.d7Text)).setText(MyApplication.b().E.get(6).c());
        ((TextView) viewInflate.findViewById(R.id.d8Text)).setText(MyApplication.b().E.get(7).c());
        ((TextView) viewInflate.findViewById(R.id.d9Text)).setText(MyApplication.b().E.get(8).c());
        ((TextView) viewInflate.findViewById(R.id.d10Text)).setText(MyApplication.b().E.get(9).c());
        ((TextView) viewInflate.findViewById(R.id.d11Text)).setText(MyApplication.b().E.get(10).c());
        ((TextView) viewInflate.findViewById(R.id.d12Text)).setText(MyApplication.b().E.get(11).c());
        ((TextView) viewInflate.findViewById(R.id.d13Text)).setText(MyApplication.b().E.get(12).c());
        ((TextView) viewInflate.findViewById(R.id.d14Text)).setText(MyApplication.b().E.get(13).c());
        ((TextView) viewInflate.findViewById(R.id.d15Text)).setText(MyApplication.b().E.get(14).c());
        ((TextView) viewInflate.findViewById(R.id.d16Text)).setText(MyApplication.b().E.get(15).c());
        viewInflate.findViewById(R.id.sys).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d1).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d2).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d3).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d4).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d5).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d6).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d7).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d8).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d9).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d10).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d11).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d12).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d13).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d14).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d15).setOnClickListener(k2Var);
        viewInflate.findViewById(R.id.d16).setOnClickListener(k2Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void k(Context context, ImageView imageView, ru.himik.nightscream.kascada.CustomComponents.z zVar, boolean z2, AlertDialog alertDialog) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_choose_image_lamp, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        n2 n2Var = new n2(imageView, context, zVar, z2, alertDialogCreate, alertDialog);
        viewInflate.findViewById(R.id.imageGreen).setOnClickListener(n2Var);
        viewInflate.findViewById(R.id.imageYellow).setOnClickListener(n2Var);
        viewInflate.findViewById(R.id.imageRed).setOnClickListener(n2Var);
        viewInflate.findViewById(R.id.imageBlue).setOnClickListener(n2Var);
        viewInflate.findViewById(R.id.imageOff).setOnClickListener(n2Var);
        viewInflate.findViewById(R.id.buttonChoosePath).setOnClickListener(n2Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void l(final Context context, final ru.himik.nightscream.kascada.CustomComponents.z zVar) {
        View viewInflate;
        View.OnClickListener kVar;
        DialogInterface.OnDismissListener r0Var;
        DialogInterface.OnDismissListener y1Var;
        TextView textView;
        int i3;
        View viewFindViewById;
        DialogInterface.OnDismissListener rVar;
        View viewFindViewById2;
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        switch (zVar.getIdComponent()) {
            case 1:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_switch, (ViewGroup) null);
                kVar = new k(context, zVar, alertDialogCreate);
                EditText editText = (EditText) viewInflate.findViewById(R.id.reg);
                editText.setText(zVar.getConnectionInfo().c() + "");
                EditText editText2 = (EditText) viewInflate.findViewById(R.id.bit);
                editText2.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText.setOnClickListener(new v(editText));
                editText2.setOnClickListener(new g0(editText2));
                r0Var = new r0(editText, context, zVar, editText2);
                alertDialogCreate.setOnDismissListener(r0Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewInflate.findViewById(R.id.dialog_preference).setOnClickListener(kVar);
                viewInflate.findViewById(R.id.dialog_set_network_device).setOnClickListener(kVar);
                i3 = R.id.dialog_change_image;
                viewFindViewById2 = viewInflate.findViewById(i3);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 2:
                Intent intent = new Intent(context, (Class<?>) PrefActivity.class);
                intent.putExtra("idComponent", zVar.getIdComponent());
                intent.putExtra("text", zVar.getCustomText());
                intent.putExtra("sizeText", (int) zVar.getTextSize());
                intent.putExtra("portraitMode", MyApplication.b().i0);
                CustomLabel customLabel = (CustomLabel) zVar;
                intent.putExtra("autoResizeText", customLabel.q());
                intent.putExtra("enableFrameLabel", customLabel.r());
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
                defaultSharedPreferences.edit().putInt("colorText", zVar.getCurrentTextColor()).apply();
                defaultSharedPreferences.edit().putInt("colorBackground", customLabel.getBackgroundColor_()).apply();
                ((mbCanvas) context).startActivityForResult(intent, 1);
                break;
            case 4:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_register, (ViewGroup) null);
                kVar = new c1(context, zVar, alertDialogCreate);
                EditText editText3 = (EditText) viewInflate.findViewById(R.id.reg);
                editText3.setText(zVar.getConnectionInfo().c() + "");
                editText3.setOnClickListener(new n1(editText3));
                y1Var = new y1(editText3, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 5:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_lamp, (ViewGroup) null);
                kVar = new i2(context, zVar, alertDialogCreate);
                EditText editText4 = (EditText) viewInflate.findViewById(R.id.reg);
                editText4.setText(zVar.getConnectionInfo().c() + "");
                EditText editText5 = (EditText) viewInflate.findViewById(R.id.bit);
                editText5.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText4.setOnClickListener(new o2(editText4));
                editText5.setOnClickListener(new a(editText5));
                r0Var = new b(editText4, context, zVar, editText5);
                alertDialogCreate.setOnDismissListener(r0Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewInflate.findViewById(R.id.dialog_preference).setOnClickListener(kVar);
                viewInflate.findViewById(R.id.dialog_set_network_device).setOnClickListener(kVar);
                i3 = R.id.dialog_change_image;
                viewFindViewById2 = viewInflate.findViewById(i3);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 6:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_button, (ViewGroup) null);
                c cVar = new c(context, zVar, alertDialogCreate);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                TextView textView2 = (TextView) viewInflate.findViewById(R.id.text_address);
                viewInflate.findViewById(R.id.dialog_preference).setOnClickListener(cVar);
                viewInflate.findViewById(R.id.dialog_set_network_device).setOnClickListener(cVar);
                viewInflate.findViewById(R.id.dialog_set_address).setOnClickListener(cVar);
                viewInflate.findViewById(R.id.dialog_change_image).setOnClickListener(cVar);
                textView2.setText(zVar.getStringAddress());
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 7:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_dyn_text, (ViewGroup) null);
                kVar = new d(context, zVar, alertDialogCreate);
                EditText editText6 = (EditText) viewInflate.findViewById(R.id.reg);
                editText6.setText(zVar.getConnectionInfo().c() + "");
                editText6.setOnClickListener(new e(editText6));
                y1Var = new f(editText6, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 8:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_edit_number, (ViewGroup) null);
                kVar = new g(context, zVar, alertDialogCreate);
                EditText editText7 = (EditText) viewInflate.findViewById(R.id.reg);
                editText7.setText(zVar.getConnectionInfo().c() + "");
                editText7.setOnClickListener(new h(editText7));
                y1Var = new i(editText7, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 9:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_alarm, (ViewGroup) null);
                kVar = new j(context, zVar, alertDialogCreate);
                EditText editText8 = (EditText) viewInflate.findViewById(R.id.reg);
                editText8.setText(zVar.getConnectionInfo().c() + "");
                EditText editText9 = (EditText) viewInflate.findViewById(R.id.bit);
                editText9.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText8.setOnClickListener(new l(editText8));
                editText9.setOnClickListener(new m(editText9));
                alertDialogCreate.setOnDismissListener(new n(editText8, context, zVar, editText9));
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_sound_alarm);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 10:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_sms, (ViewGroup) null);
                kVar = new o(context, zVar, alertDialogCreate);
                EditText editText10 = (EditText) viewInflate.findViewById(R.id.reg);
                editText10.setText(zVar.getConnectionInfo().c() + "");
                EditText editText11 = (EditText) viewInflate.findViewById(R.id.bit);
                editText11.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText10.setOnClickListener(new p(editText10));
                editText11.setOnClickListener(new q(editText11));
                rVar = new r(editText10, context, zVar, editText11);
                alertDialogCreate.setOnDismissListener(rVar);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 11:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_line_level, (ViewGroup) null);
                kVar = new s(context, zVar, alertDialogCreate);
                EditText editText12 = (EditText) viewInflate.findViewById(R.id.reg);
                editText12.setText(zVar.getConnectionInfo().c() + "");
                editText12.setOnClickListener(new t(editText12));
                y1Var = new u(editText12, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 12:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_circle_gauge, (ViewGroup) null);
                kVar = new w(context, zVar, alertDialogCreate);
                EditText editText13 = (EditText) viewInflate.findViewById(R.id.reg);
                editText13.setText(zVar.getConnectionInfo().c() + "");
                editText13.setOnClickListener(new x(editText13));
                y1Var = new y(editText13, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 13:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_seek_bar, (ViewGroup) null);
                kVar = new z(context, zVar, alertDialogCreate);
                EditText editText14 = (EditText) viewInflate.findViewById(R.id.reg);
                editText14.setText(zVar.getConnectionInfo().c() + "");
                editText14.setOnClickListener(new a0(editText14));
                alertDialogCreate.setOnDismissListener(new b0(editText14, context, zVar));
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewInflate.findViewById(R.id.dialog_preference).setOnClickListener(kVar);
                viewInflate.findViewById(R.id.dialog_set_network_device).setOnClickListener(kVar);
                i3 = R.id.dialog_turn;
                viewFindViewById2 = viewInflate.findViewById(i3);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 14:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_graph, (ViewGroup) null);
                kVar = new c0(context, zVar, alertDialogCreate);
                EditText editText15 = (EditText) viewInflate.findViewById(R.id.reg);
                editText15.setText(zVar.getConnectionInfo().c() + "");
                editText15.setOnClickListener(new d0(editText15));
                y1Var = new e0(editText15, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 15:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_archive, (ViewGroup) null);
                f0 f0Var = new f0(context, zVar, alertDialogCreate);
                EditText editText16 = (EditText) viewInflate.findViewById(R.id.reg);
                editText16.setText(zVar.getConnectionInfo().c() + "");
                EditText editText17 = (EditText) viewInflate.findViewById(R.id.bit);
                editText17.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText16.setOnClickListener(new ViewOnClickListenerC0306h0(editText16));
                editText17.setOnClickListener(new i0(editText17));
                alertDialogCreate.setOnDismissListener(new j0(editText16, context, zVar, editText17));
                TextView textView3 = (TextView) viewInflate.findViewById(R.id.text_network_device);
                if (((mbCanvas) context).f9206k) {
                    viewInflate.findViewById(R.id.dialog_preference).setVisibility(8);
                    viewInflate.findViewById(R.id.dialog_set_network_device).setVisibility(8);
                    viewInflate.findViewById(R.id.dialog_set_address).setVisibility(8);
                } else {
                    viewInflate.findViewById(R.id.dialog_preference).setOnClickListener(f0Var);
                    viewInflate.findViewById(R.id.dialog_set_network_device).setOnClickListener(f0Var);
                    viewInflate.findViewById(R.id.dialog_set_address).setOnClickListener(f0Var);
                }
                viewInflate.findViewById(R.id.dialog_graph).setOnClickListener(f0Var);
                viewInflate.findViewById(R.id.dialog_export_csv).setOnClickListener(f0Var);
                textView3.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 16:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_gif, (ViewGroup) null);
                kVar = new k0(context, zVar, alertDialogCreate);
                EditText editText18 = (EditText) viewInflate.findViewById(R.id.reg);
                editText18.setText(zVar.getConnectionInfo().c() + "");
                EditText editText19 = (EditText) viewInflate.findViewById(R.id.bit);
                editText19.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText18.setOnClickListener(new l0(editText18));
                editText19.setOnClickListener(new m0(editText19));
                rVar = new n0(editText18, context, zVar, editText19);
                alertDialogCreate.setOnDismissListener(rVar);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 17:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_dyn_pictures, (ViewGroup) null);
                kVar = new o0(context, zVar, alertDialogCreate);
                EditText editText20 = (EditText) viewInflate.findViewById(R.id.reg);
                editText20.setText(zVar.getConnectionInfo().c() + "");
                editText20.setOnClickListener(new p0(editText20));
                y1Var = new q0(editText20, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 18:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_sms_receive, (ViewGroup) null);
                kVar = new s0(context, zVar, alertDialogCreate);
                EditText editText21 = (EditText) viewInflate.findViewById(R.id.reg);
                editText21.setText(zVar.getConnectionInfo().c() + "");
                EditText editText22 = (EditText) viewInflate.findViewById(R.id.bit);
                editText22.setText(((int) zVar.getConnectionInfo().a()) + "");
                if (((ru.himik.nightscream.kascada.CustomComponents.x) zVar).getTypeCommand() == 0) {
                    editText22.setVisibility(8);
                    viewInflate.findViewById(R.id.text_address_bit).setVisibility(8);
                }
                editText21.setOnClickListener(new t0(editText21));
                editText22.setOnClickListener(new u0(editText22));
                rVar = new v0(editText21, context, zVar, editText22);
                alertDialogCreate.setOnDismissListener(rVar);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 19:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_gateway, (ViewGroup) null);
                TextView textView4 = (TextView) viewInflate.findViewById(R.id.text_network_source);
                TextView textView5 = (TextView) viewInflate.findViewById(R.id.text_network_receive);
                w0 w0Var = new w0(context, zVar, alertDialogCreate);
                Spinner spinner = (Spinner) viewInflate.findViewById(R.id.spinnerFunctionModbus);
                ru.himik.nightscream.kascada.CustomComponents.k kVar2 = (ru.himik.nightscream.kascada.CustomComponents.k) zVar;
                if (kVar2.getTypeRequestSource() == 3) {
                    spinner.setSelection(0);
                }
                if (kVar2.getTypeRequestSource() == 4) {
                    spinner.setSelection(1);
                }
                spinner.setOnItemSelectedListener(new x0(zVar));
                EditText editText23 = (EditText) viewInflate.findViewById(R.id.regSource);
                editText23.setText(kVar2.f8832g.c() + "");
                editText23.setOnClickListener(new y0(editText23));
                EditText editText24 = (EditText) viewInflate.findViewById(R.id.regReceive);
                editText24.setText(kVar2.f8833h.c() + "");
                editText24.setOnClickListener(new z0(editText24));
                alertDialogCreate.setOnDismissListener(new a1(editText23, context, zVar, editText24));
                viewInflate.findViewById(R.id.dialog_preference).setOnClickListener(w0Var);
                viewInflate.findViewById(R.id.dialog_set_network_source).setOnClickListener(w0Var);
                viewInflate.findViewById(R.id.dialog_set_network_receive).setOnClickListener(w0Var);
                textView4.setText(kVar2.getStringNameDeviceSource());
                textView5.setText(kVar2.getStringNameDeviceReceive());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 20:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_list, (ViewGroup) null);
                kVar = new b1(context, zVar, alertDialogCreate);
                EditText editText25 = (EditText) viewInflate.findViewById(R.id.reg);
                editText25.setText(zVar.getConnectionInfo().c() + "");
                editText25.setOnClickListener(new d1(editText25));
                y1Var = new e1(editText25, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 21:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_sound, (ViewGroup) null);
                kVar = new f1(context, zVar, alertDialogCreate);
                EditText editText26 = (EditText) viewInflate.findViewById(R.id.reg);
                editText26.setText(zVar.getConnectionInfo().c() + "");
                editText26.setOnClickListener(new g1(editText26));
                y1Var = new h1(editText26, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 22:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_gateway_bit, (ViewGroup) null);
                TextView textView6 = (TextView) viewInflate.findViewById(R.id.text_network_source);
                TextView textView7 = (TextView) viewInflate.findViewById(R.id.text_network_receive);
                TextView textView8 = (TextView) viewInflate.findViewById(R.id.text_address_source);
                TextView textView9 = (TextView) viewInflate.findViewById(R.id.text_address_receive);
                i1 i1Var = new i1(context, zVar, alertDialogCreate);
                viewInflate.findViewById(R.id.dialog_preference).setOnClickListener(i1Var);
                viewInflate.findViewById(R.id.dialog_set_network_source).setOnClickListener(i1Var);
                viewInflate.findViewById(R.id.dialog_set_network_receive).setOnClickListener(i1Var);
                viewInflate.findViewById(R.id.dialog_set_address_source).setOnClickListener(i1Var);
                viewInflate.findViewById(R.id.dialog_set_address_receive).setOnClickListener(i1Var);
                ru.himik.nightscream.kascada.CustomComponents.l lVar = (ru.himik.nightscream.kascada.CustomComponents.l) zVar;
                textView6.setText(lVar.getStringNameDeviceSource());
                textView7.setText(lVar.getStringNameDeviceReceive());
                textView8.setText(context.getString(R.string.dialog_address) + ": " + lVar.f8842f.c() + "." + ((int) lVar.f8842f.a()));
                textView9.setText(context.getString(R.string.dialog_address) + ": " + lVar.f8843g.c() + "." + ((int) lVar.f8843g.a()));
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 23:
                View viewInflate2 = layoutInflaterFrom.inflate(R.layout.dialog_camera, (ViewGroup) null);
                EditText editText27 = (EditText) viewInflate2.findViewById(R.id.rtsp_url);
                editText27.setText(((ru.himik.nightscream.kascada.CustomComponents.f) zVar).getRtsp());
                alertDialogCreate.setOnDismissListener(new j1(zVar, editText27));
                alertDialogCreate.setView(viewInflate2);
                alertDialogCreate.show();
                break;
            case 24:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_gauge2, (ViewGroup) null);
                kVar = new k1(context, zVar, alertDialogCreate);
                EditText editText28 = (EditText) viewInflate.findViewById(R.id.reg);
                editText28.setText(zVar.getConnectionInfo().c() + "");
                editText28.setOnClickListener(new l1(editText28));
                y1Var = new m1(editText28, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 25:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_push_notif, (ViewGroup) null);
                kVar = new o1(context, zVar, alertDialogCreate);
                EditText editText29 = (EditText) viewInflate.findViewById(R.id.reg);
                editText29.setText(zVar.getConnectionInfo().c() + "");
                EditText editText30 = (EditText) viewInflate.findViewById(R.id.bit);
                editText30.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText29.setOnClickListener(new p1(editText29));
                editText30.setOnClickListener(new q1(editText30));
                rVar = new r1(editText29, context, zVar, editText30);
                alertDialogCreate.setOnDismissListener(rVar);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 26:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_web_view, (ViewGroup) null);
                kVar = new s1(context, zVar, alertDialogCreate);
                EditText editText31 = (EditText) viewInflate.findViewById(R.id.reg);
                editText31.setText(zVar.getConnectionInfo().c() + "");
                editText31.setOnClickListener(new t1(editText31));
                y1Var = new u1(editText31, context, zVar);
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 27:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_voice_recognition, (ViewGroup) null);
                kVar = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.t
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        h0.a(context, zVar, alertDialogCreate, view);
                    }
                };
                final EditText editText32 = (EditText) viewInflate.findViewById(R.id.reg);
                editText32.setText(zVar.getConnectionInfo().c() + "");
                editText32.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.v
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        editText32.selectAll();
                    }
                });
                y1Var = new DialogInterface.OnDismissListener() { // from class: ru.himik.nightscream.kascada.r.x
                    @Override // android.content.DialogInterface.OnDismissListener
                    public final void onDismiss(DialogInterface dialogInterface) {
                        h0.c(editText32, context, zVar, dialogInterface);
                    }
                };
                alertDialogCreate.setOnDismissListener(y1Var);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
            case 28:
                viewInflate = layoutInflaterFrom.inflate(R.layout.dialog_email, (ViewGroup) null);
                kVar = new v1(context, zVar, alertDialogCreate);
                EditText editText33 = (EditText) viewInflate.findViewById(R.id.reg);
                editText33.setText(zVar.getConnectionInfo().c() + "");
                EditText editText34 = (EditText) viewInflate.findViewById(R.id.bit);
                editText34.setText(((int) zVar.getConnectionInfo().a()) + "");
                editText33.setOnClickListener(new w1(editText33));
                editText34.setOnClickListener(new x1(editText34));
                rVar = new z1(editText33, context, zVar, editText34);
                alertDialogCreate.setOnDismissListener(rVar);
                textView = (TextView) viewInflate.findViewById(R.id.text_network_device);
                viewFindViewById = viewInflate.findViewById(R.id.dialog_preference);
                viewFindViewById.setOnClickListener(kVar);
                viewFindViewById2 = viewInflate.findViewById(R.id.dialog_set_network_device);
                viewFindViewById2.setOnClickListener(kVar);
                textView.setText(zVar.getStringNameDevice());
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
                break;
        }
    }

    static void m(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar, boolean z2) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_set_function_and_bit_gatewaybit, (ViewGroup) null);
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(viewInflate);
        builder.setTitle(context.getResources().getString(R.string.base_pref_title_gateway));
        Spinner[] spinnerArr = new Spinner[1];
        EditText[] editTextArr = new EditText[1];
        EditText[] editTextArr2 = new EditText[1];
        builder.setPositiveButton(context.getResources().getString(R.string.dialog_accept), new a2());
        AlertDialog alertDialogCreate = builder.create();
        alertDialogCreate.setOnShowListener(new b2(spinnerArr, viewInflate, editTextArr, editTextArr2, z2, zVar));
        alertDialogCreate.setOnDismissListener(new c2(z2, editTextArr2, zVar, editTextArr, spinnerArr, context));
        alertDialogCreate.show();
    }

    public static void n(final Context context) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_menu_align_components, (ViewGroup) null);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.u
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                h0.d(context, alertDialogCreate, view);
            }
        };
        viewInflate.findViewById(R.id.alignLeft).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignTop).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignRight).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignVertical).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignBottom).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignHorizontal).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignSpaceHorizontal).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignSpaceVertical).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignHeightMax).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.alignWidthMax).setOnClickListener(onClickListener);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void o(Context context, ru.himik.nightscream.kascada.CustomComponents.z zVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_menu_image_lamp, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        l2 l2Var = new l2(context, viewInflate, zVar, alertDialogCreate);
        alertDialogCreate.setOnDismissListener(new m2());
        viewInflate.findViewById(R.id.imageOn).setOnClickListener(l2Var);
        viewInflate.findViewById(R.id.imageOff).setOnClickListener(l2Var);
        ru.himik.nightscream.kascada.CustomComponents.q qVar = (ru.himik.nightscream.kascada.CustomComponents.q) zVar;
        ((ImageView) viewInflate.findViewById(R.id.imageOn)).setImageBitmap(qVar.f8868j[0]);
        ((ImageView) viewInflate.findViewById(R.id.imageOff)).setImageBitmap(qVar.f8869k[0]);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void p(Context context, String str) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(str).setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.w
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i3) {
                dialogInterface.cancel();
            }
        });
        builder.create().show();
    }
}
