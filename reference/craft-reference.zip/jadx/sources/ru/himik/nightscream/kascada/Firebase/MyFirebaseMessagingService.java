package ru.himik.nightscream.kascada.Firebase;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.h;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.s0;
import com.sun.mail.imap.IMAPStore;
import java.util.Random;
import ru.himik.nightscream.kascada.MainActivity;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private void v(NotificationManager notificationManager) {
        NotificationChannel notificationChannel = new NotificationChannel("admin_channel", "New notification", 4);
        notificationChannel.setDescription("Device to device notification");
        notificationChannel.enableLights(true);
        notificationChannel.setLightColor(getResources().getColor(R.color.text_orange));
        notificationChannel.enableVibration(true);
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    public void q(s0 s0Var) {
        String str;
        String strC = "";
        if (s0Var.h() != null) {
            String strA = s0Var.h().a();
            strC = s0Var.h().c();
            str = strA;
        } else {
            str = "";
        }
        if (s0Var.g().get("title") != null) {
            str = s0Var.g().get("body");
            strC = s0Var.g().get("title");
        }
        if (s0Var.g().containsKey(IMAPStore.ID_COMMAND)) {
            if (s0Var.g().get(IMAPStore.ID_COMMAND).contains("connect_web_socket_to_kascadacloud")) {
                Intent intent = new Intent("hmikascada.ru.broadcast");
                intent.putExtra("webSocket", true);
                MyApplication.b().sendBroadcast(intent);
                return;
            }
            return;
        }
        Intent intent2 = new Intent(this, (Class<?>) MainActivity.class);
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        int iNextInt = new Random().nextInt(3000);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            v(notificationManager);
        }
        intent2.addFlags(67108864);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent2, 1073741824);
        Bitmap bitmapDecodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.ic_notification);
        Uri defaultUri = RingtoneManager.getDefaultUri(2);
        h.e eVar = new h.e(this, "admin_channel");
        eVar.u(R.drawable.ic_notification);
        eVar.o(bitmapDecodeResource);
        eVar.k(strC);
        eVar.j(str);
        eVar.f(true);
        eVar.v(defaultUri);
        eVar.i(activity);
        if (i2 >= 21) {
            eVar.h(getResources().getColor(R.color.text_orange));
        }
        notificationManager.notify(iNextInt, eVar.b());
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    public void s(String str) {
        super.s(str);
    }
}
