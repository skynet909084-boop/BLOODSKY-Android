package ru.himik.nightscream.kascada.q.f.a;

import com.sun.mail.imap.IMAPStore;
import java.util.List;
import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class f {
    private final List<a> Screens;
    private final int cScreen;
    private final int currentScreen;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final int f9284h;
    private final int w;

    public static final class a {
        private final String name;
        private final int num;
        private final int pass;

        public a(int i2, String str, int i3) {
            j.d(str, IMAPStore.ID_NAME);
            this.num = i2;
            this.name = str;
            this.pass = i3;
        }

        public static /* synthetic */ a copy$default(a aVar, int i2, String str, int i3, int i4, Object obj) {
            if ((i4 & 1) != 0) {
                i2 = aVar.num;
            }
            if ((i4 & 2) != 0) {
                str = aVar.name;
            }
            if ((i4 & 4) != 0) {
                i3 = aVar.pass;
            }
            return aVar.copy(i2, str, i3);
        }

        public final int component1() {
            return this.num;
        }

        public final String component2() {
            return this.name;
        }

        public final int component3() {
            return this.pass;
        }

        public final a copy(int i2, String str, int i3) {
            j.d(str, IMAPStore.ID_NAME);
            return new a(i2, str, i3);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.num == aVar.num && j.a(this.name, aVar.name) && this.pass == aVar.pass;
        }

        public final String getName() {
            return this.name;
        }

        public final int getNum() {
            return this.num;
        }

        public final int getPass() {
            return this.pass;
        }

        public int hashCode() {
            return (((this.num * 31) + this.name.hashCode()) * 31) + this.pass;
        }

        public String toString() {
            return "Screen(num=" + this.num + ", name=" + this.name + ", pass=" + this.pass + ')';
        }
    }

    public f(int i2, int i3, int i4, int i5, List<a> list) {
        j.d(list, "Screens");
        this.currentScreen = i2;
        this.cScreen = i3;
        this.w = i4;
        this.f9284h = i5;
        this.Screens = list;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ f copy$default(f fVar, int i2, int i3, int i4, int i5, List list, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            i2 = fVar.currentScreen;
        }
        if ((i6 & 2) != 0) {
            i3 = fVar.cScreen;
        }
        int i7 = i3;
        if ((i6 & 4) != 0) {
            i4 = fVar.w;
        }
        int i8 = i4;
        if ((i6 & 8) != 0) {
            i5 = fVar.f9284h;
        }
        int i9 = i5;
        if ((i6 & 16) != 0) {
            list = fVar.Screens;
        }
        return fVar.copy(i2, i7, i8, i9, list);
    }

    public final int component1() {
        return this.currentScreen;
    }

    public final int component2() {
        return this.cScreen;
    }

    public final int component3() {
        return this.w;
    }

    public final int component4() {
        return this.f9284h;
    }

    public final List<a> component5() {
        return this.Screens;
    }

    public final f copy(int i2, int i3, int i4, int i5, List<a> list) {
        j.d(list, "Screens");
        return new f(i2, i3, i4, i5, list);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return this.currentScreen == fVar.currentScreen && this.cScreen == fVar.cScreen && this.w == fVar.w && this.f9284h == fVar.f9284h && j.a(this.Screens, fVar.Screens);
    }

    public final int getCScreen() {
        return this.cScreen;
    }

    public final int getCurrentScreen() {
        return this.currentScreen;
    }

    public final int getH() {
        return this.f9284h;
    }

    public final List<a> getScreens() {
        return this.Screens;
    }

    public final int getW() {
        return this.w;
    }

    public int hashCode() {
        return (((((((this.currentScreen * 31) + this.cScreen) * 31) + this.w) * 31) + this.f9284h) * 31) + this.Screens.hashCode();
    }

    public String toString() {
        return "MainSettings(currentScreen=" + this.currentScreen + ", cScreen=" + this.cScreen + ", w=" + this.w + ", h=" + this.f9284h + ", Screens=" + this.Screens + ')';
    }
}
