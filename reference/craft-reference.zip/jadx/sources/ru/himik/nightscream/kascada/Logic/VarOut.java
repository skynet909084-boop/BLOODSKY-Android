package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.g;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class VarOut extends g implements e {
    boolean Q;
    String R;

    public VarOut(Context context) {
        super(context);
        this.Q = false;
        this.R = "VarOut";
    }

    public VarOut(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.Q = false;
        this.R = "VarOut";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.Q = false;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f9022d;
        if (aVar == null || aVar.getOut() == null) {
            return;
        }
        this.Q = ((Boolean) this.f9022d.getOut()).booleanValue();
        MyApplication.b().v0.L(this.f9030l, this.f9031m, this.Q);
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getBit() {
        return this.f9031m;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("reg", 0);
        jSONObject.put("bit", 0);
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.R + " " + this.f9030l + "." + this.f9031m;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        return Boolean.valueOf(this.Q);
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getReg() {
        return this.f9030l;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_textAppearanceListItemSecondary;
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public void j(int i2, int i3) {
        if (i2 <= 0 || i2 > ru.himik.nightscream.kascada.q.d.b.F || i3 < 0 || i3 > 15) {
            return;
        }
        this.f9030l = i2;
        this.f9031m = i3;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        return i2 == 1 ? 1 : 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, android.view.View
    protected void onDraw(Canvas canvas) {
        canvas.drawLine(0.0f, getHeight() / 2, this.M, getHeight() / 2, this.f9023e);
        this.C.set(this.M, this.N, getWidth() - this.N, getHeight() - this.N);
        this.f9023e.setStyle(Paint.Style.FILL);
        this.f9023e.setColor(-7829368);
        canvas.drawRect(this.C, this.f9023e);
        this.f9023e.setStyle(Paint.Style.STROKE);
        this.f9023e.setColor(-16777216);
        canvas.drawRect(this.C, this.f9023e);
        canvas.drawText(this.f9032n, (getWidth() / 2) + (this.M / 2), (int) ((getHeight() / 2) - ((this.f9024f.descent() + this.f9024f.ascent()) / 2.0f)), this.f9024f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, android.view.View
    protected void onMeasure(int i2, int i3) {
        this.f9032n = "S#" + this.f9030l + "." + this.f9031m;
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g
    public void setIn(Object obj) {
        this.Q = ((Boolean) obj).booleanValue();
    }
}
