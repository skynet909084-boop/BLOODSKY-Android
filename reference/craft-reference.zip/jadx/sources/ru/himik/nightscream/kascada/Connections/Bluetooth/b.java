package ru.himik.nightscream.kascada.Connections.Bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;
import com.karumi.dexter.R;
import com.yandex.metrica.YandexMetrica;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

/* JADX INFO: loaded from: classes.dex */
public class b extends Thread implements ru.himik.nightscream.kascada.q.a {
    int C;
    public int H;
    int K;
    String a;
    BluetoothDevice b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    BluetoothSocket f8611d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    a f8612e;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    Handler f8615h;
    long o;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> f8613f = new ArrayList<>();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f8614g = true;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    ru.himik.nightscream.kascada.CustomComponents.b f8616i = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    ru.himik.nightscream.kascada.x.a f8617j = new ru.himik.nightscream.kascada.x.a();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    boolean f8618k = false;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private UUID f8619l = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8620m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    boolean f8621n = false;
    int D = 0;
    int E = 0;
    boolean F = false;
    boolean G = false;
    boolean I = false;
    int J = 1;
    boolean L = false;
    public ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> M = new ArrayList<>();
    BluetoothAdapter c = BluetoothAdapter.getDefaultAdapter();

    public b(String str, Handler handler, int i2, int i3) {
        this.H = -1;
        this.K = 0;
        this.a = str;
        this.f8615h = handler;
        this.H = i2;
        this.K = i3;
    }

    private void h(ru.himik.nightscream.kascada.CustomComponents.b bVar, byte[] bArr) {
        Handler handler;
        int iH;
        int iJ;
        int i2;
        Message messageObtainMessage;
        int i3;
        Integer numValueOf;
        String str;
        int i4;
        int i5;
        if (bVar == null) {
            return;
        }
        int length = bArr.length;
        int[] iArr = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            iArr[i6] = bArr[i6] & 255;
        }
        if (length >= 6 && bVar.b() == iArr[0] && bVar.q() == iArr[1]) {
            byte bQ = bVar.q();
            if (bQ == 1) {
                int iH2 = bVar.h();
                if (iH2 == 19) {
                    handler = this.f8615h;
                    iH = R.styleable.AppCompatTheme_textAppearanceListItemSecondary;
                    iJ = bVar.j();
                    i2 = iArr[3];
                } else if (iH2 != 22) {
                    handler = this.f8615h;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i2 = iArr[3];
                } else if (bVar.f() > 8) {
                    byte[] bArr2 = new byte[2];
                    System.arraycopy(bArr, 3, bArr2, 0, 2);
                    messageObtainMessage = this.f8615h.obtainMessage(1, 22, bVar.j(), bArr2);
                } else {
                    byte[] bArr3 = new byte[1];
                    System.arraycopy(bArr, 3, bArr3, 0, 1);
                    messageObtainMessage = this.f8615h.obtainMessage(1, 22, bVar.j(), bArr3);
                }
                i3 = (i2 >> 0) & 1;
                numValueOf = Integer.valueOf(i3);
                messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
            } else if (bQ != 2) {
                if (bQ == 3) {
                    if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                        int[] iArr2 = new int[bVar.g() * 2];
                        try {
                            System.arraycopy(iArr, 3, iArr2, 0, bVar.g() * 2);
                            this.f8615h.obtainMessage(1, bVar.h(), bVar.j(), iArr2).sendToTarget();
                            return;
                        } catch (Exception e2) {
                            e = e2;
                            this.f8615h.obtainMessage(2, this.f8616i.h(), this.f8616i.j()).sendToTarget();
                            str = "ArrayIndexOutOfBoundsException Bluetooth TypeRequest = 3";
                            YandexMetrica.reportError(str, e);
                            return;
                        }
                    }
                    handler = this.f8615h;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i4 = iArr[3] * 256;
                    i5 = iArr[4];
                    numValueOf = Integer.valueOf(i4 + i5);
                } else if (bQ != 4) {
                    if (bQ != 5 || bVar.h() == 22) {
                        return;
                    }
                    handler = this.f8615h;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i3 = iArr[4];
                    numValueOf = Integer.valueOf(i3);
                } else {
                    if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                        int[] iArr3 = new int[bVar.g() * 2];
                        try {
                            System.arraycopy(iArr, 3, iArr3, 0, bVar.g() * 2);
                            this.f8615h.obtainMessage(1, bVar.h(), bVar.j(), iArr3).sendToTarget();
                            return;
                        } catch (Exception e3) {
                            e = e3;
                            this.f8615h.obtainMessage(2, this.f8616i.h(), this.f8616i.j()).sendToTarget();
                            str = "ArrayIndexOutOfBoundsException Bluetooth TypeRequest = 4";
                            YandexMetrica.reportError(str, e);
                            return;
                        }
                    }
                    handler = this.f8615h;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i4 = iArr[3] * 256;
                    i5 = iArr[4];
                    numValueOf = Integer.valueOf(i4 + i5);
                }
                messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
            } else if (bVar.h() != 22) {
                handler = this.f8615h;
                iH = bVar.h();
                iJ = bVar.j();
                i2 = iArr[3];
                i3 = (i2 >> 0) & 1;
                numValueOf = Integer.valueOf(i3);
                messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
            } else if (bVar.f() > 8) {
                byte[] bArr4 = new byte[2];
                System.arraycopy(bArr, 3, bArr4, 0, 2);
                messageObtainMessage = this.f8615h.obtainMessage(1, 22, bVar.j(), bArr4);
            } else {
                byte[] bArr5 = new byte[1];
                System.arraycopy(bArr, 3, bArr5, 0, 1);
                messageObtainMessage = this.f8615h.obtainMessage(1, 22, bVar.j(), bArr5);
            }
            messageObtainMessage.sendToTarget();
        }
    }

    private void i(byte[] bArr) {
        a aVar = this.f8612e;
        if (aVar != null) {
            aVar.b(bArr);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public int a() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public String b() {
        return this.a;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void c(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        this.M.add(bVar);
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void cancel() {
        this.G = true;
        this.f8614g = false;
        this.f8613f.clear();
        a aVar = this.f8612e;
        if (aVar != null) {
            aVar.a();
        }
        try {
            BluetoothSocket bluetoothSocket = this.f8611d;
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void d() {
        start();
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void e(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        if (this.F) {
            this.M.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void f(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        this.f8613f.add(bVar);
    }

    void g() {
        this.L = !this.L;
        this.E++;
        BluetoothDevice remoteDevice = this.c.getRemoteDevice(this.a);
        this.b = remoteDevice;
        if (remoteDevice != null) {
            try {
                this.f8611d = this.L ? c.a(remoteDevice) : remoteDevice.createInsecureRfcommSocketToServiceRecord(this.f8619l);
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        try {
            Thread.sleep(100L);
            BluetoothSocket bluetoothSocket = this.f8611d;
            if (bluetoothSocket != null) {
                bluetoothSocket.connect();
            }
            if (!this.G) {
                a aVar = new a(this.f8611d, this.f8613f);
                this.f8612e = aVar;
                aVar.start();
                this.C = this.f8613f.size();
                this.D = 0;
                this.f8621n = false;
                this.o = System.currentTimeMillis();
                this.F = true;
                this.E = 0;
            }
            if (this.G) {
                a aVar2 = this.f8612e;
                if (aVar2 != null) {
                    aVar2.a();
                }
                try {
                    BluetoothSocket bluetoothSocket2 = this.f8611d;
                    if (bluetoothSocket2 != null) {
                        bluetoothSocket2.close();
                    }
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
            }
            this.f8615h.obtainMessage(3, 5, this.H).sendToTarget();
            try {
                Thread.sleep(500L);
            } catch (InterruptedException e4) {
                e4.printStackTrace();
            }
        } catch (IOException e5) {
            e5.fillInStackTrace();
            try {
                Thread.sleep(100L);
                BluetoothSocket bluetoothSocket3 = this.f8611d;
                if (bluetoothSocket3 != null) {
                    bluetoothSocket3.close();
                }
                this.f8615h.obtainMessage(3, 1, this.H).sendToTarget();
            } catch (IOException unused) {
            } catch (InterruptedException e6) {
                e6.printStackTrace();
            }
        } catch (InterruptedException e7) {
            e7.printStackTrace();
        }
    }

    /* JADX WARN: Code duplicated, block: B:67:0x0137  */
    /* JADX WARN: Code duplicated, block: B:68:0x013a  */
    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        int iG;
        while (this.f8614g) {
            if (this.F || this.G || this.I) {
                if (this.f8612e.f8609j) {
                    this.F = false;
                    try {
                        BluetoothSocket bluetoothSocket = this.f8611d;
                        if (bluetoothSocket != null) {
                            bluetoothSocket.close();
                        }
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    a aVar = this.f8612e;
                    aVar.f8609j = false;
                    aVar.a();
                    this.f8615h.obtainMessage(3, 2, this.H).sendToTarget();
                }
                if (!this.f8621n) {
                    if (this.M.size() > 0) {
                        ru.himik.nightscream.kascada.CustomComponents.b bVar = this.M.get(0);
                        this.f8616i = bVar;
                        i(this.f8617j.c(bVar, this.J));
                        this.o = System.currentTimeMillis();
                        this.f8618k = true;
                        this.f8621n = true;
                    } else if (this.C > 0) {
                        this.o = System.currentTimeMillis();
                        this.f8621n = true;
                        ru.himik.nightscream.kascada.CustomComponents.b bVar2 = this.f8613f.get(this.D);
                        this.f8616i = bVar2;
                        if (!((bVar2.h() == 19 && this.f8616i.q() == 6) || (this.f8616i.h() == 22 && this.f8616i.q() == 15)) || this.f8616i.s()) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar3 = this.f8616i;
                            bVar3.x(this.f8617j.c(bVar3, this.J));
                            if (this.f8616i.e() == null) {
                                this.f8615h.obtainMessage(2, this.f8616i.h(), this.f8616i.j()).sendToTarget();
                            }
                            i(this.f8616i.e());
                            int i2 = this.D;
                            if (i2 != this.C - 1) {
                                this.D = i2 + 1;
                            } else {
                                this.D = 0;
                            }
                        } else {
                            int i3 = this.D;
                            if (i3 != this.C - 1) {
                                this.D = i3 + 1;
                            } else {
                                this.D = 0;
                            }
                        }
                    }
                    ru.himik.nightscream.kascada.CustomComponents.b bVar4 = this.f8616i;
                    if (bVar4 != null) {
                        byte bQ = bVar4.q();
                        if (bQ == 15) {
                            this.f8620m = 8;
                        } else if (bQ != 16) {
                            switch (bQ) {
                                case 1:
                                case 2:
                                    if (this.f8616i.f() <= 8) {
                                        this.f8620m = 6;
                                    } else {
                                        iG = 7;
                                        this.f8620m = iG;
                                    }
                                    break;
                                case 3:
                                case 4:
                                    iG = (this.f8616i.g() * 2) + 5;
                                    this.f8620m = iG;
                                    break;
                                case 5:
                                case 6:
                                    this.f8620m = 8;
                                    break;
                            }
                        } else {
                            this.f8620m = 6;
                        }
                    }
                    this.f8612e.f8607h = this.f8620m;
                } else if (System.currentTimeMillis() - this.o >= 2000) {
                    this.f8621n = false;
                    if (this.f8618k) {
                        this.f8618k = false;
                        this.M.remove(0);
                    }
                    if (this.f8616i.b() != 0) {
                        this.f8615h.obtainMessage(2, this.f8616i.h(), this.f8616i.j()).sendToTarget();
                    }
                }
                a aVar2 = this.f8612e;
                if (aVar2.f8606g) {
                    int i4 = aVar2.f8604e;
                    byte[] bArr = new byte[i4];
                    try {
                        System.arraycopy(aVar2.f8605f, 0, bArr, 0, i4);
                        this.f8612e.f8606g = false;
                        this.f8621n = false;
                        if (this.f8618k) {
                            if (this.f8616i.h() == this.M.get(0).h() && this.f8616i.j() == this.M.get(0).j()) {
                                this.M.remove(0);
                                this.f8618k = false;
                            } else {
                                this.f8615h.obtainMessage(1, this.f8616i.h(), this.f8616i.j(), 0).sendToTarget();
                            }
                        }
                        h(this.f8616i, bArr);
                        int i5 = this.K;
                        if (i5 > 0) {
                            try {
                                Thread.sleep(i5);
                            } catch (InterruptedException unused) {
                            }
                        }
                    } catch (Exception unused2) {
                        if (this.f8616i.b() != 0) {
                            this.f8615h.obtainMessage(2, this.f8616i.h(), this.f8616i.j()).sendToTarget();
                        }
                        int i6 = this.K;
                        if (i6 > 0) {
                            try {
                                Thread.sleep(i6);
                            } catch (InterruptedException unused3) {
                            }
                        }
                        this.f8612e.f8606g = false;
                        this.f8621n = false;
                        return;
                    }
                }
                try {
                    Thread.sleep(10L);
                } catch (InterruptedException e3) {
                    e3.printStackTrace();
                }
            } else {
                try {
                    Thread.sleep(500L);
                } catch (InterruptedException e4) {
                    e4.printStackTrace();
                }
                g();
            }
        }
    }
}
