package ru.himik.nightscream.kascada;

import android.app.DialogFragment;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.github.barteksc.pdfviewer.PDFView;
import java.io.File;
import org.videolan.libvlc.media.MediaPlayer;
import ru.himik.nightscream.kascada.Utils.q;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class v extends DialogFragment {
    int a = 1000;
    int b = MediaPlayer.MEDIA_INFO_BAD_INTERLEAVING;
    Uri c;

    public void a(int i2, int i3) {
        this.a = i2;
        this.b = i3;
    }

    public void b(Uri uri) {
        this.c = uri;
    }

    @Override // android.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) throws Throwable {
        PDFView.c cVarZ;
        getDialog().getWindow().requestFeature(1);
        getDialog().setCanceledOnTouchOutside(true);
        View viewInflate = layoutInflater.inflate(R.layout.pdf, viewGroup, false);
        PDFView pDFView = (PDFView) viewInflate.findViewById(R.id.pdfView);
        try {
            if (this.c.toString().equals("")) {
                cVarZ = pDFView.y("help.pdf");
                cVarZ.d(true);
                cVarZ.c(true);
                cVarZ.i(false);
                cVarZ.a(1);
                cVarZ.g(false);
                cVarZ.b(false);
                cVarZ.f(null);
            } else {
                cVarZ = pDFView.z(new File(q.f(getActivity(), this.c)));
                cVarZ.d(true);
                cVarZ.c(true);
                cVarZ.i(false);
                cVarZ.a(1);
                cVarZ.g(false);
                cVarZ.b(false);
                cVarZ.f(null);
            }
            cVarZ.h(true);
            cVarZ.e();
        } catch (Exception unused) {
        }
        return viewInflate;
    }

    @Override // android.app.Fragment
    public void onResume() {
        super.onResume();
        Window window = getDialog().getWindow();
        window.setLayout((int) (((double) this.a) * 0.75d), this.b);
        window.setGravity(17);
    }
}
