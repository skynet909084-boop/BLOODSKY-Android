package ru.himik.nightscream.kascada.q.f.a;

import java.util.List;
import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class i {
    private final List<d> control;
    private final f mainSettings;

    public i(f fVar, List<d> list) {
        j.d(fVar, "mainSettings");
        j.d(list, "control");
        this.mainSettings = fVar;
        this.control = list;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ i copy$default(i iVar, f fVar, List list, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            fVar = iVar.mainSettings;
        }
        if ((i2 & 2) != 0) {
            list = iVar.control;
        }
        return iVar.copy(fVar, list);
    }

    public final f component1() {
        return this.mainSettings;
    }

    public final List<d> component2() {
        return this.control;
    }

    public final i copy(f fVar, List<d> list) {
        j.d(fVar, "mainSettings");
        j.d(list, "control");
        return new i(fVar, list);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return j.a(this.mainSettings, iVar.mainSettings) && j.a(this.control, iVar.control);
    }

    public final List<d> getControl() {
        return this.control;
    }

    public final f getMainSettings() {
        return this.mainSettings;
    }

    public int hashCode() {
        return (this.mainSettings.hashCode() * 31) + this.control.hashCode();
    }

    public String toString() {
        return "OtherControls(mainSettings=" + this.mainSettings + ", control=" + this.control + ')';
    }
}
