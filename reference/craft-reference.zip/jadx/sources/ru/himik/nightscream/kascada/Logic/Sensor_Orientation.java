package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class Sensor_Orientation extends f {
    String V;
    int W;

    public Sensor_Orientation(Context context) {
        super(context);
        this.V = "SENSOR_ORIENTATION";
        this.W = 1;
    }

    public Sensor_Orientation(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = "SENSOR_ORIENTATION";
        this.W = 1;
    }

    public int getActionExecute() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("type", getActionExecute());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        try {
            int i2 = this.W;
            if (i2 == 1) {
                return Float.valueOf(mbCanvas.i1);
            }
            if (i2 != 2) {
                return i2 != 3 ? Float.valueOf(0.0f) : Float.valueOf(mbCanvas.k1);
            }
            return Float.valueOf(mbCanvas.j1);
        } catch (Exception unused) {
            return Float.valueOf(0.0f);
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_windowFixedWidthMajor;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 3;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawRect(this.G, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawRect(this.G, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        canvas.drawLine(getWidth() - this.Q, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        String str;
        int i4 = this.W;
        if (i4 == 1) {
            str = "ORIENTATION_X";
        } else {
            if (i4 != 2) {
                if (i4 == 3) {
                    str = "ORIENTATION_Z";
                }
                super.onMeasure(i2, i3);
            }
            str = "ORIENTATION_Y";
        }
        this.E = str;
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
        String str;
        this.W = i2;
        if (i2 == 1) {
            str = "ORIENTATION_X";
        } else {
            if (i2 != 2) {
                if (i2 == 3) {
                    str = "ORIENTATION_Z";
                }
                invalidate();
            }
            str = "ORIENTATION_Y";
        }
        this.E = str;
        invalidate();
    }
}
