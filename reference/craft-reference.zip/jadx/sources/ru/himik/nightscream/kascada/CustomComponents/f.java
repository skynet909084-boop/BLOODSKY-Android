package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Point;
import android.net.Uri;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;
import org.videolan.libvlc.IVLCVout;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class f extends SurfaceView implements IVLCVout.Callback, z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    View.OnLayoutChangeListener C;
    public Point D;
    public String a;
    int b;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8775d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    boolean f8776e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8777f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8778g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    String f8779h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private LibVLC f8780i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private MediaPlayer f8781j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f8782k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f8783l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private long f8784m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private long f8785n;
    private boolean o;

    class a implements SurfaceHolder.Callback {
        a(f fVar) {
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        }
    }

    class b implements View.OnLayoutChangeListener {
        b() {
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
            f.this.f8782k = i4 - i2;
            f.this.f8783l = i5 - i3;
        }
    }

    class c implements MediaPlayer.EventListener {
        c() {
        }

        @Override // org.videolan.libvlc.VLCEvent.Listener
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public void onEvent(MediaPlayer.Event event) {
            int i2 = event.type;
            if (i2 == 265) {
                try {
                    Thread.sleep(2000L);
                } catch (InterruptedException e2) {
                    e = e2;
                    e.printStackTrace();
                }
            } else {
                if (i2 != 266) {
                    return;
                }
                try {
                    Thread.sleep(2000L);
                } catch (InterruptedException e3) {
                    e = e3;
                    e.printStackTrace();
                }
            }
            f fVar = f.this;
            fVar.e(fVar.f8779h);
        }
    }

    public f(Context context) {
        super(context);
        this.a = getResources().getString(R.string.custom_camera);
        this.b = 23;
        this.f8775d = 1;
        this.f8776e = false;
        this.f8777f = 0;
        this.f8778g = 0;
        this.f8779h = "";
        this.f8781j = null;
        this.f8784m = 0L;
        this.f8785n = 0L;
        this.o = true;
        this.C = new b();
        this.D = new Point();
        addOnLayoutChangeListener(this.C);
        getHolder().addCallback(new a(this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e(String str) {
        i();
        if (this.o) {
            return;
        }
        try {
            ArrayList arrayList = new ArrayList();
            arrayList.add("--aout=opensles");
            arrayList.add("--audio-time-stretch");
            arrayList.add("-vvv");
            this.f8780i = new LibVLC(arrayList);
            getHolder().setKeepScreenOn(true);
            MediaPlayer mediaPlayer = new MediaPlayer(this.f8780i);
            this.f8781j = mediaPlayer;
            mediaPlayer.setEventListener((MediaPlayer.EventListener) new c());
            IVLCVout vLCVout = this.f8781j.getVLCVout();
            vLCVout.setVideoView(this);
            vLCVout.addCallback(this);
            vLCVout.attachViews();
            this.f8781j.setMedia(new Media(this.f8780i, Uri.parse(str)));
            this.f8781j.play();
        } catch (Exception unused) {
        }
    }

    private void i() {
        if (this.f8780i == null) {
            return;
        }
        this.f8781j.stop();
        IVLCVout vLCVout = this.f8781j.getVLCVout();
        vLCVout.removeCallback(this);
        vLCVout.detachViews();
        this.f8780i.release();
        this.f8780i = null;
    }

    public void d() {
        this.o = false;
        e(this.f8779h);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.D.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void f() {
        this.o = true;
        i();
    }

    public void g(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_width);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_width);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_width);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_width);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8775d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.f8777f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.f8778g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("rtsp_url", getRtsp());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.c;
    }

    public int getNumScreen() {
        return this.f8775d;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.D;
    }

    public String getRtsp() {
        return this.f8779h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.f8784m;
    }

    public void h() {
        if (System.currentTimeMillis() - this.f8785n > 15000) {
            this.f8785n = System.currentTimeMillis();
            e(this.f8779h);
        }
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    @Override // org.videolan.libvlc.IVLCVout.Callback
    public void onNewLayout(IVLCVout iVLCVout, int i2, int i3, int i4, int i5, int i6, int i7) {
        int i8 = i2 * i3;
    }

    @Override // org.videolan.libvlc.IVLCVout.Callback
    public void onSurfacesCreated(IVLCVout iVLCVout) {
    }

    @Override // org.videolan.libvlc.IVLCVout.Callback
    public void onSurfacesDestroyed(IVLCVout iVLCVout) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.f8776e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.f8776e = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.f8777f = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.f8778g = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.c = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8775d = i2;
    }

    public void setRtsp(String str) {
        this.f8779h = str;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.f8784m = j2;
    }
}
