package ru.himik.nightscream.kascada.s;

import android.graphics.Point;

/* JADX INFO: loaded from: classes2.dex */
public interface a {
    Point getPointTouch();
}
