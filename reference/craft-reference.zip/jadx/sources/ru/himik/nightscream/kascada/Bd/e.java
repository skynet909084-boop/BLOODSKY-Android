package ru.himik.nightscream.kascada.Bd;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class e extends SQLiteOpenHelper {
    public e(Context context) {
        super(context, "Rovki.db", (SQLiteDatabase.CursorFactory) null, 11);
    }

    private boolean a(SQLiteDatabase sQLiteDatabase, String str, String str2) {
        Cursor cursorRawQuery = null;
        try {
            cursorRawQuery = sQLiteDatabase.rawQuery("SELECT * FROM " + str + " LIMIT 0", null);
            if (cursorRawQuery.getColumnIndex(str2) != -1) {
                if (cursorRawQuery != null) {
                    cursorRawQuery.close();
                }
                return true;
            }
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            return false;
        } catch (Exception unused) {
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            return false;
        } catch (Throwable th) {
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            throw th;
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS TableNameProject (_id integer primary key autoincrement,name text,pass text default '',stationMode integer default 0,countScreen integer default 1,countDevice integer default 4,screenBackground text default '',deviceNetwork text default '',createdTime text default '00:00:00',createdDate text default '2000-01-01',work integer default 0,pdfDocument text default '',showTimeOut integer default 0,systemRegisters text default '',modbusSlave text default '',settings text default '');");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS Settings (_id integer primary key autoincrement,key text default '')");
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i2, int i3) {
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i2, int i3) {
        if (ru.himik.nightscream.kascada.w.a.a) {
            Log.d("kascada", "Обновление базы до версии " + i3);
        }
        if (!a(sQLiteDatabase, "TableNameProject", "work")) {
            sQLiteDatabase.execSQL("ALTER TABLE TableNameProject ADD work integer DEFAULT '0'");
        }
        if (!a(sQLiteDatabase, "TableNameProject", "pdfDocument")) {
            sQLiteDatabase.execSQL("ALTER TABLE TableNameProject ADD pdfDocument text DEFAULT ''");
        }
        if (!a(sQLiteDatabase, "TableNameProject", "showTimeOut")) {
            sQLiteDatabase.execSQL("ALTER TABLE TableNameProject ADD showTimeOut integer default '0'");
        }
        if (!a(sQLiteDatabase, "TableNameProject", "systemRegisters")) {
            sQLiteDatabase.execSQL("ALTER TABLE TableNameProject ADD systemRegisters text default ''");
        }
        if (!a(sQLiteDatabase, "TableNameProject", "modbusSlave")) {
            sQLiteDatabase.execSQL("ALTER TABLE TableNameProject ADD modbusSlave text default ''");
        }
        if (!a(sQLiteDatabase, "TableNameProject", "settings")) {
            sQLiteDatabase.execSQL("ALTER TABLE TableNameProject ADD settings text default ''");
        }
        if (ru.himik.nightscream.kascada.w.a.a) {
            Log.d("kascada", "База обновленна.");
        }
    }
}
