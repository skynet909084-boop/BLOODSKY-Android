package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class VarFloat extends f implements e {
    float V;
    float W;
    public String a0;

    public VarFloat(Context context) {
        super(context);
        this.V = 0.0f;
        this.W = 0.0f;
        this.a0 = "VAR_FLOAT";
    }

    public VarFloat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = 0.0f;
        this.W = 0.0f;
        this.a0 = "VAR_FLOAT";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.V = 0.0f;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getBit() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("reg", 0);
        jSONObject.put("isConstant", g());
        jSONObject.put("constant", getVarFloatConstant() + "");
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.a0 + " " + this.C;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        if (this.o) {
            return Float.valueOf(this.W);
        }
        if (MyApplication.b().v0 == null) {
            return 0;
        }
        float fH = MyApplication.b().v0.H(this.C);
        this.V = fH;
        return Float.valueOf(fH);
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getReg() {
        return this.C;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_textColorAlertDialogListItem;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 3;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public float getVarFloatConstant() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public void j(int i2, int i3) {
        if (i2 <= 0 || i2 > ru.himik.nightscream.kascada.q.d.b.F - 1 || i3 < 0 || i3 > 15) {
            return;
        }
        this.C = i2;
        this.D = i3;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawPath(u(this.G, getHeight(), 0.0f, 0.0f, getHeight()), this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawPath(u(this.G, getHeight(), 0.0f, 0.0f, getHeight()), this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        canvas.drawLine(getWidth() - this.Q, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        StringBuilder sb;
        if (this.o) {
            sb = new StringBuilder();
            sb.append(this.W);
            sb.append("");
        } else {
            sb = new StringBuilder();
            sb.append("S#");
            sb.append(this.C);
        }
        this.E = sb.toString();
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setVarFloatConstant(float f2) {
        this.W = f2;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }

    public Path u(RectF rectF, float f2, float f3, float f4, float f5) {
        Path path = new Path();
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f5 < 0.0f) {
            f5 = 0.0f;
        }
        if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        float f6 = f2 / 2.0f;
        path.moveTo(rectF.left + f6, rectF.top);
        float f7 = f3 / 2.0f;
        path.lineTo(rectF.right - f7, rectF.top);
        float f8 = rectF.right;
        float f9 = rectF.top;
        path.quadTo(f8, f9, f8, f7 + f9);
        float f10 = f4 / 2.0f;
        path.lineTo(rectF.right, rectF.bottom - f10);
        float f11 = rectF.right;
        float f12 = rectF.bottom;
        path.quadTo(f11, f12, f11 - f10, f12);
        float f13 = f5 / 2.0f;
        path.lineTo(rectF.left + f13, rectF.bottom);
        float f14 = rectF.left;
        float f15 = rectF.bottom;
        path.quadTo(f14, f15, f14, f15 - f13);
        path.lineTo(rectF.left, rectF.top + f6);
        float f16 = rectF.left;
        float f17 = rectF.top;
        path.quadTo(f16, f17, f6 + f16, f17);
        path.close();
        return path;
    }
}
