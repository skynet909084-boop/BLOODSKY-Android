package ru.himik.nightscream.kascada.r;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class f0 extends androidx.fragment.app.c {
    TextView v0;
    TextView w0;
    View.OnClickListener x0 = new a();

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            TextView textView;
            Resources resources;
            int i2;
            switch (view.getId()) {
                case R.id.chBackgroundWork /* 2131296469 */:
                    MyApplication.b().f9046n = ((CheckBox) view).isChecked();
                    return;
                case R.id.control_from_network /* 2131296509 */:
                    ((mbCanvas) f0.this.h()).q0();
                    return;
                case R.id.menu_change_mode /* 2131296828 */:
                    ((mbCanvas) f0.this.h()).c0();
                    if (!mbCanvas.Z0) {
                        f0 f0Var = f0.this;
                        textView = f0Var.v0;
                        resources = f0Var.h().getResources();
                        i2 = R.string.menu_change_on_station_mode;
                    } else {
                        f0 f0Var2 = f0.this;
                        textView = f0Var2.v0;
                        resources = f0Var2.h().getResources();
                        i2 = R.string.menu_change_on_mobile_mode;
                    }
                    break;
                case R.id.menu_edit_devices_list /* 2131296830 */:
                    ((mbCanvas) f0.this.h()).e0();
                    return;
                case R.id.menu_set_password /* 2131296831 */:
                    ((mbCanvas) f0.this.h()).f0();
                    return;
                case R.id.menu_visible_timeout /* 2131296834 */:
                    ((mbCanvas) f0.this.h()).d0();
                    if (!mbCanvas.g1) {
                        f0 f0Var3 = f0.this;
                        textView = f0Var3.w0;
                        resources = f0Var3.h().getResources();
                        i2 = R.string.menu_change_timeout_on;
                    } else {
                        f0 f0Var4 = f0.this;
                        textView = f0Var4.w0;
                        resources = f0Var4.h().getResources();
                        i2 = R.string.menu_change_timeout_off;
                    }
                    break;
                default:
                    return;
            }
            textView.setText(resources.getString(i2));
        }
    }

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void a0(Bundle bundle) {
        super.a0(bundle);
    }

    @Override // androidx.fragment.app.Fragment
    public View e0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        TextView textView;
        Resources resources;
        int i2;
        TextView textView2;
        Resources resources2;
        int i3;
        View viewInflate = layoutInflater.inflate(R.layout.menu_, viewGroup);
        r1().getWindow().requestFeature(1);
        viewInflate.findViewById(R.id.menu_edit_devices_list).setOnClickListener(this.x0);
        viewInflate.findViewById(R.id.menu_set_password).setOnClickListener(this.x0);
        viewInflate.findViewById(R.id.menu_change_mode).setOnClickListener(this.x0);
        viewInflate.findViewById(R.id.menu_visible_timeout).setOnClickListener(this.x0);
        viewInflate.findViewById(R.id.menu_create_bridge_wifi_usb).setOnClickListener(this.x0);
        viewInflate.findViewById(R.id.control_from_network).setOnClickListener(this.x0);
        viewInflate.findViewById(R.id.chBackgroundWork).setOnClickListener(this.x0);
        ((CheckBox) viewInflate.findViewById(R.id.chBackgroundWork)).setChecked(MyApplication.b().f9046n);
        this.v0 = (TextView) viewInflate.findViewById(R.id.menu_text_change_mode);
        this.w0 = (TextView) viewInflate.findViewById(R.id.menu_text_visible_timeout);
        if (mbCanvas.Z0) {
            textView = this.v0;
            resources = h().getResources();
            i2 = R.string.menu_change_on_mobile_mode;
        } else {
            textView = this.v0;
            resources = h().getResources();
            i2 = R.string.menu_change_on_station_mode;
        }
        textView.setText(resources.getString(i2));
        if (mbCanvas.g1) {
            textView2 = this.w0;
            resources2 = h().getResources();
            i3 = R.string.menu_change_timeout_off;
        } else {
            textView2 = this.w0;
            resources2 = h().getResources();
            i3 = R.string.menu_change_timeout_on;
        }
        textView2.setText(resources2.getString(i3));
        return viewInflate;
    }

    @Override // androidx.fragment.app.c, androidx.fragment.app.Fragment
    public void x0() {
        super.x0();
    }
}
