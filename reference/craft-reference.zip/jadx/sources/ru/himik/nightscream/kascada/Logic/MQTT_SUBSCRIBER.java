package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;

/* JADX INFO: loaded from: classes2.dex */
public class MQTT_SUBSCRIBER extends f {
    String V;
    Boolean W;
    int a0;
    float b0;
    int c0;
    String d0;
    int e0;

    public MQTT_SUBSCRIBER(Context context) {
        super(context);
        this.V = "MQTT_S";
        this.W = Boolean.FALSE;
        this.a0 = 0;
        this.b0 = 0.0f;
        this.c0 = 1;
        this.d0 = "";
        this.e0 = 1;
    }

    public MQTT_SUBSCRIBER(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = "MQTT_S";
        this.W = Boolean.FALSE;
        this.a0 = 0;
        this.b0 = 0.0f;
        this.c0 = 1;
        this.d0 = "";
        this.e0 = 1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("topic", this.d0);
        jSONObject.put("typeQ", this.c0);
        jSONObject.put("numMqttServer", this.e0);
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.V;
    }

    public int getNumMqttServer() {
        return this.e0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        int i2 = this.c0;
        if (i2 == 1) {
            return this.W;
        }
        if (i2 == 2) {
            return Integer.valueOf(this.a0);
        }
        if (i2 != 3) {
            return null;
        }
        return Float.valueOf(this.b0);
    }

    public String getTopic() {
        return this.d0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 139;
    }

    public int getTypeQ() {
        return this.c0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return this.c0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawRect(this.G, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawRect(this.G, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        canvas.drawLine(getWidth() - this.Q, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        this.E = "MQTT_S";
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
    }

    public void setNumMqttServer(int i2) {
        this.e0 = i2;
    }

    public void setTopic(String str) {
        this.d0 = str;
    }

    public void setTypeQ(int i2) {
        this.c0 = i2;
    }

    public void u(String str) {
        if (str == null || str.isEmpty()) {
            return;
        }
        int i2 = this.c0;
        if (i2 != 1) {
            try {
                if (i2 == 2) {
                    this.a0 = Integer.parseInt(str);
                } else if (i2 != 3) {
                    return;
                } else {
                    this.b0 = Float.parseFloat(str);
                }
                return;
            } catch (Exception unused) {
                return;
            }
        }
        if (str.toLowerCase().equals("true") || str.equals("1")) {
            this.W = Boolean.TRUE;
        }
        if (str.toLowerCase().equals("false") || str.equals("0")) {
            this.W = Boolean.FALSE;
        }
    }
}
