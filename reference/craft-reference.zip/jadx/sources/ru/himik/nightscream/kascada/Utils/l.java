package ru.himik.nightscream.kascada.Utils;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.yandex.metrica.AppMetricaDeviceIDListener;
import com.yandex.metrica.YandexMetrica;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import kotlin.b0.d.v;
import kotlin.i0.r;
import kotlin.i0.t;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class l {
    public static final l a;
    private static boolean b = false;
    private static boolean c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static boolean f9160d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static final String f9161e = "______GHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static ru.himik.nightscream.kascada.Bd.e f9162f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static final SQLiteDatabase f9163g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static String f9164h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static String f9165i;

    public static final class a implements AppMetricaDeviceIDListener {
        final /* synthetic */ v<String> a;

        a(v<String> vVar) {
            this.a = vVar;
        }

        @Override // com.yandex.metrica.AppMetricaDeviceIDListener
        public void onError(AppMetricaDeviceIDListener.Reason reason) {
            kotlin.b0.d.j.d(reason, "error");
            YandexMetrica.reportError("Activation.generateIdKaScada", kotlin.b0.d.j.i("Не удалось получить AppMetricaDeviceID reason: ", reason.name()));
        }

        /* JADX WARN: Type inference failed for: r4v5, types: [T, java.lang.String] */
        @Override // com.yandex.metrica.AppMetricaDeviceIDListener
        public void onLoaded(String str) {
            if (str == null) {
                str = "";
            }
            if (str.length() < 8) {
                YandexMetrica.reportError("Activation.generateIdKaScada", kotlin.b0.d.j.i("AppMetricaDeviceID менее 8 символов -> ", this.a.a));
                return;
            }
            this.a.a = t.L0(str, 8);
            l lVar = l.a;
            lVar.o(lVar.m(this.a.a));
            SharedPreferences.Editor editorEdit = MyApplication.b().getApplicationContext().getSharedPreferences("FINGERPRINT", 0).edit();
            editorEdit.putString("keyIdKaScada", lVar.i());
            editorEdit.apply();
            lVar.b();
        }
    }

    static {
        l lVar = new l();
        a = lVar;
        ru.himik.nightscream.kascada.Bd.e eVar = new ru.himik.nightscream.kascada.Bd.e(MyApplication.b().getApplicationContext());
        f9162f = eVar;
        SQLiteDatabase writableDatabase = eVar.getWritableDatabase();
        kotlin.b0.d.j.c(writableDatabase, "dbHelper.writableDatabase");
        f9163g = writableDatabase;
        f9164h = "";
        f9165i = "";
        Cursor cursorQuery = writableDatabase.query("Settings", null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            String string = cursorQuery.getString(cursorQuery.getColumnIndex(q.b(MyApplication.b().getApplicationContext().getString(R.string.v9), MyApplication.b().getApplicationContext())));
            kotlin.b0.d.j.c(string, "c.getString(\n           …          )\n            )");
            f9164h = string;
        }
        lVar.d();
    }

    private l() {
    }

    private final void d() {
        v vVar = new v();
        vVar.a = "";
        YandexMetrica.requestAppMetricaDeviceID(new a(vVar));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String m(String str) {
        Object objValueOf;
        String strI = "";
        int i2 = 0;
        while (i2 < str.length()) {
            char cCharAt = str.charAt(i2);
            i2++;
            l lVar = a;
            if (r.P(lVar.e(), cCharAt, 0, false, 6, null) > 0) {
                objValueOf = l.k0.b.L(r.P(lVar.e(), cCharAt, 0, false, 6, null)).toUpperCase(Locale.ROOT);
                kotlin.b0.d.j.c(objValueOf, "this as java.lang.String).toUpperCase(Locale.ROOT)");
            } else {
                objValueOf = Character.valueOf(cCharAt);
            }
            strI = kotlin.b0.d.j.i(strI, objValueOf);
        }
        return strI;
    }

    public final void b() {
        if ((h().length() > 0) && p(h())) {
            b = true;
            c = true;
            f9160d = true;
        } else {
            b = false;
            c = false;
            f9160d = false;
        }
    }

    public final void c() {
        f9163g.execSQL("delete from Settings");
        b();
    }

    public final String e() {
        return f9161e;
    }

    public final boolean f() {
        if (!(f9165i.length() == 0)) {
            return b;
        }
        String string = MyApplication.b().getApplicationContext().getSharedPreferences("FINGERPRINT", 0).getString("keyIdKaScada", "");
        String str = string != null ? string : "";
        if (str.length() == 0) {
            return false;
        }
        f9165i = str;
        b();
        return b;
    }

    public final String g() {
        return f9164h;
    }

    public final String h() {
        Context applicationContext = MyApplication.b().getApplicationContext();
        Cursor cursorQuery = f9163g.query("Settings", null, null, null, null, null, null);
        if (!cursorQuery.moveToFirst()) {
            return "";
        }
        String string = cursorQuery.getString(cursorQuery.getColumnIndex(q.b(applicationContext.getResources().getString(R.string.v9), applicationContext)));
        kotlin.b0.d.j.c(string, "c.getString(c.getColumnI…(R.string.v9), context)))");
        return string;
    }

    public final String i() {
        return f9165i;
    }

    public final String j(boolean z) {
        if (f9165i.length() == 0) {
            YandexMetrica.reportError("Activation.keyIdKaScada", "keyIdKaScada пустой UNKNOWN_ERROR");
            return "UNKNOWN_ERROR";
        }
        if (!z) {
            return f9165i;
        }
        String strValueOf = String.valueOf(Integer.parseInt(new SimpleDateFormat("ss").format(new Date())) + 10);
        String upperCase = l.k0.b.M(Long.parseLong(kotlin.b0.d.j.i(strValueOf.charAt(0) + String.valueOf(Long.parseLong(f9165i, 16)), Character.valueOf(strValueOf.charAt(1))))).toUpperCase(Locale.ROOT);
        kotlin.b0.d.j.c(upperCase, "this as java.lang.String).toUpperCase(Locale.ROOT)");
        return upperCase;
    }

    public final boolean k() {
        return f9160d;
    }

    public final boolean l() {
        return c;
    }

    public final void n(String str) {
        ContentValues contentValues;
        kotlin.b0.d.j.d(str, "key");
        Context applicationContext = MyApplication.b().getApplicationContext();
        if (str.length() > 2) {
            MyApplication.b().f9044l = str;
            SQLiteDatabase sQLiteDatabase = f9163g;
            if (!sQLiteDatabase.query("Settings", null, null, null, null, null, null).moveToFirst()) {
                contentValues = new ContentValues();
            } else if (f9164h.length() > 2 && !kotlin.b0.d.j.a(f9164h, str)) {
                c();
                contentValues = new ContentValues();
            }
            contentValues.put(q.b(applicationContext.getResources().getString(R.string.v9), MyApplication.b().getApplicationContext()), str);
            sQLiteDatabase.insert("Settings", null, contentValues);
        }
        b();
    }

    public final void o(String str) {
        kotlin.b0.d.j.d(str, "<set-?>");
        f9165i = str;
    }

    public final boolean p(String str) {
        kotlin.b0.d.j.d(str, "code");
        if (f9165i.length() < 5) {
            return false;
        }
        try {
            long j2 = Long.parseLong(str, 16) / ((long) 17);
            String str2 = f9165i;
            Locale locale = Locale.ROOT;
            String upperCase = str2.toUpperCase(locale);
            kotlin.b0.d.j.c(upperCase, "this as java.lang.String).toUpperCase(Locale.ROOT)");
            String upperCase2 = l.k0.b.M(j2).toUpperCase(locale);
            kotlin.b0.d.j.c(upperCase2, "this as java.lang.String).toUpperCase(Locale.ROOT)");
            if (!kotlin.b0.d.j.a(upperCase, upperCase2)) {
                String upperCase3 = f9165i.toUpperCase(locale);
                kotlin.b0.d.j.c(upperCase3, "this as java.lang.String).toUpperCase(Locale.ROOT)");
                String upperCase4 = l.k0.b.M(j2).toUpperCase(locale);
                kotlin.b0.d.j.c(upperCase4, "this as java.lang.String).toUpperCase(Locale.ROOT)");
                if (!kotlin.b0.d.j.a(upperCase3, kotlin.b0.d.j.i("0", upperCase4))) {
                    String upperCase5 = f9165i.toUpperCase(locale);
                    kotlin.b0.d.j.c(upperCase5, "this as java.lang.String).toUpperCase(Locale.ROOT)");
                    String upperCase6 = l.k0.b.M(j2).toUpperCase(locale);
                    kotlin.b0.d.j.c(upperCase6, "this as java.lang.String).toUpperCase(Locale.ROOT)");
                    if (!kotlin.b0.d.j.a(upperCase5, kotlin.b0.d.j.i("00", upperCase6))) {
                        return false;
                    }
                }
            }
            return true;
        } catch (Exception e2) {
            YandexMetrica.reportError("!!! Activation.validateLicense", "code: " + str + " keyIdKaScada: " + f9165i, e2);
            return false;
        }
    }
}
