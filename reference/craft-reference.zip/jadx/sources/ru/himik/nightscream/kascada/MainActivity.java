package ru.himik.nightscream.kascada;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.messaging.FirebaseMessaging;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.sun.mail.imap.IMAPStore;
import com.yandex.metrica.YandexMetrica;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Bd.Export.ProjectExportActivity;
import ru.himik.nightscream.kascada.Bd.Import.ProjectImportActivity;
import ru.himik.nightscream.kascada.Bd.ProjectDeleteListActivity;
import ru.himik.nightscream.kascada.Bd.ProjectLoadListActivity;
import ru.himik.nightscream.kascada.Connections.Usb.driver.FtdiSerialDriver;
import ru.himik.nightscream.kascada.Utils.q;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class MainActivity extends androidx.appcompat.app.d {
    ru.himik.nightscream.kascada.Bd.e c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    RelativeLayout f9033d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    CountDownTimer f9034e;
    String a = "default";
    int b = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f9035f = false;

    class a implements DialogInterface.OnClickListener {
        a(MainActivity mainActivity) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class b implements PermissionListener {
        b() {
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
            Toast.makeText(MainActivity.this.getApplicationContext(), R.string.permission_denied_start_error, 1).show();
            MainActivity.this.f();
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
            MainActivity.this.f();
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
            permissionToken.continuePermissionRequest();
            MainActivity.this.f();
        }
    }

    class c implements PermissionListener {
        final /* synthetic */ View a;

        c(View view) {
            this.a = view;
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
            Toast.makeText(MainActivity.this.getApplicationContext(), R.string.permission_denied_start_error, 1).show();
            MainActivity.this.onLoadProject(this.a);
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
            MainActivity.this.onLoadProject(this.a);
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
            permissionToken.continuePermissionRequest();
            MainActivity.this.onLoadProject(this.a);
        }
    }

    class d implements PermissionListener {
        d() {
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
            Toast.makeText(MainActivity.this.getApplicationContext(), R.string.permission_denied_import, 1).show();
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
            MainActivity.this.startActivityForResult(new Intent(MainActivity.this, (Class<?>) ProjectImportActivity.class), 3);
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
            permissionToken.continuePermissionRequest();
        }
    }

    class e extends CountDownTimer {
        final /* synthetic */ Intent a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        e(long j2, long j3, Intent intent) {
            super(j2, j3);
            this.a = intent;
        }

        @Override // android.os.CountDownTimer
        public void onFinish() {
            MainActivity.this.f9033d.setVisibility(8);
            MainActivity.this.startActivity(this.a);
        }

        @Override // android.os.CountDownTimer
        public void onTick(long j2) {
        }
    }

    class f implements PermissionListener {
        f() {
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
            Toast.makeText(MainActivity.this.getApplicationContext(), R.string.permission_denied_export, 1).show();
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
            MainActivity.this.startActivity(new Intent(MainActivity.this, (Class<?>) ProjectExportActivity.class));
        }

        @Override // com.karumi.dexter.listener.single.PermissionListener
        public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
            permissionToken.continuePermissionRequest();
        }
    }

    class g implements InputFilter {
        g() {
        }

        @Override // android.text.InputFilter
        public CharSequence filter(CharSequence charSequence, int i2, int i3, Spanned spanned, int i4, int i5) {
            while (i2 < i3) {
                if (!Character.isLetterOrDigit(charSequence.charAt(i2)) && !Character.isSpaceChar(charSequence.charAt(i2)) && !"(".equals(charSequence) && !")".equals(charSequence) && !".".equals(charSequence) && !",".equals(charSequence)) {
                    Toast.makeText(MainActivity.this.getApplicationContext(), MainActivity.this.getResources().getString(R.string.incorrect_symbol), 0).show();
                    return "";
                }
                i2++;
            }
            return null;
        }
    }

    class h implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ androidx.appcompat.widget.f b;

        h(EditText editText, androidx.appcompat.widget.f fVar) {
            this.a = editText;
            this.b = fVar;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            if (this.a.getText().toString().length() > 0) {
                MainActivity.this.a = this.a.getText().toString();
            }
            SQLiteDatabase writableDatabase = MainActivity.this.c.getWritableDatabase();
            if (writableDatabase.query("TableNameProject", null, "name = ?", new String[]{MainActivity.this.a}, null, null, null).moveToFirst()) {
                Toast.makeText(MainActivity.this.getApplicationContext(), MainActivity.this.a + " " + MainActivity.this.getResources().getString(R.string.is_used), 0).show();
                return;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put(IMAPStore.ID_NAME, MainActivity.this.a);
            contentValues.put("countScreen", (Integer) 16);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
            Date date = new Date();
            contentValues.put("createdTime", simpleDateFormat.format(date));
            contentValues.put("createdDate", new SimpleDateFormat("yyyy-MM-dd").format(date));
            MainActivity.this.b = (int) writableDatabase.insert("TableNameProject", null, contentValues);
            writableDatabase.execSQL("create table pro_" + MainActivity.this.b + "_component (_id integer primary key autoincrement,componentId int,text text default 'default',width int default 100,height int default 100,x int default 300,y int default 300,textSize int default 32,connectionInfo text default '',colorText int default -65536,colorBackground int default -65536,other text default '');");
            writableDatabase.execSQL("create table pro_" + MainActivity.this.b + "_connections(_id integer primary key autoincrement,connectionsId int,name text,server text);");
            MainActivity mainActivity = MainActivity.this;
            mainActivity.g(mainActivity.a, 16, false, Integer.toString(mainActivity.b), false, 1, this.b.isChecked());
        }
    }

    class i implements DialogInterface.OnClickListener {
        i(MainActivity mainActivity) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class j implements DialogInterface.OnClickListener {
        j() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            MyApplication.b().a.d(new ru.himik.nightscream.kascada.Utils.m(7));
            MyApplication.b().a();
            MainActivity.this.finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void j(View view) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://www.hmi-kascada.ru/politika-konfidentsialnosti/")));
    }

    static /* synthetic */ void k(com.google.firebase.remoteconfig.j jVar, f.f.a.d.h.i iVar) {
        if (iVar.n()) {
            MyApplication.b().z0 = jVar.f("dialog_before_purchase");
        }
    }

    private String l(Uri uri) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri)));
        StringBuilder sb = new StringBuilder();
        while (true) {
            String line = bufferedReader.readLine();
            if (line == null) {
                break;
            }
            sb.append(line);
        }
        if (q.f(getApplicationContext(), uri) == null) {
            Toast.makeText(getApplicationContext(), R.string.toast_error_import_path, 1).show();
            return null;
        }
        h(sb.toString(), q.f(getApplicationContext(), uri));
        return null;
    }

    public void f() {
        if (Build.VERSION.SDK_INT >= 16 && e.g.e.a.a(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
            Dexter.withActivity(this).withPermission("android.permission.READ_EXTERNAL_STORAGE").withListener(new b()).check();
            return;
        }
        Cursor cursorQuery = new ru.himik.nightscream.kascada.Bd.e(this).getWritableDatabase().query("TableNameProject", null, null, null, null, null, null);
        boolean z = false;
        if (!cursorQuery.moveToLast()) {
            return;
        }
        while (true) {
            String string = cursorQuery.getString(cursorQuery.getColumnIndex(IMAPStore.ID_NAME));
            int i2 = cursorQuery.getInt(cursorQuery.getColumnIndex("_id"));
            int i3 = cursorQuery.getInt(cursorQuery.getColumnIndex("countScreen"));
            try {
                z = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex("settings"))).getBoolean("portraitMode");
            } catch (Exception unused) {
            }
            boolean z2 = z;
            if (!cursorQuery.moveToNext()) {
                g(string, i3, true, i2 + "", false, 4, z2);
                return;
            }
            z = z2;
        }
    }

    public void g(String str, int i2, boolean z, String str2, boolean z2, int i3, boolean z3) {
        Intent intent = new Intent(this, (Class<?>) mbCanvas.class);
        intent.putExtra("PROJECT_NAME", str);
        intent.putExtra("LOADING", z);
        intent.putExtra("COUNT_SCREEN", i2);
        intent.putExtra("TABLE_NAME", str2);
        intent.putExtra("STATION_MODE", z2);
        intent.putExtra("COUNT_DEVICE", i3);
        intent.putExtra("PORTRAIT_MODE", z3);
        this.f9033d.setVisibility(0);
        this.f9035f = true;
        this.f9034e = new e(2000L, 850L, intent).start();
    }

    public void getImportFile(View view) {
        Dexter.withActivity(this).withPermission("android.permission.READ_EXTERNAL_STORAGE").withListener(new d()).check();
    }

    /* JADX WARN: Code duplicated, block: B:156:0x08be A[Catch: Exception -> 0x0867, TRY_LEAVE, TryCatch #3 {Exception -> 0x0867, blocks: (B:148:0x0880, B:150:0x0891, B:153:0x08a7, B:154:0x08b6, B:156:0x08be), top: B:181:0x0880 }] */
    /* JADX WARN: Code duplicated, block: B:159:0x08e4  */
    void h(String str, String str2) {
        int i2;
        String string;
        String string2;
        String string3;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        String str9;
        String str10;
        String str11;
        String str12;
        String str13;
        String string4;
        String str14 = "pathPic_0";
        String str15 = "screen";
        String str16 = "pathSound_6";
        String str17 = "pathSound_4";
        String str18 = "jsTableComponent_other";
        String str19 = "pathSound_3";
        String str20 = "pathSound_2";
        String str21 = "";
        String str22 = "pathSound_1";
        try {
            String str23 = "pathSound_0";
            JSONObject jSONObject = new JSONObject(str);
            JSONObject jSONObject2 = jSONObject.getJSONObject("TableNameProject");
            String str24 = "pathPic_6";
            String string5 = jSONObject2.getString(IMAPStore.ID_NAME);
            String str25 = "pathPic_5";
            jSONObject2.getInt("stationMode");
            String str26 = "pathPic_4";
            int i3 = jSONObject2.getInt("countScreen");
            String string6 = jSONObject2.getString("pass");
            String str27 = "pathPic_3";
            StringBuilder sb = new StringBuilder();
            String str28 = "pathPic_2";
            String str29 = "pathPic_1";
            sb.append(str2.substring(0, str2.lastIndexOf("/") + 1));
            sb.append("help.pdf");
            String string7 = sb.toString();
            try {
                i2 = jSONObject2.getInt("countDevice");
            } catch (Exception unused) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_import_network_device), 1).show();
                i2 = 1;
            }
            try {
                string = jSONObject2.getString("deviceNetwork");
            } catch (Exception unused2) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_import_network_device), 1).show();
                string = str21;
            }
            try {
                string2 = jSONObject2.getString("systemRegisters");
            } catch (Exception unused3) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_import_sys_reg), 1).show();
                string2 = str21;
            }
            try {
                string3 = jSONObject2.getString("settings");
            } catch (Exception unused4) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.msg_error_import_settings), 1).show();
                string3 = str21;
            }
            JSONObject jSONObject3 = jSONObject2.getJSONObject("jsTableNameProject_screenBackground");
            JSONArray jSONArray = jSONObject.getJSONArray("TableComponent");
            JSONArray jSONArray2 = jSONObject.getJSONArray("TableConnections");
            SQLiteDatabase writableDatabase = this.c.getWritableDatabase();
            JSONArray jSONArray3 = jSONArray2;
            JSONArray jSONArray4 = jSONArray;
            Cursor cursorQuery = writableDatabase.query("TableNameProject", null, "name = ?", new String[]{string5}, null, null, null);
            cursorQuery.moveToFirst();
            if (cursorQuery.getCount() > 0) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.import_project_name_used), 1).show();
                return;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put(IMAPStore.ID_NAME, string5);
            contentValues.put("countScreen", Integer.valueOf(i3));
            contentValues.put("pass", string6);
            contentValues.put("countDevice", Integer.valueOf(i2));
            contentValues.put("deviceNetwork", string);
            contentValues.put("systemRegisters", string2);
            contentValues.put("settings", string3);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
            Date date = new Date();
            contentValues.put("createdTime", simpleDateFormat.format(date));
            contentValues.put("createdDate", new SimpleDateFormat("yyyy-MM-dd").format(date));
            contentValues.put("pdfDocument", string7);
            String strSubstring = str2.substring(0, str2.lastIndexOf("/") + 1);
            int i4 = 1;
            while (i4 <= 20) {
                StringBuilder sb2 = new StringBuilder();
                String str30 = str15;
                sb2.append(str30);
                sb2.append(i4);
                sb2.append("IsColor");
                if (!jSONObject3.getBoolean(sb2.toString())) {
                    if (!jSONObject3.getBoolean(str30 + i4 + "DefaultBackground")) {
                        String string8 = jSONObject3.getString(str30 + i4 + "PathImage");
                        String str31 = str30 + i4 + "PathImage";
                        jSONObject3.put(str31, strSubstring + string8.substring(string8.lastIndexOf("/") + 1));
                    }
                }
                i4++;
                str15 = str30;
            }
            contentValues.put("screenBackground", jSONObject3.toString());
            this.b = (int) writableDatabase.insert("TableNameProject", null, contentValues);
            writableDatabase.execSQL("create table pro_" + this.b + "_component (_id integer primary key autoincrement,componentId int,text text default 'default',width int default 100,height int default 100,x int default 300,y int default 300,textSize int default 32,connectionInfo text default '',colorText int default -65536,colorBackground int default -65536,other text default '');");
            ContentValues contentValues2 = new ContentValues();
            new JSONObject();
            int i5 = 0;
            while (i5 < jSONArray4.length()) {
                jSONArray4 = jSONArray4;
                JSONObject jSONObject4 = jSONArray4.getJSONObject(i5);
                int i6 = jSONObject4.getInt("componentId");
                contentValues2.put("componentId", Integer.valueOf(i6));
                contentValues2.put("text", jSONObject4.getString("text"));
                contentValues2.put("width", Integer.valueOf(jSONObject4.getInt("width")));
                contentValues2.put("height", Integer.valueOf(jSONObject4.getInt("height")));
                contentValues2.put("x", Integer.valueOf(jSONObject4.getInt("x")));
                contentValues2.put("y", Integer.valueOf(jSONObject4.getInt("y")));
                contentValues2.put("textSize", Integer.valueOf(jSONObject4.getInt("textSize")));
                contentValues2.put("connectionInfo", jSONObject4.getString("jsTableComponent_connectionInfo"));
                contentValues2.put("colorText", Integer.valueOf(jSONObject4.getInt("colorText")));
                contentValues2.put("colorBackground", Integer.valueOf(jSONObject4.getInt("colorBackground")));
                String str32 = str18;
                if (jSONObject4.getString(str32).length() <= 0) {
                    jSONArray4 = jSONArray4;
                    str3 = str16;
                    str4 = str21;
                    str5 = str23;
                    str6 = str24;
                    str7 = str25;
                    str8 = str26;
                    str9 = str27;
                    str10 = str28;
                    str11 = str29;
                    str12 = str14;
                } else if (i6 == 5) {
                    jSONArray4 = jSONArray4;
                    str3 = str16;
                    str4 = str21;
                    str5 = str23;
                    str6 = str24;
                    str7 = str25;
                    str8 = str26;
                    str9 = str27;
                    str10 = str28;
                    str11 = str29;
                    str12 = str14;
                    try {
                        JSONObject jSONObject5 = new JSONObject(jSONObject4.getString(str32));
                        if (jSONObject5.getBoolean("isImageUserOn")) {
                            String string9 = jSONObject5.getString("pathOrNameOn");
                            StringBuilder sb3 = new StringBuilder();
                            try {
                                sb3.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                                sb3.append(string9);
                                jSONObject5.put("pathOrNameOn", sb3.toString());
                                if (jSONObject5.getBoolean("isImageUserOff")) {
                                    String string10 = jSONObject5.getString("pathOrNameOff");
                                    StringBuilder sb4 = new StringBuilder();
                                    sb4.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                                    sb4.append(string10);
                                    jSONObject5.put("pathOrNameOff", sb4.toString());
                                }
                                contentValues2.put("other", jSONObject5.toString());
                            } catch (Exception unused5) {
                            }
                        } else {
                            if (jSONObject5.getBoolean("isImageUserOff")) {
                                String string11 = jSONObject5.getString("pathOrNameOff");
                                StringBuilder sb5 = new StringBuilder();
                                sb5.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                                sb5.append(string11);
                                jSONObject5.put("pathOrNameOff", sb5.toString());
                            }
                            contentValues2.put("other", jSONObject5.toString());
                        }
                    } catch (Exception unused6) {
                    }
                } else if (i6 != 21) {
                    if (i6 == 16) {
                        str13 = str24;
                        str7 = str25;
                        str8 = str26;
                        str9 = str27;
                        str10 = str28;
                        str4 = str21;
                        str11 = str29;
                        str12 = str14;
                        JSONObject jSONObject6 = new JSONObject(jSONObject4.getString(str32));
                        jSONObject6.put("pathGif", str2.substring(0, str2.lastIndexOf("/") + 1) + jSONObject6.getString("pathGif"));
                        string4 = jSONObject6.toString();
                    } else if (i6 != 17) {
                        contentValues2.put("other", jSONObject4.getString(str32));
                        jSONArray4 = jSONArray4;
                        str3 = str16;
                        str4 = str21;
                        str5 = str23;
                        str6 = str24;
                        str7 = str25;
                        str8 = str26;
                        str9 = str27;
                        str10 = str28;
                        str11 = str29;
                        str12 = str14;
                    } else {
                        JSONObject jSONObject7 = new JSONObject(jSONObject4.getString(str32));
                        String str33 = str14;
                        String string12 = jSONObject7.getString(str33);
                        String str34 = str2.substring(0, str2.lastIndexOf("/") + 1) + string12;
                        str4 = str21;
                        if (string12.equals(str4)) {
                            jSONObject7.put(str33, str4);
                        } else {
                            jSONObject7.put(str33, str34);
                        }
                        String str35 = str29;
                        String string13 = jSONObject7.getString(str35);
                        StringBuilder sb6 = new StringBuilder();
                        str12 = str33;
                        sb6.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                        sb6.append(string13);
                        String string14 = sb6.toString();
                        if (string13.equals(str4)) {
                            jSONObject7.put(str35, str4);
                        } else {
                            jSONObject7.put(str35, string14);
                        }
                        String str36 = str28;
                        String string15 = jSONObject7.getString(str36);
                        StringBuilder sb7 = new StringBuilder();
                        str11 = str35;
                        sb7.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                        sb7.append(string15);
                        String string16 = sb7.toString();
                        if (string15.equals(str4)) {
                            jSONObject7.put(str36, str4);
                        } else {
                            jSONObject7.put(str36, string16);
                        }
                        String str37 = str27;
                        String string17 = jSONObject7.getString(str37);
                        StringBuilder sb8 = new StringBuilder();
                        str10 = str36;
                        sb8.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                        sb8.append(string17);
                        String string18 = sb8.toString();
                        if (string17.equals(str4)) {
                            jSONObject7.put(str37, str4);
                        } else {
                            jSONObject7.put(str37, string18);
                        }
                        String str38 = str26;
                        String string19 = jSONObject7.getString(str38);
                        StringBuilder sb9 = new StringBuilder();
                        str9 = str37;
                        sb9.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                        sb9.append(string19);
                        String string20 = sb9.toString();
                        if (string19.equals(str4)) {
                            jSONObject7.put(str38, str4);
                        } else {
                            jSONObject7.put(str38, string20);
                        }
                        String str39 = str25;
                        String string21 = jSONObject7.getString(str39);
                        StringBuilder sb10 = new StringBuilder();
                        str8 = str38;
                        sb10.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                        sb10.append(string21);
                        String string22 = sb10.toString();
                        if (string21.equals(str4)) {
                            jSONObject7.put(str39, str4);
                        } else {
                            jSONObject7.put(str39, string22);
                        }
                        str13 = str24;
                        String string23 = jSONObject7.getString(str13);
                        StringBuilder sb11 = new StringBuilder();
                        str7 = str39;
                        sb11.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                        sb11.append(string23);
                        String string24 = sb11.toString();
                        if (string23.equals(str4)) {
                            jSONObject7.put(str13, str4);
                        } else {
                            jSONObject7.put(str13, string24);
                        }
                        String string25 = jSONObject7.getString("pathPic_7");
                        String str40 = str2.substring(0, str2.lastIndexOf("/") + 1) + string25;
                        if (string25.equals(str4)) {
                            jSONObject7.put("pathPic_7", str4);
                        } else {
                            jSONObject7.put("pathPic_7", str40);
                        }
                        try {
                            String string26 = jSONObject7.getString("pathPic_8");
                            String str41 = str2.substring(0, str2.lastIndexOf("/") + 1) + string26;
                            if (string26.equals(str4)) {
                                jSONObject7.put("pathPic_8", str4);
                            } else {
                                jSONObject7.put("pathPic_8", str41);
                            }
                            String string27 = jSONObject7.getString("pathPic_9");
                            String str42 = str2.substring(0, str2.lastIndexOf("/") + 1) + string27;
                            if (string27.equals(str4)) {
                                jSONObject7.put("pathPic_9", str4);
                            } else {
                                jSONObject7.put("pathPic_9", str42);
                            }
                            String string28 = jSONObject7.getString("pathPic_10");
                            String str43 = str2.substring(0, str2.lastIndexOf("/") + 1) + string28;
                            if (string28.equals(str4)) {
                                jSONObject7.put("pathPic_10", str4);
                            } else {
                                jSONObject7.put("pathPic_10", str43);
                            }
                            String string29 = jSONObject7.getString("pathPic_11");
                            String str44 = str2.substring(0, str2.lastIndexOf("/") + 1) + string29;
                            if (string29.equals(str4)) {
                                jSONObject7.put("pathPic_11", str4);
                            } else {
                                jSONObject7.put("pathPic_11", str44);
                            }
                            String string30 = jSONObject7.getString("pathPic_12");
                            String str45 = str2.substring(0, str2.lastIndexOf("/") + 1) + string30;
                            if (string30.equals(str4)) {
                                jSONObject7.put("pathPic_12", str4);
                            } else {
                                jSONObject7.put("pathPic_12", str45);
                            }
                            String string31 = jSONObject7.getString("pathPic_13");
                            String str46 = str2.substring(0, str2.lastIndexOf("/") + 1) + string31;
                            if (string31.equals(str4)) {
                                jSONObject7.put("pathPic_13", str4);
                            } else {
                                jSONObject7.put("pathPic_13", str46);
                            }
                            String string32 = jSONObject7.getString("pathPic_14");
                            String str47 = str2.substring(0, str2.lastIndexOf("/") + 1) + string32;
                            if (string32.equals(str4)) {
                                jSONObject7.put("pathPic_14", str4);
                            } else {
                                jSONObject7.put("pathPic_14", str47);
                            }
                            String string33 = jSONObject7.getString("pathPic_15");
                            String str48 = str2.substring(0, str2.lastIndexOf("/") + 1) + string33;
                            if (string33.equals(str4)) {
                                jSONObject7.put("pathPic_15", str4);
                            } else {
                                jSONObject7.put("pathPic_15", str48);
                            }
                        } catch (Exception unused7) {
                        }
                        string4 = jSONObject7.toString();
                    }
                    contentValues2.put("other", string4);
                    str5 = str23;
                    str6 = str13;
                    str3 = str16;
                } else {
                    jSONArray4 = jSONArray4;
                    String str49 = str24;
                    str7 = str25;
                    str8 = str26;
                    str9 = str27;
                    str10 = str28;
                    str4 = str21;
                    str11 = str29;
                    str12 = str14;
                    JSONObject jSONObject8 = new JSONObject(jSONObject4.getString(str32));
                    String str50 = str23;
                    String string34 = jSONObject8.getString(str50);
                    StringBuilder sb12 = new StringBuilder();
                    str6 = str49;
                    sb12.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                    sb12.append(string34);
                    String string35 = sb12.toString();
                    if (string34.equals(str4)) {
                        jSONObject8.put(str50, str4);
                    } else {
                        jSONObject8.put(str50, string35);
                    }
                    String str51 = str22;
                    String string36 = jSONObject8.getString(str51);
                    StringBuilder sb13 = new StringBuilder();
                    str5 = str50;
                    sb13.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                    sb13.append(string36);
                    String string37 = sb13.toString();
                    if (string36.equals(str4)) {
                        jSONObject8.put(str51, str4);
                    } else {
                        jSONObject8.put(str51, string37);
                    }
                    String str52 = str20;
                    String string38 = jSONObject8.getString(str52);
                    StringBuilder sb14 = new StringBuilder();
                    str22 = str51;
                    sb14.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                    sb14.append(string38);
                    String string39 = sb14.toString();
                    if (string38.equals(str4)) {
                        jSONObject8.put(str52, str4);
                    } else {
                        jSONObject8.put(str52, string39);
                    }
                    String str53 = str19;
                    String string40 = jSONObject8.getString(str53);
                    StringBuilder sb15 = new StringBuilder();
                    str20 = str52;
                    sb15.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                    sb15.append(string40);
                    String string41 = sb15.toString();
                    if (string40.equals(str4)) {
                        jSONObject8.put(str53, str4);
                    } else {
                        jSONObject8.put(str53, string41);
                    }
                    String str54 = str17;
                    String string42 = jSONObject8.getString(str54);
                    StringBuilder sb16 = new StringBuilder();
                    str19 = str53;
                    sb16.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                    sb16.append(string42);
                    String string43 = sb16.toString();
                    if (string42.equals(str4)) {
                        jSONObject8.put(str54, str4);
                    } else {
                        jSONObject8.put(str54, string43);
                    }
                    String string44 = jSONObject8.getString("pathSound_5");
                    String str55 = str2.substring(0, str2.lastIndexOf("/") + 1) + string44;
                    if (string44.equals(str4)) {
                        jSONObject8.put("pathSound_5", str4);
                    } else {
                        jSONObject8.put("pathSound_53", str55);
                    }
                    str3 = str16;
                    String string45 = jSONObject8.getString(str3);
                    StringBuilder sb17 = new StringBuilder();
                    str17 = str54;
                    sb17.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                    sb17.append(string45);
                    String string46 = sb17.toString();
                    if (string45.equals(str4)) {
                        jSONObject8.put(str3, str4);
                    } else {
                        jSONObject8.put(str3, string46);
                    }
                    String string47 = jSONObject8.getString("pathSound_7");
                    String str56 = str2.substring(0, str2.lastIndexOf("/") + 1) + string47;
                    if (string47.equals(str4)) {
                        jSONObject8.put("pathSound_7", str4);
                    } else {
                        jSONObject8.put("pathSound_7", str56);
                    }
                    contentValues2.put("other", jSONObject8.toString());
                }
                writableDatabase.insert("pro_" + this.b + "_component", null, contentValues2);
                i5++;
                str16 = str3;
                str18 = str32;
                str14 = str12;
                str29 = str11;
                str28 = str10;
                str27 = str9;
                str26 = str8;
                str25 = str7;
                str24 = str6;
                str23 = str5;
                str21 = str4;
            }
            writableDatabase.execSQL("create table pro_" + this.b + "_connections(_id integer primary key autoincrement,connectionsId int,name text,server text);");
            ContentValues contentValues3 = new ContentValues();
            new JSONObject();
            int i7 = 0;
            while (i7 < jSONArray3.length()) {
                JSONArray jSONArray5 = jSONArray3;
                JSONObject jSONObject9 = jSONArray5.getJSONObject(i7);
                contentValues3.put("connectionsId", Integer.valueOf(jSONObject9.getInt("connectionsId")));
                contentValues3.put(IMAPStore.ID_NAME, jSONObject9.getString(IMAPStore.ID_NAME));
                contentValues3.put("server", jSONObject9.getString("server"));
                writableDatabase.insert("pro_" + this.b + "_connections", null, contentValues3);
                i7++;
                jSONArray3 = jSONArray5;
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_import_project), 1).show();
        }
    }

    void m() {
        final com.google.firebase.remoteconfig.j jVarD = com.google.firebase.remoteconfig.j.d();
        com.google.firebase.remoteconfig.o.b bVar = new com.google.firebase.remoteconfig.o.b();
        bVar.d(30L);
        jVarD.q(bVar.c());
        jVarD.c().b(this, new f.f.a.d.h.d() { // from class: ru.himik.nightscream.kascada.b
            @Override // f.f.a.d.h.d
            public final void a(f.f.a.d.h.i iVar) {
                MainActivity.k(jVarD, iVar);
            }
        });
    }

    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onActivityResult(int i2, int i3, Intent intent) {
        super.onActivityResult(i2, i3, intent);
        if (i3 != -1) {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_project_selected), 0).show();
            return;
        }
        if (i2 == 1) {
            g(intent.getStringExtra("PROJECT_NAME"), intent.getIntExtra("COUNT_SCREEN", 1), true, intent.getStringExtra("TABLE_NAME_PRO"), false, 4, intent.getBooleanExtra("PORTRAIT_MODE", false));
        } else {
            if (i2 == 2) {
                try {
                    l(intent.getData());
                    return;
                } catch (IOException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            if (i2 != 3) {
                return;
            }
            if (!intent.getBooleanExtra("old_load", false)) {
                f();
                return;
            }
            Intent intent2 = new Intent("android.intent.action.GET_CONTENT");
            intent2.setType("*/*");
            startActivityForResult(intent2, 2);
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        CountDownTimer countDownTimer;
        if (!this.f9035f || (countDownTimer = this.f9034e) == null) {
            return;
        }
        countDownTimer.cancel();
        this.f9033d.setVisibility(8);
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        getWindow().addFlags(FtdiSerialDriver.FtdiSerialPort.USB_ENDPOINT_IN);
        setContentView(R.layout.main_menu);
        this.f9033d = (RelativeLayout) findViewById(R.id.layout_load_project);
        ((TextView) findViewById(R.id.textVersion)).setText(getResources().getString(R.string.version) + ": 1.0.7");
        ru.himik.nightscream.kascada.Bd.e eVar = new ru.himik.nightscream.kascada.Bd.e(this);
        this.c = eVar;
        Cursor cursorQuery = eVar.getWritableDatabase().query("Settings", null, null, null, null, null, null);
        String string = cursorQuery.moveToFirst() ? cursorQuery.getString(cursorQuery.getColumnIndex(q.b(getResources().getString(R.string.v9), getApplicationContext()))) : "";
        HashMap map = new HashMap();
        if (string.length() == 0) {
            map.put("license", getResources().getString(R.string.without_license));
            ((TextView) findViewById(R.id.license)).setText(getResources().getString(R.string.license) + ": " + getResources().getString(R.string.without_license));
        } else {
            map.put("license", string);
            ((TextView) findViewById(R.id.license)).setText(getResources().getString(R.string.license) + ": " + string);
            FirebaseMessaging.f().B("/topics/" + string);
            FirebaseMessaging.f().B("/topics/" + string + "Command");
        }
        FirebaseMessaging.f().B(getResources().getString(R.string.firebase_topic_news));
        YandexMetrica.reportEvent("mainActivity", map);
        boolean z = MyApplication.b().g0.getBoolean("autoStart", true);
        if (getIntent().getBooleanExtra("Exit me", false)) {
            finish();
        }
        if (z) {
            f();
        }
        ((TextView) findViewById(R.id.textHrefPrivatePolicy)).setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.a
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.a.j(view);
            }
        });
        m();
        ru.himik.nightscream.kascada.Utils.l.a.g();
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    public void onDeleteProject(View view) {
        startActivity(new Intent(this, (Class<?>) ProjectDeleteListActivity.class));
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
    }

    public void onExit(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.dialog_exit));
        builder.setPositiveButton(getResources().getString(R.string.yes), new j());
        builder.setNegativeButton(getResources().getString(R.string.no), new a(this));
        builder.show();
    }

    public void onExportProject(View view) {
        if (Build.VERSION.SDK_INT >= 16) {
            Dexter.withActivity(this).withPermission("android.permission.WRITE_EXTERNAL_STORAGE").withListener(new f()).check();
        } else {
            startActivity(new Intent(this, (Class<?>) ProjectExportActivity.class));
        }
    }

    public void onLoadProject(View view) {
        if (Build.VERSION.SDK_INT < 16 || e.g.e.a.a(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            startActivityForResult(new Intent(this, (Class<?>) ProjectLoadListActivity.class), 1);
        } else {
            Dexter.withActivity(this).withPermission("android.permission.READ_EXTERNAL_STORAGE").withListener(new c(view)).check();
        }
    }

    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onResume() {
        super.onResume();
        ru.himik.nightscream.kascada.Bd.e eVar = new ru.himik.nightscream.kascada.Bd.e(this);
        this.c = eVar;
        Cursor cursorQuery = eVar.getWritableDatabase().query("Settings", null, null, null, null, null, null);
        String string = cursorQuery.moveToFirst() ? cursorQuery.getString(cursorQuery.getColumnIndex(q.b(getResources().getString(R.string.v9), getApplicationContext()))) : "";
        MyApplication.b().g0.edit().putBoolean("autoStart", true).apply();
        if (string.length() == 0) {
            ((TextView) findViewById(R.id.license)).setText(getResources().getString(R.string.license) + ": " + getResources().getString(R.string.without_license));
        } else {
            ((TextView) findViewById(R.id.license)).setText(getResources().getString(R.string.license) + ": " + string);
            FirebaseMessaging.f().B("/topics/" + string);
        }
        if (MyApplication.b().f9045m.isEmpty()) {
            return;
        }
        Intent intent = new Intent(this, (Class<?>) ProjectImportActivity.class);
        intent.putExtra("urlUpdate", MyApplication.b().f9045m);
        startActivityForResult(intent, 3);
    }

    public void onStartWork(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.create_new_project));
        g gVar = new g();
        EditText editText = new EditText(this);
        editText.setInputType(1);
        editText.setHint(getResources().getString(R.string.set_name_project));
        editText.setFilters(new InputFilter[]{gVar});
        androidx.appcompat.widget.f fVar = new androidx.appcompat.widget.f(this);
        fVar.setChecked(false);
        fVar.setText(getResources().getString(R.string.portrait_mode));
        fVar.setHighlightColor(getResources().getColor(R.color.text_orange));
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.addView(editText);
        linearLayout.addView(fVar);
        builder.setView(linearLayout);
        builder.setPositiveButton(getResources().getString(R.string.create), new h(editText, fVar));
        builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new i(this));
        builder.show();
    }
}
