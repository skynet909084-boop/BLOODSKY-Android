package ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import androidx.appcompat.app.d;
import java.util.Random;
import ru.himik.nightscream.kascada.Connections.Usb.driver.FtdiSerialDriver;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class BridgeWiFiToUsb extends d {
    Handler a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    ImageView f9052d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    Animation f9053e;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a f9059k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.b f9060l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    Button f9061m;
    boolean b = false;
    boolean c = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f9054f = 9600;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f9055g = 8;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f9056h = 2;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f9057i = 0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    boolean f9058j = false;

    class a extends Handler {
        a() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == 0) {
                BridgeWiFiToUsb.this.b = true;
            } else if (i2 == 1) {
                BridgeWiFiToUsb.this.b = false;
            } else if (i2 == 2) {
                BridgeWiFiToUsb.this.c = true;
            } else if (i2 == 3) {
                BridgeWiFiToUsb.this.c = false;
            } else if (i2 == 4) {
                BridgeWiFiToUsb.this.f9061m.setEnabled(true);
            }
            BridgeWiFiToUsb bridgeWiFiToUsb = BridgeWiFiToUsb.this;
            if (bridgeWiFiToUsb.b && bridgeWiFiToUsb.c) {
                bridgeWiFiToUsb.f9052d.startAnimation(bridgeWiFiToUsb.f9053e);
            } else {
                bridgeWiFiToUsb.f9052d.clearAnimation();
            }
        }
    }

    class b implements DialogInterface.OnClickListener {
        b(BridgeWiFiToUsb bridgeWiFiToUsb) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
        }
    }

    class c implements DialogInterface.OnClickListener {
        final /* synthetic */ Spinner a;
        final /* synthetic */ Spinner b;
        final /* synthetic */ Spinner c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Spinner f9062d;

        c(Spinner spinner, Spinner spinner2, Spinner spinner3, Spinner spinner4) {
            this.a = spinner;
            this.b = spinner2;
            this.c = spinner3;
            this.f9062d = spinner4;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            BridgeWiFiToUsb.this.f9054f = Integer.parseInt(this.a.getSelectedItem().toString());
            BridgeWiFiToUsb.this.f9055g = Integer.parseInt(this.b.getSelectedItem().toString());
            BridgeWiFiToUsb.this.f9056h = ru.himik.nightscream.kascada.q.e.b.a.b(this.c.getSelectedItem().toString());
            BridgeWiFiToUsb.this.f9057i = ru.himik.nightscream.kascada.q.e.b.a.a(this.f9062d.getSelectedItem().toString());
        }
    }

    public void editUsb(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View viewInflate = getLayoutInflater().inflate(R.layout.alert_dialog_add_usb, (ViewGroup) null);
        Spinner spinner = (Spinner) viewInflate.findViewById(R.id.spinnerDataBits);
        spinner.setSelection(1);
        Spinner spinner2 = (Spinner) viewInflate.findViewById(R.id.spinnerBaudRate);
        spinner2.setSelection(5);
        Spinner spinner3 = (Spinner) viewInflate.findViewById(R.id.spinnerStopBits);
        spinner3.setSelection(2);
        Spinner spinner4 = (Spinner) viewInflate.findViewById(R.id.spinnerParity);
        spinner4.setSelection(0);
        builder.setView(viewInflate).setPositiveButton(getResources().getString(R.string.dialog_accept), new c(spinner2, spinner, spinner3, spinner4)).setNegativeButton(getResources().getString(R.string.dialog_cancel), new b(this));
        builder.show();
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.layout_bridge_wifi_to_usb);
        getWindow().addFlags(FtdiSerialDriver.FtdiSerialPort.USB_ENDPOINT_IN);
        this.f9052d = (ImageView) findViewById(R.id.imageArrow);
        this.f9053e = AnimationUtils.loadAnimation(this, R.anim.clockwise_rotation);
        this.f9061m = (Button) findViewById(R.id.buttonAction);
        this.a = new a();
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a aVar = this.f9059k;
        if (aVar != null) {
            aVar.b();
            this.f9059k = null;
        }
        ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.b bVar = this.f9060l;
        if (bVar != null) {
            bVar.b();
            this.f9060l = null;
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, android.app.Activity
    protected void onStop() {
        super.onStop();
        ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a aVar = this.f9059k;
        if (aVar != null) {
            aVar.b();
            this.f9059k = null;
        }
        ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.b bVar = this.f9060l;
        if (bVar != null) {
            bVar.b();
            this.f9060l = null;
        }
    }

    public void startWork(View view) {
        if (this.f9058j) {
            this.f9061m.setText(getResources().getString(R.string.open_connection));
            this.f9058j = !this.f9058j;
            ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a aVar = this.f9059k;
            if (aVar != null) {
                aVar.b();
                this.f9059k = null;
            }
            ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.b bVar = this.f9060l;
            if (bVar != null) {
                bVar.b();
                this.f9060l = null;
            }
            this.f9061m.setEnabled(false);
            return;
        }
        this.f9061m.setText(getResources().getString(R.string.close_connection));
        this.f9058j = !this.f9058j;
        ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a aVar2 = this.f9059k;
        if (aVar2 != null) {
            aVar2.b();
        }
        this.f9059k = new ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a(this.a);
        ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.b bVar2 = this.f9060l;
        if (bVar2 != null) {
            bVar2.b();
        }
        ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.b bVar3 = new ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.b(getApplicationContext(), this.a, this.f9054f, this.f9055g, this.f9056h, this.f9057i, new Random().nextInt(11));
        this.f9060l = bVar3;
        bVar3.a(this.f9059k);
        this.f9059k.a(this.f9060l);
    }
}
