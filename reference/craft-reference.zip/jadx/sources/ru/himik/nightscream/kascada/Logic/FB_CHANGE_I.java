package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.c;

/* JADX INFO: loaded from: classes2.dex */
public class FB_CHANGE_I extends c {
    private int d0;
    private boolean e0;

    public FB_CHANGE_I(Context context) {
        super(context);
        this.d0 = 0;
        this.e0 = false;
        setName("CH_I");
        s("I", 2);
        u("Q", 1);
    }

    public FB_CHANGE_I(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = 0;
        this.e0 = false;
        setName("CH_I");
        s("I", 2);
        u("Q", 1);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.d0 = 0;
        this.e0 = false;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        boolean z;
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || aVar.getOut() == null) {
            return;
        }
        if (this.d0 != ((Integer) this.f8975g.getOut()).intValue()) {
            this.d0 = ((Integer) this.f8975g.getOut()).intValue();
            z = true;
        } else {
            z = false;
        }
        this.e0 = z;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || aVar.getOut() == null) {
            return null;
        }
        return Boolean.valueOf(this.e0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 137;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a l(int i2) {
        if (i2 == 1) {
            return this.f8975g;
        }
        if (i2 != 2) {
            return null;
        }
        return this.f8976h;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.S.setStyle(Paint.Style.FILL);
        this.S.setColor(-7829368);
        this.S.setStrokeWidth(this.U);
        this.V.set(this.T, this.U, getWidth() - this.T, getHeight() - this.U);
        canvas.drawRect(this.V, this.S);
        this.S.setStyle(Paint.Style.STROKE);
        this.S.setColor(-16777216);
        canvas.drawRect(this.V, this.S);
        this.W.setTextAlign(Paint.Align.CENTER);
        canvas.drawLine(this.T, getHeight() / 3, (getWidth() - this.T) - (this.U / 2), getHeight() / 3, this.S);
        canvas.drawLine(getWidth() / 2, getHeight() / 3, getWidth() / 2, getHeight() - this.U, this.S);
        canvas.drawText(this.L, getWidth() / 2, ((getHeight() / 3) - ((getHeight() / 3) / 2)) + this.a0, this.W);
        if (this.M.length() > 0) {
            String str = this.M;
            int width2 = getWidth() / 2;
            int i2 = this.T;
            canvas.drawText(str, ((width2 - i2) / 2) + i2, ((getHeight() / 3) / 2) + (getHeight() / 3) + this.a0, this.W);
            canvas.drawLine(0.0f, ((getHeight() / 3) / 2) + (getHeight() / 3), this.T, ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        }
        if (this.O.length() > 0) {
            String str2 = this.O;
            int width3 = getWidth() / 2;
            int i3 = this.T;
            canvas.drawText(str2, ((width3 - i3) / 2) + i3, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2) + this.a0, this.W);
            canvas.drawLine(0.0f, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2), this.T, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2), this.S);
        }
        if (this.Q.length() > 0) {
            canvas.drawText(this.Q, (getWidth() / 2) + (((getWidth() / 2) - this.T) / 2), ((getHeight() / 3) / 2) + (getHeight() / 3) + this.a0, this.W);
            if (this.f8973e && this.R == 1) {
                canvas.drawCircle((getWidth() - this.T) + this.b0, ((getHeight() / 3) / 2) + (getHeight() / 3), this.b0, this.S);
                width = (getWidth() - this.T) + (this.b0 * 2);
            } else {
                width = getWidth() - this.T;
            }
            canvas.drawLine(width, ((getHeight() / 3) / 2) + (getHeight() / 3), getWidth(), ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        }
        super.onDraw(canvas);
    }
}
