package ru.himik.nightscream.kascada.c0;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import com.sun.mail.imap.IMAPStore;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import l.c0;
import l.e0;
import l.v;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.CustomDynText;
import ru.himik.nightscream.kascada.CustomComponents.CustomList;
import ru.himik.nightscream.kascada.CustomComponents.CustomSound;
import ru.himik.nightscream.kascada.CustomComponents.c;
import ru.himik.nightscream.kascada.CustomComponents.d;
import ru.himik.nightscream.kascada.CustomComponents.e;
import ru.himik.nightscream.kascada.CustomComponents.g;
import ru.himik.nightscream.kascada.CustomComponents.h;
import ru.himik.nightscream.kascada.CustomComponents.i;
import ru.himik.nightscream.kascada.CustomComponents.k;
import ru.himik.nightscream.kascada.CustomComponents.n;
import ru.himik.nightscream.kascada.CustomComponents.r;
import ru.himik.nightscream.kascada.CustomComponents.u;
import ru.himik.nightscream.kascada.CustomComponents.w;
import ru.himik.nightscream.kascada.CustomComponents.y;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.q;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class a extends h.a.a.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    byte[] f9189l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    ByteArrayInputStream f9190m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    ByteArrayOutputStream f9191n;
    public mbCanvas o;
    public Context p;
    Handler q;
    Bitmap r;
    long s;
    boolean t;
    boolean u;
    int v;

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.c0.a$a, reason: collision with other inner class name */
    class RunnableC0299a implements Runnable {
        final /* synthetic */ String a;
        final /* synthetic */ String b;
        final /* synthetic */ int c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ String f9192d;

        RunnableC0299a(a aVar, String str, String str2, int i2, String str3) {
            this.a = str;
            this.b = str2;
            this.c = i2;
            this.f9192d = str3;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                String str = ((((("Debug-infos:\n OS Version: " + System.getProperty("os.version") + "(" + Build.VERSION.INCREMENTAL + ")") + "\n OS API Level: " + Build.VERSION.SDK_INT) + "\n Device: " + Build.DEVICE) + "\n Model (and Product): " + Build.MODEL + " (" + Build.PRODUCT + ") brand: " + Build.BRAND) + "\n Abi: " + q.d()) + "\n Fingerprint: " + Build.FINGERPRINT;
                c0 c0Var = new c0();
                v.a aVar = new v.a();
                aVar.a("v1", this.a);
                aVar.a("v2", this.b);
                aVar.a("v3", String.valueOf(this.c));
                aVar.a("v4", str);
                aVar.a("v5", "107");
                v vVarB = aVar.b();
                e0.a aVar2 = new e0.a();
                aVar2.g(this.f9192d);
                aVar2.e(vVarB);
                c0Var.y(aVar2.a()).f();
            } catch (Exception unused) {
            }
        }
    }

    class b implements Runnable {
        final /* synthetic */ String a;
        final /* synthetic */ String b;
        final /* synthetic */ int c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ String f9193d;

        b(a aVar, String str, String str2, int i2, String str3) {
            this.a = str;
            this.b = str2;
            this.c = i2;
            this.f9193d = str3;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                String str = ((("Debug-infos:\n OS Version: " + System.getProperty("os.version") + "(" + Build.VERSION.INCREMENTAL + ")") + "\n OS API Level: " + Build.VERSION.SDK_INT) + "\n Device: " + Build.DEVICE) + "\n Model (and Product): " + Build.MODEL + " (" + Build.PRODUCT + ") brand: " + Build.BRAND;
                c0 c0Var = new c0();
                v.a aVar = new v.a();
                aVar.a("v1", this.a);
                aVar.a("v2", this.b);
                aVar.a("v3", String.valueOf(this.c));
                aVar.a("v4", str);
                v vVarB = aVar.b();
                e0.a aVar2 = new e0.a();
                aVar2.g(this.f9193d);
                aVar2.e(vVarB);
                c0Var.y(aVar2.a()).f();
            } catch (Exception unused) {
            }
        }
    }

    public a(int i2, Context context, Handler handler) {
        super(i2);
        new JSONObject();
        this.s = 0L;
        this.t = false;
        this.u = false;
        this.v = 1;
        this.p = context;
        this.q = handler;
        this.o = (mbCanvas) context;
        try {
            v(8000, true);
        } catch (IOException unused) {
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:210:0x065a  */
    /* JADX WARN: Code duplicated, block: B:212:0x0663  */
    /* JADX WARN: Code duplicated, block: B:215:0x0677  */
    /* JADX WARN: Code duplicated, block: B:217:0x0693  */
    /* JADX WARN: Code duplicated, block: B:223:0x06e8  */
    /* JADX WARN: Code duplicated, block: B:225:0x0704  */
    /* JADX WARN: Code duplicated, block: B:231:0x0759  */
    /* JADX WARN: Code duplicated, block: B:233:0x0775  */
    /* JADX WARN: Code duplicated, block: B:236:0x07c1  */
    /* JADX WARN: Code duplicated, block: B:238:0x07c8  */
    /* JADX WARN: Code duplicated, block: B:246:0x07fa A[PHI: r16
      0x07fa: PHI (r16v9 java.lang.String) = (r16v8 java.lang.String), (r16v11 java.lang.String) binds: [B:232:0x0773, B:441:0x07fa] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:251:0x0817  */
    /* JADX WARN: Code duplicated, block: B:253:0x0833  */
    /* JADX WARN: Code duplicated, block: B:260:0x0886  */
    /* JADX WARN: Code duplicated, block: B:540:0x06d8 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:543:0x0749 A[SYNTHETIC] */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // h.a.a.a
    public h.a.a.a.o r(h.a.a.a.m mVar) throws IOException {
        int i2;
        JSONArray jSONArray;
        int i3;
        int i4;
        int i5;
        String str;
        String str2;
        int i6;
        int iKeyAt;
        String str3;
        String str4;
        int iKeyAt2;
        String str5;
        String str6;
        i iVar;
        int i7;
        int iKeyAt3;
        int iKeyAt4;
        int i8;
        Handler handler;
        int i9;
        Message messageObtainMessage;
        h.a.a.a.n method = mVar.getMethod();
        HashMap map = new HashMap();
        if (h.a.a.a.n.PUT.equals(method) || h.a.a.a.n.POST.equals(method)) {
            try {
                mVar.f(map);
            } catch (h.a.a.a.p | IOException e2) {
                e2.printStackTrace();
            }
        }
        InputStream inputStreamOpen = null;
        String str7 = "password";
        if (mVar.g().equals("/login") && MyApplication.b().f9044l.length() > 2 && mVar.e().get("password").get(0).toUpperCase().equals(MyApplication.b().f9044l.toUpperCase())) {
            mVar.b().f(new h.a.a.a.e("auth-kascada", mVar.e().get("password").get(0).toUpperCase()));
            try {
                inputStreamOpen = this.p.getAssets().open("web/login_ok.html");
                return h.a.a.a.n(h.a.a.a.o.d.OK, "text/html", inputStreamOpen, inputStreamOpen.available());
            } catch (IOException unused) {
            }
        }
        if (mVar.b().c("auth-kascada") == null) {
            try {
                inputStreamOpen = this.p.getAssets().open("web/login.html");
                return h.a.a.a.n(h.a.a.a.o.d.OK, "text/html", inputStreamOpen, inputStreamOpen.available());
            } catch (IOException unused2) {
            }
        }
        String strG = mVar.g();
        strG.hashCode();
        byte b2 = -1;
        switch (strG.hashCode()) {
            case -1959155492:
                if (strG.equals("/getRegistersOnline")) {
                    b2 = 0;
                }
                break;
            case -1746245850:
                if (strG.equals("/getArchiveName")) {
                    b2 = 1;
                }
                break;
            case -1645087019:
                if (strG.equals("/KaScadaGetMeScreenShotPlease")) {
                    b2 = 2;
                }
                break;
            case -1493407101:
                if (strG.equals("/Data.php")) {
                    b2 = 3;
                }
                break;
            case -1183827595:
                if (strG.equals("/getControlObject")) {
                    b2 = 4;
                }
                break;
            case -1044195366:
                if (strG.equals("/onClick")) {
                    b2 = 5;
                }
                break;
            case -1013027349:
                if (strG.equals("/changeScreen")) {
                    b2 = 6;
                }
                break;
            case -871677583:
                if (strG.equals("/myScript.js")) {
                    b2 = 7;
                }
                break;
            case -669358533:
                if (strG.equals("/img/bg.png")) {
                    b2 = 8;
                }
                break;
            case -428375052:
                if (strG.equals("/getSizeScreen")) {
                    b2 = 9;
                }
                break;
            case 47:
                if (strG.equals("/")) {
                    b2 = 10;
                }
                break;
            case 54386989:
                if (strG.equals("/getParams")) {
                    b2 = 11;
                }
                break;
            case 1224258963:
                if (strG.equals("/Archive")) {
                    b2 = 12;
                }
                break;
            case 1421689611:
                if (strG.equals("/downloadArchive")) {
                    b2 = 13;
                }
                break;
            case 1842395611:
                if (strG.equals("/jquery-3.1.0.min.js")) {
                    b2 = 14;
                }
                break;
            case 1878799359:
                if (strG.equals("/fabric.min.js")) {
                    b2 = 15;
                }
                break;
        }
        String str8 = "key";
        String str9 = "w";
        String str10 = "id";
        String str11 = "screen";
        switch (b2) {
            case 0:
                if (System.currentTimeMillis() - this.s < 500) {
                    return h.a.a.a.o(h.a.a.a.o.d.NOT_MODIFIED, "text/plain", "");
                }
                JSONObject jSONObject = new JSONObject();
                try {
                    JSONObject[] jSONObjectArr = {new JSONObject(), new JSONObject(), new JSONObject(), new JSONObject(), new JSONObject(), new JSONObject(), new JSONObject(), new JSONObject(), new JSONObject()};
                    try {
                        jSONObject.put("work", this.o.f9206k);
                        for (int i10 = 0; i10 < MyApplication.b().H.size(); i10++) {
                            u uVar = (u) MyApplication.b().H.get(MyApplication.b().H.keyAt(i10));
                            if (uVar.f8903k.l() >= 0) {
                                if (uVar.f8903k.l() == 100) {
                                    jSONObjectArr[8].put(uVar.f8903k.c() + "", uVar.getValue());
                                } else {
                                    jSONObjectArr[uVar.f8903k.l()].put(uVar.f8903k.c() + "", uVar.getValue());
                                }
                            }
                        }
                        for (int i11 = 0; i11 < MyApplication.b().I.size(); i11++) {
                            ru.himik.nightscream.kascada.CustomComponents.q qVar = (ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(MyApplication.b().I.keyAt(i11));
                            if (qVar.f8865g.l() >= 0) {
                                if (qVar.f8865g.l() == 100) {
                                    jSONObjectArr[8].put(qVar.f8865g.c() + "." + ((int) qVar.f8865g.a()), qVar.getValue());
                                } else {
                                    jSONObjectArr[qVar.f8865g.l()].put(qVar.f8865g.c() + "." + ((int) qVar.f8865g.a()), qVar.getValue());
                                }
                            }
                        }
                        for (int i12 = 0; i12 < MyApplication.b().K.size(); i12++) {
                            CustomDynText customDynText = (CustomDynText) MyApplication.b().K.get(MyApplication.b().K.keyAt(i12));
                            if (customDynText.f8667i.l() >= 0) {
                                if (customDynText.f8667i.l() == 100) {
                                    jSONObjectArr[8].put(customDynText.f8667i.c() + "", customDynText.getValue());
                                } else {
                                    jSONObjectArr[customDynText.f8667i.l()].put(customDynText.f8667i.c() + "", customDynText.getValue());
                                }
                            }
                        }
                        for (int i13 = 0; i13 < MyApplication.b().M.size(); i13++) {
                            c cVar = (c) MyApplication.b().M.get(MyApplication.b().M.keyAt(i13));
                            if (cVar.f8742h.l() >= 0) {
                                if (cVar.f8742h.l() == 100) {
                                    jSONObjectArr[8].put(cVar.f8742h.c() + "." + ((int) cVar.f8742h.a()), cVar.getValue());
                                } else {
                                    jSONObjectArr[cVar.f8742h.l()].put(cVar.f8742h.c() + "." + ((int) cVar.f8742h.a()), cVar.getValue());
                                }
                            }
                        }
                        for (int i14 = 0; i14 < MyApplication.b().N.size(); i14++) {
                            w wVar = (w) MyApplication.b().N.get(MyApplication.b().N.keyAt(i14));
                            if (wVar.f8921g.l() >= 0) {
                                if (wVar.f8921g.l() == 100) {
                                    jSONObjectArr[8].put(wVar.f8921g.c() + "." + ((int) wVar.f8921g.a()), wVar.getValue());
                                } else {
                                    jSONObjectArr[wVar.f8921g.l()].put(wVar.f8921g.c() + "." + ((int) wVar.f8921g.a()), wVar.getValue());
                                }
                            }
                        }
                        for (int i15 = 0; i15 < MyApplication.b().O.size(); i15++) {
                            r rVar = (r) MyApplication.b().O.get(MyApplication.b().O.keyAt(i15));
                            if (rVar.f8874e.l() >= 0) {
                                if (rVar.f8874e.l() == 100) {
                                    jSONObjectArr[8].put(rVar.f8874e.c() + "", rVar.getValue());
                                } else {
                                    jSONObjectArr[rVar.f8874e.l()].put(rVar.f8874e.c() + "", rVar.getValue());
                                }
                            }
                        }
                        for (int i16 = 0; i16 < MyApplication.b().P.size(); i16++) {
                            g gVar = (g) MyApplication.b().P.get(MyApplication.b().P.keyAt(i16));
                            if (gVar.I.l() >= 0) {
                                if (gVar.I.l() == 100) {
                                    jSONObjectArr[8].put(gVar.I.c() + "", gVar.getValue());
                                } else {
                                    jSONObjectArr[gVar.I.l()].put(gVar.I.c() + "", gVar.getValue());
                                }
                            }
                        }
                        for (int i17 = 0; i17 < MyApplication.b().S.size(); i17++) {
                            d dVar = (d) MyApplication.b().S.get(MyApplication.b().S.keyAt(i17));
                            if (dVar.f8753h.l() >= 0) {
                                if (dVar.f8753h.l() == 100) {
                                    jSONObjectArr[8].put(dVar.f8753h.c() + "." + ((int) dVar.f8753h.a()), dVar.getValue());
                                } else {
                                    jSONObjectArr[dVar.f8753h.l()].put(dVar.f8753h.c() + "." + ((int) dVar.f8753h.a()), dVar.getValue());
                                }
                            }
                        }
                        for (int i18 = 0; i18 < MyApplication.b().T.size(); i18++) {
                            n nVar = (n) MyApplication.b().T.get(MyApplication.b().T.keyAt(i18));
                            if (nVar.f8854g.l() >= 0) {
                                if (nVar.f8854g.l() == 100) {
                                    jSONObjectArr[8].put(nVar.f8854g.c() + "." + ((int) nVar.f8854g.a()), nVar.getValue());
                                } else {
                                    jSONObjectArr[nVar.f8854g.l()].put(nVar.f8854g.c() + "." + ((int) nVar.f8854g.a()), nVar.getValue());
                                }
                            }
                        }
                        for (int i19 = 0; i19 < MyApplication.b().U.size(); i19++) {
                            h hVar = (h) MyApplication.b().U.get(MyApplication.b().U.keyAt(i19));
                            if (hVar.f8798e.l() >= 0) {
                                if (hVar.f8798e.l() == 100) {
                                    jSONObjectArr[8].put(hVar.f8798e.c() + "", hVar.getValueWeb());
                                } else {
                                    jSONObjectArr[hVar.f8798e.l()].put(hVar.f8798e.c() + "", hVar.getValueWeb());
                                }
                            }
                        }
                        for (int i20 = 0; i20 < MyApplication.b().W.size(); i20++) {
                            k kVar = (k) MyApplication.b().W.get(MyApplication.b().W.keyAt(i20));
                            if (kVar.f8832g.l() >= 0) {
                                if (kVar.f8832g.l() == 100) {
                                    jSONObjectArr[8].put(kVar.f8832g.c() + "", kVar.getValueSource());
                                } else {
                                    jSONObjectArr[kVar.f8832g.l()].put(kVar.f8832g.c() + "", kVar.getValueSource());
                                }
                            }
                        }
                        for (int i21 = 0; i21 < MyApplication.b().X.size(); i21++) {
                            CustomList customList = (CustomList) MyApplication.b().X.get(MyApplication.b().X.keyAt(i21));
                            if (customList.f8687i.l() >= 0) {
                                if (customList.f8687i.l() == 100) {
                                    jSONObjectArr[8].put(customList.f8687i.c() + "", customList.getValue());
                                } else {
                                    jSONObjectArr[customList.f8687i.l()].put(customList.f8687i.c() + "", customList.getValue());
                                }
                            }
                        }
                        for (int i22 = 0; i22 < MyApplication.b().Y.size(); i22++) {
                            CustomSound customSound = (CustomSound) MyApplication.b().Y.get(MyApplication.b().Y.keyAt(i22));
                            if (customSound.f8696g.l() >= 0) {
                                if (customSound.f8696g.l() == 100) {
                                    jSONObjectArr[8].put(customSound.f8696g.c() + "", customSound.getValue());
                                } else {
                                    jSONObjectArr[customSound.f8696g.l()].put(customSound.f8696g.c() + "", customSound.getValue());
                                }
                            }
                        }
                        jSONObject.put("device_1", jSONObjectArr[0]);
                        jSONObject.put("device_2", jSONObjectArr[1]);
                        jSONObject.put("device_3", jSONObjectArr[2]);
                        jSONObject.put("device_4", jSONObjectArr[3]);
                        jSONObject.put("device_5", jSONObjectArr[4]);
                        jSONObject.put("device_6", jSONObjectArr[5]);
                        jSONObject.put("device_7", jSONObjectArr[6]);
                        jSONObject.put("device_8", jSONObjectArr[7]);
                        jSONObject.put("systemRegisters", jSONObjectArr[8]);
                        this.s = System.currentTimeMillis();
                        return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", jSONObject.toString());
                    } catch (Exception e3) {
                        return h.a.a.a.o(h.a.a.a.o.d.INTERNAL_ERROR, "text/plain", e3.getMessage());
                    }
                } catch (Exception unused3) {
                }
                break;
            case 1:
                JSONObject jSONObject2 = new JSONObject();
                try {
                    jSONObject2.put("countArchive", MyApplication.b().S.size());
                    for (int i23 = 0; i23 < MyApplication.b().S.size(); i23++) {
                        jSONObject2.put("Archive_" + i23, ((d) MyApplication.b().S.get(MyApplication.b().S.keyAt(i23))).getFileName());
                    }
                } catch (JSONException e4) {
                    e4.printStackTrace();
                }
                return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", jSONObject2.toString());
            case 2:
                try {
                    System.currentTimeMillis();
                    this.f9191n = new ByteArrayOutputStream();
                    mbCanvas.X0.setDrawingCacheEnabled(true);
                    Bitmap bitmapCreateBitmap = Bitmap.createBitmap(mbCanvas.X0.getDrawingCache());
                    this.r = bitmapCreateBitmap;
                    bitmapCreateBitmap.compress(Bitmap.CompressFormat.JPEG, 30, this.f9191n);
                    mbCanvas.X0.setDrawingCacheEnabled(false);
                    this.f9189l = this.f9191n.toByteArray();
                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.f9189l);
                    this.f9190m = byteArrayInputStream;
                    this.v = mbCanvas.a1;
                    return h.a.a.a.n(h.a.a.a.o.d.OK, "image/jpeg", byteArrayInputStream, byteArrayInputStream.available());
                } catch (Exception unused4) {
                }
                break;
            case 3:
                mVar.e().get("prm1");
                return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", "Всё ОК");
            case 4:
                str7 = "password";
                i2 = Integer.parseInt(mVar.e().get(str11).get(0));
                if (i2 == 0) {
                    return h.a.a.a.o(h.a.a.a.o.d.NOT_FOUND, "text/plain", "screen = 0 ???");
                }
                jSONArray = new JSONArray();
                for (i3 = 0; i3 < MyApplication.b().J.size(); i3++) {
                    iKeyAt4 = MyApplication.b().J.keyAt(i3);
                    if (((e) MyApplication.b().J.get(iKeyAt4)).getNumScreen() == i2) {
                        JSONObject jSONObject3 = new JSONObject();
                        e eVar = (e) MyApplication.b().J.get(iKeyAt4);
                        try {
                            jSONObject3.put("id", eVar.getIdComponent());
                            jSONObject3.put("key", iKeyAt4);
                            jSONObject3.put("x", (int) eVar.getX());
                            jSONObject3.put("y", (int) eVar.getY());
                            jSONObject3.put("screen", eVar.getNumScreen());
                            jSONObject3.put("w", eVar.getWidth());
                            jSONObject3.put("h", eVar.getHeight());
                            jSONArray.put(jSONObject3);
                        } catch (JSONException unused5) {
                        }
                    }
                }
                for (i4 = 0; i4 < MyApplication.b().F.size(); i4++) {
                    iKeyAt3 = MyApplication.b().F.keyAt(i4);
                    if (((y) MyApplication.b().F.get(iKeyAt3)).getNumScreen() == i2) {
                        JSONObject jSONObject4 = new JSONObject();
                        y yVar = (y) MyApplication.b().F.get(iKeyAt3);
                        try {
                            jSONObject4.put(str10, yVar.getIdComponent());
                            jSONObject4.put(str8, iKeyAt3);
                            jSONObject4.put("x", (int) yVar.getX());
                            jSONObject4.put("y", (int) yVar.getY());
                            jSONObject4.put(str11, yVar.getNumScreen());
                            jSONObject4.put(str9, yVar.getWidth());
                            jSONObject4.put("h", yVar.getHeight());
                            jSONArray.put(jSONObject4);
                        } catch (JSONException unused6) {
                        }
                    }
                }
                i5 = 0;
                while (i5 < MyApplication.b().L.size()) {
                    iKeyAt2 = MyApplication.b().L.keyAt(i5);
                    if (((i) MyApplication.b().L.get(iKeyAt2)).getNumScreen() == i2) {
                        JSONObject jSONObject5 = new JSONObject();
                        iVar = (i) MyApplication.b().L.get(iKeyAt2);
                        try {
                            jSONObject5.put(str10, iVar.getIdComponent());
                            jSONObject5.put(str8, iKeyAt2);
                            jSONObject5.put("x", (int) iVar.getX());
                            jSONObject5.put("y", (int) iVar.getY());
                            jSONObject5.put(str11, iVar.getNumScreen());
                            jSONObject5.put(str9, iVar.getWidth());
                            jSONObject5.put("h", iVar.getHeight());
                            if (iVar.getPassword().length() > 0) {
                                i7 = 1;
                            } else {
                                i7 = 0;
                            }
                            try {
                                jSONObject5.put(str7, i7);
                                str7 = str7;
                                jSONObject5.put("type", iVar.getType());
                                str5 = str11;
                                str6 = str9;
                                try {
                                    jSONObject5.put("min", iVar.getMinValue());
                                    jSONObject5.put("max", iVar.getMaxValue());
                                    jSONArray.put(jSONObject5);
                                } catch (JSONException unused7) {
                                }
                            } catch (JSONException unused8) {
                                str5 = str11;
                                str6 = str9;
                                str7 = str7;
                            }
                        } catch (JSONException unused9) {
                            str5 = str11;
                            str6 = str9;
                        }
                    } else {
                        str5 = str11;
                        str6 = str9;
                    }
                    i5++;
                    str11 = str5;
                    str9 = str6;
                }
                str = str11;
                str2 = str9;
                i6 = 0;
                while (i6 < MyApplication.b().Q.size()) {
                    iKeyAt = MyApplication.b().Q.keyAt(i6);
                    if (((ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(iKeyAt)).getNumScreen() == i2) {
                        JSONObject jSONObject6 = new JSONObject();
                        ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(iKeyAt);
                        try {
                            jSONObject6.put(str10, vVar.getIdComponent());
                            jSONObject6.put(str8, iKeyAt);
                            jSONObject6.put("x", (int) vVar.getX());
                            jSONObject6.put("y", (int) vVar.getY());
                            str3 = str;
                            try {
                                jSONObject6.put(str3, vVar.getNumScreen());
                                str4 = str2;
                                try {
                                    jSONObject6.put(str4, vVar.getWidth());
                                    jSONObject6.put("h", vVar.getHeight());
                                    jSONObject6.put("max", vVar.getMax());
                                    jSONArray.put(jSONObject6);
                                } catch (JSONException unused10) {
                                }
                            } catch (JSONException unused11) {
                                str4 = str2;
                            }
                        } catch (JSONException unused12) {
                            str3 = str;
                        }
                    } else {
                        str3 = str;
                        str4 = str2;
                    }
                    i6++;
                    str = str3;
                    str2 = str4;
                }
                return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", jSONArray.toString());
            case 5:
                try {
                    if (!this.o.f9206k) {
                        return h.a.a.a.o(h.a.a.a.o.d.NOT_FOUND, "text/plain", "!work");
                    }
                    int i24 = Integer.parseInt(mVar.e().get("id").get(0));
                    int i25 = Integer.parseInt(mVar.e().get("key").get(0));
                    if (i24 != 1) {
                        if (i24 != 6) {
                            if (i24 == 8) {
                                float f2 = Float.parseFloat(mVar.e().get("val").get(0));
                                String str12 = mVar.e().get("pass").get(0);
                                JSONObject jSONObject7 = new JSONObject();
                                jSONObject7.put("val", f2);
                                jSONObject7.put("pass", str12);
                                messageObtainMessage = this.q.obtainMessage(14, 8, i25, jSONObject7);
                            } else if (i24 == 13) {
                                messageObtainMessage = this.q.obtainMessage(14, 13, i25, Integer.valueOf(Integer.parseInt(mVar.e().get("val").get(0))));
                            }
                            messageObtainMessage.sendToTarget();
                        } else {
                            handler = this.q;
                            i9 = 6;
                            i8 = 14;
                        }
                        return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", "onCLick");
                    }
                    i8 = 14;
                    handler = this.q;
                    i9 = 1;
                    messageObtainMessage = handler.obtainMessage(i8, i9, i25);
                    messageObtainMessage.sendToTarget();
                    return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", "onCLick");
                } catch (Exception unused13) {
                    return h.a.a.a.o(h.a.a.a.o.d.INTERNAL_ERROR, "text/plain", "Error Exception");
                }
            case 6:
                try {
                    this.q.obtainMessage(14, 100, Integer.parseInt(mVar.e().get("screen").get(0)), mVar.e().get("pass").get(0)).sendToTarget();
                    break;
                } catch (Exception unused14) {
                }
                return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", "");
            case 7:
                try {
                    inputStreamOpen = this.p.getAssets().open("web/myScript.js");
                } catch (IOException unused15) {
                }
                try {
                    return h.a.a.a.n(h.a.a.a.o.d.OK, "application/javascript", inputStreamOpen, inputStreamOpen.available());
                } catch (IOException unused16) {
                }
                break;
            case 8:
                try {
                    inputStreamOpen = this.p.getAssets().open("web/img/bg.png");
                    break;
                } catch (IOException unused17) {
                }
                try {
                    return h.a.a.a.n(h.a.a.a.o.d.OK, "application/javascript", inputStreamOpen, inputStreamOpen.available());
                } catch (IOException unused18) {
                }
                break;
            case 9:
                JSONObject jSONObject8 = new JSONObject();
                try {
                    jSONObject8.put("h", MyApplication.b().f9041i);
                    jSONObject8.put("w", MyApplication.b().f9040h);
                    break;
                } catch (JSONException unused19) {
                }
                return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", jSONObject8.toString());
            case 10:
                try {
                    inputStreamOpen = this.p.getAssets().open("web/KascadaWebControl.html");
                } catch (IOException unused20) {
                }
                try {
                    return h.a.a.a.n(h.a.a.a.o.d.OK, "text/html", inputStreamOpen, inputStreamOpen.available());
                } catch (Exception unused21) {
                }
                break;
            case 11:
                JSONObject jSONObject9 = new JSONObject();
                JSONArray jSONArray2 = new JSONArray();
                try {
                    jSONObject9.put("work", this.o.f9206k);
                    if (this.o.f9206k) {
                        jSONObject9.put("cScreen", MyApplication.b().o);
                        int i26 = 0;
                        while (i26 < MyApplication.b().o) {
                            JSONObject jSONObject10 = new JSONObject();
                            int i27 = i26 + 1;
                            jSONObject10.put("num", i27);
                            jSONObject10.put(IMAPStore.ID_NAME, MyApplication.b().C.get(i26).d());
                            jSONObject10.put("pass", MyApplication.b().C.get(i26).e().length() > 0 ? 1 : 0);
                            jSONArray2.put(jSONObject10);
                            i26 = i27;
                        }
                    } else {
                        jSONObject9.put("cScreen", mbCanvas.b1);
                        int i28 = 0;
                        while (i28 < mbCanvas.b1) {
                            JSONObject jSONObject11 = new JSONObject();
                            int i29 = i28 + 1;
                            jSONObject11.put("num", i29);
                            jSONObject11.put(IMAPStore.ID_NAME, MyApplication.b().C.get(i28).d());
                            jSONObject11.put("pass", MyApplication.b().C.get(i28).e().length() > 0 ? 1 : 0);
                            jSONArray2.put(jSONObject11);
                            i28 = i29;
                        }
                    }
                    jSONObject9.put("Screens", jSONArray2);
                    jSONObject9.put("sendScreen", this.v);
                    break;
                } catch (JSONException unused22) {
                }
                return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", jSONObject9.toString());
            case 12:
                String str13 = MyApplication.b().S.size() == 0 ? "<html><head><script src='/jquery-3.1.0.min.js' type='text/javascript'></script><title>KaScada Archive</title><style>body{background: #373737 url(\"/img/bg.png\") 0 0 repeat;}</style></head><body><center><h1><font color=\"green\">KaScada Архивы</font></h1><br><font style=\"color:red;\">Архивов в этом проекте нет. </font>" : "<html><head><script src='/jquery-3.1.0.min.js' type='text/javascript'></script><title>KaScada Archive</title><style>body{background: #373737 url(\"/img/bg.png\") 0 0 repeat;}</style></head><body><center><h1><font color=\"green\">KaScada Архивы</font></h1><br>";
                for (int i30 = 0; i30 < MyApplication.b().S.size(); i30++) {
                    int iKeyAt5 = MyApplication.b().S.keyAt(i30);
                    str13 = str13 + "<input type=\"button\" value=\"Скачать " + ((d) MyApplication.b().S.get(iKeyAt5)).getFileName() + "\" onClick=\"window.open('/downloadArchive?name=" + ((d) MyApplication.b().S.get(iKeyAt5)).getFileName() + "');\"></button><br>";
                }
                return h.a.a.a.p(str13 + "</center></body></html>");
            case 13:
                try {
                    String str14 = mVar.d().get(IMAPStore.ID_NAME) + "";
                    StringBuilder sb = new StringBuilder();
                    for (int i31 = 0; i31 < MyApplication.b().S.size(); i31++) {
                        int iKeyAt6 = MyApplication.b().S.keyAt(i31);
                        if (((d) MyApplication.b().S.get(iKeyAt6)).getFileName().equals(str14)) {
                            Cursor cursorRawQuery = ((d) MyApplication.b().S.get(iKeyAt6)).getDb().rawQuery("SELECT * FROM Archive", null);
                            try {
                                if (cursorRawQuery.moveToFirst()) {
                                    while (true) {
                                        String str15 = str7;
                                        try {
                                            String str16 = str8;
                                            try {
                                                String str17 = str10;
                                                try {
                                                    String str18 = str11;
                                                    try {
                                                        String str19 = str9;
                                                        try {
                                                            sb.append(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var1")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var2")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var3")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var4")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var5")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("_time")) + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("_date")));
                                                            sb.append("\n");
                                                            if (!cursorRawQuery.moveToNext()) {
                                                                ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(sb.toString().getBytes());
                                                                h.a.a.a.o oVarN = h.a.a.a.n(h.a.a.a.o.d.OK, "application/octet-stream", byteArrayInputStream2, byteArrayInputStream2.available());
                                                                oVarN.c("Content-Disposition", "attachment; filename=\"" + str14 + ".csv\"");
                                                                return oVarN;
                                                            }
                                                            str7 = str15;
                                                            str8 = str16;
                                                            str10 = str17;
                                                            str11 = str18;
                                                            str9 = str19;
                                                        } catch (Exception unused23) {
                                                        }
                                                    } catch (Exception unused24) {
                                                    }
                                                } catch (Exception unused25) {
                                                }
                                            } catch (Exception unused26) {
                                            }
                                        } catch (Exception unused27) {
                                        }
                                    }
                                }
                            } catch (Exception unused28) {
                            }
                            ByteArrayInputStream byteArrayInputStream3 = new ByteArrayInputStream(sb.toString().getBytes());
                            h.a.a.a.o oVarN2 = h.a.a.a.n(h.a.a.a.o.d.OK, "application/octet-stream", byteArrayInputStream3, byteArrayInputStream3.available());
                            oVarN2.c("Content-Disposition", "attachment; filename=\"" + str14 + ".csv\"");
                            return oVarN2;
                        }
                        try {
                        } catch (Exception unused29) {
                        }
                        i2 = Integer.parseInt(mVar.e().get(str11).get(0));
                        if (i2 == 0) {
                            return h.a.a.a.o(h.a.a.a.o.d.NOT_FOUND, "text/plain", "screen = 0 ???");
                        }
                        jSONArray = new JSONArray();
                        while (i3 < MyApplication.b().J.size()) {
                            iKeyAt4 = MyApplication.b().J.keyAt(i3);
                            if (((e) MyApplication.b().J.get(iKeyAt4)).getNumScreen() == i2) {
                                JSONObject jSONObject12 = new JSONObject();
                                e eVar2 = (e) MyApplication.b().J.get(iKeyAt4);
                                jSONObject12.put("id", eVar2.getIdComponent());
                                jSONObject12.put("key", iKeyAt4);
                                jSONObject12.put("x", (int) eVar2.getX());
                                jSONObject12.put("y", (int) eVar2.getY());
                                jSONObject12.put("screen", eVar2.getNumScreen());
                                jSONObject12.put("w", eVar2.getWidth());
                                jSONObject12.put("h", eVar2.getHeight());
                                jSONArray.put(jSONObject12);
                            }
                        }
                        while (i4 < MyApplication.b().F.size()) {
                            iKeyAt3 = MyApplication.b().F.keyAt(i4);
                            if (((y) MyApplication.b().F.get(iKeyAt3)).getNumScreen() == i2) {
                                JSONObject jSONObject13 = new JSONObject();
                                y yVar2 = (y) MyApplication.b().F.get(iKeyAt3);
                                jSONObject13.put(str10, yVar2.getIdComponent());
                                jSONObject13.put(str8, iKeyAt3);
                                jSONObject13.put("x", (int) yVar2.getX());
                                jSONObject13.put("y", (int) yVar2.getY());
                                jSONObject13.put(str11, yVar2.getNumScreen());
                                jSONObject13.put(str9, yVar2.getWidth());
                                jSONObject13.put("h", yVar2.getHeight());
                                jSONArray.put(jSONObject13);
                            }
                        }
                        i5 = 0;
                        while (i5 < MyApplication.b().L.size()) {
                            iKeyAt2 = MyApplication.b().L.keyAt(i5);
                            if (((i) MyApplication.b().L.get(iKeyAt2)).getNumScreen() == i2) {
                                JSONObject jSONObject14 = new JSONObject();
                                iVar = (i) MyApplication.b().L.get(iKeyAt2);
                                jSONObject14.put(str10, iVar.getIdComponent());
                                jSONObject14.put(str8, iKeyAt2);
                                jSONObject14.put("x", (int) iVar.getX());
                                jSONObject14.put("y", (int) iVar.getY());
                                jSONObject14.put(str11, iVar.getNumScreen());
                                jSONObject14.put(str9, iVar.getWidth());
                                jSONObject14.put("h", iVar.getHeight());
                                if (iVar.getPassword().length() > 0) {
                                    i7 = 1;
                                } else {
                                    i7 = 0;
                                }
                                jSONObject14.put(str7, i7);
                                str7 = str7;
                                jSONObject14.put("type", iVar.getType());
                                str5 = str11;
                                str6 = str9;
                                jSONObject14.put("min", iVar.getMinValue());
                                jSONObject14.put("max", iVar.getMaxValue());
                                jSONArray.put(jSONObject14);
                            } else {
                                str5 = str11;
                                str6 = str9;
                            }
                            i5++;
                            str11 = str5;
                            str9 = str6;
                        }
                        str = str11;
                        str2 = str9;
                        i6 = 0;
                        while (i6 < MyApplication.b().Q.size()) {
                            iKeyAt = MyApplication.b().Q.keyAt(i6);
                            if (((ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(iKeyAt)).getNumScreen() == i2) {
                                JSONObject jSONObject15 = new JSONObject();
                                ru.himik.nightscream.kascada.CustomComponents.v vVar2 = (ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(iKeyAt);
                                jSONObject15.put(str10, vVar2.getIdComponent());
                                jSONObject15.put(str8, iKeyAt);
                                jSONObject15.put("x", (int) vVar2.getX());
                                jSONObject15.put("y", (int) vVar2.getY());
                                str3 = str;
                                jSONObject15.put(str3, vVar2.getNumScreen());
                                str4 = str2;
                                jSONObject15.put(str4, vVar2.getWidth());
                                jSONObject15.put("h", vVar2.getHeight());
                                jSONObject15.put("max", vVar2.getMax());
                                jSONArray.put(jSONObject15);
                            } else {
                                str3 = str;
                                str4 = str2;
                            }
                            i6++;
                            str = str3;
                            str2 = str4;
                        }
                        return h.a.a.a.o(h.a.a.a.o.d.OK, "text/plain", jSONArray.toString());
                    }
                    return h.a.a.a.o(h.a.a.a.o.d.NOT_FOUND, "", "");
                } catch (Exception unused30) {
                }
                break;
            case 14:
                try {
                    inputStreamOpen = this.p.getAssets().open("web/jquery-3.1.0.min.js");
                    break;
                } catch (IOException unused31) {
                }
                try {
                    return h.a.a.a.n(h.a.a.a.o.d.OK, "application/javascript", inputStreamOpen, inputStreamOpen.available());
                } catch (IOException unused32) {
                }
                break;
            case 15:
                try {
                    inputStreamOpen = this.p.getAssets().open("web/fabric.min.js");
                    break;
                } catch (IOException unused33) {
                }
                try {
                    return h.a.a.a.n(h.a.a.a.o.d.OK, "application/javascript", inputStreamOpen, inputStreamOpen.available());
                } catch (IOException unused34) {
                }
                break;
            default:
                return h.a.a.a.o(h.a.a.a.o.d.NOT_FOUND, "", "");
        }
    }

    public void y(String str, String str2, int i2, String str3) {
        if (this.t) {
            return;
        }
        new Thread(new RunnableC0299a(this, str, str2, i2, str3)).start();
        this.t = true;
    }

    public void z(String str, String str2, int i2, String str3) {
        if (this.u) {
            return;
        }
        new Thread(new b(this, str, str2, i2, str3)).start();
        this.u = true;
    }
}
