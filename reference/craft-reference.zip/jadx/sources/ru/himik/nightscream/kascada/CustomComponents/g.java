package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import kotlin.KotlinVersion;
import org.json.JSONException;
import org.json.JSONObject;
import org.videolan.libvlc.media.MediaPlayer;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class g extends View implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    private int C;
    private Bitmap D;
    public String E;
    int F;
    int G;
    public byte H;
    public ru.himik.nightscream.kascada.CustomComponents.b I;
    int J;
    int K;
    int L;
    int M;
    int N;
    boolean O;
    private boolean P;
    private boolean Q;
    Bitmap R;
    Paint S;
    Paint T;
    int U;
    int V;
    int W;
    private double a;
    boolean a0;
    private double b;
    int b0;
    private int c;
    int c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private double f8786d;
    private long d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f8787e;
    public Point e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private c f8788f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private List<b> f8789g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private Paint f8790h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Paint f8791i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private Paint f8792j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private Paint f8793k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Paint f8794l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private Paint f8795m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private Paint f8796n;
    private Paint o;

    class a implements c {
        a(g gVar) {
        }

        @Override // ru.himik.nightscream.kascada.CustomComponents.g.c
        public String a(double d2, double d3) {
            return String.valueOf((int) Math.round(d2));
        }
    }

    public static class b {
        private int a;
        private double b;
        private double c;

        public b(int i2, double d2, double d3) {
            this.a = i2;
            this.b = d2;
            this.c = d3;
        }

        public double a() {
            return this.b;
        }

        public int b() {
            return this.a;
        }

        public double c() {
            return this.c;
        }
    }

    public interface c {
        String a(double d2, double d3);
    }

    public g(Context context) {
        super(context);
        this.a = 100.0d;
        this.b = 0.0d;
        this.c = Color.rgb(180, 180, 180);
        this.f8786d = 20.0d;
        this.f8787e = 2;
        this.f8789g = new ArrayList();
        this.E = getResources().getString(R.string.custom_gauge);
        this.F = 12;
        this.H = (byte) 3;
        this.I = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.K = Color.parseColor("#FF277454");
        this.L = -7829368;
        this.M = -16777216;
        this.N = -16777216;
        this.O = true;
        this.R = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.S = new Paint();
        this.T = new Paint();
        this.U = 0;
        this.V = 0;
        this.W = 0;
        this.a0 = false;
        this.b0 = 0;
        this.c0 = 0;
        this.d0 = 0L;
        this.e0 = new Point();
        g();
        setLabelTextSize(Math.round(getResources().getDisplayMetrics().density * 12.0f));
    }

    private void c(Canvas canvas) {
        canvas.drawArc(f(canvas, 0.9f), 180.0f, 180.0f, true, this.f8791i);
        canvas.drawArc(f(canvas, 0.7f), 180.0f, 180.0f, true, this.f8792j);
    }

    private void d(Canvas canvas) {
        RectF rectFF = f(canvas, 1.0f);
        float fWidth = (rectFF.width() * 0.35f) + 10.0f;
        RectF rectFF2 = f(canvas, 0.2f);
        float speed = ((float) ((getSpeed() / getMaxSpeed()) * 160.0d)) + 10.0f;
        double d2 = ((double) ((180.0f - speed) / 180.0f)) * 3.141592653589793d;
        double d3 = ((double) (speed / 180.0f)) * 3.141592653589793d;
        double d4 = fWidth;
        canvas.drawLine((float) (((double) rectFF.centerX()) + (Math.cos(d2) * ((double) rectFF2.width()) * 0.5d)), (float) (((double) rectFF.centerY()) - ((Math.sin(d3) * ((double) rectFF2.width())) * 0.5d)), (float) (((double) rectFF.centerX()) + (Math.cos(d2) * d4)), (float) (((double) rectFF.centerY()) - (Math.sin(d3) * d4)), this.f8794l);
        canvas.drawArc(rectFF2, 180.0f, 180.0f, true, this.f8790h);
    }

    private void e(Canvas canvas) {
        double d2;
        Canvas canvas2 = canvas;
        float f2 = (float) ((this.f8786d / this.a) * ((double) 160.0f));
        float f3 = f2 / (this.f8787e + 1);
        RectF rectFF = f(canvas2, 1.0f);
        float fWidth = rectFF.width() * 0.35f;
        double d3 = 0.0d;
        float f4 = 10.0f;
        while (f4 <= 170.0f) {
            double d4 = ((double) ((180.0f - f4) / 180.0f)) * 3.141592653589793d;
            float f5 = f2;
            double d5 = fWidth - 15.0f;
            double d6 = d3;
            double d7 = ((double) (f4 / 180.0f)) * 3.141592653589793d;
            float f6 = fWidth;
            float f7 = f4;
            double d8 = fWidth + 15.0f;
            canvas.drawLine((float) (((double) rectFF.centerX()) + (Math.cos(d4) * d5)), (float) (((double) rectFF.centerY()) - (Math.sin(d7) * d5)), (float) (((double) rectFF.centerX()) + (Math.cos(d4) * d8)), (float) (((double) rectFF.centerY()) - (Math.sin(d7) * d8)), this.f8795m);
            int i2 = 1;
            while (i2 <= this.f8787e) {
                float f8 = f7 + (i2 * f3);
                if (f8 >= (f3 / 2.0f) + 170.0f) {
                    break;
                }
                double d9 = ((double) ((180.0f - f8) / 180.0f)) * 3.141592653589793d;
                float f9 = f6;
                double d10 = f9;
                double d11 = ((double) (f8 / 180.0f)) * 3.141592653589793d;
                canvas.drawLine((float) (((double) rectFF.centerX()) + (Math.cos(d9) * d10)), (float) (((double) rectFF.centerY()) - (Math.sin(d11) * d10)), (float) (((double) rectFF.centerX()) + (Math.cos(d9) * d8)), (float) (((double) rectFF.centerY()) - (Math.sin(d11) * d8)), this.f8795m);
                i2++;
                f3 = f3;
                f6 = f9;
            }
            float f10 = f6;
            float f11 = f3;
            if (this.f8788f != null) {
                canvas.save();
                canvas2 = canvas;
                canvas2.rotate(f7 + 180.0f, rectFF.centerX(), rectFF.centerY());
                float fCenterX = rectFF.centerX() + f10 + 15.0f + 8.0f;
                float fCenterY = rectFF.centerY();
                canvas2.rotate(90.0f, fCenterX, fCenterY);
                d2 = d6;
                canvas2.drawText(this.f8788f.a(d2, this.a), fCenterX, fCenterY, this.f8796n);
                canvas.restore();
            } else {
                canvas2 = canvas;
                d2 = d6;
            }
            f4 = f7 + f5;
            d3 = d2 + this.f8786d;
            f2 = f5;
            f3 = f11;
            fWidth = f10;
        }
        RectF rectFF2 = f(canvas2, 0.7f);
        this.o.setColor(this.c);
        canvas.drawArc(rectFF2, 185.0f, 170.0f, false, this.o);
        for (b bVar : this.f8789g) {
            this.o.setColor(bVar.b());
            canvas.drawArc(rectFF2, (float) (((bVar.a() / this.a) * 160.0d) + 190.0d), (float) (((bVar.c() - bVar.a()) / this.a) * 160.0d), false, this.o);
        }
    }

    private RectF f(Canvas canvas, float f2) {
        RectF rectF;
        int width = (canvas.getWidth() - getPaddingLeft()) - getPaddingRight();
        int height = ((canvas.getHeight() - getPaddingTop()) - getPaddingBottom()) * 2;
        if (height >= width) {
            float f3 = width * f2;
            rectF = new RectF(0.0f, 0.0f, f3, f3);
        } else {
            float f4 = height * f2;
            rectF = new RectF(0.0f, 0.0f, f4, f4);
        }
        rectF.offset(((width - rectF.width()) / 2.0f) + getPaddingLeft(), ((height - rectF.height()) / 2.0f) + getPaddingTop());
        return rectF;
    }

    private void g() {
        if (Build.VERSION.SDK_INT >= 11 && !isInEditMode()) {
            setLayerType(2, null);
        }
        Paint paint = new Paint(1);
        this.f8790h = paint;
        paint.setStyle(Paint.Style.FILL);
        this.f8790h.setColor(this.M);
        Paint paint2 = new Paint(1);
        this.f8791i = paint2;
        paint2.setStyle(Paint.Style.FILL);
        this.f8791i.setColor(this.K);
        Paint paint3 = new Paint(1);
        this.f8792j = paint3;
        paint3.setStyle(Paint.Style.FILL);
        this.f8792j.setColor(this.L);
        Paint paint4 = new Paint(1);
        this.f8796n = paint4;
        paint4.setColor(this.N);
        this.f8796n.setTextSize(this.C);
        this.f8796n.setTextAlign(Paint.Align.CENTER);
        Bitmap bitmapDecodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.spot_mask);
        this.D = bitmapDecodeResource;
        this.D = Bitmap.createBitmap(bitmapDecodeResource, 0, 0, bitmapDecodeResource.getWidth(), this.D.getHeight() / 2);
        Paint paint5 = new Paint(1);
        this.f8793k = paint5;
        paint5.setDither(true);
        Paint paint6 = new Paint(1);
        this.f8795m = paint6;
        paint6.setStrokeWidth(3.0f);
        this.f8795m.setStyle(Paint.Style.STROKE);
        this.f8795m.setColor(this.c);
        Paint paint7 = new Paint(1);
        this.o = paint7;
        paint7.setStyle(Paint.Style.STROKE);
        this.o.setStrokeWidth(5.0f);
        this.o.setColor(this.c);
        Paint paint8 = new Paint(1);
        this.f8794l = paint8;
        paint8.setStrokeWidth(5.0f);
        this.f8794l.setStyle(Paint.Style.STROKE);
        this.f8794l.setColor(Color.argb(MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK, KotlinVersion.MAX_COMPONENT_VALUE, 0, 0));
    }

    public void a(double d2, double d3, int i2) {
        if (d2 >= d3) {
            return;
        }
        double d4 = this.a;
        if (d2 < d4 * (-0.03125d)) {
            d2 = d4 * (-0.03125d);
        }
        double d5 = d2;
        if (d3 > d4 * 1.03125d) {
            d3 = d4 * 1.03125d;
        }
        this.f8789g.add(new b(i2, d5, d3));
        invalidate();
    }

    public void b() {
        this.f8789g.clear();
        invalidate();
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.e0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public int getCenterColor() {
        return this.M;
    }

    public int getColorText() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    public int getDefaultColor() {
        return this.c;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.b0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.c0;
    }

    public int getFirstColorPoint() {
        return this.U;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.F;
    }

    public int getInColor() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.I.l());
        jSONObject.put("addressRegister", this.I.c());
        jSONObject.put("typeRequest", (int) this.I.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("showText", i());
        jSONObject.put("sizeText", getLabelTextSize());
        jSONObject.put("colorText", getColorText());
        jSONObject.put("max", getMaxSpeed());
        jSONObject.put("inColor", getInColor());
        jSONObject.put("outColor", getOutColor());
        jSONObject.put("centerColor", getCenterColor());
        jSONObject.put("firstColorPoint", getFirstColorPoint());
        jSONObject.put("secondColorPoint", getSecondColorPoint());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.G;
    }

    public c getLabelConverter() {
        return this.f8788f;
    }

    public int getLabelTextSize() {
        return this.C;
    }

    public double getMajorTickStep() {
        return this.f8786d;
    }

    public double getMaxSpeed() {
        return this.a;
    }

    public int getMinorTicks() {
        return this.f8787e;
    }

    public int getNumScreen() {
        return this.J;
    }

    public int getOutColor() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.e0;
    }

    public int getSecondColorPoint() {
        return this.V;
    }

    public double getSpeed() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.I.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.I.l() >= 100) {
            this.I.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.I.c();
        }
        this.I.u((byte) MyApplication.b().E.get(this.I.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.I.b()) + "#" + this.I.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.I.l() >= 0) {
            if (this.I.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.I.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.d0;
    }

    public int getValue() {
        return this.W;
    }

    public void h(int i2, int i3, int i4, boolean z) {
        this.f8787e = 4;
        setShowText(this.O);
        j(this.U, this.V);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width_gauge));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height_gauge));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setKey(i4);
        this.I.A(this.F);
    }

    public boolean i() {
        return this.O;
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002b A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:12:0x002d  */
    /* JADX WARN: Code duplicated, block: B:13:0x0036  */
    /* JADX WARN: Code duplicated, block: B:15:0x0043  */
    /* JADX WARN: Code duplicated, block: B:17:? A[RETURN, SYNTHETIC] */
    public void j(int i2, int i3) {
        double d2;
        double maxSpeed;
        this.U = i2;
        this.V = i3;
        b();
        if (i2 != 0 || i3 != 0) {
            if (i2 == 0) {
                a(0.0d, i3, -16711936);
            } else {
                d2 = 0.0d;
                maxSpeed = i2;
            }
            if (i2 != 0) {
                if (i3 != 0) {
                    a(i2, i3, -256);
                } else {
                    a(i2, getMaxSpeed(), -256);
                }
            }
            if (i3 > 0) {
                a(i3, getMaxSpeed(), -65536);
            }
        }
        d2 = 0.0d;
        maxSpeed = getMaxSpeed();
        a(d2, maxSpeed, -16711936);
        if (i2 != 0) {
            if (i3 != 0) {
                a(i2, i3, -256);
            } else {
                a(i2, getMaxSpeed(), -256);
            }
        }
        if (i3 > 0) {
            a(i3, getMaxSpeed(), -65536);
        }
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(0);
        c(canvas);
        e(canvas);
        d(canvas);
        if (this.Q) {
            this.T.setColor(-65536);
            this.T.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.T);
        }
        if (this.P && mbCanvas.g1) {
            canvas.drawBitmap(this.R, (getWidth() / 2) - (this.R.getWidth() / 2), getHeight() - this.R.getHeight(), this.S);
        }
        if (this.a0) {
            this.T.setColor(-16711936);
            this.T.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.T);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.a0;
    }

    public void setCenterColor(int i2) {
        this.M = i2;
        this.f8790h.setColor(i2);
        invalidate();
    }

    public void setColorText(int i2) {
        this.N = i2;
        this.f8796n.setColor(i2);
        invalidate();
    }

    public void setConnectionError(boolean z) {
        this.Q = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.P = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.a0 = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    public void setDefaultColor(int i2) {
        this.c = i2;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.b0 = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.c0 = i2;
    }

    public void setFont(String str) {
    }

    public void setInColor(int i2) {
        this.L = i2;
        this.f8792j.setColor(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.G = i2;
    }

    public void setLabelConverter(c cVar) {
        this.f8788f = cVar;
        invalidate();
    }

    public void setLabelTextSize(int i2) {
        this.C = i2;
        Paint paint = this.f8796n;
        if (paint != null) {
            paint.setTextSize(i2);
            invalidate();
        }
    }

    public void setMajorTickStep(double d2) {
        if (d2 <= 0.0d) {
            throw new IllegalArgumentException("Non-positive value specified as a major tick step.");
        }
        this.f8786d = d2;
        invalidate();
    }

    public void setMaxSpeed(double d2) {
        if (d2 <= 0.0d) {
            return;
        }
        this.a = d2;
        setMajorTickStep(d2 / 5.0d);
        invalidate();
    }

    public void setMinorTicks(int i2) {
        this.f8787e = i2;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.I.G(i2);
        this.J = i2;
    }

    public void setOutColor(int i2) {
        this.K = i2;
        this.f8791i.setColor(i2);
        invalidate();
    }

    public void setShowText(boolean z) {
        this.O = z;
        if (z) {
            setLabelConverter(new a(this));
        } else {
            setLabelConverter(null);
            invalidate();
        }
    }

    public void setSpeed(double d2) {
        this.W = (int) d2;
        if (d2 < 0.0d) {
            return;
        }
        double d3 = this.a;
        if (d2 > d3) {
            d2 = d3;
        }
        this.b = d2;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.d0 = j2;
    }
}
