package ru.himik.nightscream.kascada.Preference.NetworkDevicePref;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.d;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import ru.himik.nightscream.kascada.Preference.ServerList.EditServerList;
import ru.himik.nightscream.kascada.Preference.v0;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class PrefActivityNetworkDevice extends d {
    EditText A0;
    EditText B0;
    TableRow C;
    EditText C0;
    TableRow D;
    TableRow E;
    TableRow F;
    TableRow G;
    EditText H;
    EditText I;
    EditText J;
    EditText K;
    EditText L;
    EditText M;
    EditText N;
    EditText O;
    EditText P;
    EditText Q;
    EditText R;
    EditText S;
    EditText T;
    EditText U;
    EditText V;
    EditText W;
    TextView X;
    TextView Y;
    TextView Z;
    TextView a0;
    TextView b0;
    TextView c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    TextView f9082d;
    TextView d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    TableRow f9083e;
    TextView e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    TableRow f9084f;
    TextView f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    TableRow f9085g;
    TextView g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    TableRow f9086h;
    TextView h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    TableRow f9087i;
    TextView i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    TableRow f9088j;
    TextView j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    TableRow f9089k;
    TextView k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    TableRow f9090l;
    TextView l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    TableRow f9091m;
    TextView m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    TableRow f9092n;
    EditText n0;
    TableRow o;
    EditText o0;
    EditText p0;
    EditText q0;
    EditText r0;
    EditText s0;
    EditText t0;
    EditText u0;
    EditText v0;
    EditText w0;
    EditText x0;
    EditText y0;
    EditText z0;
    ArrayList<ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a> a = new ArrayList<>();
    ArrayList<ru.himik.nightscream.kascada.Preference.ServerList.a> b = new ArrayList<>();
    int c = 18;
    boolean D0 = false;

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PrefActivityNetworkDevice.this.i();
        }
    }

    class b implements View.OnClickListener {
        b() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PrefActivityNetworkDevice.this.h();
        }
    }

    class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PrefActivityNetworkDevice.this.onBackPressed();
        }
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0502 A[PHI: r22
      0x0502: PHI (r22v1 boolean) = (r22v0 boolean), (r22v4 boolean) binds: [B:100:0x0500, B:97:0x04e1] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:102:0x0504 A[PHI: r22
      0x0504: PHI (r22v3 boolean) = (r22v0 boolean), (r22v4 boolean) binds: [B:100:0x0500, B:97:0x04e1] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:110:0x0570 A[PHI: r23
      0x0570: PHI (r23v1 boolean) = (r23v0 boolean), (r23v3 boolean) binds: [B:109:0x056e, B:106:0x054f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:118:0x05d8  */
    /* JADX WARN: Code duplicated, block: B:126:0x0640  */
    /* JADX WARN: Code duplicated, block: B:12:0x008e A[PHI: r21
      0x008e: PHI (r21v2 boolean) = (r21v1 boolean), (r21v4 boolean) binds: [B:11:0x008c, B:8:0x006d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:134:0x06a8  */
    /* JADX WARN: Code duplicated, block: B:20:0x00f5  */
    /* JADX WARN: Code duplicated, block: B:28:0x015c  */
    /* JADX WARN: Code duplicated, block: B:36:0x01c3  */
    /* JADX WARN: Code duplicated, block: B:44:0x022a  */
    /* JADX WARN: Code duplicated, block: B:52:0x0291  */
    /* JADX WARN: Code duplicated, block: B:60:0x02f8  */
    /* JADX WARN: Code duplicated, block: B:68:0x035f  */
    /* JADX WARN: Code duplicated, block: B:76:0x03c6  */
    /* JADX WARN: Code duplicated, block: B:84:0x042d  */
    /* JADX WARN: Code duplicated, block: B:92:0x0494  */
    /* JADX WARN: Code duplicated, block: B:93:0x0496  */
    public void f() {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        int i2 = 0;
        boolean z5 = false;
        boolean z6 = false;
        boolean z7 = false;
        boolean z8 = false;
        boolean z9 = false;
        boolean z10 = false;
        boolean z11 = false;
        boolean z12 = false;
        boolean z13 = false;
        boolean z14 = false;
        boolean z15 = false;
        boolean z16 = false;
        boolean z17 = false;
        boolean z18 = false;
        boolean z19 = false;
        boolean z20 = false;
        while (true) {
            z = z17;
            if (i2 >= this.b.size()) {
                break;
            }
            boolean z21 = z16;
            if (this.b.get(i2).c() == 2) {
                String string = this.X.getText().toString();
                StringBuilder sb = new StringBuilder();
                z2 = z15;
                sb.append(this.b.get(i2).d());
                sb.append(":");
                sb.append(this.b.get(i2).h());
                if (string.equals(sb.toString())) {
                    z5 = true;
                }
            } else {
                z2 = z15;
                if (this.X.getText().toString().equals(this.b.get(i2).h())) {
                    z5 = true;
                }
            }
            if (this.b.get(i2).c() == 2) {
                if (this.Y.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z6 = true;
                }
            } else if (this.Y.getText().toString().equals(this.b.get(i2).h())) {
                z6 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.Z.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z7 = true;
                }
            } else if (this.Z.getText().toString().equals(this.b.get(i2).h())) {
                z7 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.a0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z8 = true;
                }
            } else if (this.a0.getText().toString().equals(this.b.get(i2).h())) {
                z8 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.b0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z9 = true;
                }
            } else if (this.b0.getText().toString().equals(this.b.get(i2).h())) {
                z9 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.c0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z10 = true;
                }
            } else if (this.c0.getText().toString().equals(this.b.get(i2).h())) {
                z10 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.d0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z11 = true;
                }
            } else if (this.d0.getText().toString().equals(this.b.get(i2).h())) {
                z11 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.e0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z12 = true;
                }
            } else if (this.e0.getText().toString().equals(this.b.get(i2).h())) {
                z12 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.f0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z13 = true;
                }
            } else if (this.f0.getText().toString().equals(this.b.get(i2).h())) {
                z13 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.g0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z14 = true;
                }
            } else if (this.g0.getText().toString().equals(this.b.get(i2).h())) {
                z14 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.h0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z15 = true;
                } else {
                    z15 = z2;
                }
            } else if (this.h0.getText().toString().equals(this.b.get(i2).h())) {
                z15 = true;
            } else {
                z15 = z2;
            }
            if (this.b.get(i2).c() == 2) {
                String string2 = this.i0.getText().toString();
                StringBuilder sb2 = new StringBuilder();
                z3 = z5;
                sb2.append(this.b.get(i2).d());
                sb2.append(":");
                sb2.append(this.b.get(i2).h());
                if (string2.equals(sb2.toString())) {
                    z16 = true;
                } else {
                    z16 = z21;
                }
            } else {
                z3 = z5;
                if (this.i0.getText().toString().equals(this.b.get(i2).h())) {
                    z16 = true;
                } else {
                    z16 = z21;
                }
            }
            if (this.b.get(i2).c() == 2) {
                String string3 = this.j0.getText().toString();
                StringBuilder sb3 = new StringBuilder();
                z4 = z6;
                sb3.append(this.b.get(i2).d());
                sb3.append(":");
                sb3.append(this.b.get(i2).h());
                if (string3.equals(sb3.toString())) {
                    z = true;
                }
            } else {
                z4 = z6;
                if (this.j0.getText().toString().equals(this.b.get(i2).h())) {
                    z = true;
                }
            }
            if (this.b.get(i2).c() == 2) {
                if (this.k0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z18 = true;
                }
            } else if (this.k0.getText().toString().equals(this.b.get(i2).h())) {
                z18 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.l0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z19 = true;
                }
            } else if (this.l0.getText().toString().equals(this.b.get(i2).h())) {
                z19 = true;
            }
            if (this.b.get(i2).c() == 2) {
                if (this.m0.getText().toString().equals(this.b.get(i2).d() + ":" + this.b.get(i2).h())) {
                    z20 = true;
                }
            } else if (this.m0.getText().toString().equals(this.b.get(i2).h())) {
                z20 = true;
            }
            i2++;
            z17 = z;
            z5 = z3;
            z6 = z4;
        }
        boolean z22 = z15;
        boolean z23 = z16;
        if (!z5) {
            this.X.setText("");
            this.a.get(0).n("");
        }
        if (!z6) {
            this.Y.setText("");
            this.a.get(1).n("");
        }
        if (!z7) {
            this.Z.setText("");
            this.a.get(2).n("");
        }
        if (!z8) {
            this.a0.setText("");
            this.a.get(3).n("");
        }
        if (!z9) {
            this.b0.setText("");
            this.a.get(4).n("");
        }
        if (!z10) {
            this.c0.setText("");
            this.a.get(5).n("");
        }
        if (!z11) {
            this.d0.setText("");
            this.a.get(6).n("");
        }
        if (!z12) {
            this.e0.setText("");
            this.a.get(7).n("");
        }
        if (!z13) {
            this.f0.setText("");
            this.a.get(8).n("");
        }
        if (!z14) {
            this.g0.setText("");
            this.a.get(9).n("");
        }
        if (!z22) {
            this.h0.setText("");
            this.a.get(10).n("");
        }
        if (!z23) {
            this.i0.setText("");
            this.a.get(11).n("");
        }
        if (!z) {
            this.j0.setText("");
            this.a.get(12).n("");
        }
        if (!z18) {
            this.k0.setText("");
            this.a.get(13).n("");
        }
        if (!z19) {
            this.l0.setText("");
            this.a.get(14).n("");
        }
        if (z20) {
            return;
        }
        this.m0.setText("");
        this.a.get(15).n("");
    }

    public void g() {
        this.a.get(0).k(this.H.getText().toString());
        this.a.get(0).n(this.X.getText().toString());
        if (this.n0.length() > 0) {
            this.a.get(0).i(Integer.parseInt(this.n0.getText().toString()));
        } else {
            this.a.get(0).i(1);
        }
        this.a.get(1).k(this.I.getText().toString());
        this.a.get(1).n(this.Y.getText().toString());
        if (this.o0.length() > 0) {
            this.a.get(1).i(Integer.parseInt(this.o0.getText().toString()));
        } else {
            this.a.get(1).i(1);
        }
        this.a.get(2).k(this.J.getText().toString());
        this.a.get(2).n(this.Z.getText().toString());
        if (this.p0.length() > 0) {
            this.a.get(2).i(Integer.parseInt(this.p0.getText().toString()));
        } else {
            this.a.get(2).i(1);
        }
        this.a.get(3).k(this.K.getText().toString());
        this.a.get(3).n(this.a0.getText().toString());
        if (this.q0.length() > 0) {
            this.a.get(3).i(Integer.parseInt(this.q0.getText().toString()));
        } else {
            this.a.get(3).i(1);
        }
        this.a.get(4).k(this.L.getText().toString());
        this.a.get(4).n(this.b0.getText().toString());
        if (this.r0.length() > 0) {
            this.a.get(4).i(Integer.parseInt(this.r0.getText().toString()));
        } else {
            this.a.get(4).i(1);
        }
        this.a.get(5).k(this.M.getText().toString());
        this.a.get(5).n(this.c0.getText().toString());
        if (this.s0.length() > 0) {
            this.a.get(5).i(Integer.parseInt(this.s0.getText().toString()));
        } else {
            this.a.get(5).i(1);
        }
        this.a.get(6).k(this.N.getText().toString());
        this.a.get(6).n(this.d0.getText().toString());
        if (this.t0.length() > 0) {
            this.a.get(6).i(Integer.parseInt(this.t0.getText().toString()));
        } else {
            this.a.get(6).i(1);
        }
        this.a.get(7).k(this.O.getText().toString());
        this.a.get(7).n(this.e0.getText().toString());
        if (this.u0.length() > 0) {
            this.a.get(7).i(Integer.parseInt(this.u0.getText().toString()));
        } else {
            this.a.get(7).i(1);
        }
        this.a.get(8).k(this.P.getText().toString());
        this.a.get(8).n(this.f0.getText().toString());
        if (this.v0.length() > 0) {
            this.a.get(8).i(Integer.parseInt(this.v0.getText().toString()));
        } else {
            this.a.get(8).i(1);
        }
        this.a.get(9).k(this.Q.getText().toString());
        this.a.get(9).n(this.g0.getText().toString());
        if (this.w0.length() > 0) {
            this.a.get(9).i(Integer.parseInt(this.w0.getText().toString()));
        } else {
            this.a.get(9).i(1);
        }
        this.a.get(10).k(this.R.getText().toString());
        this.a.get(10).n(this.h0.getText().toString());
        if (this.x0.length() > 0) {
            this.a.get(10).i(Integer.parseInt(this.x0.getText().toString()));
        } else {
            this.a.get(10).i(1);
        }
        this.a.get(11).k(this.S.getText().toString());
        this.a.get(11).n(this.i0.getText().toString());
        if (this.y0.length() > 0) {
            this.a.get(11).i(Integer.parseInt(this.y0.getText().toString()));
        } else {
            this.a.get(11).i(1);
        }
        this.a.get(12).k(this.T.getText().toString());
        this.a.get(12).n(this.j0.getText().toString());
        if (this.z0.length() > 0) {
            this.a.get(12).i(Integer.parseInt(this.z0.getText().toString()));
        } else {
            this.a.get(12).i(1);
        }
        this.a.get(13).k(this.U.getText().toString());
        this.a.get(13).n(this.k0.getText().toString());
        if (this.A0.length() > 0) {
            this.a.get(13).i(Integer.parseInt(this.A0.getText().toString()));
        } else {
            this.a.get(13).i(1);
        }
        this.a.get(14).k(this.V.getText().toString());
        this.a.get(14).n(this.l0.getText().toString());
        if (this.B0.length() > 0) {
            this.a.get(14).i(Integer.parseInt(this.B0.getText().toString()));
        } else {
            this.a.get(14).i(1);
        }
        this.a.get(15).k(this.W.getText().toString());
        this.a.get(15).n(this.m0.getText().toString());
        if (this.C0.length() > 0) {
            this.a.get(15).i(Integer.parseInt(this.C0.getText().toString()));
        } else {
            this.a.get(15).i(1);
        }
        Intent intent = getIntent();
        Bundle bundle = new Bundle();
        bundle.putInt("COUNT_NETWORK_DEVICE", this.c);
        bundle.putParcelableArrayList("networkDevice", this.a);
        bundle.putParcelableArrayList("serverList", this.b);
        intent.putExtras(bundle);
        setResult(-1, intent);
        finish();
    }

    void h() {
        int i2 = this.c;
        if (i2 <= 1) {
            return;
        }
        int i3 = i2 - 1;
        this.c = i3;
        k(i3);
    }

    void i() {
        int i2 = this.c;
        if (i2 >= 16) {
            return;
        }
        int i3 = i2 + 1;
        this.c = i3;
        k(i3);
    }

    void j(int i2) {
        Intent intent = new Intent(getApplicationContext(), (Class<?>) EditServerList.class);
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("serverList", this.b);
        bundle.putInt("posDeviceNetwork", i2);
        intent.putExtras(bundle);
        intent.putExtra("portraitMode", this.D0);
        startActivityForResult(intent, 1);
    }

    void k(int i2) {
        switch (i2) {
            case 1:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(4);
                this.f9085g.setVisibility(4);
                this.f9086h.setVisibility(4);
                this.f9087i.setVisibility(4);
                this.f9088j.setVisibility(4);
                this.f9089k.setVisibility(4);
                this.f9090l.setVisibility(4);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 2:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(4);
                this.f9086h.setVisibility(4);
                this.f9087i.setVisibility(4);
                this.f9088j.setVisibility(4);
                this.f9089k.setVisibility(4);
                this.f9090l.setVisibility(4);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 3:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(4);
                this.f9087i.setVisibility(4);
                this.f9088j.setVisibility(4);
                this.f9089k.setVisibility(4);
                this.f9090l.setVisibility(4);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 4:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(4);
                this.f9088j.setVisibility(4);
                this.f9089k.setVisibility(4);
                this.f9090l.setVisibility(4);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 5:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(4);
                this.f9089k.setVisibility(4);
                this.f9090l.setVisibility(4);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 6:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(4);
                this.f9090l.setVisibility(4);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 7:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(4);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 8:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(4);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 9:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(4);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 10:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(0);
                this.o.setVisibility(4);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 11:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(0);
                this.o.setVisibility(0);
                this.C.setVisibility(4);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 12:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(0);
                this.o.setVisibility(0);
                this.C.setVisibility(0);
                this.D.setVisibility(4);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 13:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(0);
                this.o.setVisibility(0);
                this.C.setVisibility(0);
                this.D.setVisibility(0);
                this.E.setVisibility(4);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 14:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(0);
                this.o.setVisibility(0);
                this.C.setVisibility(0);
                this.D.setVisibility(0);
                this.E.setVisibility(0);
                this.F.setVisibility(4);
                this.G.setVisibility(4);
                break;
            case 15:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(0);
                this.o.setVisibility(0);
                this.C.setVisibility(0);
                this.D.setVisibility(0);
                this.E.setVisibility(0);
                this.F.setVisibility(0);
                this.G.setVisibility(4);
                break;
            case 16:
                this.f9083e.setVisibility(0);
                this.f9084f.setVisibility(0);
                this.f9085g.setVisibility(0);
                this.f9086h.setVisibility(0);
                this.f9087i.setVisibility(0);
                this.f9088j.setVisibility(0);
                this.f9089k.setVisibility(0);
                this.f9090l.setVisibility(0);
                this.f9091m.setVisibility(0);
                this.f9092n.setVisibility(0);
                this.o.setVisibility(0);
                this.C.setVisibility(0);
                this.D.setVisibility(0);
                this.E.setVisibility(0);
                this.F.setVisibility(0);
                this.G.setVisibility(0);
                break;
        }
        this.f9082d.setText(this.c + "");
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:17:0x0095. Please report as an issue. */
    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onActivityResult(int i2, int i3, Intent intent) {
        String strH;
        TextView textView;
        TextView textView2;
        StringBuilder sb;
        super.onActivityResult(i2, i3, intent);
        if (i2 == 1) {
            if (i3 == -1) {
                int i4 = intent.getExtras().getInt("position");
                this.b = intent.getExtras().getParcelableArrayList("serverList");
                int i5 = intent.getExtras().getInt("posDeviceNetwork");
                int i6 = intent.getExtras().getInt("idServer");
                if (i5 > 0 && i4 != -2) {
                    if (i4 != -1) {
                        int i7 = i5 - 1;
                        this.a.get(i7).n(this.b.get(i4).h());
                        this.a.get(i7).j(i6);
                        if (this.a.get(i7).b() == 2 || this.a.get(i7).b() == 4) {
                            this.a.get(i7).m(this.b.get(i4).l());
                        }
                        switch (i5) {
                            case 1:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.X;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.X;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 2:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.Y;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.Y;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 3:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.Z;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.Z;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 4:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.a0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.a0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 5:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.b0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.b0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 6:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.c0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.c0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 7:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.d0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.d0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 8:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.e0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.e0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 9:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.f0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.f0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 10:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.g0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.g0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 11:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.h0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.h0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 12:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.i0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.i0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 13:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.j0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.j0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 14:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.k0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.k0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 15:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.l0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.l0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                            case 16:
                                if (this.b.get(i4).c() != 2) {
                                    textView = this.m0;
                                    strH = this.b.get(i4).h();
                                    textView.setText(strH);
                                } else {
                                    textView2 = this.m0;
                                    sb = new StringBuilder();
                                    sb.append(this.b.get(i4).d());
                                    sb.append(":");
                                    sb.append(this.b.get(i4).h());
                                    textView2.setText(sb.toString());
                                }
                                break;
                        }
                    } else {
                        strH = "";
                        this.a.get(i5 - 1).n("");
                        switch (i5) {
                            case 1:
                                textView = this.X;
                                break;
                            case 2:
                                textView = this.Y;
                                break;
                            case 3:
                                textView = this.Z;
                                break;
                            case 4:
                                textView = this.a0;
                                break;
                            case 5:
                                textView = this.b0;
                                break;
                            case 6:
                                textView = this.c0;
                                break;
                            case 7:
                                textView = this.d0;
                                break;
                            case 8:
                                textView = this.e0;
                                break;
                            case 9:
                                textView = this.f0;
                                break;
                            case 10:
                                textView = this.g0;
                                break;
                            case 11:
                                textView = this.h0;
                                break;
                            case 12:
                                textView = this.i0;
                                break;
                            case 13:
                                textView = this.j0;
                                break;
                            case 14:
                                textView = this.k0;
                                break;
                            case 15:
                                textView = this.l0;
                                break;
                            case 16:
                                textView = this.m0;
                                break;
                        }
                        textView.setText(strH);
                    }
                }
            }
            f();
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        g();
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.layout_device_network);
        boolean booleanExtra = getIntent().getBooleanExtra("portraitMode", false);
        this.D0 = booleanExtra;
        if (booleanExtra) {
            setRequestedOrientation(1);
        }
        Toolbar toolbar = (Toolbar) findViewById(R.id.network_device_toolbar);
        this.f9082d = (TextView) findViewById(R.id.textCountDevice);
        findViewById(R.id.plus).setOnClickListener(new a());
        findViewById(R.id.minus).setOnClickListener(new b());
        this.f9083e = (TableRow) findViewById(R.id.tableRow1);
        this.f9084f = (TableRow) findViewById(R.id.tableRow2);
        this.f9085g = (TableRow) findViewById(R.id.tableRow3);
        this.f9086h = (TableRow) findViewById(R.id.tableRow4);
        this.f9087i = (TableRow) findViewById(R.id.tableRow5);
        this.f9088j = (TableRow) findViewById(R.id.tableRow6);
        this.f9089k = (TableRow) findViewById(R.id.tableRow7);
        this.f9090l = (TableRow) findViewById(R.id.tableRow8);
        this.f9091m = (TableRow) findViewById(R.id.tableRow9);
        this.f9092n = (TableRow) findViewById(R.id.tableRow10);
        this.o = (TableRow) findViewById(R.id.tableRow11);
        this.C = (TableRow) findViewById(R.id.tableRow12);
        this.D = (TableRow) findViewById(R.id.tableRow13);
        this.E = (TableRow) findViewById(R.id.tableRow14);
        this.F = (TableRow) findViewById(R.id.tableRow15);
        this.G = (TableRow) findViewById(R.id.tableRow16);
        this.H = (EditText) findViewById(R.id.editNameDevice1);
        this.I = (EditText) findViewById(R.id.editNameDevice2);
        this.J = (EditText) findViewById(R.id.editNameDevice3);
        this.K = (EditText) findViewById(R.id.editNameDevice4);
        this.L = (EditText) findViewById(R.id.editNameDevice5);
        this.M = (EditText) findViewById(R.id.editNameDevice6);
        this.N = (EditText) findViewById(R.id.editNameDevice7);
        this.O = (EditText) findViewById(R.id.editNameDevice8);
        this.P = (EditText) findViewById(R.id.editNameDevice9);
        this.Q = (EditText) findViewById(R.id.editNameDevice10);
        this.R = (EditText) findViewById(R.id.editNameDevice11);
        this.S = (EditText) findViewById(R.id.editNameDevice12);
        this.T = (EditText) findViewById(R.id.editNameDevice13);
        this.U = (EditText) findViewById(R.id.editNameDevice14);
        this.V = (EditText) findViewById(R.id.editNameDevice15);
        this.W = (EditText) findViewById(R.id.editNameDevice16);
        this.X = (TextView) findViewById(R.id.textServerDevice1);
        this.Y = (TextView) findViewById(R.id.textServerDevice2);
        this.Z = (TextView) findViewById(R.id.textServerDevice3);
        this.a0 = (TextView) findViewById(R.id.textServerDevice4);
        this.b0 = (TextView) findViewById(R.id.textServerDevice5);
        this.c0 = (TextView) findViewById(R.id.textServerDevice6);
        this.d0 = (TextView) findViewById(R.id.textServerDevice7);
        this.e0 = (TextView) findViewById(R.id.textServerDevice8);
        this.f0 = (TextView) findViewById(R.id.textServerDevice9);
        this.g0 = (TextView) findViewById(R.id.textServerDevice10);
        this.h0 = (TextView) findViewById(R.id.textServerDevice11);
        this.i0 = (TextView) findViewById(R.id.textServerDevice12);
        this.j0 = (TextView) findViewById(R.id.textServerDevice13);
        this.k0 = (TextView) findViewById(R.id.textServerDevice14);
        this.l0 = (TextView) findViewById(R.id.textServerDevice15);
        this.m0 = (TextView) findViewById(R.id.textServerDevice16);
        EditText editText = (EditText) findViewById(R.id.editAddressDevice1);
        this.n0 = editText;
        editText.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText2 = (EditText) findViewById(R.id.editAddressDevice2);
        this.o0 = editText2;
        editText2.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText3 = (EditText) findViewById(R.id.editAddressDevice3);
        this.p0 = editText3;
        editText3.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText4 = (EditText) findViewById(R.id.editAddressDevice4);
        this.q0 = editText4;
        editText4.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText5 = (EditText) findViewById(R.id.editAddressDevice5);
        this.r0 = editText5;
        editText5.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText6 = (EditText) findViewById(R.id.editAddressDevice6);
        this.s0 = editText6;
        editText6.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText7 = (EditText) findViewById(R.id.editAddressDevice7);
        this.t0 = editText7;
        editText7.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText8 = (EditText) findViewById(R.id.editAddressDevice8);
        this.u0 = editText8;
        editText8.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText9 = (EditText) findViewById(R.id.editAddressDevice9);
        this.v0 = editText9;
        editText9.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText10 = (EditText) findViewById(R.id.editAddressDevice10);
        this.w0 = editText10;
        editText10.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText11 = (EditText) findViewById(R.id.editAddressDevice11);
        this.x0 = editText11;
        editText11.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText12 = (EditText) findViewById(R.id.editAddressDevice12);
        this.y0 = editText12;
        editText12.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText13 = (EditText) findViewById(R.id.editAddressDevice13);
        this.z0 = editText13;
        editText13.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText14 = (EditText) findViewById(R.id.editAddressDevice14);
        this.A0 = editText14;
        editText14.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText15 = (EditText) findViewById(R.id.editAddressDevice15);
        this.B0 = editText15;
        editText15.setFilters(new InputFilter[]{new v0("0", "254")});
        EditText editText16 = (EditText) findViewById(R.id.editAddressDevice16);
        this.C0 = editText16;
        editText16.setFilters(new InputFilter[]{new v0("0", "254")});
        if (toolbar != null) {
            toolbar.setTitle(getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getResources().getString(R.string.network_connection));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
            toolbar.setNavigationOnClickListener(new c());
        }
        this.a = getIntent().getParcelableArrayListExtra("networkDevice");
        this.b = getIntent().getParcelableArrayListExtra("serverList");
        int intExtra = getIntent().getIntExtra("COUNT_DEVICE", 16);
        this.c = intExtra;
        k(intExtra);
        this.H.setText(this.a.get(0).c());
        this.n0.setText(this.a.get(0).a() + "");
        this.X.setText(this.a.get(0).e());
        this.I.setText(this.a.get(1).c());
        this.o0.setText(this.a.get(1).a() + "");
        this.Y.setText(this.a.get(1).e());
        this.J.setText(this.a.get(2).c());
        this.p0.setText(this.a.get(2).a() + "");
        this.Z.setText(this.a.get(2).e());
        this.K.setText(this.a.get(3).c());
        this.q0.setText(this.a.get(3).a() + "");
        this.a0.setText(this.a.get(3).e());
        this.L.setText(this.a.get(4).c());
        this.r0.setText(this.a.get(4).a() + "");
        this.b0.setText(this.a.get(4).e());
        this.M.setText(this.a.get(5).c());
        this.s0.setText(this.a.get(5).a() + "");
        this.c0.setText(this.a.get(5).e());
        this.N.setText(this.a.get(6).c());
        this.t0.setText(this.a.get(6).a() + "");
        this.d0.setText(this.a.get(6).e());
        this.O.setText(this.a.get(7).c());
        this.u0.setText(this.a.get(7).a() + "");
        this.e0.setText(this.a.get(7).e());
        this.P.setText(this.a.get(8).c());
        this.v0.setText(this.a.get(8).a() + "");
        this.f0.setText(this.a.get(8).e());
        this.Q.setText(this.a.get(9).c());
        this.w0.setText(this.a.get(9).a() + "");
        this.g0.setText(this.a.get(9).e());
        this.R.setText(this.a.get(10).c());
        this.x0.setText(this.a.get(10).a() + "");
        this.h0.setText(this.a.get(10).e());
        this.S.setText(this.a.get(11).c());
        this.y0.setText(this.a.get(11).a() + "");
        this.i0.setText(this.a.get(11).e());
        this.T.setText(this.a.get(12).c());
        this.z0.setText(this.a.get(12).a() + "");
        this.j0.setText(this.a.get(12).e());
        this.U.setText(this.a.get(13).c());
        this.A0.setText(this.a.get(13).a() + "");
        this.k0.setText(this.a.get(13).e());
        this.V.setText(this.a.get(14).c());
        this.B0.setText(this.a.get(14).a() + "");
        this.l0.setText(this.a.get(14).e());
        this.W.setText(this.a.get(15).c());
        this.C0.setText(this.a.get(15).a() + "");
        this.m0.setText(this.a.get(15).e());
        f();
    }

    public void onSelectServer(View view) {
        int i2;
        switch (view.getId()) {
            case R.id.textServerDevice1 /* 2131297214 */:
                i2 = 1;
                break;
            case R.id.textServerDevice10 /* 2131297215 */:
                i2 = 10;
                break;
            case R.id.textServerDevice11 /* 2131297216 */:
                i2 = 11;
                break;
            case R.id.textServerDevice12 /* 2131297217 */:
                i2 = 12;
                break;
            case R.id.textServerDevice13 /* 2131297218 */:
                i2 = 13;
                break;
            case R.id.textServerDevice14 /* 2131297219 */:
                i2 = 14;
                break;
            case R.id.textServerDevice15 /* 2131297220 */:
                i2 = 15;
                break;
            case R.id.textServerDevice16 /* 2131297221 */:
                i2 = 16;
                break;
            case R.id.textServerDevice2 /* 2131297222 */:
                i2 = 2;
                break;
            case R.id.textServerDevice3 /* 2131297223 */:
                i2 = 3;
                break;
            case R.id.textServerDevice4 /* 2131297224 */:
                i2 = 4;
                break;
            case R.id.textServerDevice5 /* 2131297225 */:
                i2 = 5;
                break;
            case R.id.textServerDevice6 /* 2131297226 */:
                i2 = 6;
                break;
            case R.id.textServerDevice7 /* 2131297227 */:
                i2 = 7;
                break;
            case R.id.textServerDevice8 /* 2131297228 */:
                i2 = 8;
                break;
            case R.id.textServerDevice9 /* 2131297229 */:
                i2 = 9;
                break;
            default:
                return;
        }
        j(i2);
    }
}
