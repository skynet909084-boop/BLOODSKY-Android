package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ProgressBar;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class r extends ProgressBar implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    private boolean C;
    Bitmap D;
    Paint E;
    Paint F;
    int G;
    int H;
    int I;
    boolean J;
    int K;
    int L;
    int M;
    private long N;
    public Point O;
    public String a;
    int b;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public byte f8873d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public b f8874e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8875f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    Paint f8876g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    boolean f8877h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f8878i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f8879j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    String f8880k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    int f8881l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8882m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    boolean f8883n;
    private boolean o;

    public r(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.a = getResources().getString(R.string.custom_line_level);
        this.b = 11;
        this.f8873d = (byte) 3;
        this.f8874e = new b();
        this.f8876g = new Paint(1);
        this.f8877h = false;
        this.f8878i = 50;
        this.f8879j = -16776961;
        this.f8880k = "0";
        this.f8881l = Color.parseColor("#2AEC00");
        this.f8882m = Color.parseColor("#9C9C9B");
        this.f8883n = true;
        this.D = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.E = new Paint();
        this.F = new Paint();
        this.G = 100;
        this.H = 0;
        this.I = 0;
        this.J = false;
        this.K = 0;
        this.L = 0;
        this.M = (int) getResources().getDimension(R.dimen.padding_linear);
        this.N = 0L;
        this.O = new Point();
        setProgressDrawable(a(this.f8881l, this.f8882m));
    }

    protected Drawable a(int i2, int i3) {
        GradientDrawable gradientDrawable;
        if (Color.alpha(i3) == 0) {
            gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0, 0, 0});
        } else {
            gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{Color.parseColor("#282828"), Color.parseColor("#ffffff"), Color.parseColor("#777777")});
            gradientDrawable.setStroke((int) getResources().getDimension(R.dimen.width_stroke), Color.parseColor("#FF444444"));
        }
        gradientDrawable.setShape(0);
        gradientDrawable.setGradientType(0);
        gradientDrawable.setCornerRadius(getResources().getDimension(R.dimen.corner_radius));
        if (Build.VERSION.SDK_INT >= 16) {
            setBackground(gradientDrawable);
        } else {
            setBackgroundDrawable(gradientDrawable);
        }
        GradientDrawable gradientDrawable2 = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{ru.himik.nightscream.kascada.Utils.q.k(i3, 0.7f), i3, ru.himik.nightscream.kascada.Utils.q.k(i3, 0.7f)});
        gradientDrawable2.setShape(0);
        gradientDrawable2.setGradientType(0);
        gradientDrawable2.setCornerRadius(getResources().getDimension(R.dimen.corner_radius));
        GradientDrawable gradientDrawable3 = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{ru.himik.nightscream.kascada.Utils.q.k(i2, 0.7f), i2, ru.himik.nightscream.kascada.Utils.q.k(i2, 0.7f)});
        gradientDrawable3.setShape(0);
        gradientDrawable3.setGradientType(0);
        gradientDrawable3.setCornerRadius(getResources().getDimension(R.dimen.corner_radius));
        gradientDrawable3.setGradientCenter(0.5f, 0.5f);
        ShapeDrawable shapeDrawable = new ShapeDrawable(new RectShape());
        shapeDrawable.getPaint().setColor(0);
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{gradientDrawable2, new ClipDrawable(shapeDrawable, 80, 2), new ClipDrawable(gradientDrawable3, 80, 2)});
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.secondaryProgress);
        layerDrawable.setId(2, android.R.id.progress);
        return layerDrawable;
    }

    public void b(int i2, int i3, int i4, boolean z) {
        setMax(100);
        setProgressDrawable(a(this.f8881l, this.f8882m));
        setProgress(0);
        this.f8876g.setStyle(Paint.Style.STROKE);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setKey(i4);
        setPadding((int) getResources().getDimension(R.dimen.padding_linear), (int) getResources().getDimension(R.dimen.padding_linear), (int) getResources().getDimension(R.dimen.padding_linear), (int) getResources().getDimension(R.dimen.padding_linear));
    }

    public boolean c() {
        return this.f8883n;
    }

    public boolean d() {
        return this.f8877h;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.O.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e() {
        setProgressDrawable(a(this.f8881l, this.f8882m));
    }

    public int getColorBackground() {
        return this.f8882m;
    }

    public int getColorProgress() {
        return this.f8881l;
    }

    public int getColorText() {
        return this.f8879j;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8874e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8875f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8874e.l());
        jSONObject.put("addressRegister", this.f8874e.c());
        jSONObject.put("typeRequest", (int) this.f8874e.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("showText", d());
        jSONObject.put("sizeText", getSizeText());
        jSONObject.put("colorText", getColorText());
        jSONObject.put("showScale", c());
        jSONObject.put("max", getValueMax());
        jSONObject.put("min", getValueMin());
        jSONObject.put("colorProgress", getColorProgress());
        jSONObject.put("colorBackground", getColorBackground());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.c;
    }

    public int getNumScreen() {
        return this.f8875f;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.O;
    }

    public int getSizeText() {
        return this.f8878i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8874e.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8874e.l() >= 100) {
            this.f8874e.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8874e.c();
        }
        this.f8874e.u((byte) MyApplication.b().E.get(this.f8874e.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8874e.b()) + "#" + this.f8874e.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8874e.l() >= 0) {
            if (this.f8874e.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8874e.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.N;
    }

    public int getValue() {
        return this.I;
    }

    public int getValueMax() {
        return this.G;
    }

    public int getValueMin() {
        return this.H;
    }

    @Override // android.widget.ProgressBar, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        int i2;
        super.onDraw(canvas);
        this.E.setColor(-16777216);
        this.E.setStrokeWidth(2.0f);
        this.f8876g.setTextSize(this.f8878i);
        this.f8876g.setColor(this.f8879j);
        this.f8880k = String.valueOf(this.I);
        float height = getHeight();
        float width2 = getWidth();
        float f2 = (height - (this.M * 2)) / 20.0f;
        if (this.f8877h) {
            String str = this.f8880k;
            canvas.drawText(str, (width2 / 2.0f) - (this.f8876g.measureText(str) / 2.0f), height - this.M, this.f8876g);
        }
        int width3 = getWidth() / 3;
        int width4 = getWidth() / 4;
        int width5 = getWidth() / 8;
        for (int i3 = 1; i3 < 20; i3++) {
            if (i3 % 2 == 0) {
                if (i3 == 10) {
                    if (this.f8883n) {
                        width = getWidth() / 2;
                        i2 = width3 / 2;
                        float f3 = width - i2;
                        float f4 = i3 * f2;
                        canvas.drawLine(f3, f4 + this.M, (getWidth() / 2) + i2, f4 + this.M, this.E);
                    }
                } else if (this.f8883n) {
                    width = getWidth() / 2;
                    i2 = width4 / 2;
                    float f5 = width - i2;
                    float f6 = i3 * f2;
                    canvas.drawLine(f5, f6 + this.M, (getWidth() / 2) + i2, f6 + this.M, this.E);
                }
            } else if (this.f8883n) {
                width = getWidth() / 2;
                i2 = width5 / 2;
                float f7 = width - i2;
                float f8 = i3 * f2;
                canvas.drawLine(f7, f8 + this.M, (getWidth() / 2) + i2, f8 + this.M, this.E);
            }
        }
        if (this.C) {
            this.F.setColor(-65536);
            this.F.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.F);
        }
        if (this.o && mbCanvas.g1) {
            canvas.drawBitmap(this.D, getWidth() - this.D.getWidth(), getHeight() - this.D.getHeight(), this.E);
        }
        if (this.J) {
            this.F.setColor(-16711936);
            this.F.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.F);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.J;
    }

    public void setColorBackground(int i2) {
        this.f8882m = i2;
    }

    public void setColorProgress(int i2) {
        this.f8881l = i2;
    }

    public void setColorText(int i2) {
        this.f8879j = i2;
    }

    public void setConnectionError(boolean z) {
        this.C = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.o = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.J = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.K = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.L = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.c = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8874e.G(i2);
        this.f8875f = i2;
    }

    public void setShowScale(boolean z) {
        this.f8883n = z;
    }

    public void setShowText(boolean z) {
        this.f8877h = z;
    }

    public void setSizeText(int i2) {
        this.f8878i = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.N = j2;
    }

    public void setValue(int i2) {
        if (this.I == i2) {
            return;
        }
        this.I = i2;
        int i3 = this.H;
        int i4 = this.G;
        if (i3 >= i4) {
            setProgress(0);
            invalidate();
        } else if (i2 <= i3) {
            setProgress(0);
            invalidate();
        } else if (i2 < i4) {
            setProgress((int) ((100.0f / (i4 - i3)) * (i2 - i3)));
        } else {
            setProgress(100);
            invalidate();
        }
    }

    public void setValueMax(int i2) {
        this.G = i2;
    }

    public void setValueMin(int i2) {
        this.H = i2;
    }
}
