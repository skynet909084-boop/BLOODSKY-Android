package ru.himik.nightscream.kascada.w;

/* JADX INFO: loaded from: classes2.dex */
public class a {
    public static boolean a = false;
}
