package ru.himik.nightscream.kascada.q.c;

import ru.himik.nightscream.kascada.MyApplication;

/* JADX INFO: loaded from: classes.dex */
public class c {
    public static byte[] a(int[] iArr) {
        int i2 = ((iArr[2] * 256) + iArr[3]) / 16;
        int i3 = ((iArr[2] * 256) + iArr[3]) % 16;
        int i4 = iArr[5];
        int i5 = (iArr[2] * 256) + iArr[3] + i4;
        int i6 = ru.himik.nightscream.kascada.q.d.b.E;
        if (i5 > i6 * 16 || i4 > i6) {
            return null;
        }
        byte[] bArr = new byte[i4 % 8 > 0 ? (i4 / 8) + 1 : i4 / 8];
        for (int i7 = 0; i7 < i4; i7++) {
            int i8 = (i2 * 16) + i3 + i7;
            if (MyApplication.b().v0.G(i8 / 16, i8 % 16) == 1) {
                int i9 = i7 / 8;
                bArr[i9] = (byte) (bArr[i9] | (1 << (i7 % 8)));
            }
        }
        int length = bArr.length + 2 + 3;
        byte[] bArr2 = new byte[length];
        bArr2[0] = 1;
        bArr2[1] = 1;
        bArr2[2] = (byte) bArr.length;
        for (int i10 = 0; i10 < bArr.length; i10++) {
            bArr2[i10 + 3] = bArr[i10];
        }
        int i11 = length - 2;
        byte[] bArr3 = new byte[i11];
        System.arraycopy(bArr2, 0, bArr3, 0, i11);
        int iD = ru.himik.nightscream.kascada.x.b.d(bArr3);
        bArr2[i11] = ru.himik.nightscream.kascada.x.b.b(iD);
        bArr2[length - 1] = ru.himik.nightscream.kascada.x.b.a(iD);
        return bArr2;
    }

    public static byte[] b(int[] iArr) {
        int i2 = (iArr[2] * 256) + iArr[3];
        int i3 = iArr[5];
        int i4 = i2 + i3;
        int i5 = ru.himik.nightscream.kascada.q.d.b.E;
        if (i4 > i5 || i3 > i5) {
            return null;
        }
        int i6 = i3 * 2;
        int i7 = i6 + 5;
        byte[] bArr = new byte[i7];
        bArr[0] = 1;
        bArr[1] = 3;
        bArr[2] = (byte) i6;
        for (int i8 = 0; i8 < i3; i8++) {
            int i9 = (i8 * 2) + 3;
            int i10 = i2 + i8;
            bArr[i9] = ru.himik.nightscream.kascada.x.b.e(MyApplication.b().v0.f9265j[i10])[2];
            bArr[i9 + 1] = ru.himik.nightscream.kascada.x.b.e(MyApplication.b().v0.f9265j[i10])[3];
        }
        int i11 = i7 - 2;
        byte[] bArr2 = new byte[i11];
        System.arraycopy(bArr, 0, bArr2, 0, i11);
        int iD = ru.himik.nightscream.kascada.x.b.d(bArr2);
        bArr[i11] = ru.himik.nightscream.kascada.x.b.b(iD);
        bArr[i7 - 1] = ru.himik.nightscream.kascada.x.b.a(iD);
        return bArr;
    }

    public static byte[] c(int[] iArr) {
        int i2 = (iArr[8] * 256) + iArr[9];
        int i3 = iArr[11];
        int i4 = i2 + i3;
        int i5 = ru.himik.nightscream.kascada.q.d.b.E;
        if (i4 > i5 || i3 > i5) {
            return null;
        }
        int i6 = i3 * 2;
        byte[] bArr = new byte[i6 + 9];
        bArr[0] = (byte) iArr[0];
        bArr[1] = (byte) iArr[1];
        bArr[5] = (byte) (i6 + 3);
        bArr[6] = 1;
        bArr[7] = 3;
        bArr[8] = (byte) i6;
        for (int i7 = 0; i7 < i3; i7++) {
            int i8 = (i7 * 2) + 9;
            int i9 = i2 + i7;
            bArr[i8] = ru.himik.nightscream.kascada.x.b.e(MyApplication.b().v0.f9265j[i9])[2];
            bArr[i8 + 1] = ru.himik.nightscream.kascada.x.b.e(MyApplication.b().v0.f9265j[i9])[3];
        }
        return bArr;
    }

    public static byte[] d(int[] iArr) {
        int i2 = ((iArr[2] * 256) + iArr[3]) / 16;
        int i3 = ((iArr[2] * 256) + iArr[3]) % 16;
        if (i2 > ru.himik.nightscream.kascada.q.d.b.E) {
            return null;
        }
        MyApplication.b().v0.K(i2, i3, iArr[4] == 255);
        return new byte[]{(byte) iArr[0], (byte) iArr[1], (byte) iArr[2], (byte) iArr[3], (byte) iArr[4], (byte) iArr[5], (byte) iArr[6], (byte) iArr[7]};
    }

    public static byte[] e(int[] iArr) {
        int i2 = (iArr[2] * 256) + iArr[3];
        int i3 = (iArr[4] * 256) + iArr[5];
        if (i2 > ru.himik.nightscream.kascada.q.d.b.E) {
            return null;
        }
        MyApplication.b().v0.f9265j[i2] = i3;
        byte[] bArr = new byte[6];
        byte[] bArr2 = {1, 6, (byte) iArr[2], (byte) iArr[3], (byte) iArr[4], (byte) iArr[5], ru.himik.nightscream.kascada.x.b.b(iD), ru.himik.nightscream.kascada.x.b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 6);
        int iD = ru.himik.nightscream.kascada.x.b.d(bArr);
        return bArr2;
    }

    public static byte[] f(int[] iArr) {
        int i2 = (iArr[8] * 256) + iArr[9];
        int i3 = (iArr[10] * 256) + iArr[11];
        if (i2 > ru.himik.nightscream.kascada.q.d.b.E) {
            return null;
        }
        MyApplication.b().v0.f9265j[i2] = i3;
        return new byte[]{(byte) iArr[0], (byte) iArr[1], (byte) iArr[2], (byte) iArr[3], (byte) iArr[4], (byte) iArr[5], (byte) iArr[6], (byte) iArr[7], (byte) iArr[8], (byte) iArr[9], (byte) iArr[10], (byte) iArr[11]};
    }

    public static byte[] g(int[] iArr) {
        int i2 = ((iArr[2] * 256) + iArr[3]) / 16;
        int i3 = ((iArr[2] * 256) + iArr[3]) % 16;
        int i4 = iArr[5];
        int i5 = (iArr[2] * 256) + iArr[3] + i4;
        int i6 = ru.himik.nightscream.kascada.q.d.b.E;
        if (i5 > i6 * 16 || i4 > i6) {
            return null;
        }
        int i7 = 0;
        while (true) {
            boolean z = true;
            if (i7 >= i4) {
                byte[] bArr = new byte[6];
                byte[] bArr2 = {1, 15, (byte) iArr[2], (byte) iArr[3], (byte) iArr[4], (byte) iArr[5], ru.himik.nightscream.kascada.x.b.b(iD), ru.himik.nightscream.kascada.x.b.a(iD)};
                System.arraycopy(bArr2, 0, bArr, 0, 6);
                int iD = ru.himik.nightscream.kascada.x.b.d(bArr);
                return bArr2;
            }
            int i8 = (iArr[(i7 / 8) + 7] >> (i7 % 8)) & 1;
            ru.himik.nightscream.kascada.q.d.b bVar = MyApplication.b().v0;
            int i9 = (i2 * 16) + i3 + i7;
            int i10 = i9 / 16;
            int i11 = i9 % 16;
            if (i8 != 1) {
                z = false;
            }
            bVar.K(i10, i11, z);
            i7++;
        }
    }

    public static byte[] h(int[] iArr) {
        int i2 = (iArr[2] * 256) + iArr[3];
        int i3 = iArr[5];
        int i4 = i2 + i3;
        int i5 = ru.himik.nightscream.kascada.q.d.b.E;
        if (i4 > i5 || i3 > i5) {
            return null;
        }
        for (int i6 = 0; i6 < i3; i6++) {
            int i7 = (i6 * 2) + 7;
            MyApplication.b().v0.f9265j[i2 + i6] = (iArr[i7] * 256) + iArr[i7 + 1];
        }
        byte[] bArr = new byte[6];
        byte[] bArr2 = {1, 16, (byte) iArr[2], (byte) iArr[3], (byte) iArr[4], (byte) iArr[5], ru.himik.nightscream.kascada.x.b.b(iD), ru.himik.nightscream.kascada.x.b.a(iD)};
        System.arraycopy(bArr2, 0, bArr, 0, 6);
        int iD = ru.himik.nightscream.kascada.x.b.d(bArr);
        return bArr2;
    }

    public static byte[] i(int[] iArr) {
        int i2 = (iArr[8] * 256) + iArr[9];
        int i3 = iArr[11];
        int i4 = i2 + i3;
        int i5 = ru.himik.nightscream.kascada.q.d.b.E;
        if (i4 > i5 || i3 > i5) {
            return null;
        }
        for (int i6 = 0; i6 < i3; i6++) {
            int i7 = (i6 * 2) + 13;
            MyApplication.b().v0.f9265j[i2 + i6] = (iArr[i7] * 256) + iArr[i7 + 1];
        }
        return new byte[]{(byte) iArr[0], (byte) iArr[1], 0, 0, 0, 6, 1, 16, (byte) iArr[8], (byte) iArr[9], (byte) iArr[10], (byte) iArr[11]};
    }
}
