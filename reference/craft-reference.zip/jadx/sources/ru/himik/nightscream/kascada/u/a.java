package ru.himik.nightscream.kascada.u;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class a {
    private String a;
    private String b;
    private String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f9363d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private String f9364e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private String f9365f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private String f9366g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private String f9367h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private String f9368i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f9369j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private String f9370k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private String f9371l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private String f9372m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f9373n;
    private ArrayList<String> o;
    private Context p;
    private d q;
    private c r;

    public static final class b {
        private Context a;
        private String b;
        private String c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private String f9374d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private String f9375e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private String f9376f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private String f9377g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private String f9378h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private String f9379i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private String f9380j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        private boolean f9381k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        private ArrayList<String> f9382l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        private String f9383m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        private String f9384n;
        private String o;
        private boolean p;
        private d q;
        private c r;

        private b(Context context) {
            this.f9378h = "";
            this.f9379i = "";
            this.f9380j = "text/plain";
            this.f9381k = true;
            this.f9382l = new ArrayList<>();
            this.p = true;
            this.a = context;
            this.f9383m = context.getString(R.string.msg_sending_email);
            this.f9384n = context.getString(R.string.msg_email_sent_successfully);
            this.o = context.getString(R.string.msg_error_sending_email);
        }

        public b A(String str) {
            this.f9374d = str;
            return this;
        }

        public b B(String str) {
            this.f9378h = str;
            return this;
        }

        public b C(String str) {
            this.f9380j = str;
            return this;
        }

        public b D(String str) {
            this.b = str;
            return this;
        }

        public a s() {
            return new a(this);
        }

        public a t() {
            a aVarS = s();
            aVarS.t();
            return aVarS;
        }

        public b u(String str) {
            this.f9379i = str;
            return this;
        }

        public b v(String str) {
            this.f9375e = str;
            return this;
        }

        public b w(c cVar) {
            this.r = cVar;
            return this;
        }

        public b x(d dVar) {
            this.q = dVar;
            return this;
        }

        public b y(String str) {
            this.c = str;
            return this;
        }

        public b z(boolean z) {
            this.p = z;
            return this;
        }
    }

    public interface c {
        void a();
    }

    public interface d {
        void a();
    }

    public class e extends AsyncTask<String, Void, Boolean> {
        private ProgressDialog a;

        public e() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Boolean doInBackground(String... strArr) {
            try {
                ru.himik.nightscream.kascada.u.b bVar = new ru.himik.nightscream.kascada.u.b(a.this.a, a.this.b, a.this.f9369j);
                if (!a.this.o.isEmpty()) {
                    for (int i2 = 0; i2 < a.this.o.size(); i2++) {
                        if (!((String) a.this.o.get(i2)).isEmpty()) {
                            bVar.a((String) a.this.o.get(i2));
                        }
                    }
                }
                bVar.b(a.this.f9366g, a.this.f9367h, a.this.a, a.this.c, a.this.f9363d, a.this.f9364e, a.this.f9365f, a.this.f9368i);
                return Boolean.TRUE;
            } catch (Exception e2) {
                ru.himik.nightscream.kascada.w.b.a("Email", "[EMAIL] " + Arrays.toString(e2.getStackTrace()));
                e2.printStackTrace();
                return Boolean.FALSE;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void onPostExecute(Boolean bool) {
            super.onPostExecute(bool);
            ProgressDialog progressDialog = this.a;
            if (progressDialog != null && progressDialog.isShowing()) {
                this.a.dismiss();
            }
            if (bool.booleanValue()) {
                if (a.this.f9373n && !TextUtils.isEmpty(a.this.f9371l)) {
                    Toast.makeText(a.this.p, a.this.f9371l, 0).show();
                }
                if (a.this.q != null) {
                    a.this.q.a();
                    return;
                }
                return;
            }
            if (a.this.f9373n && !TextUtils.isEmpty(a.this.f9372m)) {
                Toast.makeText(a.this.p, a.this.f9372m, 0).show();
            }
            if (a.this.r != null) {
                a.this.r.a();
            }
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            super.onPreExecute();
            if (a.this.f9373n) {
                ProgressDialog progressDialog = new ProgressDialog(a.this.p);
                this.a = progressDialog;
                progressDialog.setMessage(a.this.f9370k);
                this.a.setCancelable(false);
                this.a.show();
            }
        }
    }

    private a(b bVar) {
        this.f9373n = true;
        this.o = new ArrayList<>();
        this.p = bVar.a;
        this.o = bVar.f9382l;
        this.a = bVar.b;
        this.b = bVar.c;
        this.c = bVar.f9374d;
        this.f9363d = bVar.f9375e;
        this.f9364e = bVar.f9376f;
        this.f9365f = bVar.f9377g;
        this.f9366g = bVar.f9378h;
        this.f9367h = bVar.f9379i;
        this.f9368i = bVar.f9380j;
        this.f9369j = bVar.f9381k;
        w(bVar.f9383m);
        y(bVar.f9384n);
        x(bVar.o);
        this.f9373n = bVar.p;
        v(bVar.q);
        u(bVar.r);
    }

    public static b s(Context context) {
        return new b(context);
    }

    public void t() {
        if (TextUtils.isEmpty(this.a)) {
            throw new IllegalArgumentException("You didn't set a Gmail username");
        }
        if (TextUtils.isEmpty(this.b)) {
            throw new IllegalArgumentException("You didn't set a Gmail password");
        }
        if (TextUtils.isEmpty(this.f9363d) && TextUtils.isEmpty(this.f9364e) && TextUtils.isEmpty(this.f9365f)) {
            throw new IllegalArgumentException("You didn't set any recipient addresses");
        }
        ru.himik.nightscream.kascada.u.d.a(this.p);
        new e().execute(new String[0]);
    }

    public void u(c cVar) {
        this.r = cVar;
    }

    public void v(d dVar) {
        this.q = dVar;
    }

    public void w(String str) {
        this.f9370k = str;
    }

    public void x(String str) {
        this.f9372m = str;
    }

    public void y(String str) {
        this.f9371l = str;
    }
}
