package ru.himik.nightscream.kascada;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.location.Location;
import android.location.LocationListener;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.Display;
import android.view.DragEvent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.sun.mail.imap.IMAPStore;
import com.yandex.metrica.YandexMetrica;
import com.yandex.metrica.YandexMetricaDefaultValues;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Connections.Cloud.CloudConnector;
import ru.himik.nightscream.kascada.Connections.Usb.driver.FtdiSerialDriver;
import ru.himik.nightscream.kascada.Connections.Wifi.WifiConnector;
import ru.himik.nightscream.kascada.CustomComponents.CustomDynText;
import ru.himik.nightscream.kascada.CustomComponents.CustomLabel;
import ru.himik.nightscream.kascada.CustomComponents.CustomList;
import ru.himik.nightscream.kascada.CustomComponents.CustomSound;
import ru.himik.nightscream.kascada.Logic.ABS;
import ru.himik.nightscream.kascada.Logic.FB_AND;
import ru.himik.nightscream.kascada.Logic.FB_ARITHMETIC_FLOAT;
import ru.himik.nightscream.kascada.Logic.FB_ARITHMETIC_INT;
import ru.himik.nightscream.kascada.Logic.FB_ARRAY;
import ru.himik.nightscream.kascada.Logic.FB_CHANGE_F;
import ru.himik.nightscream.kascada.Logic.FB_CHANGE_I;
import ru.himik.nightscream.kascada.Logic.FB_COMPARE;
import ru.himik.nightscream.kascada.Logic.FB_COMPARE_FLOAT;
import ru.himik.nightscream.kascada.Logic.FB_CTU;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.Logic.FB_MOVE;
import ru.himik.nightscream.kascada.Logic.FB_MX;
import ru.himik.nightscream.kascada.Logic.FB_OR;
import ru.himik.nightscream.kascada.Logic.FB_POW;
import ru.himik.nightscream.kascada.Logic.FB_RS;
import ru.himik.nightscream.kascada.Logic.FB_SEL;
import ru.himik.nightscream.kascada.Logic.FB_TIMER;
import ru.himik.nightscream.kascada.Logic.FB_TRIGGER;
import ru.himik.nightscream.kascada.Logic.FB_XOR;
import ru.himik.nightscream.kascada.Logic.FloatToInt;
import ru.himik.nightscream.kascada.Logic.IntToFloat;
import ru.himik.nightscream.kascada.Logic.LOG;
import ru.himik.nightscream.kascada.Logic.MQTT_PUBLISHER;
import ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER;
import ru.himik.nightscream.kascada.Logic.ODTEMP;
import ru.himik.nightscream.kascada.Logic.SIN;
import ru.himik.nightscream.kascada.Logic.Sensor_Light;
import ru.himik.nightscream.kascada.Logic.Sensor_Orientation;
import ru.himik.nightscream.kascada.Logic.Sensor_Speed;
import ru.himik.nightscream.kascada.Logic.Sunrise_GPS;
import ru.himik.nightscream.kascada.Logic.Var;
import ru.himik.nightscream.kascada.Logic.VarFloat;
import ru.himik.nightscream.kascada.Logic.VarInt;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameIn;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameOut;
import ru.himik.nightscream.kascada.Logic.VarOut;
import ru.himik.nightscream.kascada.Logic.VarOutFloat;
import ru.himik.nightscream.kascada.Logic.VarOutInt;
import ru.himik.nightscream.kascada.Logic.WordToFloat;
import ru.himik.nightscream.kascada.Preference.NetworkDevicePref.PrefActivityNetworkDevice;
import ru.himik.nightscream.kascada.Preference.x0;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class mbCanvas extends androidx.appcompat.app.d {
    public static RelativeLayout X0;
    static ru.himik.nightscream.kascada.a0 d1;
    public static ru.himik.nightscream.kascada.Logic.a f1;
    public Handler C;
    boolean D;
    Timer E;
    IntentFilter F;
    IntentFilter G;
    Intent H;
    ru.himik.nightscream.kascada.p K;
    ru.himik.nightscream.kascada.CustomComponents.p L;
    boolean M0;
    float N0;
    TextView O;
    float O0;
    ru.himik.nightscream.kascada.v Q;
    public ru.himik.nightscream.kascada.c0.a R;
    boolean S;
    ru.himik.nightscream.kascada.z U;
    LinearLayout W;
    FrameLayout a;
    ImageView a0;
    ImageView b;
    ImageView b0;
    ImageView c;
    ImageView c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    ImageView f9199d;
    ru.himik.nightscream.kascada.t.b d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    ImageView f9200e;
    ru.himik.nightscream.kascada.t.c e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    ImageView f9201f;
    ru.himik.nightscream.kascada.t.d.b f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    View f9202g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    ru.himik.nightscream.kascada.Bd.e f9203h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public View f9204i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.a f9205j;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    RelativeLayout f9207l;
    androidx.fragment.app.n l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    ImageView f9208m;
    RelativeLayout m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    ImageView f9209n;
    BroadcastReceiver p0;
    public static ArrayList<ru.himik.nightscream.kascada.q.a> Y0 = new ArrayList<>();
    public static boolean Z0 = false;
    public static int a1 = 1;
    public static int b1 = 100;
    public static boolean c1 = false;
    public static int e1 = 25;
    public static boolean g1 = false;
    public static ru.himik.nightscream.kascada.Utils.o h1 = null;
    public static float i1 = 0.0f;
    public static float j1 = 0.0f;
    public static float k1 = 0.0f;
    public static int l1 = 0;
    public static float m1 = 0.0f;
    public static int n1 = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f9206k = false;
    ru.himik.nightscream.kascada.x.a o = new ru.himik.nightscream.kascada.x.a();
    boolean I = false;
    int J = 0;
    public int M = 0;
    public int N = 0;
    public boolean P = false;
    boolean T = false;
    public SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> V = new SparseArray<>();
    public SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> X = new SparseArray<>();
    boolean Y = false;
    int Z = 0;
    ru.himik.nightscream.kascada.Connections.Cloud.b g0 = null;
    boolean h0 = false;
    boolean i0 = false;
    boolean j0 = false;
    private int k0 = 0;
    i.b.l.a n0 = new i.b.l.a();
    IntentFilter o0 = new IntentFilter("hmikascada.ru.broadcast");
    View.OnClickListener q0 = new g0();
    View.OnClickListener r0 = new r0();
    View.OnClickListener s0 = new s0();
    View.OnClickListener t0 = new t0();
    BroadcastReceiver u0 = new b();
    private LocationListener v0 = new c();
    final SensorEventListener w0 = new d(this);
    boolean x0 = false;
    ArrayList<JSONObject> y0 = new ArrayList<>();
    int z0 = 0;
    boolean A0 = false;
    float B0 = 0.0f;
    float C0 = 0.0f;
    View.OnTouchListener D0 = new k();
    View.OnTouchListener E0 = new q();
    SeekBar.OnSeekBarChangeListener F0 = new r();
    View.OnTouchListener G0 = new s();
    ru.himik.nightscream.kascada.CustomComponents.v.c H0 = new t();
    ru.himik.nightscream.kascada.CustomComponents.o.d I0 = new u();
    View.OnTouchListener J0 = new w();
    View.OnTouchListener K0 = new x(this);
    View.OnLongClickListener L0 = new y();
    View.OnDragListener P0 = new z();
    View.OnDragListener Q0 = new a0();
    View.OnClickListener R0 = new p0();
    public boolean S0 = false;
    public ru.himik.nightscream.kascada.Logic.c.a T0 = null;
    ArrayList<FB_MACRO> U0 = new ArrayList<>();
    Integer V0 = 0;
    FB_MACRO W0 = null;

    class a extends Handler {

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.mbCanvas$a$a, reason: collision with other inner class name */
        class RunnableC0300a implements Runnable {
            final /* synthetic */ MotionEvent[] a;
            final /* synthetic */ int b;

            RunnableC0300a(a aVar, MotionEvent[] motionEventArr, int i2) {
                this.a = motionEventArr;
                this.b = i2;
            }

            @Override // java.lang.Runnable
            public void run() {
                long jUptimeMillis = SystemClock.uptimeMillis();
                this.a[0] = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 1, 10.0f, 10.0f, 0);
                ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(this.b)).dispatchTouchEvent(this.a[0]);
            }
        }

        a() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            Button button;
            TextView textView;
            ImageView imageView;
            View view;
            Context applicationContext;
            StringBuilder sb;
            Resources resources;
            int i2;
            Context applicationContext2;
            StringBuilder sb2;
            Resources resources2;
            int i3;
            Context applicationContext3;
            Resources resources3;
            int i4;
            Toast toastMakeText;
            Context applicationContext4;
            Resources resources4;
            int i5;
            String string;
            Toast toastMakeText2;
            mbCanvas mbcanvas = mbCanvas.this;
            boolean z = mbcanvas.f9206k;
            if (z) {
                try {
                    switch (message.what) {
                        case 1:
                            int i6 = message.arg1;
                            if (i6 == 1) {
                                if (((Integer) message.obj).intValue() == 255 || ((Integer) message.obj).intValue() == 1) {
                                    ((ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(message.arg2)).setState(true);
                                    ((ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(message.arg2)).setConnectionTimeOut(false);
                                    ((ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(message.arg2)).invalidate();
                                }
                                if (((Integer) message.obj).intValue() == 0) {
                                    ((ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(message.arg2)).setState(false);
                                }
                            } else if (i6 == 28) {
                                ((ru.himik.nightscream.kascada.CustomComponents.j) MyApplication.b().e0.get(message.arg2)).b(((Integer) message.obj).intValue());
                            } else if (i6 == 100) {
                                ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(message.arg2)).d((int[]) message.obj);
                            } else {
                                if (i6 != 102) {
                                    if (i6 != 103) {
                                        switch (i6) {
                                            case 4:
                                                ((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(message.arg2)).setValue((int[]) message.obj);
                                                ((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(message.arg2)).setConnectionTimeOut(false);
                                                textView = (ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(message.arg2);
                                                textView.invalidate();
                                                break;
                                            case 5:
                                                ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(message.arg2)).setValue(((Integer) message.obj).intValue());
                                                ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(message.arg2)).setConnectionTimeOut(false);
                                                imageView = (ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(message.arg2);
                                                imageView.invalidate();
                                                break;
                                            case 6:
                                                ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(message.arg2)).setConnectionTimeOut(false);
                                                button = (ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(message.arg2);
                                                button.invalidate();
                                                break;
                                            case 7:
                                                ((CustomDynText) MyApplication.b().K.get(message.arg2)).setState(((Integer) message.obj).intValue());
                                                ((CustomDynText) MyApplication.b().K.get(message.arg2)).setConnectionTimeOut(false);
                                                textView = (CustomDynText) MyApplication.b().K.get(message.arg2);
                                                textView.invalidate();
                                                break;
                                            case 8:
                                                ((ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(message.arg2)).setValue((int[]) message.obj);
                                                ((ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(message.arg2)).setConnectionTimeOut(false);
                                                textView = (ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(message.arg2);
                                                textView.invalidate();
                                                break;
                                            case 9:
                                                ((Integer) message.obj).intValue();
                                                ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(message.arg2)).c(((Integer) message.obj).intValue());
                                                break;
                                            case 10:
                                                ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(message.arg2)).e(((Integer) message.obj).intValue());
                                                break;
                                            case 11:
                                                ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(message.arg2)).setValue(((Integer) message.obj).intValue());
                                                ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(message.arg2)).setConnectionTimeOut(false);
                                                break;
                                            case 12:
                                                ((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(message.arg2)).setSpeed(((Integer) message.obj).intValue());
                                                ((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(message.arg2)).setConnectionTimeOut(false);
                                                break;
                                            case 13:
                                                ((ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(message.arg2)).setProgress(((Integer) message.obj).intValue());
                                                ((ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(message.arg2)).setConnectionTimeOut(false);
                                                break;
                                            case 14:
                                                ((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(message.arg2)).g((int[]) message.obj);
                                                ((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(message.arg2)).setConnectionTimeOut(false);
                                                break;
                                            case 15:
                                                ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(message.arg2)).setValue(((Integer) message.obj).intValue());
                                                break;
                                            case 16:
                                                ((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(message.arg2)).setValue(((Integer) message.obj).intValue());
                                                ((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(message.arg2)).setConnectionTimeOut(false);
                                                break;
                                            case 17:
                                                ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(message.arg2)).h(((Integer) message.obj).intValue(), mbCanvas.this.f9206k);
                                                ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(message.arg2)).setConnectionTimeOut(false);
                                                break;
                                            default:
                                                switch (i6) {
                                                    case 19:
                                                        ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(message.arg2)).setValueSource((int[]) message.obj);
                                                        if (!mbCanvas.this.f9206k) {
                                                        }
                                                        break;
                                                    case 20:
                                                        ((CustomList) MyApplication.b().X.get(message.arg2)).setValue(((Integer) message.obj).intValue());
                                                        ((CustomList) MyApplication.b().X.get(message.arg2)).setConnectionTimeOut(false);
                                                        textView = (CustomList) MyApplication.b().X.get(message.arg2);
                                                        textView.invalidate();
                                                        break;
                                                    case 21:
                                                        ((CustomSound) MyApplication.b().Y.get(message.arg2)).setValue(((Integer) message.obj).intValue());
                                                        ((CustomSound) MyApplication.b().Y.get(message.arg2)).setConnectionTimeOut(false);
                                                        button = (CustomSound) MyApplication.b().Y.get(message.arg2);
                                                        button.invalidate();
                                                        break;
                                                    case 22:
                                                        ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(message.arg2)).setValueSource((byte[]) message.obj);
                                                        break;
                                                    default:
                                                        switch (i6) {
                                                            case 24:
                                                                ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(message.arg2)).setValue(((Integer) message.obj).intValue());
                                                                ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(message.arg2)).setConnectionTimeOut(false);
                                                                break;
                                                            case 25:
                                                                ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(message.arg2)).b(((Integer) message.obj).intValue());
                                                                break;
                                                            case 26:
                                                                ((ru.himik.nightscream.kascada.CustomComponents.b0) MyApplication.b().d0.get(message.arg2)).e(((Integer) message.obj).intValue());
                                                                break;
                                                            default:
                                                                switch (i6) {
                                                                    case 150:
                                                                        ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(message.arg2)).f(((Integer) message.obj).intValue());
                                                                        break;
                                                                    case 151:
                                                                        ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(message.arg2)).l(((Integer) message.obj).intValue());
                                                                        break;
                                                                    case 152:
                                                                        ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(message.arg2)).n((int[]) message.obj);
                                                                        break;
                                                                    case 153:
                                                                        ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(message.arg2)).m((int[]) message.obj);
                                                                        break;
                                                                    case 154:
                                                                        ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(message.arg2)).r(((Integer) message.obj).intValue());
                                                                        break;
                                                                }
                                                                break;
                                                        }
                                                        break;
                                                }
                                                break;
                                        }
                                    } else {
                                        ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(message.arg2)).a(((Integer) message.obj).intValue());
                                        if (mbCanvas.this.f9206k) {
                                            ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(message.arg2)).setConnectionTimeOut(false);
                                        }
                                        break;
                                    }
                                } else {
                                    ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(message.arg2)).a(((Integer) message.obj).intValue());
                                    if (!mbCanvas.this.f9206k) {
                                    }
                                }
                                ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(message.arg2)).setConnectionTimeOut(false);
                            }
                            break;
                        case 2:
                            if (z) {
                                int i7 = message.arg1;
                                if (i7 != 1) {
                                    if (i7 != 24) {
                                        if (i7 != 100) {
                                            switch (i7) {
                                                case 4:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(message.arg2)).setConnectionTimeOut(true);
                                                    textView = (ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(message.arg2);
                                                    textView.invalidate();
                                                    break;
                                                case 5:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(message.arg2)).setConnectionTimeOut(true);
                                                    imageView = (ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(message.arg2);
                                                    imageView.invalidate();
                                                    break;
                                                case 6:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(message.arg2)).setConnectionTimeOut(true);
                                                    button = (ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(message.arg2);
                                                    break;
                                                case 7:
                                                    ((CustomDynText) MyApplication.b().K.get(message.arg2)).setConnectionTimeOut(true);
                                                    textView = (CustomDynText) MyApplication.b().K.get(message.arg2);
                                                    textView.invalidate();
                                                    break;
                                                case 8:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(message.arg2)).setConnectionTimeOut(true);
                                                    textView = (ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(message.arg2);
                                                    textView.invalidate();
                                                    break;
                                                case 9:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(message.arg2)).setConnectionTimeOut(true);
                                                    button = (ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(message.arg2);
                                                    break;
                                                case 10:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(message.arg2)).setConnectionTimeOut(true);
                                                    button = (ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(message.arg2);
                                                    break;
                                                case 11:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(message.arg2)).setConnectionTimeOut(true);
                                                    ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(message.arg2)).invalidate();
                                                    break;
                                                case 12:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(message.arg2)).setConnectionTimeOut(true);
                                                    view = (ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(message.arg2);
                                                    break;
                                                case 13:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(message.arg2)).setConnectionTimeOut(true);
                                                    ((ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(message.arg2)).invalidate();
                                                    break;
                                                case 14:
                                                    ((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(message.arg2)).setConnectionTimeOut(true);
                                                    view = (ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(message.arg2);
                                                    break;
                                                default:
                                                    switch (i7) {
                                                        case 16:
                                                            ((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(message.arg2)).setConnectionTimeOut(true);
                                                            imageView = (ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(message.arg2);
                                                            imageView.invalidate();
                                                            break;
                                                        case 17:
                                                            ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(message.arg2)).setConnectionTimeOut(true);
                                                            imageView = (ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(message.arg2);
                                                            imageView.invalidate();
                                                            break;
                                                        case 18:
                                                            ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(message.arg2)).setConnectionTimeOut(true);
                                                            button = (ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(message.arg2);
                                                            break;
                                                        case 19:
                                                            ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(message.arg2)).setConnectionTimeOut(true);
                                                            button = (ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(message.arg2);
                                                            break;
                                                        case 20:
                                                            ((CustomList) MyApplication.b().X.get(message.arg2)).setConnectionTimeOut(true);
                                                            textView = (CustomList) MyApplication.b().X.get(message.arg2);
                                                            textView.invalidate();
                                                            break;
                                                    }
                                                    break;
                                            }
                                        } else {
                                            ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(message.arg2)).c("!NO RESPONSE!");
                                            break;
                                        }
                                    } else {
                                        ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(message.arg2)).setConnectionTimeOut(true);
                                        view = (ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(message.arg2);
                                    }
                                    view.invalidate();
                                } else {
                                    ((ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(message.arg2)).setConnectionTimeOut(true);
                                    button = (ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(message.arg2);
                                }
                                button.invalidate();
                            }
                            break;
                        case 3:
                            if (z) {
                                int i8 = message.arg1;
                                if (i8 == 1) {
                                    if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                        applicationContext = mbcanvas.getApplicationContext();
                                        sb = new StringBuilder();
                                        resources = mbCanvas.this.getResources();
                                        i2 = R.string.bluetooth_error_connection;
                                        sb.append(resources.getString(i2));
                                        sb.append(" ");
                                        sb.append(MyApplication.b().f9036d.get(message.arg2).d());
                                        Toast.makeText(applicationContext, sb.toString(), 0).show();
                                    }
                                    mbcanvas = mbCanvas.this;
                                    mbcanvas.l0(message.arg2, true);
                                } else if (i8 == 2) {
                                    if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                        applicationContext = mbcanvas.getApplicationContext();
                                        sb = new StringBuilder();
                                        resources = mbCanvas.this.getResources();
                                        i2 = R.string.bluetooth_error_critical;
                                        sb.append(resources.getString(i2));
                                        sb.append(" ");
                                        sb.append(MyApplication.b().f9036d.get(message.arg2).d());
                                        Toast.makeText(applicationContext, sb.toString(), 0).show();
                                    }
                                    mbcanvas = mbCanvas.this;
                                    mbcanvas.l0(message.arg2, true);
                                } else if (i8 != 3) {
                                    if (i8 == 4) {
                                        if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                            Toast.makeText(mbcanvas.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.bluetooth_error_connect_with_device) + " " + MyApplication.b().f9036d.get(message.arg2).d(), 0).show();
                                        }
                                        MyApplication.b().f9036d.get(message.arg2).n(false);
                                        mbCanvas.this.l0(message.arg2, true);
                                        break;
                                    } else if (i8 == 5) {
                                        if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                            applicationContext2 = mbcanvas.getApplicationContext();
                                            sb2 = new StringBuilder();
                                            resources2 = mbCanvas.this.getResources();
                                            i3 = R.string.bluetooth_error_connected_to;
                                            sb2.append(resources2.getString(i3));
                                            sb2.append(" ");
                                            sb2.append(MyApplication.b().f9036d.get(message.arg2).d());
                                            Toast.makeText(applicationContext2, sb2.toString(), 1).show();
                                        }
                                        MyApplication.b().f9036d.get(message.arg2).n(true);
                                        mbCanvas.this.l0(message.arg2, false);
                                        break;
                                    }
                                } else if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                    Toast.makeText(mbcanvas.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.bluetooth_error_reconnect), 0).show();
                                }
                                MyApplication.b().f9036d.get(message.arg2).n(false);
                            }
                            break;
                        case 4:
                            applicationContext3 = mbcanvas.getApplicationContext();
                            resources3 = mbCanvas.this.getResources();
                            i4 = R.string.you_have_test_version;
                            toastMakeText = Toast.makeText(applicationContext3, resources3.getString(i4), 1);
                            toastMakeText.show();
                            break;
                        case 5:
                            int i9 = message.arg1;
                            if (i9 == 1) {
                                applicationContext4 = mbcanvas.getApplicationContext();
                                resources4 = mbCanvas.this.getResources();
                                i5 = R.string.archive_export_start;
                                toastMakeText = Toast.makeText(applicationContext4, resources4.getString(i5), 0);
                            } else if (i9 == 2) {
                                toastMakeText = Toast.makeText(mbcanvas.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.archive_export_successfully) + " " + message.arg2, 1);
                            } else if (i9 == 3) {
                                applicationContext3 = mbcanvas.getApplicationContext();
                                resources3 = mbCanvas.this.getResources();
                                i4 = R.string.archive_export_error;
                                toastMakeText = Toast.makeText(applicationContext3, resources3.getString(i4), 1);
                            }
                            toastMakeText.show();
                            break;
                        case 6:
                            int i10 = message.arg1;
                            if (i10 == 1) {
                                if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                    applicationContext2 = mbcanvas.getApplicationContext();
                                    sb2 = new StringBuilder();
                                    resources2 = mbCanvas.this.getResources();
                                    i3 = R.string.wifi_connect_to;
                                    sb2.append(resources2.getString(i3));
                                    sb2.append(" ");
                                    sb2.append(MyApplication.b().f9036d.get(message.arg2).d());
                                    Toast.makeText(applicationContext2, sb2.toString(), 1).show();
                                }
                                MyApplication.b().f9036d.get(message.arg2).n(true);
                                mbCanvas.this.l0(message.arg2, false);
                            } else {
                                if (i10 == 2) {
                                    if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                        applicationContext = mbcanvas.getApplicationContext();
                                        sb = new StringBuilder();
                                        resources = mbCanvas.this.getResources();
                                        i2 = R.string.wifi_error_connect;
                                        sb.append(resources.getString(i2));
                                        sb.append(" ");
                                        sb.append(MyApplication.b().f9036d.get(message.arg2).d());
                                        Toast.makeText(applicationContext, sb.toString(), 0).show();
                                    }
                                    mbcanvas = mbCanvas.this;
                                } else if (i10 == 3) {
                                    if (!mbCanvas.Z0 || mbCanvas.c1 || !z) {
                                        applicationContext = mbcanvas.getApplicationContext();
                                        sb = new StringBuilder();
                                        resources = mbCanvas.this.getResources();
                                        i2 = R.string.wifi_error_disconnect_timeout;
                                        sb.append(resources.getString(i2));
                                        sb.append(" ");
                                        sb.append(MyApplication.b().f9036d.get(message.arg2).d());
                                        Toast.makeText(applicationContext, sb.toString(), 0).show();
                                    }
                                    mbcanvas = mbCanvas.this;
                                } else if (i10 != 4) {
                                }
                                mbcanvas.l0(message.arg2, true);
                                MyApplication.b().f9036d.get(message.arg2).n(false);
                            }
                            break;
                        case 7:
                            applicationContext4 = mbcanvas.getApplicationContext();
                            resources4 = mbCanvas.this.getResources();
                            i5 = R.string.sms_come;
                            toastMakeText = Toast.makeText(applicationContext4, resources4.getString(i5), 0);
                            toastMakeText.show();
                            break;
                        case 8:
                            int i11 = message.arg1;
                            if (i11 != 1) {
                                if (i11 != 2) {
                                }
                                MyApplication.b().f9036d.get(message.arg2).n(false);
                                mbCanvas.this.l0(message.arg2, true);
                            }
                            MyApplication.b().f9036d.get(message.arg2).n(true);
                            mbCanvas.this.l0(message.arg2, false);
                            break;
                        case 9:
                            int i12 = message.arg1;
                            if (i12 == 1) {
                                mbcanvas.clickScreenLeft(null);
                                break;
                            } else if (i12 == 2) {
                                mbcanvas.clickScreenRight(null);
                                break;
                            }
                            break;
                        case 10:
                            mbcanvas.n0(((Integer) message.obj).intValue());
                            break;
                        case 11:
                            int iIntValue = ((Integer) message.obj).intValue();
                            if (iIntValue > 0) {
                                mbCanvas.X0.setBackgroundColor(ru.himik.nightscream.kascada.q.d.a.a[iIntValue]);
                            } else if (mbCanvas.a1 > 0) {
                                if (MyApplication.b().C.get(mbCanvas.a1 - 1).a().booleanValue()) {
                                    mbCanvas.X0.setBackgroundColor(MyApplication.b().C.get(mbCanvas.a1 - 1).b());
                                } else if (Build.VERSION.SDK_INT >= 16) {
                                    mbCanvas.X0.setBackground(MyApplication.b().C.get(mbCanvas.a1 - 1).c());
                                } else {
                                    mbCanvas.X0.setBackgroundDrawable(MyApplication.b().C.get(mbCanvas.a1 - 1).c());
                                }
                            }
                            break;
                        case 12:
                            if (z) {
                                try {
                                    Cursor cursorRawQuery = mbcanvas.f9203h.getWritableDatabase().rawQuery("SELECT pass FROM TableNameProject WHERE name= '" + MyApplication.b().m0 + "'", null);
                                    if (cursorRawQuery != null) {
                                        cursorRawQuery.moveToFirst();
                                        string = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pass"));
                                    } else {
                                        string = "";
                                    }
                                    if (string != null && !string.equals("")) {
                                        if (string.equals(message.obj + "")) {
                                            mbCanvas.this.w0();
                                        }
                                        break;
                                    }
                                } catch (Exception unused) {
                                    toastMakeText = Toast.makeText(mbCanvas.this.getApplicationContext(), R.string.msg_error_read_password_from_bd, 1);
                                    break;
                                }
                            }
                            break;
                        case 13:
                            int iIntValue2 = ((Integer) message.obj).intValue();
                            if (iIntValue2 == 1) {
                                mbCanvas.this.m0.setVisibility(0);
                                mbCanvas mbcanvas2 = mbCanvas.this;
                                if (mbcanvas2.f9206k) {
                                    mbcanvas2.B0(true);
                                }
                                mbCanvas.this.S = true;
                                MyApplication.b().a();
                                mbCanvas.this.finishAffinity();
                                break;
                            } else if (iIntValue2 == 2) {
                                mbCanvas.this.h(false);
                                break;
                            } else if (iIntValue2 == 3) {
                                mbCanvas.this.y0();
                                break;
                            } else if (iIntValue2 == 4) {
                                mbCanvas.this.A0();
                                break;
                            } else if (iIntValue2 == 5) {
                                ru.himik.nightscream.kascada.b0.d.a.c("каскада");
                                break;
                            }
                            break;
                        case 14:
                            int i13 = message.arg1;
                            if (i13 == 1) {
                                ((ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(message.arg2)).performClick();
                                break;
                            } else if (i13 == 6) {
                                int i14 = message.arg2;
                                MotionEvent[] motionEventArr = {MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 0, 10.0f, 10.0f, 0)};
                                ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(i14)).dispatchTouchEvent(motionEventArr[0]);
                                new Handler().postDelayed(new RunnableC0300a(this, motionEventArr, i14), 200L);
                                break;
                            } else if (i13 == 8) {
                                int i15 = message.arg2;
                                JSONObject jSONObject = (JSONObject) message.obj;
                                mbcanvas.t((ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(i15), jSONObject.getString("val"), jSONObject.getString("pass"));
                                break;
                            } else if (i13 == 13) {
                                ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(message.arg2);
                                if (mbCanvas.this.f9206k && ((Integer) message.obj).intValue() <= vVar.getMax()) {
                                    vVar.setProgress(((Integer) message.obj).intValue());
                                    if (vVar.f8909f.l() == 100) {
                                        vVar.f8909f.H(vVar.getProgress());
                                        MyApplication.b().v0.e(vVar.f8909f);
                                    } else if (vVar.f8909f.k() == -1) {
                                        toastMakeText2 = Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getApplicationContext().getResources().getString(R.string.toast_no_connection), 1);
                                        toastMakeText2.show();
                                    } else if (MyApplication.b().f9036d.get(mbCanvas.Y0.get(vVar.f8909f.k()).a()).k()) {
                                        vVar.f8909f.H(vVar.getProgress());
                                        ru.himik.nightscream.kascada.CustomComponents.b bVar = vVar.f8909f;
                                        bVar.x(mbCanvas.this.o.c(bVar, bVar.i()));
                                        mbCanvas.Y0.get(vVar.f8909f.k()).e(vVar.f8909f);
                                        ru.himik.nightscream.kascada.CustomComponents.b bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b(vVar.getIdComponent(), (byte) MyApplication.b().E.get(vVar.f8909f.l()).a(), vVar.f8909f.c(), (byte) 0, (byte) 3, vVar.getKey());
                                        bVar2.F(vVar.f8909f.r());
                                        bVar2.x(mbCanvas.this.o.c(bVar2, vVar.f8909f.i()));
                                        mbCanvas.Y0.get(vVar.f8909f.k()).c(bVar2);
                                    }
                                    break;
                                }
                            } else if (i13 == 100) {
                                mbcanvas.o0(message.arg2, (String) message.obj);
                                break;
                            }
                            break;
                        case 15:
                            int i16 = message.arg1;
                            if (i16 == 2) {
                                toastMakeText = Toast.makeText(mbcanvas.getApplicationContext(), R.string.toast_modbus_server_start_error, 0);
                                toastMakeText.show();
                                break;
                            } else if (i16 == 4) {
                                toastMakeText2 = Toast.makeText(mbcanvas.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.toast_modbus_server_client_connected) + " " + message.obj, 0);
                                toastMakeText2.show();
                                break;
                            }
                            break;
                        case 16:
                            MyApplication.b().v0.R(((Boolean) message.obj).booleanValue());
                            break;
                    }
                } catch (Exception unused2) {
                }
            }
        }
    }

    class a0 implements View.OnDragListener {
        a0() {
        }

        @Override // android.view.View.OnDragListener
        public boolean onDrag(View view, DragEvent dragEvent) {
            View view2 = (View) dragEvent.getLocalState();
            if (dragEvent.getAction() == 3) {
                if (view2 instanceof RelativeLayout) {
                    mbCanvas.this.X.clear();
                    for (int i2 = 0; i2 < mbCanvas.this.V.size(); i2++) {
                        SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = mbCanvas.this.V;
                        if (sparseArray.get(sparseArray.keyAt(i2)).p()) {
                            if (mbCanvas.this.X.size() == 0) {
                                mbCanvas mbcanvas = mbCanvas.this;
                                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = mbcanvas.X;
                                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray3 = mbcanvas.V;
                                sparseArray2.append(0, sparseArray3.get(sparseArray3.keyAt(i2)));
                            } else {
                                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray4 = mbCanvas.this.X;
                                int iKeyAt = sparseArray4.keyAt(sparseArray4.size() - 1) + 1;
                                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray5 = mbCanvas.this.V;
                                sparseArray4.append(iKeyAt, sparseArray5.get(sparseArray5.keyAt(i2)));
                            }
                        }
                    }
                    for (int i3 = 0; i3 < mbCanvas.this.X.size(); i3++) {
                        mbCanvas mbcanvas2 = mbCanvas.this;
                        SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray6 = mbcanvas2.X;
                        mbcanvas2.deleteView((View) sparseArray6.get(sparseArray6.keyAt(i3)));
                    }
                    mbCanvas.this.X.clear();
                    Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.deleted), 0).show();
                    return true;
                }
                Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.deleted), 0).show();
                mbCanvas.this.deleteView(view2);
            }
            return true;
        }
    }

    class b extends BroadcastReceiver {
        b() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (mbCanvas.this.f9206k) {
                String string = intent.getExtras().get("from").toString();
                String string2 = intent.getExtras().get("sms").toString();
                if (string == null || string2 == null) {
                    return;
                }
                mbCanvas.this.h0(string, string2);
            }
        }
    }

    class b0 implements Runnable {
        final /* synthetic */ String a;

        b0(String str) {
            this.a = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            Message messageObtainMessage;
            BufferedWriter bufferedWriter = null;
            Cursor cursorRawQuery = ((ru.himik.nightscream.kascada.CustomComponents.d) mbCanvas.this.f9204i).getDb().rawQuery("SELECT * FROM Archive", null);
            mbCanvas.this.C.obtainMessage(5, 1, 0).sendToTarget();
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath() + "/KaScada//Archive//" + MyApplication.b().m0 + "//");
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(file.getPath() + "//" + this.a + ".csv");
            if (!file2.exists()) {
                try {
                    file2.createNewFile();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
            try {
                bufferedWriter = new BufferedWriter(new FileWriter(file2, false));
            } catch (IOException e3) {
                e3.printStackTrace();
            }
            if (bufferedWriter == null) {
                messageObtainMessage = mbCanvas.this.C.obtainMessage(5, 3, 1);
            } else {
                try {
                    if (cursorRawQuery.moveToFirst()) {
                        do {
                            bufferedWriter.write(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var1")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var2")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var3")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var4")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("var5")).replace('.', ',') + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("_time")) + ";" + cursorRawQuery.getString(cursorRawQuery.getColumnIndex("_date")));
                            bufferedWriter.newLine();
                        } while (cursorRawQuery.moveToNext());
                    }
                } catch (Exception unused) {
                    mbCanvas.this.C.obtainMessage(5, 3, 0).sendToTarget();
                    try {
                        bufferedWriter.close();
                    } catch (IOException e4) {
                        e4.printStackTrace();
                    }
                }
                try {
                    bufferedWriter.flush();
                    bufferedWriter.close();
                } catch (IOException e5) {
                    e5.printStackTrace();
                }
                messageObtainMessage = mbCanvas.this.C.obtainMessage(5, 2, cursorRawQuery.getCount());
            }
            messageObtainMessage.sendToTarget();
        }
    }

    class c implements LocationListener {
        c() {
        }

        @Override // android.location.LocationListener
        public void onLocationChanged(Location location) {
            if (mbCanvas.this.f9206k) {
                mbCanvas.m1 = location.getSpeed() * 3.6f;
            }
            for (int i2 = 0; i2 < MyApplication.b().D.size(); i2++) {
                int iKeyAt = MyApplication.b().D.keyAt(i2);
                if (MyApplication.b().D.get(iKeyAt) instanceof Sunrise_GPS) {
                    ((Sunrise_GPS) MyApplication.b().D.get(iKeyAt)).setLatitude((float) location.getLatitude());
                    ((Sunrise_GPS) MyApplication.b().D.get(iKeyAt)).setLongitude((float) location.getLongitude());
                    ((Sunrise_GPS) MyApplication.b().D.get(iKeyAt)).u();
                }
            }
        }

        @Override // android.location.LocationListener
        public void onProviderDisabled(String str) {
        }

        @Override // android.location.LocationListener
        public void onProviderEnabled(String str) {
        }

        @Override // android.location.LocationListener
        public void onStatusChanged(String str, int i2, Bundle bundle) {
        }
    }

    class c0 implements DialogInterface.OnShowListener {
        final /* synthetic */ AlertDialog a;
        final /* synthetic */ EditText b;
        final /* synthetic */ EditText c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ EditText f9210d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ EditText f9211e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ EditText f9212f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final /* synthetic */ EditText f9213g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        final /* synthetic */ CheckBox f9214h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        final /* synthetic */ CheckBox f9215i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        final /* synthetic */ CheckBox f9216j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        final /* synthetic */ CheckBox f9217k;

        class a implements View.OnClickListener {
            a() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Context applicationContext;
                Resources resources;
                int i2;
                String strValueOf;
                String strValueOf2;
                String strValueOf3;
                String strValueOf4;
                String strValueOf5;
                int i3 = Integer.parseInt(c0.this.b.getText().toString());
                int i4 = Integer.parseInt(c0.this.c.getText().toString());
                int i5 = Integer.parseInt(c0.this.f9210d.getText().toString());
                int i6 = Integer.parseInt(c0.this.f9211e.getText().toString());
                int i7 = Integer.parseInt(c0.this.f9212f.getText().toString());
                int i8 = Integer.parseInt(c0.this.f9213g.getText().toString());
                if (i3 == 0 || i3 > 31 || i4 == 0 || i4 > 12 || i5 == 0) {
                    applicationContext = mbCanvas.this.getApplicationContext();
                    resources = mbCanvas.this.getResources();
                    i2 = R.string.date_wrong;
                } else {
                    if (i6 <= 24 && i7 <= 59 && i8 <= 59) {
                        boolean[] zArr = {c0.this.f9214h.isChecked(), c0.this.f9215i.isChecked(), c0.this.f9216j.isChecked(), c0.this.f9217k.isChecked()};
                        if (i6 < 10) {
                            strValueOf = "0" + String.valueOf(i6);
                        } else {
                            strValueOf = String.valueOf(i6);
                        }
                        if (i7 < 10) {
                            strValueOf2 = "0" + String.valueOf(i7);
                        } else {
                            strValueOf2 = String.valueOf(i7);
                        }
                        if (i8 < 10) {
                            strValueOf3 = "0" + String.valueOf(i8);
                        } else {
                            strValueOf3 = String.valueOf(i8);
                        }
                        if (i3 < 10) {
                            strValueOf4 = "0" + String.valueOf(i3);
                        } else {
                            strValueOf4 = String.valueOf(i3);
                        }
                        if (i4 < 10) {
                            strValueOf5 = "0" + String.valueOf(i4);
                        } else {
                            strValueOf5 = String.valueOf(i4);
                        }
                        ((ru.himik.nightscream.kascada.CustomComponents.d) mbCanvas.this.f9204i).s(i5 + "", strValueOf5, strValueOf4, strValueOf, strValueOf2, strValueOf3);
                        String str = i5 + "-" + strValueOf5 + "-" + strValueOf4;
                        Cursor cursorRawQuery = ((ru.himik.nightscream.kascada.CustomComponents.d) mbCanvas.this.f9204i).getDb().rawQuery("SELECT * FROM (SELECT * FROM Archive WHERE _time < '" + (strValueOf + ":" + strValueOf2 + ":" + strValueOf3) + "' and _date = '" + str + "' order by _id DESC limit 300) order by _id ASC", null);
                        if (cursorRawQuery.getCount() == 0) {
                            Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.data_empty), 0).show();
                            return;
                        }
                        Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.loaded) + " " + cursorRawQuery.getCount() + " " + mbCanvas.this.getResources().getString(R.string.records), 0).show();
                        mbCanvas.this.f(zArr, cursorRawQuery);
                        c0.this.a.dismiss();
                        return;
                    }
                    applicationContext = mbCanvas.this.getApplicationContext();
                    resources = mbCanvas.this.getResources();
                    i2 = R.string.time_wrong;
                }
                Toast.makeText(applicationContext, resources.getString(i2), 0).show();
            }
        }

        c0(AlertDialog alertDialog, EditText editText, EditText editText2, EditText editText3, EditText editText4, EditText editText5, EditText editText6, CheckBox checkBox, CheckBox checkBox2, CheckBox checkBox3, CheckBox checkBox4) {
            this.a = alertDialog;
            this.b = editText;
            this.c = editText2;
            this.f9210d = editText3;
            this.f9211e = editText4;
            this.f9212f = editText5;
            this.f9213g = editText6;
            this.f9214h = checkBox;
            this.f9215i = checkBox2;
            this.f9216j = checkBox3;
            this.f9217k = checkBox4;
        }

        @Override // android.content.DialogInterface.OnShowListener
        public void onShow(DialogInterface dialogInterface) {
            this.a.getButton(-1).setOnClickListener(new a());
        }
    }

    class d implements SensorEventListener {
        d(mbCanvas mbcanvas) {
        }

        @Override // android.hardware.SensorEventListener
        public void onAccuracyChanged(Sensor sensor, int i2) {
        }

        @Override // android.hardware.SensorEventListener
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.sensor.getType() == 3) {
                float[] fArr = sensorEvent.values;
                mbCanvas.i1 = fArr[0];
                mbCanvas.j1 = fArr[1];
                mbCanvas.k1 = fArr[2];
            }
            if (sensorEvent.sensor.getType() == 5) {
                mbCanvas.l1 = (int) sensorEvent.values[0];
            }
        }
    }

    class d0 implements Runnable {
        final /* synthetic */ ArrayList a;

        d0(ArrayList arrayList) {
            this.a = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            for (int i2 = 0; i2 < this.a.size(); i2++) {
                mbCanvas.this.L.f(((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).b(), ((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).a());
                mbCanvas.this.L.g(((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).c(), ((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).a());
                mbCanvas.this.L.h(((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).d(), ((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).a());
                mbCanvas.this.L.i(((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).e(), ((ru.himik.nightscream.kascada.CustomComponents.s) this.a.get(i2)).a());
            }
            mbCanvas.this.L.e();
        }
    }

    class e implements MultiplePermissionsListener {
        e() {
        }

        @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
        public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
            permissionToken.continuePermissionRequest();
        }

        @Override // com.karumi.dexter.listener.multi.MultiplePermissionsListener
        public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
            if (multiplePermissionsReport.areAllPermissionsGranted()) {
                mbCanvas.this.C0(false);
            } else {
                Toast.makeText(mbCanvas.this.getApplicationContext(), R.string.permission_denied_work_on, 1).show();
            }
        }
    }

    class e0 implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ String b;

        e0(EditText editText, String str) {
            this.a = editText;
            this.b = str;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            if (this.b.equals(this.a.getText().toString())) {
                mbCanvas.this.w0();
            } else {
                Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.pass_wrong), 0).show();
            }
        }
    }

    class f implements DialogInterface.OnClickListener {
        final /* synthetic */ com.rarepebble.colorpicker.b a;

        f(mbCanvas mbcanvas, com.rarepebble.colorpicker.b bVar) {
            this.a = bVar;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            mbCanvas.X0.setBackgroundColor(this.a.getColor());
            MyApplication.b().C.get(mbCanvas.a1 - 1).h(Boolean.TRUE);
            MyApplication.b().C.get(mbCanvas.a1 - 1).i(this.a.getColor());
        }
    }

    class f0 implements DialogInterface.OnClickListener {
        f0(mbCanvas mbcanvas) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class g implements DialogInterface.OnClickListener {
        g(mbCanvas mbcanvas) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class g0 implements View.OnClickListener {
        g0() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            new ru.himik.nightscream.kascada.r.f0().x1(mbCanvas.this.getSupportFragmentManager(), "");
        }
    }

    class h extends f.b.a.t.j.g<Bitmap> {
        h(int i2, int i3) {
            super(i2, i3);
        }

        @Override // f.b.a.t.j.j
        /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
        public void b(Bitmap bitmap, f.b.a.t.i.c<? super Bitmap> cVar) {
            MyApplication.b().C.get(mbCanvas.a1 - 1).k(new BitmapDrawable(mbCanvas.this.getApplicationContext().getResources(), bitmap));
            mbCanvas.this.y0();
        }
    }

    class h0 implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;

        h0(EditText editText) {
            this.a = editText;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            Context applicationContext;
            Resources resources;
            int i3;
            SQLiteDatabase writableDatabase = mbCanvas.this.f9203h.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("pass", this.a.getText().toString());
            if (writableDatabase.update("TableNameProject", contentValues, "name = ?", new String[]{MyApplication.b().m0}) > 0) {
                applicationContext = mbCanvas.this.getApplicationContext();
                resources = mbCanvas.this.getResources();
                i3 = R.string.pass_saved;
            } else {
                applicationContext = mbCanvas.this.getApplicationContext();
                resources = mbCanvas.this.getResources();
                i3 = R.string.error_pass_save;
            }
            Toast.makeText(applicationContext, resources.getString(i3), 0).show();
        }
    }

    class i extends f.b.a.t.j.g<Bitmap> {

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ x0 f9220d;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        i(int i2, int i3, x0 x0Var) {
            super(i2, i3);
            this.f9220d = x0Var;
        }

        @Override // f.b.a.t.j.j
        /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
        public void b(Bitmap bitmap, f.b.a.t.i.c<? super Bitmap> cVar) {
            this.f9220d.k(new BitmapDrawable(bitmap));
            mbCanvas.this.y0();
        }
    }

    class i0 implements DialogInterface.OnClickListener {
        i0(mbCanvas mbcanvas) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class j implements View.OnClickListener {
        final /* synthetic */ AlertDialog a;

        class a implements InputFilter {
            a() {
            }

            @Override // android.text.InputFilter
            public CharSequence filter(CharSequence charSequence, int i2, int i3, Spanned spanned, int i4, int i5) {
                while (i2 < i3) {
                    if (!Character.isLetterOrDigit(charSequence.charAt(i2)) && !Character.isSpaceChar(charSequence.charAt(i2)) && !"(".equals(charSequence) && !")".equals(charSequence) && !".".equals(charSequence) && !",".equals(charSequence)) {
                        Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.wrong_symbol), 0).show();
                        return "";
                    }
                    i2++;
                }
                return null;
            }
        }

        class b implements DialogInterface.OnClickListener {
            final /* synthetic */ EditText a;

            b(EditText editText) {
                this.a = editText;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                if (this.a.getText().toString().length() > 0) {
                    MyApplication.b().m0 = this.a.getText().toString();
                }
                SQLiteDatabase writableDatabase = mbCanvas.this.f9203h.getWritableDatabase();
                if (writableDatabase.query("TableNameProject", null, "name = ?", new String[]{MyApplication.b().m0}, null, null, null).moveToFirst()) {
                    Toast.makeText(mbCanvas.this.getApplicationContext(), MyApplication.b().m0 + " " + mbCanvas.this.getResources().getString(R.string.already_in_use), 0).show();
                    return;
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put(IMAPStore.ID_NAME, MyApplication.b().m0);
                contentValues.put("countScreen", (Integer) 16);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
                Date date = new Date();
                contentValues.put("createdTime", simpleDateFormat.format(date));
                contentValues.put("createdDate", new SimpleDateFormat("yyyy-MM-dd").format(date));
                int iInsert = (int) writableDatabase.insert("TableNameProject", null, contentValues);
                writableDatabase.execSQL("create table pro_" + iInsert + "_component (_id integer primary key autoincrement,componentId int,text text default 'default',width int default 100,height int default 100,x int default 300,y int default 300,textSize int default 32,connectionInfo text default '',colorText int default -65536,colorBackground int default -65536,other text default '');");
                writableDatabase.execSQL("create table pro_" + iInsert + "_connections(_id integer primary key autoincrement,connectionsId int,name text,server text);");
                MyApplication.b().j0 = "pro_" + iInsert + "_connections";
                MyApplication.b().k0 = "pro_" + iInsert + "_component";
                MyApplication.b().l0 = iInsert + "";
                mbCanvas.this.h(true);
                mbCanvas mbcanvas = mbCanvas.this;
                mbcanvas.D = false;
                mbcanvas.finish();
            }
        }

        class c implements DialogInterface.OnClickListener {
            c(j jVar) {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.cancel();
            }
        }

        j(AlertDialog alertDialog) {
            this.a = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.exit_no_save /* 2131296652 */:
                    mbCanvas.this.D = false;
                    MyApplication.b().g0.edit().putBoolean("autoStart", false).apply();
                    MyApplication.b().a();
                    mbCanvas.this.finish();
                    break;
                case R.id.exit_save_as /* 2131296653 */:
                    AlertDialog.Builder builder = new AlertDialog.Builder(mbCanvas.this);
                    builder.setTitle(mbCanvas.this.getResources().getString(R.string.new_project_name));
                    a aVar = new a();
                    EditText editText = new EditText(mbCanvas.this);
                    editText.setInputType(1);
                    editText.setHint(mbCanvas.this.getResources().getString(R.string.new_project_name));
                    editText.setFilters(new InputFilter[]{aVar});
                    builder.setView(editText);
                    builder.setPositiveButton(mbCanvas.this.getResources().getString(R.string.create), new b(editText));
                    builder.setNegativeButton(mbCanvas.this.getResources().getString(R.string.dialog_cancel), new c(this));
                    builder.show();
                    break;
                case R.id.exit_yes /* 2131296654 */:
                    MyApplication.b().g0.edit().putBoolean("autoStart", false).apply();
                    mbCanvas.this.h(true);
                    mbCanvas.this.D = false;
                    break;
                default:
                    return;
            }
            this.a.dismiss();
        }
    }

    class j0 implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;

        j0(mbCanvas mbcanvas, EditText editText) {
            this.a = editText;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            MyApplication.b().C.get(mbCanvas.a1 - 1).m(this.a.getText().toString());
        }
    }

    class k implements View.OnTouchListener {
        k() {
        }

        /* JADX WARN: Code duplicated, block: B:24:0x00b7  */
        /* JADX WARN: Code duplicated, block: B:26:0x00bd  */
        /* JADX WARN: Code duplicated, block: B:29:0x00db  */
        /* JADX WARN: Code duplicated, block: B:41:0x0126  */
        /* JADX WARN: Code duplicated, block: B:59:0x01cf  */
        /* JADX WARN: Code duplicated, block: B:64:0x021b  */
        /* JADX WARN: Code duplicated, block: B:66:0x022f  */
        /* JADX WARN: Code duplicated, block: B:69:0x0247  */
        /* JADX WARN: Code duplicated, block: B:70:0x0254  */
        /* JADX WARN: Code duplicated, block: B:72:0x025a  */
        /* JADX WARN: Code duplicated, block: B:88:0x0242 A[SYNTHETIC] */
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            mbCanvas mbcanvas;
            float customX;
            float customY;
            int i2;
            boolean z;
            mbCanvas mbcanvas2;
            ru.himik.nightscream.kascada.CustomComponents.z zVar;
            ru.himik.nightscream.kascada.CustomComponents.z zVar2;
            int action = motionEvent.getAction();
            if (action != 0) {
                if (action == 1) {
                    mbcanvas = mbCanvas.this;
                    if (mbcanvas.A0) {
                        mbcanvas.A0 = false;
                        customX = MyApplication.b().f9040h;
                        customY = MyApplication.b().f9041i;
                        float customX2 = 0.0f;
                        float customY2 = 0.0f;
                        for (i2 = 0; i2 < mbCanvas.this.V.size(); i2++) {
                            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = mbCanvas.this.V;
                            zVar2 = sparseArray.get(sparseArray.keyAt(i2));
                            if ((zVar2.getIdComponent() == 133 || !((VarNameIn) zVar2).t()) && (zVar2.getIdComponent() != 134 || !((VarNameOut) zVar2).t())) {
                                if ((zVar2.getCustomWidth() / 2) + zVar2.getCustomX() >= mbCanvas.this.U.getX() || (zVar2.getCustomWidth() / 2) + zVar2.getCustomX() > mbCanvas.this.U.getLayoutParams().width + mbCanvas.this.U.getX() || (zVar2.getCustomHeight() / 2) + zVar2.getCustomY() < mbCanvas.this.U.getY() || (zVar2.getCustomHeight() / 2) + zVar2.getCustomY() > mbCanvas.this.U.getLayoutParams().height + mbCanvas.this.U.getY()) {
                                    zVar2.setCustomSelect(false);
                                    zVar2.setDiffX(0);
                                    zVar2.setDiffY(0);
                                } else {
                                    zVar2.setCustomSelect(true);
                                    if (zVar2.getCustomX() < customX) {
                                        customX = zVar2.getCustomX();
                                    }
                                    if (zVar2.getCustomY() < customY) {
                                        customY = zVar2.getCustomY();
                                    }
                                    if (zVar2.getCustomX() + zVar2.getCustomWidth() > customX2) {
                                        customX2 = zVar2.getCustomX() + zVar2.getCustomWidth();
                                    }
                                    if (zVar2.getCustomY() + zVar2.getCustomHeight() > customY2) {
                                        customY2 = zVar2.getCustomY() + zVar2.getCustomHeight();
                                    }
                                }
                            }
                        }
                        mbCanvas.this.U.setX(customX);
                        mbCanvas.this.U.setY(customY);
                        mbCanvas.this.U.getLayoutParams().width = (int) (customX2 - customX);
                        mbCanvas.this.U.getLayoutParams().height = (int) (customY2 - customY);
                        mbCanvas.this.U.bringToFront();
                        mbCanvas.this.U.requestLayout();
                        z = false;
                        for (int i3 = 0; i3 < mbCanvas.this.V.size(); i3++) {
                            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = mbCanvas.this.V;
                            zVar = sparseArray2.get(sparseArray2.keyAt(i3));
                            if (zVar.p()) {
                                zVar.setDiffX((int) (zVar.getCustomX() - customX));
                                zVar.setDiffY((int) (zVar.getCustomY() - customY));
                                z = true;
                            }
                        }
                        if (z) {
                            mbCanvas.this.W.animate().translationY(0.0f);
                        } else {
                            mbcanvas2 = mbCanvas.this;
                            if (!mbcanvas2.Y) {
                                mbcanvas2.W.animate().translationY(mbCanvas.this.W.getHeight());
                            }
                        }
                    }
                } else if (action == 2) {
                    mbCanvas mbcanvas3 = mbCanvas.this;
                    if (mbcanvas3.A0) {
                        if (mbcanvas3.U.getVisibility() == 4) {
                            mbCanvas.this.U.setVisibility(0);
                        }
                        float x = motionEvent.getX();
                        mbCanvas mbcanvas4 = mbCanvas.this;
                        if (x > mbcanvas4.B0) {
                            ViewGroup.LayoutParams layoutParams = mbcanvas4.U.getLayoutParams();
                            int x2 = (int) motionEvent.getX();
                            mbCanvas mbcanvas5 = mbCanvas.this;
                            float f2 = mbcanvas5.B0;
                            layoutParams.width = x2 - ((int) f2);
                            mbcanvas5.U.setX(f2);
                        } else {
                            mbcanvas4.U.setX(motionEvent.getX());
                            mbCanvas.this.U.getLayoutParams().width = ((int) mbCanvas.this.B0) - ((int) motionEvent.getX());
                        }
                        float y = motionEvent.getY();
                        mbCanvas mbcanvas6 = mbCanvas.this;
                        if (y > mbcanvas6.C0) {
                            ViewGroup.LayoutParams layoutParams2 = mbcanvas6.U.getLayoutParams();
                            int y2 = (int) motionEvent.getY();
                            mbCanvas mbcanvas7 = mbCanvas.this;
                            float f3 = mbcanvas7.C0;
                            layoutParams2.height = y2 - ((int) f3);
                            mbcanvas7.U.setY(f3);
                        } else {
                            mbcanvas6.U.setY(motionEvent.getY());
                            mbCanvas.this.U.getLayoutParams().height = ((int) mbCanvas.this.C0) - ((int) motionEvent.getY());
                        }
                        mbCanvas.this.U.requestLayout();
                    }
                } else if (action == 3) {
                    mbcanvas = mbCanvas.this;
                    if (mbcanvas.A0) {
                        mbcanvas.A0 = false;
                        customX = MyApplication.b().f9040h;
                        customY = MyApplication.b().f9041i;
                        float customX3 = 0.0f;
                        float customY3 = 0.0f;
                        while (i2 < mbCanvas.this.V.size()) {
                            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray3 = mbCanvas.this.V;
                            zVar2 = sparseArray3.get(sparseArray3.keyAt(i2));
                            if (zVar2.getIdComponent() == 133) {
                                if ((zVar2.getCustomWidth() / 2) + zVar2.getCustomX() >= mbCanvas.this.U.getX()) {
                                    zVar2.setCustomSelect(false);
                                    zVar2.setDiffX(0);
                                    zVar2.setDiffY(0);
                                } else {
                                    zVar2.setCustomSelect(false);
                                    zVar2.setDiffX(0);
                                    zVar2.setDiffY(0);
                                }
                            } else if ((zVar2.getCustomWidth() / 2) + zVar2.getCustomX() >= mbCanvas.this.U.getX()) {
                                zVar2.setCustomSelect(false);
                                zVar2.setDiffX(0);
                                zVar2.setDiffY(0);
                            } else {
                                zVar2.setCustomSelect(false);
                                zVar2.setDiffX(0);
                                zVar2.setDiffY(0);
                            }
                        }
                        mbCanvas.this.U.setX(customX);
                        mbCanvas.this.U.setY(customY);
                        mbCanvas.this.U.getLayoutParams().width = (int) (customX3 - customX);
                        mbCanvas.this.U.getLayoutParams().height = (int) (customY3 - customY);
                        mbCanvas.this.U.bringToFront();
                        mbCanvas.this.U.requestLayout();
                        z = false;
                        while (i3 < mbCanvas.this.V.size()) {
                            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray4 = mbCanvas.this.V;
                            zVar = sparseArray4.get(sparseArray4.keyAt(i3));
                            if (zVar.p()) {
                                zVar.setDiffX((int) (zVar.getCustomX() - customX));
                                zVar.setDiffY((int) (zVar.getCustomY() - customY));
                                z = true;
                            }
                        }
                        if (z) {
                            mbCanvas.this.W.animate().translationY(0.0f);
                        } else {
                            mbcanvas2 = mbCanvas.this;
                            if (!mbcanvas2.Y) {
                                mbcanvas2.W.animate().translationY(mbCanvas.this.W.getHeight());
                            }
                        }
                    }
                }
            } else if (view.getId() == R.id.mainWorkLayout) {
                mbCanvas.this.q(false);
                mbCanvas mbcanvas8 = mbCanvas.this;
                if (!mbcanvas8.f9206k) {
                    mbcanvas8.A0 = true;
                    mbcanvas8.U.setVisibility(4);
                    mbCanvas.this.U.setX(motionEvent.getX());
                    mbCanvas.this.U.setY(motionEvent.getY());
                    mbCanvas.this.U.getLayoutParams().width = 1;
                    mbCanvas.this.U.getLayoutParams().height = 1;
                    mbCanvas.this.U.bringToFront();
                    mbCanvas.this.B0 = motionEvent.getX();
                    mbCanvas.this.C0 = motionEvent.getY();
                }
            } else {
                view.startDrag(null, new View.DragShadowBuilder(view), view, 0);
                view.setVisibility(4);
            }
            return true;
        }
    }

    class k0 implements DialogInterface.OnClickListener {
        k0(mbCanvas mbcanvas) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class l implements TextWatcher {
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.i a;
        final /* synthetic */ EditText b;

        l(mbCanvas mbcanvas, ru.himik.nightscream.kascada.CustomComponents.i iVar, EditText editText) {
            this.a = iVar;
            this.b = editText;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            String str = ".";
            if (!charSequence.toString().contains(".") || charSequence.charAt(charSequence.length() - 1) == '.') {
                str = ",";
                if (!charSequence.toString().contains(",") || charSequence.charAt(charSequence.length() - 1) == ',' || charSequence.toString().length() - (charSequence.toString().indexOf(",") + 1) <= this.a.getCountNumAfterPointEditNumber()) {
                    return;
                }
            } else if (charSequence.toString().length() - (charSequence.toString().indexOf(".") + 1) <= this.a.getCountNumAfterPointEditNumber()) {
                return;
            }
            this.b.setText(charSequence.toString().substring(0, charSequence.toString().indexOf(str) + 1 + this.a.getCountNumAfterPointEditNumber()));
            EditText editText = this.b;
            editText.setSelection(editText.length());
        }
    }

    class l0 implements DialogInterface.OnClickListener {
        final /* synthetic */ int a;
        final /* synthetic */ EditText b;

        l0(int i2, EditText editText) {
            this.a = i2;
            this.b = editText;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            if (!MyApplication.b().C.get(this.a - 1).e().equals(this.b.getText().toString())) {
                Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.access_error), 1).show();
                return;
            }
            mbCanvas.a1 = this.a;
            mbCanvas.this.y0();
            mbCanvas.this.z0();
        }
    }

    class m implements DialogInterface.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.i a;
        final /* synthetic */ EditText b;
        final /* synthetic */ EditText c;

        m(ru.himik.nightscream.kascada.CustomComponents.i iVar, EditText editText, EditText editText2) {
            this.a = iVar;
            this.b = editText;
            this.c = editText2;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            mbCanvas.this.t(this.a, this.b.getText().toString(), this.c.getText().toString());
        }
    }

    class m0 implements DialogInterface.OnClickListener {
        m0(mbCanvas mbcanvas) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class n implements DialogInterface.OnClickListener {
        n(mbCanvas mbcanvas) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class n0 extends CountDownTimer {
        final /* synthetic */ String a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        n0(long j2, long j3, String str) {
            super(j2, j3);
            this.a = str;
        }

        @Override // android.os.CountDownTimer
        public void onFinish() {
            mbCanvas.this.D = false;
            MyApplication.b().f9045m = this.a;
            MyApplication.b().g0.edit().putBoolean("autoStart", false).apply();
            MyApplication.b().a();
            mbCanvas.this.finish();
        }

        @Override // android.os.CountDownTimer
        public void onTick(long j2) {
        }
    }

    class o implements TextView.OnEditorActionListener {
        final /* synthetic */ ru.himik.nightscream.kascada.CustomComponents.i a;
        final /* synthetic */ EditText b;
        final /* synthetic */ EditText c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9223d;

        o(ru.himik.nightscream.kascada.CustomComponents.i iVar, EditText editText, EditText editText2, AlertDialog alertDialog) {
            this.a = iVar;
            this.b = editText;
            this.c = editText2;
            this.f9223d = alertDialog;
        }

        @Override // android.widget.TextView.OnEditorActionListener
        public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
            if (i2 != 6) {
                return true;
            }
            mbCanvas.this.t(this.a, this.b.getText().toString(), this.c.getText().toString());
            this.f9223d.dismiss();
            return true;
        }
    }

    class o0 implements androidx.appcompat.widget.l0.d {
        o0() {
        }

        @Override // androidx.appcompat.widget.l0.d
        public boolean onMenuItemClick(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == R.id.popup_open_pdf) {
                FragmentManager fragmentManager = mbCanvas.this.getFragmentManager();
                mbCanvas.this.Q.a(MyApplication.b().f9040h, MyApplication.b().f9041i);
                mbCanvas.this.Q.b(Uri.parse(MyApplication.b().f9043k));
                mbCanvas.this.Q.show(fragmentManager, "");
            } else if (itemId == R.id.popup_set_pdf_path_file) {
                Intent intent = new Intent("android.intent.action.GET_CONTENT");
                intent.setType("application/pdf");
                intent.addCategory("android.intent.category.OPENABLE");
                try {
                    mbCanvas mbcanvas = mbCanvas.this;
                    mbcanvas.startActivityForResult(Intent.createChooser(intent, mbcanvas.getResources().getString(R.string.choose_pdf_file)), 8);
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.error_get_pdf_file), 1).show();
                }
            }
            return true;
        }
    }

    class p implements View.OnClickListener {
        final /* synthetic */ RelativeLayout C;
        final /* synthetic */ RelativeLayout D;
        final /* synthetic */ TextView E;
        final /* synthetic */ CustomList a;
        final /* synthetic */ RelativeLayout b;
        final /* synthetic */ RelativeLayout c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9225d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9226e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9227f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9228g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9229h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9230i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9231j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9232k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9233l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9234m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        final /* synthetic */ RelativeLayout f9235n;
        final /* synthetic */ RelativeLayout o;

        p(CustomList customList, RelativeLayout relativeLayout, RelativeLayout relativeLayout2, RelativeLayout relativeLayout3, RelativeLayout relativeLayout4, RelativeLayout relativeLayout5, RelativeLayout relativeLayout6, RelativeLayout relativeLayout7, RelativeLayout relativeLayout8, RelativeLayout relativeLayout9, RelativeLayout relativeLayout10, RelativeLayout relativeLayout11, RelativeLayout relativeLayout12, RelativeLayout relativeLayout13, RelativeLayout relativeLayout14, RelativeLayout relativeLayout15, RelativeLayout relativeLayout16, TextView textView) {
            this.a = customList;
            this.b = relativeLayout;
            this.c = relativeLayout2;
            this.f9225d = relativeLayout3;
            this.f9226e = relativeLayout4;
            this.f9227f = relativeLayout5;
            this.f9228g = relativeLayout6;
            this.f9229h = relativeLayout7;
            this.f9230i = relativeLayout8;
            this.f9231j = relativeLayout9;
            this.f9232k = relativeLayout10;
            this.f9233l = relativeLayout11;
            this.f9234m = relativeLayout12;
            this.f9235n = relativeLayout13;
            this.o = relativeLayout14;
            this.C = relativeLayout15;
            this.D = relativeLayout16;
            this.E = textView;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            RelativeLayout relativeLayout;
            int color;
            switch (view.getId()) {
                case R.id.bit0 /* 2131296421 */:
                    if (this.a.h(0).length() != 0) {
                        if (!this.a.l(0)) {
                            relativeLayout = this.b;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.b;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit1 /* 2131296422 */:
                    if (this.a.h(1).length() != 0) {
                        if (!this.a.l(1)) {
                            relativeLayout = this.c;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.c;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit10 /* 2131296423 */:
                    if (this.a.h(10).length() != 0) {
                        if (!this.a.l(10)) {
                            relativeLayout = this.f9233l;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9233l;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit11 /* 2131296424 */:
                    if (this.a.h(11).length() != 0) {
                        if (!this.a.l(11)) {
                            relativeLayout = this.f9234m;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9234m;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit12 /* 2131296425 */:
                    if (this.a.h(12).length() != 0) {
                        if (!this.a.l(12)) {
                            relativeLayout = this.f9235n;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9235n;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit13 /* 2131296426 */:
                    if (this.a.h(13).length() != 0) {
                        if (!this.a.l(13)) {
                            relativeLayout = this.o;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.o;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit14 /* 2131296427 */:
                    if (this.a.h(14).length() != 0) {
                        if (!this.a.l(14)) {
                            relativeLayout = this.C;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.C;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit15 /* 2131296428 */:
                    if (this.a.h(15).length() != 0) {
                        if (!this.a.l(15)) {
                            relativeLayout = this.D;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.D;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit2 /* 2131296429 */:
                    if (this.a.h(2).length() != 0) {
                        if (!this.a.l(2)) {
                            relativeLayout = this.f9225d;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9225d;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit3 /* 2131296430 */:
                    if (this.a.h(3).length() != 0) {
                        if (!this.a.l(3)) {
                            relativeLayout = this.f9226e;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9226e;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit4 /* 2131296431 */:
                    if (this.a.h(4).length() != 0) {
                        if (!this.a.l(4)) {
                            relativeLayout = this.f9227f;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9227f;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit5 /* 2131296432 */:
                    if (this.a.h(5).length() != 0) {
                        if (!this.a.l(5)) {
                            relativeLayout = this.f9228g;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9228g;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit6 /* 2131296433 */:
                    if (this.a.h(6).length() != 0) {
                        if (!this.a.l(6)) {
                            relativeLayout = this.f9229h;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9229h;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit7 /* 2131296434 */:
                    if (this.a.h(7).length() != 0) {
                        if (!this.a.l(7)) {
                            relativeLayout = this.f9230i;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9230i;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit8 /* 2131296435 */:
                    if (this.a.h(8).length() != 0) {
                        if (!this.a.l(8)) {
                            relativeLayout = this.f9231j;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9231j;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
                case R.id.bit9 /* 2131296436 */:
                    if (this.a.h(9).length() != 0) {
                        if (!this.a.l(9)) {
                            relativeLayout = this.f9232k;
                            color = mbCanvas.this.getResources().getColor(R.color.select_line);
                            relativeLayout.setBackgroundColor(color);
                        } else {
                            relativeLayout = this.f9232k;
                            color = Color.parseColor("#005005");
                            relativeLayout.setBackgroundColor(color);
                        }
                    }
                    break;
            }
            if (this.a.f8687i.l() == 100) {
                CustomList customList = this.a;
                customList.f8687i.H(customList.getValue());
                MyApplication.b().v0.e(this.a.f8687i);
            } else if (this.a.f8687i.k() != -1) {
                CustomList customList2 = this.a;
                customList2.f8687i.H(customList2.getValue());
                mbCanvas.Y0.get(this.a.f8687i.k()).e(this.a.f8687i);
            } else {
                Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getApplicationContext().getResources().getString(R.string.toast_no_connection), 1).show();
            }
            this.E.setText(this.a.getValue() + "");
        }
    }

    class p0 implements View.OnClickListener {
        p0() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            mbCanvas mbcanvas = mbCanvas.this;
            if (mbcanvas.f9206k) {
                return;
            }
            ru.himik.nightscream.kascada.Logic.c.a aVar = (ru.himik.nightscream.kascada.Logic.c.a) view;
            if (!mbcanvas.S0) {
                mbcanvas.s0(aVar);
                return;
            }
            mbcanvas.S0 = false;
            int freeIn = aVar.getFreeIn();
            if (freeIn > 0) {
                if (mbCanvas.this.T0.getTypeVarOut() != aVar.o(freeIn)) {
                    Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.wrong_type_logic), 1).show();
                    return;
                }
                mbCanvas.this.T0.c();
                mbCanvas.this.T0.e(aVar);
                mbCanvas.this.T0.setNumOnIn(freeIn);
                aVar.d(mbCanvas.this.T0, freeIn);
                mbCanvas.f1.invalidate();
            }
        }
    }

    class q implements View.OnTouchListener {
        q() {
        }

        /* JADX WARN: Code duplicated, block: B:13:0x002a  */
        /* JADX WARN: Code duplicated, block: B:16:0x003f  */
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            ru.himik.nightscream.kascada.CustomComponents.b bVar;
            ru.himik.nightscream.kascada.CustomComponents.b bVar2;
            ru.himik.nightscream.kascada.CustomComponents.e eVar = (ru.himik.nightscream.kascada.CustomComponents.e) view;
            int action = motionEvent.getAction();
            if (action == 0) {
                view.playSoundEffect(0);
                int mode = eVar.getMode();
                if (mode == 0) {
                    eVar.f8769i.J(true);
                    if (eVar.f8769i.l() == 100) {
                        MyApplication.b().v0.e(eVar.f8769i);
                    } else if (eVar.f8769i.k() != -1) {
                        mbCanvas.Y0.get(eVar.f8769i.k()).e(eVar.f8769i);
                    }
                } else if (mode == 1) {
                    mbCanvas.this.n0(eVar.getChangeScreen());
                } else if (mode == 2) {
                    int typeRegister = eVar.getTypeRegister();
                    if (typeRegister != 0) {
                        if (typeRegister == 1) {
                            if (eVar.f8769i.l() == 100) {
                                bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b();
                                bVar2.C(eVar.getKey());
                                bVar2.L((byte) 16);
                                bVar2.K(1);
                                bVar2.v(eVar.getConstantRegister());
                                bVar2.I(Float.parseFloat(eVar.getConstant()));
                                bVar2.A(6);
                                MyApplication.b().v0.e(bVar2);
                            } else if (eVar.f8769i.k() != -1) {
                                bVar = new ru.himik.nightscream.kascada.CustomComponents.b();
                                bVar.C(eVar.getKey());
                                bVar.L((byte) 16);
                                bVar.K(1);
                                bVar.v(eVar.getConstantRegister());
                                bVar.I(Float.parseFloat(eVar.getConstant()));
                                bVar.A(6);
                                bVar.B(MyApplication.b().E.get(eVar.f8769i.l()).b());
                                bVar.F(MyApplication.b().E.get(eVar.f8769i.l()).g());
                                bVar.u((byte) MyApplication.b().E.get(eVar.f8769i.l()).a());
                                mbCanvas.Y0.get(eVar.f8769i.k()).e(bVar);
                            }
                        }
                    } else if (eVar.f8769i.l() == 100) {
                        bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b();
                        bVar2.C(eVar.getKey());
                        bVar2.L((byte) 6);
                        bVar2.A(6);
                        bVar2.H(Integer.parseInt(eVar.getConstant()));
                        bVar2.v(eVar.getConstantRegister());
                        MyApplication.b().v0.e(bVar2);
                    } else if (eVar.f8769i.k() != -1) {
                        bVar = new ru.himik.nightscream.kascada.CustomComponents.b();
                        bVar.C(eVar.getKey());
                        bVar.L((byte) 6);
                        bVar.v(eVar.getConstantRegister());
                        bVar.H(Integer.parseInt(eVar.getConstant()));
                        bVar.A(6);
                        bVar.B(MyApplication.b().E.get(eVar.f8769i.l()).b());
                        bVar.F(MyApplication.b().E.get(eVar.f8769i.l()).g());
                        bVar.u((byte) MyApplication.b().E.get(eVar.f8769i.l()).a());
                        mbCanvas.Y0.get(eVar.f8769i.k()).e(bVar);
                    }
                }
                Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getApplicationContext().getResources().getString(R.string.toast_no_connection), 0).show();
            } else if ((action == 1 || action == 3) && eVar.getMode() == 0) {
                eVar.f8769i.J(false);
                if (eVar.f8769i.l() == 100) {
                    MyApplication.b().v0.e(eVar.f8769i);
                } else if (eVar.f8769i.k() != -1) {
                    mbCanvas.Y0.get(eVar.f8769i.k()).e(eVar.f8769i);
                }
            }
            return true;
        }
    }

    class q0 implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;

        q0(EditText editText) {
            this.a = editText;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            String string = this.a.getText().toString();
            if (string.length() < 5 || string.length() > 15) {
                return;
            }
            ru.himik.nightscream.kascada.Utils.l lVar = ru.himik.nightscream.kascada.Utils.l.a;
            if (lVar.p(string)) {
                g.a.a.e.f(mbCanvas.this, R.string.thank_you_for_your_purchase, 1).show();
                lVar.n(string.toUpperCase());
                return;
            }
            mbCanvas mbcanvas = mbCanvas.this;
            mbcanvas.V0 = Integer.valueOf(mbcanvas.V0.intValue() + 1);
            if (mbCanvas.this.V0.intValue() > 5) {
                YandexMetrica.reportEvent("Ошибка ввода кода лицензии БОЛЕЕ 5 раз", "code: " + string);
                mbCanvas.this.finish();
            }
            YandexMetrica.reportEvent("Ошибка ввода кода лицензии", "code: " + string);
            g.a.a.e.b(mbCanvas.this, "Что-то пошло не так", 1).show();
        }
    }

    class r implements SeekBar.OnSeekBarChangeListener {
        r() {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int i2, boolean z) {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
            ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) seekBar;
            if (mbCanvas.this.f9206k) {
                if (vVar.f8909f.l() == 100) {
                    vVar.f8909f.H(vVar.getProgress());
                    MyApplication.b().v0.e(vVar.f8909f);
                    return;
                }
                if (vVar.f8909f.k() == -1) {
                    Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getApplicationContext().getResources().getString(R.string.toast_no_connection), 1).show();
                    return;
                }
                if (MyApplication.b().f9036d.get(mbCanvas.Y0.get(vVar.f8909f.k()).a()).k()) {
                    vVar.f8909f.H(vVar.getProgress());
                    ru.himik.nightscream.kascada.CustomComponents.b bVar = vVar.f8909f;
                    bVar.x(mbCanvas.this.o.c(bVar, bVar.i()));
                    mbCanvas.Y0.get(vVar.f8909f.k()).e(vVar.f8909f);
                    ru.himik.nightscream.kascada.CustomComponents.b bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b(vVar.getIdComponent(), (byte) MyApplication.b().E.get(vVar.f8909f.l()).a(), vVar.f8909f.c(), (byte) 0, (byte) 3, vVar.getKey());
                    bVar2.F(vVar.f8909f.r());
                    bVar2.x(mbCanvas.this.o.c(bVar2, vVar.f8909f.i()));
                    mbCanvas.Y0.get(vVar.f8909f.k()).c(bVar2);
                }
            }
        }
    }

    class r0 implements View.OnClickListener {
        r0() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            mbCanvas.this.x0(false);
        }
    }

    class s implements View.OnTouchListener {
        s() {
        }

        /* JADX WARN: Code duplicated, block: B:27:0x0071  */
        /* JADX WARN: Code duplicated, block: B:34:0x013a  */
        /* JADX WARN: Code duplicated, block: B:37:0x015f  */
        /* JADX WARN: Code duplicated, block: B:54:0x0261  */
        /* JADX WARN: Code duplicated, block: B:56:0x0269  */
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            ru.himik.nightscream.kascada.CustomComponents.b bVar;
            ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) view;
            if (!mbCanvas.this.f9206k) {
                int action = motionEvent.getAction();
                if (action == 0) {
                    view.playSoundEffect(0);
                    vVar.h(view);
                } else if (action == 1) {
                    vVar.j(view);
                    if (!vVar.H) {
                        mbCanvas.this.onClickView(view);
                    }
                } else if (action == 2) {
                    mbCanvas.this.setProgress(vVar.getMax() - ((int) ((vVar.getMax() * motionEvent.getY()) / vVar.getHeight())));
                } else if (action == 3) {
                    vVar.j(view);
                }
                return true;
            }
            if (vVar.f8909f.l() == 100 && !vVar.g()) {
                return false;
            }
            if (vVar.f8909f.k() != -1 && MyApplication.b().f9036d.get(mbCanvas.Y0.get(vVar.f8909f.k()).a()).k() && !vVar.g()) {
                return false;
            }
            int action2 = motionEvent.getAction();
            if (action2 == 0) {
                if (vVar.f8909f.l() != 100 || (vVar.f8909f.k() != -1 && MyApplication.b().f9036d.get(mbCanvas.Y0.get(vVar.f8909f.k()).a()).k())) {
                    vVar.setProgressCalc(motionEvent.getY());
                }
            } else if (action2 == 1) {
                if (vVar.f8909f.l() == 100) {
                    vVar.setProgressCalc(motionEvent.getY());
                } else if (vVar.f8909f.k() == -1) {
                    Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getApplicationContext().getResources().getString(R.string.toast_no_connection), 1).show();
                } else if (MyApplication.b().f9036d.get(mbCanvas.Y0.get(vVar.f8909f.k()).a()).k()) {
                    vVar.setProgressCalc(motionEvent.getY());
                }
                if (mbCanvas.this.f9206k) {
                    if (vVar.f8909f.l() == 100) {
                        vVar.f8909f.H(vVar.getProgress());
                        MyApplication.b().v0.e(vVar.f8909f);
                    } else if (vVar.f8909f.k() == -1) {
                        Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getApplicationContext().getResources().getString(R.string.toast_no_connection), 1).show();
                    } else if (MyApplication.b().f9036d.get(mbCanvas.Y0.get(vVar.f8909f.k()).a()).k()) {
                        vVar.f8909f.H(vVar.getProgress());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar2 = vVar.f8909f;
                        bVar2.x(mbCanvas.this.o.c(bVar2, bVar2.i()));
                        mbCanvas.Y0.get(vVar.f8909f.k()).e(vVar.f8909f);
                        bVar = new ru.himik.nightscream.kascada.CustomComponents.b(vVar.getIdComponent(), (byte) MyApplication.b().E.get(vVar.f8909f.l()).a(), vVar.f8909f.c(), (byte) 0, (byte) 3, vVar.getKey());
                        bVar.F(vVar.f8909f.r());
                        bVar.x(mbCanvas.this.o.c(bVar, vVar.f8909f.i()));
                        mbCanvas.Y0.get(vVar.f8909f.k()).c(bVar);
                    }
                }
            } else if (action2 != 2) {
                if (action2 == 3 && mbCanvas.this.f9206k) {
                    if (vVar.f8909f.l() == 100) {
                        vVar.f8909f.H(vVar.getProgress());
                        MyApplication.b().v0.e(vVar.f8909f);
                    } else if (vVar.f8909f.k() == -1) {
                        Toast.makeText(mbCanvas.this.getApplicationContext(), mbCanvas.this.getApplicationContext().getResources().getString(R.string.toast_no_connection), 1).show();
                    } else if (MyApplication.b().f9036d.get(mbCanvas.Y0.get(vVar.f8909f.k()).a()).k()) {
                        vVar.f8909f.H(vVar.getProgress());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar3 = vVar.f8909f;
                        bVar3.x(mbCanvas.this.o.c(bVar3, bVar3.i()));
                        mbCanvas.Y0.get(vVar.f8909f.k()).e(vVar.f8909f);
                        bVar = new ru.himik.nightscream.kascada.CustomComponents.b(vVar.getIdComponent(), (byte) MyApplication.b().E.get(vVar.f8909f.l()).a(), vVar.f8909f.c(), (byte) 0, (byte) 3, vVar.getKey());
                        bVar.F(vVar.f8909f.r());
                        bVar.x(mbCanvas.this.o.c(bVar, vVar.f8909f.i()));
                        mbCanvas.Y0.get(vVar.f8909f.k()).c(bVar);
                    }
                }
            } else if (vVar.f8909f.l() != 100) {
                vVar.setProgressCalc(motionEvent.getY());
            } else {
                vVar.setProgressCalc(motionEvent.getY());
            }
            return true;
        }
    }

    class s0 implements View.OnClickListener {
        s0() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.menu_app_bar_hide /* 2131296823 */:
                    mbCanvas.this.f9207l.setVisibility(4);
                    mbCanvas.this.a0.setVisibility(0);
                    break;
                case R.id.menu_app_bar_show /* 2131296824 */:
                    if (mbCanvas.a1 != -1) {
                        mbCanvas.this.a0.setVisibility(4);
                        if (mbCanvas.this.f9207l.getVisibility() != 0) {
                            mbCanvas.this.f9207l.setVisibility(0);
                        } else {
                            mbCanvas.this.f9207l.setVisibility(4);
                        }
                    } else {
                        mbCanvas mbcanvas = mbCanvas.this;
                        mbcanvas.Z = 0;
                        mbCanvas.a1 = mbcanvas.W0.getNumScreen();
                        mbCanvas mbcanvas2 = mbCanvas.this;
                        mbcanvas2.p(mbcanvas2.W0);
                        mbCanvas.this.y0();
                    }
                    break;
            }
        }
    }

    class t implements ru.himik.nightscream.kascada.CustomComponents.v.c {
        t() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // ru.himik.nightscream.kascada.CustomComponents.v.c
        public boolean onLongClick(View view) {
            if (mbCanvas.this.f9206k) {
                return true;
            }
            if (view instanceof ru.himik.nightscream.kascada.CustomComponents.z) {
                ((ru.himik.nightscream.kascada.CustomComponents.z) view).setTimeZ(System.currentTimeMillis() + 1471228928);
            }
            mbCanvas.this.q(false);
            mbCanvas.this.f9201f.setVisibility(0);
            view.setVisibility(4);
            ru.himik.nightscream.kascada.s.c cVar = new ru.himik.nightscream.kascada.s.c(view);
            cVar.a(((ru.himik.nightscream.kascada.s.a) view).getPointTouch());
            view.startDrag(null, cVar, view, 0);
            view.bringToFront();
            mbCanvas mbcanvas = mbCanvas.this;
            mbcanvas.f9204i = view;
            mbcanvas.D();
            return true;
        }
    }

    class t0 implements View.OnClickListener {
        t0() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            mbCanvas.this.onClickView(view);
        }
    }

    class u implements ru.himik.nightscream.kascada.CustomComponents.o.d {
        u() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // ru.himik.nightscream.kascada.CustomComponents.o.d
        public boolean onLongClick(View view) {
            if (mbCanvas.this.f9206k) {
                return true;
            }
            if (view instanceof ru.himik.nightscream.kascada.CustomComponents.z) {
                ((ru.himik.nightscream.kascada.CustomComponents.z) view).setTimeZ(System.currentTimeMillis() + 1471228928);
            }
            mbCanvas.this.q(false);
            mbCanvas.this.f9201f.setVisibility(0);
            view.setVisibility(4);
            ru.himik.nightscream.kascada.s.c cVar = new ru.himik.nightscream.kascada.s.c(view);
            cVar.a(((ru.himik.nightscream.kascada.s.a) view).getPointTouch());
            view.startDrag(null, cVar, view, 0);
            view.bringToFront();
            mbCanvas mbcanvas = mbCanvas.this;
            mbcanvas.f9204i = view;
            mbcanvas.D();
            return true;
        }
    }

    class u0 extends TimerTask {

        class a implements Runnable {
            final /* synthetic */ String a;

            a(String str) {
                this.a = str;
            }

            /* JADX WARN: Code duplicated, block: B:41:0x00c5  */
            @Override // java.lang.Runnable
            public void run() {
                int intExtra;
                mbCanvas mbcanvas = mbCanvas.this;
                boolean z = false;
                if (mbcanvas.T) {
                    mbcanvas.T = false;
                    if (!mbCanvas.Z0 || mbCanvas.c1 || !mbcanvas.f9206k) {
                        Toast.makeText(mbcanvas.getApplicationContext(), mbCanvas.this.getResources().getString(R.string.repeat_key), 1).show();
                    }
                }
                mbCanvas.this.O.setText(this.a);
                Intent intent = mbCanvas.this.H;
                if (intent != null && ((intExtra = intent.getIntExtra("status", -1)) == 2 || (intExtra != 3 && intExtra != 4 && intExtra == 5))) {
                    z = true;
                }
                if (MyApplication.b().v0 != null) {
                    MyApplication.b().v0.X(mbCanvas.c1);
                    mbCanvas mbcanvas2 = mbCanvas.this;
                    mbcanvas2.J = mbcanvas2.H.getIntExtra("level", -1);
                    MyApplication.b().v0.S(mbCanvas.this.J);
                }
                if (mbCanvas.c1 != z) {
                    mbCanvas.this.f9209n.setBackgroundResource(z ? R.drawable.battery_charging2_48 : R.drawable.battery_empty_48);
                    mbCanvas.c1 = z;
                    mbCanvas.this.onClickIcoCharging(null);
                }
                if (!mbCanvas.Z0 || mbCanvas.c1) {
                    mbCanvas.this.getWindow().addFlags(FtdiSerialDriver.FtdiSerialPort.USB_ENDPOINT_IN);
                } else {
                    mbCanvas mbcanvas3 = mbCanvas.this;
                    if (mbcanvas3.f9206k) {
                        mbcanvas3.getWindow().clearFlags(FtdiSerialDriver.FtdiSerialPort.USB_ENDPOINT_IN);
                    } else {
                        mbCanvas.this.getWindow().addFlags(FtdiSerialDriver.FtdiSerialPort.USB_ENDPOINT_IN);
                    }
                }
                boolean z2 = mbCanvas.c1;
                if (z2) {
                    mbCanvas.this.I = true;
                }
                if (!z2) {
                    mbCanvas mbcanvas4 = mbCanvas.this;
                    if (!mbcanvas4.i0 && mbcanvas4.I) {
                        mbcanvas4.i0 = true;
                    }
                }
                mbCanvas mbcanvas5 = mbCanvas.this;
                if (mbcanvas5.J <= 10 && !mbcanvas5.j0) {
                    mbcanvas5.j0 = true;
                }
                mbCanvas.d1.d();
            }
        }

        u0() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            String str = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(Calendar.getInstance().getTime());
            mbCanvas mbcanvas = mbCanvas.this;
            mbcanvas.H = mbcanvas.getApplicationContext().registerReceiver(null, mbCanvas.this.F);
            mbCanvas.this.C.post(new a(str));
        }
    }

    class v extends BroadcastReceiver {
        v(mbCanvas mbcanvas) {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            try {
                if (intent.hasExtra("webSocket")) {
                    MyApplication.b().x0.e();
                }
            } catch (Exception unused) {
            }
        }
    }

    class v0 implements DialogInterface.OnClickListener {
        final /* synthetic */ EditText a;

        v0(EditText editText) {
            this.a = editText;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            MyApplication.b().C.get(mbCanvas.a1 - 1).l(this.a.getText().toString());
            mbCanvas.this.y0();
        }
    }

    class w implements View.OnTouchListener {
        w() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (mbCanvas.this.f9206k) {
                ru.himik.nightscream.kascada.CustomComponents.o oVar = (ru.himik.nightscream.kascada.CustomComponents.o) view;
                oVar.setTimeLastTouch(System.currentTimeMillis());
                oVar.setLockZoom(true);
                return false;
            }
            int action = motionEvent.getAction();
            if (action == 0) {
                ((ru.himik.nightscream.kascada.CustomComponents.o) view).k(view);
            } else if (action == 1) {
                ru.himik.nightscream.kascada.CustomComponents.o oVar2 = (ru.himik.nightscream.kascada.CustomComponents.o) view;
                oVar2.o();
                if (!oVar2.c0) {
                    mbCanvas.this.onClickView(view);
                }
            } else if (action == 3) {
                ((ru.himik.nightscream.kascada.CustomComponents.o) view).o();
            }
            return true;
        }
    }

    class w0 implements DialogInterface.OnClickListener {
        w0(mbCanvas mbcanvas) {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            dialogInterface.cancel();
        }
    }

    class x implements View.OnTouchListener {
        x(mbCanvas mbcanvas) {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action != 0 && action != 2) {
                return true;
            }
            ((ru.himik.nightscream.kascada.CustomComponents.h) view).g((int) motionEvent.getX(), (int) motionEvent.getY());
            return true;
        }
    }

    class y implements View.OnLongClickListener {
        y() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            View.DragShadowBuilder dragShadowBuilder;
            if (mbCanvas.this.f9206k) {
                return true;
            }
            if (view instanceof ru.himik.nightscream.kascada.CustomComponents.z) {
                ((ru.himik.nightscream.kascada.CustomComponents.z) view).setTimeZ(System.currentTimeMillis() + 1471228928);
            }
            mbCanvas.this.q(false);
            mbCanvas.this.f9201f.setVisibility(0);
            view.setVisibility(4);
            if (view instanceof ru.himik.nightscream.kascada.z) {
                dragShadowBuilder = new View.DragShadowBuilder(view);
            } else {
                ru.himik.nightscream.kascada.s.c cVar = new ru.himik.nightscream.kascada.s.c(view);
                cVar.a(((ru.himik.nightscream.kascada.s.a) view).getPointTouch());
                dragShadowBuilder = cVar;
            }
            view.startDrag(null, dragShadowBuilder, view, 0);
            view.bringToFront();
            mbCanvas mbcanvas = mbCanvas.this;
            mbcanvas.f9204i = view;
            mbcanvas.D();
            return true;
        }
    }

    class z implements View.OnDragListener {
        z() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override // android.view.View.OnDragListener
        public boolean onDrag(View view, DragEvent dragEvent) {
            mbCanvas mbcanvas;
            int i2;
            int i3;
            String str;
            float f2;
            int height;
            if (view == null) {
                return false;
            }
            mbCanvas.this.W.animate().translationY(mbCanvas.this.W.getHeight());
            View view2 = (View) dragEvent.getLocalState();
            mbCanvas.this.M0 = view2.getId() == R.id.resize_top_left || view2.getId() == R.id.resize_top_right || view2.getId() == R.id.resize_bottom_left || view2.getId() == R.id.resize_bottom_right;
            mbCanvas.this.N0 = dragEvent.getX();
            mbCanvas.this.O0 = dragEvent.getY();
            int action = dragEvent.getAction();
            if (action != 2) {
                if (action == 3) {
                    if (dragEvent.getClipData() == null) {
                        view2.setVisibility(0);
                        mbCanvas mbcanvas2 = mbCanvas.this;
                        if (!mbcanvas2.M0) {
                            boolean z = view2 instanceof ru.himik.nightscream.kascada.z;
                            float f3 = mbcanvas2.N0;
                            if (z) {
                                view2.setX(f3 - (view2.getWidth() / 2));
                                f2 = mbCanvas.this.O0;
                                height = view2.getHeight() / 2;
                            } else {
                                ru.himik.nightscream.kascada.s.a aVar = (ru.himik.nightscream.kascada.s.a) view2;
                                view2.setX(f3 - aVar.getPointTouch().x);
                                f2 = mbCanvas.this.O0;
                                height = aVar.getPointTouch().y;
                            }
                            view2.setY(f2 - height);
                            if (view2 instanceof ru.himik.nightscream.kascada.s.b) {
                                mbCanvas.this.StartResize(view2);
                            }
                            if (view2 instanceof RelativeLayout) {
                                for (int i4 = 0; i4 < mbCanvas.this.V.size(); i4++) {
                                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = mbCanvas.this.V;
                                    ru.himik.nightscream.kascada.CustomComponents.z zVar = sparseArray.get(sparseArray.keyAt(i4));
                                    if (zVar.p()) {
                                        View view3 = (View) zVar;
                                        view3.setX(mbCanvas.this.U.getX() + zVar.getDiffX());
                                        view3.setY(mbCanvas.this.U.getY() + zVar.getDiffY());
                                        view3.invalidate();
                                    }
                                }
                                mbCanvas.this.U.setVisibility(0);
                            }
                        }
                        if (view2 instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                            ((ru.himik.nightscream.kascada.Logic.c.a) view2).r();
                            mbCanvas.f1.invalidate();
                        }
                        if (view2 instanceof ru.himik.nightscream.kascada.z) {
                            mbCanvas.f1.invalidate();
                        }
                    } else {
                        int id = view2.getId();
                        if (id != R.id.cardViewFileMacros) {
                            switch (id) {
                                case R.id.tab_alarm /* 2131297079 */:
                                    mbcanvas = mbCanvas.this;
                                    i2 = (int) mbcanvas.N0;
                                    i3 = (int) mbcanvas.O0;
                                    str = "CustomAlarm";
                                    mbcanvas.l(str, i2, i3, 0);
                                    break;
                                case R.id.tab_archive /* 2131297080 */:
                                    mbcanvas = mbCanvas.this;
                                    i2 = (int) mbcanvas.N0;
                                    i3 = (int) mbcanvas.O0;
                                    str = "CustomArchive";
                                    mbcanvas.l(str, i2, i3, 0);
                                    break;
                                default:
                                    switch (id) {
                                        case R.id.tab_button /* 2131297082 */:
                                            mbCanvas mbcanvas3 = mbCanvas.this;
                                            mbcanvas3.l("CustomButton", (int) mbcanvas3.N0, (int) mbcanvas3.O0, 4);
                                            break;
                                        case R.id.tab_camera /* 2131297083 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomCamera";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_digital_indicator /* 2131297084 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomRegister";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_digital_setters /* 2131297085 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomEditNumber";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_dyn_pictures /* 2131297086 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomDynPictures";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_dyn_text /* 2131297087 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomDynText";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_el_and /* 2131297088 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_AND";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_el_arithmetic_float /* 2131297089 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_ARITHMETIC_FLOAT";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_el_arithmetic_int /* 2131297090 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_ARITHMETIC_INT";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_el_compare_float /* 2131297091 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_COMPARE_FLOAT";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_el_compare_int /* 2131297092 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_COMPARE";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_el_or /* 2131297093 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_OR";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_email /* 2131297094 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomEmail";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_abs /* 2131297095 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "ABS";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_array /* 2131297096 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_ARRAY";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_change_f /* 2131297097 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_CHANGE_F";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_change_i /* 2131297098 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_CHANGE_I";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_ctu /* 2131297099 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_CTU";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_dt /* 2131297100 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "ODTEMP";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_float_to_int /* 2131297101 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FloatToInt";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_int_to_float /* 2131297102 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "IntToFloat";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_log /* 2131297103 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "LOG";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_macro /* 2131297104 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "Macro";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_move /* 2131297105 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_MOVE";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_mqtt_publisher /* 2131297106 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "MQTT_PUBLISHER";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_mqtt_subscriber /* 2131297107 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "MQTT_SUBSCRIBER";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_mx /* 2131297108 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_MX";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_pow /* 2131297109 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_POW";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_rs /* 2131297110 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_RS";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_sel /* 2131297111 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_SEL";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_sensor_light /* 2131297112 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "Sensor_light";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_sensor_orientation /* 2131297113 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "Sensor_Orientation";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_sensor_speed /* 2131297114 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "Sensor_speed";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_sin /* 2131297115 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "SIN";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_sunrise /* 2131297116 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "Sunrise_GPS";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_t_trigger /* 2131297117 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_TRIGGER";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_timer /* 2131297118 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_TIMER";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_word_to_float /* 2131297119 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "WordToFloat";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_fb_xor /* 2131297120 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "FB_XOR";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_gateway /* 2131297121 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomGateway";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_gateway_bit /* 2131297122 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomGatewayBit";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_gif /* 2131297123 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomGif";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_graph /* 2131297124 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomGraphIco";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_lamp /* 2131297125 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomLamp";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_line_level /* 2131297126 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomLineLevel";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_line_setter /* 2131297127 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomSeekBar";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_list /* 2131297128 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomList";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_push_notif /* 2131297129 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomPushNotif";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_round_indicator /* 2131297130 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomGauge2";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_sms_in /* 2131297131 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomSmsReceive";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_sms_out /* 2131297132 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomSms";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_sound /* 2131297133 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomSound";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_switch /* 2131297134 */:
                                            mbCanvas mbcanvas4 = mbCanvas.this;
                                            mbcanvas4.l("CustomSwitch", (int) mbcanvas4.N0, (int) mbcanvas4.O0, 8);
                                            break;
                                        case R.id.tab_text /* 2131297135 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomLabel";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_var /* 2131297136 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "Var";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_varFloat /* 2131297137 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "VarFloat";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_varInt /* 2131297138 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "VarInt";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_varOut /* 2131297139 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "VarOut";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_varOutFloat /* 2131297140 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "VarOutFloat";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_varOutInt /* 2131297141 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "VarOutInt";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_var_name_in /* 2131297142 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "VarNameIn";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_var_name_out /* 2131297143 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "VarNameOut";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_voice_recognition /* 2131297144 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomVoiceRecognition";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                        case R.id.tab_web_view /* 2131297145 */:
                                            mbcanvas = mbCanvas.this;
                                            i2 = (int) mbcanvas.N0;
                                            i3 = (int) mbcanvas.O0;
                                            str = "CustomWebView";
                                            mbcanvas.l(str, i2, i3, 0);
                                            break;
                                    }
                                    break;
                            }
                        } else {
                            mbCanvas mbcanvas5 = mbCanvas.this;
                            String string = dragEvent.getClipData().getItemAt(0).getText().toString();
                            mbCanvas mbcanvas6 = mbCanvas.this;
                            mbcanvas5.b0(string, (int) mbcanvas6.N0, (int) mbcanvas6.O0);
                        }
                    }
                    mbCanvas.this.b0.bringToFront();
                    if (mbCanvas.this.f9207l.getVisibility() != 0) {
                        mbCanvas.this.a0.bringToFront();
                    }
                } else if (action != 4) {
                    if (action == 5) {
                        mbCanvas.this.x0(true);
                    }
                } else if (!dragEvent.getResult()) {
                    view2.setVisibility(0);
                }
                mbCanvas.this.f9201f.setVisibility(4);
            } else {
                mbCanvas mbcanvas7 = mbCanvas.this;
                if (mbcanvas7.M0) {
                    view2.setY(((int) mbcanvas7.O0) - (view2.getHeight() / 2));
                    view2.setX(((int) mbCanvas.this.N0) - (view2.getWidth() / 2));
                    view2.setVisibility(0);
                    mbCanvas.this.Resizing(view2);
                }
                if (view2 instanceof RelativeLayout) {
                    mbCanvas.this.U.setVisibility(4);
                    for (int i5 = 0; i5 < mbCanvas.this.V.size(); i5++) {
                        SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = mbCanvas.this.V;
                        ru.himik.nightscream.kascada.CustomComponents.z zVar2 = sparseArray2.get(sparseArray2.keyAt(i5));
                        if (zVar2.p()) {
                            View view4 = (View) zVar2;
                            mbCanvas mbcanvas8 = mbCanvas.this;
                            view4.setX((mbcanvas8.N0 - (mbcanvas8.U.getLayoutParams().width / 2)) + zVar2.getDiffX());
                            mbCanvas mbcanvas9 = mbCanvas.this;
                            view4.setY((mbcanvas9.O0 - (mbcanvas9.U.getLayoutParams().height / 2)) + zVar2.getDiffY());
                            view4.requestLayout();
                        }
                    }
                }
            }
            return true;
        }
    }

    static {
        System.loadLibrary("modbus");
    }

    private void A() {
        String string;
        Cursor cursorRawQuery = this.f9203h.getWritableDatabase().rawQuery("SELECT pass FROM TableNameProject WHERE name= '" + MyApplication.b().m0 + "'", null);
        if (cursorRawQuery != null) {
            cursorRawQuery.moveToFirst();
            string = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pass"));
        } else {
            string = "";
        }
        if (string == null) {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_pass), 0).show();
            return;
        }
        if (string.equals("")) {
            w0();
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.dialog_enter_password));
        EditText editText = new EditText(this);
        editText.setInputType(129);
        editText.setSelection(editText.getText().length());
        builder.setView(editText);
        builder.setPositiveButton(getResources().getString(R.string.dialog_accept), new e0(editText, string));
        builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new f0(this));
        builder.show();
    }

    public static void F(int i2, ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        if (bVar.l() == 100) {
            MyApplication.b().v0.e(bVar);
        } else {
            Y0.get(i2).e(bVar);
        }
    }

    private void G() {
        MyApplication myApplicationB;
        int i2;
        MyApplication myApplicationB2;
        Integer num;
        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        defaultDisplay.getMetrics(new DisplayMetrics());
        try {
            if (Build.VERSION.SDK_INT < 17) {
                if (MyApplication.b().i0) {
                    MyApplication.b().f9040h = ((Integer) Display.class.getMethod("getRawHeight", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
                    myApplicationB2 = MyApplication.b();
                    num = (Integer) Display.class.getMethod("getRawWidth", new Class[0]).invoke(defaultDisplay, new Object[0]);
                } else {
                    MyApplication.b().f9040h = ((Integer) Display.class.getMethod("getRawWidth", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
                    myApplicationB2 = MyApplication.b();
                    num = (Integer) Display.class.getMethod("getRawHeight", new Class[0]).invoke(defaultDisplay, new Object[0]);
                }
                myApplicationB2.f9041i = num.intValue();
                return;
            }
            Point point = new Point();
            Display.class.getMethod("getRealSize", Point.class).invoke(defaultDisplay, point);
            if (MyApplication.b().i0) {
                MyApplication.b().f9040h = point.y;
                myApplicationB = MyApplication.b();
                i2 = point.x;
            } else {
                MyApplication.b().f9040h = point.x;
                myApplicationB = MyApplication.b();
                i2 = point.y;
            }
            myApplicationB.f9041i = i2;
        } catch (Exception unused) {
        }
    }

    private void H() {
        if (a1 > MyApplication.b().o) {
            n0(1);
        }
    }

    static /* synthetic */ int I(ru.himik.nightscream.kascada.CustomComponents.z zVar, ru.himik.nightscream.kascada.CustomComponents.z zVar2) {
        return zVar.getCustomX() < zVar2.getCustomX() ? -1 : 1;
    }

    static /* synthetic */ int J(ru.himik.nightscream.kascada.CustomComponents.z zVar, ru.himik.nightscream.kascada.CustomComponents.z zVar2) {
        return zVar.getCustomY() < zVar2.getCustomY() ? -1 : 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: K, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ boolean L(View view) {
        ru.himik.nightscream.kascada.Utils.l.a.c();
        g.a.a.e.g(this, "Лицензия удалена").show();
        return true;
    }

    static /* synthetic */ void M(DialogInterface dialogInterface, int i2) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: N, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void O(DialogInterface dialogInterface, int i2) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://hmi-kascada.ru/")));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: Q, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void R(DialogInterface dialogInterface, int i2) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://kascada-cloud.fvds.ru/payment/shop/index.php")));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: S, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void T(DialogInterface dialogInterface, int i2) {
        dialogInterface.dismiss();
        r0();
    }

    static /* synthetic */ int U(ru.himik.nightscream.kascada.CustomComponents.z zVar, ru.himik.nightscream.kascada.CustomComponents.z zVar2) {
        return zVar.getTimeZ() < zVar2.getTimeZ() ? -1 : 1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: V, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void W(String str) {
        str.hashCode();
        switch (str) {
            case "тоскана":
            case "тоскану":
            case "listen":
            case "каскада":
            case "каскадов":
            case "каскадом":
                ru.himik.nightscream.kascada.Utils.l.a.l();
                try {
                    ru.himik.nightscream.kascada.r.y.c cVarA = ru.himik.nightscream.kascada.r.y.c.y0.a();
                    if (!cVarA.N()) {
                        cVarA.x1(getSupportFragmentManager(), "BottomSheetVoiceRecognition");
                        break;
                    }
                } catch (Exception unused) {
                }
                MyApplication.b().b.d("");
                break;
        }
    }

    static /* synthetic */ void X(Throwable th) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: Y, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void Z(DialogInterface dialogInterface, int i2) {
        new ru.himik.nightscream.kascada.r.d0(this).show();
        dialogInterface.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:315:0x054e A[PHI: r1
      0x054e: PHI (r1v300 ru.himik.nightscream.kascada.Logic.c.d) = 
      (r1v142 ru.himik.nightscream.kascada.Logic.c.d)
      (r1v298 ru.himik.nightscream.kascada.Logic.c.d)
      (r1v301 ru.himik.nightscream.kascada.Logic.c.d)
     binds: [B:689:0x1ae9, B:314:0x054c, B:300:0x04ae] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:322:0x05ad A[PHI: r1
      0x05ad: PHI (r1v303 ru.himik.nightscream.kascada.Logic.c.c) = 
      (r1v136 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v143 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v156 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v165 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v209 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v210 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v211 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v246 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v273 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v274 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v295 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v296 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v297 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v299 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v302 ru.himik.nightscream.kascada.Logic.c.c)
      (r1v304 ru.himik.nightscream.kascada.Logic.c.c)
     binds: [B:721:0x1c56, B:682:0x1a9a, B:630:0x177b, B:608:0x1632, B:520:0x10ea, B:513:0x109b, B:506:0x104c, B:441:0x0c48, B:413:0x0aac, B:406:0x0a5d, B:335:0x0658, B:328:0x060a, B:321:0x05ab, B:307:0x04fd, B:293:0x045f, B:286:0x0410] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:538:0x1206 A[PHI: r1
      0x1206: PHI (r1v182 ru.himik.nightscream.kascada.Logic.c.f) = 
      (r1v350 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v351 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v352 ru.himik.nightscream.kascada.Logic.c.f)
     binds: [B:700:0x1b59, B:668:0x19d8, B:537:0x1204] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:539:0x1208 A[PHI: r1
      0x1208: PHI (r1v180 ru.himik.nightscream.kascada.Logic.c.f) = 
      (r1v355 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v356 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v357 ru.himik.nightscream.kascada.Logic.c.f)
     binds: [B:700:0x1b59, B:668:0x19d8, B:537:0x1204] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:645:0x1847 A[PHI: r1
      0x1847: PHI (r1v292 ru.himik.nightscream.kascada.Logic.c.f) = 
      (r1v137 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v153 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v217 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v218 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v284 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v291 ru.himik.nightscream.kascada.Logic.c.f)
      (r1v293 ru.himik.nightscream.kascada.Logic.c.f)
     binds: [B:714:0x1c07, B:644:0x1845, B:477:0x0e65, B:470:0x0e16, B:371:0x083f, B:354:0x0773, B:347:0x0724] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:696:0x1b1a A[PHI: r1
      0x1b1a: PHI (r1v285 ru.himik.nightscream.kascada.Logic.c.g) = 
      (r1v347 ru.himik.nightscream.kascada.Logic.c.g)
      (r1v348 ru.himik.nightscream.kascada.Logic.c.g)
      (r1v349 ru.himik.nightscream.kascada.Logic.c.g)
     binds: [B:695:0x1b18, B:692:0x1b01, B:364:0x07ed] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:697:0x1b1c A[PHI: r1
      0x1b1c: PHI (r1v288 ru.himik.nightscream.kascada.Logic.c.g) = 
      (r1v340 ru.himik.nightscream.kascada.Logic.c.g)
      (r1v341 ru.himik.nightscream.kascada.Logic.c.g)
      (r1v342 ru.himik.nightscream.kascada.Logic.c.g)
     binds: [B:695:0x1b18, B:692:0x1b01, B:364:0x07ed] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:708:0x1baa A[PHI: r1
      0x1baa: PHI (r1v277 ru.himik.nightscream.kascada.Logic.c.b) = 
      (r1v138 ru.himik.nightscream.kascada.Logic.c.b)
      (r1v177 ru.himik.nightscream.kascada.Logic.c.b)
      (r1v178 ru.himik.nightscream.kascada.Logic.c.b)
      (r1v179 ru.himik.nightscream.kascada.Logic.c.b)
      (r1v272 ru.himik.nightscream.kascada.Logic.c.b)
      (r1v278 ru.himik.nightscream.kascada.Logic.c.b)
     binds: [B:707:0x1ba8, B:561:0x1324, B:554:0x12d5, B:547:0x1286, B:420:0x0afb, B:392:0x09a0] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:9:0x0028  */
    /* JADX WARN: Type inference incomplete: some casts might be missing */
    public void l(String str, int i2, int i3, int i4) {
        ru.himik.nightscream.kascada.Logic.c.c fb_arithmetic_int;
        ru.himik.nightscream.kascada.Logic.c.f odtemp;
        ru.himik.nightscream.kascada.Logic.c.b intToFloat;
        ru.himik.nightscream.kascada.Logic.c.d fb_array;
        ru.himik.nightscream.kascada.CustomComponents.b bVar;
        ru.himik.nightscream.kascada.Logic.c.f fVar;
        int iKeyAt;
        ru.himik.nightscream.kascada.Logic.c.f fVar2;
        ru.himik.nightscream.kascada.Logic.c.f fVar3;
        ru.himik.nightscream.kascada.Logic.c.g gVar;
        int iKeyAt2;
        View view;
        ru.himik.nightscream.kascada.Logic.c.g gVar2;
        ru.himik.nightscream.kascada.Logic.c.g gVar3;
        if (E() > n1 && !ru.himik.nightscream.kascada.Utils.l.a.f()) {
            t0();
        }
        str.hashCode();
        boolean z2 = true;
        switch (str) {
            case "FB_ARITHMETIC_INT":
                fb_arithmetic_int = new FB_ARITHMETIC_INT(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt3 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt3, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt3, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "ODTEMP":
                odtemp = new ODTEMP(this);
                X0.addView(odtemp);
                int iKeyAt4 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt4, odtemp);
                odtemp.s(i2, i3, iKeyAt4, false);
                odtemp.setNumScreen(a1);
                odtemp.setOnLongClickListener(this.L0);
                odtemp.setOnClickListener(this.R0);
                if (a1 == -1) {
                    odtemp.setRootNameMacro(this.W0.getName());
                    odtemp.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "IntToFloat":
                intToFloat = new IntToFloat(this);
                X0.addView(intToFloat);
                int iKeyAt5 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt5, intToFloat);
                intToFloat.j(i2, i3, iKeyAt5, false);
                intToFloat.setNumScreen(a1);
                intToFloat.setOnLongClickListener(this.L0);
                intToFloat.setOnClickListener(this.R0);
                if (a1 == -1) {
                    intToFloat.setRootNameMacro(this.W0.getName());
                    intToFloat.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "VarInt":
                VarInt varInt = new VarInt(this);
                X0.addView(varInt);
                fVar3 = varInt;
                fVar = varInt;
                if (MyApplication.b().D.size() == 0) {
                    iKeyAt = 0;
                    fVar2 = fVar3;
                } else {
                    iKeyAt = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                    fVar2 = fVar;
                }
                MyApplication.b().D.append(iKeyAt, fVar2);
                fVar2.s(i2, i3, iKeyAt, false);
                fVar2.setNumScreen(a1);
                view = fVar2;
                view.setOnLongClickListener(this.L0);
                view.setOnClickListener(this.R0);
                break;
            case "VarOut":
                VarOut varOut = new VarOut(this);
                X0.addView(varOut);
                gVar3 = varOut;
                gVar = varOut;
                if (MyApplication.b().D.size() == 0) {
                    iKeyAt2 = 0;
                    gVar2 = gVar;
                } else {
                    iKeyAt2 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                    gVar2 = gVar3;
                }
                MyApplication.b().D.append(iKeyAt2, gVar2);
                gVar2.s(i2, i3, iKeyAt2, false);
                gVar2.setNumScreen(a1);
                view = gVar2;
                view.setOnLongClickListener(this.L0);
                view.setOnClickListener(this.R0);
                break;
            case "VarOutFloat":
                VarOutFloat varOutFloat = new VarOutFloat(this);
                X0.addView(varOutFloat);
                gVar3 = varOutFloat;
                gVar = varOutFloat;
                if (MyApplication.b().D.size() == 0) {
                    iKeyAt2 = 0;
                    gVar2 = gVar;
                } else {
                    iKeyAt2 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                    gVar2 = gVar3;
                }
                MyApplication.b().D.append(iKeyAt2, gVar2);
                gVar2.s(i2, i3, iKeyAt2, false);
                gVar2.setNumScreen(a1);
                view = gVar2;
                view.setOnLongClickListener(this.L0);
                view.setOnClickListener(this.R0);
                break;
            case "FB_ARRAY":
                fb_array = new FB_ARRAY(this);
                X0.addView(fb_array);
                int iKeyAt6 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt6, fb_array);
                fb_array.j(i2, i3, iKeyAt6, false);
                fb_array.setNumScreen(a1);
                fb_array.setOnLongClickListener(this.L0);
                fb_array.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_array.setRootNameMacro(this.W0.getName());
                    fb_array.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_TIMER":
                fb_arithmetic_int = new FB_TIMER(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt7 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt7, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt7, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomWebView":
                ru.himik.nightscream.kascada.CustomComponents.b0 b0Var = new ru.himik.nightscream.kascada.CustomComponents.b0(this);
                X0.addView(b0Var);
                int iKeyAt8 = MyApplication.b().d0.size() == 0 ? 0 : MyApplication.b().d0.keyAt(MyApplication.b().d0.size() - 1) + 1;
                b0Var.c(i2, i3, iKeyAt8, false);
                MyApplication.b().d0.append(iKeyAt8, b0Var);
                b0Var.setTag(Integer.valueOf(b0Var.getIdComponent()));
                b0Var.bringToFront();
                b0Var.setOnLongClickListener(this.L0);
                b0Var.setOnClickListener(this.t0);
                b0Var.setNumScreen(a1);
                b0Var.invalidate();
                b0Var.setTimeZ(System.currentTimeMillis() + 1471228928);
                b0Var.loadUrl("https://hmi-kascada.ru/");
                if (MyApplication.b().f9042j == 1) {
                    bVar = b0Var.f8729f;
                    bVar.E(0);
                    break;
                }
                break;
            case "VarFloat":
                VarFloat varFloat = new VarFloat(this);
                X0.addView(varFloat);
                fVar3 = varFloat;
                fVar = varFloat;
                if (MyApplication.b().D.size() == 0) {
                    iKeyAt = 0;
                    fVar2 = fVar3;
                } else {
                    iKeyAt = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                    fVar2 = fVar;
                }
                MyApplication.b().D.append(iKeyAt, fVar2);
                fVar2.s(i2, i3, iKeyAt, false);
                fVar2.setNumScreen(a1);
                view = fVar2;
                view.setOnLongClickListener(this.L0);
                view.setOnClickListener(this.R0);
                break;
            case "CustomGif":
                ru.himik.nightscream.kascada.CustomComponents.n nVar = new ru.himik.nightscream.kascada.CustomComponents.n(this);
                X0.addView(nVar);
                int iKeyAt9 = MyApplication.b().T.size() == 0 ? 0 : MyApplication.b().T.keyAt(MyApplication.b().T.size() - 1) + 1;
                nVar.d(i2, i3, iKeyAt9, false);
                MyApplication.b().T.append(iKeyAt9, nVar);
                nVar.f8854g.L(nVar.f8853f);
                nVar.f8854g.A(nVar.getIdComponent());
                nVar.bringToFront();
                nVar.setOnLongClickListener(this.L0);
                nVar.setOnClickListener(this.t0);
                nVar.setNumScreen(a1);
                nVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = nVar.f8854g;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomSms":
                ru.himik.nightscream.kascada.CustomComponents.w wVar = new ru.himik.nightscream.kascada.CustomComponents.w(this);
                X0.addView(wVar);
                int iKeyAt10 = MyApplication.b().N.size() == 0 ? 0 : MyApplication.b().N.keyAt(MyApplication.b().N.size() - 1) + 1;
                wVar.a(i2, i3, iKeyAt10, false);
                MyApplication.b().N.append(iKeyAt10, wVar);
                wVar.setTag(Integer.valueOf(wVar.getIdComponent()));
                wVar.f8921g.L(wVar.f8920f);
                wVar.f8921g.A(wVar.getIdComponent());
                wVar.bringToFront();
                wVar.setOnLongClickListener(this.L0);
                wVar.setOnClickListener(this.t0);
                wVar.setNumScreen(a1);
                wVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = wVar.f8921g;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomSeekBar":
                ru.himik.nightscream.kascada.CustomComponents.v vVar = new ru.himik.nightscream.kascada.CustomComponents.v(this);
                X0.addView(vVar);
                int iKeyAt11 = MyApplication.b().Q.size() == 0 ? 0 : MyApplication.b().Q.keyAt(MyApplication.b().Q.size() - 1) + 1;
                vVar.f(i2, i3, iKeyAt11, false);
                MyApplication.b().Q.append(iKeyAt11, vVar);
                vVar.setTag(Integer.valueOf(vVar.getIdComponent()));
                vVar.f8909f.L(vVar.f8908e);
                vVar.f8909f.A(vVar.getIdComponent());
                vVar.bringToFront();
                vVar.setOnLongSeekBarClick(this.H0);
                vVar.setOnTouchListener(this.G0);
                vVar.setOnSeekBarChangeListener(this.F0);
                vVar.setNumScreen(a1);
                vVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = vVar.f8909f;
                    bVar.E(0);
                    break;
                }
                break;
            case "Sensor_Orientation":
                odtemp = new Sensor_Orientation(this);
                X0.addView(odtemp);
                int iKeyAt12 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt12, odtemp);
                odtemp.s(i2, i3, iKeyAt12, false);
                odtemp.setNumScreen(a1);
                odtemp.setOnLongClickListener(this.L0);
                odtemp.setOnClickListener(this.R0);
                if (a1 == -1) {
                    odtemp.setRootNameMacro(this.W0.getName());
                    odtemp.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomDynText":
                CustomDynText customDynText = new CustomDynText(this);
                X0.addView(customDynText);
                int iKeyAt13 = MyApplication.b().K.size() == 0 ? 0 : MyApplication.b().K.keyAt(MyApplication.b().K.size() - 1) + 1;
                customDynText.s(i2, i3, iKeyAt13, false);
                MyApplication.b().K.append(iKeyAt13, customDynText);
                customDynText.setTag(Integer.valueOf(customDynText.getIdComponent()));
                customDynText.f8667i.L(customDynText.f8666h);
                customDynText.f8667i.A(customDynText.getIdComponent());
                customDynText.bringToFront();
                customDynText.setOnLongClickListener(this.L0);
                customDynText.setOnClickListener(this.t0);
                customDynText.setNumScreen(a1);
                customDynText.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = customDynText.f8667i;
                    bVar.E(0);
                    break;
                }
                break;
            case "FB_MOVE":
                fb_arithmetic_int = new FB_MOVE(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt14 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt14, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt14, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomVoiceRecognition":
                if (MyApplication.b().f0.size() > 0) {
                    ru.himik.nightscream.kascada.Utils.l.a.l();
                }
                ru.himik.nightscream.kascada.CustomComponents.a0 a0Var = new ru.himik.nightscream.kascada.CustomComponents.a0(this);
                X0.addView(a0Var);
                int iKeyAt15 = MyApplication.b().f0.size() == 0 ? 0 : MyApplication.b().f0.keyAt(MyApplication.b().f0.size() - 1) + 1;
                a0Var.c(i2, i3, iKeyAt15, false);
                MyApplication.b().f0.append(iKeyAt15, a0Var);
                a0Var.setTag(Integer.valueOf(a0Var.getIdComponent()));
                a0Var.bringToFront();
                a0Var.setOnLongClickListener(this.L0);
                a0Var.setOnClickListener(this.t0);
                a0Var.setNumScreen(a1);
                a0Var.invalidate();
                a0Var.setTimeZ(System.currentTimeMillis() + 1471228928);
                a0Var.f8708g.E(100);
                break;
            case "CustomRegister":
                ru.himik.nightscream.kascada.CustomComponents.u uVar = new ru.himik.nightscream.kascada.CustomComponents.u(this);
                X0.addView(uVar);
                int iKeyAt16 = MyApplication.b().H.size() == 0 ? 0 : MyApplication.b().H.keyAt(MyApplication.b().H.size() - 1) + 1;
                uVar.k(i2, i3, iKeyAt16, false);
                MyApplication.b().H.append(iKeyAt16, uVar);
                uVar.setTag(Integer.valueOf(uVar.getIdComponent()));
                uVar.f8903k.L(uVar.f8901i);
                uVar.f8903k.A(uVar.getIdComponent());
                uVar.bringToFront();
                uVar.setTextColor(-16777216);
                uVar.setOnLongClickListener(this.L0);
                uVar.setOnClickListener(this.t0);
                uVar.setNumScreen(a1);
                uVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = uVar.f8903k;
                    bVar.E(0);
                    break;
                }
                break;
            case "FB_COMPARE":
                fb_arithmetic_int = new FB_COMPARE(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt17 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt17, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt17, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomAlarm":
                ru.himik.nightscream.kascada.CustomComponents.c cVar = new ru.himik.nightscream.kascada.CustomComponents.c(this);
                X0.addView(cVar);
                int iKeyAt18 = MyApplication.b().M.size() == 0 ? 0 : MyApplication.b().M.keyAt(MyApplication.b().M.size() - 1) + 1;
                cVar.a(i2, i3, iKeyAt18, false);
                MyApplication.b().M.append(iKeyAt18, cVar);
                cVar.setTag(Integer.valueOf(cVar.getIdComponent()));
                cVar.f8742h.L(cVar.f8741g);
                cVar.f8742h.A(cVar.getIdComponent());
                cVar.bringToFront();
                cVar.setOnLongClickListener(this.L0);
                cVar.setOnClickListener(this.t0);
                cVar.setNumScreen(a1);
                cVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = cVar.f8742h;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomEmail":
                ru.himik.nightscream.kascada.CustomComponents.j jVar = new ru.himik.nightscream.kascada.CustomComponents.j(this);
                X0.addView(jVar);
                int iKeyAt19 = MyApplication.b().e0.size() == 0 ? 0 : MyApplication.b().e0.keyAt(MyApplication.b().e0.size() - 1) + 1;
                jVar.a(i2, i3, iKeyAt19, false);
                MyApplication.b().e0.append(iKeyAt19, jVar);
                jVar.setTag(Integer.valueOf(jVar.getIdComponent()));
                jVar.bringToFront();
                jVar.setOnLongClickListener(this.L0);
                jVar.setOnClickListener(this.t0);
                jVar.setNumScreen(a1);
                jVar.invalidate();
                jVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = jVar.f8822h;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomLabel":
                CustomLabel customLabel = new CustomLabel(this);
                X0.addView(customLabel);
                int iKeyAt20 = MyApplication.b().G.size() == 0 ? 0 : MyApplication.b().G.keyAt(MyApplication.b().G.size() - 1) + 1;
                MyApplication.b().G.append(iKeyAt20, customLabel);
                customLabel.o(i2, i3, iKeyAt20, false);
                customLabel.setTag(Integer.valueOf(customLabel.getIdComponent()));
                customLabel.bringToFront();
                customLabel.setOnLongClickListener(this.L0);
                customLabel.setOnClickListener(this.t0);
                customLabel.setNumScreen(a1);
                customLabel.setTimeZ(System.currentTimeMillis() + 1471228928);
                break;
            case "CustomSound":
                CustomSound customSound = new CustomSound(this);
                X0.addView(customSound);
                int iKeyAt21 = MyApplication.b().Y.size() == 0 ? 0 : MyApplication.b().Y.keyAt(MyApplication.b().Y.size() - 1) + 1;
                customSound.c(i2, i3, iKeyAt21, false);
                MyApplication.b().Y.append(iKeyAt21, customSound);
                customSound.setTag(Integer.valueOf(customSound.getIdComponent()));
                customSound.f8696g.L(customSound.f8695f);
                customSound.f8696g.A(customSound.getIdComponent());
                customSound.bringToFront();
                customSound.setOnLongClickListener(this.L0);
                customSound.setOnClickListener(this.t0);
                customSound.setNumScreen(a1);
                customSound.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = customSound.f8696g;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomCircleGauge":
                ru.himik.nightscream.kascada.CustomComponents.g gVar4 = new ru.himik.nightscream.kascada.CustomComponents.g(this);
                X0.addView(gVar4);
                int iKeyAt22 = MyApplication.b().P.size() == 0 ? 0 : MyApplication.b().P.keyAt(MyApplication.b().P.size() - 1) + 1;
                gVar4.h(i2, i3, iKeyAt22, false);
                MyApplication.b().P.append(iKeyAt22, gVar4);
                gVar4.setTag(Integer.valueOf(gVar4.getIdComponent()));
                gVar4.I.L(gVar4.H);
                gVar4.I.A(gVar4.getIdComponent());
                gVar4.bringToFront();
                gVar4.setOnLongClickListener(this.L0);
                gVar4.setOnClickListener(this.t0);
                gVar4.setNumScreen(a1);
                gVar4.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = gVar4.I;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomLineLevel":
                ru.himik.nightscream.kascada.CustomComponents.r rVar = new ru.himik.nightscream.kascada.CustomComponents.r(this, null, android.R.attr.progressBarStyleHorizontal);
                X0.addView(rVar);
                int iKeyAt23 = MyApplication.b().O.size() == 0 ? 0 : MyApplication.b().O.keyAt(MyApplication.b().O.size() - 1) + 1;
                rVar.b(i2, i3, iKeyAt23, false);
                MyApplication.b().O.append(iKeyAt23, rVar);
                rVar.setTag(Integer.valueOf(rVar.getIdComponent()));
                rVar.f8874e.L(rVar.f8873d);
                rVar.f8874e.A(rVar.getIdComponent());
                rVar.bringToFront();
                rVar.setOnLongClickListener(this.L0);
                rVar.setOnClickListener(this.t0);
                rVar.setNumScreen(a1);
                rVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = rVar.f8874e;
                    bVar.E(0);
                    break;
                }
                break;
            case "ABS":
                intToFloat = new ABS(this);
                X0.addView(intToFloat);
                int iKeyAt24 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt24, intToFloat);
                intToFloat.j(i2, i3, iKeyAt24, false);
                intToFloat.setNumScreen(a1);
                intToFloat.setOnLongClickListener(this.L0);
                intToFloat.setOnClickListener(this.R0);
                if (a1 == -1) {
                    intToFloat.setRootNameMacro(this.W0.getName());
                    intToFloat.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "LOG":
                intToFloat = new LOG(this);
                X0.addView(intToFloat);
                int iKeyAt25 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt25, intToFloat);
                intToFloat.j(i2, i3, iKeyAt25, false);
                intToFloat.setNumScreen(a1);
                intToFloat.setOnLongClickListener(this.L0);
                intToFloat.setOnClickListener(this.R0);
                if (a1 == -1) {
                    intToFloat.setRootNameMacro(this.W0.getName());
                    intToFloat.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "SIN":
                intToFloat = new SIN(this);
                X0.addView(intToFloat);
                int iKeyAt26 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt26, intToFloat);
                intToFloat.j(i2, i3, iKeyAt26, false);
                intToFloat.setNumScreen(a1);
                intToFloat.setOnLongClickListener(this.L0);
                intToFloat.setOnClickListener(this.R0);
                if (a1 == -1) {
                    intToFloat.setRootNameMacro(this.W0.getName());
                    intToFloat.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "Var":
                Var var = new Var(this);
                X0.addView(var);
                fVar3 = var;
                fVar = var;
                if (MyApplication.b().D.size() == 0) {
                    iKeyAt = 0;
                    fVar2 = fVar3;
                } else {
                    iKeyAt = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                    fVar2 = fVar;
                }
                MyApplication.b().D.append(iKeyAt, fVar2);
                fVar2.s(i2, i3, iKeyAt, false);
                fVar2.setNumScreen(a1);
                view = fVar2;
                view.setOnLongClickListener(this.L0);
                view.setOnClickListener(this.R0);
                break;
            case "CustomSmsReceive":
                ru.himik.nightscream.kascada.CustomComponents.x xVar = new ru.himik.nightscream.kascada.CustomComponents.x(this);
                X0.addView(xVar);
                int iKeyAt27 = MyApplication.b().V.size() == 0 ? 0 : MyApplication.b().V.keyAt(MyApplication.b().V.size() - 1) + 1;
                xVar.a(i2, i3, iKeyAt27, false);
                MyApplication.b().V.append(iKeyAt27, xVar);
                xVar.setTag(Integer.valueOf(xVar.getIdComponent()));
                xVar.f8932g.L(xVar.f8931f);
                xVar.f8932g.A(xVar.getIdComponent());
                xVar.bringToFront();
                xVar.setOnLongClickListener(this.L0);
                xVar.setOnClickListener(this.t0);
                xVar.setNumScreen(a1);
                xVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = xVar.f8932g;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomButton":
                ru.himik.nightscream.kascada.CustomComponents.e eVar = new ru.himik.nightscream.kascada.CustomComponents.e(this);
                X0.addView(eVar);
                int iKeyAt28 = MyApplication.b().J.size() == 0 ? 0 : MyApplication.b().J.keyAt(MyApplication.b().J.size() - 1) + 1;
                eVar.setImageState(i4);
                eVar.k(i2, i3, iKeyAt28, false, i4);
                MyApplication.b().J.append(iKeyAt28, eVar);
                eVar.setTag(Integer.valueOf(eVar.getIdComponent()));
                eVar.f8769i.L(eVar.f8768h);
                eVar.f8769i.A(eVar.getIdComponent());
                eVar.bringToFront();
                eVar.setOnLongClickListener(this.L0);
                eVar.setOnClickListener(this.t0);
                eVar.setNumScreen(a1);
                eVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = eVar.f8769i;
                    bVar.E(0);
                    break;
                }
                break;
            case "FB_MX":
                fb_arithmetic_int = new FB_MX(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt29 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt29, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt29, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_OR":
                fb_arithmetic_int = new FB_OR(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt30 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt30, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt30, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_RS":
                fb_arithmetic_int = new FB_RS(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt31 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt31, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt31, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "Macro":
                x0(true);
                FB_MACRO fb_macro = new FB_MACRO(this);
                X0.addView(fb_macro);
                int iKeyAt32 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt32, fb_macro);
                fb_macro.s(i2, i3, iKeyAt32, false);
                fb_macro.setNumScreen(a1);
                fb_macro.setOnLongClickListener(this.L0);
                fb_macro.setOnClickListener(this.R0);
                ru.himik.nightscream.kascada.r.e0.r(this, fb_macro);
                this.W0 = fb_macro;
                a1 = -1;
                z2 = false;
                break;
            case "CustomCamera":
                ru.himik.nightscream.kascada.CustomComponents.f fVar4 = new ru.himik.nightscream.kascada.CustomComponents.f(this);
                X0.addView(fVar4);
                int iKeyAt33 = MyApplication.b().a0.size() == 0 ? 0 : MyApplication.b().a0.keyAt(MyApplication.b().a0.size() - 1) + 1;
                fVar4.g(i2, i3, iKeyAt33, false);
                MyApplication.b().a0.append(iKeyAt33, fVar4);
                fVar4.setTag(Integer.valueOf(fVar4.getIdComponent()));
                fVar4.bringToFront();
                fVar4.setOnLongClickListener(this.L0);
                fVar4.setOnClickListener(this.t0);
                fVar4.setNumScreen(a1);
                fVar4.setTimeZ(System.currentTimeMillis() + 1471228928);
                break;
            case "CustomGauge2":
                ru.himik.nightscream.kascada.CustomComponents.m mVar = new ru.himik.nightscream.kascada.CustomComponents.m(this);
                X0.addView(mVar);
                int iKeyAt34 = MyApplication.b().b0.size() == 0 ? 0 : MyApplication.b().b0.keyAt(MyApplication.b().b0.size() - 1) + 1;
                mVar.T(i2, i3, iKeyAt34, false);
                MyApplication.b().b0.append(iKeyAt34, mVar);
                mVar.setTag(Integer.valueOf(mVar.getIdComponent()));
                mVar.bringToFront();
                mVar.setOnLongClickListener(this.L0);
                mVar.setOnClickListener(this.t0);
                mVar.setNumScreen(a1);
                mVar.invalidate();
                mVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = mVar.J0;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomGatewayBit":
                ru.himik.nightscream.kascada.CustomComponents.l lVar = new ru.himik.nightscream.kascada.CustomComponents.l(this);
                X0.addView(lVar);
                int iKeyAt35 = MyApplication.b().Z.size() == 0 ? 0 : MyApplication.b().Z.keyAt(MyApplication.b().Z.size() - 1) + 1;
                lVar.b(i2, i3, iKeyAt35, false);
                MyApplication.b().Z.append(iKeyAt35, lVar);
                lVar.setTag(Integer.valueOf(lVar.getIdComponent()));
                lVar.f8842f.A(lVar.getIdComponent());
                lVar.f8843g.A(lVar.getIdComponent());
                lVar.bringToFront();
                lVar.setOnLongClickListener(this.L0);
                lVar.setOnClickListener(this.t0);
                lVar.setNumScreen(a1);
                lVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                break;
            case "Sensor_light":
                odtemp = new Sensor_Light(this);
                X0.addView(odtemp);
                int iKeyAt36 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt36, odtemp);
                odtemp.s(i2, i3, iKeyAt36, false);
                odtemp.setNumScreen(a1);
                odtemp.setOnLongClickListener(this.L0);
                odtemp.setOnClickListener(this.R0);
                if (a1 == -1) {
                    odtemp.setRootNameMacro(this.W0.getName());
                    odtemp.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "Sensor_speed":
                odtemp = new Sensor_Speed(this);
                X0.addView(odtemp);
                int iKeyAt37 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt37, odtemp);
                odtemp.s(i2, i3, iKeyAt37, false);
                odtemp.setNumScreen(a1);
                odtemp.setOnLongClickListener(this.L0);
                odtemp.setOnClickListener(this.R0);
                if (a1 == -1) {
                    odtemp.setRootNameMacro(this.W0.getName());
                    odtemp.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomLamp":
                ru.himik.nightscream.kascada.CustomComponents.q qVar = new ru.himik.nightscream.kascada.CustomComponents.q(this);
                X0.addView(qVar);
                int iKeyAt38 = MyApplication.b().I.size() == 0 ? 0 : MyApplication.b().I.keyAt(MyApplication.b().I.size() - 1) + 1;
                qVar.c(i2, i3, iKeyAt38, false);
                MyApplication.b().I.append(iKeyAt38, qVar);
                qVar.setTag(Integer.valueOf(qVar.getIdComponent()));
                qVar.f8865g.L(qVar.f8864f);
                qVar.f8865g.A(qVar.getIdComponent());
                qVar.bringToFront();
                qVar.setOnLongClickListener(this.L0);
                qVar.setOnClickListener(this.t0);
                qVar.setNumScreen(a1);
                qVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = qVar.f8865g;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomList":
                CustomList customList = new CustomList(this);
                X0.addView(customList);
                int iKeyAt39 = MyApplication.b().X.size() == 0 ? 0 : MyApplication.b().X.keyAt(MyApplication.b().X.size() - 1) + 1;
                customList.i(i2, i3, iKeyAt39, false);
                MyApplication.b().X.append(iKeyAt39, customList);
                customList.setTag(Integer.valueOf(customList.getIdComponent()));
                customList.f8687i.L(customList.f8686h);
                customList.f8687i.A(customList.getIdComponent());
                customList.bringToFront();
                customList.setOnLongClickListener(this.L0);
                customList.setOnClickListener(this.t0);
                customList.setNumScreen(a1);
                customList.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = customList.f8687i;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomSwitch":
                ru.himik.nightscream.kascada.CustomComponents.y yVar = new ru.himik.nightscream.kascada.CustomComponents.y(this);
                X0.addView(yVar);
                int iKeyAt40 = MyApplication.b().F.size() == 0 ? 0 : MyApplication.b().F.keyAt(MyApplication.b().F.size() - 1) + 1;
                yVar.setImageState(i4);
                yVar.c(i2, i3, iKeyAt40, false, i4);
                MyApplication.b().F.append(iKeyAt40, yVar);
                yVar.setTag(Integer.valueOf(yVar.getIdComponent()));
                yVar.f8943g.L(yVar.f8942f);
                yVar.f8943g.A(yVar.getIdComponent());
                yVar.bringToFront();
                yVar.setOnLongClickListener(this.L0);
                yVar.setOnClickListener(this.t0);
                yVar.setNumScreen(a1);
                yVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = yVar.f8943g;
                    bVar.E(0);
                    break;
                }
                break;
            case "FB_ARITHMETIC_FLOAT":
                fb_arithmetic_int = new FB_ARITHMETIC_FLOAT(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt41 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt41, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt41, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomGraphIco":
                n.a.f.d dVar = new n.a.f.d();
                n.a.g.d dVar2 = new n.a.g.d();
                ru.himik.nightscream.kascada.CustomComponents.o oVar = new ru.himik.nightscream.kascada.CustomComponents.o(this, new n.a.e.g(dVar, dVar2));
                oVar.F = dVar;
                oVar.G = dVar2;
                X0.addView(oVar);
                int iKeyAt42 = MyApplication.b().R.size() == 0 ? 0 : MyApplication.b().R.keyAt(MyApplication.b().R.size() - 1) + 1;
                oVar.m(i2, i3, iKeyAt42, false);
                MyApplication.b().R.append(iKeyAt42, oVar);
                oVar.setTag(Integer.valueOf(oVar.getIdComponent()));
                oVar.T.L(oVar.S);
                oVar.T.A(oVar.getIdComponent());
                oVar.bringToFront();
                oVar.setOnLongGraphClick(this.I0);
                oVar.setOnTouchListener(this.J0);
                oVar.setNumScreen(a1);
                oVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = oVar.T;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomDynPictures":
                ru.himik.nightscream.kascada.CustomComponents.h hVar = new ru.himik.nightscream.kascada.CustomComponents.h(this);
                X0.addView(hVar);
                int iKeyAt43 = MyApplication.b().U.size() == 0 ? 0 : MyApplication.b().U.keyAt(MyApplication.b().U.size() - 1) + 1;
                hVar.d(i2, i3, iKeyAt43, false);
                MyApplication.b().U.append(iKeyAt43, hVar);
                hVar.f8798e.L(hVar.f8797d);
                hVar.f8798e.A(hVar.getIdComponent());
                hVar.bringToFront();
                hVar.setOnLongClickListener(this.L0);
                hVar.setOnClickListener(this.t0);
                hVar.setNumScreen(a1);
                hVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = hVar.f8798e;
                    bVar.E(0);
                    break;
                }
                break;
            case "FloatToInt":
                intToFloat = new FloatToInt(this);
                X0.addView(intToFloat);
                int iKeyAt44 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt44, intToFloat);
                intToFloat.j(i2, i3, iKeyAt44, false);
                intToFloat.setNumScreen(a1);
                intToFloat.setOnLongClickListener(this.L0);
                intToFloat.setOnClickListener(this.R0);
                if (a1 == -1) {
                    intToFloat.setRootNameMacro(this.W0.getName());
                    intToFloat.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_CHANGE_F":
                fb_arithmetic_int = new FB_CHANGE_F(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt45 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt45, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt45, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_CHANGE_I":
                fb_arithmetic_int = new FB_CHANGE_I(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt46 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt46, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt46, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomPushNotif":
                ru.himik.nightscream.kascada.CustomComponents.t tVar = new ru.himik.nightscream.kascada.CustomComponents.t(this);
                X0.addView(tVar);
                int iKeyAt47 = MyApplication.b().c0.size() == 0 ? 0 : MyApplication.b().c0.keyAt(MyApplication.b().c0.size() - 1) + 1;
                tVar.a(i2, i3, iKeyAt47, false);
                MyApplication.b().c0.append(iKeyAt47, tVar);
                tVar.setTag(Integer.valueOf(tVar.getIdComponent()));
                tVar.bringToFront();
                tVar.setOnLongClickListener(this.L0);
                tVar.setOnClickListener(this.t0);
                tVar.setNumScreen(a1);
                tVar.invalidate();
                tVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = tVar.f8889g;
                    bVar.E(0);
                    break;
                }
                break;
            case "WordToFloat":
                intToFloat = new WordToFloat(this);
                X0.addView(intToFloat);
                int iKeyAt48 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt48, intToFloat);
                intToFloat.j(i2, i3, iKeyAt48, false);
                intToFloat.setNumScreen(a1);
                intToFloat.setOnLongClickListener(this.L0);
                intToFloat.setOnClickListener(this.R0);
                if (a1 == -1) {
                    intToFloat.setRootNameMacro(this.W0.getName());
                    intToFloat.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomArchive":
                ru.himik.nightscream.kascada.CustomComponents.d dVar3 = new ru.himik.nightscream.kascada.CustomComponents.d(this);
                X0.addView(dVar3);
                int iKeyAt49 = MyApplication.b().S.size() == 0 ? 0 : MyApplication.b().S.keyAt(MyApplication.b().S.size() - 1) + 1;
                dVar3.g(i2, i3, iKeyAt49, false);
                dVar3.setProjectName(MyApplication.b().m0);
                MyApplication.b().S.append(iKeyAt49, dVar3);
                dVar3.setTag(Integer.valueOf(dVar3.getIdComponent()));
                dVar3.f8753h.L(dVar3.f8752g);
                dVar3.f8753h.A(dVar3.getIdComponent());
                dVar3.f8754i.L(dVar3.f8752g);
                dVar3.f8754i.A(dVar3.getIdComponent());
                dVar3.bringToFront();
                dVar3.setOnLongClickListener(this.L0);
                dVar3.setOnClickListener(this.t0);
                dVar3.setNumScreen(a1);
                dVar3.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = dVar3.f8753h;
                    bVar.E(0);
                    break;
                }
                break;
            case "CustomEditNumber":
                ru.himik.nightscream.kascada.CustomComponents.i iVar = new ru.himik.nightscream.kascada.CustomComponents.i(this);
                X0.addView(iVar);
                int iKeyAt50 = MyApplication.b().L.size() == 0 ? 0 : MyApplication.b().L.keyAt(MyApplication.b().L.size() - 1) + 1;
                iVar.j(i2, i3, iKeyAt50, false);
                MyApplication.b().L.append(iKeyAt50, iVar);
                iVar.setTag(Integer.valueOf(iVar.getIdComponent()));
                iVar.f8813j.L(iVar.f8812i);
                iVar.f8813j.A(iVar.getIdComponent());
                iVar.setTextColor(-16777216);
                iVar.bringToFront();
                iVar.setOnLongClickListener(this.L0);
                iVar.setOnClickListener(this.t0);
                iVar.setNumScreen(a1);
                iVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                if (MyApplication.b().f9042j == 1) {
                    bVar = iVar.f8813j;
                    bVar.E(0);
                    break;
                }
                break;
            case "VarNameIn":
                odtemp = new VarNameIn(this);
                X0.addView(odtemp);
                int iKeyAt51 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt51, odtemp);
                odtemp.s(i2, i3, iKeyAt51, false);
                odtemp.setNumScreen(a1);
                odtemp.setOnLongClickListener(this.L0);
                odtemp.setOnClickListener(this.R0);
                ru.himik.nightscream.kascada.r.e0.o(this, odtemp);
                if (a1 == -1) {
                    odtemp.setRootNameMacro(this.W0.getName());
                    odtemp.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "VarOutInt":
                VarOutInt varOutInt = new VarOutInt(this);
                X0.addView(varOutInt);
                gVar3 = varOutInt;
                gVar = varOutInt;
                if (MyApplication.b().D.size() == 0) {
                    iKeyAt2 = 0;
                    gVar2 = gVar;
                } else {
                    iKeyAt2 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                    gVar2 = gVar3;
                }
                MyApplication.b().D.append(iKeyAt2, gVar2);
                gVar2.s(i2, i3, iKeyAt2, false);
                gVar2.setNumScreen(a1);
                view = gVar2;
                view.setOnLongClickListener(this.L0);
                view.setOnClickListener(this.R0);
                break;
            case "VarNameOut":
                VarNameOut varNameOut = new VarNameOut(this);
                X0.addView(varNameOut);
                int iKeyAt52 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt52, varNameOut);
                varNameOut.s(i2, i3, iKeyAt52, false);
                varNameOut.setNumScreen(a1);
                varNameOut.setOnLongClickListener(this.L0);
                varNameOut.setOnClickListener(this.R0);
                ru.himik.nightscream.kascada.r.e0.o(this, varNameOut);
                if (a1 == -1) {
                    varNameOut.setRootNameMacro(this.W0.getName());
                    varNameOut.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "MQTT_SUBSCRIBER":
                odtemp = new MQTT_SUBSCRIBER(this);
                X0.addView(odtemp);
                int iKeyAt53 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt53, odtemp);
                odtemp.s(i2, i3, iKeyAt53, false);
                odtemp.setNumScreen(a1);
                odtemp.setOnLongClickListener(this.L0);
                odtemp.setOnClickListener(this.R0);
                if (a1 == -1) {
                    odtemp.setRootNameMacro(this.W0.getName());
                    odtemp.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "Sunrise_GPS":
                odtemp = new Sunrise_GPS(this);
                X0.addView(odtemp);
                int iKeyAt54 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt54, odtemp);
                odtemp.s(i2, i3, iKeyAt54, false);
                odtemp.setNumScreen(a1);
                odtemp.setOnLongClickListener(this.L0);
                odtemp.setOnClickListener(this.R0);
                if (a1 == -1) {
                    odtemp.setRootNameMacro(this.W0.getName());
                    odtemp.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "CustomGateway":
                ru.himik.nightscream.kascada.CustomComponents.k kVar = new ru.himik.nightscream.kascada.CustomComponents.k(this);
                X0.addView(kVar);
                int iKeyAt55 = MyApplication.b().W.size() == 0 ? 0 : MyApplication.b().W.keyAt(MyApplication.b().W.size() - 1) + 1;
                kVar.b(i2, i3, iKeyAt55, false);
                MyApplication.b().W.append(iKeyAt55, kVar);
                kVar.setTag(Integer.valueOf(kVar.getIdComponent()));
                kVar.setTypeRequestSource((byte) 3);
                kVar.f8832g.A(kVar.getIdComponent());
                kVar.f8833h.L(kVar.f8831f);
                kVar.f8833h.A(kVar.getIdComponent());
                kVar.bringToFront();
                kVar.setOnLongClickListener(this.L0);
                kVar.setOnClickListener(this.t0);
                kVar.setNumScreen(a1);
                kVar.setTimeZ(System.currentTimeMillis() + 1471228928);
                break;
            case "FB_COMPARE_FLOAT":
                fb_arithmetic_int = new FB_COMPARE_FLOAT(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt56 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt56, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt56, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "MQTT_PUBLISHER":
                fb_arithmetic_int = new MQTT_PUBLISHER(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt57 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt57, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt57, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_AND":
                fb_arithmetic_int = new FB_AND(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt58 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt58, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt58, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_CTU":
                fb_array = new FB_CTU(this);
                X0.addView(fb_array);
                int iKeyAt59 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt59, fb_array);
                fb_array.j(i2, i3, iKeyAt59, false);
                fb_array.setNumScreen(a1);
                fb_array.setOnLongClickListener(this.L0);
                fb_array.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_array.setRootNameMacro(this.W0.getName());
                    fb_array.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_POW":
                fb_arithmetic_int = new FB_POW(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt60 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt60, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt60, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_SEL":
                fb_array = new FB_SEL(this);
                X0.addView(fb_array);
                int iKeyAt61 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt61, fb_array);
                fb_array.j(i2, i3, iKeyAt61, false);
                fb_array.setNumScreen(a1);
                fb_array.setOnLongClickListener(this.L0);
                fb_array.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_array.setRootNameMacro(this.W0.getName());
                    fb_array.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_XOR":
                fb_arithmetic_int = new FB_XOR(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt62 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt62, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt62, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
            case "FB_TRIGGER":
                fb_arithmetic_int = new FB_TRIGGER(this);
                X0.addView(fb_arithmetic_int);
                int iKeyAt63 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                MyApplication.b().D.append(iKeyAt63, fb_arithmetic_int);
                fb_arithmetic_int.j(i2, i3, iKeyAt63, false);
                fb_arithmetic_int.setNumScreen(a1);
                fb_arithmetic_int.setOnLongClickListener(this.L0);
                fb_arithmetic_int.setOnClickListener(this.R0);
                if (a1 == -1) {
                    fb_arithmetic_int.setRootNameMacro(this.W0.getName());
                    fb_arithmetic_int.setRootUniqueIdMacro(this.W0.c);
                    break;
                }
                break;
        }
        if (z2) {
            x0(false);
        }
        z0();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v336 */
    /* JADX WARN: Type inference failed for: r4v337, types: [boolean, byte] */
    /* JADX WARN: Type inference failed for: r4v368 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    private ru.himik.nightscream.kascada.CustomComponents.z m(int i2, String str, int i3, int i4, int i5, int i6, int i7, String str2, int i8, int i9, String str3) {
        boolean z2;
        int iKeyAt;
        String str4;
        boolean z3;
        int iKeyAt2;
        boolean z4;
        int iKeyAt3;
        String str5;
        boolean z5;
        int iKeyAt4;
        boolean z6;
        boolean z7;
        int iKeyAt5;
        String str6;
        boolean z8;
        int iKeyAt6;
        boolean z9;
        int iKeyAt7;
        boolean z10;
        int iKeyAt8;
        boolean z11;
        int iKeyAt9;
        boolean z12;
        int iKeyAt10;
        boolean z13;
        int iKeyAt11;
        boolean z14;
        int iKeyAt12;
        boolean z15;
        int iKeyAt13;
        boolean z16;
        int iKeyAt14;
        boolean z17;
        int iKeyAt15;
        boolean z18;
        int iKeyAt16;
        boolean z19;
        boolean z20;
        boolean z21;
        int iKeyAt17;
        boolean z22;
        int iKeyAt18;
        boolean z23;
        int iKeyAt19;
        ?? r4;
        int iKeyAt20;
        boolean z24;
        int iKeyAt21;
        boolean z25;
        int iKeyAt22;
        boolean z26;
        int iKeyAt23;
        boolean z27;
        int iKeyAt24;
        boolean z28;
        int iKeyAt25;
        boolean z29;
        int iKeyAt26;
        boolean z30;
        int iKeyAt27;
        boolean z31;
        int iKeyAt28;
        boolean z32;
        int iKeyAt29;
        boolean z33;
        int iKeyAt30;
        boolean z34;
        int iKeyAt31;
        boolean z35;
        int iKeyAt32;
        boolean z36;
        int iKeyAt33;
        boolean z37;
        int iKeyAt34;
        boolean z38;
        int iKeyAt35;
        boolean z39;
        int iKeyAt36;
        boolean z40;
        int iKeyAt37;
        boolean z41;
        int iKeyAt38;
        boolean z42;
        int iKeyAt39;
        boolean z43;
        int iKeyAt40;
        boolean z44;
        int iKeyAt41;
        boolean z45;
        int iKeyAt42;
        boolean z46;
        int iKeyAt43;
        boolean z47;
        int iKeyAt44;
        boolean z48;
        int iKeyAt45;
        boolean z49;
        int iKeyAt46;
        boolean z50;
        int iKeyAt47;
        boolean z51;
        int iKeyAt48;
        boolean z52;
        int iKeyAt49;
        boolean z53;
        int iKeyAt50;
        boolean z54;
        int iKeyAt51;
        boolean z55;
        int iKeyAt52;
        boolean z56;
        int iKeyAt53;
        boolean z57;
        int iKeyAt54;
        boolean z58;
        int iKeyAt55;
        boolean z59;
        int iKeyAt56;
        boolean z60;
        int iKeyAt57;
        boolean z61;
        int iKeyAt58;
        boolean z62;
        int iKeyAt59;
        String str7;
        boolean z63;
        int iKeyAt60;
        boolean z64;
        int iKeyAt61;
        boolean z65;
        int iKeyAt62;
        boolean z66;
        int iKeyAt63;
        boolean z67;
        int iKeyAt64;
        boolean z68;
        int iKeyAt65;
        if (i2 == 1) {
            ru.himik.nightscream.kascada.CustomComponents.y yVar = new ru.himik.nightscream.kascada.CustomComponents.y(this);
            X0.addView(yVar);
            if (MyApplication.b().F.size() == 0) {
                iKeyAt = 0;
                z2 = true;
            } else {
                z2 = true;
                iKeyAt = MyApplication.b().F.keyAt(MyApplication.b().F.size() - 1) + 1;
            }
            MyApplication.b().F.append(iKeyAt, yVar);
            yVar.setTag(Integer.valueOf(yVar.getIdComponent()));
            yVar.bringToFront();
            yVar.b(i5, i6, iKeyAt, z2);
            yVar.getLayoutParams().width = i3;
            yVar.getLayoutParams().height = i4;
            yVar.setX(i5);
            yVar.setY(i6);
            yVar.setText(str);
            yVar.setTextSize(0, i7);
            yVar.f8943g.L(yVar.f8942f);
            yVar.f8943g.A(yVar.getIdComponent());
            yVar.setTextColor(i8);
            yVar.setOnLongClickListener(this.L0);
            yVar.setOnClickListener(this.t0);
            try {
                JSONObject jSONObject = new JSONObject(str2);
                yVar.f8943g.E(jSONObject.getInt("posDeviceNetworkInList"));
                yVar.f8943g.v(jSONObject.getInt("addressRegister"));
                yVar.f8943g.t((byte) jSONObject.getInt("addressBit"));
                yVar.f8943g.L((byte) jSONObject.getInt("typeRequest"));
                str4 = " ";
            } catch (JSONException unused) {
                Context applicationContext = getApplicationContext();
                StringBuilder sb = new StringBuilder();
                sb.append(getResources().getString(R.string.error_load_component));
                str4 = r9;
                sb.append(str4);
                sb.append(yVar.c);
                Toast.makeText(applicationContext, sb.toString(), 0).show();
            }
            try {
                JSONObject jSONObject2 = new JSONObject(str3);
                yVar.setVisibleInWork(jSONObject2.getBoolean("visibleInWork"));
                yVar.setNumScreen(jSONObject2.getInt("numScreen"));
                yVar.setImageState(jSONObject2.getInt("imagePosition"));
                try {
                    yVar.setTimeZ(jSONObject2.getLong("timeZ"));
                } catch (Exception unused2) {
                }
            } catch (JSONException unused3) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + str4 + yVar.c, 0).show();
            }
            return yVar;
        }
        if (i2 == 2) {
            CustomLabel customLabel = new CustomLabel(this);
            X0.addView(customLabel);
            if (MyApplication.b().G.size() == 0) {
                z3 = true;
                iKeyAt2 = 0;
            } else {
                z3 = true;
                iKeyAt2 = MyApplication.b().G.keyAt(MyApplication.b().G.size() - 1) + 1;
            }
            MyApplication.b().G.append(iKeyAt2, customLabel);
            customLabel.setTag(Integer.valueOf(customLabel.getIdComponent()));
            customLabel.bringToFront();
            customLabel.o(i5, i6, iKeyAt2, z3);
            customLabel.getLayoutParams().width = i3;
            customLabel.getLayoutParams().height = i4;
            customLabel.setX(i5);
            customLabel.setY(i6);
            customLabel.setText(str);
            customLabel.setTextSize(0, i7);
            customLabel.setTextColor(i8);
            customLabel.setBackgroundColor_(i9);
            customLabel.setOnLongClickListener(this.L0);
            customLabel.setOnClickListener(this.t0);
            try {
                JSONObject jSONObject3 = new JSONObject(str3);
                customLabel.setNumScreen(jSONObject3.getInt("numScreen"));
                try {
                    customLabel.setAutoResizeText(jSONObject3.getBoolean("autoResizeText"));
                } catch (Exception unused4) {
                }
                try {
                    customLabel.setEnableFrameLabel(jSONObject3.getBoolean("enableFrameLabel"));
                } catch (Exception unused5) {
                }
                try {
                    customLabel.setTimeZ(jSONObject3.getLong("timeZ"));
                } catch (Exception unused6) {
                }
            } catch (JSONException unused7) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customLabel.f8673e, 0).show();
            }
            return customLabel;
        }
        switch (i2) {
            case 4:
                ru.himik.nightscream.kascada.CustomComponents.u uVar = new ru.himik.nightscream.kascada.CustomComponents.u(this);
                X0.addView(uVar);
                if (MyApplication.b().H.size() == 0) {
                    iKeyAt3 = 0;
                    z4 = true;
                } else {
                    z4 = true;
                    iKeyAt3 = MyApplication.b().H.keyAt(MyApplication.b().H.size() - 1) + 1;
                }
                MyApplication.b().H.append(iKeyAt3, uVar);
                uVar.setTag(Integer.valueOf(uVar.getIdComponent()));
                uVar.bringToFront();
                uVar.k(i5, i6, iKeyAt3, z4);
                uVar.getLayoutParams().width = i3;
                uVar.getLayoutParams().height = i4;
                uVar.setX(i5);
                uVar.setY(i6);
                uVar.setTextSize(0, i7);
                uVar.f8903k.L(uVar.f8901i);
                uVar.f8903k.A(uVar.getIdComponent());
                uVar.setTextColor(i8);
                uVar.setBackgroundColorReg(i9);
                uVar.setOnLongClickListener(this.L0);
                uVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject4 = new JSONObject(str2);
                    uVar.f8903k.E(jSONObject4.getInt("posDeviceNetworkInList"));
                    uVar.f8903k.v(jSONObject4.getInt("addressRegister"));
                    uVar.f8903k.L((byte) jSONObject4.getInt("typeRequest"));
                    str5 = " ";
                } catch (JSONException unused8) {
                    Context applicationContext2 = getApplicationContext();
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(getResources().getString(R.string.error_load_component));
                    str5 = r13;
                    sb2.append(str5);
                    sb2.append(uVar.f8897e);
                    Toast.makeText(applicationContext2, sb2.toString(), 0).show();
                }
                try {
                    JSONObject jSONObject5 = new JSONObject(str3);
                    try {
                        uVar.setType(jSONObject5.getInt("type"));
                        break;
                    } catch (JSONException unused9) {
                    }
                    uVar.setDigit(jSONObject5.getInt("digit"));
                    uVar.setDivisor(jSONObject5.getInt("divisor"));
                    uVar.setNumScreen(jSONObject5.getInt("numScreen"));
                    try {
                        uVar.setFontChange(jSONObject5.getBoolean("fontChange"));
                        break;
                    } catch (Exception unused10) {
                    }
                    try {
                        uVar.setEnableFrameRegister(jSONObject5.getBoolean("enableFrameRegister"));
                        break;
                    } catch (Exception unused11) {
                    }
                    try {
                        uVar.setTimeZ(jSONObject5.getLong("timeZ"));
                        break;
                    } catch (Exception unused12) {
                    }
                } catch (JSONException unused13) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + str5 + uVar.f8897e, 0).show();
                }
                return uVar;
            case 5:
                ru.himik.nightscream.kascada.CustomComponents.q qVar = new ru.himik.nightscream.kascada.CustomComponents.q(this);
                X0.addView(qVar);
                if (MyApplication.b().I.size() == 0) {
                    iKeyAt4 = 0;
                    z5 = true;
                } else {
                    z5 = true;
                    iKeyAt4 = MyApplication.b().I.keyAt(MyApplication.b().I.size() - 1) + 1;
                }
                MyApplication.b().I.append(iKeyAt4, qVar);
                qVar.setTag(Integer.valueOf(qVar.getIdComponent()));
                qVar.bringToFront();
                qVar.c(i5, i6, iKeyAt4, z5);
                qVar.setX(i5);
                qVar.setY(i6);
                qVar.getLayoutParams().width = i3;
                qVar.getLayoutParams().height = i4;
                qVar.f8865g.L(qVar.f8864f);
                qVar.f8865g.A(qVar.getIdComponent());
                qVar.setOnLongClickListener(this.L0);
                qVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject6 = new JSONObject(str2);
                    qVar.f8865g.E(jSONObject6.getInt("posDeviceNetworkInList"));
                    qVar.f8865g.v(jSONObject6.getInt("addressRegister"));
                    qVar.f8865g.t((byte) jSONObject6.getInt("addressBit"));
                    qVar.f8865g.L((byte) jSONObject6.getInt("typeRequest"));
                    break;
                } catch (JSONException unused14) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + qVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject7 = new JSONObject(str3);
                    try {
                        int i10 = jSONObject7.getInt("imagePosition");
                        try {
                            try {
                                if (i10 == 1) {
                                    z6 = false;
                                    qVar.d(true, false, "green");
                                } else if (i10 == 2) {
                                    z6 = false;
                                    qVar.d(true, false, "yellow");
                                } else {
                                    if (i10 != 3) {
                                        if (i10 == 4) {
                                            z6 = false;
                                            qVar.d(true, false, "blue");
                                        }
                                        qVar.K = i3;
                                        qVar.d(true, jSONObject7.getBoolean("isImageUserOn"), jSONObject7.getString("pathOrNameOn"));
                                        qVar.d(false, jSONObject7.getBoolean("isImageUserOff"), jSONObject7.getString("pathOrNameOff"));
                                        qVar.setTimeZ(jSONObject7.getLong("timeZ"));
                                        qVar.setNumScreen(jSONObject7.getInt("numScreen"));
                                        return qVar;
                                    }
                                    z6 = false;
                                    qVar.d(true, false, "red");
                                }
                                qVar.K = i3;
                                qVar.d(true, jSONObject7.getBoolean("isImageUserOn"), jSONObject7.getString("pathOrNameOn"));
                                qVar.d(false, jSONObject7.getBoolean("isImageUserOff"), jSONObject7.getString("pathOrNameOff"));
                                break;
                            } catch (Exception unused15) {
                            }
                            qVar.setTimeZ(jSONObject7.getLong("timeZ"));
                            break;
                        } catch (Exception unused16) {
                        }
                        qVar.d(z6, z6, "off");
                        break;
                    } catch (Exception unused17) {
                    }
                    qVar.setNumScreen(jSONObject7.getInt("numScreen"));
                    break;
                } catch (JSONException unused18) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + qVar.c, 0).show();
                }
                return qVar;
            case 6:
                ru.himik.nightscream.kascada.CustomComponents.e eVar = new ru.himik.nightscream.kascada.CustomComponents.e(this);
                X0.addView(eVar);
                if (MyApplication.b().J.size() == 0) {
                    iKeyAt5 = 0;
                    z7 = true;
                } else {
                    z7 = true;
                    iKeyAt5 = MyApplication.b().J.keyAt(MyApplication.b().J.size() - 1) + 1;
                }
                MyApplication.b().J.append(iKeyAt5, eVar);
                eVar.setTag(Integer.valueOf(eVar.getIdComponent()));
                eVar.bringToFront();
                eVar.j(i5, i6, iKeyAt5, z7);
                eVar.getLayoutParams().width = i3;
                eVar.getLayoutParams().height = i4;
                eVar.setX(i5);
                eVar.setY(i6);
                eVar.setText(str);
                eVar.setTextSize(0, i7);
                eVar.f8769i.L(eVar.f8768h);
                eVar.f8769i.A(eVar.getIdComponent());
                eVar.setTextColor(i8);
                eVar.setOnLongClickListener(this.L0);
                eVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject8 = new JSONObject(str2);
                    eVar.f8769i.E(jSONObject8.getInt("posDeviceNetworkInList"));
                    eVar.f8769i.v(jSONObject8.getInt("addressRegister"));
                    eVar.f8769i.t((byte) jSONObject8.getInt("addressBit"));
                    eVar.f8769i.L((byte) jSONObject8.getInt("typeRequest"));
                    str6 = " ";
                } catch (JSONException unused19) {
                    Context applicationContext3 = getApplicationContext();
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(getResources().getString(R.string.error_load_component));
                    str6 = r1;
                    sb3.append(str6);
                    sb3.append(eVar.c);
                    Toast.makeText(applicationContext3, sb3.toString(), 0).show();
                }
                try {
                    JSONObject jSONObject9 = new JSONObject(str3);
                    eVar.setVisibleInWork(jSONObject9.getBoolean("visibleInWork"));
                    eVar.setNumScreen(jSONObject9.getInt("numScreen"));
                    eVar.setImageState(jSONObject9.getInt("imagePosition"));
                    try {
                        eVar.setMode(jSONObject9.getInt("mode"));
                        eVar.setChangeScreen(jSONObject9.getInt("changeScreen"));
                        eVar.setTypeRegister(jSONObject9.getInt("typeRegister"));
                        eVar.setConstantRegister(jSONObject9.getInt("constantRegister"));
                        eVar.setConstant(jSONObject9.getString("constant"));
                        break;
                    } catch (Exception unused20) {
                    }
                    try {
                        eVar.setAutoResizeText(jSONObject9.getBoolean("autoResizeText"));
                        break;
                    } catch (Exception unused21) {
                    }
                    try {
                        eVar.setTimeZ(jSONObject9.getLong("timeZ"));
                        break;
                    } catch (Exception unused22) {
                    }
                } catch (JSONException unused23) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + str6 + eVar.c, 0).show();
                }
                return eVar;
            case 7:
                CustomDynText customDynText = new CustomDynText(this);
                X0.addView(customDynText);
                if (MyApplication.b().K.size() == 0) {
                    iKeyAt6 = 0;
                    z8 = true;
                } else {
                    z8 = true;
                    iKeyAt6 = MyApplication.b().K.keyAt(MyApplication.b().K.size() - 1) + 1;
                }
                MyApplication.b().K.append(iKeyAt6, customDynText);
                customDynText.setTag(Integer.valueOf(customDynText.getIdComponent()));
                customDynText.bringToFront();
                customDynText.s(i5, i6, iKeyAt6, z8);
                customDynText.getLayoutParams().width = i3;
                customDynText.getLayoutParams().height = i4;
                customDynText.setX(i5);
                customDynText.setY(i6);
                customDynText.f8667i.L(customDynText.f8666h);
                customDynText.f8667i.A(customDynText.getIdComponent());
                customDynText.setOnLongClickListener(this.L0);
                customDynText.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject10 = new JSONObject(str2);
                    customDynText.f8667i.E(jSONObject10.getInt("posDeviceNetworkInList"));
                    customDynText.f8667i.v(jSONObject10.getInt("addressRegister"));
                    customDynText.f8667i.t((byte) jSONObject10.getInt("addressBit"));
                    break;
                } catch (JSONException unused24) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customDynText.f8663e, 0).show();
                }
                try {
                    JSONObject jSONObject11 = new JSONObject(str3);
                    customDynText.setColorText(jSONObject11.getInt("colorText"));
                    customDynText.w(0, jSONObject11.getString("text0"));
                    customDynText.w(1, jSONObject11.getString("text1"));
                    customDynText.w(2, jSONObject11.getString("text2"));
                    customDynText.w(3, jSONObject11.getString("text3"));
                    customDynText.w(4, jSONObject11.getString("text4"));
                    customDynText.w(5, jSONObject11.getString("text5"));
                    customDynText.w(6, jSONObject11.getString("text6"));
                    customDynText.w(7, jSONObject11.getString("text7"));
                    try {
                        customDynText.w(8, jSONObject11.getString("text8"));
                        customDynText.w(9, jSONObject11.getString("text9"));
                        customDynText.w(10, jSONObject11.getString("text10"));
                        customDynText.w(11, jSONObject11.getString("text11"));
                        customDynText.w(12, jSONObject11.getString("text12"));
                        customDynText.w(13, jSONObject11.getString("text13"));
                        customDynText.w(14, jSONObject11.getString("text14"));
                        customDynText.w(15, jSONObject11.getString("text15"));
                        break;
                    } catch (Exception unused25) {
                    }
                    customDynText.v(0, jSONObject11.getInt("colorBackground0"));
                    customDynText.v(1, jSONObject11.getInt("colorBackground1"));
                    customDynText.v(2, jSONObject11.getInt("colorBackground2"));
                    customDynText.v(3, jSONObject11.getInt("colorBackground3"));
                    customDynText.v(4, jSONObject11.getInt("colorBackground4"));
                    customDynText.v(5, jSONObject11.getInt("colorBackground5"));
                    customDynText.v(6, jSONObject11.getInt("colorBackground6"));
                    customDynText.v(7, jSONObject11.getInt("colorBackground7"));
                    try {
                        customDynText.v(8, jSONObject11.getInt("colorBackground8"));
                        customDynText.v(9, jSONObject11.getInt("colorBackground9"));
                        customDynText.v(10, jSONObject11.getInt("colorBackground10"));
                        customDynText.v(11, jSONObject11.getInt("colorBackground11"));
                        customDynText.v(12, jSONObject11.getInt("colorBackground12"));
                        customDynText.v(13, jSONObject11.getInt("colorBackground13"));
                        customDynText.v(14, jSONObject11.getInt("colorBackground14"));
                        customDynText.v(15, jSONObject11.getInt("colorBackground15"));
                        break;
                    } catch (Exception unused26) {
                    }
                    try {
                        customDynText.setTextSize(jSONObject11.getInt("sizeText"));
                        customDynText.setAutoResizeText(jSONObject11.getBoolean("autoResizeText"));
                        break;
                    } catch (Exception unused27) {
                    }
                    customDynText.setNumScreen(jSONObject11.getInt("numScreen"));
                    try {
                        customDynText.setTypeCommand(jSONObject11.getInt("typeCommand"));
                        break;
                    } catch (Exception unused28) {
                    }
                    try {
                        customDynText.setEnableFrameDynText(jSONObject11.getBoolean("enableFrameDynText"));
                        break;
                    } catch (Exception unused29) {
                    }
                    try {
                        customDynText.setTimeZ(jSONObject11.getLong("timeZ"));
                        break;
                    } catch (Exception unused30) {
                    }
                } catch (JSONException unused31) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customDynText.f8663e, 0).show();
                }
                return customDynText;
            case 8:
                ru.himik.nightscream.kascada.CustomComponents.i iVar = new ru.himik.nightscream.kascada.CustomComponents.i(this);
                X0.addView(iVar);
                if (MyApplication.b().L.size() == 0) {
                    z9 = true;
                    iKeyAt7 = 0;
                } else {
                    z9 = true;
                    iKeyAt7 = MyApplication.b().L.keyAt(MyApplication.b().L.size() - 1) + 1;
                }
                MyApplication.b().L.append(iKeyAt7, iVar);
                iVar.setTag(Integer.valueOf(iVar.getIdComponent()));
                iVar.bringToFront();
                iVar.j(i5, i6, iKeyAt7, z9);
                iVar.getLayoutParams().width = i3;
                iVar.getLayoutParams().height = i4;
                iVar.setX(i5);
                iVar.setY(i6);
                iVar.f(str);
                iVar.setTextColor(i8);
                iVar.setBackgroundColorEditNumber(i9);
                iVar.f8813j.L(iVar.f8812i);
                iVar.f8813j.A(iVar.getIdComponent());
                iVar.setOnLongClickListener(this.L0);
                iVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject12 = new JSONObject(str2);
                    iVar.f8813j.E(jSONObject12.getInt("posDeviceNetworkInList"));
                    iVar.setMinValue(Float.parseFloat(jSONObject12.getString("min")));
                    iVar.setMaxValue(Float.parseFloat(jSONObject12.getString("max")));
                    iVar.f8813j.v(jSONObject12.getInt("addressRegister"));
                    try {
                        iVar.setPassword(jSONObject12.getString("password"));
                        break;
                    } catch (Exception unused32) {
                    }
                } catch (JSONException unused33) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + iVar.f8808e, 0).show();
                }
                try {
                    JSONObject jSONObject13 = new JSONObject(str3);
                    iVar.setNumScreen(jSONObject13.getInt("numScreen"));
                    try {
                        iVar.setType(jSONObject13.getInt("type"));
                        iVar.setTypeInt(jSONObject13.getInt("typeInt"));
                        iVar.setCountNumAfterPointEditNumber(jSONObject13.getInt("countNumAfterPointEditNumber"));
                        break;
                    } catch (JSONException unused34) {
                    }
                    try {
                        iVar.setFontChange(jSONObject13.getBoolean("fontChange"));
                        break;
                    } catch (Exception unused35) {
                    }
                    try {
                        iVar.setEnableFrameEditNumber(jSONObject13.getBoolean("enableFrameEditNumber"));
                        break;
                    } catch (Exception unused36) {
                    }
                    try {
                        iVar.setTimeZ(jSONObject13.getLong("timeZ"));
                        break;
                    } catch (Exception unused37) {
                    }
                } catch (JSONException unused38) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + iVar.f8808e, 0).show();
                }
                return iVar;
            case 9:
                ru.himik.nightscream.kascada.CustomComponents.c cVar = new ru.himik.nightscream.kascada.CustomComponents.c(this);
                X0.addView(cVar);
                if (MyApplication.b().M.size() == 0) {
                    iKeyAt8 = 0;
                    z10 = true;
                } else {
                    z10 = true;
                    iKeyAt8 = MyApplication.b().M.keyAt(MyApplication.b().M.size() - 1) + 1;
                }
                MyApplication.b().M.append(iKeyAt8, cVar);
                cVar.setTag(Integer.valueOf(cVar.getIdComponent()));
                cVar.bringToFront();
                cVar.a(i5, i6, iKeyAt8, z10);
                cVar.setX(i5);
                cVar.setY(i6);
                cVar.f8742h.L(cVar.f8741g);
                cVar.f8742h.A(cVar.getIdComponent());
                cVar.setOnClickListener(this.t0);
                cVar.setOnLongClickListener(this.L0);
                try {
                    JSONObject jSONObject14 = new JSONObject(str2);
                    cVar.f8742h.E(jSONObject14.getInt("posDeviceNetworkInList"));
                    cVar.f8742h.v(jSONObject14.getInt("addressRegister"));
                    cVar.f8742h.t((byte) jSONObject14.getInt("addressBit"));
                    cVar.f8742h.L((byte) jSONObject14.getInt("typeRequest"));
                    break;
                } catch (JSONException unused39) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + cVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject15 = new JSONObject(str3);
                    cVar.setPosSound(jSONObject15.getInt("posSound"));
                    cVar.setNumScreen(jSONObject15.getInt("numScreen"));
                    try {
                        cVar.setTimeZ(jSONObject15.getLong("timeZ"));
                        break;
                    } catch (Exception unused40) {
                    }
                } catch (JSONException unused41) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + cVar.c, 0).show();
                }
                return cVar;
            case 10:
                ru.himik.nightscream.kascada.CustomComponents.w wVar = new ru.himik.nightscream.kascada.CustomComponents.w(this);
                X0.addView(wVar);
                if (MyApplication.b().N.size() == 0) {
                    iKeyAt9 = 0;
                    z11 = true;
                } else {
                    z11 = true;
                    iKeyAt9 = MyApplication.b().N.keyAt(MyApplication.b().N.size() - 1) + 1;
                }
                MyApplication.b().N.append(iKeyAt9, wVar);
                wVar.setTag(Integer.valueOf(wVar.getIdComponent()));
                wVar.bringToFront();
                wVar.a(i5, i6, iKeyAt9, z11);
                wVar.setX(i5);
                wVar.setY(i6);
                wVar.f8921g.L(wVar.f8920f);
                wVar.f8921g.A(wVar.getIdComponent());
                wVar.setOnClickListener(this.t0);
                wVar.setOnLongClickListener(this.L0);
                try {
                    JSONObject jSONObject16 = new JSONObject(str2);
                    wVar.f8921g.E(jSONObject16.getInt("posDeviceNetworkInList"));
                    wVar.f8921g.v(jSONObject16.getInt("addressRegister"));
                    wVar.f8921g.t((byte) jSONObject16.getInt("addressBit"));
                    wVar.f8921g.L((byte) jSONObject16.getInt("typeRequest"));
                    break;
                } catch (JSONException unused42) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + wVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject17 = new JSONObject(str3);
                    wVar.setNumScreen(jSONObject17.getInt("numScreen"));
                    wVar.setPhone(jSONObject17.getString("phone"));
                    wVar.setMessage(jSONObject17.getString("message"));
                    wVar.setOption(jSONObject17.getBoolean("option"));
                    wVar.setOptionRegister(jSONObject17.getInt("optionRegister"));
                    try {
                        wVar.setOptionCountRegister(jSONObject17.getInt("optionCountRegister"));
                        break;
                    } catch (Exception unused43) {
                    }
                    try {
                        wVar.setTimeZ(jSONObject17.getLong("timeZ"));
                        break;
                    } catch (Exception unused44) {
                    }
                } catch (JSONException unused45) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + wVar.c, 0).show();
                }
                return wVar;
            case 11:
                ru.himik.nightscream.kascada.CustomComponents.r rVar = new ru.himik.nightscream.kascada.CustomComponents.r(this, null, android.R.attr.progressBarStyleHorizontal);
                X0.addView(rVar);
                if (MyApplication.b().O.size() == 0) {
                    iKeyAt10 = 0;
                    z12 = true;
                } else {
                    z12 = true;
                    iKeyAt10 = MyApplication.b().O.keyAt(MyApplication.b().O.size() - 1) + 1;
                }
                MyApplication.b().O.append(iKeyAt10, rVar);
                rVar.setTag(Integer.valueOf(rVar.getIdComponent()));
                rVar.bringToFront();
                rVar.b(i5, i6, iKeyAt10, z12);
                rVar.getLayoutParams().width = i3;
                rVar.getLayoutParams().height = i4;
                rVar.setX(i5);
                rVar.setY(i6);
                rVar.f8874e.A(rVar.getIdComponent());
                rVar.setOnLongClickListener(this.L0);
                rVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject18 = new JSONObject(str2);
                    rVar.f8874e.E(jSONObject18.getInt("posDeviceNetworkInList"));
                    rVar.f8874e.v(jSONObject18.getInt("addressRegister"));
                    rVar.f8874e.L((byte) jSONObject18.getInt("typeRequest"));
                    break;
                } catch (JSONException unused46) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + rVar.a, 0).show();
                }
                try {
                    JSONObject jSONObject19 = new JSONObject(str3);
                    rVar.setNumScreen(jSONObject19.getInt("numScreen"));
                    rVar.setShowText(jSONObject19.getBoolean("showText"));
                    rVar.setSizeText(jSONObject19.getInt("sizeText"));
                    rVar.setColorText(jSONObject19.getInt("colorText"));
                    rVar.setShowScale(jSONObject19.getBoolean("showScale"));
                    rVar.setColorProgress(jSONObject19.getInt("colorProgress"));
                    rVar.setColorBackground(jSONObject19.getInt("colorBackground"));
                    rVar.setValueMax(jSONObject19.getInt("max"));
                    try {
                        rVar.setValueMin(jSONObject19.getInt("min"));
                    } catch (JSONException unused47) {
                        rVar.setValueMin(0);
                    }
                    try {
                        rVar.setTimeZ(jSONObject19.getLong("timeZ"));
                        break;
                    } catch (Exception unused48) {
                    }
                    break;
                } catch (JSONException unused49) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + rVar.a, 0).show();
                }
                rVar.e();
                return rVar;
            case 12:
                ru.himik.nightscream.kascada.CustomComponents.g gVar = new ru.himik.nightscream.kascada.CustomComponents.g(this);
                X0.addView(gVar);
                if (MyApplication.b().P.size() == 0) {
                    iKeyAt11 = 0;
                    z13 = true;
                } else {
                    z13 = true;
                    iKeyAt11 = MyApplication.b().P.keyAt(MyApplication.b().P.size() - 1) + 1;
                }
                MyApplication.b().P.append(iKeyAt11, gVar);
                gVar.setTag(Integer.valueOf(gVar.getIdComponent()));
                gVar.bringToFront();
                gVar.h(i5, i6, iKeyAt11, z13);
                gVar.getLayoutParams().width = i3;
                gVar.getLayoutParams().height = i4;
                gVar.setX(i5);
                gVar.setY(i6);
                gVar.I.A(gVar.getIdComponent());
                gVar.setOnLongClickListener(this.L0);
                gVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject20 = new JSONObject(str2);
                    gVar.I.E(jSONObject20.getInt("posDeviceNetworkInList"));
                    gVar.I.v(jSONObject20.getInt("addressRegister"));
                    gVar.I.L((byte) jSONObject20.getInt("typeRequest"));
                    break;
                } catch (JSONException unused50) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + gVar.E, 0).show();
                }
                try {
                    JSONObject jSONObject21 = new JSONObject(str3);
                    gVar.setNumScreen(jSONObject21.getInt("numScreen"));
                    gVar.setShowText(jSONObject21.getBoolean("showText"));
                    gVar.setLabelTextSize(jSONObject21.getInt("sizeText"));
                    gVar.setColorText(jSONObject21.getInt("colorText"));
                    gVar.setMaxSpeed(jSONObject21.getInt("max"));
                    gVar.setInColor(jSONObject21.getInt("inColor"));
                    gVar.setOutColor(jSONObject21.getInt("outColor"));
                    gVar.setCenterColor(jSONObject21.getInt("centerColor"));
                    gVar.j(jSONObject21.getInt("firstColorPoint"), jSONObject21.getInt("secondColorPoint"));
                    try {
                        gVar.setTimeZ(jSONObject21.getLong("timeZ"));
                        break;
                    } catch (Exception unused51) {
                    }
                } catch (JSONException unused52) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + gVar.E, 0).show();
                }
                return gVar;
            case 13:
                ru.himik.nightscream.kascada.CustomComponents.v vVar = new ru.himik.nightscream.kascada.CustomComponents.v(this);
                X0.addView(vVar);
                if (MyApplication.b().Q.size() == 0) {
                    z14 = true;
                    iKeyAt12 = 0;
                } else {
                    z14 = true;
                    iKeyAt12 = MyApplication.b().Q.keyAt(MyApplication.b().Q.size() - 1) + 1;
                }
                MyApplication.b().Q.append(iKeyAt12, vVar);
                vVar.setTag(Integer.valueOf(vVar.getIdComponent()));
                vVar.bringToFront();
                vVar.f(i5, i6, iKeyAt12, z14);
                vVar.getLayoutParams().width = i3;
                vVar.getLayoutParams().height = i4;
                vVar.setX(i5);
                vVar.setY(i6);
                vVar.f8909f.A(vVar.getIdComponent());
                vVar.setOnLongSeekBarClick(this.H0);
                vVar.setOnTouchListener(this.G0);
                vVar.setOnSeekBarChangeListener(this.F0);
                try {
                    JSONObject jSONObject22 = new JSONObject(str2);
                    vVar.f8909f.E(jSONObject22.getInt("posDeviceNetworkInList"));
                    vVar.f8909f.v(jSONObject22.getInt("addressRegister"));
                    vVar.f8909f.L((byte) jSONObject22.getInt("typeRequest"));
                    break;
                } catch (JSONException unused53) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + vVar.b, 0).show();
                }
                try {
                    JSONObject jSONObject23 = new JSONObject(str3);
                    vVar.setNumScreen(jSONObject23.getInt("numScreen"));
                    vVar.setColorText(jSONObject23.getInt("colorText"));
                    vVar.setMax(jSONObject23.getInt("max"));
                    vVar.setColorProgress(jSONObject23.getInt("colorProgress"));
                    vVar.setColorBackground(jSONObject23.getInt("colorBackground"));
                    vVar.k(jSONObject23.getBoolean("isTurn"), i3, i4, true);
                    try {
                        vVar.setTimeZ(jSONObject23.getLong("timeZ"));
                        break;
                    } catch (Exception unused54) {
                    }
                } catch (JSONException unused55) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + vVar.b, 0).show();
                }
                vVar.l();
                return vVar;
            case 14:
                n.a.f.d dVar = new n.a.f.d();
                n.a.g.d dVar2 = new n.a.g.d();
                ru.himik.nightscream.kascada.CustomComponents.o oVar = new ru.himik.nightscream.kascada.CustomComponents.o(this, new n.a.e.g(dVar, dVar2));
                oVar.F = dVar;
                oVar.G = dVar2;
                X0.addView(oVar);
                if (MyApplication.b().R.size() == 0) {
                    iKeyAt13 = 0;
                    z15 = true;
                } else {
                    z15 = true;
                    iKeyAt13 = MyApplication.b().R.keyAt(MyApplication.b().R.size() - 1) + 1;
                }
                MyApplication.b().R.append(iKeyAt13, oVar);
                oVar.setTag(Integer.valueOf(oVar.getIdComponent()));
                oVar.bringToFront();
                oVar.m(i5, i6, iKeyAt13, z15);
                oVar.getLayoutParams().width = i3;
                oVar.getLayoutParams().height = i4;
                oVar.setX(i5);
                oVar.setY(i6);
                oVar.T.A(oVar.getIdComponent());
                oVar.setOnLongGraphClick(this.I0);
                oVar.setOnTouchListener(this.J0);
                try {
                    JSONObject jSONObject24 = new JSONObject(str2);
                    oVar.T.E(jSONObject24.getInt("posDeviceNetworkInList"));
                    oVar.T.v(jSONObject24.getInt("addressRegister"));
                    oVar.T.L((byte) jSONObject24.getInt("typeRequest"));
                    break;
                } catch (JSONException unused56) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + oVar.P, 0).show();
                }
                try {
                    JSONObject jSONObject25 = new JSONObject(str3);
                    oVar.setNumScreen(jSONObject25.getInt("numScreen"));
                    oVar.setSecondPeriod(jSONObject25.getInt("secondPeriod"));
                    oVar.setCountPoint(jSONObject25.getInt("countPoint"));
                    oVar.setColorBackground_(jSONObject25.getInt("colorBackground"));
                    try {
                        oVar.setType(jSONObject25.getInt("typeGraph"));
                        break;
                    } catch (Exception unused57) {
                    }
                    try {
                        oVar.setTimeZ(jSONObject25.getLong("timeZ"));
                        break;
                    } catch (Exception unused58) {
                    }
                    try {
                        oVar.setNameSeries1(jSONObject25.getString("nameSeries1"));
                        oVar.setNameSeries2(jSONObject25.getString("nameSeries2"));
                        oVar.setNameSeries3(jSONObject25.getString("nameSeries3"));
                        oVar.setNameSeries4(jSONObject25.getString("nameSeries4"));
                        oVar.setCountGraphChannel(jSONObject25.getInt("countGraphChannel"));
                        break;
                    } catch (Exception unused59) {
                    }
                } catch (JSONException unused60) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + oVar.P, 0).show();
                }
                return oVar;
            case 15:
                ru.himik.nightscream.kascada.CustomComponents.d dVar3 = new ru.himik.nightscream.kascada.CustomComponents.d(this);
                X0.addView(dVar3);
                if (MyApplication.b().S.size() == 0) {
                    iKeyAt14 = 0;
                    z16 = true;
                } else {
                    z16 = true;
                    iKeyAt14 = MyApplication.b().S.keyAt(MyApplication.b().S.size() - 1) + 1;
                }
                MyApplication.b().S.append(iKeyAt14, dVar3);
                dVar3.setTag(Integer.valueOf(dVar3.getIdComponent()));
                dVar3.bringToFront();
                dVar3.g(i5, i6, iKeyAt14, z16);
                dVar3.setProjectName(MyApplication.b().m0);
                dVar3.setX(i5);
                dVar3.setY(i6);
                dVar3.f8753h.A(dVar3.getIdComponent());
                dVar3.setOnLongClickListener(this.L0);
                dVar3.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject26 = new JSONObject(str2);
                    dVar3.f8753h.E(jSONObject26.getInt("posDeviceNetworkInList"));
                    dVar3.f8753h.v(jSONObject26.getInt("addressRegister"));
                    dVar3.f8753h.t((byte) jSONObject26.getInt("addressBit"));
                    dVar3.f8753h.L((byte) jSONObject26.getInt("typeRequest"));
                    try {
                        dVar3.f8754i.E(jSONObject26.getInt("posDeviceNetworkInList_triggerData"));
                        dVar3.f8754i.v(jSONObject26.getInt("addressRegister_triggerData"));
                        dVar3.f8754i.t((byte) jSONObject26.getInt("addressBit_triggerData"));
                        dVar3.f8754i.L((byte) jSONObject26.getInt("typeRequest_triggerData"));
                        break;
                    } catch (Exception unused61) {
                    }
                } catch (JSONException unused62) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + dVar3.f8749d, 0).show();
                }
                try {
                    JSONObject jSONObject27 = new JSONObject(str3);
                    dVar3.setNumScreen(jSONObject27.getInt("numScreen"));
                    dVar3.setFileName(jSONObject27.getString("fileName"));
                    dVar3.setTypeRecord(jSONObject27.getString("typeRecord"));
                    dVar3.setCountChannel(jSONObject27.getInt("countChannel"));
                    dVar3.setRegisterArchive(jSONObject27.getInt("registerArchive"));
                    try {
                        dVar3.setEmailLogin(jSONObject27.getString("emailLogin"));
                        dVar3.setEmailPassword(jSONObject27.getString("emailPassword"));
                        dVar3.setEmailTo(jSONObject27.getString("emailTo"));
                        dVar3.setRegSendEmail(jSONObject27.getInt("regSendEmail"));
                        dVar3.setBitSendEmail(jSONObject27.getInt("bitSendEmail"));
                        dVar3.setResetArchive(jSONObject27.getBoolean("isResetArchive"));
                        dVar3.setRegResetArchive(jSONObject27.getInt("regResetArchive"));
                        dVar3.setBitResetArchive(jSONObject27.getInt("bitResetArchive"));
                        break;
                    } catch (Exception unused63) {
                    }
                    try {
                        dVar3.setOptionChannel(jSONObject27.getBoolean("optionChannel"));
                        dVar3.setTypeRecordOptionChannel(jSONObject27.getString("typeRecordOptionChannel"));
                        dVar3.setRegArchiveOptionalChannel(jSONObject27.getInt("regArchiveOptionalChannel"));
                        dVar3.setCountArchiveOptionalChannelASCII(jSONObject27.getInt("countArchiveOptionalChannelASCII"));
                        break;
                    } catch (Exception unused64) {
                    }
                    try {
                        dVar3.setSendToCloudArchive(jSONObject27.getBoolean("isSendToCloudArchive"));
                        dVar3.setRegSendToCloudArchive(jSONObject27.getInt("regSendToCloudArchive"));
                        dVar3.setBitSendToCloudArchive(jSONObject27.getInt("bitSendToCloudArchive"));
                        break;
                    } catch (Exception unused65) {
                    }
                    try {
                        dVar3.setTimeZ(jSONObject27.getLong("timeZ"));
                        break;
                    } catch (Exception unused66) {
                    }
                } catch (JSONException unused67) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + dVar3.f8749d, 0).show();
                }
                return dVar3;
            case 16:
                ru.himik.nightscream.kascada.CustomComponents.n nVar = new ru.himik.nightscream.kascada.CustomComponents.n(this);
                X0.addView(nVar);
                if (MyApplication.b().T.size() == 0) {
                    iKeyAt15 = 0;
                    z17 = true;
                } else {
                    z17 = true;
                    iKeyAt15 = MyApplication.b().T.keyAt(MyApplication.b().T.size() - 1) + 1;
                }
                MyApplication.b().T.append(iKeyAt15, nVar);
                nVar.bringToFront();
                nVar.d(i5, i6, iKeyAt15, z17);
                nVar.setX(i5);
                nVar.setY(i6);
                nVar.getLayoutParams().width = i3;
                nVar.getLayoutParams().height = i4;
                nVar.f8854g.A(nVar.getIdComponent());
                nVar.setOnLongClickListener(this.L0);
                nVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject28 = new JSONObject(str2);
                    nVar.f8854g.E(jSONObject28.getInt("posDeviceNetworkInList"));
                    nVar.f8854g.v(jSONObject28.getInt("addressRegister"));
                    nVar.f8854g.t((byte) jSONObject28.getInt("addressBit"));
                    nVar.f8854g.L((byte) jSONObject28.getInt("typeRequest"));
                    break;
                } catch (JSONException unused68) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + nVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject29 = new JSONObject(str3);
                    nVar.setNumScreen(jSONObject29.getInt("numScreen"));
                    nVar.setPathGif(jSONObject29.getString("pathGif"));
                    try {
                        nVar.setTimeZ(jSONObject29.getLong("timeZ"));
                        break;
                    } catch (Exception unused69) {
                    }
                } catch (JSONException unused70) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + nVar.c, 0).show();
                }
                return nVar;
            case 17:
                ru.himik.nightscream.kascada.CustomComponents.h hVar = new ru.himik.nightscream.kascada.CustomComponents.h(this);
                X0.addView(hVar);
                if (MyApplication.b().U.size() == 0) {
                    iKeyAt16 = 0;
                    z18 = true;
                } else {
                    z18 = true;
                    iKeyAt16 = MyApplication.b().U.keyAt(MyApplication.b().U.size() - 1) + 1;
                }
                MyApplication.b().U.append(iKeyAt16, hVar);
                hVar.bringToFront();
                hVar.d(i5, i6, iKeyAt16, z18);
                hVar.setX(i5);
                hVar.setY(i6);
                hVar.getLayoutParams().width = i3;
                hVar.getLayoutParams().height = i4;
                hVar.f8798e.A(hVar.getIdComponent());
                hVar.setOnLongClickListener(this.L0);
                hVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject30 = new JSONObject(str2);
                    hVar.f8798e.E(jSONObject30.getInt("posDeviceNetworkInList"));
                    hVar.f8798e.v(jSONObject30.getInt("addressRegister"));
                    hVar.f8798e.t((byte) jSONObject30.getInt("addressBit"));
                    hVar.f8798e.L((byte) jSONObject30.getInt("typeRequest"));
                    break;
                } catch (JSONException unused71) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + hVar.a, 0).show();
                }
                try {
                    JSONObject jSONObject31 = new JSONObject(str3);
                    hVar.setNumScreen(jSONObject31.getInt("numScreen"));
                    hVar.e(jSONObject31.getString("pathPic_0"), 0);
                    hVar.e(jSONObject31.getString("pathPic_1"), 1);
                    hVar.e(jSONObject31.getString("pathPic_2"), 2);
                    hVar.e(jSONObject31.getString("pathPic_3"), 3);
                    hVar.e(jSONObject31.getString("pathPic_4"), 4);
                    hVar.e(jSONObject31.getString("pathPic_5"), 5);
                    hVar.e(jSONObject31.getString("pathPic_6"), 6);
                    hVar.e(jSONObject31.getString("pathPic_7"), 7);
                    try {
                        hVar.e(jSONObject31.getString("pathPic_8"), 8);
                        hVar.e(jSONObject31.getString("pathPic_9"), 9);
                        hVar.e(jSONObject31.getString("pathPic_10"), 10);
                        hVar.e(jSONObject31.getString("pathPic_11"), 11);
                        hVar.e(jSONObject31.getString("pathPic_12"), 12);
                        hVar.e(jSONObject31.getString("pathPic_13"), 13);
                        hVar.e(jSONObject31.getString("pathPic_14"), 14);
                        hVar.e(jSONObject31.getString("pathPic_15"), 15);
                        break;
                    } catch (Exception unused72) {
                    }
                    try {
                        hVar.setTypeCommand(jSONObject31.getInt("typeCommand"));
                        break;
                    } catch (Exception unused73) {
                    }
                    try {
                        hVar.setTimeZ(jSONObject31.getLong("timeZ"));
                        break;
                    } catch (Exception unused74) {
                    }
                    try {
                        hVar.f(jSONObject31.getInt("regTouchX"), jSONObject31.getInt("regTouchY"));
                        break;
                    } catch (Exception unused75) {
                    }
                    z19 = false;
                } catch (JSONException unused76) {
                    z19 = false;
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + hVar.a, 0).show();
                }
                hVar.b(z19);
                return hVar;
            case 18:
                int iKeyAt66 = 0;
                ru.himik.nightscream.kascada.CustomComponents.x xVar = new ru.himik.nightscream.kascada.CustomComponents.x(this);
                X0.addView(xVar);
                if (MyApplication.b().V.size() == 0) {
                    z20 = true;
                } else {
                    z20 = true;
                    iKeyAt66 = MyApplication.b().V.keyAt(MyApplication.b().V.size() - 1) + 1;
                }
                MyApplication.b().V.append(iKeyAt66, xVar);
                xVar.setTag(Integer.valueOf(xVar.getIdComponent()));
                xVar.bringToFront();
                xVar.a(i5, i6, iKeyAt66, z20);
                xVar.setX(i5);
                xVar.setY(i6);
                xVar.f8932g.A(xVar.getIdComponent());
                xVar.setOnLongClickListener(this.L0);
                xVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject32 = new JSONObject(str2);
                    xVar.f8932g.E(jSONObject32.getInt("posDeviceNetworkInList"));
                    xVar.f8932g.v(jSONObject32.getInt("addressRegister"));
                    xVar.f8932g.t((byte) jSONObject32.getInt("addressBit"));
                    xVar.f8932g.L((byte) jSONObject32.getInt("typeRequest"));
                    break;
                } catch (JSONException unused77) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + xVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject33 = new JSONObject(str3);
                    xVar.setNumScreen(jSONObject33.getInt("numScreen"));
                    xVar.setPhone(jSONObject33.getString("phone"));
                    xVar.setCommand(jSONObject33.getString(IMAPStore.ID_COMMAND));
                    xVar.setTypeCommand(jSONObject33.getInt("typeCommand"));
                    try {
                        xVar.setStrob(jSONObject33.getBoolean("strob"));
                        xVar.setRegStrob(jSONObject33.getInt("regStrob"));
                        xVar.setBitStrob(jSONObject33.getInt("bitStrob"));
                        break;
                    } catch (Exception unused78) {
                    }
                    try {
                        xVar.setTimeZ(jSONObject33.getLong("timeZ"));
                        break;
                    } catch (Exception unused79) {
                    }
                } catch (JSONException unused80) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + xVar.c, 0).show();
                }
                return xVar;
            case 19:
                ru.himik.nightscream.kascada.CustomComponents.k kVar = new ru.himik.nightscream.kascada.CustomComponents.k(this);
                X0.addView(kVar);
                if (MyApplication.b().W.size() == 0) {
                    iKeyAt17 = 0;
                    z21 = true;
                } else {
                    z21 = true;
                    iKeyAt17 = MyApplication.b().W.keyAt(MyApplication.b().W.size() - 1) + 1;
                }
                MyApplication.b().W.append(iKeyAt17, kVar);
                kVar.setTag(Integer.valueOf(kVar.getIdComponent()));
                kVar.bringToFront();
                kVar.b(i5, i6, iKeyAt17, z21);
                kVar.setX(i5);
                kVar.setY(i6);
                kVar.f8832g.L((byte) 3);
                kVar.f8832g.A(kVar.getIdComponent());
                kVar.f8833h.L(kVar.f8831f);
                kVar.f8833h.A(kVar.getIdComponent());
                kVar.setOnLongClickListener(this.L0);
                kVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject34 = new JSONObject(str2);
                    kVar.f8832g.E(jSONObject34.getInt("posDeviceNetworkInList_source"));
                    kVar.f8832g.v(jSONObject34.getInt("addressRegister_source"));
                    kVar.f8833h.E(jSONObject34.getInt("posDeviceNetworkInList_receive"));
                    kVar.f8833h.v(jSONObject34.getInt("addressRegister_receive"));
                    try {
                        kVar.f8832g.z((byte) jSONObject34.getInt("countRegister_source"));
                        kVar.f8834i.E((byte) jSONObject34.getInt("posDeviceNetworkInList_trigger"));
                        break;
                    } catch (Exception unused81) {
                    }
                    try {
                        kVar.setTypeRequestSource((byte) jSONObject34.getInt("typeRequest_source"));
                        break;
                    } catch (Exception unused82) {
                    }
                } catch (JSONException unused83) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + kVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject35 = new JSONObject(str3);
                    kVar.setNumScreen(jSONObject35.getInt("numScreen"));
                    try {
                        kVar.setMode(jSONObject35.getInt("mode"));
                        kVar.setRegMode(jSONObject35.getInt("regMode"));
                        kVar.setBitMode(jSONObject35.getInt("bitMode"));
                        break;
                    } catch (JSONException unused84) {
                    }
                    try {
                        kVar.setTimeZ(jSONObject35.getLong("timeZ"));
                        break;
                    } catch (Exception unused85) {
                    }
                } catch (JSONException unused86) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + kVar.c, 0).show();
                }
                return kVar;
            case 20:
                CustomList customList = new CustomList(this);
                X0.addView(customList);
                if (MyApplication.b().X.size() == 0) {
                    iKeyAt18 = 0;
                    z22 = true;
                } else {
                    z22 = true;
                    iKeyAt18 = MyApplication.b().X.keyAt(MyApplication.b().X.size() - 1) + 1;
                }
                MyApplication.b().X.append(iKeyAt18, customList);
                customList.setTag(Integer.valueOf(customList.getIdComponent()));
                customList.bringToFront();
                customList.i(i5, i6, iKeyAt18, z22);
                customList.getLayoutParams().width = i3;
                customList.getLayoutParams().height = i4;
                customList.setText(str);
                customList.setX(i5);
                customList.setY(i6);
                customList.setTextSize(0, i7);
                customList.f8687i.L(customList.f8686h);
                customList.f8687i.A(customList.getIdComponent());
                customList.setTextColor(i8);
                customList.setOnLongClickListener(this.L0);
                customList.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject36 = new JSONObject(str2);
                    customList.f8687i.E(jSONObject36.getInt("posDeviceNetworkInList"));
                    customList.f8687i.v(jSONObject36.getInt("addressRegister"));
                    customList.f8687i.L((byte) jSONObject36.getInt("typeRequest"));
                    break;
                } catch (JSONException unused87) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customList.f8683e, 0).show();
                }
                String string = "";
                try {
                    JSONObject jSONObject37 = new JSONObject(str3);
                    customList.setNumScreen(jSONObject37.getInt("numScreen"));
                    string = jSONObject37.getString("textBit");
                    customList.setVisibleInWork(jSONObject37.getBoolean("visibleInWork"));
                    customList.setCheckNoChange(jSONObject37.getBoolean("checkNoChange"));
                    try {
                        customList.setTimeZ(jSONObject37.getLong("timeZ"));
                        break;
                    } catch (Exception unused88) {
                    }
                } catch (JSONException unused89) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customList.f8683e, 0).show();
                }
                try {
                    JSONObject jSONObject38 = new JSONObject(string);
                    for (int i11 = 0; i11 < 16; i11++) {
                        customList.m(jSONObject38.getString("textBit" + i11), i11);
                    }
                } catch (JSONException unused90) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customList.f8683e, 0).show();
                }
                return customList;
            case 21:
                CustomSound customSound = new CustomSound(this);
                X0.addView(customSound);
                if (MyApplication.b().Y.size() == 0) {
                    iKeyAt19 = 0;
                    z23 = true;
                } else {
                    z23 = true;
                    iKeyAt19 = MyApplication.b().Y.keyAt(MyApplication.b().Y.size() - 1) + 1;
                }
                MyApplication.b().Y.append(iKeyAt19, customSound);
                customSound.setTag(Integer.valueOf(customSound.getIdComponent()));
                customSound.bringToFront();
                customSound.c(i5, i6, iKeyAt19, z23);
                customSound.setX(i5);
                customSound.setY(i6);
                customSound.f8696g.A(customSound.getIdComponent());
                customSound.setOnLongClickListener(this.L0);
                customSound.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject39 = new JSONObject(str2);
                    customSound.f8696g.E(jSONObject39.getInt("posDeviceNetworkInList"));
                    customSound.f8696g.v(jSONObject39.getInt("addressRegister"));
                    customSound.f8696g.t((byte) jSONObject39.getInt("addressBit"));
                    customSound.f8696g.L((byte) jSONObject39.getInt("typeRequest"));
                    break;
                } catch (JSONException unused91) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customSound.c, 0).show();
                }
                try {
                    JSONObject jSONObject40 = new JSONObject(str3);
                    customSound.setNumScreen(jSONObject40.getInt("numScreen"));
                    customSound.f(jSONObject40.getString("pathSound_0"), 0);
                    customSound.f(jSONObject40.getString("pathSound_1"), 1);
                    customSound.f(jSONObject40.getString("pathSound_2"), 2);
                    customSound.f(jSONObject40.getString("pathSound_3"), 3);
                    customSound.f(jSONObject40.getString("pathSound_4"), 4);
                    customSound.f(jSONObject40.getString("pathSound_5"), 5);
                    customSound.f(jSONObject40.getString("pathSound_6"), 6);
                    customSound.f(jSONObject40.getString("pathSound_7"), 7);
                    try {
                        customSound.setTimeZ(jSONObject40.getLong("timeZ"));
                        break;
                    } catch (Exception unused92) {
                    }
                } catch (JSONException unused93) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + customSound.c, 0).show();
                }
                return customSound;
            case 22:
                ru.himik.nightscream.kascada.CustomComponents.l lVar = new ru.himik.nightscream.kascada.CustomComponents.l(this);
                X0.addView(lVar);
                if (MyApplication.b().Z.size() == 0) {
                    iKeyAt20 = 0;
                    r4 = 1;
                } else {
                    r4 = 1;
                    iKeyAt20 = MyApplication.b().Z.keyAt(MyApplication.b().Z.size() - 1) + 1;
                }
                MyApplication.b().Z.append(iKeyAt20, lVar);
                lVar.setTag(Integer.valueOf(lVar.getIdComponent()));
                lVar.bringToFront();
                lVar.b(i5, i6, iKeyAt20, r4);
                lVar.setX(i5);
                lVar.setY(i6);
                lVar.f8842f.L(r4);
                lVar.f8842f.A(lVar.getIdComponent());
                lVar.f8843g.L((byte) 15);
                lVar.f8843g.A(lVar.getIdComponent());
                lVar.setOnLongClickListener(this.L0);
                lVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject41 = new JSONObject(str2);
                    lVar.f8842f.E(jSONObject41.getInt("posDeviceNetworkInList_source"));
                    lVar.f8842f.v(jSONObject41.getInt("addressRegister_source"));
                    lVar.f8843g.E(jSONObject41.getInt("posDeviceNetworkInList_receive"));
                    lVar.f8843g.v(jSONObject41.getInt("addressRegister_receive"));
                    try {
                        lVar.f8842f.t((byte) jSONObject41.getInt("addressBit_source"));
                        lVar.f8843g.t((byte) jSONObject41.getInt("addressBit_receive"));
                        lVar.f8842f.y(jSONObject41.getInt("countBit"));
                        lVar.f8843g.y(jSONObject41.getInt("countBit"));
                        lVar.f8844h.E((byte) jSONObject41.getInt("posDeviceNetworkInList_trigger"));
                        break;
                    } catch (Exception unused94) {
                    }
                } catch (JSONException unused95) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + lVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject42 = new JSONObject(str3);
                    try {
                        lVar.setNumScreen(jSONObject42.getInt("numScreen"));
                        lVar.f8842f.L((byte) jSONObject42.getInt("functionModbusSource"));
                        lVar.setMode(jSONObject42.getInt("mode"));
                        lVar.setRegMode(jSONObject42.getInt("regMode"));
                        lVar.setBitMode(jSONObject42.getInt("bitMode"));
                        break;
                    } catch (JSONException unused96) {
                    }
                    try {
                        lVar.setTimeZ(jSONObject42.getLong("timeZ"));
                        break;
                    } catch (Exception unused97) {
                    }
                } catch (JSONException unused98) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + lVar.c, 0).show();
                }
                return lVar;
            case 23:
                ru.himik.nightscream.kascada.CustomComponents.f fVar = new ru.himik.nightscream.kascada.CustomComponents.f(this);
                X0.addView(fVar);
                if (MyApplication.b().a0.size() == 0) {
                    iKeyAt21 = 0;
                    z24 = true;
                } else {
                    z24 = true;
                    iKeyAt21 = MyApplication.b().a0.keyAt(MyApplication.b().a0.size() - 1) + 1;
                }
                MyApplication.b().a0.append(iKeyAt21, fVar);
                fVar.setTag(Integer.valueOf(fVar.getIdComponent()));
                fVar.bringToFront();
                fVar.g(i5, i6, iKeyAt21, z24);
                fVar.getLayoutParams().width = i3;
                fVar.getLayoutParams().height = i4;
                fVar.setX(i5);
                fVar.setY(i6);
                fVar.setOnLongClickListener(this.L0);
                fVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject43 = new JSONObject(str3);
                    try {
                        fVar.setNumScreen(jSONObject43.getInt("numScreen"));
                        fVar.setRtsp(jSONObject43.getString("rtsp_url"));
                        break;
                    } catch (JSONException unused99) {
                    }
                    try {
                        fVar.setTimeZ(jSONObject43.getLong("timeZ"));
                        break;
                    } catch (Exception unused100) {
                    }
                } catch (JSONException unused101) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + fVar.a, 0).show();
                }
                return fVar;
            case 24:
                ru.himik.nightscream.kascada.CustomComponents.m mVar = new ru.himik.nightscream.kascada.CustomComponents.m(this);
                X0.addView(mVar);
                if (MyApplication.b().b0.size() == 0) {
                    iKeyAt22 = 0;
                    z25 = true;
                } else {
                    z25 = true;
                    iKeyAt22 = MyApplication.b().b0.keyAt(MyApplication.b().b0.size() - 1) + 1;
                }
                MyApplication.b().b0.append(iKeyAt22, mVar);
                mVar.setTag(Integer.valueOf(mVar.getIdComponent()));
                mVar.bringToFront();
                mVar.T(i5, i6, iKeyAt22, z25);
                mVar.getLayoutParams().width = i3;
                mVar.getLayoutParams().height = i4;
                mVar.setX(i5);
                mVar.setY(i6);
                mVar.J0.A(mVar.getIdComponent());
                mVar.setOnLongClickListener(this.L0);
                mVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject44 = new JSONObject(str2);
                    mVar.J0.E(jSONObject44.getInt("posDeviceNetworkInList"));
                    mVar.J0.v(jSONObject44.getInt("addressRegister"));
                    mVar.J0.L((byte) jSONObject44.getInt("typeRequest"));
                    break;
                } catch (JSONException unused102) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + mVar.F0, 0).show();
                }
                try {
                    JSONObject jSONObject45 = new JSONObject(str3);
                    mVar.setNumScreen(jSONObject45.getInt("numScreen"));
                    mVar.setMaxGauge(jSONObject45.getInt("maxGauge"));
                    mVar.setMinGauge(jSONObject45.getInt("minGauge"));
                    mVar.setColorTextValue(jSONObject45.getInt("colorTextValue"));
                    mVar.setColorTextScale(jSONObject45.getInt("colorTextScale"));
                    mVar.setCountTextScale(jSONObject45.getInt("countTextScale"));
                    mVar.setSizeText(jSONObject45.getInt("sizeText"));
                    mVar.setColorCenterCircle(jSONObject45.getInt("colorCenterCircle"));
                    mVar.setColorMark(jSONObject45.getInt("colorMark"));
                    mVar.U(jSONObject45.getInt("percentLowScale"), jSONObject45.getInt("percentMediumScale"));
                    try {
                        mVar.setHideBackground(jSONObject45.getBoolean("hideBackground"));
                        break;
                    } catch (Exception unused103) {
                    }
                    try {
                        mVar.setTimeZ(jSONObject45.getLong("timeZ"));
                        break;
                    } catch (Exception unused104) {
                    }
                    try {
                        mVar.setIndicatorName(jSONObject45.getString("indicatorName"));
                        break;
                    } catch (Exception unused105) {
                    }
                    mVar.setColorIndicator(jSONObject45.getInt("colorIndicator"));
                    break;
                } catch (JSONException unused106) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + mVar.F0, 0).show();
                }
                return mVar;
            case 25:
                ru.himik.nightscream.kascada.CustomComponents.t tVar = new ru.himik.nightscream.kascada.CustomComponents.t(this);
                X0.addView(tVar);
                if (MyApplication.b().c0.size() == 0) {
                    iKeyAt23 = 0;
                    z26 = true;
                } else {
                    z26 = true;
                    iKeyAt23 = MyApplication.b().c0.keyAt(MyApplication.b().c0.size() - 1) + 1;
                }
                MyApplication.b().c0.append(iKeyAt23, tVar);
                tVar.setTag(Integer.valueOf(tVar.getIdComponent()));
                tVar.bringToFront();
                tVar.a(i5, i6, iKeyAt23, z26);
                tVar.setX(i5);
                tVar.setY(i6);
                tVar.f8889g.A(tVar.getIdComponent());
                tVar.setOnLongClickListener(this.L0);
                tVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject46 = new JSONObject(str2);
                    tVar.f8889g.E(jSONObject46.getInt("posDeviceNetworkInList"));
                    tVar.f8889g.v(jSONObject46.getInt("addressRegister"));
                    tVar.f8889g.t((byte) jSONObject46.getInt("addressBit"));
                    tVar.f8889g.L((byte) jSONObject46.getInt("typeRequest"));
                    break;
                } catch (JSONException unused107) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + tVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject47 = new JSONObject(str3);
                    tVar.setNumScreen(jSONObject47.getInt("numScreen"));
                    tVar.setTo(jSONObject47.getString("to"));
                    tVar.setTitle(jSONObject47.getString("title"));
                    tVar.setBody(jSONObject47.getString("body"));
                    try {
                        tVar.setTimeZ(jSONObject47.getLong("timeZ"));
                        break;
                    } catch (Exception unused108) {
                    }
                } catch (JSONException unused109) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + tVar.c, 0).show();
                }
                return tVar;
            case 26:
                ru.himik.nightscream.kascada.CustomComponents.b0 b0Var = new ru.himik.nightscream.kascada.CustomComponents.b0(this);
                X0.addView(b0Var);
                if (MyApplication.b().d0.size() == 0) {
                    iKeyAt24 = 0;
                    z27 = true;
                } else {
                    z27 = true;
                    iKeyAt24 = MyApplication.b().d0.keyAt(MyApplication.b().d0.size() - 1) + 1;
                }
                MyApplication.b().d0.append(iKeyAt24, b0Var);
                b0Var.setTag(Integer.valueOf(b0Var.getIdComponent()));
                b0Var.bringToFront();
                b0Var.c(i5, i6, iKeyAt24, z27);
                b0Var.getLayoutParams().width = i3;
                b0Var.getLayoutParams().height = i4;
                b0Var.setX(i5);
                b0Var.setY(i6);
                b0Var.f8729f.A(b0Var.getIdComponent());
                b0Var.setOnLongClickListener(this.L0);
                b0Var.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject48 = new JSONObject(str2);
                    b0Var.f8729f.E(jSONObject48.getInt("posDeviceNetworkInList"));
                    b0Var.f8729f.v(jSONObject48.getInt("addressRegister"));
                    b0Var.f8729f.t((byte) jSONObject48.getInt("addressBit"));
                    b0Var.f8729f.L((byte) jSONObject48.getInt("typeRequest"));
                    break;
                } catch (JSONException unused110) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + b0Var.b, 0).show();
                }
                try {
                    JSONObject jSONObject49 = new JSONObject(str3);
                    b0Var.setNumScreen(jSONObject49.getInt("numScreen"));
                    b0Var.setTimeZ(jSONObject49.getLong("timeZ"));
                    try {
                        b0Var.d(0, jSONObject49.getString("link0"));
                        b0Var.d(1, jSONObject49.getString("link1"));
                        b0Var.d(2, jSONObject49.getString("link2"));
                        b0Var.d(3, jSONObject49.getString("link3"));
                        b0Var.d(4, jSONObject49.getString("link4"));
                        b0Var.d(5, jSONObject49.getString("link5"));
                        b0Var.d(6, jSONObject49.getString("link6"));
                        b0Var.d(7, jSONObject49.getString("link7"));
                        b0Var.d(8, jSONObject49.getString("link8"));
                        b0Var.d(9, jSONObject49.getString("link9"));
                        b0Var.d(10, jSONObject49.getString("link10"));
                        b0Var.d(11, jSONObject49.getString("link11"));
                        b0Var.d(12, jSONObject49.getString("link12"));
                        b0Var.d(13, jSONObject49.getString("link13"));
                        b0Var.d(14, jSONObject49.getString("link14"));
                        b0Var.d(15, jSONObject49.getString("link15"));
                        break;
                    } catch (Exception unused111) {
                    }
                } catch (JSONException unused112) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + b0Var.b, 0).show();
                }
                return b0Var;
            case 27:
                ru.himik.nightscream.kascada.CustomComponents.a0 a0Var = new ru.himik.nightscream.kascada.CustomComponents.a0(this);
                X0.addView(a0Var);
                if (MyApplication.b().f0.size() == 0) {
                    iKeyAt25 = 0;
                    z28 = true;
                } else {
                    z28 = true;
                    iKeyAt25 = MyApplication.b().f0.keyAt(MyApplication.b().f0.size() - 1) + 1;
                }
                MyApplication.b().f0.append(iKeyAt25, a0Var);
                a0Var.setTag(Integer.valueOf(a0Var.getIdComponent()));
                a0Var.bringToFront();
                a0Var.c(i5, i6, iKeyAt25, z28);
                a0Var.getLayoutParams().width = i3;
                a0Var.getLayoutParams().height = i4;
                a0Var.setX(i5);
                a0Var.setY(i6);
                a0Var.f8708g.A(a0Var.getIdComponent());
                a0Var.setOnLongClickListener(this.L0);
                a0Var.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject50 = new JSONObject(str2);
                    a0Var.f8708g.E(jSONObject50.getInt("posDeviceNetworkInList"));
                    a0Var.f8708g.v(jSONObject50.getInt("addressRegister"));
                    a0Var.f8708g.t((byte) jSONObject50.getInt("addressBit"));
                    a0Var.f8708g.L((byte) jSONObject50.getInt("typeRequest"));
                    break;
                } catch (JSONException unused113) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + a0Var.c, 0).show();
                }
                try {
                    JSONObject jSONObject51 = new JSONObject(str3);
                    a0Var.setNumScreen(jSONObject51.getInt("numScreen"));
                    a0Var.setTimeZ(jSONObject51.getLong("timeZ"));
                    try {
                        a0Var.d(0, jSONObject51.getString("textVoice0"));
                        a0Var.d(1, jSONObject51.getString("textVoice1"));
                        a0Var.d(2, jSONObject51.getString("textVoice2"));
                        a0Var.d(3, jSONObject51.getString("textVoice3"));
                        a0Var.d(4, jSONObject51.getString("textVoice4"));
                        a0Var.d(5, jSONObject51.getString("textVoice5"));
                        a0Var.d(6, jSONObject51.getString("textVoice6"));
                        a0Var.d(7, jSONObject51.getString("textVoice7"));
                        a0Var.d(8, jSONObject51.getString("textVoice8"));
                        a0Var.d(9, jSONObject51.getString("textVoice9"));
                        a0Var.d(10, jSONObject51.getString("textVoice10"));
                        a0Var.d(11, jSONObject51.getString("textVoice11"));
                        a0Var.d(12, jSONObject51.getString("textVoice12"));
                        a0Var.d(13, jSONObject51.getString("textVoice13"));
                        a0Var.d(14, jSONObject51.getString("textVoice14"));
                        a0Var.d(15, jSONObject51.getString("textVoice15"));
                        break;
                    } catch (Exception unused114) {
                    }
                } catch (JSONException unused115) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + a0Var.c, 0).show();
                }
                return a0Var;
            case 28:
                ru.himik.nightscream.kascada.CustomComponents.j jVar = new ru.himik.nightscream.kascada.CustomComponents.j(this);
                X0.addView(jVar);
                if (MyApplication.b().e0.size() == 0) {
                    iKeyAt26 = 0;
                    z29 = true;
                } else {
                    z29 = true;
                    iKeyAt26 = MyApplication.b().e0.keyAt(MyApplication.b().e0.size() - 1) + 1;
                }
                MyApplication.b().e0.append(iKeyAt26, jVar);
                jVar.setTag(Integer.valueOf(jVar.getIdComponent()));
                jVar.bringToFront();
                jVar.a(i5, i6, iKeyAt26, z29);
                jVar.getLayoutParams().width = i3;
                jVar.getLayoutParams().height = i4;
                jVar.setX(i5);
                jVar.setY(i6);
                jVar.f8822h.A(jVar.getIdComponent());
                jVar.setOnLongClickListener(this.L0);
                jVar.setOnClickListener(this.t0);
                try {
                    JSONObject jSONObject52 = new JSONObject(str2);
                    jVar.f8822h.E(jSONObject52.getInt("posDeviceNetworkInList"));
                    jVar.f8822h.v(jSONObject52.getInt("addressRegister"));
                    jVar.f8822h.t((byte) jSONObject52.getInt("addressBit"));
                    jVar.f8822h.L((byte) jSONObject52.getInt("typeRequest"));
                    break;
                } catch (JSONException unused116) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + jVar.c, 0).show();
                }
                try {
                    JSONObject jSONObject53 = new JSONObject(str3);
                    jVar.setNumScreen(jSONObject53.getInt("numScreen"));
                    jVar.setTimeZ(jSONObject53.getLong("timeZ"));
                    try {
                        jVar.setTitle(jSONObject53.getString("title"));
                        jVar.setBody(jSONObject53.getString("body"));
                        jVar.setEmailTo(jSONObject53.getString("emailTo"));
                        jVar.setEmailLogin(jSONObject53.getString("emailLogin"));
                        jVar.setEmailPassword(jSONObject53.getString("emailPassword"));
                        break;
                    } catch (Exception unused117) {
                    }
                } catch (JSONException unused118) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_component) + " " + jVar.c, 0).show();
                }
                return jVar;
            default:
                switch (i2) {
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItem /* 101 */:
                        Var var = new Var(this);
                        X0.addView(var);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt27 = 0;
                            z30 = true;
                        } else {
                            z30 = true;
                            iKeyAt27 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt27, var);
                        var.s(i5, i6, iKeyAt27, z30);
                        var.setX(i5);
                        var.setY(i6);
                        var.setOnLongClickListener(this.L0);
                        var.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject54 = new JSONObject(str3);
                            var.setNumScreen(jSONObject54.getInt("numScreen"));
                            var.setInvert(jSONObject54.getBoolean("invertOut"));
                            var.setSaveKey(jSONObject54.getInt("saveKey"));
                            var.setKeyOut(jSONObject54.getInt("keyOut"));
                            var.setNumOnIn(jSONObject54.getInt("numOnIn"));
                            var.j(jSONObject54.getInt("reg"), jSONObject54.getInt("bit"));
                            var.setConstant(jSONObject54.getBoolean("isConstant"));
                            var.setVarConstant(jSONObject54.getBoolean("constant"));
                            break;
                        } catch (JSONException unused119) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + var.getTypeFb(), 0).show();
                        }
                        var.bringToFront();
                        return var;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItemSecondary /* 102 */:
                        VarOut varOut = new VarOut(this);
                        X0.addView(varOut);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt28 = 0;
                            z31 = true;
                        } else {
                            z31 = true;
                            iKeyAt28 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt28, varOut);
                        varOut.s(i5, i6, iKeyAt28, z31);
                        varOut.setX(i5);
                        varOut.setY(i6);
                        varOut.setOnLongClickListener(this.L0);
                        varOut.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject55 = new JSONObject(str3);
                            varOut.setNumScreen(jSONObject55.getInt("numScreen"));
                            varOut.setInvert(jSONObject55.getBoolean("invertOut"));
                            varOut.setSaveKey(jSONObject55.getInt("saveKey"));
                            varOut.setKeyOut(jSONObject55.getInt("keyOut"));
                            varOut.setNumOnIn(jSONObject55.getInt("numOnIn"));
                            varOut.j(jSONObject55.getInt("reg"), jSONObject55.getInt("bit"));
                            break;
                        } catch (JSONException unused120) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + varOut.getTypeFb(), 0).show();
                        }
                        varOut.bringToFront();
                        return varOut;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItemSmall /* 103 */:
                        FB_AND fb_and = new FB_AND(this);
                        X0.addView(fb_and);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt29 = 0;
                            z32 = true;
                        } else {
                            z32 = true;
                            iKeyAt29 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt29, fb_and);
                        fb_and.j(i5, i6, iKeyAt29, z32);
                        fb_and.setX(i5);
                        fb_and.setY(i6);
                        fb_and.setOnLongClickListener(this.L0);
                        fb_and.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject56 = new JSONObject(str3);
                            fb_and.setNumScreen(jSONObject56.getInt("numScreen"));
                            fb_and.setInvert(jSONObject56.getBoolean("invertOut"));
                            fb_and.setSaveKey(jSONObject56.getInt("saveKey"));
                            fb_and.setKeyOut(jSONObject56.getInt("keyOut"));
                            fb_and.setNumOnIn(jSONObject56.getInt("numOnIn"));
                            try {
                                fb_and.setRootNameMacro(jSONObject56.getString("nMcr"));
                                fb_and.setRootUniqueIdMacro(jSONObject56.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused121) {
                            }
                        } catch (JSONException unused122) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_and.getTypeFb(), 0).show();
                        }
                        fb_and.bringToFront();
                        return fb_and;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textAppearancePopupMenuHeader /* 104 */:
                        FB_OR fb_or = new FB_OR(this);
                        X0.addView(fb_or);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt30 = 0;
                            z33 = true;
                        } else {
                            z33 = true;
                            iKeyAt30 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt30, fb_or);
                        fb_or.j(i5, i6, iKeyAt30, z33);
                        fb_or.setX(i5);
                        fb_or.setY(i6);
                        fb_or.setOnLongClickListener(this.L0);
                        fb_or.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject57 = new JSONObject(str3);
                            fb_or.setNumScreen(jSONObject57.getInt("numScreen"));
                            fb_or.setInvert(jSONObject57.getBoolean("invertOut"));
                            fb_or.setSaveKey(jSONObject57.getInt("saveKey"));
                            fb_or.setKeyOut(jSONObject57.getInt("keyOut"));
                            fb_or.setNumOnIn(jSONObject57.getInt("numOnIn"));
                            try {
                                fb_or.setRootNameMacro(jSONObject57.getString("nMcr"));
                                fb_or.setRootUniqueIdMacro(jSONObject57.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused123) {
                            }
                        } catch (JSONException unused124) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_or.getTypeFb(), 0).show();
                        }
                        fb_or.bringToFront();
                        return fb_or;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceSearchResultSubtitle /* 105 */:
                        VarInt varInt = new VarInt(this);
                        X0.addView(varInt);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt31 = 0;
                            z34 = true;
                        } else {
                            z34 = true;
                            iKeyAt31 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt31, varInt);
                        varInt.s(i5, i6, iKeyAt31, z34);
                        varInt.setX(i5);
                        varInt.setY(i6);
                        varInt.setOnLongClickListener(this.L0);
                        varInt.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject58 = new JSONObject(str3);
                            varInt.setNumScreen(jSONObject58.getInt("numScreen"));
                            varInt.setSaveKey(jSONObject58.getInt("saveKey"));
                            varInt.setKeyOut(jSONObject58.getInt("keyOut"));
                            varInt.setNumOnIn(jSONObject58.getInt("numOnIn"));
                            varInt.j(jSONObject58.getInt("reg"), 0);
                            varInt.setConstant(jSONObject58.getBoolean("isConstant"));
                            varInt.setVarIntConstant(jSONObject58.getInt("constant"));
                            break;
                        } catch (Exception unused125) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + varInt.getTypeFb(), 0).show();
                        }
                        varInt.bringToFront();
                        return varInt;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceSearchResultTitle /* 106 */:
                        VarOutInt varOutInt = new VarOutInt(this);
                        X0.addView(varOutInt);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt32 = 0;
                            z35 = true;
                        } else {
                            z35 = true;
                            iKeyAt32 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt32, varOutInt);
                        varOutInt.s(i5, i6, iKeyAt32, z35);
                        varOutInt.setX(i5);
                        varOutInt.setY(i6);
                        varOutInt.setOnLongClickListener(this.L0);
                        varOutInt.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject59 = new JSONObject(str3);
                            varOutInt.setNumScreen(jSONObject59.getInt("numScreen"));
                            varOutInt.setInvert(jSONObject59.getBoolean("invertOut"));
                            varOutInt.setSaveKey(jSONObject59.getInt("saveKey"));
                            varOutInt.setKeyOut(jSONObject59.getInt("keyOut"));
                            varOutInt.setNumOnIn(jSONObject59.getInt("numOnIn"));
                            varOutInt.j(jSONObject59.getInt("reg"), 0);
                            break;
                        } catch (JSONException unused126) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + varOutInt.getTypeFb(), 0).show();
                        }
                        varOutInt.bringToFront();
                        return varOutInt;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceSmallPopupMenu /* 107 */:
                        FB_COMPARE fb_compare = new FB_COMPARE(this);
                        X0.addView(fb_compare);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt33 = 0;
                            z36 = true;
                        } else {
                            z36 = true;
                            iKeyAt33 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt33, fb_compare);
                        fb_compare.j(i5, i6, iKeyAt33, z36);
                        fb_compare.setX(i5);
                        fb_compare.setY(i6);
                        fb_compare.setOnLongClickListener(this.L0);
                        fb_compare.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject60 = new JSONObject(str3);
                            fb_compare.setNumScreen(jSONObject60.getInt("numScreen"));
                            fb_compare.setInvert(jSONObject60.getBoolean("invertOut"));
                            fb_compare.setSaveKey(jSONObject60.getInt("saveKey"));
                            fb_compare.setKeyOut(jSONObject60.getInt("keyOut"));
                            fb_compare.setNumOnIn(jSONObject60.getInt("numOnIn"));
                            try {
                                fb_compare.setRootNameMacro(jSONObject60.getString("nMcr"));
                                fb_compare.setRootUniqueIdMacro(jSONObject60.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused127) {
                            }
                            fb_compare.setActionExecute(jSONObject60.getInt("compareAction"));
                            break;
                        } catch (JSONException unused128) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_compare.getTypeFb(), 0).show();
                        }
                        fb_compare.bringToFront();
                        return fb_compare;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textColorAlertDialogListItem /* 108 */:
                        VarFloat varFloat = new VarFloat(this);
                        X0.addView(varFloat);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt34 = 0;
                            z37 = true;
                        } else {
                            z37 = true;
                            iKeyAt34 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt34, varFloat);
                        varFloat.s(i5, i6, iKeyAt34, z37);
                        varFloat.setX(i5);
                        varFloat.setY(i6);
                        varFloat.setOnLongClickListener(this.L0);
                        varFloat.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject61 = new JSONObject(str3);
                            varFloat.setNumScreen(jSONObject61.getInt("numScreen"));
                            varFloat.setInvert(jSONObject61.getBoolean("invertOut"));
                            varFloat.setSaveKey(jSONObject61.getInt("saveKey"));
                            varFloat.setKeyOut(jSONObject61.getInt("keyOut"));
                            varFloat.setNumOnIn(jSONObject61.getInt("numOnIn"));
                            varFloat.j(jSONObject61.getInt("reg"), 0);
                            varFloat.setConstant(jSONObject61.getBoolean("isConstant"));
                            varFloat.setVarFloatConstant(Float.valueOf(jSONObject61.getString("constant")).floatValue());
                            break;
                        } catch (JSONException unused129) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + varFloat.getTypeFb(), 0).show();
                        }
                        varFloat.bringToFront();
                        return varFloat;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_textColorSearchUrl /* 109 */:
                        VarOutFloat varOutFloat = new VarOutFloat(this);
                        X0.addView(varOutFloat);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt35 = 0;
                            z38 = true;
                        } else {
                            z38 = true;
                            iKeyAt35 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt35, varOutFloat);
                        varOutFloat.s(i5, i6, iKeyAt35, z38);
                        varOutFloat.setX(i5);
                        varOutFloat.setY(i6);
                        varOutFloat.setOnLongClickListener(this.L0);
                        varOutFloat.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject62 = new JSONObject(str3);
                            varOutFloat.setNumScreen(jSONObject62.getInt("numScreen"));
                            varOutFloat.setInvert(jSONObject62.getBoolean("invertOut"));
                            varOutFloat.setSaveKey(jSONObject62.getInt("saveKey"));
                            varOutFloat.setKeyOut(jSONObject62.getInt("keyOut"));
                            varOutFloat.setNumOnIn(jSONObject62.getInt("numOnIn"));
                            varOutFloat.j(jSONObject62.getInt("reg"), 0);
                            try {
                                varOutFloat.S = jSONObject62.getBoolean("isHighRegister");
                                varOutFloat.T = jSONObject62.getBoolean("isHighByte");
                                break;
                            } catch (Exception unused130) {
                            }
                        } catch (JSONException unused131) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + varOutFloat.getTypeFb(), 0).show();
                        }
                        varOutFloat.bringToFront();
                        return varOutFloat;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_toolbarNavigationButtonStyle /* 110 */:
                        FB_ARITHMETIC_INT fb_arithmetic_int = new FB_ARITHMETIC_INT(this);
                        X0.addView(fb_arithmetic_int);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt36 = 0;
                            z39 = true;
                        } else {
                            z39 = true;
                            iKeyAt36 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt36, fb_arithmetic_int);
                        fb_arithmetic_int.j(i5, i6, iKeyAt36, z39);
                        fb_arithmetic_int.setX(i5);
                        fb_arithmetic_int.setY(i6);
                        fb_arithmetic_int.setOnLongClickListener(this.L0);
                        fb_arithmetic_int.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject63 = new JSONObject(str3);
                            fb_arithmetic_int.setNumScreen(jSONObject63.getInt("numScreen"));
                            fb_arithmetic_int.setSaveKey(jSONObject63.getInt("saveKey"));
                            fb_arithmetic_int.setKeyOut(jSONObject63.getInt("keyOut"));
                            fb_arithmetic_int.setNumOnIn(jSONObject63.getInt("numOnIn"));
                            try {
                                fb_arithmetic_int.setRootNameMacro(jSONObject63.getString("nMcr"));
                                fb_arithmetic_int.setRootUniqueIdMacro(jSONObject63.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused132) {
                            }
                            fb_arithmetic_int.setActionExecute(jSONObject63.getInt("compareAction"));
                            break;
                        } catch (JSONException unused133) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_arithmetic_int.getTypeFb(), 0).show();
                        }
                        fb_arithmetic_int.bringToFront();
                        return fb_arithmetic_int;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_toolbarStyle /* 111 */:
                        FB_ARITHMETIC_FLOAT fb_arithmetic_float = new FB_ARITHMETIC_FLOAT(this);
                        X0.addView(fb_arithmetic_float);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt37 = 0;
                            z40 = true;
                        } else {
                            z40 = true;
                            iKeyAt37 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt37, fb_arithmetic_float);
                        fb_arithmetic_float.j(i5, i6, iKeyAt37, z40);
                        fb_arithmetic_float.setX(i5);
                        fb_arithmetic_float.setY(i6);
                        fb_arithmetic_float.setOnLongClickListener(this.L0);
                        fb_arithmetic_float.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject64 = new JSONObject(str3);
                            fb_arithmetic_float.setNumScreen(jSONObject64.getInt("numScreen"));
                            fb_arithmetic_float.setSaveKey(jSONObject64.getInt("saveKey"));
                            fb_arithmetic_float.setKeyOut(jSONObject64.getInt("keyOut"));
                            fb_arithmetic_float.setNumOnIn(jSONObject64.getInt("numOnIn"));
                            try {
                                fb_arithmetic_float.setRootNameMacro(jSONObject64.getString("nMcr"));
                                fb_arithmetic_float.setRootUniqueIdMacro(jSONObject64.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused134) {
                            }
                            fb_arithmetic_float.setActionExecute(jSONObject64.getInt("compareAction"));
                            break;
                        } catch (JSONException unused135) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_arithmetic_float.getTypeFb(), 0).show();
                        }
                        fb_arithmetic_float.bringToFront();
                        return fb_arithmetic_float;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_tooltipForegroundColor /* 112 */:
                        FB_COMPARE_FLOAT fb_compare_float = new FB_COMPARE_FLOAT(this);
                        X0.addView(fb_compare_float);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt38 = 0;
                            z41 = true;
                        } else {
                            z41 = true;
                            iKeyAt38 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt38, fb_compare_float);
                        fb_compare_float.j(i5, i6, iKeyAt38, z41);
                        fb_compare_float.setX(i5);
                        fb_compare_float.setY(i6);
                        fb_compare_float.setOnLongClickListener(this.L0);
                        fb_compare_float.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject65 = new JSONObject(str3);
                            fb_compare_float.setNumScreen(jSONObject65.getInt("numScreen"));
                            fb_compare_float.setInvert(jSONObject65.getBoolean("invertOut"));
                            fb_compare_float.setSaveKey(jSONObject65.getInt("saveKey"));
                            fb_compare_float.setKeyOut(jSONObject65.getInt("keyOut"));
                            fb_compare_float.setNumOnIn(jSONObject65.getInt("numOnIn"));
                            try {
                                fb_compare_float.setRootNameMacro(jSONObject65.getString("nMcr"));
                                fb_compare_float.setRootUniqueIdMacro(jSONObject65.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused136) {
                            }
                            fb_compare_float.setActionExecute(jSONObject65.getInt("compareAction"));
                            break;
                        } catch (JSONException unused137) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_compare_float.getTypeFb(), 0).show();
                        }
                        fb_compare_float.bringToFront();
                        return fb_compare_float;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_tooltipFrameBackground /* 113 */:
                        FB_RS fb_rs = new FB_RS(this);
                        X0.addView(fb_rs);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt39 = 0;
                            z42 = true;
                        } else {
                            z42 = true;
                            iKeyAt39 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt39, fb_rs);
                        fb_rs.j(i5, i6, iKeyAt39, z42);
                        fb_rs.setX(i5);
                        fb_rs.setY(i6);
                        fb_rs.setOnLongClickListener(this.L0);
                        fb_rs.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject66 = new JSONObject(str3);
                            fb_rs.setNumScreen(jSONObject66.getInt("numScreen"));
                            fb_rs.setInvert(jSONObject66.getBoolean("invertOut"));
                            fb_rs.setSaveKey(jSONObject66.getInt("saveKey"));
                            fb_rs.setKeyOut(jSONObject66.getInt("keyOut"));
                            fb_rs.setNumOnIn(jSONObject66.getInt("numOnIn"));
                            try {
                                fb_rs.setRootNameMacro(jSONObject66.getString("nMcr"));
                                fb_rs.setRootUniqueIdMacro(jSONObject66.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused138) {
                            }
                        } catch (JSONException unused139) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_rs.getName(), 0).show();
                        }
                        fb_rs.bringToFront();
                        return fb_rs;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_viewInflaterClass /* 114 */:
                        FB_TRIGGER fb_trigger = new FB_TRIGGER(this);
                        X0.addView(fb_trigger);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt40 = 0;
                            z43 = true;
                        } else {
                            z43 = true;
                            iKeyAt40 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt40, fb_trigger);
                        fb_trigger.j(i5, i6, iKeyAt40, z43);
                        fb_trigger.setX(i5);
                        fb_trigger.setY(i6);
                        fb_trigger.setOnLongClickListener(this.L0);
                        fb_trigger.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject67 = new JSONObject(str3);
                            fb_trigger.setNumScreen(jSONObject67.getInt("numScreen"));
                            fb_trigger.setInvert(jSONObject67.getBoolean("invertOut"));
                            fb_trigger.setSaveKey(jSONObject67.getInt("saveKey"));
                            fb_trigger.setKeyOut(jSONObject67.getInt("keyOut"));
                            fb_trigger.setNumOnIn(jSONObject67.getInt("numOnIn"));
                            try {
                                fb_trigger.setRootNameMacro(jSONObject67.getString("nMcr"));
                                fb_trigger.setRootUniqueIdMacro(jSONObject67.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused140) {
                            }
                            fb_trigger.setActionExecute(jSONObject67.getInt("type"));
                            break;
                        } catch (JSONException unused141) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_trigger.getName(), 0).show();
                        }
                        fb_trigger.bringToFront();
                        return fb_trigger;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowActionBar /* 115 */:
                        FB_TIMER fb_timer = new FB_TIMER(this);
                        X0.addView(fb_timer);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt41 = 0;
                            z44 = true;
                        } else {
                            z44 = true;
                            iKeyAt41 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt41, fb_timer);
                        fb_timer.j(i5, i6, iKeyAt41, z44);
                        fb_timer.setX(i5);
                        fb_timer.setY(i6);
                        fb_timer.setOnLongClickListener(this.L0);
                        fb_timer.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject68 = new JSONObject(str3);
                            fb_timer.setNumScreen(jSONObject68.getInt("numScreen"));
                            fb_timer.setInvert(jSONObject68.getBoolean("invertOut"));
                            fb_timer.setSaveKey(jSONObject68.getInt("saveKey"));
                            fb_timer.setKeyOut(jSONObject68.getInt("keyOut"));
                            fb_timer.setNumOnIn(jSONObject68.getInt("numOnIn"));
                            try {
                                fb_timer.setRootNameMacro(jSONObject68.getString("nMcr"));
                                fb_timer.setRootUniqueIdMacro(jSONObject68.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused142) {
                            }
                            fb_timer.setActionExecute(jSONObject68.getInt("type"));
                            fb_timer.setTypeTime(jSONObject68.getInt("typeTime"));
                            break;
                        } catch (JSONException unused143) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_timer.getName(), 0).show();
                        }
                        fb_timer.bringToFront();
                        return fb_timer;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowActionBarOverlay /* 116 */:
                        FB_CTU fb_ctu = new FB_CTU(this);
                        X0.addView(fb_ctu);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt42 = 0;
                            z45 = true;
                        } else {
                            z45 = true;
                            iKeyAt42 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt42, fb_ctu);
                        fb_ctu.j(i5, i6, iKeyAt42, z45);
                        fb_ctu.setX(i5);
                        fb_ctu.setY(i6);
                        fb_ctu.setOnLongClickListener(this.L0);
                        fb_ctu.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject69 = new JSONObject(str3);
                            fb_ctu.setNumScreen(jSONObject69.getInt("numScreen"));
                            fb_ctu.setInvert(jSONObject69.getBoolean("invertOut"));
                            fb_ctu.setSaveKey(jSONObject69.getInt("saveKey"));
                            fb_ctu.setKeyOut(jSONObject69.getInt("keyOut"));
                            fb_ctu.setNumOnIn(jSONObject69.getInt("numOnIn"));
                            try {
                                fb_ctu.setRootNameMacro(jSONObject69.getString("nMcr"));
                                fb_ctu.setRootUniqueIdMacro(jSONObject69.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused144) {
                            }
                        } catch (JSONException unused145) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_ctu.getName(), 0).show();
                        }
                        fb_ctu.bringToFront();
                        return fb_ctu;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowActionModeOverlay /* 117 */:
                        FB_MOVE fb_move = new FB_MOVE(this);
                        X0.addView(fb_move);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt43 = 0;
                            z46 = true;
                        } else {
                            z46 = true;
                            iKeyAt43 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt43, fb_move);
                        fb_move.j(i5, i6, iKeyAt43, z46);
                        fb_move.setX(i5);
                        fb_move.setY(i6);
                        fb_move.setOnLongClickListener(this.L0);
                        fb_move.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject70 = new JSONObject(str3);
                            fb_move.setNumScreen(jSONObject70.getInt("numScreen"));
                            fb_move.setSaveKey(jSONObject70.getInt("saveKey"));
                            fb_move.setKeyOut(jSONObject70.getInt("keyOut"));
                            fb_move.setNumOnIn(jSONObject70.getInt("numOnIn"));
                            try {
                                fb_move.setRootNameMacro(jSONObject70.getString("nMcr"));
                                fb_move.setRootUniqueIdMacro(jSONObject70.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused146) {
                            }
                        } catch (JSONException unused147) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_move.getName(), 0).show();
                        }
                        fb_move.bringToFront();
                        return fb_move;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowFixedHeightMajor /* 118 */:
                        IntToFloat intToFloat = new IntToFloat(this);
                        X0.addView(intToFloat);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt44 = 0;
                            z47 = true;
                        } else {
                            z47 = true;
                            iKeyAt44 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt44, intToFloat);
                        intToFloat.j(i5, i6, iKeyAt44, z47);
                        intToFloat.setX(i5);
                        intToFloat.setY(i6);
                        intToFloat.setOnLongClickListener(this.L0);
                        intToFloat.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject71 = new JSONObject(str3);
                            intToFloat.setNumScreen(jSONObject71.getInt("numScreen"));
                            intToFloat.setSaveKey(jSONObject71.getInt("saveKey"));
                            intToFloat.setKeyOut(jSONObject71.getInt("keyOut"));
                            intToFloat.setNumOnIn(jSONObject71.getInt("numOnIn"));
                            try {
                                intToFloat.setRootNameMacro(jSONObject71.getString("nMcr"));
                                intToFloat.setRootUniqueIdMacro(jSONObject71.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused148) {
                            }
                        } catch (JSONException unused149) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + intToFloat.getName(), 0).show();
                        }
                        intToFloat.bringToFront();
                        return intToFloat;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowFixedHeightMinor /* 119 */:
                        FloatToInt floatToInt = new FloatToInt(this);
                        X0.addView(floatToInt);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt45 = 0;
                            z48 = true;
                        } else {
                            z48 = true;
                            iKeyAt45 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt45, floatToInt);
                        floatToInt.j(i5, i6, iKeyAt45, z48);
                        floatToInt.setX(i5);
                        floatToInt.setY(i6);
                        floatToInt.setOnLongClickListener(this.L0);
                        floatToInt.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject72 = new JSONObject(str3);
                            floatToInt.setNumScreen(jSONObject72.getInt("numScreen"));
                            floatToInt.setSaveKey(jSONObject72.getInt("saveKey"));
                            floatToInt.setKeyOut(jSONObject72.getInt("keyOut"));
                            floatToInt.setNumOnIn(jSONObject72.getInt("numOnIn"));
                            try {
                                floatToInt.setRootNameMacro(jSONObject72.getString("nMcr"));
                                floatToInt.setRootUniqueIdMacro(jSONObject72.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused150) {
                            }
                        } catch (JSONException unused151) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + floatToInt.getName(), 0).show();
                        }
                        floatToInt.bringToFront();
                        return floatToInt;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowFixedWidthMajor /* 120 */:
                        Sensor_Orientation sensor_Orientation = new Sensor_Orientation(this);
                        X0.addView(sensor_Orientation);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt46 = 0;
                            z49 = true;
                        } else {
                            z49 = true;
                            iKeyAt46 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt46, sensor_Orientation);
                        sensor_Orientation.s(i5, i6, iKeyAt46, z49);
                        sensor_Orientation.setX(i5);
                        sensor_Orientation.setY(i6);
                        sensor_Orientation.setOnLongClickListener(this.L0);
                        sensor_Orientation.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject73 = new JSONObject(str3);
                            sensor_Orientation.setNumScreen(jSONObject73.getInt("numScreen"));
                            sensor_Orientation.setSaveKey(jSONObject73.getInt("saveKey"));
                            sensor_Orientation.setKeyOut(jSONObject73.getInt("keyOut"));
                            sensor_Orientation.setNumOnIn(jSONObject73.getInt("numOnIn"));
                            try {
                                sensor_Orientation.setRootNameMacro(jSONObject73.getString("nMcr"));
                                sensor_Orientation.setRootUniqueIdMacro(jSONObject73.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused152) {
                            }
                            sensor_Orientation.setActionExecute(jSONObject73.getInt("type"));
                            break;
                        } catch (JSONException unused153) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + sensor_Orientation.getName(), 0).show();
                        }
                        sensor_Orientation.bringToFront();
                        return sensor_Orientation;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowFixedWidthMinor /* 121 */:
                        SIN sin = new SIN(this);
                        X0.addView(sin);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt47 = 0;
                            z50 = true;
                        } else {
                            z50 = true;
                            iKeyAt47 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt47, sin);
                        sin.j(i5, i6, iKeyAt47, z50);
                        sin.setX(i5);
                        sin.setY(i6);
                        sin.setOnLongClickListener(this.L0);
                        sin.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject74 = new JSONObject(str3);
                            sin.setNumScreen(jSONObject74.getInt("numScreen"));
                            sin.setSaveKey(jSONObject74.getInt("saveKey"));
                            sin.setKeyOut(jSONObject74.getInt("keyOut"));
                            sin.setNumOnIn(jSONObject74.getInt("numOnIn"));
                            try {
                                sin.setRootNameMacro(jSONObject74.getString("nMcr"));
                                sin.setRootUniqueIdMacro(jSONObject74.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused154) {
                            }
                        } catch (JSONException unused155) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + sin.getName(), 0).show();
                        }
                        sin.bringToFront();
                        return sin;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowMinWidthMajor /* 122 */:
                        LOG log = new LOG(this);
                        X0.addView(log);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt48 = 0;
                            z51 = true;
                        } else {
                            z51 = true;
                            iKeyAt48 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt48, log);
                        log.j(i5, i6, iKeyAt48, z51);
                        log.setX(i5);
                        log.setY(i6);
                        log.setOnLongClickListener(this.L0);
                        log.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject75 = new JSONObject(str3);
                            log.setNumScreen(jSONObject75.getInt("numScreen"));
                            log.setSaveKey(jSONObject75.getInt("saveKey"));
                            log.setKeyOut(jSONObject75.getInt("keyOut"));
                            log.setNumOnIn(jSONObject75.getInt("numOnIn"));
                            try {
                                log.setRootNameMacro(jSONObject75.getString("nMcr"));
                                log.setRootUniqueIdMacro(jSONObject75.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused156) {
                            }
                        } catch (JSONException unused157) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + log.getName(), 0).show();
                        }
                        log.bringToFront();
                        return log;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowMinWidthMinor /* 123 */:
                        ABS abs = new ABS(this);
                        X0.addView(abs);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt49 = 0;
                            z52 = true;
                        } else {
                            z52 = true;
                            iKeyAt49 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt49, abs);
                        abs.j(i5, i6, iKeyAt49, z52);
                        abs.setX(i5);
                        abs.setY(i6);
                        abs.setOnLongClickListener(this.L0);
                        abs.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject76 = new JSONObject(str3);
                            abs.setNumScreen(jSONObject76.getInt("numScreen"));
                            abs.setSaveKey(jSONObject76.getInt("saveKey"));
                            abs.setKeyOut(jSONObject76.getInt("keyOut"));
                            abs.setNumOnIn(jSONObject76.getInt("numOnIn"));
                            try {
                                abs.setRootNameMacro(jSONObject76.getString("nMcr"));
                                abs.setRootUniqueIdMacro(jSONObject76.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused158) {
                            }
                        } catch (JSONException unused159) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + abs.getName(), 0).show();
                        }
                        abs.bringToFront();
                        return abs;
                    case com.karumi.dexter.R.styleable.AppCompatTheme_windowNoTitle /* 124 */:
                        FB_POW fb_pow = new FB_POW(this);
                        X0.addView(fb_pow);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt50 = 0;
                            z53 = true;
                        } else {
                            z53 = true;
                            iKeyAt50 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt50, fb_pow);
                        fb_pow.j(i5, i6, iKeyAt50, z53);
                        fb_pow.setX(i5);
                        fb_pow.setY(i6);
                        fb_pow.setOnLongClickListener(this.L0);
                        fb_pow.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject77 = new JSONObject(str3);
                            fb_pow.setNumScreen(jSONObject77.getInt("numScreen"));
                            fb_pow.setSaveKey(jSONObject77.getInt("saveKey"));
                            fb_pow.setKeyOut(jSONObject77.getInt("keyOut"));
                            fb_pow.setNumOnIn(jSONObject77.getInt("numOnIn"));
                            try {
                                fb_pow.setRootNameMacro(jSONObject77.getString("nMcr"));
                                fb_pow.setRootUniqueIdMacro(jSONObject77.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused160) {
                            }
                        } catch (JSONException unused161) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_pow.getName(), 0).show();
                        }
                        fb_pow.bringToFront();
                        return fb_pow;
                    case 125:
                        FB_XOR fb_xor = new FB_XOR(this);
                        X0.addView(fb_xor);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt51 = 0;
                            z54 = true;
                        } else {
                            z54 = true;
                            iKeyAt51 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt51, fb_xor);
                        fb_xor.j(i5, i6, iKeyAt51, z54);
                        fb_xor.setX(i5);
                        fb_xor.setY(i6);
                        fb_xor.setOnLongClickListener(this.L0);
                        fb_xor.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject78 = new JSONObject(str3);
                            fb_xor.setNumScreen(jSONObject78.getInt("numScreen"));
                            fb_xor.setSaveKey(jSONObject78.getInt("saveKey"));
                            fb_xor.setKeyOut(jSONObject78.getInt("keyOut"));
                            fb_xor.setNumOnIn(jSONObject78.getInt("numOnIn"));
                            try {
                                fb_xor.setRootNameMacro(jSONObject78.getString("nMcr"));
                                fb_xor.setRootUniqueIdMacro(jSONObject78.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused162) {
                            }
                        } catch (JSONException unused163) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_xor.getName(), 0).show();
                        }
                        fb_xor.bringToFront();
                        return fb_xor;
                    case 126:
                        FB_SEL fb_sel = new FB_SEL(this);
                        X0.addView(fb_sel);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt52 = 0;
                            z55 = true;
                        } else {
                            z55 = true;
                            iKeyAt52 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt52, fb_sel);
                        fb_sel.j(i5, i6, iKeyAt52, z55);
                        fb_sel.setX(i5);
                        fb_sel.setY(i6);
                        fb_sel.setOnLongClickListener(this.L0);
                        fb_sel.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject79 = new JSONObject(str3);
                            fb_sel.setNumScreen(jSONObject79.getInt("numScreen"));
                            fb_sel.setSaveKey(jSONObject79.getInt("saveKey"));
                            fb_sel.setKeyOut(jSONObject79.getInt("keyOut"));
                            fb_sel.setNumOnIn(jSONObject79.getInt("numOnIn"));
                            try {
                                fb_sel.setRootNameMacro(jSONObject79.getString("nMcr"));
                                fb_sel.setRootUniqueIdMacro(jSONObject79.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused164) {
                            }
                        } catch (JSONException unused165) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_sel.getName(), 0).show();
                        }
                        fb_sel.bringToFront();
                        return fb_sel;
                    case 127:
                        Sunrise_GPS sunrise_GPS = new Sunrise_GPS(this);
                        X0.addView(sunrise_GPS);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt53 = 0;
                            z56 = true;
                        } else {
                            z56 = true;
                            iKeyAt53 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt53, sunrise_GPS);
                        sunrise_GPS.s(i5, i6, iKeyAt53, z56);
                        sunrise_GPS.setX(i5);
                        sunrise_GPS.setY(i6);
                        sunrise_GPS.setOnLongClickListener(this.L0);
                        sunrise_GPS.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject80 = new JSONObject(str3);
                            sunrise_GPS.setNumScreen(jSONObject80.getInt("numScreen"));
                            sunrise_GPS.setSaveKey(jSONObject80.getInt("saveKey"));
                            sunrise_GPS.setKeyOut(jSONObject80.getInt("keyOut"));
                            sunrise_GPS.setNumOnIn(jSONObject80.getInt("numOnIn"));
                            try {
                                sunrise_GPS.setRootNameMacro(jSONObject80.getString("nMcr"));
                                sunrise_GPS.setRootUniqueIdMacro(jSONObject80.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused166) {
                            }
                            sunrise_GPS.setActionExecute(jSONObject80.getInt("type"));
                            sunrise_GPS.setLatitude((float) jSONObject80.getDouble("latitude"));
                            sunrise_GPS.setLongitude((float) jSONObject80.getDouble("longitude"));
                            break;
                        } catch (JSONException unused167) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + sunrise_GPS.getName(), 0).show();
                        }
                        sunrise_GPS.bringToFront();
                        return sunrise_GPS;
                    case FtdiSerialDriver.FtdiSerialPort.USB_ENDPOINT_IN /* 128 */:
                        FB_MX fb_mx = new FB_MX(this);
                        X0.addView(fb_mx);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt54 = 0;
                            z57 = true;
                        } else {
                            z57 = true;
                            iKeyAt54 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt54, fb_mx);
                        fb_mx.j(i5, i6, iKeyAt54, z57);
                        fb_mx.setX(i5);
                        fb_mx.setY(i6);
                        fb_mx.setOnLongClickListener(this.L0);
                        fb_mx.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject81 = new JSONObject(str3);
                            fb_mx.setNumScreen(jSONObject81.getInt("numScreen"));
                            fb_mx.setSaveKey(jSONObject81.getInt("saveKey"));
                            fb_mx.setKeyOut(jSONObject81.getInt("keyOut"));
                            fb_mx.setNumOnIn(jSONObject81.getInt("numOnIn"));
                            try {
                                fb_mx.setRootNameMacro(jSONObject81.getString("nMcr"));
                                fb_mx.setRootUniqueIdMacro(jSONObject81.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused168) {
                            }
                        } catch (JSONException unused169) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_mx.getName(), 0).show();
                        }
                        fb_mx.bringToFront();
                        return fb_mx;
                    case 129:
                        WordToFloat wordToFloat = new WordToFloat(this);
                        X0.addView(wordToFloat);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt55 = 0;
                            z58 = true;
                        } else {
                            z58 = true;
                            iKeyAt55 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt55, wordToFloat);
                        wordToFloat.j(i5, i6, iKeyAt55, z58);
                        wordToFloat.setX(i5);
                        wordToFloat.setY(i6);
                        wordToFloat.setOnLongClickListener(this.L0);
                        wordToFloat.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject82 = new JSONObject(str3);
                            wordToFloat.setNumScreen(jSONObject82.getInt("numScreen"));
                            wordToFloat.setSaveKey(jSONObject82.getInt("saveKey"));
                            wordToFloat.setKeyOut(jSONObject82.getInt("keyOut"));
                            wordToFloat.setNumOnIn(jSONObject82.getInt("numOnIn"));
                            try {
                                wordToFloat.setRootNameMacro(jSONObject82.getString("nMcr"));
                                wordToFloat.setRootUniqueIdMacro(jSONObject82.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused170) {
                            }
                        } catch (JSONException unused171) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + wordToFloat.getName(), 0).show();
                        }
                        wordToFloat.bringToFront();
                        return wordToFloat;
                    case 130:
                        ODTEMP odtemp = new ODTEMP(this);
                        X0.addView(odtemp);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt56 = 0;
                            z59 = true;
                        } else {
                            z59 = true;
                            iKeyAt56 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt56, odtemp);
                        odtemp.s(i5, i6, iKeyAt56, z59);
                        odtemp.setX(i5);
                        odtemp.setY(i6);
                        odtemp.setOnLongClickListener(this.L0);
                        odtemp.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject83 = new JSONObject(str3);
                            odtemp.setNumScreen(jSONObject83.getInt("numScreen"));
                            odtemp.setSaveKey(jSONObject83.getInt("saveKey"));
                            odtemp.setKeyOut(jSONObject83.getInt("keyOut"));
                            odtemp.setNumOnIn(jSONObject83.getInt("numOnIn"));
                            try {
                                odtemp.setRootNameMacro(jSONObject83.getString("nMcr"));
                                odtemp.setRootUniqueIdMacro(jSONObject83.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused172) {
                            }
                            odtemp.setIp(jSONObject83.getString("ip"));
                            odtemp.setTypeSensor(jSONObject83.getInt("typeSensor"));
                            odtemp.setTypeResponse(jSONObject83.getInt("typeResponse"));
                            break;
                        } catch (JSONException unused173) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + odtemp.getName(), 0).show();
                        }
                        odtemp.bringToFront();
                        return odtemp;
                    case 131:
                        Sensor_Light sensor_Light = new Sensor_Light(this);
                        X0.addView(sensor_Light);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt57 = 0;
                            z60 = true;
                        } else {
                            z60 = true;
                            iKeyAt57 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt57, sensor_Light);
                        sensor_Light.s(i5, i6, iKeyAt57, z60);
                        sensor_Light.setX(i5);
                        sensor_Light.setY(i6);
                        sensor_Light.setOnLongClickListener(this.L0);
                        sensor_Light.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject84 = new JSONObject(str3);
                            sensor_Light.setNumScreen(jSONObject84.getInt("numScreen"));
                            sensor_Light.setSaveKey(jSONObject84.getInt("saveKey"));
                            sensor_Light.setKeyOut(jSONObject84.getInt("keyOut"));
                            sensor_Light.setNumOnIn(jSONObject84.getInt("numOnIn"));
                            try {
                                sensor_Light.setRootNameMacro(jSONObject84.getString("nMcr"));
                                sensor_Light.setRootUniqueIdMacro(jSONObject84.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused174) {
                            }
                        } catch (JSONException unused175) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + sensor_Light.getName(), 0).show();
                        }
                        sensor_Light.bringToFront();
                        return sensor_Light;
                    case 132:
                        Sensor_Speed sensor_Speed = new Sensor_Speed(this);
                        X0.addView(sensor_Speed);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt58 = 0;
                            z61 = true;
                        } else {
                            z61 = true;
                            iKeyAt58 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt58, sensor_Speed);
                        sensor_Speed.s(i5, i6, iKeyAt58, z61);
                        sensor_Speed.setX(i5);
                        sensor_Speed.setY(i6);
                        sensor_Speed.setOnLongClickListener(this.L0);
                        sensor_Speed.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject85 = new JSONObject(str3);
                            sensor_Speed.setNumScreen(jSONObject85.getInt("numScreen"));
                            sensor_Speed.setSaveKey(jSONObject85.getInt("saveKey"));
                            sensor_Speed.setKeyOut(jSONObject85.getInt("keyOut"));
                            sensor_Speed.setNumOnIn(jSONObject85.getInt("numOnIn"));
                            try {
                                sensor_Speed.setRootNameMacro(jSONObject85.getString("nMcr"));
                                sensor_Speed.setRootUniqueIdMacro(jSONObject85.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused176) {
                            }
                        } catch (JSONException unused177) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + sensor_Speed.getName(), 0).show();
                        }
                        sensor_Speed.bringToFront();
                        return sensor_Speed;
                    case 133:
                        VarNameIn varNameIn = new VarNameIn(this);
                        X0.addView(varNameIn);
                        if (MyApplication.b().D.size() == 0) {
                            z62 = true;
                            iKeyAt59 = 0;
                        } else {
                            z62 = true;
                            iKeyAt59 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt59, varNameIn);
                        varNameIn.s(i5, i6, iKeyAt59, z62);
                        varNameIn.setX(i5);
                        varNameIn.setY(i6);
                        varNameIn.setOnLongClickListener(this.L0);
                        varNameIn.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject86 = new JSONObject(str3);
                            varNameIn.setNumScreen(jSONObject86.getInt("numScreen"));
                            varNameIn.setInvert(jSONObject86.getBoolean("invertOut"));
                            varNameIn.setSaveKey(jSONObject86.getInt("saveKey"));
                            varNameIn.setKeyOut(jSONObject86.getInt("keyOut"));
                            varNameIn.setNumOnIn(jSONObject86.getInt("numOnIn"));
                            try {
                                varNameIn.setRootNameMacro(jSONObject86.getString("nMcr"));
                                varNameIn.setRootUniqueIdMacro(jSONObject86.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused178) {
                            }
                            try {
                                varNameIn.setTypeVar(jSONObject86.getInt("typeVar"));
                                varNameIn.setTypeVarValue(jSONObject86.getInt("typeVarValue"));
                                if (varNameIn.getTypeVarValue() == 2) {
                                    varNameIn.setConstant(jSONObject86.getBoolean("isConstant"));
                                    int typeVar = varNameIn.getTypeVar();
                                    if (typeVar == 1) {
                                        varNameIn.setVarConstant(jSONObject86.getBoolean("constant"));
                                    } else if (typeVar == 2) {
                                        varNameIn.setVarIntConstant(jSONObject86.getInt("constant"));
                                    } else if (typeVar == 3) {
                                        varNameIn.setVarFloatConstant(Float.valueOf(jSONObject86.getString("constant")).floatValue());
                                    }
                                } else {
                                    varNameIn.setVarName(jSONObject86.getString(IMAPStore.ID_NAME));
                                    if (varNameIn.getNumScreen() != -1) {
                                        C().c().b(varNameIn.getVarName(), varNameIn.getTypeVar());
                                    }
                                }
                            } catch (Exception unused179) {
                                Context applicationContext4 = getApplicationContext();
                                StringBuilder sb4 = new StringBuilder();
                                sb4.append(getResources().getString(R.string.error_load_logic));
                                str7 = " ";
                                try {
                                    sb4.append(str7);
                                    sb4.append(varNameIn.getName());
                                    Toast.makeText(applicationContext4, sb4.toString(), 0).show();
                                } catch (JSONException unused180) {
                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + str7 + varNameIn.getName(), 0).show();
                                }
                            }
                            break;
                        } catch (JSONException unused181) {
                            str7 = r7;
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + str7 + varNameIn.getName(), 0).show();
                        }
                        varNameIn.bringToFront();
                        return varNameIn;
                    case 134:
                        VarNameOut varNameOut = new VarNameOut(this);
                        X0.addView(varNameOut);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt60 = 0;
                            z63 = true;
                        } else {
                            z63 = true;
                            iKeyAt60 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt60, varNameOut);
                        varNameOut.s(i5, i6, iKeyAt60, z63);
                        varNameOut.setX(i5);
                        varNameOut.setY(i6);
                        varNameOut.setOnLongClickListener(this.L0);
                        varNameOut.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject87 = new JSONObject(str3);
                            varNameOut.setNumScreen(jSONObject87.getInt("numScreen"));
                            varNameOut.setSaveKey(jSONObject87.getInt("saveKey"));
                            varNameOut.setKeyOut(jSONObject87.getInt("keyOut"));
                            varNameOut.setNumOnIn(jSONObject87.getInt("numOnIn"));
                            try {
                                varNameOut.setRootNameMacro(jSONObject87.getString("nMcr"));
                                varNameOut.setRootUniqueIdMacro(jSONObject87.getLong("unIdMcr"));
                                break;
                            } catch (Exception unused182) {
                            }
                            try {
                                varNameOut.setTypeVar(jSONObject87.getInt("typeVar"));
                                varNameOut.setVarName(jSONObject87.getString(IMAPStore.ID_NAME));
                                if (varNameOut.getNumScreen() != -1) {
                                    C().c().b(varNameOut.getVarName(), varNameOut.getTypeVar());
                                }
                            } catch (Exception unused183) {
                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + varNameOut.getName(), 0).show();
                            }
                            break;
                        } catch (JSONException unused184) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + varNameOut.getName(), 0).show();
                        }
                        varNameOut.bringToFront();
                        return varNameOut;
                    case 135:
                        FB_MACRO fb_macro = new FB_MACRO(this);
                        X0.addView(fb_macro);
                        int iKeyAt67 = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        MyApplication.b().D.append(iKeyAt67, fb_macro);
                        fb_macro.setOnLongClickListener(this.L0);
                        fb_macro.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject88 = new JSONObject(str3);
                            fb_macro.setNumScreen(jSONObject88.getInt("numScreen"));
                            try {
                                fb_macro.setSaveKey(jSONObject88.getInt("saveKey"));
                            } catch (Exception unused185) {
                                fb_macro.setSaveKey(0);
                            }
                            try {
                                fb_macro.setKeyOut(jSONObject88.getInt("keyOut"));
                            } catch (Exception unused186) {
                                fb_macro.setKeyOut(-1);
                            }
                            try {
                                fb_macro.setNumOnIn(jSONObject88.getInt("numOnIn"));
                            } catch (Exception unused187) {
                                fb_macro.setNumOnIn(0);
                            }
                            fb_macro.setName(jSONObject88.getString(IMAPStore.ID_NAME));
                            fb_macro.t(jSONObject88.getInt("countIn"), true);
                            fb_macro.c = jSONObject88.getLong("uniqueId");
                            fb_macro.E.h(jSONObject88.getString("nameIn1"));
                            fb_macro.E.i(jSONObject88.getInt("typeIn1"));
                            fb_macro.E.a.setNumOnIn(jSONObject88.getInt("numOnIn1"));
                            fb_macro.E.a.setKeyOut(jSONObject88.getInt("keyOutIn1"));
                            fb_macro.F.h(jSONObject88.getString("nameIn2"));
                            fb_macro.F.i(jSONObject88.getInt("typeIn2"));
                            fb_macro.F.a.setNumOnIn(jSONObject88.getInt("numOnIn2"));
                            fb_macro.F.a.setKeyOut(jSONObject88.getInt("keyOutIn2"));
                            fb_macro.G.h(jSONObject88.getString("nameIn3"));
                            fb_macro.G.i(jSONObject88.getInt("typeIn3"));
                            fb_macro.G.a.setNumOnIn(jSONObject88.getInt("numOnIn3"));
                            fb_macro.G.a.setKeyOut(jSONObject88.getInt("keyOutIn3"));
                            fb_macro.H.h(jSONObject88.getString("nameIn4"));
                            fb_macro.H.i(jSONObject88.getInt("typeIn4"));
                            fb_macro.H.a.setNumOnIn(jSONObject88.getInt("numOnIn4"));
                            fb_macro.H.a.setKeyOut(jSONObject88.getInt("keyOutIn4"));
                            fb_macro.I.h(jSONObject88.getString("nameOut"));
                            fb_macro.I.i(jSONObject88.getInt("typeOut"));
                            fb_macro.I.a.setSaveKey(jSONObject88.getInt("saveKeyOut"));
                            break;
                        } catch (JSONException unused188) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_macro.getName(), 0).show();
                        }
                        fb_macro.s(i5, i6, iKeyAt67, true);
                        fb_macro.setX(i5);
                        fb_macro.setY(i6);
                        fb_macro.r();
                        fb_macro.bringToFront();
                        return fb_macro;
                    case 136:
                        FB_ARRAY fb_array = new FB_ARRAY(this);
                        X0.addView(fb_array);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt61 = 0;
                            z64 = true;
                        } else {
                            z64 = true;
                            iKeyAt61 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt61, fb_array);
                        fb_array.j(i5, i6, iKeyAt61, z64);
                        fb_array.setX(i5);
                        fb_array.setY(i6);
                        fb_array.setOnLongClickListener(this.L0);
                        fb_array.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject89 = new JSONObject(str3);
                            fb_array.setNumScreen(jSONObject89.getInt("numScreen"));
                            fb_array.setSaveKey(jSONObject89.getInt("saveKey"));
                            fb_array.setKeyOut(jSONObject89.getInt("keyOut"));
                            fb_array.setNumOnIn(jSONObject89.getInt("numOnIn"));
                            break;
                        } catch (JSONException unused189) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_array.getName(), 0).show();
                        }
                        fb_array.bringToFront();
                        return fb_array;
                    case 137:
                        FB_CHANGE_I fb_change_i = new FB_CHANGE_I(this);
                        X0.addView(fb_change_i);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt62 = 0;
                            z65 = true;
                        } else {
                            z65 = true;
                            iKeyAt62 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt62, fb_change_i);
                        fb_change_i.j(i5, i6, iKeyAt62, z65);
                        fb_change_i.setX(i5);
                        fb_change_i.setY(i6);
                        fb_change_i.setOnLongClickListener(this.L0);
                        fb_change_i.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject90 = new JSONObject(str3);
                            fb_change_i.setNumScreen(jSONObject90.getInt("numScreen"));
                            fb_change_i.setSaveKey(jSONObject90.getInt("saveKey"));
                            fb_change_i.setKeyOut(jSONObject90.getInt("keyOut"));
                            fb_change_i.setNumOnIn(jSONObject90.getInt("numOnIn"));
                            break;
                        } catch (JSONException unused190) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_change_i.getName(), 0).show();
                        }
                        fb_change_i.bringToFront();
                        return fb_change_i;
                    case 138:
                        FB_CHANGE_F fb_change_f = new FB_CHANGE_F(this);
                        X0.addView(fb_change_f);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt63 = 0;
                            z66 = true;
                        } else {
                            z66 = true;
                            iKeyAt63 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt63, fb_change_f);
                        fb_change_f.j(i5, i6, iKeyAt63, z66);
                        fb_change_f.setX(i5);
                        fb_change_f.setY(i6);
                        fb_change_f.setOnLongClickListener(this.L0);
                        fb_change_f.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject91 = new JSONObject(str3);
                            fb_change_f.setNumScreen(jSONObject91.getInt("numScreen"));
                            fb_change_f.setSaveKey(jSONObject91.getInt("saveKey"));
                            fb_change_f.setKeyOut(jSONObject91.getInt("keyOut"));
                            fb_change_f.setNumOnIn(jSONObject91.getInt("numOnIn"));
                            break;
                        } catch (JSONException unused191) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + fb_change_f.getName(), 0).show();
                        }
                        fb_change_f.bringToFront();
                        return fb_change_f;
                    case 139:
                        MQTT_SUBSCRIBER mqtt_subscriber = new MQTT_SUBSCRIBER(this);
                        X0.addView(mqtt_subscriber);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt64 = 0;
                            z67 = true;
                        } else {
                            z67 = true;
                            iKeyAt64 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt64, mqtt_subscriber);
                        mqtt_subscriber.s(i5, i6, iKeyAt64, z67);
                        mqtt_subscriber.setX(i5);
                        mqtt_subscriber.setY(i6);
                        mqtt_subscriber.setOnLongClickListener(this.L0);
                        mqtt_subscriber.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject92 = new JSONObject(str3);
                            mqtt_subscriber.setNumScreen(jSONObject92.getInt("numScreen"));
                            mqtt_subscriber.setSaveKey(jSONObject92.getInt("saveKey"));
                            mqtt_subscriber.setKeyOut(jSONObject92.getInt("keyOut"));
                            mqtt_subscriber.setNumOnIn(jSONObject92.getInt("numOnIn"));
                            mqtt_subscriber.setTopic(jSONObject92.getString("topic"));
                            mqtt_subscriber.setTypeQ(jSONObject92.getInt("typeQ"));
                            try {
                                mqtt_subscriber.setNumMqttServer(jSONObject92.getInt("numMqttServer"));
                                break;
                            } catch (Exception unused192) {
                            }
                        } catch (JSONException unused193) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + mqtt_subscriber.getName(), 0).show();
                        }
                        mqtt_subscriber.bringToFront();
                        return mqtt_subscriber;
                    case 140:
                        MQTT_PUBLISHER mqtt_publisher = new MQTT_PUBLISHER(this);
                        X0.addView(mqtt_publisher);
                        if (MyApplication.b().D.size() == 0) {
                            iKeyAt65 = 0;
                            z68 = true;
                        } else {
                            z68 = true;
                            iKeyAt65 = MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
                        }
                        MyApplication.b().D.append(iKeyAt65, mqtt_publisher);
                        mqtt_publisher.j(i5, i6, iKeyAt65, z68);
                        mqtt_publisher.setX(i5);
                        mqtt_publisher.setY(i6);
                        mqtt_publisher.setOnLongClickListener(this.L0);
                        mqtt_publisher.setOnClickListener(this.R0);
                        try {
                            JSONObject jSONObject93 = new JSONObject(str3);
                            mqtt_publisher.setNumScreen(jSONObject93.getInt("numScreen"));
                            mqtt_publisher.setSaveKey(jSONObject93.getInt("saveKey"));
                            mqtt_publisher.setKeyOut(jSONObject93.getInt("keyOut"));
                            mqtt_publisher.setNumOnIn(jSONObject93.getInt("numOnIn"));
                            mqtt_publisher.setTopic(jSONObject93.getString("topic"));
                            mqtt_publisher.setTypeIn(jSONObject93.getInt("typeIn"));
                            try {
                                mqtt_publisher.setNumMqttServer(jSONObject93.getInt("numMqttServer"));
                                mqtt_publisher.setMqttRetain(jSONObject93.getBoolean("mqttRetain"));
                                break;
                            } catch (Exception unused194) {
                            }
                        } catch (JSONException unused195) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_logic) + " " + mqtt_publisher.getName(), 0).show();
                        }
                        mqtt_publisher.bringToFront();
                        return mqtt_publisher;
                    default:
                        this.a.bringToFront();
                        this.W.bringToFront();
                        return null;
                }
        }
    }

    private void m0(String str, x0 x0Var) {
        f.b.a.i.w(this).t(new File(str)).K().o(new i(MyApplication.b().f9040h, MyApplication.b().f9041i, x0Var));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void n0(int i2) {
        if (a1 == i2) {
            return;
        }
        if (!this.f9206k) {
            if (i2 > b1 || i2 < 1) {
                a1 = 1;
            }
            y0();
            z0();
        }
        if (i2 > MyApplication.b().o || i2 < 1) {
            return;
        }
        if (!MyApplication.b().C.get(i2 - 1).e().equals("")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getResources().getString(R.string.screen) + " " + i2 + " " + getResources().getString(R.string.requires_pass));
            EditText editText = new EditText(this);
            editText.setInputType(129);
            editText.setSelection(editText.getText().length());
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
            builder.setView(editText);
            builder.setPositiveButton(getResources().getString(R.string.dialog_accept), new l0(i2, editText));
            builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new m0(this));
            builder.show();
            return;
        }
        a1 = i2;
        y0();
        z0();
    }

    public static void o(String str, String str2) {
        d1.a(str, str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void o0(int i2, String str) {
        if (a1 == i2) {
            return;
        }
        if (!this.f9206k) {
            if (i2 > b1 || i2 < 1) {
                a1 = 1;
            }
            y0();
        }
        if (i2 > MyApplication.b().o || i2 < 1) {
            return;
        }
        int i3 = i2 - 1;
        if (!MyApplication.b().C.get(i3).e().equals("") && !MyApplication.b().C.get(i3).e().equals(str)) {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.access_error), 1).show();
            return;
        }
        a1 = i2;
        y0();
    }

    private void t0() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getResources().getString(R.string.dialog_purchases_message, ru.himik.nightscream.kascada.Utils.l.a.j(true))).setTitle(R.string.dialog_purchases_title);
        builder.setPositiveButton(R.string.dialog_purchases_buy, new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.g
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.a.R(dialogInterface, i2);
            }
        });
        builder.setNeutralButton("Ввести ключ", new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.e
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.a.T(dialogInterface, i2);
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.d
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                mbCanvas.M(dialogInterface, i2);
            }
        });
        builder.create().show();
        if (MyApplication.b().z0.isEmpty()) {
            return;
        }
        AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
        builder2.setMessage(MyApplication.b().z0).setTitle(R.string.attention);
        builder2.setPositiveButton(R.string.open_site, new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.o
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.a.O(dialogInterface, i2);
            }
        });
        builder2.setNegativeButton(getResources().getString(R.string.dialog_cancel), new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.c
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.dismiss();
            }
        });
        builder2.create().show();
    }

    private boolean u() {
        boolean z2;
        ArrayList arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT >= 16) {
            if (e.g.e.a.a(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
                arrayList.add("android.permission.READ_EXTERNAL_STORAGE");
                z2 = false;
            } else {
                z2 = true;
            }
            if (e.g.e.a.a(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
                arrayList.add("android.permission.WRITE_EXTERNAL_STORAGE");
                z2 = false;
            }
            if (MyApplication.b().f0.size() > 0 && e.g.e.a.a(this, "android.permission.RECORD_AUDIO") != 0) {
                arrayList.add("android.permission.RECORD_AUDIO");
                z2 = false;
            }
            if (MyApplication.b().N.size() > 0 && e.g.e.a.a(this, "android.permission.SEND_SMS") != 0) {
                arrayList.add("android.permission.SEND_SMS");
                z2 = false;
            }
            if (MyApplication.b().V.size() > 0 && e.g.e.a.a(this, "android.permission.RECEIVE_SMS") != 0) {
                arrayList.add("android.permission.RECEIVE_SMS");
                z2 = false;
            }
            for (int i2 = 0; i2 < MyApplication.b().D.size(); i2++) {
                int iKeyAt = MyApplication.b().D.keyAt(i2);
                if ((MyApplication.b().D.get(iKeyAt) instanceof Sunrise_GPS) || (MyApplication.b().D.get(iKeyAt) instanceof Sensor_Speed)) {
                    if (e.g.e.a.a(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                        break;
                    }
                    arrayList.add("android.permission.ACCESS_FINE_LOCATION");
                    z2 = false;
                    break;
                }
            }
            if (!z2) {
                Dexter.withActivity(this).withPermissions(arrayList).withListener(new e()).check();
                return false;
            }
        }
        return true;
    }

    public void A0() {
        String string;
        String string2 = MyApplication.b().g0.getString(MyApplication.b().m0, "");
        if (string2.isEmpty()) {
            string = getString(R.string.toast_not_found_url_for_project);
        } else {
            if (URLUtil.isValidUrl(string2)) {
                B0(true);
                this.m0.setVisibility(0);
                new n0(1000L, 500L, string2).start();
                return;
            }
            string = "Url is not valid";
        }
        g.a.a.e.b(this, string, 1).show();
    }

    public void B() {
        if ("mounted".equals(Environment.getExternalStorageState())) {
            new Thread(new b0(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getFileName())).start();
            return;
        }
        if ("mounted_ro".equals(Environment.getExternalStorageState())) {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.export_csv_error) + " №1", 1).show();
            return;
        }
        Toast.makeText(getApplicationContext(), getResources().getString(R.string.export_csv_error) + " №2", 1).show();
    }

    public void B0(boolean z2) {
        i.b.q.b<ru.himik.nightscream.kascada.Utils.m> bVar;
        ru.himik.nightscream.kascada.Utils.m mVar;
        this.f9206k = false;
        ru.himik.nightscream.kascada.b0.d.a.p().onFinish();
        i.b.l.a aVar = this.n0;
        if (aVar != null) {
            aVar.d();
        }
        this.c0.setVisibility(0);
        this.b0.setVisibility(0);
        this.W.setVisibility(0);
        this.a.setVisibility(0);
        this.f9208m.setBackgroundResource(R.drawable.start);
        d1.c();
        if (a1 > 1) {
            findViewById(R.id.lockScreen).setVisibility(0);
        }
        MyApplication.b().h();
        for (int i2 = 0; i2 < MyApplication.b().M.size(); i2++) {
            int iKeyAt = MyApplication.b().M.keyAt(i2);
            if (((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt)).invalidate();
        }
        for (int i3 = 0; i3 < MyApplication.b().U.size(); i3++) {
            int iKeyAt2 = MyApplication.b().U.keyAt(i3);
            if (!z2) {
                ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt2)).b(false);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt2)).setOnClickListener(this.t0);
            ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt2)).setOnTouchListener(null);
            ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt2)).invalidate();
        }
        for (int i4 = 0; i4 < MyApplication.b().N.size(); i4++) {
            int iKeyAt3 = MyApplication.b().N.keyAt(i4);
            if (((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt3)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt3)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt3)).invalidate();
        }
        for (int i5 = 0; i5 < MyApplication.b().V.size(); i5++) {
            int iKeyAt4 = MyApplication.b().V.keyAt(i5);
            if (((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt4)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt4)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt4)).invalidate();
        }
        for (int i6 = 0; i6 < MyApplication.b().W.size(); i6++) {
            int iKeyAt5 = MyApplication.b().W.keyAt(i6);
            if (((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt5)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt5)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt5)).invalidate();
        }
        for (int i7 = 0; i7 < MyApplication.b().Y.size(); i7++) {
            int iKeyAt6 = MyApplication.b().Y.keyAt(i7);
            if (((CustomSound) MyApplication.b().Y.get(iKeyAt6)).getNumScreen() == a1) {
                ((CustomSound) MyApplication.b().Y.get(iKeyAt6)).setVisibility(0);
            }
            ((CustomSound) MyApplication.b().Y.get(iKeyAt6)).invalidate();
        }
        for (int i8 = 0; i8 < MyApplication.b().Z.size(); i8++) {
            int iKeyAt7 = MyApplication.b().Z.keyAt(i8);
            if (((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt7)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt7)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt7)).invalidate();
        }
        for (int i9 = 0; i9 < MyApplication.b().a0.size(); i9++) {
            int iKeyAt8 = MyApplication.b().a0.keyAt(i9);
            if (((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt8)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt8)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt8)).invalidate();
        }
        for (int i10 = 0; i10 < MyApplication.b().c0.size(); i10++) {
            int iKeyAt9 = MyApplication.b().c0.keyAt(i10);
            if (((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt9)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt9)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt9)).invalidate();
        }
        for (int i11 = 0; i11 < MyApplication.b().f0.size(); i11++) {
            int iKeyAt10 = MyApplication.b().f0.keyAt(i11);
            if (((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt10)).getNumScreen() == a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt10)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt10)).invalidate();
        }
        for (int i12 = 0; i12 < Y0.size(); i12++) {
            Y0.get(i12).cancel();
        }
        Y0.clear();
        ru.himik.nightscream.kascada.Utils.o oVar = h1;
        if (oVar != null) {
            oVar.a();
        }
        g0(false, MyApplication.b().f9039g);
        C().c().i(MyApplication.b().D);
        C().q0.h();
        C().r0.h();
        try {
            C().t0.unregisterListener(this.w0);
        } catch (Exception unused) {
        }
        try {
            C().s0.removeUpdates(this.v0);
        } catch (Exception unused2) {
        }
        y0();
        if (z2) {
            bVar = MyApplication.b().a;
            mVar = new ru.himik.nightscream.kascada.Utils.m(6);
        } else {
            bVar = MyApplication.b().a;
            mVar = new ru.himik.nightscream.kascada.Utils.m(4);
        }
        bVar.d(mVar);
    }

    public MyApplication C() {
        return (MyApplication) getApplication();
    }

    /* JADX WARN: Code duplicated, block: B:103:0x045f  */
    /* JADX WARN: Code duplicated, block: B:105:0x0471  */
    /* JADX WARN: Code duplicated, block: B:107:0x0497  */
    /* JADX WARN: Code duplicated, block: B:120:0x0547  */
    /* JADX WARN: Code duplicated, block: B:122:0x055a  */
    /* JADX WARN: Code duplicated, block: B:124:0x0580  */
    /* JADX WARN: Code duplicated, block: B:445:0x198a  */
    /* JADX WARN: Code duplicated, block: B:448:0x19a9  */
    /* JADX WARN: Code duplicated, block: B:557:0x20a5  */
    /* JADX WARN: Code duplicated, block: B:560:0x20c4  */
    /* JADX WARN: Code duplicated, block: B:720:0x0624 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:81:0x0328  */
    public void C0(boolean z2) {
        ru.himik.nightscream.kascada.Utils.m mVar;
        ru.himik.nightscream.kascada.CustomComponents.b bVar;
        byte b2;
        ru.himik.nightscream.kascada.CustomComponents.b bVar2;
        byte b3;
        ArrayList<ru.himik.nightscream.kascada.q.a> arrayList;
        ru.himik.nightscream.kascada.q.a cloudConnector;
        if (this.f9206k) {
            return;
        }
        if (MyApplication.b().f0.size() > 0) {
            this.n0.c(MyApplication.b().b.n(i.b.k.b.a.a()).j(new i.b.n.c() { // from class: ru.himik.nightscream.kascada.f
                @Override // i.b.n.c
                public final void a(Object obj) {
                    this.a.W((String) obj);
                }
            }, new i.b.n.c() { // from class: ru.himik.nightscream.kascada.n
                @Override // i.b.n.c
                public final void a(Object obj) {
                    mbCanvas.X((Throwable) obj);
                }
            }));
            String strB = ru.himik.nightscream.kascada.Utils.n.a.b();
            if (!strB.equals("")) {
                new AlertDialog.Builder(this).setTitle(R.string.dialog_voice_rec_download).setMessage(getResources().getString(R.string.dialog_voice_rec_check_model_error1) + " " + strB + " " + getResources().getString(R.string.dialog_voice_rec_check_model_error2) + " " + getResources().getString(R.string.dialog_voice_rec_check_model_error3)).setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.i
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i2) {
                        this.a.Z(dialogInterface, i2);
                    }
                }).setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.j
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i2) {
                        dialogInterface.dismiss();
                    }
                }).create().show();
                return;
            }
            ru.himik.nightscream.kascada.b0.d dVar = ru.himik.nightscream.kascada.b0.d.a;
            if (!dVar.l()) {
                ru.himik.nightscream.kascada.r.h0.p(this, getResources().getString(R.string.voice_cpu_abi_not_support));
                return;
            }
            dVar.x();
        }
        this.f9206k = true;
        C().c().i(MyApplication.b().D);
        C().c().a(MyApplication.b().D);
        if (u()) {
            this.f9207l.setVisibility(4);
            this.a0.setVisibility(0);
            q(false);
            MyApplication.b().o = 1;
            this.c0.setVisibility(4);
            this.b0.setVisibility(4);
            boolean z3 = false;
            boolean z4 = false;
            boolean z5 = false;
            boolean z6 = false;
            for (int i2 = 0; i2 < MyApplication.b().D.size(); i2++) {
                int iKeyAt = MyApplication.b().D.keyAt(i2);
                ((View) MyApplication.b().D.get(iKeyAt)).setVisibility(4);
                if ((MyApplication.b().D.get(iKeyAt) instanceof Sensor_Orientation) && !z5) {
                    try {
                        C().t0.registerListener(this.w0, C().t0.getDefaultSensor(3), 3);
                    } catch (Exception unused) {
                        Toast.makeText(this, getResources().getString(R.string.error_register_listener_sensor_orientation), 1).show();
                    }
                    z5 = true;
                }
                if ((MyApplication.b().D.get(iKeyAt) instanceof Sunrise_GPS) && !z3) {
                    z3 = true;
                }
                if ((MyApplication.b().D.get(iKeyAt) instanceof Sensor_Speed) && !z4) {
                    z4 = true;
                }
                if ((MyApplication.b().D.get(iKeyAt) instanceof Sensor_Light) && !z6) {
                    try {
                        C().t0.registerListener(this.w0, C().t0.getDefaultSensor(5), 3);
                    } catch (Exception unused2) {
                        Toast.makeText(this, getResources().getString(R.string.error_register_listener_sensor_light), 1).show();
                    }
                    z6 = true;
                }
            }
            if (z3 || z4) {
                int i3 = YandexMetricaDefaultValues.DEFAULT_MAX_REPORTS_COUNT_UPPER_BOUND;
                if (z4) {
                    i3 = 0;
                }
                try {
                    C().s0.requestLocationUpdates("gps", i3, 0, this.v0);
                } catch (Exception unused3) {
                    Toast.makeText(this, getResources().getString(R.string.error_register_listener_gps), 0).show();
                }
                if (!C().s0.isProviderEnabled("gps")) {
                    Toast.makeText(this, R.string.message_enable_gps, 0).show();
                }
            }
            boolean z7 = false;
            for (int i4 = 0; i4 < MyApplication.b().f9042j; i4++) {
                int i5 = 0;
                while (true) {
                    if (i5 < MyApplication.b().f9036d.size()) {
                        if (MyApplication.b().f9036d.get(i5).c() != 1) {
                            if (MyApplication.b().f9036d.get(i5).c() == 2) {
                                if (MyApplication.b().f9036d.get(i5).c() != 3) {
                                    if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                        if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h()) || i4 + 1 > MyApplication.b().f9042j) {
                                            MyApplication.b().E.get(i4).o(false);
                                        } else {
                                            MyApplication.b().E.get(i4).o(true);
                                            boolean z8 = false;
                                            for (int i6 = 0; i6 < Y0.size(); i6++) {
                                                if (Y0.get(i6).b().equals(MyApplication.b().f9036d.get(i5).h())) {
                                                    MyApplication.b().E.get(i4).l(i6);
                                                    z8 = true;
                                                }
                                            }
                                            if (!z8) {
                                                arrayList = Y0;
                                                cloudConnector = new CloudConnector(MyApplication.b().f9036d.get(i5).h(), this.C, i5, this.P, this, MyApplication.b().f9044l, MyApplication.b().f9036d.get(i5).g());
                                                arrayList.add(cloudConnector);
                                                MyApplication.b().E.get(i4).l(Y0.size() - 1);
                                            }
                                        }
                                    }
                                    i5++;
                                } else if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h()) || i4 + 1 > MyApplication.b().f9042j) {
                                    MyApplication.b().E.get(i4).o(false);
                                    if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                        if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                        }
                                        MyApplication.b().E.get(i4).o(false);
                                    }
                                    i5++;
                                } else {
                                    MyApplication.b().E.get(i4).o(true);
                                    boolean z9 = false;
                                    for (int i7 = 0; i7 < Y0.size(); i7++) {
                                        if (Y0.get(i7).b().equals(MyApplication.b().f9036d.get(i5).h())) {
                                            MyApplication.b().E.get(i4).l(i7);
                                            z9 = true;
                                        }
                                    }
                                    if (!z9) {
                                        Y0.add(new ru.himik.nightscream.kascada.q.e.a(MyApplication.b().f9036d.get(i5), this.C, i5, this, this.P, MyApplication.b().f9036d.get(i5).g()));
                                        MyApplication.b().E.get(i4).l(Y0.size() - 1);
                                    }
                                }
                            } else if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).i()) || i4 + 1 > MyApplication.b().f9042j) {
                                MyApplication.b().E.get(i4).o(false);
                                if (MyApplication.b().f9036d.get(i5).c() != 3) {
                                    if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                        if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                        }
                                        MyApplication.b().E.get(i4).o(false);
                                    }
                                    i5++;
                                } else {
                                    if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                    }
                                    MyApplication.b().E.get(i4).o(false);
                                    if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                        if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                        }
                                        MyApplication.b().E.get(i4).o(false);
                                    }
                                    i5++;
                                }
                            } else {
                                try {
                                    int i8 = Integer.parseInt(MyApplication.b().f9036d.get(i5).h());
                                    if (i8 >= 65535 || i8 <= 0 || MyApplication.b().f9036d.get(i5).d().length() <= 3) {
                                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.connect_with_this_network_settings_impossibly), 0).show();
                                    }
                                    MyApplication.b().E.get(i4).o(true);
                                    boolean z10 = false;
                                    for (int i9 = 0; i9 < Y0.size(); i9++) {
                                        if (Y0.get(i9).b().equals(MyApplication.b().f9036d.get(i5).i())) {
                                            MyApplication.b().E.get(i4).l(i9);
                                            z10 = true;
                                        }
                                    }
                                    if (!z10) {
                                        cloudConnector = wifiConnector;
                                        arrayList = Y0;
                                        WifiConnector wifiConnector = new WifiConnector(MyApplication.b().f9036d.get(i5).d(), Integer.parseInt(MyApplication.b().f9036d.get(i5).h()), this.C, i5, this.P, this, MyApplication.b().f9036d.get(i5).g());
                                        arrayList.add(cloudConnector);
                                        MyApplication.b().E.get(i4).l(Y0.size() - 1);
                                    }
                                } catch (Exception unused4) {
                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.port_connection_wrong), 0).show();
                                }
                            }
                        } else if (!MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h()) || i4 + 1 > MyApplication.b().f9042j) {
                            MyApplication.b().E.get(i4).o(false);
                            if (MyApplication.b().f9036d.get(i5).c() == 2) {
                                if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).i())) {
                                }
                                MyApplication.b().E.get(i4).o(false);
                                if (MyApplication.b().f9036d.get(i5).c() != 3) {
                                    if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                        if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                        }
                                        MyApplication.b().E.get(i4).o(false);
                                    }
                                    i5++;
                                } else {
                                    if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                    }
                                    MyApplication.b().E.get(i4).o(false);
                                    if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                        if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                        }
                                        MyApplication.b().E.get(i4).o(false);
                                    }
                                    i5++;
                                }
                            } else if (MyApplication.b().f9036d.get(i5).c() != 3) {
                                if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                    if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                    }
                                    MyApplication.b().E.get(i4).o(false);
                                }
                                i5++;
                            } else {
                                if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                }
                                MyApplication.b().E.get(i4).o(false);
                                if (MyApplication.b().f9036d.get(i5).c() != 4) {
                                    if (MyApplication.b().E.get(i4).e().equals(MyApplication.b().f9036d.get(i5).h())) {
                                    }
                                    MyApplication.b().E.get(i4).o(false);
                                }
                                i5++;
                            }
                        } else {
                            MyApplication.b().E.get(i4).o(true);
                            boolean z11 = false;
                            for (int i10 = 0; i10 < Y0.size(); i10++) {
                                if (Y0.get(i10).b().equals(MyApplication.b().f9036d.get(i5).h())) {
                                    MyApplication.b().E.get(i4).l(i10);
                                    z11 = true;
                                }
                            }
                            if (!z11) {
                                Y0.add(new ru.himik.nightscream.kascada.Connections.Bluetooth.b(MyApplication.b().f9036d.get(i5).h(), this.C, i5, MyApplication.b().f9036d.get(i5).g()));
                                MyApplication.b().E.get(i4).l(Y0.size() - 1);
                            }
                            z7 = true;
                        }
                    }
                }
            }
            if (z7) {
                BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
                if (defaultAdapter == null) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_access_to_bluetooth), 0).show();
                    B0(false);
                    return;
                }
                if (!defaultAdapter.isEnabled()) {
                    startActivityForResult(new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE"), 0);
                }
                if (!defaultAdapter.isEnabled()) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.turn_on_bluetooth_and_try_again), 0).show();
                    B0(false);
                    return;
                }
            }
            for (int i11 = 0; i11 < MyApplication.b().F.size(); i11++) {
                int iKeyAt2 = MyApplication.b().F.keyAt(i11);
                ru.himik.nightscream.kascada.CustomComponents.y yVar = (ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(iKeyAt2);
                if (yVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = yVar.getNumScreen();
                }
                if (yVar.d()) {
                    yVar.setBackgroundColor(0);
                }
                if (yVar.f8943g.l() >= 0 && yVar.f8943g.l() != 100 && MyApplication.b().E.get(yVar.f8943g.l()).h()) {
                    yVar.f8943g.B(MyApplication.b().E.get(yVar.f8943g.l()).b());
                    yVar.f8943g.F(MyApplication.b().E.get(yVar.f8943g.l()).g());
                    yVar.f8943g.D(MyApplication.b().E.get(yVar.f8943g.l()).d());
                    yVar.f8943g.u((byte) MyApplication.b().E.get(yVar.f8943g.l()).a());
                }
                yVar.f8943g.C(iKeyAt2);
            }
            for (int i12 = 0; i12 < MyApplication.b().H.size(); i12++) {
                int iKeyAt3 = MyApplication.b().H.keyAt(i12);
                ru.himik.nightscream.kascada.CustomComponents.u uVar = (ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(iKeyAt3);
                if (uVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = uVar.getNumScreen();
                }
                if (uVar.f8903k.l() >= 0) {
                    if (uVar.f8903k.l() == 100) {
                        MyApplication.b().v0.f(uVar.f8903k);
                    } else if (MyApplication.b().E.get(uVar.f8903k.l()).h()) {
                        uVar.f8903k.D(MyApplication.b().E.get(uVar.f8903k.l()).d());
                        uVar.f8903k.u((byte) MyApplication.b().E.get(uVar.f8903k.l()).a());
                        uVar.f8903k.B(MyApplication.b().E.get(uVar.f8903k.l()).b());
                        uVar.f8903k.F(MyApplication.b().E.get(uVar.f8903k.l()).g());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar3 = uVar.f8903k;
                        bVar3.x(this.o.c(bVar3, bVar3.i()));
                        Y0.get(uVar.f8903k.k()).f(uVar.f8903k);
                    }
                }
                uVar.f8903k.C(iKeyAt3);
            }
            for (int i13 = 0; i13 < MyApplication.b().I.size(); i13++) {
                int iKeyAt4 = MyApplication.b().I.keyAt(i13);
                ru.himik.nightscream.kascada.CustomComponents.q qVar = (ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt4);
                if (qVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = qVar.getNumScreen();
                }
                if (qVar.f8865g.l() >= 0) {
                    if (qVar.f8865g.l() == 100) {
                        MyApplication.b().v0.f(qVar.f8865g);
                    } else if (MyApplication.b().E.get(qVar.f8865g.l()).h()) {
                        qVar.f8865g.D(MyApplication.b().E.get(qVar.f8865g.l()).d());
                        qVar.f8865g.u((byte) MyApplication.b().E.get(qVar.f8865g.l()).a());
                        qVar.f8865g.B(MyApplication.b().E.get(qVar.f8865g.l()).b());
                        qVar.f8865g.F(MyApplication.b().E.get(qVar.f8865g.l()).g());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar4 = qVar.f8865g;
                        bVar4.x(this.o.c(bVar4, bVar4.i()));
                        Y0.get(qVar.f8865g.k()).f(qVar.f8865g);
                    }
                }
                qVar.f8865g.C(iKeyAt4);
            }
            for (int i14 = 0; i14 < MyApplication.b().J.size(); i14++) {
                int iKeyAt5 = MyApplication.b().J.keyAt(i14);
                ru.himik.nightscream.kascada.CustomComponents.e eVar = (ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt5);
                if (eVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = eVar.getNumScreen();
                }
                if (eVar.m()) {
                    eVar.setBackgroundColor(0);
                }
                eVar.setOnTouchListener(this.E0);
                if (eVar.f8769i.l() >= 0 && eVar.f8769i.l() != 100 && MyApplication.b().E.get(eVar.f8769i.l()).h()) {
                    eVar.f8769i.D(MyApplication.b().E.get(eVar.f8769i.l()).d());
                    eVar.f8769i.B(MyApplication.b().E.get(eVar.f8769i.l()).b());
                    eVar.f8769i.F(MyApplication.b().E.get(eVar.f8769i.l()).g());
                    eVar.f8769i.u((byte) MyApplication.b().E.get(eVar.f8769i.l()).a());
                }
                eVar.f8769i.C(iKeyAt5);
            }
            for (int i15 = 0; i15 < MyApplication.b().K.size(); i15++) {
                int iKeyAt6 = MyApplication.b().K.keyAt(i15);
                CustomDynText customDynText = (CustomDynText) MyApplication.b().K.get(iKeyAt6);
                if (customDynText.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = customDynText.getNumScreen();
                }
                if (customDynText.f8667i.l() >= 0) {
                    if (customDynText.f8667i.l() == 100) {
                        MyApplication.b().v0.f(customDynText.f8667i);
                    } else if (MyApplication.b().E.get(customDynText.f8667i.l()).h()) {
                        customDynText.f8667i.D(MyApplication.b().E.get(customDynText.f8667i.l()).d());
                        customDynText.f8667i.u((byte) MyApplication.b().E.get(customDynText.f8667i.l()).a());
                        customDynText.f8667i.B(MyApplication.b().E.get(customDynText.f8667i.l()).b());
                        customDynText.f8667i.F(MyApplication.b().E.get(customDynText.f8667i.l()).g());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar5 = customDynText.f8667i;
                        bVar5.x(this.o.c(bVar5, bVar5.i()));
                        Y0.get(customDynText.f8667i.k()).f(customDynText.f8667i);
                    }
                }
                customDynText.f8667i.C(iKeyAt6);
            }
            for (int i16 = 0; i16 < MyApplication.b().L.size(); i16++) {
                int iKeyAt7 = MyApplication.b().L.keyAt(i16);
                ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(iKeyAt7);
                if (iVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = iVar.getNumScreen();
                }
                if (iVar.f8813j.l() >= 0 && iVar.f8813j.l() != 100 && MyApplication.b().E.get(iVar.f8813j.l()).h()) {
                    iVar.f8813j.D(MyApplication.b().E.get(iVar.f8813j.l()).d());
                    iVar.f8813j.B(MyApplication.b().E.get(iVar.f8813j.l()).b());
                    iVar.f8813j.F(MyApplication.b().E.get(iVar.f8813j.l()).g());
                    iVar.f8813j.u((byte) MyApplication.b().E.get(iVar.f8813j.l()).a());
                }
                iVar.f8813j.C(iKeyAt7);
            }
            for (int i17 = 0; i17 < MyApplication.b().M.size(); i17++) {
                int iKeyAt8 = MyApplication.b().M.keyAt(i17);
                ru.himik.nightscream.kascada.CustomComponents.c cVar = (ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt8);
                if (cVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = cVar.getNumScreen();
                }
                if (cVar.f8742h.l() >= 0) {
                    if (cVar.f8742h.l() == 100) {
                        MyApplication.b().v0.f(cVar.f8742h);
                    } else if (MyApplication.b().E.get(cVar.f8742h.l()).h()) {
                        cVar.f8742h.D(MyApplication.b().E.get(cVar.f8742h.l()).d());
                        cVar.f8742h.u((byte) MyApplication.b().E.get(cVar.f8742h.l()).a());
                        cVar.f8742h.B(MyApplication.b().E.get(cVar.f8742h.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar6 = cVar.f8742h;
                        bVar6.x(this.o.c(bVar6, bVar6.i()));
                        cVar.f8742h.F(MyApplication.b().E.get(cVar.f8742h.l()).g());
                        Y0.get(cVar.f8742h.k()).f(cVar.f8742h);
                    }
                    cVar.b();
                }
                cVar.f8742h.C(iKeyAt8);
                cVar.setVisibility(4);
                cVar.invalidate();
            }
            for (int i18 = 0; i18 < MyApplication.b().N.size(); i18++) {
                int iKeyAt9 = MyApplication.b().N.keyAt(i18);
                ru.himik.nightscream.kascada.CustomComponents.w wVar = (ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt9);
                if (wVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = wVar.getNumScreen();
                }
                if (wVar.f8921g.l() >= 0) {
                    if (wVar.f8921g.l() == 100) {
                        MyApplication.b().v0.f(wVar.f8921g);
                    } else if (MyApplication.b().E.get(wVar.f8921g.l()).h()) {
                        wVar.f8921g.D(MyApplication.b().E.get(wVar.f8921g.l()).d());
                        wVar.f8921g.u((byte) MyApplication.b().E.get(wVar.f8921g.l()).a());
                        wVar.f8921g.B(MyApplication.b().E.get(wVar.f8921g.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar7 = wVar.f8921g;
                        bVar7.x(this.o.c(bVar7, bVar7.i()));
                        wVar.f8921g.F(MyApplication.b().E.get(wVar.f8921g.l()).g());
                        Y0.get(wVar.f8921g.k()).f(wVar.f8921g);
                    }
                }
                wVar.f8921g.C(iKeyAt9);
                wVar.setVisibility(4);
                wVar.invalidate();
            }
            for (int i19 = 0; i19 < MyApplication.b().O.size(); i19++) {
                int iKeyAt10 = MyApplication.b().O.keyAt(i19);
                ru.himik.nightscream.kascada.CustomComponents.r rVar = (ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt10);
                if (rVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = rVar.getNumScreen();
                }
                if (rVar.f8874e.l() >= 0) {
                    if (rVar.f8874e.l() == 100) {
                        MyApplication.b().v0.f(rVar.f8874e);
                    } else if (MyApplication.b().E.get(rVar.f8874e.l()).h()) {
                        rVar.f8874e.D(MyApplication.b().E.get(rVar.f8874e.l()).d());
                        rVar.f8874e.u((byte) MyApplication.b().E.get(rVar.f8874e.l()).a());
                        rVar.f8874e.B(MyApplication.b().E.get(rVar.f8874e.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar8 = rVar.f8874e;
                        bVar8.x(this.o.c(bVar8, bVar8.i()));
                        rVar.f8874e.F(MyApplication.b().E.get(rVar.f8874e.l()).g());
                        Y0.get(rVar.f8874e.k()).f(rVar.f8874e);
                    }
                    rVar.invalidate();
                }
                rVar.f8874e.C(iKeyAt10);
            }
            for (int i20 = 0; i20 < MyApplication.b().P.size(); i20++) {
                int iKeyAt11 = MyApplication.b().P.keyAt(i20);
                ru.himik.nightscream.kascada.CustomComponents.g gVar = (ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt11);
                if (gVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = gVar.getNumScreen();
                }
                if (gVar.I.l() >= 0) {
                    if (gVar.I.l() == 100) {
                        MyApplication.b().v0.f(gVar.I);
                    } else if (MyApplication.b().E.get(gVar.I.l()).h()) {
                        gVar.I.D(MyApplication.b().E.get(gVar.I.l()).d());
                        gVar.I.u((byte) MyApplication.b().E.get(gVar.I.l()).a());
                        gVar.I.B(MyApplication.b().E.get(gVar.I.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar9 = gVar.I;
                        bVar9.x(this.o.c(bVar9, bVar9.i()));
                        gVar.I.F(MyApplication.b().E.get(gVar.I.l()).g());
                        Y0.get(gVar.I.k()).f(gVar.I);
                    }
                    gVar.invalidate();
                }
                gVar.I.C(iKeyAt11);
            }
            for (int i21 = 0; i21 < MyApplication.b().Q.size(); i21++) {
                int iKeyAt12 = MyApplication.b().Q.keyAt(i21);
                ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(iKeyAt12);
                if (vVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = vVar.getNumScreen();
                }
                vVar.setEnableOnTouch(true);
                if (vVar.f8909f.l() >= 0) {
                    if (vVar.f8909f.l() == 100) {
                        vVar.invalidate();
                    } else if (MyApplication.b().E.get(vVar.f8909f.l()).h()) {
                        vVar.f8909f.D(MyApplication.b().E.get(vVar.f8909f.l()).d());
                        vVar.f8909f.u((byte) MyApplication.b().E.get(vVar.f8909f.l()).a());
                        vVar.f8909f.B(MyApplication.b().E.get(vVar.f8909f.l()).b());
                        vVar.f8909f.F(MyApplication.b().E.get(vVar.f8909f.l()).g());
                        vVar.invalidate();
                    }
                }
                vVar.f8909f.C(iKeyAt12);
            }
            for (int i22 = 0; i22 < MyApplication.b().R.size(); i22++) {
                int iKeyAt13 = MyApplication.b().R.keyAt(i22);
                ru.himik.nightscream.kascada.CustomComponents.o oVar = (ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt13);
                if (oVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = oVar.getNumScreen();
                }
                if (oVar.T.l() >= 0) {
                    if (oVar.T.l() == 100) {
                        oVar.setWorkMode(true);
                        oVar.invalidate();
                    } else if (MyApplication.b().E.get(oVar.T.l()).h()) {
                        oVar.T.D(MyApplication.b().E.get(oVar.T.l()).d());
                        oVar.T.u((byte) MyApplication.b().E.get(oVar.T.l()).a());
                        oVar.T.B(MyApplication.b().E.get(oVar.T.l()).b());
                        oVar.T.F(MyApplication.b().E.get(oVar.T.l()).g());
                        oVar.setWorkMode(true);
                        oVar.invalidate();
                    }
                }
                oVar.T.C(iKeyAt13);
            }
            for (int i23 = 0; i23 < MyApplication.b().S.size(); i23++) {
                int iKeyAt14 = MyApplication.b().S.keyAt(i23);
                ru.himik.nightscream.kascada.CustomComponents.d dVar2 = (ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(iKeyAt14);
                if (dVar2.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = dVar2.getNumScreen();
                }
                if (dVar2.f8753h.l() >= 0) {
                    if (dVar2.f8753h.l() == 100) {
                        MyApplication.b().v0.f(dVar2.f8753h);
                    } else if (MyApplication.b().E.get(dVar2.f8753h.l()).h()) {
                        dVar2.f8753h.D(MyApplication.b().E.get(dVar2.f8753h.l()).d());
                        dVar2.f8753h.u((byte) MyApplication.b().E.get(dVar2.f8753h.l()).a());
                        dVar2.f8753h.B(MyApplication.b().E.get(dVar2.f8753h.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar10 = dVar2.f8753h;
                        bVar10.x(this.o.c(bVar10, bVar10.i()));
                        dVar2.f8753h.F(MyApplication.b().E.get(dVar2.f8753h.l()).g());
                        Y0.get(dVar2.f8753h.k()).f(dVar2.f8753h);
                    }
                }
                if (dVar2.f8754i.l() >= 0) {
                    if (dVar2.f8754i.l() == 100) {
                        if (dVar2.i()) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar11 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar11.L((byte) 1);
                            bVar11.C(iKeyAt14);
                            bVar11.v(dVar2.getRegResetArchive());
                            bVar11.t((byte) dVar2.getBitResetArchive());
                            bVar11.A(151);
                            MyApplication.b().v0.f(bVar11);
                        }
                        if (dVar2.j()) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar12 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar12.L((byte) 1);
                            bVar12.C(iKeyAt14);
                            bVar12.v(dVar2.getRegSendToCloudArchive());
                            bVar12.t((byte) dVar2.getBitSendToCloudArchive());
                            bVar12.A(154);
                            MyApplication.b().v0.f(bVar12);
                        }
                    } else if (MyApplication.b().E.get(dVar2.f8754i.l()).h()) {
                        dVar2.f8754i.D(MyApplication.b().E.get(dVar2.f8754i.l()).d());
                        dVar2.f8754i.u((byte) MyApplication.b().E.get(dVar2.f8754i.l()).a());
                        dVar2.f8754i.B(MyApplication.b().E.get(dVar2.f8754i.l()).b());
                        dVar2.f8754i.F(MyApplication.b().E.get(dVar2.f8754i.l()).g());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar13 = dVar2.f8754i;
                        bVar13.x(this.o.c(bVar13, bVar13.i()));
                        if (dVar2.i()) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar14 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar14.D(MyApplication.b().E.get(dVar2.f8754i.l()).d());
                            bVar14.u((byte) MyApplication.b().E.get(dVar2.f8754i.l()).a());
                            bVar14.B(MyApplication.b().E.get(dVar2.f8754i.l()).b());
                            bVar14.F(MyApplication.b().E.get(dVar2.f8754i.l()).g());
                            bVar14.L((byte) 1);
                            bVar14.C(iKeyAt14);
                            bVar14.v(dVar2.getRegResetArchive());
                            bVar14.t((byte) dVar2.getBitResetArchive());
                            bVar14.A(151);
                            Y0.get(bVar14.k()).f(bVar14);
                        }
                        if (dVar2.j()) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar15 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar15.D(MyApplication.b().E.get(dVar2.f8754i.l()).d());
                            bVar15.u((byte) MyApplication.b().E.get(dVar2.f8754i.l()).a());
                            bVar15.B(MyApplication.b().E.get(dVar2.f8754i.l()).b());
                            bVar15.F(MyApplication.b().E.get(dVar2.f8754i.l()).g());
                            bVar15.L((byte) 1);
                            bVar15.C(iKeyAt14);
                            bVar15.v(dVar2.getRegSendToCloudArchive());
                            bVar15.t((byte) dVar2.getBitSendToCloudArchive());
                            bVar15.A(154);
                            Y0.get(bVar15.k()).f(bVar15);
                        }
                    }
                }
                dVar2.f8754i.C(iKeyAt14);
                dVar2.f8753h.C(iKeyAt14);
                dVar2.invalidate();
                dVar2.q(true);
            }
            for (int i24 = 0; i24 < MyApplication.b().T.size(); i24++) {
                int iKeyAt15 = MyApplication.b().T.keyAt(i24);
                ru.himik.nightscream.kascada.CustomComponents.n nVar = (ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt15);
                if (nVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = nVar.getNumScreen();
                }
                if (nVar.f8854g.l() >= 0) {
                    if (nVar.f8854g.l() == 100) {
                        MyApplication.b().v0.f(nVar.f8854g);
                    } else if (MyApplication.b().E.get(nVar.f8854g.l()).h()) {
                        nVar.f8854g.D(MyApplication.b().E.get(nVar.f8854g.l()).d());
                        nVar.f8854g.u((byte) MyApplication.b().E.get(nVar.f8854g.l()).a());
                        nVar.f8854g.B(MyApplication.b().E.get(nVar.f8854g.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar16 = nVar.f8854g;
                        bVar16.x(this.o.c(bVar16, bVar16.i()));
                        nVar.f8854g.F(MyApplication.b().E.get(nVar.f8854g.l()).g());
                        Y0.get(nVar.f8854g.k()).f(nVar.f8854g);
                    }
                }
                nVar.f8854g.C(iKeyAt15);
            }
            for (int i25 = 0; i25 < MyApplication.b().U.size(); i25++) {
                int iKeyAt16 = MyApplication.b().U.keyAt(i25);
                ru.himik.nightscream.kascada.CustomComponents.h hVar = (ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt16);
                hVar.setOnTouchListener(this.K0);
                if (hVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = hVar.getNumScreen();
                }
                if (hVar.f8798e.l() >= 0) {
                    if (hVar.f8798e.l() == 100) {
                        MyApplication.b().v0.f(hVar.f8798e);
                    } else if (MyApplication.b().E.get(hVar.f8798e.l()).h()) {
                        hVar.f8798e.D(MyApplication.b().E.get(hVar.f8798e.l()).d());
                        hVar.f8798e.u((byte) MyApplication.b().E.get(hVar.f8798e.l()).a());
                        hVar.f8798e.B(MyApplication.b().E.get(hVar.f8798e.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar17 = hVar.f8798e;
                        bVar17.x(this.o.c(bVar17, bVar17.i()));
                        hVar.f8798e.F(MyApplication.b().E.get(hVar.f8798e.l()).g());
                        Y0.get(hVar.f8798e.k()).f(hVar.f8798e);
                        hVar.b(true);
                    }
                }
                hVar.f8798e.C(iKeyAt16);
            }
            for (int i26 = 0; i26 < MyApplication.b().V.size(); i26++) {
                int iKeyAt17 = MyApplication.b().V.keyAt(i26);
                ru.himik.nightscream.kascada.CustomComponents.x xVar = (ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt17);
                if (xVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = xVar.getNumScreen();
                }
                if (xVar.f8932g.l() >= 0 && xVar.f8932g.l() != 100 && MyApplication.b().E.get(xVar.f8932g.l()).h()) {
                    xVar.f8932g.D(MyApplication.b().E.get(xVar.f8932g.l()).d());
                    xVar.f8932g.B(MyApplication.b().E.get(xVar.f8932g.l()).b());
                    xVar.f8932g.F(MyApplication.b().E.get(xVar.f8932g.l()).g());
                    xVar.f8932g.u((byte) MyApplication.b().E.get(xVar.f8932g.l()).a());
                }
                xVar.f8932g.C(iKeyAt17);
                xVar.setVisibility(4);
                xVar.invalidate();
            }
            for (int i27 = 0; i27 < MyApplication.b().W.size(); i27++) {
                int iKeyAt18 = MyApplication.b().W.keyAt(i27);
                ru.himik.nightscream.kascada.CustomComponents.k kVar = (ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt18);
                if (kVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = kVar.getNumScreen();
                }
                if (kVar.f8832g.g() == 1) {
                    bVar2 = kVar.f8833h;
                    b3 = 6;
                } else {
                    bVar2 = kVar.f8833h;
                    b3 = 16;
                }
                bVar2.L(b3);
                int mode = kVar.getMode();
                if (mode == 0) {
                    if (kVar.f8832g.l() >= 0) {
                        if (kVar.f8832g.l() == 100) {
                            kVar.f8832g.C(iKeyAt18);
                            MyApplication.b().v0.f(kVar.f8832g);
                        } else if (MyApplication.b().E.get(kVar.f8832g.l()).h()) {
                            kVar.f8832g.C(iKeyAt18);
                            kVar.f8832g.B(MyApplication.b().E.get(kVar.f8832g.l()).b());
                            kVar.f8832g.F(MyApplication.b().E.get(kVar.f8832g.l()).g());
                            kVar.f8832g.D(MyApplication.b().E.get(kVar.f8832g.l()).d());
                            kVar.f8832g.u((byte) MyApplication.b().E.get(kVar.f8832g.l()).a());
                            Y0.get(kVar.f8832g.k()).f(kVar.f8832g);
                        }
                    }
                    if (kVar.f8833h.l() >= 0) {
                        if (kVar.f8833h.l() == 100) {
                            kVar.f8833h.C(iKeyAt18);
                            MyApplication.b().v0.f(kVar.f8833h);
                        } else if (MyApplication.b().E.get(kVar.f8833h.l()).h()) {
                            kVar.f8833h.C(iKeyAt18);
                            kVar.f8833h.D(MyApplication.b().E.get(kVar.f8833h.l()).d());
                            kVar.f8833h.u((byte) MyApplication.b().E.get(kVar.f8833h.l()).a());
                            kVar.f8833h.B(MyApplication.b().E.get(kVar.f8833h.l()).b());
                            kVar.f8833h.F(MyApplication.b().E.get(kVar.f8833h.l()).g());
                            Y0.get(kVar.f8833h.k()).f(kVar.f8833h);
                        }
                    }
                } else if (mode == 1) {
                    if (kVar.f8834i.l() >= 0) {
                        if (kVar.f8834i.l() == 100) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar18 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar18.C(iKeyAt18);
                            bVar18.L((byte) 1);
                            bVar18.A(com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItemSecondary);
                            bVar18.v(kVar.getRegMode());
                            bVar18.t((byte) kVar.getBitMode());
                            MyApplication.b().v0.f(bVar18);
                        } else if (MyApplication.b().E.get(kVar.f8834i.l()).h()) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar19 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar19.C(iKeyAt18);
                            bVar19.L((byte) 1);
                            bVar19.v(kVar.getRegMode());
                            bVar19.t((byte) kVar.getBitMode());
                            bVar19.A(com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItemSecondary);
                            bVar19.B(MyApplication.b().E.get(kVar.f8834i.l()).b());
                            bVar19.F(MyApplication.b().E.get(kVar.f8834i.l()).g());
                            bVar19.u((byte) MyApplication.b().E.get(kVar.f8834i.l()).a());
                            kVar.f8834i.D(MyApplication.b().E.get(kVar.f8834i.l()).d());
                            Y0.get(kVar.f8834i.k()).f(bVar19);
                        }
                    }
                    if (kVar.f8832g.l() >= 0) {
                        if (kVar.f8832g.l() == 100) {
                            kVar.f8832g.C(iKeyAt18);
                        } else if (MyApplication.b().E.get(kVar.f8832g.l()).h()) {
                            kVar.f8832g.C(iKeyAt18);
                            kVar.f8832g.B(MyApplication.b().E.get(kVar.f8832g.l()).b());
                            kVar.f8832g.F(MyApplication.b().E.get(kVar.f8832g.l()).g());
                            kVar.f8832g.D(MyApplication.b().E.get(kVar.f8832g.l()).d());
                            kVar.f8832g.u((byte) MyApplication.b().E.get(kVar.f8832g.l()).a());
                        }
                    }
                    if (kVar.f8833h.l() >= 0) {
                        if (kVar.f8833h.l() == 100) {
                            kVar.f8833h.C(iKeyAt18);
                        } else if (MyApplication.b().E.get(kVar.f8833h.l()).h()) {
                            kVar.f8833h.C(iKeyAt18);
                            kVar.f8833h.D(MyApplication.b().E.get(kVar.f8833h.l()).d());
                            kVar.f8833h.u((byte) MyApplication.b().E.get(kVar.f8833h.l()).a());
                            kVar.f8833h.B(MyApplication.b().E.get(kVar.f8833h.l()).b());
                            kVar.f8833h.F(MyApplication.b().E.get(kVar.f8833h.l()).g());
                        }
                    }
                } else if (mode == 2) {
                    if (kVar.f8832g.l() >= 0) {
                        if (kVar.f8832g.l() == 100) {
                            kVar.f8832g.C(iKeyAt18);
                            MyApplication.b().v0.f(kVar.f8832g);
                        } else if (MyApplication.b().E.get(kVar.f8832g.l()).h()) {
                            kVar.f8832g.C(iKeyAt18);
                            kVar.f8832g.B(MyApplication.b().E.get(kVar.f8832g.l()).b());
                            kVar.f8832g.F(MyApplication.b().E.get(kVar.f8832g.l()).g());
                            kVar.f8832g.D(MyApplication.b().E.get(kVar.f8832g.l()).d());
                            kVar.f8832g.u((byte) MyApplication.b().E.get(kVar.f8832g.l()).a());
                            Y0.get(kVar.f8832g.k()).f(kVar.f8832g);
                        }
                    }
                    if (kVar.f8833h.l() >= 0) {
                        if (kVar.f8833h.l() == 100) {
                            kVar.f8833h.C(iKeyAt18);
                        } else if (MyApplication.b().E.get(kVar.f8833h.l()).h()) {
                            kVar.f8833h.C(iKeyAt18);
                            kVar.f8833h.D(MyApplication.b().E.get(kVar.f8833h.l()).d());
                            kVar.f8833h.u((byte) MyApplication.b().E.get(kVar.f8833h.l()).a());
                            kVar.f8833h.B(MyApplication.b().E.get(kVar.f8833h.l()).b());
                            kVar.f8833h.F(MyApplication.b().E.get(kVar.f8833h.l()).g());
                        }
                    }
                }
                kVar.setVisibility(4);
                kVar.invalidate();
                kVar.f();
            }
            for (int i28 = 0; i28 < MyApplication.b().X.size(); i28++) {
                int iKeyAt19 = MyApplication.b().X.keyAt(i28);
                CustomList customList = (CustomList) MyApplication.b().X.get(iKeyAt19);
                if (customList.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = customList.getNumScreen();
                }
                if (customList.k()) {
                    customList.setBackgroundColor(0);
                }
                if (customList.f8687i.l() >= 0 && customList.f8687i.l() != 100 && MyApplication.b().E.get(customList.f8687i.l()).h()) {
                    customList.f8687i.D(MyApplication.b().E.get(customList.f8687i.l()).d());
                    customList.f8687i.B(MyApplication.b().E.get(customList.f8687i.l()).b());
                    customList.f8687i.F(MyApplication.b().E.get(customList.f8687i.l()).g());
                    customList.f8687i.u((byte) MyApplication.b().E.get(customList.f8687i.l()).a());
                }
                customList.f8687i.C(iKeyAt19);
            }
            for (int i29 = 0; i29 < MyApplication.b().G.size(); i29++) {
                CustomLabel customLabel = (CustomLabel) MyApplication.b().G.get(MyApplication.b().G.keyAt(i29));
                if (customLabel.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = customLabel.getNumScreen();
                }
            }
            for (int i30 = 0; i30 < MyApplication.b().Y.size(); i30++) {
                int iKeyAt20 = MyApplication.b().Y.keyAt(i30);
                CustomSound customSound = (CustomSound) MyApplication.b().Y.get(iKeyAt20);
                if (customSound.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = customSound.getNumScreen();
                }
                if (customSound.f8696g.l() >= 0) {
                    if (customSound.f8696g.l() == 100) {
                        MyApplication.b().v0.f(customSound.f8696g);
                    } else if (MyApplication.b().E.get(customSound.f8696g.l()).h()) {
                        customSound.f8696g.D(MyApplication.b().E.get(customSound.f8696g.l()).d());
                        customSound.f8696g.B(MyApplication.b().E.get(customSound.f8696g.l()).b());
                        customSound.f8696g.F(MyApplication.b().E.get(customSound.f8696g.l()).g());
                        customSound.f8696g.u((byte) MyApplication.b().E.get(customSound.f8696g.l()).a());
                        Y0.get(customSound.f8696g.k()).f(customSound.f8696g);
                    }
                }
                customSound.f8696g.C(iKeyAt20);
                customSound.setVisibility(4);
                customSound.invalidate();
                customSound.b();
            }
            for (int i31 = 0; i31 < MyApplication.b().Z.size(); i31++) {
                int iKeyAt21 = MyApplication.b().Z.keyAt(i31);
                ru.himik.nightscream.kascada.CustomComponents.l lVar = (ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt21);
                if (lVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = lVar.getNumScreen();
                }
                if (lVar.f8842f.f() == 1) {
                    bVar = lVar.f8843g;
                    b2 = 5;
                } else {
                    bVar = lVar.f8843g;
                    b2 = 15;
                }
                bVar.L(b2);
                int mode2 = lVar.getMode();
                if (mode2 == 0) {
                    if (lVar.f8842f.l() >= 0) {
                        if (lVar.f8842f.l() == 100) {
                            lVar.f8842f.C(iKeyAt21);
                            MyApplication.b().v0.f(lVar.f8842f);
                        } else if (MyApplication.b().E.get(lVar.f8842f.l()).h()) {
                            lVar.f8842f.C(iKeyAt21);
                            lVar.f8842f.B(MyApplication.b().E.get(lVar.f8842f.l()).b());
                            lVar.f8842f.F(MyApplication.b().E.get(lVar.f8842f.l()).g());
                            lVar.f8842f.D(MyApplication.b().E.get(lVar.f8842f.l()).d());
                            lVar.f8842f.u((byte) MyApplication.b().E.get(lVar.f8842f.l()).a());
                            Y0.get(lVar.f8842f.k()).f(lVar.f8842f);
                        }
                    }
                    if (lVar.f8843g.l() >= 0) {
                        if (lVar.f8843g.l() == 100) {
                            lVar.f8843g.C(iKeyAt21);
                            MyApplication.b().v0.f(lVar.f8843g);
                        } else if (MyApplication.b().E.get(lVar.f8843g.l()).h()) {
                            lVar.f8843g.C(iKeyAt21);
                            lVar.f8843g.D(MyApplication.b().E.get(lVar.f8843g.l()).d());
                            lVar.f8843g.u((byte) MyApplication.b().E.get(lVar.f8843g.l()).a());
                            lVar.f8843g.B(MyApplication.b().E.get(lVar.f8843g.l()).b());
                            lVar.f8843g.F(MyApplication.b().E.get(lVar.f8843g.l()).g());
                            Y0.get(lVar.f8843g.k()).f(lVar.f8843g);
                        }
                    }
                } else if (mode2 == 1) {
                    if (lVar.f8844h.l() >= 0) {
                        if (lVar.f8844h.l() == 100) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar20 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar20.C(iKeyAt21);
                            bVar20.L((byte) 1);
                            bVar20.A(com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItemSmall);
                            bVar20.v(lVar.getRegMode());
                            bVar20.t((byte) lVar.getBitMode());
                            MyApplication.b().v0.f(bVar20);
                        } else if (MyApplication.b().E.get(lVar.f8844h.l()).h()) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar21 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar21.C(iKeyAt21);
                            bVar21.L((byte) 1);
                            bVar21.v(lVar.getRegMode());
                            bVar21.t((byte) lVar.getBitMode());
                            bVar21.A(com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItemSmall);
                            bVar21.B(MyApplication.b().E.get(lVar.f8844h.l()).b());
                            bVar21.F(MyApplication.b().E.get(lVar.f8844h.l()).g());
                            bVar21.u((byte) MyApplication.b().E.get(lVar.f8844h.l()).a());
                            lVar.f8844h.D(MyApplication.b().E.get(lVar.f8844h.l()).d());
                            Y0.get(lVar.f8844h.k()).f(bVar21);
                        }
                    }
                    if (lVar.f8842f.l() >= 0) {
                        if (lVar.f8842f.l() == 100) {
                            lVar.f8842f.C(iKeyAt21);
                        } else if (MyApplication.b().E.get(lVar.f8842f.l()).h()) {
                            lVar.f8842f.C(iKeyAt21);
                            lVar.f8842f.B(MyApplication.b().E.get(lVar.f8842f.l()).b());
                            lVar.f8842f.F(MyApplication.b().E.get(lVar.f8842f.l()).g());
                            lVar.f8842f.D(MyApplication.b().E.get(lVar.f8842f.l()).d());
                            lVar.f8842f.u((byte) MyApplication.b().E.get(lVar.f8842f.l()).a());
                        }
                    }
                    if (lVar.f8843g.l() >= 0) {
                        if (lVar.f8843g.l() == 100) {
                            lVar.f8843g.C(iKeyAt21);
                        } else if (MyApplication.b().E.get(lVar.f8843g.l()).h()) {
                            lVar.f8843g.C(iKeyAt21);
                            lVar.f8843g.D(MyApplication.b().E.get(lVar.f8843g.l()).d());
                            lVar.f8843g.u((byte) MyApplication.b().E.get(lVar.f8843g.l()).a());
                            lVar.f8843g.B(MyApplication.b().E.get(lVar.f8843g.l()).b());
                            lVar.f8843g.F(MyApplication.b().E.get(lVar.f8843g.l()).g());
                        }
                    }
                } else if (mode2 == 2) {
                    if (lVar.f8842f.l() >= 0) {
                        if (lVar.f8842f.l() == 100) {
                            lVar.f8842f.C(iKeyAt21);
                            MyApplication.b().v0.f(lVar.f8842f);
                        } else if (MyApplication.b().E.get(lVar.f8842f.l()).h()) {
                            lVar.f8842f.C(iKeyAt21);
                            lVar.f8842f.B(MyApplication.b().E.get(lVar.f8842f.l()).b());
                            lVar.f8842f.F(MyApplication.b().E.get(lVar.f8842f.l()).g());
                            lVar.f8842f.D(MyApplication.b().E.get(lVar.f8842f.l()).d());
                            lVar.f8842f.u((byte) MyApplication.b().E.get(lVar.f8842f.l()).a());
                            Y0.get(lVar.f8842f.k()).f(lVar.f8842f);
                        }
                    }
                    if (lVar.f8843g.l() >= 0) {
                        if (lVar.f8843g.l() == 100) {
                            lVar.f8843g.C(iKeyAt21);
                        } else if (MyApplication.b().E.get(lVar.f8843g.l()).h()) {
                            lVar.f8843g.C(iKeyAt21);
                            lVar.f8843g.D(MyApplication.b().E.get(lVar.f8843g.l()).d());
                            lVar.f8843g.u((byte) MyApplication.b().E.get(lVar.f8843g.l()).a());
                            lVar.f8843g.B(MyApplication.b().E.get(lVar.f8843g.l()).b());
                            lVar.f8843g.F(MyApplication.b().E.get(lVar.f8843g.l()).g());
                        }
                    }
                }
                lVar.setVisibility(4);
                lVar.invalidate();
                lVar.c();
            }
            for (int i32 = 0; i32 < MyApplication.b().a0.size(); i32++) {
                ru.himik.nightscream.kascada.CustomComponents.f fVar = (ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(MyApplication.b().a0.keyAt(i32));
                if (fVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = fVar.getNumScreen();
                }
                fVar.d();
            }
            for (int i33 = 0; i33 < MyApplication.b().b0.size(); i33++) {
                int iKeyAt22 = MyApplication.b().b0.keyAt(i33);
                ru.himik.nightscream.kascada.CustomComponents.m mVar2 = (ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt22);
                if (mVar2.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = mVar2.getNumScreen();
                }
                if (mVar2.J0.l() >= 0) {
                    if (mVar2.J0.l() == 100) {
                        MyApplication.b().v0.f(mVar2.J0);
                    } else if (MyApplication.b().E.get(mVar2.J0.l()).h()) {
                        mVar2.J0.D(MyApplication.b().E.get(mVar2.J0.l()).d());
                        mVar2.J0.u((byte) MyApplication.b().E.get(mVar2.J0.l()).a());
                        mVar2.J0.B(MyApplication.b().E.get(mVar2.J0.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar22 = mVar2.J0;
                        bVar22.x(this.o.c(bVar22, bVar22.i()));
                        mVar2.J0.F(MyApplication.b().E.get(mVar2.J0.l()).g());
                        Y0.get(mVar2.J0.k()).f(mVar2.J0);
                    }
                }
                mVar2.J0.C(iKeyAt22);
                mVar2.J0.A(24);
                mVar2.invalidate();
            }
            for (int i34 = 0; i34 < MyApplication.b().c0.size(); i34++) {
                int iKeyAt23 = MyApplication.b().c0.keyAt(i34);
                ru.himik.nightscream.kascada.CustomComponents.t tVar = (ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt23);
                if (tVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = tVar.getNumScreen();
                }
                if (tVar.f8889g.l() >= 0) {
                    if (tVar.f8889g.l() == 100) {
                        MyApplication.b().v0.f(tVar.f8889g);
                    } else if (MyApplication.b().E.get(tVar.f8889g.l()).h()) {
                        tVar.f8889g.D(MyApplication.b().E.get(tVar.f8889g.l()).d());
                        tVar.f8889g.u((byte) MyApplication.b().E.get(tVar.f8889g.l()).a());
                        tVar.f8889g.B(MyApplication.b().E.get(tVar.f8889g.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar23 = tVar.f8889g;
                        bVar23.x(this.o.c(bVar23, bVar23.i()));
                        tVar.f8889g.F(MyApplication.b().E.get(tVar.f8889g.l()).g());
                        Y0.get(tVar.f8889g.k()).f(tVar.f8889g);
                    }
                }
                tVar.f8889g.C(iKeyAt23);
                tVar.setVisibility(4);
                tVar.invalidate();
            }
            for (int i35 = 0; i35 < MyApplication.b().d0.size(); i35++) {
                int iKeyAt24 = MyApplication.b().d0.keyAt(i35);
                ru.himik.nightscream.kascada.CustomComponents.b0 b0Var = (ru.himik.nightscream.kascada.CustomComponents.b0) MyApplication.b().d0.get(iKeyAt24);
                if (b0Var.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = b0Var.getNumScreen();
                }
                if (b0Var.f8729f.l() >= 0) {
                    if (b0Var.f8729f.l() == 100) {
                        MyApplication.b().v0.f(b0Var.f8729f);
                    } else if (MyApplication.b().E.get(b0Var.f8729f.l()).h()) {
                        b0Var.f8729f.D(MyApplication.b().E.get(b0Var.f8729f.l()).d());
                        b0Var.f8729f.u((byte) MyApplication.b().E.get(b0Var.f8729f.l()).a());
                        b0Var.f8729f.B(MyApplication.b().E.get(b0Var.f8729f.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar24 = b0Var.f8729f;
                        bVar24.x(this.o.c(bVar24, bVar24.i()));
                        b0Var.f8729f.F(MyApplication.b().E.get(b0Var.f8729f.l()).g());
                        Y0.get(b0Var.f8729f.k()).f(b0Var.f8729f);
                    }
                }
                b0Var.f8729f.C(iKeyAt24);
            }
            for (int i36 = 0; i36 < MyApplication.b().e0.size(); i36++) {
                int iKeyAt25 = MyApplication.b().e0.keyAt(i36);
                ru.himik.nightscream.kascada.CustomComponents.j jVar = (ru.himik.nightscream.kascada.CustomComponents.j) MyApplication.b().e0.get(iKeyAt25);
                if (jVar.getNumScreen() > MyApplication.b().o) {
                    MyApplication.b().o = jVar.getNumScreen();
                }
                if (jVar.f8822h.l() >= 0) {
                    if (jVar.f8822h.l() == 100) {
                        MyApplication.b().v0.f(jVar.f8822h);
                    } else if (MyApplication.b().E.get(jVar.f8822h.l()).h()) {
                        jVar.f8822h.D(MyApplication.b().E.get(jVar.f8822h.l()).d());
                        jVar.f8822h.u((byte) MyApplication.b().E.get(jVar.f8822h.l()).a());
                        jVar.f8822h.B(MyApplication.b().E.get(jVar.f8822h.l()).b());
                        ru.himik.nightscream.kascada.CustomComponents.b bVar25 = jVar.f8822h;
                        bVar25.x(this.o.c(bVar25, bVar25.i()));
                        jVar.f8822h.F(MyApplication.b().E.get(jVar.f8822h.l()).g());
                        Y0.get(jVar.f8822h.k()).f(jVar.f8822h);
                    }
                }
                jVar.f8822h.C(iKeyAt25);
                jVar.setVisibility(4);
                jVar.invalidate();
            }
            for (int i37 = 0; i37 < MyApplication.b().f0.size(); i37++) {
                int iKeyAt26 = MyApplication.b().f0.keyAt(i37);
                ((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt26)).setVisibility(4);
                ((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt26)).invalidate();
            }
            this.a.setVisibility(4);
            this.W.setVisibility(4);
            this.f9208m.setBackgroundResource(R.drawable.stop);
            for (int i38 = 0; i38 < Y0.size(); i38++) {
                try {
                    Y0.get(i38).d();
                } catch (Exception unused5) {
                }
                try {
                    SystemClock.sleep(10L);
                } catch (Exception unused6) {
                }
            }
            H();
            init(getApplicationContext());
            String strG = ru.himik.nightscream.kascada.Utils.l.a.g();
            for (int i39 = 0; i39 < this.V.size(); i39++) {
                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = this.V;
                sparseArray.get(sparseArray.keyAt(i39)).setCustomSelect(false);
            }
            this.U.getLayoutParams().width = 0;
            this.U.getLayoutParams().height = 0;
            this.R.y(strG, MyApplication.b().f9044l, getSomeValue(), ru.himik.nightscream.kascada.Utils.q.b(getResources().getString(R.string.v11), getApplicationContext()));
            this.R.z(strG, MyApplication.b().f9044l, getSomeValue(), ru.himik.nightscream.kascada.Utils.q.b(getResources().getString(R.string.v12), getApplicationContext()));
            findViewById(R.id.lockScreen).setVisibility(4);
            l0(100, false);
            g0(true, MyApplication.b().f9039g);
            h1 = new ru.himik.nightscream.kascada.Utils.o(this.C);
            i.b.q.b<ru.himik.nightscream.kascada.Utils.m> bVar26 = MyApplication.b().a;
            if (z2) {
                mVar = new ru.himik.nightscream.kascada.Utils.m(3);
                bVar26.d(mVar);
                MyApplication.b().f();
            } else {
                mVar = new ru.himik.nightscream.kascada.Utils.m(5);
                bVar26.d(mVar);
            }
            C().q0.g();
            C().r0.g();
        }
    }

    public void D() {
        ru.himik.nightscream.kascada.CustomComponents.a aVar;
        boolean zD;
        ru.himik.nightscream.kascada.CustomComponents.a aVar2;
        int backgroundColor_;
        ru.himik.nightscream.kascada.CustomComponents.a aVar3;
        ru.himik.nightscream.kascada.CustomComponents.b bVar;
        if (this.f9204i.getTag() != null && !ru.himik.nightscream.kascada.CustomComponents.n.class.isInstance(this.f9204i) && !ru.himik.nightscream.kascada.CustomComponents.h.class.isInstance(this.f9204i)) {
            switch (((Integer) this.f9204i.getTag()).intValue()) {
                case 1:
                    ru.himik.nightscream.kascada.CustomComponents.y yVar = (ru.himik.nightscream.kascada.CustomComponents.y) this.f9204i;
                    this.f9205j.m(yVar.getHeight());
                    this.f9205j.u(yVar.getWidth());
                    this.f9205j.v((int) yVar.getX());
                    this.f9205j.w((int) yVar.getY());
                    this.f9205j.n(yVar.getIdComponent());
                    this.f9205j.r((int) yVar.getTextSize());
                    this.f9205j.o(yVar.getKey());
                    this.f9205j.f(yVar.f8943g.a());
                    if (yVar.f8943g.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (yVar.f8943g.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(yVar.f8943g.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(yVar.f8943g.l()).a());
                    }
                    this.f9205j.q(yVar.f8943g.l());
                    this.f9205j.e(yVar.f8943g.c());
                    this.f9205j.i(yVar.getCurrentTextColor());
                    aVar = this.f9205j;
                    zD = yVar.d();
                    aVar.t(zD);
                    break;
                case 2:
                    CustomLabel customLabel = (CustomLabel) this.f9204i;
                    this.f9205j.m(customLabel.getHeight());
                    this.f9205j.u(customLabel.getWidth());
                    this.f9205j.v((int) customLabel.getX());
                    this.f9205j.w((int) customLabel.getY());
                    this.f9205j.n(customLabel.getIdComponent());
                    this.f9205j.s(customLabel.getText().toString());
                    this.f9205j.r((int) customLabel.getTextSize());
                    this.f9205j.o(customLabel.getKey());
                    this.f9205j.i(customLabel.getCurrentTextColor());
                    aVar2 = this.f9205j;
                    backgroundColor_ = customLabel.getBackgroundColor_();
                    aVar2.h(backgroundColor_);
                    break;
                case 4:
                    ru.himik.nightscream.kascada.CustomComponents.u uVar = (ru.himik.nightscream.kascada.CustomComponents.u) this.f9204i;
                    this.f9205j.m(uVar.getHeight());
                    this.f9205j.u(uVar.getWidth());
                    this.f9205j.v((int) uVar.getX());
                    this.f9205j.w((int) uVar.getY());
                    this.f9205j.n(uVar.getIdComponent());
                    this.f9205j.s(uVar.getText().toString());
                    this.f9205j.r((int) uVar.getTextSize());
                    this.f9205j.o(uVar.getKey());
                    if (uVar.f8903k.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (uVar.f8903k.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(uVar.f8903k.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(uVar.f8903k.l()).a());
                    }
                    this.f9205j.q(uVar.f8903k.l());
                    this.f9205j.e(uVar.f8903k.c());
                    this.f9205j.i(uVar.getCurrentTextColor());
                    this.f9205j.h(uVar.getBackgroundColorReg());
                    this.f9205j.k(uVar.getDigit());
                    this.f9205j.l(uVar.getDivisor());
                    break;
                case 5:
                    ru.himik.nightscream.kascada.CustomComponents.q qVar = (ru.himik.nightscream.kascada.CustomComponents.q) this.f9204i;
                    this.f9205j.m(qVar.getHeight());
                    this.f9205j.u(qVar.getWidth());
                    this.f9205j.v((int) qVar.getX());
                    this.f9205j.w((int) qVar.getY());
                    this.f9205j.n(qVar.getIdComponent());
                    this.f9205j.o(qVar.getKey());
                    this.f9205j.f(qVar.f8865g.a());
                    if (qVar.f8865g.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (qVar.f8865g.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(qVar.f8865g.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(qVar.f8865g.l()).a());
                    }
                    this.f9205j.q(qVar.f8865g.l());
                    aVar3 = this.f9205j;
                    bVar = qVar.f8865g;
                    aVar3.e(bVar.c());
                    break;
                case 6:
                    ru.himik.nightscream.kascada.CustomComponents.e eVar = (ru.himik.nightscream.kascada.CustomComponents.e) this.f9204i;
                    this.f9205j.m(eVar.getHeight());
                    this.f9205j.u(eVar.getWidth());
                    this.f9205j.v((int) eVar.getX());
                    this.f9205j.w((int) eVar.getY());
                    this.f9205j.n(eVar.getIdComponent());
                    this.f9205j.s(eVar.getText().toString());
                    this.f9205j.r((int) eVar.getTextSize());
                    this.f9205j.o(eVar.getKey());
                    this.f9205j.f(eVar.f8769i.a());
                    if (eVar.f8769i.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (eVar.f8769i.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(eVar.f8769i.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(eVar.f8769i.l()).a());
                    }
                    this.f9205j.q(eVar.f8769i.l());
                    this.f9205j.e(eVar.f8769i.c());
                    this.f9205j.i(eVar.getCurrentTextColor());
                    aVar = this.f9205j;
                    zD = eVar.m();
                    aVar.t(zD);
                    break;
                case 7:
                    CustomDynText customDynText = (CustomDynText) this.f9204i;
                    this.f9205j.m(customDynText.getHeight());
                    this.f9205j.u(customDynText.getWidth());
                    this.f9205j.v((int) customDynText.getX());
                    this.f9205j.w((int) customDynText.getY());
                    this.f9205j.n(customDynText.getIdComponent());
                    this.f9205j.s(customDynText.getCustomText());
                    this.f9205j.r((int) customDynText.getTextSize());
                    this.f9205j.o(customDynText.getKey());
                    this.f9205j.i(customDynText.getCurrentTextColor());
                    this.f9205j.f(customDynText.f8667i.a());
                    if (customDynText.f8667i.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (customDynText.f8667i.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(customDynText.f8667i.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(customDynText.f8667i.l()).a());
                    }
                    this.f9205j.q(customDynText.f8667i.l());
                    aVar3 = this.f9205j;
                    bVar = customDynText.f8667i;
                    aVar3.e(bVar.c());
                    break;
                case 8:
                    ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) this.f9204i;
                    this.f9205j.m(iVar.getHeight());
                    this.f9205j.u(iVar.getWidth());
                    this.f9205j.v((int) iVar.getX());
                    this.f9205j.w((int) iVar.getY());
                    this.f9205j.n(iVar.getIdComponent());
                    this.f9205j.s(iVar.getCustomText());
                    this.f9205j.r((int) iVar.getTextSize());
                    this.f9205j.o(iVar.getKey());
                    if (iVar.f8813j.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (iVar.f8813j.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(iVar.f8813j.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(iVar.f8813j.l()).a());
                    }
                    this.f9205j.q(iVar.f8813j.l());
                    this.f9205j.e(iVar.f8813j.c());
                    this.f9205j.i(iVar.getCurrentTextColor());
                    aVar2 = this.f9205j;
                    backgroundColor_ = iVar.getBackgroundColorEditNumber();
                    aVar2.h(backgroundColor_);
                    break;
                case 9:
                    ru.himik.nightscream.kascada.CustomComponents.c cVar = (ru.himik.nightscream.kascada.CustomComponents.c) this.f9204i;
                    this.f9205j.m(cVar.getHeight());
                    this.f9205j.u(cVar.getWidth());
                    this.f9205j.v((int) cVar.getX());
                    this.f9205j.w((int) cVar.getY());
                    this.f9205j.n(cVar.getIdComponent());
                    this.f9205j.s(cVar.getCustomText());
                    this.f9205j.o(cVar.getKey());
                    if (cVar.f8742h.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (cVar.f8742h.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(cVar.f8742h.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(cVar.f8742h.l()).a());
                    }
                    this.f9205j.q(cVar.f8742h.l());
                    this.f9205j.f(cVar.f8742h.a());
                    aVar3 = this.f9205j;
                    bVar = cVar.f8742h;
                    aVar3.e(bVar.c());
                    break;
                case 10:
                    ru.himik.nightscream.kascada.CustomComponents.w wVar = (ru.himik.nightscream.kascada.CustomComponents.w) this.f9204i;
                    this.f9205j.v((int) wVar.getX());
                    this.f9205j.w((int) wVar.getY());
                    this.f9205j.n(wVar.getIdComponent());
                    this.f9205j.o(wVar.getKey());
                    if (wVar.f8921g.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (wVar.f8921g.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(wVar.f8921g.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(wVar.f8921g.l()).a());
                    }
                    this.f9205j.q(wVar.f8921g.l());
                    this.f9205j.f(wVar.f8921g.a());
                    aVar3 = this.f9205j;
                    bVar = wVar.f8921g;
                    aVar3.e(bVar.c());
                    break;
                case 11:
                    ru.himik.nightscream.kascada.CustomComponents.r rVar = (ru.himik.nightscream.kascada.CustomComponents.r) this.f9204i;
                    this.f9205j.v((int) rVar.getX());
                    this.f9205j.w((int) rVar.getY());
                    this.f9205j.n(rVar.getIdComponent());
                    this.f9205j.o(rVar.getKey());
                    if (rVar.f8874e.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (rVar.f8874e.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(rVar.f8874e.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(rVar.f8874e.l()).a());
                    }
                    this.f9205j.q(rVar.f8874e.l());
                    aVar3 = this.f9205j;
                    bVar = rVar.f8874e;
                    aVar3.e(bVar.c());
                    break;
                case 12:
                    ru.himik.nightscream.kascada.CustomComponents.g gVar = (ru.himik.nightscream.kascada.CustomComponents.g) this.f9204i;
                    this.f9205j.m(gVar.getHeight());
                    this.f9205j.u(gVar.getWidth());
                    this.f9205j.v((int) gVar.getX());
                    this.f9205j.w((int) gVar.getY());
                    this.f9205j.n(gVar.getIdComponent());
                    this.f9205j.o(gVar.getKey());
                    if (gVar.I.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (gVar.I.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(gVar.I.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(gVar.I.l()).a());
                    }
                    this.f9205j.q(gVar.I.l());
                    aVar3 = this.f9205j;
                    bVar = gVar.I;
                    aVar3.e(bVar.c());
                    break;
                case 13:
                    ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) this.f9204i;
                    this.f9205j.m(vVar.getHeight());
                    this.f9205j.u(vVar.getWidth());
                    this.f9205j.v((int) vVar.getX());
                    this.f9205j.w((int) vVar.getY());
                    this.f9205j.n(vVar.getIdComponent());
                    this.f9205j.o(vVar.getKey());
                    if (vVar.f8909f.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (vVar.f8909f.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(vVar.f8909f.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(vVar.f8909f.l()).a());
                    }
                    this.f9205j.q(vVar.f8909f.l());
                    this.f9205j.e(vVar.f8909f.c());
                    this.f9205j.p(vVar.getMax());
                    break;
                case 14:
                    ru.himik.nightscream.kascada.CustomComponents.o oVar = (ru.himik.nightscream.kascada.CustomComponents.o) this.f9204i;
                    this.f9205j.m(oVar.getHeight());
                    this.f9205j.u(oVar.getWidth());
                    this.f9205j.v((int) oVar.getX());
                    this.f9205j.w((int) oVar.getY());
                    this.f9205j.n(oVar.getIdComponent());
                    this.f9205j.o(oVar.getKey());
                    if (oVar.T.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (oVar.T.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(oVar.T.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(oVar.T.l()).a());
                    }
                    this.f9205j.q(oVar.T.l());
                    aVar3 = this.f9205j;
                    bVar = oVar.T;
                    aVar3.e(bVar.c());
                    break;
                case 15:
                    ru.himik.nightscream.kascada.CustomComponents.d dVar = (ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i;
                    this.f9205j.v((int) dVar.getX());
                    this.f9205j.w((int) dVar.getY());
                    this.f9205j.n(dVar.getIdComponent());
                    this.f9205j.o(dVar.getKey());
                    if (dVar.f8753h.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (dVar.f8753h.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(dVar.f8753h.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(dVar.f8753h.l()).a());
                    }
                    this.f9205j.q(dVar.f8753h.l());
                    this.f9205j.f(dVar.f8753h.a());
                    aVar3 = this.f9205j;
                    bVar = dVar.f8753h;
                    aVar3.e(bVar.c());
                    break;
                case 18:
                    ru.himik.nightscream.kascada.CustomComponents.x xVar = (ru.himik.nightscream.kascada.CustomComponents.x) this.f9204i;
                    this.f9205j.v((int) xVar.getX());
                    this.f9205j.w((int) xVar.getY());
                    this.f9205j.n(xVar.getIdComponent());
                    this.f9205j.o(xVar.getKey());
                    if (xVar.f8932g.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (xVar.f8932g.l() >= 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(xVar.f8932g.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(xVar.f8932g.l()).a());
                    }
                    this.f9205j.q(xVar.f8932g.l());
                    this.f9205j.f(xVar.f8932g.a());
                    aVar3 = this.f9205j;
                    bVar = xVar.f8932g;
                    aVar3.e(bVar.c());
                    break;
                case 20:
                    CustomList customList = (CustomList) this.f9204i;
                    this.f9205j.m(customList.getHeight());
                    this.f9205j.u(customList.getWidth());
                    this.f9205j.v((int) customList.getX());
                    this.f9205j.w((int) customList.getY());
                    this.f9205j.n(customList.getIdComponent());
                    this.f9205j.r((int) customList.getTextSize());
                    this.f9205j.o(customList.getKey());
                    if (customList.f8687i.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (customList.f8687i.l() == 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(customList.f8687i.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(customList.f8687i.l()).a());
                    }
                    this.f9205j.q(customList.f8687i.l());
                    this.f9205j.e(customList.f8687i.c());
                    this.f9205j.i(customList.getCurrentTextColor());
                    break;
                case 21:
                    CustomSound customSound = (CustomSound) this.f9204i;
                    this.f9205j.m(customSound.getHeight());
                    this.f9205j.u(customSound.getWidth());
                    this.f9205j.v((int) customSound.getX());
                    this.f9205j.w((int) customSound.getY());
                    this.f9205j.n(customSound.getIdComponent());
                    this.f9205j.o(customSound.getKey());
                    if (customSound.f8696g.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (customSound.f8696g.l() == 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(customSound.f8696g.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(customSound.f8696g.l()).a());
                    }
                    this.f9205j.q(customSound.f8696g.l());
                    aVar3 = this.f9205j;
                    bVar = customSound.f8696g;
                    aVar3.e(bVar.c());
                    break;
                case 25:
                    ru.himik.nightscream.kascada.CustomComponents.t tVar = (ru.himik.nightscream.kascada.CustomComponents.t) this.f9204i;
                    this.f9205j.m(tVar.getHeight());
                    this.f9205j.u(tVar.getWidth());
                    this.f9205j.v((int) tVar.getX());
                    this.f9205j.w((int) tVar.getY());
                    this.f9205j.n(tVar.getIdComponent());
                    this.f9205j.o(tVar.getKey());
                    if (tVar.f8889g.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (tVar.f8889g.l() == 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(tVar.f8889g.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(tVar.f8889g.l()).a());
                    }
                    this.f9205j.q(tVar.f8889g.l());
                    aVar3 = this.f9205j;
                    bVar = tVar.f8889g;
                    aVar3.e(bVar.c());
                    break;
                case 26:
                    ru.himik.nightscream.kascada.CustomComponents.b0 b0Var = (ru.himik.nightscream.kascada.CustomComponents.b0) this.f9204i;
                    this.f9205j.m(b0Var.getHeight());
                    this.f9205j.u(b0Var.getWidth());
                    this.f9205j.v((int) b0Var.getX());
                    this.f9205j.w((int) b0Var.getY());
                    this.f9205j.n(b0Var.getIdComponent());
                    this.f9205j.o(b0Var.getKey());
                    if (b0Var.f8729f.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (b0Var.f8729f.l() == 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    } else {
                        this.f9205j.j(MyApplication.b().E.get(b0Var.f8729f.l()).c());
                        this.f9205j.g((byte) MyApplication.b().E.get(b0Var.f8729f.l()).a());
                    }
                    this.f9205j.q(b0Var.f8729f.l());
                    aVar3 = this.f9205j;
                    bVar = b0Var.f8729f;
                    aVar3.e(bVar.c());
                    break;
                case 27:
                    ru.himik.nightscream.kascada.CustomComponents.a0 a0Var = (ru.himik.nightscream.kascada.CustomComponents.a0) this.f9204i;
                    this.f9205j.m(a0Var.getHeight());
                    this.f9205j.u(a0Var.getWidth());
                    this.f9205j.v((int) a0Var.getX());
                    this.f9205j.w((int) a0Var.getY());
                    this.f9205j.n(a0Var.getIdComponent());
                    this.f9205j.o(a0Var.getKey());
                    if (a0Var.f8708g.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (a0Var.f8708g.l() == 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    }
                    this.f9205j.q(a0Var.f8708g.l());
                    aVar3 = this.f9205j;
                    bVar = a0Var.f8708g;
                    aVar3.e(bVar.c());
                    break;
                case 28:
                    ru.himik.nightscream.kascada.CustomComponents.j jVar = (ru.himik.nightscream.kascada.CustomComponents.j) this.f9204i;
                    this.f9205j.m(jVar.getHeight());
                    this.f9205j.u(jVar.getWidth());
                    this.f9205j.v((int) jVar.getX());
                    this.f9205j.w((int) jVar.getY());
                    this.f9205j.n(jVar.getIdComponent());
                    this.f9205j.o(jVar.getKey());
                    if (jVar.f8822h.l() < 0) {
                        this.f9205j.g(-1);
                    } else if (jVar.f8822h.l() == 100) {
                        this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                        this.f9205j.g(1);
                    }
                    this.f9205j.q(jVar.f8822h.l());
                    aVar3 = this.f9205j;
                    bVar = jVar.f8822h;
                    aVar3.e(bVar.c());
                    break;
            }
        }
        View view = this.f9204i;
        if (view instanceof ru.himik.nightscream.kascada.CustomComponents.n) {
            ru.himik.nightscream.kascada.CustomComponents.n nVar = (ru.himik.nightscream.kascada.CustomComponents.n) view;
            this.f9205j.m(nVar.getHeight());
            this.f9205j.u(nVar.getWidth());
            this.f9205j.v((int) nVar.getX());
            this.f9205j.w((int) nVar.getY());
            this.f9205j.n(nVar.getIdComponent());
            this.f9205j.o(nVar.getKey());
            this.f9205j.f(nVar.f8854g.a());
            if (nVar.f8854g.l() < 0) {
                this.f9205j.g(-1);
            } else if (nVar.f8854g.l() >= 100) {
                this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                this.f9205j.g(1);
            } else {
                this.f9205j.j(MyApplication.b().E.get(nVar.f8854g.l()).c());
                this.f9205j.g((byte) MyApplication.b().E.get(nVar.f8854g.l()).a());
            }
            this.f9205j.q(nVar.f8854g.l());
            this.f9205j.e(nVar.f8854g.c());
        }
        View view2 = this.f9204i;
        if (view2 instanceof ru.himik.nightscream.kascada.CustomComponents.h) {
            ru.himik.nightscream.kascada.CustomComponents.h hVar = (ru.himik.nightscream.kascada.CustomComponents.h) view2;
            this.f9205j.m(hVar.getHeight());
            this.f9205j.u(hVar.getWidth());
            this.f9205j.v((int) hVar.getX());
            this.f9205j.w((int) hVar.getY());
            this.f9205j.n(hVar.getIdComponent());
            this.f9205j.o(hVar.getKey());
            this.f9205j.f(hVar.f8798e.a());
            if (hVar.f8798e.l() < 0) {
                this.f9205j.g(-1);
            } else if (hVar.f8798e.l() >= 100) {
                this.f9205j.j(getResources().getString(R.string.dialog_device_system));
                this.f9205j.g(1);
            } else {
                this.f9205j.j(MyApplication.b().E.get(hVar.f8798e.l()).c());
                this.f9205j.g((byte) MyApplication.b().E.get(hVar.f8798e.l()).a());
            }
            this.f9205j.q(hVar.f8798e.l());
            this.f9205j.e(hVar.f8798e.c());
        }
        View view3 = this.f9204i;
        if (view3 instanceof ru.himik.nightscream.kascada.CustomComponents.k) {
            ru.himik.nightscream.kascada.CustomComponents.k kVar = (ru.himik.nightscream.kascada.CustomComponents.k) view3;
            this.f9205j.v((int) kVar.getX());
            this.f9205j.w((int) kVar.getY());
            this.f9205j.n(kVar.getIdComponent());
            this.f9205j.o(kVar.getKey());
        }
        View view4 = this.f9204i;
        if (view4 instanceof ru.himik.nightscream.kascada.CustomComponents.l) {
            ru.himik.nightscream.kascada.CustomComponents.l lVar = (ru.himik.nightscream.kascada.CustomComponents.l) view4;
            this.f9205j.v((int) lVar.getX());
            this.f9205j.w((int) lVar.getY());
            this.f9205j.n(lVar.getIdComponent());
            this.f9205j.o(lVar.getKey());
        }
        View view5 = this.f9204i;
        if (view5 instanceof ru.himik.nightscream.kascada.CustomComponents.f) {
            ru.himik.nightscream.kascada.CustomComponents.f fVar = (ru.himik.nightscream.kascada.CustomComponents.f) view5;
            this.f9205j.v((int) fVar.getX());
            this.f9205j.w((int) fVar.getY());
            this.f9205j.n(fVar.getIdComponent());
            this.f9205j.o(fVar.getKey());
        }
        View view6 = this.f9204i;
        if (view6 instanceof ru.himik.nightscream.kascada.CustomComponents.m) {
            ru.himik.nightscream.kascada.CustomComponents.m mVar = (ru.himik.nightscream.kascada.CustomComponents.m) view6;
            this.f9205j.v((int) mVar.getX());
            this.f9205j.w((int) mVar.getY());
            this.f9205j.n(mVar.getIdComponent());
            this.f9205j.o(mVar.getKey());
        }
    }

    public int E() {
        return MyApplication.b().F.size() + MyApplication.b().G.size() + MyApplication.b().H.size() + MyApplication.b().I.size() + MyApplication.b().J.size() + MyApplication.b().K.size() + MyApplication.b().L.size() + MyApplication.b().M.size() + MyApplication.b().N.size() + MyApplication.b().O.size() + MyApplication.b().P.size() + MyApplication.b().Q.size() + MyApplication.b().R.size() + MyApplication.b().S.size() + MyApplication.b().T.size() + MyApplication.b().U.size() + MyApplication.b().V.size() + MyApplication.b().W.size() + MyApplication.b().X.size() + MyApplication.b().Y.size() + MyApplication.b().Z.size() + MyApplication.b().a0.size() + MyApplication.b().b0.size() + MyApplication.b().c0.size() + MyApplication.b().d0.size() + MyApplication.b().e0.size() + MyApplication.b().f0.size();
    }

    public void Resizing(View view) {
        ImageView imageView;
        view.invalidate();
        switch (view.getId()) {
            case R.id.resize_bottom_left /* 2131296974 */:
                this.b.setX(view.getX());
                imageView = this.f9200e;
                break;
            case R.id.resize_bottom_right /* 2131296975 */:
                this.c.setX(view.getX());
                imageView = this.f9199d;
                break;
            case R.id.resize_top_left /* 2131296976 */:
                this.f9199d.setX(view.getX());
                imageView = this.c;
                break;
            case R.id.resize_top_right /* 2131296977 */:
                this.f9200e.setX(view.getX());
                imageView = this.b;
                break;
            default:
                int x2 = ((int) this.c.getX()) - ((int) this.b.getX());
                this.f9202g.getLayoutParams().height = ((int) this.f9199d.getY()) - ((int) this.b.getY());
                this.f9202g.getLayoutParams().width = x2;
                this.f9202g.setX(this.b.getX() + (this.b.getWidth() / 2));
                this.f9202g.setY(this.b.getY() + (this.b.getHeight() / 2));
                this.f9202g.requestLayout();
        }
        imageView.setY(view.getY());
        int x3 = ((int) this.c.getX()) - ((int) this.b.getX());
        this.f9202g.getLayoutParams().height = ((int) this.f9199d.getY()) - ((int) this.b.getY());
        this.f9202g.getLayoutParams().width = x3;
        this.f9202g.setX(this.b.getX() + (this.b.getWidth() / 2));
        this.f9202g.setY(this.b.getY() + (this.b.getHeight() / 2));
        this.f9202g.requestLayout();
    }

    public void StartResize(View view) {
        this.f9202g = view;
        this.b.setY(view.getY() - (this.b.getHeight() / 2));
        this.b.setX(view.getX() - (this.b.getWidth() / 2));
        this.b.bringToFront();
        this.f9199d.setY((view.getY() - (this.f9199d.getHeight() / 2)) + view.getHeight());
        this.f9199d.setX(view.getX() - (this.f9199d.getWidth() / 2));
        this.f9199d.bringToFront();
        this.c.setY(view.getY() - (this.c.getHeight() / 2));
        this.c.setX((view.getX() - (this.c.getWidth() / 2)) + view.getWidth());
        this.c.bringToFront();
        this.f9200e.setY((view.getY() - (this.f9200e.getHeight() / 2)) + view.getHeight());
        this.f9200e.setX((view.getX() - (this.f9200e.getWidth() / 2)) + view.getWidth());
        this.f9200e.bringToFront();
        if (Build.VERSION.SDK_INT >= 21) {
            this.b.setElevation(101.0f);
            this.f9199d.setElevation(101.0f);
            this.c.setElevation(101.0f);
            this.f9200e.setElevation(101.0f);
        }
        q(true);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void alignSelectView(View view) {
        ArrayList arrayList;
        float x2 = this.U.getX();
        float y2 = this.U.getY();
        float x3 = this.U.getX() + this.U.getWidth();
        float y3 = this.U.getY() + this.U.getHeight();
        float x4 = this.U.getX() + (this.U.getWidth() / 2);
        float y4 = this.U.getY() + (this.U.getHeight() / 2);
        float customX = 0.0f;
        switch (view.getId()) {
            case R.id.alignBottom /* 2131296363 */:
                for (int i2 = 0; i2 < this.V.size(); i2++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar = sparseArray.get(sparseArray.keyAt(i2));
                    if (zVar.p()) {
                        zVar.setY(y3 - zVar.getCustomHeight());
                        zVar.setDiffY((int) (zVar.getCustomY() - y2));
                    }
                    if (zVar instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                        ((ru.himik.nightscream.kascada.Logic.c.a) zVar).r();
                    }
                }
                break;
            case R.id.alignHeightMax /* 2131296364 */:
                int customHeight = 0;
                for (int i3 = 0; i3 < this.V.size(); i3++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar2 = sparseArray2.get(sparseArray2.keyAt(i3));
                    if (zVar2.p() && zVar2.getCustomHeight() > customHeight) {
                        customHeight = zVar2.getCustomHeight();
                    }
                }
                for (int i4 = 0; i4 < this.V.size(); i4++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray3 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar3 = sparseArray3.get(sparseArray3.keyAt(i4));
                    if (zVar3.p() && (zVar3 instanceof ru.himik.nightscream.kascada.s.b)) {
                        ((View) zVar3).getLayoutParams().height = customHeight;
                    }
                }
                break;
            case R.id.alignHorizontal /* 2131296365 */:
                for (int i5 = 0; i5 < this.V.size(); i5++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray4 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar4 = sparseArray4.get(sparseArray4.keyAt(i5));
                    if (zVar4.p()) {
                        zVar4.setY(y4 - (zVar4.getCustomHeight() / 2));
                        zVar4.setDiffY((int) (zVar4.getCustomY() - y2));
                    }
                    if (zVar4 instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                        ((ru.himik.nightscream.kascada.Logic.c.a) zVar4).r();
                    }
                }
                break;
            case R.id.alignLeft /* 2131296366 */:
                for (int i6 = 0; i6 < this.V.size(); i6++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray5 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar5 = sparseArray5.get(sparseArray5.keyAt(i6));
                    if (zVar5.p()) {
                        zVar5.setX(x2);
                        zVar5.setDiffX(0);
                    }
                    if (zVar5 instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                        ((ru.himik.nightscream.kascada.Logic.c.a) zVar5).r();
                    }
                }
                break;
            case R.id.alignRight /* 2131296367 */:
                for (int i7 = 0; i7 < this.V.size(); i7++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray6 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar6 = sparseArray6.get(sparseArray6.keyAt(i7));
                    if (zVar6.p()) {
                        zVar6.setX(x3 - zVar6.getCustomWidth());
                        zVar6.setDiffX((int) (zVar6.getCustomX() - x2));
                    }
                    if (zVar6 instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                        ((ru.himik.nightscream.kascada.Logic.c.a) zVar6).r();
                    }
                }
                break;
            case R.id.alignSpaceHorizontal /* 2131296368 */:
                arrayList = new ArrayList();
                for (int i8 = 0; i8 < this.V.size(); i8++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray7 = this.V;
                    if (sparseArray7.get(sparseArray7.keyAt(i8)).p()) {
                        SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray8 = this.V;
                        arrayList.add(sparseArray8.get(sparseArray8.keyAt(i8)));
                    }
                }
                Collections.sort(arrayList, new Comparator() { // from class: ru.himik.nightscream.kascada.l
                    @Override // java.util.Comparator
                    public final int compare(Object obj, Object obj2) {
                        return mbCanvas.I((ru.himik.nightscream.kascada.CustomComponents.z) obj, (ru.himik.nightscream.kascada.CustomComponents.z) obj2);
                    }
                });
                Iterator it = arrayList.iterator();
                float customWidth = 0.0f;
                while (it.hasNext()) {
                    customWidth += ((ru.himik.nightscream.kascada.CustomComponents.z) it.next()).getCustomWidth();
                }
                if (arrayList.size() > 2) {
                    float customX2 = (((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(arrayList.size() - 1)).getCustomX() + ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(arrayList.size() - 1)).getCustomWidth()) - ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(0)).getCustomX();
                    if (customX2 > customWidth) {
                        float size = (customX2 - customWidth) / (arrayList.size() - 1);
                        for (int i9 = 0; i9 < arrayList.size(); i9++) {
                            if (i9 != 0 && i9 != arrayList.size() - 1) {
                                int i10 = i9 - 1;
                                ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i9)).setX(((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i10)).getCustomX() + ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i10)).getCustomWidth() + size);
                                ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i9)).setDiffX((int) (((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i9)).getCustomX() - x2));
                            }
                        }
                    } else {
                        float size2 = customX2 / arrayList.size();
                        for (int i11 = 0; i11 < arrayList.size(); i11++) {
                            ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i11)).setX((i11 * size2) + ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(0)).getCustomX());
                            ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i11)).setDiffX((int) (((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i11)).getCustomX() - x2));
                        }
                    }
                }
                arrayList.clear();
                break;
            case R.id.alignSpaceVertical /* 2131296369 */:
                arrayList = new ArrayList();
                for (int i12 = 0; i12 < this.V.size(); i12++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray9 = this.V;
                    if (sparseArray9.get(sparseArray9.keyAt(i12)).p()) {
                        SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray10 = this.V;
                        arrayList.add(sparseArray10.get(sparseArray10.keyAt(i12)));
                    }
                }
                Collections.sort(arrayList, new Comparator() { // from class: ru.himik.nightscream.kascada.m
                    @Override // java.util.Comparator
                    public final int compare(Object obj, Object obj2) {
                        return mbCanvas.J((ru.himik.nightscream.kascada.CustomComponents.z) obj, (ru.himik.nightscream.kascada.CustomComponents.z) obj2);
                    }
                });
                Iterator it2 = arrayList.iterator();
                float customHeight2 = 0.0f;
                while (it2.hasNext()) {
                    customHeight2 += ((ru.himik.nightscream.kascada.CustomComponents.z) it2.next()).getCustomHeight();
                }
                if (arrayList.size() > 2) {
                    float customY = (((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(arrayList.size() - 1)).getCustomY() + ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(arrayList.size() - 1)).getCustomHeight()) - ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(0)).getCustomY();
                    if (customY > customHeight2) {
                        float size3 = (customY - customHeight2) / (arrayList.size() - 1);
                        for (int i13 = 0; i13 < arrayList.size(); i13++) {
                            if (i13 != 0 && i13 != arrayList.size() - 1) {
                                int i14 = i13 - 1;
                                ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i13)).setY(((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i14)).getCustomY() + ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i14)).getCustomHeight() + size3);
                                ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i13)).setDiffY((int) (((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i13)).getCustomY() - y2));
                            }
                        }
                    } else {
                        float size4 = customY / arrayList.size();
                        for (int i15 = 0; i15 < arrayList.size(); i15++) {
                            ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i15)).setY((i15 * size4) + ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(0)).getCustomY());
                            ((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i15)).setDiffY((int) (((ru.himik.nightscream.kascada.CustomComponents.z) arrayList.get(i15)).getCustomY() - y2));
                        }
                    }
                }
                arrayList.clear();
                break;
            case R.id.alignTop /* 2131296370 */:
                for (int i16 = 0; i16 < this.V.size(); i16++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray11 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar7 = sparseArray11.get(sparseArray11.keyAt(i16));
                    if (zVar7.p()) {
                        zVar7.setY(y2);
                        zVar7.setDiffY(0);
                    }
                }
                break;
            case R.id.alignVertical /* 2131296371 */:
                for (int i17 = 0; i17 < this.V.size(); i17++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray12 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar8 = sparseArray12.get(sparseArray12.keyAt(i17));
                    if (zVar8.p()) {
                        zVar8.setX(x4 - (zVar8.getCustomWidth() / 2));
                        zVar8.setDiffX((int) (zVar8.getCustomX() - x2));
                    }
                    if (zVar8 instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                        ((ru.himik.nightscream.kascada.Logic.c.a) zVar8).r();
                    }
                }
                break;
            case R.id.alignWidthMax /* 2131296372 */:
                int customWidth2 = 0;
                for (int i18 = 0; i18 < this.V.size(); i18++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray13 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar9 = sparseArray13.get(sparseArray13.keyAt(i18));
                    if (zVar9.p() && zVar9.getCustomWidth() > customWidth2) {
                        customWidth2 = zVar9.getCustomWidth();
                    }
                }
                for (int i19 = 0; i19 < this.V.size(); i19++) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray14 = this.V;
                    ru.himik.nightscream.kascada.CustomComponents.z zVar10 = sparseArray14.get(sparseArray14.keyAt(i19));
                    if (zVar10.p() && (zVar10 instanceof ru.himik.nightscream.kascada.s.b)) {
                        ((View) zVar10).getLayoutParams().width = customWidth2;
                    }
                }
                break;
        }
        float customX3 = MyApplication.b().f9040h;
        float customY2 = MyApplication.b().f9041i;
        float customY3 = 0.0f;
        for (int i20 = 0; i20 < this.V.size(); i20++) {
            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray15 = this.V;
            ru.himik.nightscream.kascada.CustomComponents.z zVar11 = sparseArray15.get(sparseArray15.keyAt(i20));
            if (zVar11.p()) {
                if (zVar11.getCustomX() < customX3) {
                    customX3 = zVar11.getCustomX();
                }
                if (zVar11.getCustomY() < customY2) {
                    customY2 = zVar11.getCustomY();
                }
                View view2 = (View) zVar11;
                if (zVar11.getCustomX() + view2.getLayoutParams().width > customX) {
                    customX = zVar11.getCustomX() + view2.getLayoutParams().width;
                }
                if (zVar11.getCustomY() + view2.getLayoutParams().height > customY3) {
                    customY3 = zVar11.getCustomY() + view2.getLayoutParams().height;
                }
            }
        }
        this.U.setX(customX3);
        this.U.setY(customY2);
        this.U.getLayoutParams().width = (int) (customX - customX3);
        this.U.getLayoutParams().height = (int) (customY3 - customY2);
        this.U.bringToFront();
        this.U.requestLayout();
        f1.invalidate();
    }

    void b0(String str, int i2, int i3) {
        try {
            this.z0++;
            JSONObject jSONObject = new JSONObject(ru.himik.nightscream.kascada.Utils.n.a.g(str, MyApplication.b().m0));
            long jC = ru.himik.nightscream.kascada.Utils.q.c();
            jSONObject.put("uniqueId", jC);
            JSONArray jSONArray = new JSONArray(jSONObject.getString("fbInMacros"));
            int i4 = -1;
            if (jSONArray.length() > 0) {
                int i5 = 0;
                while (i5 < jSONArray.length()) {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(i5);
                    if (jSONObject2.getInt("saveKey") != i4) {
                        jSONObject2.put("saveKey", jSONObject2.getInt("saveKey") + 1000000 + (this.z0 * 100));
                    }
                    if (jSONObject2.getInt("keyOut") != -1) {
                        jSONObject2.put("keyOut", jSONObject2.getInt("keyOut") + 1000000 + (this.z0 * 100));
                    }
                    jSONObject2.put("unIdMcr", jC);
                    this.y0.add(jSONObject2);
                    i5++;
                    i4 = -1;
                }
            }
            jSONObject.put("numScreen", a1);
            if (jSONObject.getInt("saveKeyOut") != -1) {
                jSONObject.put("saveKeyOut", jSONObject.getInt("saveKeyOut") + 1000000 + (this.z0 * 100));
            }
            if (jSONObject.getInt("keyOutIn1") != -1) {
                jSONObject.put("keyOutIn1", jSONObject.getInt("keyOutIn1") + 1000000 + (this.z0 * 100));
            }
            if (jSONObject.getInt("keyOutIn2") != -1) {
                jSONObject.put("keyOutIn2", jSONObject.getInt("keyOutIn2") + 1000000 + (this.z0 * 100));
            }
            if (jSONObject.getInt("keyOutIn3") != -1) {
                jSONObject.put("keyOutIn3", jSONObject.getInt("keyOutIn3") + 1000000 + (this.z0 * 100));
            }
            if (jSONObject.getInt("keyOutIn4") != -1) {
                jSONObject.put("keyOutIn4", jSONObject.getInt("keyOutIn4") + 1000000 + (this.z0 * 100));
            }
            m(135, "", 0, 0, i2, i3, 0, "", 0, 0, jSONObject.toString());
        } catch (Exception unused) {
        }
        if (this.y0.size() > 0) {
            for (int i6 = 0; i6 < this.y0.size(); i6++) {
                try {
                    m(this.y0.get(i6).getInt("componentId"), "", 0, 0, this.y0.get(i6).getInt("x"), this.y0.get(i6).getInt("y"), 0, "", 0, 0, this.y0.get(i6).toString());
                } catch (Exception unused2) {
                }
            }
        }
        this.y0.clear();
        i0();
        y0();
    }

    public void c0() {
        Z0 = !Z0;
    }

    public void clickScreenLeft(View view) {
        s(false);
    }

    public void clickScreenRight(View view) {
        s(true);
    }

    public void d0() {
        g1 = !g1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void deleteView(View view) {
        SparseArray sparseArray;
        int key;
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (view.getTag() != null && !ru.himik.nightscream.kascada.CustomComponents.n.class.isInstance(view) && !ru.himik.nightscream.kascada.CustomComponents.h.class.isInstance(view)) {
            switch (((Integer) view.getTag()).intValue()) {
                case 1:
                    sparseArray = MyApplication.b().F;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.y) view).getKey();
                    break;
                case 2:
                    sparseArray = MyApplication.b().G;
                    key = ((CustomLabel) view).getKey();
                    break;
                case 4:
                    sparseArray = MyApplication.b().H;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.u) view).getKey();
                    break;
                case 5:
                    sparseArray = MyApplication.b().I;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.q) view).getKey();
                    break;
                case 6:
                    sparseArray = MyApplication.b().J;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.e) view).getKey();
                    break;
                case 7:
                    sparseArray = MyApplication.b().K;
                    key = ((CustomDynText) view).getKey();
                    break;
                case 8:
                    sparseArray = MyApplication.b().L;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.i) view).getKey();
                    break;
                case 9:
                    sparseArray = MyApplication.b().M;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.c) view).getKey();
                    break;
                case 10:
                    sparseArray = MyApplication.b().N;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.w) view).getKey();
                    break;
                case 11:
                    sparseArray = MyApplication.b().O;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.r) view).getKey();
                    break;
                case 12:
                    sparseArray = MyApplication.b().P;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.g) view).getKey();
                    break;
                case 13:
                    sparseArray = MyApplication.b().Q;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.v) view).getKey();
                    break;
                case 14:
                    sparseArray = MyApplication.b().R;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.o) view).getKey();
                    break;
                case 15:
                    sparseArray = MyApplication.b().S;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.d) view).getKey();
                    break;
                case 18:
                    sparseArray = MyApplication.b().V;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.x) view).getKey();
                    break;
                case 19:
                    sparseArray = MyApplication.b().W;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.k) view).getKey();
                    break;
                case 20:
                    sparseArray = MyApplication.b().X;
                    key = ((CustomList) view).getKey();
                    break;
                case 21:
                    sparseArray = MyApplication.b().Y;
                    key = ((CustomSound) view).getKey();
                    break;
                case 22:
                    sparseArray = MyApplication.b().Z;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.l) view).getKey();
                    break;
                case 23:
                    sparseArray = MyApplication.b().a0;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.f) view).getKey();
                    break;
                case 24:
                    sparseArray = MyApplication.b().b0;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.m) view).getKey();
                    break;
                case 25:
                    sparseArray = MyApplication.b().c0;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.t) view).getKey();
                    break;
                case 26:
                    ru.himik.nightscream.kascada.CustomComponents.b0 b0Var = (ru.himik.nightscream.kascada.CustomComponents.b0) view;
                    b0Var.destroy();
                    sparseArray = MyApplication.b().d0;
                    key = b0Var.getKey();
                    break;
                case 27:
                    sparseArray = MyApplication.b().f0;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.a0) view).getKey();
                    break;
                case 28:
                    sparseArray = MyApplication.b().e0;
                    key = ((ru.himik.nightscream.kascada.CustomComponents.j) view).getKey();
                    break;
            }
            sparseArray.remove(key);
        }
        if (view instanceof ru.himik.nightscream.kascada.CustomComponents.n) {
            MyApplication.b().T.remove(((ru.himik.nightscream.kascada.CustomComponents.n) view).getKey());
        }
        if (view instanceof ru.himik.nightscream.kascada.CustomComponents.h) {
            MyApplication.b().U.remove(((ru.himik.nightscream.kascada.CustomComponents.h) view).getKey());
        }
        if (view instanceof ru.himik.nightscream.kascada.Logic.c.a) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = (ru.himik.nightscream.kascada.Logic.c.a) view;
            aVar.a();
            MyApplication.b().D.remove(aVar.getKey());
            f1.invalidate();
        }
        viewGroup.removeView(view);
        this.f9201f.setVisibility(4);
        z0();
    }

    public void e0() {
        Intent intent = new Intent(this, (Class<?>) PrefActivityNetworkDevice.class);
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("networkDevice", MyApplication.b().E);
        bundle.putParcelableArrayList("serverList", MyApplication.b().f9036d);
        intent.putExtras(bundle);
        intent.putExtra("COUNT_DEVICE", MyApplication.b().f9042j);
        intent.putExtra("portraitMode", MyApplication.b().i0);
        startActivityForResult(intent, 9);
    }

    public void f(boolean[] zArr, Cursor cursor) {
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        a1 = 0;
        y0();
        this.L.k();
        System.currentTimeMillis();
        this.L.getLayoutParams().height = MyApplication.b().f9041i;
        this.L.getLayoutParams().width = MyApplication.b().f9040h;
        this.L.setY(0.0f);
        ((TextView) findViewById(R.id.numScreen)).setText(getResources().getString(R.string.custom_graph) + ": " + ((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getFileName());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();
        ArrayList arrayList = new ArrayList();
        if (cursor.moveToFirst()) {
            do {
                try {
                    f2 = cursor.getFloat(cursor.getColumnIndex("var1"));
                    try {
                        f3 = cursor.getFloat(cursor.getColumnIndex("var2"));
                        try {
                            try {
                                f4 = cursor.getFloat(cursor.getColumnIndex("var3"));
                                try {
                                    f5 = f2;
                                    f6 = f3;
                                    f7 = f4;
                                    f8 = cursor.getFloat(cursor.getColumnIndex("var4"));
                                } catch (Exception unused) {
                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_data_get_from_archive), 1).show();
                                    f5 = f2;
                                    f6 = f3;
                                    f7 = f4;
                                    f8 = 0.0f;
                                }
                            } catch (Exception unused2) {
                                f4 = 0.0f;
                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_data_get_from_archive), 1).show();
                                f5 = f2;
                                f6 = f3;
                                f7 = f4;
                                f8 = 0.0f;
                                String string = cursor.getString(cursor.getColumnIndex("_time"));
                                calendar.setTime(simpleDateFormat.parse(cursor.getString(cursor.getColumnIndex("_date")) + " " + string));
                                arrayList.add(new ru.himik.nightscream.kascada.CustomComponents.s(f5, f6, f7, f8, new Date(calendar.getTimeInMillis())));
                            }
                            calendar.setTime(simpleDateFormat.parse(cursor.getString(cursor.getColumnIndex("_date")) + " " + string));
                        } catch (ParseException unused3) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_data_get_from_archive_time), 1).show();
                        }
                    } catch (Exception unused4) {
                        f3 = 0.0f;
                        f4 = 0.0f;
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_data_get_from_archive), 1).show();
                        f5 = f2;
                        f6 = f3;
                        f7 = f4;
                        f8 = 0.0f;
                        String string2 = cursor.getString(cursor.getColumnIndex("_time"));
                        calendar.setTime(simpleDateFormat.parse(cursor.getString(cursor.getColumnIndex("_date")) + " " + string2));
                        arrayList.add(new ru.himik.nightscream.kascada.CustomComponents.s(f5, f6, f7, f8, new Date(calendar.getTimeInMillis())));
                    }
                } catch (Exception unused5) {
                    f2 = 0.0f;
                }
                String string3 = cursor.getString(cursor.getColumnIndex("_time"));
                arrayList.add(new ru.himik.nightscream.kascada.CustomComponents.s(f5, f6, f7, f8, new Date(calendar.getTimeInMillis())));
            } while (cursor.moveToNext());
        }
        this.L.j(zArr);
        System.currentTimeMillis();
        new Thread(new d0(arrayList)).start();
    }

    public void f0() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.action_set_password));
        EditText editText = new EditText(this);
        editText.setInputType(129);
        editText.setSelection(editText.getText().length());
        builder.setView(editText);
        builder.setPositiveButton(getResources().getString(R.string.dialog_accept), new h0(editText));
        builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new i0(this));
        builder.show();
    }

    /* JADX WARN: Code duplicated, block: B:103:0x0388 A[Catch: Exception -> 0x032f, TRY_ENTER, TRY_LEAVE, TryCatch #1 {Exception -> 0x032f, blocks: (B:84:0x0320, B:91:0x0349, B:95:0x035e, B:99:0x0373, B:103:0x0388), top: B:328:0x0320 }] */
    /* JADX WARN: Code duplicated, block: B:128:0x048b A[LOOP:0: B:21:0x00eb->B:128:0x048b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:132:0x04b4  */
    /* JADX WARN: Code duplicated, block: B:135:0x04ca  */
    /* JADX WARN: Code duplicated, block: B:151:0x0553 A[Catch: Exception -> 0x073f, LOOP:3: B:151:0x0553->B:228:0x072c, LOOP_START, PHI: r25 r41 r43
      0x0553: PHI (r25v3 java.lang.String) = (r25v1 java.lang.String), (r25v4 java.lang.String) binds: [B:150:0x0551, B:228:0x072c] A[DONT_GENERATE, DONT_INLINE]
      0x0553: PHI (r41v3 java.lang.String) = (r41v1 java.lang.String), (r41v4 java.lang.String) binds: [B:150:0x0551, B:228:0x072c] A[DONT_GENERATE, DONT_INLINE]
      0x0553: PHI (r43v3 java.lang.String) = (r43v1 java.lang.String), (r43v4 java.lang.String) binds: [B:150:0x0551, B:228:0x072c] A[DONT_GENERATE, DONT_INLINE], TRY_LEAVE, TryCatch #31 {Exception -> 0x073f, blocks: (B:149:0x0533, B:151:0x0553), top: B:380:0x0533 }] */
    /* JADX WARN: Code duplicated, block: B:154:0x0562  */
    /* JADX WARN: Code duplicated, block: B:156:0x0565  */
    /* JADX WARN: Code duplicated, block: B:158:0x0568  */
    /* JADX WARN: Code duplicated, block: B:160:0x056b  */
    /* JADX WARN: Code duplicated, block: B:161:0x0573  */
    /* JADX WARN: Code duplicated, block: B:187:0x05e3  */
    /* JADX WARN: Code duplicated, block: B:204:0x0661  */
    /* JADX WARN: Code duplicated, block: B:220:0x06c9 A[Catch: Exception -> 0x0735, TRY_LEAVE, TryCatch #6 {Exception -> 0x0735, blocks: (B:225:0x0725, B:217:0x06ac, B:220:0x06c9, B:221:0x06d8, B:222:0x06e5, B:224:0x06fd), top: B:338:0x0725, inners: #5 }] */
    /* JADX WARN: Code duplicated, block: B:228:0x072c A[LOOP:3: B:151:0x0553->B:228:0x072c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:231:0x0737  */
    /* JADX WARN: Code duplicated, block: B:252:0x0801 A[Catch: JSONException -> 0x08a6, TryCatch #20 {JSONException -> 0x08a6, blocks: (B:237:0x078b, B:238:0x079e, B:250:0x07e5, B:252:0x0801, B:254:0x0876, B:253:0x0838, B:249:0x07dd), top: B:364:0x078b }] */
    /* JADX WARN: Code duplicated, block: B:253:0x0838 A[Catch: JSONException -> 0x08a6, TryCatch #20 {JSONException -> 0x08a6, blocks: (B:237:0x078b, B:238:0x079e, B:250:0x07e5, B:252:0x0801, B:254:0x0876, B:253:0x0838, B:249:0x07dd), top: B:364:0x078b }] */
    /* JADX WARN: Code duplicated, block: B:263:0x092c  */
    /* JADX WARN: Code duplicated, block: B:264:0x092f  */
    /* JADX WARN: Code duplicated, block: B:271:0x0946  */
    /* JADX WARN: Code duplicated, block: B:287:0x09e4 A[Catch: JSONException -> 0x0b8e, TryCatch #37 {JSONException -> 0x0b8e, blocks: (B:285:0x09d4, B:287:0x09e4, B:293:0x09f7, B:295:0x0a03, B:296:0x0a45, B:297:0x0a48, B:298:0x0a4b, B:305:0x0b1f, B:307:0x0b2b, B:308:0x0b6d, B:309:0x0b70, B:310:0x0b73), top: B:390:0x09d4 }] */
    /* JADX WARN: Code duplicated, block: B:289:0x09f1  */
    /* JADX WARN: Code duplicated, block: B:291:0x09f4  */
    /* JADX WARN: Code duplicated, block: B:293:0x09f7 A[Catch: JSONException -> 0x0b8e, TryCatch #37 {JSONException -> 0x0b8e, blocks: (B:285:0x09d4, B:287:0x09e4, B:293:0x09f7, B:295:0x0a03, B:296:0x0a45, B:297:0x0a48, B:298:0x0a4b, B:305:0x0b1f, B:307:0x0b2b, B:308:0x0b6d, B:309:0x0b70, B:310:0x0b73), top: B:390:0x09d4 }] */
    /* JADX WARN: Code duplicated, block: B:295:0x0a03 A[Catch: JSONException -> 0x0b8e, TryCatch #37 {JSONException -> 0x0b8e, blocks: (B:285:0x09d4, B:287:0x09e4, B:293:0x09f7, B:295:0x0a03, B:296:0x0a45, B:297:0x0a48, B:298:0x0a4b, B:305:0x0b1f, B:307:0x0b2b, B:308:0x0b6d, B:309:0x0b70, B:310:0x0b73), top: B:390:0x09d4 }] */
    /* JADX WARN: Code duplicated, block: B:299:0x0b15  */
    /* JADX WARN: Code duplicated, block: B:302:0x0b1a  */
    /* JADX WARN: Code duplicated, block: B:305:0x0b1f A[Catch: JSONException -> 0x0b8e, TryCatch #37 {JSONException -> 0x0b8e, blocks: (B:285:0x09d4, B:287:0x09e4, B:293:0x09f7, B:295:0x0a03, B:296:0x0a45, B:297:0x0a48, B:298:0x0a4b, B:305:0x0b1f, B:307:0x0b2b, B:308:0x0b6d, B:309:0x0b70, B:310:0x0b73), top: B:390:0x09d4 }] */
    /* JADX WARN: Code duplicated, block: B:307:0x0b2b A[Catch: JSONException -> 0x0b8e, TryCatch #37 {JSONException -> 0x0b8e, blocks: (B:285:0x09d4, B:287:0x09e4, B:293:0x09f7, B:295:0x0a03, B:296:0x0a45, B:297:0x0a48, B:298:0x0a4b, B:305:0x0b1f, B:307:0x0b2b, B:308:0x0b6d, B:309:0x0b70, B:310:0x0b73), top: B:390:0x09d4 }] */
    /* JADX WARN: Code duplicated, block: B:310:0x0b73 A[Catch: JSONException -> 0x0b8e, TRY_LEAVE, TryCatch #37 {JSONException -> 0x0b8e, blocks: (B:285:0x09d4, B:287:0x09e4, B:293:0x09f7, B:295:0x0a03, B:296:0x0a45, B:297:0x0a48, B:298:0x0a4b, B:305:0x0b1f, B:307:0x0b2b, B:308:0x0b6d, B:309:0x0b70, B:310:0x0b73), top: B:390:0x09d4 }] */
    /* JADX WARN: Code duplicated, block: B:316:0x0bc7 A[Catch: Exception -> 0x0c15, LOOP:7: B:316:0x0bc7->B:321:0x0c12, LOOP_START, PHI: r3
      0x0bc7: PHI (r3v20 int) = (r3v17 int), (r3v21 int) binds: [B:315:0x0bc5, B:321:0x0c12] A[DONT_GENERATE, DONT_INLINE], TryCatch #28 {Exception -> 0x0c15, blocks: (B:314:0x0bb2, B:316:0x0bc7, B:318:0x0bcd, B:320:0x0bdd), top: B:374:0x0bb2 }] */
    /* JADX WARN: Code duplicated, block: B:318:0x0bcd A[Catch: Exception -> 0x0c15, TryCatch #28 {Exception -> 0x0c15, blocks: (B:314:0x0bb2, B:316:0x0bc7, B:318:0x0bcd, B:320:0x0bdd), top: B:374:0x0bb2 }] */
    /* JADX WARN: Code duplicated, block: B:320:0x0bdd A[Catch: Exception -> 0x0c15, TRY_LEAVE, TryCatch #28 {Exception -> 0x0c15, blocks: (B:314:0x0bb2, B:316:0x0bc7, B:318:0x0bcd, B:320:0x0bdd), top: B:374:0x0bb2 }] */
    /* JADX WARN: Code duplicated, block: B:328:0x0320 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:350:0x04d3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:356:0x07a2 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:391:0x093e A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:399:0x04b0 A[EDGE_INSN: B:399:0x04b0->B:130:0x04b0 BREAK  A[LOOP:0: B:21:0x00eb->B:128:0x048b], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:404:0x0767 A[EDGE_INSN: B:404:0x0767->B:236:0x0767 BREAK  A[LOOP:3: B:151:0x0553->B:228:0x072c], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:409:0x0a45 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:412:0x0c12 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:415:0x0b6d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:91:0x0349 A[Catch: Exception -> 0x032f, TRY_ENTER, TRY_LEAVE, TryCatch #1 {Exception -> 0x032f, blocks: (B:84:0x0320, B:91:0x0349, B:95:0x035e, B:99:0x0373, B:103:0x0388), top: B:328:0x0320 }] */
    /* JADX WARN: Code duplicated, block: B:95:0x035e A[Catch: Exception -> 0x032f, TRY_ENTER, TRY_LEAVE, TryCatch #1 {Exception -> 0x032f, blocks: (B:84:0x0320, B:91:0x0349, B:95:0x035e, B:99:0x0373, B:103:0x0388), top: B:328:0x0320 }] */
    /* JADX WARN: Code duplicated, block: B:99:0x0373 A[Catch: Exception -> 0x032f, TRY_ENTER, TRY_LEAVE, TryCatch #1 {Exception -> 0x032f, blocks: (B:84:0x0320, B:91:0x0349, B:95:0x035e, B:99:0x0373, B:103:0x0388), top: B:328:0x0320 }] */
    /* JADX WARN: Instruction removed from duplicated block: B:252:0x0801, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:253:0x0838, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:320:0x0bdd, please report this as an issue */
    public void g() {
        String str;
        SQLiteDatabase sQLiteDatabase;
        String str2;
        String str3;
        int i2;
        String str4;
        String str5;
        String str6;
        Exception exc;
        Cursor cursorRawQuery;
        int i3;
        Exception exc2;
        JSONArray jSONArray;
        String string;
        int iIndexOf;
        String string2;
        JSONArray jSONArray2;
        int i4;
        int i5;
        int i6;
        int i7;
        JSONObject jSONObject;
        String string3;
        int i8;
        boolean z2;
        String str7;
        StringBuilder sb;
        int i9;
        x0 x0Var;
        Cursor cursorQuery;
        int i10;
        int i11;
        boolean z3;
        Exception exc3;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        boolean z4;
        int i17;
        int i18;
        boolean z5;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        String str8;
        String str9;
        String str10;
        Exception exc4;
        String str11;
        String str12 = "keyOutIn4";
        String str13 = "keyOutIn3";
        String str14 = "keyOutIn2";
        String str15 = "keyOutIn1";
        String str16 = "saveKeyOut";
        String str17 = "screen";
        String str18 = "server";
        MyApplication.b().a();
        SQLiteDatabase writableDatabase = this.f9203h.getWritableDatabase();
        try {
            Cursor cursorRawQuery2 = writableDatabase.rawQuery("SELECT settings FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
            cursorRawQuery2.moveToFirst();
            JSONObject jSONObject2 = new JSONObject(cursorRawQuery2.getString(cursorRawQuery2.getColumnIndex("settings")));
            this.M = jSONObject2.getInt("widthDisplay");
            this.N = jSONObject2.getInt("heightDisplay");
            MyApplication.b().i0 = jSONObject2.getBoolean("portraitMode");
            try {
                MyApplication.b().f9046n = jSONObject2.getBoolean("backgroundWork");
            } catch (Exception e2) {
                YandexMetrica.reportError("Загрузка фона", e2);
                e2.printStackTrace();
            }
            try {
                f.f.b.e eVar = new f.f.b.e();
                MyApplication.b().o0 = (ru.himik.nightscream.kascada.q.b.a) eVar.i(jSONObject2.getString("MQTT_Server"), ru.himik.nightscream.kascada.q.b.a.class);
                try {
                    MyApplication.b().p0 = (ru.himik.nightscream.kascada.q.b.a) eVar.i(jSONObject2.getString("MQTT_Server2"), ru.himik.nightscream.kascada.q.b.a.class);
                } catch (Exception unused) {
                }
            } catch (Exception e3) {
                YandexMetrica.reportError("Загрузка MQTT сервера", e3);
                e3.printStackTrace();
            }
        } catch (Exception e4) {
            YandexMetrica.reportError("Загрузка Settings", e4);
            e4.printStackTrace();
        }
        Cursor cursorQuery2 = writableDatabase.query(MyApplication.b().k0, null, null, null, null, null, null);
        boolean zMoveToFirst = cursorQuery2.moveToFirst();
        String str19 = "componentId";
        String str20 = IMAPStore.ID_NAME;
        String str21 = "rtu";
        if (zMoveToFirst) {
            while (true) {
                int i24 = cursorQuery2.getInt(cursorQuery2.getColumnIndex(str19));
                String string4 = cursorQuery2.getString(cursorQuery2.getColumnIndex("text"));
                int i25 = cursorQuery2.getInt(cursorQuery2.getColumnIndex("width"));
                int i26 = cursorQuery2.getInt(cursorQuery2.getColumnIndex("height"));
                String str22 = str19;
                int i27 = cursorQuery2.getInt(cursorQuery2.getColumnIndex("x"));
                sQLiteDatabase = writableDatabase;
                int i28 = cursorQuery2.getInt(cursorQuery2.getColumnIndex("y"));
                str2 = str18;
                int i29 = this.M;
                str3 = str17;
                if (i29 != 0 && this.N != 0 && i29 != MyApplication.b().f9040h && this.N != MyApplication.b().f9041i) {
                    i28 = (int) (MyApplication.b().f9041i * (i28 / this.N));
                    i26 = (int) (MyApplication.b().f9041i * (i26 / this.N));
                    i27 = (int) (MyApplication.b().f9040h * (i27 / this.M));
                    i25 = (int) (MyApplication.b().f9040h * (i25 / this.M));
                }
                int i30 = cursorQuery2.getInt(cursorQuery2.getColumnIndex("textSize"));
                String string5 = cursorQuery2.getString(cursorQuery2.getColumnIndex("connectionInfo"));
                int i31 = cursorQuery2.getInt(cursorQuery2.getColumnIndex("colorText"));
                int i32 = cursorQuery2.getInt(cursorQuery2.getColumnIndex("colorBackground"));
                String string6 = cursorQuery2.getString(cursorQuery2.getColumnIndex("other"));
                if (i25 < 10) {
                    z5 = true;
                    this.x0 = true;
                    i19 = 100;
                } else {
                    z5 = true;
                    i19 = i25;
                }
                if (i26 < 10) {
                    this.x0 = z5;
                    i20 = 100;
                } else {
                    i20 = i26;
                }
                if (i27 >= MyApplication.b().f9040h) {
                    i27 = MyApplication.b().f9040h / 2;
                    this.x0 = z5;
                }
                if (i28 >= MyApplication.b().f9041i) {
                    i28 = MyApplication.b().f9041i / 2;
                    this.x0 = z5;
                }
                if (i27 + i19 <= 0 || i28 + i20 <= 0) {
                    int i33 = MyApplication.b().f9040h / 2;
                    int i34 = MyApplication.b().f9041i / 2;
                    i21 = 1;
                    this.x0 = true;
                    i22 = i33;
                    i23 = i34;
                } else {
                    i22 = i27;
                    i23 = i28;
                    i21 = 1;
                }
                if (i24 == 135) {
                    this.z0 += i21;
                    try {
                        JSONObject jSONObject3 = new JSONObject(string6);
                        JSONObject jSONObject4 = new JSONObject(ru.himik.nightscream.kascada.Utils.n.a.g(jSONObject3.getString(str20), MyApplication.b().m0));
                        String str23 = str16;
                        try {
                            long jC = ru.himik.nightscream.kascada.Utils.q.c();
                            jSONObject4.put("uniqueId", jC);
                            JSONArray jSONArray3 = new JSONArray(jSONObject4.getString("fbInMacros"));
                            i24 = i24;
                            str20 = str20;
                            cursorQuery2 = cursorQuery2;
                            if (jSONArray3.length() > 0) {
                                int i35 = 0;
                                while (i35 < jSONArray3.length()) {
                                    try {
                                        JSONObject jSONObject5 = jSONArray3.getJSONObject(i35);
                                        JSONArray jSONArray4 = jSONArray3;
                                        str11 = string6;
                                        if (jSONObject5.getInt("saveKey") != -1) {
                                            try {
                                                jSONObject5.put("saveKey", jSONObject5.getInt("saveKey") + 1000000 + (this.z0 * 100));
                                            } catch (Exception e5) {
                                                exc4 = e5;
                                                str8 = str23;
                                                str9 = str11;
                                                i2 = 0;
                                                str10 = str12;
                                                str = str22;
                                                YandexMetrica.reportError("Загрузка макроса", exc4);
                                                exc4.printStackTrace();
                                                m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, str9);
                                                if (!cursorQuery2.moveToNext()) {
                                                    break;
                                                    if (this.x0) {
                                                        Toast.makeText(getApplicationContext(), R.string.detect_properties_problems_component, i2).show();
                                                    }
                                                    if (this.y0.size() > 0) {
                                                        i17 = 0;
                                                        while (i17 < this.y0.size()) {
                                                            try {
                                                                i18 = i17;
                                                                try {
                                                                    m(this.y0.get(i17).getInt(str), "", 0, 0, this.y0.get(i17).getInt("x"), this.y0.get(i17).getInt("y"), 0, "", 0, 0, this.y0.get(i17).toString());
                                                                } catch (Exception e6) {
                                                                    e = e6;
                                                                    Exception exc5 = e;
                                                                    YandexMetrica.reportError("mbCanvas.LoadFromBd: load fb from macro error", exc5);
                                                                    exc5.printStackTrace();
                                                                }
                                                            } catch (Exception e7) {
                                                                e = e7;
                                                                i18 = i17;
                                                            }
                                                            i17 = i18 + 1;
                                                        }
                                                    }
                                                    this.y0.clear();
                                                    i0();
                                                    cursorQuery = sQLiteDatabase.query(MyApplication.b().j0, null, null, null, null, null, null);
                                                    if (cursorQuery.moveToFirst()) {
                                                        while (true) {
                                                            i10 = cursorQuery.getInt(cursorQuery.getColumnIndex("connectionsId"));
                                                            if (i10 != 1) {
                                                                str4 = str2;
                                                                str5 = str20;
                                                                str6 = str21;
                                                                try {
                                                                    JSONObject jSONObject6 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                                    MyApplication.b().f9036d.add(new ru.himik.nightscream.kascada.Preference.ServerList.a(1, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), jSONObject6.getString(str4), jSONObject6.getInt("pause")));
                                                                } catch (JSONException e8) {
                                                                    YandexMetrica.reportError("Загрузка сервера Bluetooth", e8);
                                                                    e8.printStackTrace();
                                                                    MyApplication.b().f9036d.add(new ru.himik.nightscream.kascada.Preference.ServerList.a(1, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), cursorQuery.getString(cursorQuery.getColumnIndex(str4)), 0));
                                                                }
                                                            } else if (i10 != 2) {
                                                                if (i10 != 3) {
                                                                    str4 = str2;
                                                                    str6 = str21;
                                                                    int i36 = 9600;
                                                                    try {
                                                                        JSONObject jSONObject7 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                                        i36 = jSONObject7.getInt("baudRate");
                                                                        i12 = jSONObject7.getInt("dataBits");
                                                                        try {
                                                                            i13 = jSONObject7.getInt("stopBits");
                                                                            try {
                                                                                i15 = jSONObject7.getInt("parity");
                                                                                try {
                                                                                    i14 = jSONObject7.getInt("pause");
                                                                                } catch (Exception unused2) {
                                                                                    i14 = 0;
                                                                                }
                                                                            } catch (Exception e9) {
                                                                                exc3 = e9;
                                                                                YandexMetrica.reportError("Загрузка сервера USB", exc3);
                                                                                exc3.printStackTrace();
                                                                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_usb_settings), 1).show();
                                                                                i14 = 0;
                                                                                i15 = 0;
                                                                            }
                                                                        } catch (Exception e10) {
                                                                            exc3 = e10;
                                                                            i13 = 2;
                                                                            YandexMetrica.reportError("Загрузка сервера USB", exc3);
                                                                            exc3.printStackTrace();
                                                                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_usb_settings), 1).show();
                                                                            i14 = 0;
                                                                            i15 = 0;
                                                                            ru.himik.nightscream.kascada.Preference.ServerList.a aVar = new ru.himik.nightscream.kascada.Preference.ServerList.a(3, "Usb", "", i14);
                                                                            aVar.m(i36);
                                                                            aVar.o(i12);
                                                                            aVar.u(i13);
                                                                            aVar.q(i15);
                                                                            MyApplication.b().f9036d.add(aVar);
                                                                            str5 = str20;
                                                                            if (!cursorQuery.moveToNext()) {
                                                                                break;
                                                                                SQLiteDatabase sQLiteDatabase2 = sQLiteDatabase;
                                                                                Cursor cursorRawQuery3 = sQLiteDatabase2.rawQuery("SELECT screenBackground FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                                cursorRawQuery3.moveToFirst();
                                                                                jSONObject = new JSONObject(cursorRawQuery3.getString(cursorRawQuery3.getColumnIndex("screenBackground")));
                                                                                string3 = "";
                                                                                i8 = 0;
                                                                                z2 = false;
                                                                                while (i8 < b1) {
                                                                                    StringBuilder sb2 = new StringBuilder();
                                                                                    str7 = str3;
                                                                                    sb2.append(str7);
                                                                                    int i37 = i8 + 1;
                                                                                    sb2.append(i37);
                                                                                    sb2.append("DefaultBackground");
                                                                                    z2 = jSONObject.getBoolean(sb2.toString());
                                                                                    string3 = jSONObject.getString(str7 + i37 + "Pass");
                                                                                    sb = new StringBuilder();
                                                                                    sb.append(str7);
                                                                                    i9 = i8 + 1;
                                                                                    sb.append(i9);
                                                                                    sb.append("IsColor");
                                                                                    if (jSONObject.getBoolean(sb.toString())) {
                                                                                        x0Var = new x0(Boolean.TRUE, "", jSONObject.getInt(str7 + i9 + "Color"), string3, getResources().getString(R.string.screen));
                                                                                        MyApplication.b().C.add(x0Var);
                                                                                    } else {
                                                                                        x0Var = new x0(Boolean.FALSE, jSONObject.getString(str7 + i9 + "PathImage"), 15592941, string3, getResources().getString(R.string.screen));
                                                                                        MyApplication.b().C.add(x0Var);
                                                                                        m0(x0Var.f(), x0Var);
                                                                                    }
                                                                                    x0Var.j(z2);
                                                                                    MyApplication.b().C.get(i8).l(jSONObject.getString(str7 + i9 + "Name"));
                                                                                    str3 = str7;
                                                                                    i8 = i9;
                                                                                }
                                                                                cursorRawQuery = sQLiteDatabase2.rawQuery("SELECT stationMode,countDevice,deviceNetwork,pdfDocument,showTimeOut,systemRegisters FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                                cursorRawQuery.moveToFirst();
                                                                                MyApplication.b().f9043k = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pdfDocument"));
                                                                                if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("stationMode")) == 1) {
                                                                                    Z0 = true;
                                                                                } else {
                                                                                    Z0 = false;
                                                                                }
                                                                                if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("showTimeOut")) == 1) {
                                                                                    g1 = true;
                                                                                    i3 = 0;
                                                                                } else {
                                                                                    i3 = 0;
                                                                                    g1 = false;
                                                                                }
                                                                                Cursor cursorRawQuery4 = sQLiteDatabase2.rawQuery("SELECT modbusSlave FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                                cursorRawQuery4.moveToFirst();
                                                                                JSONObject jSONObject8 = new JSONObject(cursorRawQuery4.getString(cursorRawQuery4.getColumnIndex("modbusSlave")));
                                                                                MyApplication.b().f9039g = jSONObject8.getInt("modbusSlavePort");
                                                                                MyApplication.b().f9037e = jSONObject8.getBoolean("kascadaCloudSlave");
                                                                                MyApplication.b().f9038f = jSONObject8.getBoolean("kascadaCloudRemoteControl");
                                                                                MyApplication.b().f9042j = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("countDevice"));
                                                                                string2 = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("deviceNetwork"));
                                                                                if (string2.length() > 0) {
                                                                                    jSONArray2 = new JSONArray(string2);
                                                                                    if (jSONArray2.length() == 8) {
                                                                                        for (i6 = 0; i6 < 8; i6++) {
                                                                                            for (i7 = 0; i7 < 8; i7++) {
                                                                                                if (jSONArray2.getJSONObject(i7).getInt("num") == i6) {
                                                                                                    String string7 = jSONArray2.getJSONObject(i7).getString(str5);
                                                                                                    String string8 = jSONArray2.getJSONObject(i7).getString(str4);
                                                                                                    int i38 = jSONArray2.getJSONObject(i7).getInt(IMAPStore.ID_ADDRESS);
                                                                                                    int i39 = jSONArray2.getJSONObject(i7).getInt("idServer");
                                                                                                    boolean z6 = jSONArray2.getJSONObject(i7).getBoolean(str6);
                                                                                                    ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar2 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string7, i38, string8, "", "", i39);
                                                                                                    aVar2.m(z6);
                                                                                                    MyApplication.b().E.add(aVar2);
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
                                                                                    } else {
                                                                                        for (i4 = 0; i4 < 16; i4++) {
                                                                                            for (i5 = 0; i5 < 16; i5++) {
                                                                                                if (jSONArray2.getJSONObject(i5).getInt("num") == i4) {
                                                                                                    String string9 = jSONArray2.getJSONObject(i5).getString(str5);
                                                                                                    String string10 = jSONArray2.getJSONObject(i5).getString(str4);
                                                                                                    int i40 = jSONArray2.getJSONObject(i5).getInt(IMAPStore.ID_ADDRESS);
                                                                                                    int i41 = jSONArray2.getJSONObject(i5).getInt("idServer");
                                                                                                    boolean z7 = jSONArray2.getJSONObject(i5).getBoolean(str6);
                                                                                                    ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar3 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string9, i40, string10, "", "", i41);
                                                                                                    aVar3.m(z7);
                                                                                                    MyApplication.b().E.add(aVar3);
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                } else {
                                                                                    x();
                                                                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.list_device_empty), 1).show();
                                                                                }
                                                                                jSONArray = new JSONArray(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("systemRegisters")));
                                                                                if (jSONArray.length() > 0) {
                                                                                    while (i3 < jSONArray.length()) {
                                                                                        string = jSONArray.getJSONObject(i3).toString();
                                                                                        iIndexOf = string.indexOf("_");
                                                                                        if (iIndexOf > 0) {
                                                                                            int i42 = Integer.parseInt(string.substring(iIndexOf + 1, string.indexOf(":") - 1));
                                                                                            MyApplication.b().v0.f9265j[i42] = jSONArray.getJSONObject(i3).getInt("reg_" + i42);
                                                                                        }
                                                                                        i3++;
                                                                                    }
                                                                                }
                                                                                f1.invalidate();
                                                                            }
                                                                            str2 = str4;
                                                                            str21 = str6;
                                                                            str20 = str5;
                                                                        }
                                                                    } catch (Exception e11) {
                                                                        exc3 = e11;
                                                                        i12 = 8;
                                                                    }
                                                                    ru.himik.nightscream.kascada.Preference.ServerList.a aVar4 = new ru.himik.nightscream.kascada.Preference.ServerList.a(3, "Usb", "", i14);
                                                                    aVar4.m(i36);
                                                                    aVar4.o(i12);
                                                                    aVar4.u(i13);
                                                                    aVar4.q(i15);
                                                                    MyApplication.b().f9036d.add(aVar4);
                                                                } else if (i10 != 4) {
                                                                    str4 = str2;
                                                                    str5 = str20;
                                                                    str6 = str21;
                                                                } else {
                                                                    String string11 = "error";
                                                                    try {
                                                                        str4 = str2;
                                                                        try {
                                                                            JSONObject jSONObject9 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                                            string11 = jSONObject9.getString(str4);
                                                                            str6 = str21;
                                                                            try {
                                                                                try {
                                                                                    z4 = jSONObject9.getBoolean(str6);
                                                                                    try {
                                                                                        i16 = jSONObject9.getInt("pause");
                                                                                    } catch (Exception unused3) {
                                                                                        i16 = 0;
                                                                                    }
                                                                                } catch (JSONException e12) {
                                                                                    e = e12;
                                                                                    JSONException jSONException = e;
                                                                                    YandexMetrica.reportError("Загрузка сервера Cloud", jSONException);
                                                                                    jSONException.printStackTrace();
                                                                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_cloud_settings), 1).show();
                                                                                    i16 = 0;
                                                                                    z4 = false;
                                                                                }
                                                                            } catch (Exception e13) {
                                                                                e = e13;
                                                                                exc = e;
                                                                                str5 = str20;
                                                                                YandexMetrica.reportError("Ошибка при загрузке настроек подключений", exc);
                                                                                exc.printStackTrace();
                                                                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_settings_network), 0).show();
                                                                            }
                                                                        } catch (JSONException e14) {
                                                                            e = e14;
                                                                            str6 = str21;
                                                                            JSONException jSONException2 = e;
                                                                            YandexMetrica.reportError("Загрузка сервера Cloud", jSONException2);
                                                                            jSONException2.printStackTrace();
                                                                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_cloud_settings), 1).show();
                                                                            i16 = 0;
                                                                            z4 = false;
                                                                            ru.himik.nightscream.kascada.Preference.ServerList.a aVar5 = new ru.himik.nightscream.kascada.Preference.ServerList.a(4, "KaScada Cloud", string11, i16);
                                                                            aVar5.s(z4);
                                                                            MyApplication.b().f9036d.add(aVar5);
                                                                            str5 = str20;
                                                                            if (!cursorQuery.moveToNext()) {
                                                                                break;
                                                                                SQLiteDatabase sQLiteDatabase3 = sQLiteDatabase;
                                                                                Cursor cursorRawQuery5 = sQLiteDatabase3.rawQuery("SELECT screenBackground FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                                cursorRawQuery5.moveToFirst();
                                                                                jSONObject = new JSONObject(cursorRawQuery5.getString(cursorRawQuery5.getColumnIndex("screenBackground")));
                                                                                string3 = "";
                                                                                i8 = 0;
                                                                                z2 = false;
                                                                                while (i8 < b1) {
                                                                                    try {
                                                                                        StringBuilder sb3 = new StringBuilder();
                                                                                        str7 = str3;
                                                                                        try {
                                                                                            sb3.append(str7);
                                                                                            int i310 = i8 + 1;
                                                                                            sb3.append(i310);
                                                                                            sb3.append("DefaultBackground");
                                                                                            z2 = jSONObject.getBoolean(sb3.toString());
                                                                                            string3 = jSONObject.getString(str7 + i310 + "Pass");
                                                                                        } catch (Exception e15) {
                                                                                            e = e15;
                                                                                            Exception exc6 = e;
                                                                                            YandexMetrica.reportError("Ошибка при импоте настроек подключений", exc6);
                                                                                            exc6.printStackTrace();
                                                                                        }
                                                                                    } catch (Exception e16) {
                                                                                        e = e16;
                                                                                        str7 = str3;
                                                                                    }
                                                                                    sb = new StringBuilder();
                                                                                    sb.append(str7);
                                                                                    i9 = i8 + 1;
                                                                                    sb.append(i9);
                                                                                    sb.append("IsColor");
                                                                                    if (jSONObject.getBoolean(sb.toString())) {
                                                                                        x0Var = new x0(Boolean.TRUE, "", jSONObject.getInt(str7 + i9 + "Color"), string3, getResources().getString(R.string.screen));
                                                                                        MyApplication.b().C.add(x0Var);
                                                                                    } else {
                                                                                        x0Var = new x0(Boolean.FALSE, jSONObject.getString(str7 + i9 + "PathImage"), 15592941, string3, getResources().getString(R.string.screen));
                                                                                        MyApplication.b().C.add(x0Var);
                                                                                        m0(x0Var.f(), x0Var);
                                                                                    }
                                                                                    x0Var.j(z2);
                                                                                    MyApplication.b().C.get(i8).l(jSONObject.getString(str7 + i9 + "Name"));
                                                                                    str3 = str7;
                                                                                    i8 = i9;
                                                                                }
                                                                                cursorRawQuery = sQLiteDatabase3.rawQuery("SELECT stationMode,countDevice,deviceNetwork,pdfDocument,showTimeOut,systemRegisters FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                                cursorRawQuery.moveToFirst();
                                                                                MyApplication.b().f9043k = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pdfDocument"));
                                                                                if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("stationMode")) == 1) {
                                                                                    Z0 = true;
                                                                                } else {
                                                                                    Z0 = false;
                                                                                }
                                                                                if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("showTimeOut")) == 1) {
                                                                                    try {
                                                                                        g1 = true;
                                                                                        i3 = 0;
                                                                                    } catch (Exception e17) {
                                                                                        exc2 = e17;
                                                                                        i3 = 0;
                                                                                        YandexMetrica.reportError("Загрузка stationMode", exc2);
                                                                                        exc2.printStackTrace();
                                                                                        Toast.makeText(getApplicationContext(), exc2.toString(), 1).show();
                                                                                    }
                                                                                } else {
                                                                                    i3 = 0;
                                                                                    try {
                                                                                        g1 = false;
                                                                                    } catch (Exception e18) {
                                                                                        e = e18;
                                                                                        exc2 = e;
                                                                                        YandexMetrica.reportError("Загрузка stationMode", exc2);
                                                                                        exc2.printStackTrace();
                                                                                        Toast.makeText(getApplicationContext(), exc2.toString(), 1).show();
                                                                                    }
                                                                                }
                                                                                Cursor cursorRawQuery6 = sQLiteDatabase3.rawQuery("SELECT modbusSlave FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                                cursorRawQuery6.moveToFirst();
                                                                                JSONObject jSONObject10 = new JSONObject(cursorRawQuery6.getString(cursorRawQuery6.getColumnIndex("modbusSlave")));
                                                                                MyApplication.b().f9039g = jSONObject10.getInt("modbusSlavePort");
                                                                                MyApplication.b().f9037e = jSONObject10.getBoolean("kascadaCloudSlave");
                                                                                MyApplication.b().f9038f = jSONObject10.getBoolean("kascadaCloudRemoteControl");
                                                                                MyApplication.b().f9042j = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("countDevice"));
                                                                                string2 = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("deviceNetwork"));
                                                                                if (string2.length() > 0) {
                                                                                    jSONArray2 = new JSONArray(string2);
                                                                                    if (jSONArray2.length() == 8) {
                                                                                        while (i6 < 8) {
                                                                                            while (i7 < 8) {
                                                                                                if (jSONArray2.getJSONObject(i7).getInt("num") == i6) {
                                                                                                    String string12 = jSONArray2.getJSONObject(i7).getString(str5);
                                                                                                    String string13 = jSONArray2.getJSONObject(i7).getString(str4);
                                                                                                    int i311 = jSONArray2.getJSONObject(i7).getInt(IMAPStore.ID_ADDRESS);
                                                                                                    int i312 = jSONArray2.getJSONObject(i7).getInt("idServer");
                                                                                                    boolean z8 = jSONArray2.getJSONObject(i7).getBoolean(str6);
                                                                                                    ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar6 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string12, i311, string13, "", "", i312);
                                                                                                    aVar6.m(z8);
                                                                                                    MyApplication.b().E.add(aVar6);
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
                                                                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
                                                                                    } else {
                                                                                        while (i4 < 16) {
                                                                                            while (i5 < 16) {
                                                                                                if (jSONArray2.getJSONObject(i5).getInt("num") == i4) {
                                                                                                    String string14 = jSONArray2.getJSONObject(i5).getString(str5);
                                                                                                    String string15 = jSONArray2.getJSONObject(i5).getString(str4);
                                                                                                    int i43 = jSONArray2.getJSONObject(i5).getInt(IMAPStore.ID_ADDRESS);
                                                                                                    int i44 = jSONArray2.getJSONObject(i5).getInt("idServer");
                                                                                                    boolean z9 = jSONArray2.getJSONObject(i5).getBoolean(str6);
                                                                                                    ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar7 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string14, i43, string15, "", "", i44);
                                                                                                    aVar7.m(z9);
                                                                                                    MyApplication.b().E.add(aVar7);
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                } else {
                                                                                    x();
                                                                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.list_device_empty), 1).show();
                                                                                }
                                                                                jSONArray = new JSONArray(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("systemRegisters")));
                                                                                if (jSONArray.length() > 0) {
                                                                                    while (i3 < jSONArray.length()) {
                                                                                        string = jSONArray.getJSONObject(i3).toString();
                                                                                        iIndexOf = string.indexOf("_");
                                                                                        if (iIndexOf > 0) {
                                                                                            int i45 = Integer.parseInt(string.substring(iIndexOf + 1, string.indexOf(":") - 1));
                                                                                            MyApplication.b().v0.f9265j[i45] = jSONArray.getJSONObject(i3).getInt("reg_" + i45);
                                                                                        }
                                                                                        i3++;
                                                                                    }
                                                                                }
                                                                                f1.invalidate();
                                                                            }
                                                                            str2 = str4;
                                                                            str21 = str6;
                                                                            str20 = str5;
                                                                        } catch (Exception e19) {
                                                                            e = e19;
                                                                            str6 = str21;
                                                                            exc = e;
                                                                            str5 = str20;
                                                                            YandexMetrica.reportError("Ошибка при загрузке настроек подключений", exc);
                                                                            exc.printStackTrace();
                                                                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_settings_network), 0).show();
                                                                            SQLiteDatabase sQLiteDatabase4 = sQLiteDatabase;
                                                                            Cursor cursorRawQuery7 = sQLiteDatabase4.rawQuery("SELECT screenBackground FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                            cursorRawQuery7.moveToFirst();
                                                                            jSONObject = new JSONObject(cursorRawQuery7.getString(cursorRawQuery7.getColumnIndex("screenBackground")));
                                                                            string3 = "";
                                                                            i8 = 0;
                                                                            z2 = false;
                                                                            while (i8 < b1) {
                                                                                StringBuilder sb4 = new StringBuilder();
                                                                                str7 = str3;
                                                                                sb4.append(str7);
                                                                                int i313 = i8 + 1;
                                                                                sb4.append(i313);
                                                                                sb4.append("DefaultBackground");
                                                                                z2 = jSONObject.getBoolean(sb4.toString());
                                                                                string3 = jSONObject.getString(str7 + i313 + "Pass");
                                                                                sb = new StringBuilder();
                                                                                sb.append(str7);
                                                                                i9 = i8 + 1;
                                                                                sb.append(i9);
                                                                                sb.append("IsColor");
                                                                                if (jSONObject.getBoolean(sb.toString())) {
                                                                                    x0Var = new x0(Boolean.TRUE, "", jSONObject.getInt(str7 + i9 + "Color"), string3, getResources().getString(R.string.screen));
                                                                                    MyApplication.b().C.add(x0Var);
                                                                                } else {
                                                                                    x0Var = new x0(Boolean.FALSE, jSONObject.getString(str7 + i9 + "PathImage"), 15592941, string3, getResources().getString(R.string.screen));
                                                                                    MyApplication.b().C.add(x0Var);
                                                                                    m0(x0Var.f(), x0Var);
                                                                                }
                                                                                x0Var.j(z2);
                                                                                MyApplication.b().C.get(i8).l(jSONObject.getString(str7 + i9 + "Name"));
                                                                                str3 = str7;
                                                                                i8 = i9;
                                                                            }
                                                                            cursorRawQuery = sQLiteDatabase4.rawQuery("SELECT stationMode,countDevice,deviceNetwork,pdfDocument,showTimeOut,systemRegisters FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                            cursorRawQuery.moveToFirst();
                                                                            MyApplication.b().f9043k = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pdfDocument"));
                                                                            if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("stationMode")) == 1) {
                                                                                Z0 = true;
                                                                            } else {
                                                                                Z0 = false;
                                                                            }
                                                                            if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("showTimeOut")) == 1) {
                                                                                g1 = true;
                                                                                i3 = 0;
                                                                            } else {
                                                                                i3 = 0;
                                                                                g1 = false;
                                                                            }
                                                                            Cursor cursorRawQuery8 = sQLiteDatabase4.rawQuery("SELECT modbusSlave FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                                            cursorRawQuery8.moveToFirst();
                                                                            JSONObject jSONObject11 = new JSONObject(cursorRawQuery8.getString(cursorRawQuery8.getColumnIndex("modbusSlave")));
                                                                            MyApplication.b().f9039g = jSONObject11.getInt("modbusSlavePort");
                                                                            MyApplication.b().f9037e = jSONObject11.getBoolean("kascadaCloudSlave");
                                                                            MyApplication.b().f9038f = jSONObject11.getBoolean("kascadaCloudRemoteControl");
                                                                            MyApplication.b().f9042j = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("countDevice"));
                                                                            string2 = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("deviceNetwork"));
                                                                            if (string2.length() > 0) {
                                                                                jSONArray2 = new JSONArray(string2);
                                                                                if (jSONArray2.length() == 8) {
                                                                                    while (i6 < 8) {
                                                                                        while (i7 < 8) {
                                                                                            if (jSONArray2.getJSONObject(i7).getInt("num") == i6) {
                                                                                                String string16 = jSONArray2.getJSONObject(i7).getString(str5);
                                                                                                String string17 = jSONArray2.getJSONObject(i7).getString(str4);
                                                                                                int i314 = jSONArray2.getJSONObject(i7).getInt(IMAPStore.ID_ADDRESS);
                                                                                                int i315 = jSONArray2.getJSONObject(i7).getInt("idServer");
                                                                                                boolean z10 = jSONArray2.getJSONObject(i7).getBoolean(str6);
                                                                                                ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar8 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string16, i314, string17, "", "", i315);
                                                                                                aVar8.m(z10);
                                                                                                MyApplication.b().E.add(aVar8);
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
                                                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
                                                                                } else {
                                                                                    while (i4 < 16) {
                                                                                        while (i5 < 16) {
                                                                                            if (jSONArray2.getJSONObject(i5).getInt("num") == i4) {
                                                                                                String string18 = jSONArray2.getJSONObject(i5).getString(str5);
                                                                                                String string19 = jSONArray2.getJSONObject(i5).getString(str4);
                                                                                                int i46 = jSONArray2.getJSONObject(i5).getInt(IMAPStore.ID_ADDRESS);
                                                                                                int i47 = jSONArray2.getJSONObject(i5).getInt("idServer");
                                                                                                boolean z11 = jSONArray2.getJSONObject(i5).getBoolean(str6);
                                                                                                ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar9 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string18, i46, string19, "", "", i47);
                                                                                                aVar9.m(z11);
                                                                                                MyApplication.b().E.add(aVar9);
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            } else {
                                                                                x();
                                                                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.list_device_empty), 1).show();
                                                                            }
                                                                            jSONArray = new JSONArray(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("systemRegisters")));
                                                                            if (jSONArray.length() > 0) {
                                                                                while (i3 < jSONArray.length()) {
                                                                                    string = jSONArray.getJSONObject(i3).toString();
                                                                                    iIndexOf = string.indexOf("_");
                                                                                    if (iIndexOf > 0) {
                                                                                        int i48 = Integer.parseInt(string.substring(iIndexOf + 1, string.indexOf(":") - 1));
                                                                                        MyApplication.b().v0.f9265j[i48] = jSONArray.getJSONObject(i3).getInt("reg_" + i48);
                                                                                    }
                                                                                    i3++;
                                                                                }
                                                                            }
                                                                            f1.invalidate();
                                                                        }
                                                                    } catch (JSONException e20) {
                                                                        e = e20;
                                                                        str4 = str2;
                                                                    } catch (Exception e21) {
                                                                        e = e21;
                                                                        str4 = str2;
                                                                    }
                                                                    ru.himik.nightscream.kascada.Preference.ServerList.a aVar10 = new ru.himik.nightscream.kascada.Preference.ServerList.a(4, "KaScada Cloud", string11, i16);
                                                                    aVar10.s(z4);
                                                                    MyApplication.b().f9036d.add(aVar10);
                                                                }
                                                                str5 = str20;
                                                            } else {
                                                                str4 = str2;
                                                                str6 = str21;
                                                                String string20 = "502";
                                                                try {
                                                                    JSONObject jSONObject12 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                                    string20 = jSONObject12.getString(str4);
                                                                    z3 = jSONObject12.getBoolean(str6);
                                                                    try {
                                                                        i11 = jSONObject12.getInt("pause");
                                                                    } catch (Exception unused4) {
                                                                        i11 = 0;
                                                                    }
                                                                } catch (JSONException e22) {
                                                                    YandexMetrica.reportError("Загрузка сервера WiFi", e22);
                                                                    e22.printStackTrace();
                                                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_wifi_settings), 1).show();
                                                                    i11 = 0;
                                                                    z3 = false;
                                                                }
                                                                try {
                                                                    str5 = str20;
                                                                    ru.himik.nightscream.kascada.Preference.ServerList.a aVar11 = new ru.himik.nightscream.kascada.Preference.ServerList.a(2, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), string20, i11);
                                                                    aVar11.s(z3);
                                                                    MyApplication.b().f9036d.add(aVar11);
                                                                } catch (Exception e23) {
                                                                    e = e23;
                                                                    str5 = str20;
                                                                    exc = e;
                                                                    YandexMetrica.reportError("Ошибка при загрузке настроек подключений", exc);
                                                                    exc.printStackTrace();
                                                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_settings_network), 0).show();
                                                                }
                                                            }
                                                            try {
                                                                if (!cursorQuery.moveToNext()) {
                                                                    break;
                                                                }
                                                                str2 = str4;
                                                                str21 = str6;
                                                                str20 = str5;
                                                            } catch (Exception e24) {
                                                                e = e24;
                                                                exc = e;
                                                                YandexMetrica.reportError("Ошибка при загрузке настроек подключений", exc);
                                                                exc.printStackTrace();
                                                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_settings_network), 0).show();
                                                            }
                                                        }
                                                    } else {
                                                        str4 = str2;
                                                        str5 = str20;
                                                        str6 = str21;
                                                    }
                                                    SQLiteDatabase sQLiteDatabase5 = sQLiteDatabase;
                                                    Cursor cursorRawQuery9 = sQLiteDatabase5.rawQuery("SELECT screenBackground FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                    cursorRawQuery9.moveToFirst();
                                                    jSONObject = new JSONObject(cursorRawQuery9.getString(cursorRawQuery9.getColumnIndex("screenBackground")));
                                                    string3 = "";
                                                    i8 = 0;
                                                    z2 = false;
                                                    while (i8 < b1) {
                                                        StringBuilder sb5 = new StringBuilder();
                                                        str7 = str3;
                                                        sb5.append(str7);
                                                        int i316 = i8 + 1;
                                                        sb5.append(i316);
                                                        sb5.append("DefaultBackground");
                                                        z2 = jSONObject.getBoolean(sb5.toString());
                                                        string3 = jSONObject.getString(str7 + i316 + "Pass");
                                                        sb = new StringBuilder();
                                                        sb.append(str7);
                                                        i9 = i8 + 1;
                                                        sb.append(i9);
                                                        sb.append("IsColor");
                                                        if (jSONObject.getBoolean(sb.toString())) {
                                                            x0Var = new x0(Boolean.TRUE, "", jSONObject.getInt(str7 + i9 + "Color"), string3, getResources().getString(R.string.screen));
                                                            MyApplication.b().C.add(x0Var);
                                                        } else {
                                                            x0Var = new x0(Boolean.FALSE, jSONObject.getString(str7 + i9 + "PathImage"), 15592941, string3, getResources().getString(R.string.screen));
                                                            MyApplication.b().C.add(x0Var);
                                                            m0(x0Var.f(), x0Var);
                                                        }
                                                        x0Var.j(z2);
                                                        MyApplication.b().C.get(i8).l(jSONObject.getString(str7 + i9 + "Name"));
                                                        str3 = str7;
                                                        i8 = i9;
                                                    }
                                                    cursorRawQuery = sQLiteDatabase5.rawQuery("SELECT stationMode,countDevice,deviceNetwork,pdfDocument,showTimeOut,systemRegisters FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                    cursorRawQuery.moveToFirst();
                                                    MyApplication.b().f9043k = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pdfDocument"));
                                                    if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("stationMode")) == 1) {
                                                        Z0 = true;
                                                    } else {
                                                        Z0 = false;
                                                    }
                                                    if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("showTimeOut")) == 1) {
                                                        g1 = true;
                                                        i3 = 0;
                                                    } else {
                                                        i3 = 0;
                                                        g1 = false;
                                                    }
                                                    Cursor cursorRawQuery10 = sQLiteDatabase5.rawQuery("SELECT modbusSlave FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                                    cursorRawQuery10.moveToFirst();
                                                    JSONObject jSONObject13 = new JSONObject(cursorRawQuery10.getString(cursorRawQuery10.getColumnIndex("modbusSlave")));
                                                    MyApplication.b().f9039g = jSONObject13.getInt("modbusSlavePort");
                                                    MyApplication.b().f9037e = jSONObject13.getBoolean("kascadaCloudSlave");
                                                    MyApplication.b().f9038f = jSONObject13.getBoolean("kascadaCloudRemoteControl");
                                                    MyApplication.b().f9042j = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("countDevice"));
                                                    string2 = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("deviceNetwork"));
                                                    if (string2.length() > 0) {
                                                        jSONArray2 = new JSONArray(string2);
                                                        if (jSONArray2.length() == 8) {
                                                            while (i6 < 8) {
                                                                while (i7 < 8) {
                                                                    if (jSONArray2.getJSONObject(i7).getInt("num") == i6) {
                                                                        String string110 = jSONArray2.getJSONObject(i7).getString(str5);
                                                                        String string111 = jSONArray2.getJSONObject(i7).getString(str4);
                                                                        int i317 = jSONArray2.getJSONObject(i7).getInt(IMAPStore.ID_ADDRESS);
                                                                        int i318 = jSONArray2.getJSONObject(i7).getInt("idServer");
                                                                        boolean z12 = jSONArray2.getJSONObject(i7).getBoolean(str6);
                                                                        ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar12 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string110, i317, string111, "", "", i318);
                                                                        aVar12.m(z12);
                                                                        MyApplication.b().E.add(aVar12);
                                                                    }
                                                                }
                                                            }
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
                                                            MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
                                                        } else {
                                                            while (i4 < 16) {
                                                                while (i5 < 16) {
                                                                    if (jSONArray2.getJSONObject(i5).getInt("num") == i4) {
                                                                        String string112 = jSONArray2.getJSONObject(i5).getString(str5);
                                                                        String string113 = jSONArray2.getJSONObject(i5).getString(str4);
                                                                        int i49 = jSONArray2.getJSONObject(i5).getInt(IMAPStore.ID_ADDRESS);
                                                                        int i410 = jSONArray2.getJSONObject(i5).getInt("idServer");
                                                                        boolean z13 = jSONArray2.getJSONObject(i5).getBoolean(str6);
                                                                        ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar13 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string112, i49, string113, "", "", i410);
                                                                        aVar13.m(z13);
                                                                        MyApplication.b().E.add(aVar13);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        x();
                                                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.list_device_empty), 1).show();
                                                    }
                                                    jSONArray = new JSONArray(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("systemRegisters")));
                                                    if (jSONArray.length() > 0) {
                                                        while (i3 < jSONArray.length()) {
                                                            string = jSONArray.getJSONObject(i3).toString();
                                                            iIndexOf = string.indexOf("_");
                                                            if (iIndexOf > 0) {
                                                                int i411 = Integer.parseInt(string.substring(iIndexOf + 1, string.indexOf(":") - 1));
                                                                MyApplication.b().v0.f9265j[i411] = jSONArray.getJSONObject(i3).getInt("reg_" + i411);
                                                            }
                                                            i3++;
                                                        }
                                                    }
                                                    f1.invalidate();
                                                }
                                                str19 = str;
                                                str16 = str8;
                                                cursorQuery2 = cursorQuery2;
                                                str12 = str10;
                                                str13 = str13;
                                                writableDatabase = sQLiteDatabase;
                                                str18 = str2;
                                                str15 = str15;
                                                str14 = str14;
                                                str20 = str20;
                                                str17 = str3;
                                                str21 = str21;
                                            }
                                        }
                                        if (jSONObject5.getInt("keyOut") != -1) {
                                            jSONObject5.put("keyOut", jSONObject5.getInt("keyOut") + 1000000 + (this.z0 * 100));
                                        }
                                        jSONObject5.put("unIdMcr", jC);
                                        this.y0.add(jSONObject5);
                                        i35++;
                                        jSONArray3 = jSONArray4;
                                        string6 = str11;
                                    } catch (Exception e25) {
                                        exc4 = e25;
                                        str15 = str15;
                                        str21 = str21;
                                        sQLiteDatabase = sQLiteDatabase;
                                        str3 = str3;
                                        str8 = str23;
                                        i24 = i24;
                                        str20 = str20;
                                        cursorQuery2 = cursorQuery2;
                                        i2 = 0;
                                        str9 = string6;
                                        str10 = str12;
                                        str = str22;
                                        YandexMetrica.reportError("Загрузка макроса", exc4);
                                        exc4.printStackTrace();
                                        m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, str9);
                                    }
                                }
                                str11 = string6;
                                try {
                                    jSONObject4.put("numScreen", jSONObject3.getInt("numScreen"));
                                    jSONObject4.put("saveKey", jSONObject3.getInt("saveKey"));
                                    jSONObject4.put("numOnIn", jSONObject3.getInt("numOnIn"));
                                    jSONObject4.put("keyOut", jSONObject3.getInt("keyOut"));
                                    try {
                                        if (jSONObject4.getInt(str23) != -1) {
                                            try {
                                                jSONObject4.put(str23, jSONObject4.getInt(str23) + 1000000 + (this.z0 * 100));
                                            } catch (Exception e26) {
                                                exc4 = e26;
                                                str8 = str23;
                                                str9 = str11;
                                                i2 = 0;
                                                str10 = str12;
                                                str = str22;
                                                YandexMetrica.reportError("Загрузка макроса", exc4);
                                                exc4.printStackTrace();
                                                m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, str9);
                                            }
                                        }
                                        if (jSONObject4.getInt(str15) != -1) {
                                            jSONObject4.put(str15, jSONObject4.getInt(str15) + 1000000 + (this.z0 * 100));
                                        }
                                        if (jSONObject4.getInt(str14) != -1) {
                                            jSONObject4.put(str14, jSONObject4.getInt(str14) + 1000000 + (this.z0 * 100));
                                        }
                                        if (jSONObject4.getInt(str13) != -1) {
                                            jSONObject4.put(str13, jSONObject4.getInt(str13) + 1000000 + (this.z0 * 100));
                                        }
                                        if (jSONObject4.getInt(str12) != -1) {
                                            jSONObject4.put(str12, jSONObject4.getInt(str12) + 1000000 + (this.z0 * 100));
                                        }
                                        i24 = i24;
                                        str10 = str12;
                                        cursorQuery2 = cursorQuery2;
                                        str = str22;
                                        sQLiteDatabase = sQLiteDatabase;
                                        str20 = str20;
                                        str13 = str13;
                                        str3 = str3;
                                        str9 = str11;
                                        str2 = str2;
                                        i2 = 0;
                                        str21 = str21;
                                        str8 = str23;
                                        str15 = str15;
                                        str14 = str14;
                                        try {
                                            m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, jSONObject4.toString());
                                        } catch (Exception e27) {
                                            e = e27;
                                            exc4 = e;
                                            YandexMetrica.reportError("Загрузка макроса", exc4);
                                            exc4.printStackTrace();
                                            m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, str9);
                                        }
                                    } catch (Exception e28) {
                                        e = e28;
                                        str8 = str23;
                                        str14 = str14;
                                        str9 = str11;
                                        i2 = 0;
                                        str10 = str12;
                                        str = str22;
                                        exc4 = e;
                                        YandexMetrica.reportError("Загрузка макроса", exc4);
                                        exc4.printStackTrace();
                                        m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, str9);
                                        if (!cursorQuery2.moveToNext()) {
                                            break;
                                            if (this.x0) {
                                                Toast.makeText(getApplicationContext(), R.string.detect_properties_problems_component, i2).show();
                                            }
                                            if (this.y0.size() > 0) {
                                                i17 = 0;
                                                while (i17 < this.y0.size()) {
                                                    i18 = i17;
                                                    m(this.y0.get(i17).getInt(str), "", 0, 0, this.y0.get(i17).getInt("x"), this.y0.get(i17).getInt("y"), 0, "", 0, 0, this.y0.get(i17).toString());
                                                    i17 = i18 + 1;
                                                }
                                            }
                                            this.y0.clear();
                                            i0();
                                            cursorQuery = sQLiteDatabase.query(MyApplication.b().j0, null, null, null, null, null, null);
                                            if (cursorQuery.moveToFirst()) {
                                                while (true) {
                                                    i10 = cursorQuery.getInt(cursorQuery.getColumnIndex("connectionsId"));
                                                    if (i10 != 1) {
                                                        str4 = str2;
                                                        str5 = str20;
                                                        str6 = str21;
                                                        JSONObject jSONObject14 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                        MyApplication.b().f9036d.add(new ru.himik.nightscream.kascada.Preference.ServerList.a(1, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), jSONObject14.getString(str4), jSONObject14.getInt("pause")));
                                                    } else if (i10 != 2) {
                                                        if (i10 != 3) {
                                                            str4 = str2;
                                                            str6 = str21;
                                                            int i319 = 9600;
                                                            JSONObject jSONObject15 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                            i319 = jSONObject15.getInt("baudRate");
                                                            i12 = jSONObject15.getInt("dataBits");
                                                            i13 = jSONObject15.getInt("stopBits");
                                                            i15 = jSONObject15.getInt("parity");
                                                            i14 = jSONObject15.getInt("pause");
                                                            ru.himik.nightscream.kascada.Preference.ServerList.a aVar14 = new ru.himik.nightscream.kascada.Preference.ServerList.a(3, "Usb", "", i14);
                                                            aVar14.m(i319);
                                                            aVar14.o(i12);
                                                            aVar14.u(i13);
                                                            aVar14.q(i15);
                                                            MyApplication.b().f9036d.add(aVar14);
                                                        } else if (i10 != 4) {
                                                            str4 = str2;
                                                            str5 = str20;
                                                            str6 = str21;
                                                        } else {
                                                            String string114 = "error";
                                                            str4 = str2;
                                                            JSONObject jSONObject16 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                            string114 = jSONObject16.getString(str4);
                                                            str6 = str21;
                                                            z4 = jSONObject16.getBoolean(str6);
                                                            i16 = jSONObject16.getInt("pause");
                                                            ru.himik.nightscream.kascada.Preference.ServerList.a aVar15 = new ru.himik.nightscream.kascada.Preference.ServerList.a(4, "KaScada Cloud", string114, i16);
                                                            aVar15.s(z4);
                                                            MyApplication.b().f9036d.add(aVar15);
                                                        }
                                                        str5 = str20;
                                                    } else {
                                                        str4 = str2;
                                                        str6 = str21;
                                                        String string21 = "502";
                                                        JSONObject jSONObject17 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                        string21 = jSONObject17.getString(str4);
                                                        z3 = jSONObject17.getBoolean(str6);
                                                        i11 = jSONObject17.getInt("pause");
                                                        str5 = str20;
                                                        ru.himik.nightscream.kascada.Preference.ServerList.a aVar16 = new ru.himik.nightscream.kascada.Preference.ServerList.a(2, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), string21, i11);
                                                        aVar16.s(z3);
                                                        MyApplication.b().f9036d.add(aVar16);
                                                    }
                                                    if (!cursorQuery.moveToNext()) {
                                                        break;
                                                        break;
                                                    } else {
                                                        str2 = str4;
                                                        str21 = str6;
                                                        str20 = str5;
                                                    }
                                                }
                                            } else {
                                                str4 = str2;
                                                str5 = str20;
                                                str6 = str21;
                                            }
                                            SQLiteDatabase sQLiteDatabase6 = sQLiteDatabase;
                                            Cursor cursorRawQuery11 = sQLiteDatabase6.rawQuery("SELECT screenBackground FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                            cursorRawQuery11.moveToFirst();
                                            jSONObject = new JSONObject(cursorRawQuery11.getString(cursorRawQuery11.getColumnIndex("screenBackground")));
                                            string3 = "";
                                            i8 = 0;
                                            z2 = false;
                                            while (i8 < b1) {
                                                StringBuilder sb6 = new StringBuilder();
                                                str7 = str3;
                                                sb6.append(str7);
                                                int i3110 = i8 + 1;
                                                sb6.append(i3110);
                                                sb6.append("DefaultBackground");
                                                z2 = jSONObject.getBoolean(sb6.toString());
                                                string3 = jSONObject.getString(str7 + i3110 + "Pass");
                                                sb = new StringBuilder();
                                                sb.append(str7);
                                                i9 = i8 + 1;
                                                sb.append(i9);
                                                sb.append("IsColor");
                                                if (jSONObject.getBoolean(sb.toString())) {
                                                    x0Var = new x0(Boolean.TRUE, "", jSONObject.getInt(str7 + i9 + "Color"), string3, getResources().getString(R.string.screen));
                                                    MyApplication.b().C.add(x0Var);
                                                } else {
                                                    x0Var = new x0(Boolean.FALSE, jSONObject.getString(str7 + i9 + "PathImage"), 15592941, string3, getResources().getString(R.string.screen));
                                                    MyApplication.b().C.add(x0Var);
                                                    m0(x0Var.f(), x0Var);
                                                }
                                                x0Var.j(z2);
                                                MyApplication.b().C.get(i8).l(jSONObject.getString(str7 + i9 + "Name"));
                                                str3 = str7;
                                                i8 = i9;
                                            }
                                            cursorRawQuery = sQLiteDatabase6.rawQuery("SELECT stationMode,countDevice,deviceNetwork,pdfDocument,showTimeOut,systemRegisters FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                            cursorRawQuery.moveToFirst();
                                            MyApplication.b().f9043k = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pdfDocument"));
                                            if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("stationMode")) == 1) {
                                                Z0 = true;
                                            } else {
                                                Z0 = false;
                                            }
                                            if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("showTimeOut")) == 1) {
                                                g1 = true;
                                                i3 = 0;
                                            } else {
                                                i3 = 0;
                                                g1 = false;
                                            }
                                            Cursor cursorRawQuery12 = sQLiteDatabase6.rawQuery("SELECT modbusSlave FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                            cursorRawQuery12.moveToFirst();
                                            JSONObject jSONObject18 = new JSONObject(cursorRawQuery12.getString(cursorRawQuery12.getColumnIndex("modbusSlave")));
                                            MyApplication.b().f9039g = jSONObject18.getInt("modbusSlavePort");
                                            MyApplication.b().f9037e = jSONObject18.getBoolean("kascadaCloudSlave");
                                            MyApplication.b().f9038f = jSONObject18.getBoolean("kascadaCloudRemoteControl");
                                            MyApplication.b().f9042j = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("countDevice"));
                                            string2 = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("deviceNetwork"));
                                            if (string2.length() > 0) {
                                                jSONArray2 = new JSONArray(string2);
                                                if (jSONArray2.length() == 8) {
                                                    while (i6 < 8) {
                                                        while (i7 < 8) {
                                                            if (jSONArray2.getJSONObject(i7).getInt("num") == i6) {
                                                                String string115 = jSONArray2.getJSONObject(i7).getString(str5);
                                                                String string116 = jSONArray2.getJSONObject(i7).getString(str4);
                                                                int i3111 = jSONArray2.getJSONObject(i7).getInt(IMAPStore.ID_ADDRESS);
                                                                int i3112 = jSONArray2.getJSONObject(i7).getInt("idServer");
                                                                boolean z14 = jSONArray2.getJSONObject(i7).getBoolean(str6);
                                                                ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar17 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string115, i3111, string116, "", "", i3112);
                                                                aVar17.m(z14);
                                                                MyApplication.b().E.add(aVar17);
                                                            }
                                                        }
                                                    }
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
                                                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
                                                } else {
                                                    while (i4 < 16) {
                                                        while (i5 < 16) {
                                                            if (jSONArray2.getJSONObject(i5).getInt("num") == i4) {
                                                                String string117 = jSONArray2.getJSONObject(i5).getString(str5);
                                                                String string118 = jSONArray2.getJSONObject(i5).getString(str4);
                                                                int i412 = jSONArray2.getJSONObject(i5).getInt(IMAPStore.ID_ADDRESS);
                                                                int i413 = jSONArray2.getJSONObject(i5).getInt("idServer");
                                                                boolean z15 = jSONArray2.getJSONObject(i5).getBoolean(str6);
                                                                ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar18 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string117, i412, string118, "", "", i413);
                                                                aVar18.m(z15);
                                                                MyApplication.b().E.add(aVar18);
                                                            }
                                                        }
                                                    }
                                                }
                                            } else {
                                                x();
                                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.list_device_empty), 1).show();
                                            }
                                            jSONArray = new JSONArray(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("systemRegisters")));
                                            if (jSONArray.length() > 0) {
                                                while (i3 < jSONArray.length()) {
                                                    string = jSONArray.getJSONObject(i3).toString();
                                                    iIndexOf = string.indexOf("_");
                                                    if (iIndexOf > 0) {
                                                        int i414 = Integer.parseInt(string.substring(iIndexOf + 1, string.indexOf(":") - 1));
                                                        MyApplication.b().v0.f9265j[i414] = jSONArray.getJSONObject(i3).getInt("reg_" + i414);
                                                    }
                                                    i3++;
                                                }
                                            }
                                            f1.invalidate();
                                        }
                                        str19 = str;
                                        str16 = str8;
                                        cursorQuery2 = cursorQuery2;
                                        str12 = str10;
                                        str13 = str13;
                                        writableDatabase = sQLiteDatabase;
                                        str18 = str2;
                                        str15 = str15;
                                        str14 = str14;
                                        str20 = str20;
                                        str17 = str3;
                                        str21 = str21;
                                    }
                                } catch (Exception e29) {
                                    e = e29;
                                    str8 = str23;
                                }
                                if (!cursorQuery2.moveToNext()) {
                                    break;
                                }
                                str19 = str;
                                str16 = str8;
                                cursorQuery2 = cursorQuery2;
                                str12 = str10;
                                str13 = str13;
                                writableDatabase = sQLiteDatabase;
                                str18 = str2;
                                str15 = str15;
                                str14 = str14;
                                str20 = str20;
                                str17 = str3;
                                str21 = str21;
                            } else {
                                str11 = string6;
                                jSONObject4.put("numScreen", jSONObject3.getInt("numScreen"));
                                jSONObject4.put("saveKey", jSONObject3.getInt("saveKey"));
                                jSONObject4.put("numOnIn", jSONObject3.getInt("numOnIn"));
                                jSONObject4.put("keyOut", jSONObject3.getInt("keyOut"));
                                if (jSONObject4.getInt(str23) != -1) {
                                    jSONObject4.put(str23, jSONObject4.getInt(str23) + 1000000 + (this.z0 * 100));
                                }
                                if (jSONObject4.getInt(str15) != -1) {
                                    jSONObject4.put(str15, jSONObject4.getInt(str15) + 1000000 + (this.z0 * 100));
                                }
                                if (jSONObject4.getInt(str14) != -1) {
                                    jSONObject4.put(str14, jSONObject4.getInt(str14) + 1000000 + (this.z0 * 100));
                                }
                                if (jSONObject4.getInt(str13) != -1) {
                                    jSONObject4.put(str13, jSONObject4.getInt(str13) + 1000000 + (this.z0 * 100));
                                }
                                if (jSONObject4.getInt(str12) != -1) {
                                    jSONObject4.put(str12, jSONObject4.getInt(str12) + 1000000 + (this.z0 * 100));
                                }
                                i24 = i24;
                                str10 = str12;
                                cursorQuery2 = cursorQuery2;
                                str = str22;
                                sQLiteDatabase = sQLiteDatabase;
                                str20 = str20;
                                str13 = str13;
                                str3 = str3;
                                str9 = str11;
                                str2 = str2;
                                i2 = 0;
                                str21 = str21;
                                str8 = str23;
                                str15 = str15;
                                str14 = str14;
                                m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, jSONObject4.toString());
                                if (!cursorQuery2.moveToNext()) {
                                    break;
                                    break;
                                }
                                str19 = str;
                                str16 = str8;
                                cursorQuery2 = cursorQuery2;
                                str12 = str10;
                                str13 = str13;
                                writableDatabase = sQLiteDatabase;
                                str18 = str2;
                                str15 = str15;
                                str14 = str14;
                                str20 = str20;
                                str17 = str3;
                                str21 = str21;
                            }
                        } catch (Exception e30) {
                            e = e30;
                            str8 = str23;
                            i2 = 0;
                            str9 = string6;
                            str10 = str12;
                            str = str22;
                            exc4 = e;
                            YandexMetrica.reportError("Загрузка макроса", exc4);
                            exc4.printStackTrace();
                            m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, str9);
                            if (!cursorQuery2.moveToNext()) {
                                break;
                                if (this.x0) {
                                    Toast.makeText(getApplicationContext(), R.string.detect_properties_problems_component, i2).show();
                                }
                                if (this.y0.size() > 0) {
                                    i17 = 0;
                                    while (i17 < this.y0.size()) {
                                        i18 = i17;
                                        m(this.y0.get(i17).getInt(str), "", 0, 0, this.y0.get(i17).getInt("x"), this.y0.get(i17).getInt("y"), 0, "", 0, 0, this.y0.get(i17).toString());
                                        i17 = i18 + 1;
                                    }
                                }
                                this.y0.clear();
                                i0();
                                cursorQuery = sQLiteDatabase.query(MyApplication.b().j0, null, null, null, null, null, null);
                                if (cursorQuery.moveToFirst()) {
                                    while (true) {
                                        i10 = cursorQuery.getInt(cursorQuery.getColumnIndex("connectionsId"));
                                        if (i10 != 1) {
                                            str4 = str2;
                                            str5 = str20;
                                            str6 = str21;
                                            JSONObject jSONObject19 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                            MyApplication.b().f9036d.add(new ru.himik.nightscream.kascada.Preference.ServerList.a(1, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), jSONObject19.getString(str4), jSONObject19.getInt("pause")));
                                        } else if (i10 != 2) {
                                            if (i10 != 3) {
                                                str4 = str2;
                                                str6 = str21;
                                                int i3113 = 9600;
                                                JSONObject jSONObject110 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                i3113 = jSONObject110.getInt("baudRate");
                                                i12 = jSONObject110.getInt("dataBits");
                                                i13 = jSONObject110.getInt("stopBits");
                                                i15 = jSONObject110.getInt("parity");
                                                i14 = jSONObject110.getInt("pause");
                                                ru.himik.nightscream.kascada.Preference.ServerList.a aVar19 = new ru.himik.nightscream.kascada.Preference.ServerList.a(3, "Usb", "", i14);
                                                aVar19.m(i3113);
                                                aVar19.o(i12);
                                                aVar19.u(i13);
                                                aVar19.q(i15);
                                                MyApplication.b().f9036d.add(aVar19);
                                            } else if (i10 != 4) {
                                                str4 = str2;
                                                str5 = str20;
                                                str6 = str21;
                                            } else {
                                                String string119 = "error";
                                                str4 = str2;
                                                JSONObject jSONObject111 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                string119 = jSONObject111.getString(str4);
                                                str6 = str21;
                                                z4 = jSONObject111.getBoolean(str6);
                                                i16 = jSONObject111.getInt("pause");
                                                ru.himik.nightscream.kascada.Preference.ServerList.a aVar110 = new ru.himik.nightscream.kascada.Preference.ServerList.a(4, "KaScada Cloud", string119, i16);
                                                aVar110.s(z4);
                                                MyApplication.b().f9036d.add(aVar110);
                                            }
                                            str5 = str20;
                                        } else {
                                            str4 = str2;
                                            str6 = str21;
                                            String string22 = "502";
                                            JSONObject jSONObject112 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                            string22 = jSONObject112.getString(str4);
                                            z3 = jSONObject112.getBoolean(str6);
                                            i11 = jSONObject112.getInt("pause");
                                            str5 = str20;
                                            ru.himik.nightscream.kascada.Preference.ServerList.a aVar111 = new ru.himik.nightscream.kascada.Preference.ServerList.a(2, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), string22, i11);
                                            aVar111.s(z3);
                                            MyApplication.b().f9036d.add(aVar111);
                                        }
                                        if (!cursorQuery.moveToNext()) {
                                            break;
                                            break;
                                        } else {
                                            str2 = str4;
                                            str21 = str6;
                                            str20 = str5;
                                        }
                                    }
                                } else {
                                    str4 = str2;
                                    str5 = str20;
                                    str6 = str21;
                                }
                                SQLiteDatabase sQLiteDatabase7 = sQLiteDatabase;
                                Cursor cursorRawQuery13 = sQLiteDatabase7.rawQuery("SELECT screenBackground FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                cursorRawQuery13.moveToFirst();
                                jSONObject = new JSONObject(cursorRawQuery13.getString(cursorRawQuery13.getColumnIndex("screenBackground")));
                                string3 = "";
                                i8 = 0;
                                z2 = false;
                                while (i8 < b1) {
                                    StringBuilder sb7 = new StringBuilder();
                                    str7 = str3;
                                    sb7.append(str7);
                                    int i3114 = i8 + 1;
                                    sb7.append(i3114);
                                    sb7.append("DefaultBackground");
                                    z2 = jSONObject.getBoolean(sb7.toString());
                                    string3 = jSONObject.getString(str7 + i3114 + "Pass");
                                    sb = new StringBuilder();
                                    sb.append(str7);
                                    i9 = i8 + 1;
                                    sb.append(i9);
                                    sb.append("IsColor");
                                    if (jSONObject.getBoolean(sb.toString())) {
                                        x0Var = new x0(Boolean.TRUE, "", jSONObject.getInt(str7 + i9 + "Color"), string3, getResources().getString(R.string.screen));
                                        MyApplication.b().C.add(x0Var);
                                    } else {
                                        x0Var = new x0(Boolean.FALSE, jSONObject.getString(str7 + i9 + "PathImage"), 15592941, string3, getResources().getString(R.string.screen));
                                        MyApplication.b().C.add(x0Var);
                                        m0(x0Var.f(), x0Var);
                                    }
                                    x0Var.j(z2);
                                    MyApplication.b().C.get(i8).l(jSONObject.getString(str7 + i9 + "Name"));
                                    str3 = str7;
                                    i8 = i9;
                                }
                                cursorRawQuery = sQLiteDatabase7.rawQuery("SELECT stationMode,countDevice,deviceNetwork,pdfDocument,showTimeOut,systemRegisters FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                cursorRawQuery.moveToFirst();
                                MyApplication.b().f9043k = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pdfDocument"));
                                if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("stationMode")) == 1) {
                                    Z0 = true;
                                } else {
                                    Z0 = false;
                                }
                                if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("showTimeOut")) == 1) {
                                    g1 = true;
                                    i3 = 0;
                                } else {
                                    i3 = 0;
                                    g1 = false;
                                }
                                Cursor cursorRawQuery14 = sQLiteDatabase7.rawQuery("SELECT modbusSlave FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
                                cursorRawQuery14.moveToFirst();
                                JSONObject jSONObject113 = new JSONObject(cursorRawQuery14.getString(cursorRawQuery14.getColumnIndex("modbusSlave")));
                                MyApplication.b().f9039g = jSONObject113.getInt("modbusSlavePort");
                                MyApplication.b().f9037e = jSONObject113.getBoolean("kascadaCloudSlave");
                                MyApplication.b().f9038f = jSONObject113.getBoolean("kascadaCloudRemoteControl");
                                MyApplication.b().f9042j = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("countDevice"));
                                string2 = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("deviceNetwork"));
                                if (string2.length() > 0) {
                                    jSONArray2 = new JSONArray(string2);
                                    if (jSONArray2.length() == 8) {
                                        while (i6 < 8) {
                                            while (i7 < 8) {
                                                if (jSONArray2.getJSONObject(i7).getInt("num") == i6) {
                                                    String string1110 = jSONArray2.getJSONObject(i7).getString(str5);
                                                    String string1111 = jSONArray2.getJSONObject(i7).getString(str4);
                                                    int i3115 = jSONArray2.getJSONObject(i7).getInt(IMAPStore.ID_ADDRESS);
                                                    int i3116 = jSONArray2.getJSONObject(i7).getInt("idServer");
                                                    boolean z16 = jSONArray2.getJSONObject(i7).getBoolean(str6);
                                                    ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar112 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string1110, i3115, string1111, "", "", i3116);
                                                    aVar112.m(z16);
                                                    MyApplication.b().E.add(aVar112);
                                                }
                                            }
                                        }
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
                                        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
                                    } else {
                                        while (i4 < 16) {
                                            while (i5 < 16) {
                                                if (jSONArray2.getJSONObject(i5).getInt("num") == i4) {
                                                    String string1112 = jSONArray2.getJSONObject(i5).getString(str5);
                                                    String string1113 = jSONArray2.getJSONObject(i5).getString(str4);
                                                    int i415 = jSONArray2.getJSONObject(i5).getInt(IMAPStore.ID_ADDRESS);
                                                    int i416 = jSONArray2.getJSONObject(i5).getInt("idServer");
                                                    boolean z17 = jSONArray2.getJSONObject(i5).getBoolean(str6);
                                                    ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar113 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string1112, i415, string1113, "", "", i416);
                                                    aVar113.m(z17);
                                                    MyApplication.b().E.add(aVar113);
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    x();
                                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.list_device_empty), 1).show();
                                }
                                jSONArray = new JSONArray(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("systemRegisters")));
                                if (jSONArray.length() > 0) {
                                    while (i3 < jSONArray.length()) {
                                        string = jSONArray.getJSONObject(i3).toString();
                                        iIndexOf = string.indexOf("_");
                                        if (iIndexOf > 0) {
                                            int i417 = Integer.parseInt(string.substring(iIndexOf + 1, string.indexOf(":") - 1));
                                            MyApplication.b().v0.f9265j[i417] = jSONArray.getJSONObject(i3).getInt("reg_" + i417);
                                        }
                                        i3++;
                                    }
                                }
                                f1.invalidate();
                            }
                            str19 = str;
                            str16 = str8;
                            cursorQuery2 = cursorQuery2;
                            str12 = str10;
                            str13 = str13;
                            writableDatabase = sQLiteDatabase;
                            str18 = str2;
                            str15 = str15;
                            str14 = str14;
                            str20 = str20;
                            str17 = str3;
                            str21 = str21;
                        }
                    } catch (Exception e31) {
                        e = e31;
                        str8 = str16;
                    }
                } else {
                    i24 = i24;
                    str20 = str20;
                    cursorQuery2 = cursorQuery2;
                    str15 = str15;
                    str14 = str14;
                    str21 = str21;
                    sQLiteDatabase = sQLiteDatabase;
                    str3 = str3;
                    str8 = str16;
                    str13 = str13;
                    str2 = str2;
                    i2 = 0;
                    str9 = string6;
                    str10 = str12;
                    str = str22;
                }
                m(i24, string4, i19, i20, i22, i23, i30, string5, i31, i32, str9);
                if (!cursorQuery2.moveToNext()) {
                    break;
                    break;
                }
                str19 = str;
                str16 = str8;
                cursorQuery2 = cursorQuery2;
                str12 = str10;
                str13 = str13;
                writableDatabase = sQLiteDatabase;
                str18 = str2;
                str15 = str15;
                str14 = str14;
                str20 = str20;
                str17 = str3;
                str21 = str21;
            }
        } else {
            str20 = IMAPStore.ID_NAME;
            str = "componentId";
            sQLiteDatabase = writableDatabase;
            str2 = "server";
            str3 = "screen";
            str21 = str21;
            i2 = 0;
        }
        if (this.x0) {
            Toast.makeText(getApplicationContext(), R.string.detect_properties_problems_component, i2).show();
        }
        if (this.y0.size() > 0) {
            i17 = 0;
            while (i17 < this.y0.size()) {
                i18 = i17;
                m(this.y0.get(i17).getInt(str), "", 0, 0, this.y0.get(i17).getInt("x"), this.y0.get(i17).getInt("y"), 0, "", 0, 0, this.y0.get(i17).toString());
                i17 = i18 + 1;
            }
        }
        this.y0.clear();
        i0();
        try {
            cursorQuery = sQLiteDatabase.query(MyApplication.b().j0, null, null, null, null, null, null);
            if (cursorQuery.moveToFirst()) {
                while (true) {
                    i10 = cursorQuery.getInt(cursorQuery.getColumnIndex("connectionsId"));
                    if (i10 != 1) {
                        str4 = str2;
                        str5 = str20;
                        str6 = str21;
                        JSONObject jSONObject114 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                        MyApplication.b().f9036d.add(new ru.himik.nightscream.kascada.Preference.ServerList.a(1, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), jSONObject114.getString(str4), jSONObject114.getInt("pause")));
                    } else if (i10 != 2) {
                        if (i10 != 3) {
                            str4 = str2;
                            str6 = str21;
                            int i3117 = 9600;
                            JSONObject jSONObject115 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                            i3117 = jSONObject115.getInt("baudRate");
                            i12 = jSONObject115.getInt("dataBits");
                            i13 = jSONObject115.getInt("stopBits");
                            i15 = jSONObject115.getInt("parity");
                            i14 = jSONObject115.getInt("pause");
                            ru.himik.nightscream.kascada.Preference.ServerList.a aVar114 = new ru.himik.nightscream.kascada.Preference.ServerList.a(3, "Usb", "", i14);
                            aVar114.m(i3117);
                            aVar114.o(i12);
                            aVar114.u(i13);
                            aVar114.q(i15);
                            MyApplication.b().f9036d.add(aVar114);
                        } else if (i10 != 4) {
                            str4 = str2;
                            str5 = str20;
                            str6 = str21;
                        } else {
                            String string1114 = "error";
                            str4 = str2;
                            JSONObject jSONObject116 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                            string1114 = jSONObject116.getString(str4);
                            str6 = str21;
                            z4 = jSONObject116.getBoolean(str6);
                            i16 = jSONObject116.getInt("pause");
                            ru.himik.nightscream.kascada.Preference.ServerList.a aVar115 = new ru.himik.nightscream.kascada.Preference.ServerList.a(4, "KaScada Cloud", string1114, i16);
                            aVar115.s(z4);
                            MyApplication.b().f9036d.add(aVar115);
                        }
                        str5 = str20;
                    } else {
                        str4 = str2;
                        str6 = str21;
                        String string23 = "502";
                        JSONObject jSONObject117 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                        string23 = jSONObject117.getString(str4);
                        z3 = jSONObject117.getBoolean(str6);
                        i11 = jSONObject117.getInt("pause");
                        str5 = str20;
                        ru.himik.nightscream.kascada.Preference.ServerList.a aVar116 = new ru.himik.nightscream.kascada.Preference.ServerList.a(2, cursorQuery.getString(cursorQuery.getColumnIndex(str5)), string23, i11);
                        aVar116.s(z3);
                        MyApplication.b().f9036d.add(aVar116);
                    }
                    if (!cursorQuery.moveToNext()) {
                        break;
                        break;
                    } else {
                        str2 = str4;
                        str21 = str6;
                        str20 = str5;
                    }
                }
            } else {
                str4 = str2;
                str5 = str20;
                str6 = str21;
            }
        } catch (Exception e32) {
            e = e32;
            str4 = str2;
            str5 = str20;
            str6 = str21;
        }
        SQLiteDatabase sQLiteDatabase8 = sQLiteDatabase;
        Cursor cursorRawQuery15 = sQLiteDatabase8.rawQuery("SELECT screenBackground FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
        cursorRawQuery15.moveToFirst();
        try {
            jSONObject = new JSONObject(cursorRawQuery15.getString(cursorRawQuery15.getColumnIndex("screenBackground")));
            string3 = "";
            i8 = 0;
            z2 = false;
            while (i8 < b1) {
                StringBuilder sb8 = new StringBuilder();
                str7 = str3;
                sb8.append(str7);
                int i3118 = i8 + 1;
                sb8.append(i3118);
                sb8.append("DefaultBackground");
                z2 = jSONObject.getBoolean(sb8.toString());
                string3 = jSONObject.getString(str7 + i3118 + "Pass");
                sb = new StringBuilder();
                sb.append(str7);
                i9 = i8 + 1;
                sb.append(i9);
                sb.append("IsColor");
                if (jSONObject.getBoolean(sb.toString())) {
                    x0Var = new x0(Boolean.TRUE, "", jSONObject.getInt(str7 + i9 + "Color"), string3, getResources().getString(R.string.screen));
                    MyApplication.b().C.add(x0Var);
                } else {
                    x0Var = new x0(Boolean.FALSE, jSONObject.getString(str7 + i9 + "PathImage"), 15592941, string3, getResources().getString(R.string.screen));
                    MyApplication.b().C.add(x0Var);
                    m0(x0Var.f(), x0Var);
                }
                x0Var.j(z2);
                MyApplication.b().C.get(i8).l(jSONObject.getString(str7 + i9 + "Name"));
                str3 = str7;
                i8 = i9;
            }
        } catch (JSONException e33) {
            YandexMetrica.reportError("Ошибка при чтении фона из базы", e33);
            e33.printStackTrace();
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_background), 0).show();
            for (int i50 = 0; i50 < b1; i50++) {
                MyApplication.b().C.add(new x0(Boolean.TRUE, "", 15592941, "", getResources().getString(R.string.screen)));
            }
        }
        cursorRawQuery = sQLiteDatabase8.rawQuery("SELECT stationMode,countDevice,deviceNetwork,pdfDocument,showTimeOut,systemRegisters FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
        cursorRawQuery.moveToFirst();
        MyApplication.b().f9043k = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("pdfDocument"));
        if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("stationMode")) == 1) {
            Z0 = true;
        } else {
            Z0 = false;
        }
        try {
            if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("showTimeOut")) == 1) {
                g1 = true;
                i3 = 0;
            } else {
                i3 = 0;
                g1 = false;
            }
        } catch (Exception e34) {
            e = e34;
            i3 = 0;
        }
        try {
            Cursor cursorRawQuery16 = sQLiteDatabase8.rawQuery("SELECT modbusSlave FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
            cursorRawQuery16.moveToFirst();
            JSONObject jSONObject118 = new JSONObject(cursorRawQuery16.getString(cursorRawQuery16.getColumnIndex("modbusSlave")));
            MyApplication.b().f9039g = jSONObject118.getInt("modbusSlavePort");
            MyApplication.b().f9037e = jSONObject118.getBoolean("kascadaCloudSlave");
            MyApplication.b().f9038f = jSONObject118.getBoolean("kascadaCloudRemoteControl");
        } catch (Exception e35) {
            YandexMetrica.reportError("Загрузка ModBus Slave", e35);
            e35.printStackTrace();
        }
        MyApplication.b().f9042j = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("countDevice"));
        try {
            string2 = cursorRawQuery.getString(cursorRawQuery.getColumnIndex("deviceNetwork"));
            if (string2.length() > 0) {
                jSONArray2 = new JSONArray(string2);
                if (jSONArray2.length() == 8) {
                    while (i6 < 8) {
                        while (i7 < 8) {
                            if (jSONArray2.getJSONObject(i7).getInt("num") == i6) {
                                String string1115 = jSONArray2.getJSONObject(i7).getString(str5);
                                String string1116 = jSONArray2.getJSONObject(i7).getString(str4);
                                int i3119 = jSONArray2.getJSONObject(i7).getInt(IMAPStore.ID_ADDRESS);
                                int i31110 = jSONArray2.getJSONObject(i7).getInt("idServer");
                                boolean z18 = jSONArray2.getJSONObject(i7).getBoolean(str6);
                                ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar117 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string1115, i3119, string1116, "", "", i31110);
                                aVar117.m(z18);
                                MyApplication.b().E.add(aVar117);
                            }
                        }
                    }
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
                    MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
                } else {
                    while (i4 < 16) {
                        while (i5 < 16) {
                            if (jSONArray2.getJSONObject(i5).getInt("num") == i4) {
                                String string1117 = jSONArray2.getJSONObject(i5).getString(str5);
                                String string1118 = jSONArray2.getJSONObject(i5).getString(str4);
                                int i418 = jSONArray2.getJSONObject(i5).getInt(IMAPStore.ID_ADDRESS);
                                int i419 = jSONArray2.getJSONObject(i5).getInt("idServer");
                                boolean z19 = jSONArray2.getJSONObject(i5).getBoolean(str6);
                                ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a aVar118 = new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a(string1117, i418, string1118, "", "", i419);
                                aVar118.m(z19);
                                MyApplication.b().E.add(aVar118);
                            }
                        }
                    }
                }
            } else {
                x();
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.list_device_empty), 1).show();
            }
        } catch (JSONException e36) {
            YandexMetrica.reportError("Загрузка NETWORK DEVICE", e36);
            e36.printStackTrace();
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_list_network_device), 1).show();
            x();
        }
        try {
            jSONArray = new JSONArray(cursorRawQuery.getString(cursorRawQuery.getColumnIndex("systemRegisters")));
            if (jSONArray.length() > 0) {
                while (i3 < jSONArray.length()) {
                    string = jSONArray.getJSONObject(i3).toString();
                    iIndexOf = string.indexOf("_");
                    if (iIndexOf > 0) {
                        int i4110 = Integer.parseInt(string.substring(iIndexOf + 1, string.indexOf(":") - 1));
                        MyApplication.b().v0.f9265j[i4110] = jSONArray.getJSONObject(i3).getInt("reg_" + i4110);
                    }
                    i3++;
                }
            }
        } catch (Exception e37) {
            YandexMetrica.reportError("Загрузка Retain System Registers", e37);
            e37.printStackTrace();
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_load_system_registers), 1).show();
        }
        f1.invalidate();
    }

    public void g0(boolean z2, int i2) {
        if (!z2) {
            ru.himik.nightscream.kascada.Connections.Cloud.b bVar = this.g0;
            if (bVar != null) {
                bVar.a();
                return;
            }
            return;
        }
        if (MyApplication.b().f9037e) {
            try {
                this.g0 = new ru.himik.nightscream.kascada.Connections.Cloud.b(this.P, this, MyApplication.b().f9044l);
            } catch (Exception unused) {
                Toast.makeText(getApplicationContext(), R.string.critical_error_connection_kascadacloud_slave, 0).show();
            }
        }
    }

    public native int getSomeValue();

    public void h(boolean z2) {
        i.b.q.b<ru.himik.nightscream.kascada.Utils.m> bVar;
        ru.himik.nightscream.kascada.Utils.m mVar;
        MyApplication.b().g();
        if (z2) {
            this.m0.setVisibility(0);
            bVar = MyApplication.b().a;
            mVar = new ru.himik.nightscream.kascada.Utils.m(2);
        } else {
            bVar = MyApplication.b().a;
            mVar = new ru.himik.nightscream.kascada.Utils.m(1);
        }
        bVar.d(mVar);
    }

    public void h0(String str, String str2) {
        if (MyApplication.b().V.size() > 0) {
            boolean z2 = false;
            boolean z3 = false;
            for (int i2 = 0; i2 < MyApplication.b().V.size(); i2++) {
                ru.himik.nightscream.kascada.CustomComponents.x xVar = (ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(MyApplication.b().V.keyAt(i2));
                String phone = xVar.getPhone();
                if (xVar.getPhone().length() >= 5) {
                    if (String.valueOf(xVar.getPhone().charAt(0)).equals("8") && phone.length() == 11) {
                        phone = "+7" + phone.substring(1);
                    }
                    if (phone.equals(str)) {
                        if (xVar.getTypeCommand() == 0) {
                            int length = xVar.getCommand().length();
                            int length2 = str2.length();
                            if (length2 >= length && length2 != length && str2.substring(0, length).equals(xVar.getCommand())) {
                                String[] strArrSplit = str2.substring(length, str2.length()).trim().split(" ");
                                int length3 = strArrSplit.length;
                                if (length3 > 16) {
                                    length3 = 16;
                                }
                                int[] iArr = new int[length3];
                                for (int i3 = 0; i3 < length3; i3++) {
                                    try {
                                        iArr[i3] = Integer.parseInt(strArrSplit[i3]);
                                        if (iArr[i3] >= -32768) {
                                            int i4 = iArr[i3];
                                        }
                                    } catch (Exception unused) {
                                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.sms_in_error_parse_int), 1).show();
                                    }
                                }
                                ru.himik.nightscream.kascada.CustomComponents.b bVar = new ru.himik.nightscream.kascada.CustomComponents.b();
                                bVar.A(xVar.getIdComponent());
                                bVar.F(xVar.f8932g.r());
                                bVar.E(xVar.f8932g.l());
                                bVar.u(xVar.f8932g.b());
                                bVar.v(xVar.f8932g.c());
                                bVar.C(xVar.getKey());
                                bVar.D(xVar.f8932g.k());
                                bVar.L((byte) 16);
                                bVar.K(0);
                                bVar.w(iArr);
                                if (xVar.f8932g.l() == 100) {
                                    if (MyApplication.b().v0 != null) {
                                        MyApplication.b().v0.e(bVar);
                                    }
                                } else if (MyApplication.b().E.get(xVar.f8932g.l()).h()) {
                                    Y0.get(xVar.f8932g.k()).e(bVar);
                                }
                                if (xVar.b()) {
                                    ru.himik.nightscream.kascada.CustomComponents.b bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b();
                                    bVar2.A(xVar.getIdComponent());
                                    bVar2.F(xVar.f8932g.r());
                                    bVar2.E(xVar.f8932g.l());
                                    bVar2.u(xVar.f8932g.b());
                                    bVar2.v(xVar.getRegStrob());
                                    bVar2.t((byte) xVar.getBitStrob());
                                    bVar2.J(true);
                                    bVar2.C(xVar.getKey());
                                    bVar2.D(xVar.f8932g.k());
                                    bVar2.L((byte) 5);
                                    if (xVar.f8932g.l() == 100) {
                                        if (MyApplication.b().v0 != null) {
                                            MyApplication.b().v0.e(bVar2);
                                        }
                                    } else if (MyApplication.b().E.get(xVar.f8932g.l()).h()) {
                                        Y0.get(xVar.f8932g.k()).e(bVar2);
                                    }
                                }
                            }
                        } else if (xVar.getCommand().equals(str2)) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar3 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar3.A(xVar.getIdComponent());
                            bVar3.F(xVar.f8932g.r());
                            bVar3.E(xVar.f8932g.l());
                            bVar3.u(xVar.f8932g.b());
                            bVar3.C(xVar.getKey());
                            bVar3.D(xVar.f8932g.k());
                            bVar3.v(xVar.f8932g.c());
                            bVar3.t(xVar.f8932g.a());
                            bVar3.L((byte) 5);
                            bVar3.J(true);
                            bVar3.x(this.o.c(bVar3, xVar.f8932g.i()));
                            if (xVar.f8932g.l() != 100) {
                                Y0.get(xVar.f8932g.k()).e(bVar3);
                            } else if (MyApplication.b().v0 != null) {
                                MyApplication.b().v0.e(bVar3);
                            }
                            z2 = true;
                        } else {
                            Toast.makeText(getApplication(), getResources().getString(R.string.sms_in_error_phone_ok_but_command_wrong), 1).show();
                            z3 = true;
                        }
                    }
                }
            }
            if (z2) {
                Toast.makeText(getApplication(), getResources().getString(R.string.sms_in_error_phone_and_command_ok_send), 1).show();
            }
            if (!z3 || z2) {
                return;
            }
            Toast.makeText(getApplication(), getResources().getString(R.string.sms_in_error_phone_ok_but_command_wrong), 1).show();
        }
    }

    public void i0() {
        for (int i2 = 0; i2 < MyApplication.b().D.size(); i2++) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = MyApplication.b().D.get(MyApplication.b().D.keyAt(i2));
            if (aVar.getKeyOut() != -1 && aVar.getKeyOut() >= 0) {
                for (int i3 = 0; i3 < MyApplication.b().D.size(); i3++) {
                    ru.himik.nightscream.kascada.Logic.c.a aVar2 = MyApplication.b().D.get(MyApplication.b().D.keyAt(i3));
                    if (aVar.getSaveKey() != aVar2.getSaveKey() && ((aVar2.getTypeFb() != 133 || !((VarNameIn) aVar2).t()) && aVar2.getSaveKey() == aVar.getKeyOut())) {
                        aVar.e(aVar2);
                        aVar2.d(aVar, aVar.getNumOnIn());
                    }
                }
            }
        }
    }

    public native void init(Context context);

    public void j0() {
        com.rarepebble.colorpicker.b bVar = new com.rarepebble.colorpicker.b(getApplicationContext());
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.choose_background));
        builder.setView(bVar);
        builder.setPositiveButton(getResources().getString(R.string.set), new f(this, bVar));
        builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new g(this));
        builder.show();
    }

    public void k0() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent2.setType("image/*");
        Intent intentCreateChooser = Intent.createChooser(intent, getResources().getString(R.string.choose_background));
        intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
        startActivityForResult(intentCreateChooser, 4);
    }

    void l0(int i2, boolean z2) {
        if (this.f9206k) {
            for (int i3 = 0; i3 < MyApplication.b().f9042j; i3++) {
                try {
                    if (MyApplication.b().E.get(i3).d() != -1 && Y0.get(MyApplication.b().E.get(i3).d()).a() == i2) {
                        MyApplication.b().v0.Y(i3, z2);
                    }
                } catch (Exception unused) {
                }
            }
            if (this.f9206k) {
                for (int i4 = 0; i4 < MyApplication.b().F.size(); i4++) {
                    int iKeyAt = MyApplication.b().F.keyAt(i4);
                    ru.himik.nightscream.kascada.CustomComponents.y yVar = (ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(iKeyAt);
                    if (yVar.f8943g.k() != -1 && Y0.get(yVar.f8943g.k()).a() == i2) {
                        yVar.setConnectionError(z2);
                        yVar.invalidate();
                        if (!z2) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar = new ru.himik.nightscream.kascada.CustomComponents.b(yVar.getIdComponent(), (byte) MyApplication.b().E.get(yVar.f8943g.l()).a(), yVar.f8943g.c(), yVar.f8943g.a(), (byte) 1, iKeyAt);
                            bVar.x(this.o.c(bVar, yVar.f8943g.i()));
                            bVar.F(yVar.f8943g.r());
                            Y0.get(yVar.f8943g.k()).c(bVar);
                        }
                    }
                }
                for (int i5 = 0; i5 < MyApplication.b().H.size(); i5++) {
                    int iKeyAt2 = MyApplication.b().H.keyAt(i5);
                    if (((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(iKeyAt2)).f8903k.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(iKeyAt2)).f8903k.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(iKeyAt2)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(iKeyAt2)).invalidate();
                    }
                }
                for (int i6 = 0; i6 < MyApplication.b().I.size(); i6++) {
                    int iKeyAt3 = MyApplication.b().I.keyAt(i6);
                    if (((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt3)).f8865g.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt3)).f8865g.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt3)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt3)).invalidate();
                    }
                }
                for (int i7 = 0; i7 < MyApplication.b().J.size(); i7++) {
                    int iKeyAt4 = MyApplication.b().J.keyAt(i7);
                    if (((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt4)).f8769i.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt4)).f8769i.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt4)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt4)).invalidate();
                    }
                }
                for (int i8 = 0; i8 < MyApplication.b().K.size(); i8++) {
                    CustomDynText customDynText = (CustomDynText) MyApplication.b().K.get(MyApplication.b().K.keyAt(i8));
                    if (customDynText.f8667i.k() != -1 && Y0.get(customDynText.f8667i.k()).a() == i2) {
                        customDynText.setConnectionError(z2);
                        customDynText.invalidate();
                    }
                }
                for (int i9 = 0; i9 < MyApplication.b().L.size(); i9++) {
                    ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(MyApplication.b().L.keyAt(i9));
                    if (iVar.f8813j.k() != -1 && !z2) {
                        iVar.setConnectionError(z2);
                        iVar.invalidate();
                        if (iVar.f8813j.l() == 100) {
                            MyApplication.b().v0.e(iVar.getInitConnectionInfo());
                        }
                        if (Y0.get(iVar.f8813j.k()).a() == i2) {
                            Y0.get(iVar.f8813j.k()).c(iVar.getInitConnectionInfo());
                        }
                    }
                }
                for (int i10 = 0; i10 < MyApplication.b().M.size(); i10++) {
                    int iKeyAt5 = MyApplication.b().M.keyAt(i10);
                    if (((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).f8742h.k() != -1 && ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).getNumScreen() == a1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).f8742h.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).invalidate();
                    }
                }
                for (int i11 = 0; i11 < MyApplication.b().N.size(); i11++) {
                    int iKeyAt6 = MyApplication.b().N.keyAt(i11);
                    if (((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).f8921g.k() != -1 && ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).getNumScreen() == a1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).f8921g.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).invalidate();
                    }
                }
                for (int i12 = 0; i12 < MyApplication.b().O.size(); i12++) {
                    int iKeyAt7 = MyApplication.b().O.keyAt(i12);
                    if (((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt7)).f8874e.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt7)).f8874e.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt7)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt7)).invalidate();
                    }
                }
                for (int i13 = 0; i13 < MyApplication.b().P.size(); i13++) {
                    int iKeyAt8 = MyApplication.b().P.keyAt(i13);
                    if (((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt8)).I.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt8)).I.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt8)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt8)).invalidate();
                    }
                }
                for (int i14 = 0; i14 < MyApplication.b().Q.size(); i14++) {
                    ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(MyApplication.b().Q.keyAt(i14));
                    if (vVar.f8909f.k() != -1) {
                        if (vVar.f8909f.l() == 100) {
                            ru.himik.nightscream.kascada.CustomComponents.b bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b();
                            bVar2.A(vVar.getIdComponent());
                            bVar2.v(vVar.f8909f.c());
                            bVar2.t(vVar.f8909f.a());
                            bVar2.L((byte) 3);
                            bVar2.C(vVar.getKey());
                            bVar2.F(vVar.f8909f.r());
                            bVar2.u(vVar.f8909f.b());
                            bVar2.x(this.o.c(bVar2, vVar.f8909f.i()));
                            MyApplication.b().v0.e(bVar2);
                        } else if (Y0.get(vVar.f8909f.k()).a() == i2) {
                            vVar.setConnectionError(z2);
                            vVar.invalidate();
                            if (!z2) {
                                ru.himik.nightscream.kascada.CustomComponents.b bVar3 = new ru.himik.nightscream.kascada.CustomComponents.b();
                                bVar3.A(vVar.getIdComponent());
                                bVar3.v(vVar.f8909f.c());
                                bVar3.t(vVar.f8909f.a());
                                bVar3.L((byte) 3);
                                bVar3.F(vVar.f8909f.r());
                                bVar3.C(vVar.getKey());
                                bVar3.u(vVar.f8909f.b());
                                bVar3.x(this.o.c(bVar3, vVar.f8909f.i()));
                                Y0.get(vVar.f8909f.k()).c(bVar3);
                            }
                        }
                    }
                }
                for (int i15 = 0; i15 < MyApplication.b().R.size(); i15++) {
                    int iKeyAt9 = MyApplication.b().R.keyAt(i15);
                    if (((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt9)).T.k() == -1) {
                        break;
                    }
                    if (Y0.get(((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt9)).T.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt9)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt9)).invalidate();
                    }
                }
                for (int i16 = 0; i16 < MyApplication.b().T.size(); i16++) {
                    int iKeyAt10 = MyApplication.b().T.keyAt(i16);
                    if (((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt10)).f8854g.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt10)).f8854g.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt10)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt10)).invalidate();
                    }
                }
                for (int i17 = 0; i17 < MyApplication.b().U.size(); i17++) {
                    int iKeyAt11 = MyApplication.b().U.keyAt(i17);
                    if (((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt11)).f8798e.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt11)).f8798e.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt11)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt11)).invalidate();
                    }
                }
                for (int i18 = 0; i18 < MyApplication.b().V.size(); i18++) {
                    int iKeyAt12 = MyApplication.b().V.keyAt(i18);
                    if (((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt12)).f8932g.k() != -1 && ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt12)).getNumScreen() == a1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt12)).f8932g.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt12)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt12)).invalidate();
                    }
                }
                for (int i19 = 0; i19 < MyApplication.b().W.size(); i19++) {
                    int iKeyAt13 = MyApplication.b().W.keyAt(i19);
                    if (((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).f8832g.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).f8832g.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).setConnectionErrorSource(z2);
                    }
                    if (((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).f8833h.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).f8833h.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).setConnectionErrorReceive(z2);
                    }
                    if (((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).getNumScreen() == a1 && (((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).d() || ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).c())) {
                        ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).setVisibility(0);
                    } else {
                        ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).setVisibility(4);
                    }
                    if (!this.f9206k) {
                        ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt13)).setVisibility(0);
                    }
                }
                for (int i20 = 0; i20 < MyApplication.b().X.size(); i20++) {
                    int iKeyAt14 = MyApplication.b().X.keyAt(i20);
                    if (((CustomList) MyApplication.b().X.get(iKeyAt14)).f8687i.k() != -1 && Y0.get(((CustomList) MyApplication.b().X.get(iKeyAt14)).f8687i.k()).a() == i2) {
                        ((CustomList) MyApplication.b().X.get(iKeyAt14)).setConnectionError(z2);
                        ((CustomList) MyApplication.b().X.get(iKeyAt14)).invalidate();
                    }
                }
                for (int i21 = 0; i21 < MyApplication.b().Y.size(); i21++) {
                    int iKeyAt15 = MyApplication.b().Y.keyAt(i21);
                    if (((CustomSound) MyApplication.b().Y.get(iKeyAt15)).f8696g.k() != -1 && Y0.get(((CustomSound) MyApplication.b().Y.get(iKeyAt15)).f8696g.k()).a() == i2) {
                        ((CustomSound) MyApplication.b().Y.get(iKeyAt15)).setConnectionError(z2);
                        ((CustomSound) MyApplication.b().Y.get(iKeyAt15)).invalidate();
                    }
                }
                for (int i22 = 0; i22 < MyApplication.b().b0.size(); i22++) {
                    int iKeyAt16 = MyApplication.b().b0.keyAt(i22);
                    if (((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt16)).J0.k() != -1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt16)).J0.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt16)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt16)).invalidate();
                    }
                }
                for (int i23 = 0; i23 < MyApplication.b().c0.size(); i23++) {
                    int iKeyAt17 = MyApplication.b().c0.keyAt(i23);
                    if (((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt17)).f8889g.k() != -1 && ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt17)).getNumScreen() == a1 && Y0.get(((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt17)).f8889g.k()).a() == i2) {
                        ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt17)).setConnectionError(z2);
                        ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt17)).invalidate();
                    }
                }
                y0();
            }
        }
    }

    public void lockScreen(View view) {
        if (a1 > 1) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getResources().getString(R.string.set_pass_on_screen));
            EditText editText = new EditText(this);
            editText.setInputType(129);
            editText.setSelection(editText.getText().length());
            editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
            builder.setView(editText);
            builder.setPositiveButton(getResources().getString(R.string.dialog_accept), new j0(this, editText));
            builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new k0(this));
            builder.show();
        }
        if (a1 == 1) {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.on_first_screen_can_not_set_pass), 1).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void n(ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View view = (View) aVar;
        X0.addView(view);
        int iKeyAt = MyApplication.b().D.size() == 0 ? 0 : MyApplication.b().D.keyAt(MyApplication.b().D.size() - 1) + 1;
        MyApplication.b().D.append(iKeyAt, aVar);
        ((ru.himik.nightscream.kascada.CustomComponents.z) aVar).setKey(iKeyAt);
        aVar.setSaveKey(iKeyAt);
        if (a1 != -1) {
            view.setVisibility(4);
        }
        view.setOnClickListener(this.R0);
    }

    /* JADX WARN: Code duplicated, block: B:246:0x0eb0  */
    /* JADX WARN: Code duplicated, block: B:75:0x04e4 A[PHI: r3
      0x04e4: PHI (r3v220 ru.himik.nightscream.kascada.CustomComponents.b) = (r3v211 ru.himik.nightscream.kascada.CustomComponents.b), (r3v225 ru.himik.nightscream.kascada.CustomComponents.b) binds: [B:74:0x04e2, B:56:0x03a8] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:76:0x04e7 A[PHI: r3 r5
      0x04e7: PHI (r3v222 ru.himik.nightscream.kascada.CustomComponents.b) = (r3v211 ru.himik.nightscream.kascada.CustomComponents.b), (r3v225 ru.himik.nightscream.kascada.CustomComponents.b) binds: [B:74:0x04e2, B:56:0x03a8] A[DONT_GENERATE, DONT_INLINE]
      0x04e7: PHI (r5v345 int) = (r5v331 int), (r5v361 int) binds: [B:74:0x04e2, B:56:0x03a8] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onActivityResult(int i2, int i3, Intent intent) {
        byte b2;
        ru.himik.nightscream.kascada.CustomComponents.b bVar;
        ru.himik.nightscream.kascada.CustomComponents.b bVar2;
        double d2;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        ru.himik.nightscream.kascada.CustomComponents.b bVar3;
        int i13;
        super.onActivityResult(i2, i3, intent);
        if (i2 == 4 && i3 == -1) {
            if (intent == null) {
                return;
            }
            Uri data = intent.getData();
            File file = null;
            try {
                file = new File(ru.himik.nightscream.kascada.Utils.q.f(this, data));
            } catch (Exception unused) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.failed_to_load_file), 1).show();
            }
            if (file == null) {
                return;
            }
            f.b.a.i.w(this).t(file).K().o(new h(MyApplication.b().f9040h, MyApplication.b().f9041i));
            MyApplication.b().C.get(a1 - 1).h(Boolean.FALSE);
            MyApplication.b().C.get(a1 - 1).n(ru.himik.nightscream.kascada.Utils.q.f(this, data));
            this.W.bringToFront();
            this.f9207l.bringToFront();
            this.a.bringToFront();
        }
        if (i2 == 1) {
            SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
            switch (this.f9205j.c()) {
                case 1:
                    ((ru.himik.nightscream.kascada.CustomComponents.y) this.f9204i).setVisibleInWork(defaultSharedPreferences.getBoolean("checkVisible", false));
                    break;
                case 2:
                    CustomLabel customLabel = (CustomLabel) this.f9204i;
                    customLabel.setText(defaultSharedPreferences.getString("base_pref_edit_text", getResources().getString(R.string.error)));
                    customLabel.setTextSize(0, Integer.parseInt(defaultSharedPreferences.getString("base_pref_edit_height_text", "36")));
                    customLabel.setTextColor(defaultSharedPreferences.getInt("colorText", this.f9205j.b()));
                    customLabel.setBackgroundColor_(defaultSharedPreferences.getInt("colorBackground", this.f9205j.a()));
                    customLabel.setAutoResizeText(defaultSharedPreferences.getBoolean("AutoResizeText", true));
                    customLabel.setEnableFrameLabel(defaultSharedPreferences.getBoolean("enableFrameLabel", false));
                    break;
                case 4:
                    ru.himik.nightscream.kascada.CustomComponents.u uVar = (ru.himik.nightscream.kascada.CustomComponents.u) this.f9204i;
                    uVar.setTextColor(defaultSharedPreferences.getInt("colorText", this.f9205j.b()));
                    uVar.setBackgroundColorReg(defaultSharedPreferences.getInt("colorBackground", this.f9205j.a()));
                    uVar.setDigit(Integer.parseInt(defaultSharedPreferences.getString("listDigit", "4")));
                    uVar.setDivisor(Integer.parseInt(defaultSharedPreferences.getString("listDivisor", "0")));
                    uVar.setType(Integer.parseInt(defaultSharedPreferences.getString("listTypeRegister", "1")));
                    if (uVar.getDigit() < uVar.getDivisor()) {
                        uVar.setDivisor(0);
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.number_of_digits_must_be_greater_than_the_decimal_point), 0).show();
                    }
                    uVar.f(uVar.getValue());
                    uVar.setFontChange(defaultSharedPreferences.getBoolean("checkFontChangeRegister", false));
                    uVar.setEnableFrameRegister(defaultSharedPreferences.getBoolean("enableFrameRegister", false));
                    break;
                case 5:
                    ((ru.himik.nightscream.kascada.CustomComponents.q) this.f9204i).setTypeRequest((byte) Integer.parseInt(defaultSharedPreferences.getString("listTypeLamp", "1")));
                    break;
                case 6:
                    ru.himik.nightscream.kascada.CustomComponents.e eVar = (ru.himik.nightscream.kascada.CustomComponents.e) this.f9204i;
                    eVar.setText(defaultSharedPreferences.getString("base_pref_edit_text", "ошибка ...."));
                    eVar.setTextSize(0, Integer.parseInt(defaultSharedPreferences.getString("base_pref_edit_height_text", "36")));
                    eVar.setTextColor(defaultSharedPreferences.getInt("colorText", this.f9205j.b()));
                    eVar.setVisibleInWork(defaultSharedPreferences.getBoolean("checkVisible", false));
                    eVar.setMode(Integer.parseInt(defaultSharedPreferences.getString("list_button_mode", "0")));
                    eVar.setAutoResizeText(defaultSharedPreferences.getBoolean("AutoResizeText", true));
                    break;
                case 7:
                    CustomDynText customDynText = (CustomDynText) this.f9204i;
                    customDynText.setColorText(defaultSharedPreferences.getInt("colorText", this.f9205j.b()));
                    customDynText.w(0, defaultSharedPreferences.getString("base_pref_edit_text0", ""));
                    customDynText.w(1, defaultSharedPreferences.getString("base_pref_edit_text1", ""));
                    customDynText.w(2, defaultSharedPreferences.getString("base_pref_edit_text2", ""));
                    customDynText.w(3, defaultSharedPreferences.getString("base_pref_edit_text3", ""));
                    customDynText.w(4, defaultSharedPreferences.getString("base_pref_edit_text4", ""));
                    customDynText.w(5, defaultSharedPreferences.getString("base_pref_edit_text5", ""));
                    customDynText.w(6, defaultSharedPreferences.getString("base_pref_edit_text6", ""));
                    customDynText.w(7, defaultSharedPreferences.getString("base_pref_edit_text7", ""));
                    customDynText.w(8, defaultSharedPreferences.getString("base_pref_edit_text8", ""));
                    customDynText.w(9, defaultSharedPreferences.getString("base_pref_edit_text9", ""));
                    customDynText.w(10, defaultSharedPreferences.getString("base_pref_edit_text10", ""));
                    customDynText.w(11, defaultSharedPreferences.getString("base_pref_edit_text11", ""));
                    customDynText.w(12, defaultSharedPreferences.getString("base_pref_edit_text12", ""));
                    customDynText.w(13, defaultSharedPreferences.getString("base_pref_edit_text13", ""));
                    customDynText.w(14, defaultSharedPreferences.getString("base_pref_edit_text14", ""));
                    customDynText.w(15, defaultSharedPreferences.getString("base_pref_edit_text15", ""));
                    customDynText.v(0, defaultSharedPreferences.getInt("colorBackground0", 16777215));
                    customDynText.v(1, defaultSharedPreferences.getInt("colorBackground1", 16777215));
                    customDynText.v(2, defaultSharedPreferences.getInt("colorBackground2", 16777215));
                    customDynText.v(3, defaultSharedPreferences.getInt("colorBackground3", 16777215));
                    customDynText.v(4, defaultSharedPreferences.getInt("colorBackground4", 16777215));
                    customDynText.v(5, defaultSharedPreferences.getInt("colorBackground5", 16777215));
                    customDynText.v(6, defaultSharedPreferences.getInt("colorBackground6", 16777215));
                    customDynText.v(7, defaultSharedPreferences.getInt("colorBackground7", 16777215));
                    customDynText.v(8, defaultSharedPreferences.getInt("colorBackground8", 16777215));
                    customDynText.v(9, defaultSharedPreferences.getInt("colorBackground9", 16777215));
                    customDynText.v(10, defaultSharedPreferences.getInt("colorBackground10", 16777215));
                    customDynText.v(11, defaultSharedPreferences.getInt("colorBackground11", 16777215));
                    customDynText.v(12, defaultSharedPreferences.getInt("colorBackground12", 16777215));
                    customDynText.v(13, defaultSharedPreferences.getInt("colorBackground13", 16777215));
                    customDynText.v(14, defaultSharedPreferences.getInt("colorBackground14", 16777215));
                    customDynText.v(15, defaultSharedPreferences.getInt("colorBackground15", 16777215));
                    customDynText.setTypeCommand(Integer.parseInt(defaultSharedPreferences.getString("listTypeCommandDynText", "0")));
                    customDynText.setAutoResizeText(defaultSharedPreferences.getBoolean("AutoResizeText", true));
                    customDynText.setEnableFrameDynText(defaultSharedPreferences.getBoolean("enableFrameDynText", false));
                    if (!customDynText.t()) {
                        customDynText.setTextSize(0, Integer.parseInt(defaultSharedPreferences.getString("base_pref_edit_height_text", "36")));
                    }
                    break;
                case 8:
                    ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) this.f9204i;
                    iVar.setTextColor(defaultSharedPreferences.getInt("colorText", this.f9205j.b()));
                    iVar.setBackgroundColorEditNumber(defaultSharedPreferences.getInt("colorBackground", this.f9205j.a()));
                    iVar.setMinValue(Float.parseFloat(defaultSharedPreferences.getString("min", "0")));
                    iVar.setMaxValue(Float.parseFloat(defaultSharedPreferences.getString("max", "1000")));
                    iVar.setPassword(defaultSharedPreferences.getString("edit_number_pass", ""));
                    iVar.setType(Integer.parseInt(defaultSharedPreferences.getString("listTypeEditNumber", "0")));
                    iVar.setTypeInt(Integer.parseInt(defaultSharedPreferences.getString("listTypeIntEditNumber", "0")));
                    iVar.setCountNumAfterPointEditNumber(Integer.parseInt(defaultSharedPreferences.getString("listCountNumAfterPointEditNumber", "0")) + 1);
                    iVar.setFontChange(defaultSharedPreferences.getBoolean("checkFontChangeEditNumber", false));
                    iVar.setEnableFrameEditNumber(defaultSharedPreferences.getBoolean("enableFrameEditNumber", false));
                    break;
                case 10:
                    ru.himik.nightscream.kascada.CustomComponents.w wVar = (ru.himik.nightscream.kascada.CustomComponents.w) this.f9204i;
                    wVar.setPhone(defaultSharedPreferences.getString("pref_edit_sms_phone", ""));
                    wVar.setMessage(defaultSharedPreferences.getString("pref_edit_sms_message", "error"));
                    wVar.setOption(defaultSharedPreferences.getBoolean("chOption", false));
                    try {
                        wVar.setOptionRegister(Integer.parseInt(defaultSharedPreferences.getString("optionRegister", "0")));
                        break;
                    } catch (Exception unused2) {
                    }
                    try {
                        wVar.setOptionCountRegister(Integer.parseInt(defaultSharedPreferences.getString("optionCountRegister", "0")));
                    } catch (Exception unused3) {
                    }
                    break;
                case 11:
                    ru.himik.nightscream.kascada.CustomComponents.r rVar = (ru.himik.nightscream.kascada.CustomComponents.r) this.f9204i;
                    rVar.setShowText(defaultSharedPreferences.getBoolean("chShowText", false));
                    try {
                        rVar.setSizeText(Integer.parseInt(defaultSharedPreferences.getString("editSizeText", "50")));
                        break;
                    } catch (Exception unused4) {
                    }
                    rVar.setColorText(defaultSharedPreferences.getInt("colorText", -16777216));
                    rVar.setShowScale(defaultSharedPreferences.getBoolean("chShowScale", true));
                    try {
                        rVar.setValueMax(Integer.parseInt(defaultSharedPreferences.getString("lineLevelEditMax", "100")));
                        break;
                    } catch (Exception unused5) {
                    }
                    try {
                        rVar.setValueMin(Integer.parseInt(defaultSharedPreferences.getString("lineLevelEditMin", "0")));
                        break;
                    } catch (Exception unused6) {
                    }
                    rVar.setColorProgress(defaultSharedPreferences.getInt("colorProgress", -16711936));
                    rVar.setColorBackground(defaultSharedPreferences.getInt("colorBackground", 0));
                    rVar.e();
                    rVar.invalidate();
                    break;
                case 12:
                    ru.himik.nightscream.kascada.CustomComponents.g gVar = (ru.himik.nightscream.kascada.CustomComponents.g) this.f9204i;
                    gVar.setOutColor(defaultSharedPreferences.getInt("gauge_outColor", Color.parseColor("#FF277454")));
                    gVar.setInColor(defaultSharedPreferences.getInt("gauge_inColor", Color.parseColor("#890b0b0b")));
                    gVar.setCenterColor(defaultSharedPreferences.getInt("gauge_centerColor", Color.parseColor("#000000")));
                    try {
                        int i14 = Integer.parseInt(defaultSharedPreferences.getString("max_gauge", "100"));
                        if (i14 > 5) {
                            d2 = i14;
                        } else {
                            Toast.makeText(getApplicationContext(), "Максимум не менее 5.", 1).show();
                            d2 = 5.0d;
                        }
                        gVar.setMaxSpeed(d2);
                        break;
                    } catch (Exception unused7) {
                    }
                    try {
                        gVar.setLabelTextSize(Integer.parseInt(defaultSharedPreferences.getString("gauge_sizeText", "50")));
                        break;
                    } catch (Exception unused8) {
                    }
                    gVar.setShowText(defaultSharedPreferences.getBoolean("gauge_showText", true));
                    gVar.setColorText(defaultSharedPreferences.getInt("gauge_textColor", -16777216));
                    gVar.j(defaultSharedPreferences.getInt("firstPoint", 0), defaultSharedPreferences.getInt("secondPoint", 0));
                    break;
                case 13:
                    ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) this.f9204i;
                    vVar.setColorText(defaultSharedPreferences.getInt("colorText", -65536));
                    String string = defaultSharedPreferences.getString("seekBarEditMax", "100");
                    vVar.setMax(string.length() > 0 ? Integer.parseInt(string) : 100);
                    vVar.setColorProgress(defaultSharedPreferences.getInt("colorProgress", -16776961));
                    vVar.setColorBackground(defaultSharedPreferences.getInt("colorBackground", 0));
                    vVar.l();
                    break;
                case 14:
                    ru.himik.nightscream.kascada.CustomComponents.o oVar = (ru.himik.nightscream.kascada.CustomComponents.o) this.f9204i;
                    String string2 = defaultSharedPreferences.getString("secondPeriod", "100");
                    oVar.setSecondPeriod(string2.length() > 0 ? Integer.parseInt(string2) : 1000);
                    String string3 = defaultSharedPreferences.getString("graphCountPoint", "10");
                    oVar.setCountPoint(string3.length() > 0 ? Integer.parseInt(string3) : 10);
                    oVar.setColorBackground_(defaultSharedPreferences.getInt("graphColorBackground", -16777216));
                    oVar.setType(Integer.parseInt(defaultSharedPreferences.getString("listTypeGraph", "1")));
                    oVar.setNameSeries1(defaultSharedPreferences.getString("graphNameSeries1", ""));
                    oVar.setNameSeries2(defaultSharedPreferences.getString("graphNameSeries2", ""));
                    oVar.setNameSeries3(defaultSharedPreferences.getString("graphNameSeries3", ""));
                    oVar.setNameSeries4(defaultSharedPreferences.getString("graphNameSeries4", ""));
                    try {
                        oVar.setCountGraphChannel(Integer.parseInt(defaultSharedPreferences.getString("graphCountChannel", "1")));
                        break;
                    } catch (Exception unused9) {
                    }
                    oVar.a();
                    break;
                case 15:
                    ru.himik.nightscream.kascada.CustomComponents.d dVar = (ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i;
                    dVar.setFileName(defaultSharedPreferences.getString("ArchiveFileName", "default"));
                    dVar.setTypeRecord(defaultSharedPreferences.getString("ArchiveType", "FLOAT"));
                    String string4 = defaultSharedPreferences.getString("ArchiveCountChannel", "4");
                    dVar.setCountChannel(string4.length() > 0 ? Integer.parseInt(string4) : 4);
                    String string5 = defaultSharedPreferences.getString("ArchiveRegister", "0");
                    if (string5.length() > 0) {
                        dVar.setRegisterArchive(Integer.parseInt(string5));
                    } else {
                        dVar.setRegisterArchive(0);
                    }
                    dVar.setOptionChannel(defaultSharedPreferences.getBoolean("ArchiveOptionChannel", false));
                    dVar.setTypeRecordOptionChannel(defaultSharedPreferences.getString("ArchiveTypeOptionChannel", "ASCII"));
                    try {
                        i4 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveRegisterOptionChannel", "0"));
                    } catch (Exception unused10) {
                        i4 = 0;
                    }
                    dVar.setRegArchiveOptionalChannel(i4);
                    try {
                        i5 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveLengthOptionChannel", "2"));
                    } catch (Exception unused11) {
                        i5 = 2;
                    }
                    dVar.setCountArchiveOptionalChannelASCII(i5);
                    int i15 = Integer.parseInt(defaultSharedPreferences.getString("listArchiveConnections", "1"));
                    if (i15 == 0) {
                        dVar.f8754i.E(100);
                    } else {
                        dVar.f8754i.E(i15 - 1);
                    }
                    dVar.setEmailLogin(defaultSharedPreferences.getString("ArchiveEmailLogin", ""));
                    dVar.setEmailPassword(defaultSharedPreferences.getString("ArchiveEmailPassword", ""));
                    dVar.setEmailTo(defaultSharedPreferences.getString("ArchiveEmailTo", ""));
                    try {
                        i6 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveRegisterSendMail", "0"));
                    } catch (Exception unused12) {
                        i6 = 0;
                    }
                    dVar.setRegSendEmail(i6);
                    try {
                        i7 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveBitSendMail", "0"));
                    } catch (Exception unused13) {
                        i7 = 0;
                    }
                    if (i7 < 0 || i7 > 15) {
                        dVar.setBitSendEmail(0);
                    } else {
                        dVar.setBitSendEmail(i7);
                    }
                    dVar.setResetArchive(defaultSharedPreferences.getBoolean("ArchiveIsReset", false));
                    try {
                        i8 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveRegisterReset", "0"));
                    } catch (Exception unused14) {
                        i8 = 0;
                    }
                    dVar.setRegResetArchive(i8);
                    try {
                        i9 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveBitReset", "0"));
                    } catch (Exception unused15) {
                        i9 = 0;
                    }
                    if (i9 < 0 || i9 > 15) {
                        dVar.setBitResetArchive(0);
                    } else {
                        dVar.setBitResetArchive(i9);
                    }
                    dVar.setSendToCloudArchive(defaultSharedPreferences.getBoolean("archiveSendToCloudArchive", false));
                    try {
                        i10 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveRegisterSendToCloudArchive", "0"));
                    } catch (Exception unused16) {
                        i10 = 0;
                    }
                    dVar.setRegSendToCloudArchive(i10);
                    try {
                        i11 = Integer.parseInt(defaultSharedPreferences.getString("ArchiveBitSendToCloudArchive", "0"));
                    } catch (Exception unused17) {
                        i11 = 0;
                    }
                    if (i11 < 0 || i11 > 15) {
                        dVar.setBitSendToCloudArchive(0);
                    } else {
                        dVar.setBitSendToCloudArchive(i11);
                    }
                    break;
                case 16:
                    ((ru.himik.nightscream.kascada.CustomComponents.n) this.f9204i).setPathGif(defaultSharedPreferences.getString("EditGifPath", ""));
                    break;
                case 17:
                    ru.himik.nightscream.kascada.CustomComponents.h hVar = (ru.himik.nightscream.kascada.CustomComponents.h) this.f9204i;
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_0", ""), 0);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_1", ""), 1);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_2", ""), 2);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_3", ""), 3);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_4", ""), 4);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_5", ""), 5);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_6", ""), 6);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_7", ""), 7);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_8", ""), 8);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_9", ""), 9);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_10", ""), 10);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_11", ""), 11);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_12", ""), 12);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_13", ""), 13);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_14", ""), 14);
                    hVar.e(defaultSharedPreferences.getString("EditPathPicture_15", ""), 15);
                    hVar.f(Integer.parseInt(defaultSharedPreferences.getString("prefEditTouchX", "0")), Integer.parseInt(defaultSharedPreferences.getString("prefEditTouchY", "0")));
                    hVar.setTypeCommand(Integer.parseInt(defaultSharedPreferences.getString("listTypeCommandDynPicture", "0")));
                    hVar.b(false);
                    break;
                case 18:
                    ru.himik.nightscream.kascada.CustomComponents.x xVar = (ru.himik.nightscream.kascada.CustomComponents.x) this.f9204i;
                    String string6 = defaultSharedPreferences.getString("SmsReceivePhone", "");
                    String string7 = defaultSharedPreferences.getString("SmsReceiveTextCommand", "");
                    xVar.setTypeCommand(Integer.parseInt(defaultSharedPreferences.getString("listTypeCommandSmsReceive", "0")));
                    xVar.setPhone(string6);
                    xVar.setCommand(string7);
                    xVar.setStrob(defaultSharedPreferences.getBoolean("smsRecCheckStrob", false));
                    xVar.setRegStrob(Integer.parseInt(defaultSharedPreferences.getString("smsRecReg", "0")));
                    xVar.setBitStrob(Integer.parseInt(defaultSharedPreferences.getString("smsRecBit", "0")));
                    if (xVar.getBitStrob() < 0 || xVar.getBitStrob() > 15) {
                        xVar.setBitStrob(0);
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 1).show();
                    }
                    break;
                case 19:
                    ru.himik.nightscream.kascada.CustomComponents.k kVar = (ru.himik.nightscream.kascada.CustomComponents.k) this.f9204i;
                    kVar.setMode(Integer.parseInt(defaultSharedPreferences.getString("listModeGateway", "0")));
                    kVar.setRegMode(Integer.parseInt(defaultSharedPreferences.getString("gatewayReg", "0")));
                    int i16 = Integer.parseInt(defaultSharedPreferences.getString("editGatewayCountRegister", "1"));
                    if (i16 <= 0 || i16 >= ru.himik.nightscream.kascada.q.d.b.E) {
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_input_num_sys_reg), 1).show();
                    } else {
                        kVar.f8832g.z((byte) i16);
                    }
                    byte b3 = (byte) Integer.parseInt(defaultSharedPreferences.getString("gatewayBit", "0"));
                    if (b3 < 16) {
                        kVar.setBitMode(b3);
                    } else {
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                    }
                    i12 = Integer.parseInt(defaultSharedPreferences.getString("listGatewayConnections", "1"));
                    bVar3 = kVar.f8834i;
                    if (i12 == 0) {
                        i13 = 100;
                    } else {
                        i13 = i12 - 1;
                    }
                    bVar3.E(i13);
                    break;
                case 20:
                    CustomList customList = (CustomList) this.f9204i;
                    customList.setText(defaultSharedPreferences.getString("base_pref_edit_text", getResources().getString(R.string.error)));
                    customList.setTextSize(0, Integer.parseInt(defaultSharedPreferences.getString("base_pref_edit_height_text", "36")));
                    customList.setTextColor(defaultSharedPreferences.getInt("colorText", this.f9205j.b()));
                    customList.setVisibleInWork(defaultSharedPreferences.getBoolean("checkVisible", true));
                    customList.setCheckNoChange(defaultSharedPreferences.getBoolean("checkNoChange", false));
                    for (int i17 = 0; i17 < 16; i17++) {
                        customList.m(defaultSharedPreferences.getString("base_pref_list_text_" + i17, ""), i17);
                    }
                    break;
                case 21:
                    CustomSound customSound = (CustomSound) this.f9204i;
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_0", ""), 0);
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_1", ""), 1);
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_2", ""), 2);
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_3", ""), 3);
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_4", ""), 4);
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_5", ""), 5);
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_6", ""), 6);
                    customSound.f(defaultSharedPreferences.getString("EditPathSound_7", ""), 7);
                    break;
                case 22:
                    ru.himik.nightscream.kascada.CustomComponents.l lVar = (ru.himik.nightscream.kascada.CustomComponents.l) this.f9204i;
                    try {
                        int i18 = Integer.parseInt(defaultSharedPreferences.getString("editGatewayBitCountBit", "1"));
                        if (i18 >= 1 && i18 <= 16) {
                            lVar.f8842f.y(i18);
                            lVar.f8843g.y(i18);
                            if (i18 > 1) {
                                if (lVar.f8842f.l() == 100) {
                                    lVar.f8842f.t((byte) 0);
                                }
                                if (lVar.f8843g.l() == 100) {
                                    lVar.f8843g.t((byte) 0);
                                }
                            }
                        }
                        break;
                    } catch (Exception unused18) {
                    }
                    lVar.setMode(Integer.parseInt(defaultSharedPreferences.getString("listModeGateway", "0")));
                    lVar.setRegMode(Integer.parseInt(defaultSharedPreferences.getString("gatewayReg", "0")));
                    byte b4 = (byte) Integer.parseInt(defaultSharedPreferences.getString("gatewayBit", "0"));
                    if (b4 < 16) {
                        lVar.setBitMode(b4);
                    } else {
                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                    }
                    i12 = Integer.parseInt(defaultSharedPreferences.getString("listGatewayConnections", "1"));
                    bVar3 = lVar.f8844h;
                    if (i12 == 0) {
                        i13 = 100;
                    } else {
                        i13 = i12 - 1;
                    }
                    bVar3.E(i13);
                    break;
                case 24:
                    ru.himik.nightscream.kascada.CustomComponents.m mVar = (ru.himik.nightscream.kascada.CustomComponents.m) this.f9204i;
                    mVar.setColorTextValue(defaultSharedPreferences.getInt("gauge_colorTextValue", -16777216));
                    mVar.setColorTextScale(defaultSharedPreferences.getInt("gauge_colorTextScale", -16777216));
                    mVar.setColorCenterCircle(defaultSharedPreferences.getInt("gauge_colorCenterCircle", -7829368));
                    mVar.setColorMark(defaultSharedPreferences.getInt("gauge_colorMark", -16777216));
                    int i19 = Integer.parseInt(defaultSharedPreferences.getString("gauge_min", "0"));
                    int i20 = Integer.parseInt(defaultSharedPreferences.getString("gauge_max", "100"));
                    if (i19 < i20) {
                        try {
                            mVar.setMaxGauge(i20);
                            mVar.setMinGauge(i19);
                        } catch (Exception unused19) {
                            if (i19 < i20) {
                                mVar.setMinGauge(i19);
                                mVar.setMaxGauge(i20);
                            }
                        }
                    }
                    int i21 = Integer.parseInt(defaultSharedPreferences.getString("gauge_countTextScale", "6"));
                    if (i21 > i20) {
                        Toast.makeText(this, R.string.toast_count_must_be_less_max_value, 1).show();
                    } else {
                        mVar.setCountTextScale(i21);
                    }
                    mVar.setSizeText(Integer.parseInt(defaultSharedPreferences.getString("gauge_sizeText", "20")));
                    mVar.U(defaultSharedPreferences.getInt("gauge_percentLowScale", 0), defaultSharedPreferences.getInt("gauge_percentMediumScale", 100));
                    mVar.setIndicatorName(defaultSharedPreferences.getString("gaugeIndicator", ""));
                    mVar.setHideBackground(defaultSharedPreferences.getBoolean("hideBackground", false));
                    mVar.setColorIndicator(defaultSharedPreferences.getInt("gauge_colorIndicator", getResources().getColor(R.color.text_orange)));
                    mVar.invalidate();
                    break;
                case 25:
                    ru.himik.nightscream.kascada.CustomComponents.t tVar = (ru.himik.nightscream.kascada.CustomComponents.t) this.f9204i;
                    tVar.setTo(defaultSharedPreferences.getString("pref_edit_push_to", ""));
                    tVar.setTitle(defaultSharedPreferences.getString("pref_edit_push_title", ""));
                    tVar.setBody(defaultSharedPreferences.getString("pref_edit_push_body", ""));
                    break;
                case 26:
                    ru.himik.nightscream.kascada.CustomComponents.b0 b0Var = (ru.himik.nightscream.kascada.CustomComponents.b0) this.f9204i;
                    b0Var.d(0, defaultSharedPreferences.getString("web_view_link_bit_0", ""));
                    b0Var.d(1, defaultSharedPreferences.getString("web_view_link_bit_1", ""));
                    b0Var.d(2, defaultSharedPreferences.getString("web_view_link_bit_2", ""));
                    b0Var.d(3, defaultSharedPreferences.getString("web_view_link_bit_3", ""));
                    b0Var.d(4, defaultSharedPreferences.getString("web_view_link_bit_4", ""));
                    b0Var.d(5, defaultSharedPreferences.getString("web_view_link_bit_5", ""));
                    b0Var.d(6, defaultSharedPreferences.getString("web_view_link_bit_6", ""));
                    b0Var.d(7, defaultSharedPreferences.getString("web_view_link_bit_7", ""));
                    b0Var.d(8, defaultSharedPreferences.getString("web_view_link_bit_8", ""));
                    b0Var.d(9, defaultSharedPreferences.getString("web_view_link_bit_9", ""));
                    b0Var.d(10, defaultSharedPreferences.getString("web_view_link_bit_10", ""));
                    b0Var.d(11, defaultSharedPreferences.getString("web_view_link_bit_11", ""));
                    b0Var.d(12, defaultSharedPreferences.getString("web_view_link_bit_12", ""));
                    b0Var.d(13, defaultSharedPreferences.getString("web_view_link_bit_13", ""));
                    b0Var.d(14, defaultSharedPreferences.getString("web_view_link_bit_14", ""));
                    b0Var.d(15, defaultSharedPreferences.getString("web_view_link_bit_15", ""));
                    break;
                case 27:
                    ru.himik.nightscream.kascada.CustomComponents.a0 a0Var = (ru.himik.nightscream.kascada.CustomComponents.a0) this.f9204i;
                    a0Var.d(0, defaultSharedPreferences.getString("voice_rec_text_bit_0", ""));
                    a0Var.d(1, defaultSharedPreferences.getString("voice_rec_text_bit_1", ""));
                    a0Var.d(2, defaultSharedPreferences.getString("voice_rec_text_bit_2", ""));
                    a0Var.d(3, defaultSharedPreferences.getString("voice_rec_text_bit_3", ""));
                    a0Var.d(4, defaultSharedPreferences.getString("voice_rec_text_bit_4", ""));
                    a0Var.d(5, defaultSharedPreferences.getString("voice_rec_text_bit_5", ""));
                    a0Var.d(6, defaultSharedPreferences.getString("voice_rec_text_bit_6", ""));
                    a0Var.d(7, defaultSharedPreferences.getString("voice_rec_text_bit_7", ""));
                    a0Var.d(8, defaultSharedPreferences.getString("voice_rec_text_bit_8", ""));
                    a0Var.d(9, defaultSharedPreferences.getString("voice_rec_text_bit_9", ""));
                    a0Var.d(10, defaultSharedPreferences.getString("voice_rec_text_bit_10", ""));
                    a0Var.d(11, defaultSharedPreferences.getString("voice_rec_text_bit_11", ""));
                    a0Var.d(12, defaultSharedPreferences.getString("voice_rec_text_bit_12", ""));
                    a0Var.d(13, defaultSharedPreferences.getString("voice_rec_text_bit_13", ""));
                    a0Var.d(14, defaultSharedPreferences.getString("voice_rec_text_bit_14", ""));
                    a0Var.d(15, defaultSharedPreferences.getString("voice_rec_text_bit_15", ""));
                    break;
                case 28:
                    ru.himik.nightscream.kascada.CustomComponents.j jVar = (ru.himik.nightscream.kascada.CustomComponents.j) this.f9204i;
                    jVar.setEmailLogin(defaultSharedPreferences.getString("email_login", ""));
                    jVar.setEmailPassword(defaultSharedPreferences.getString("email_password", ""));
                    jVar.setEmailTo(defaultSharedPreferences.getString("email_to", ""));
                    jVar.setTitle(defaultSharedPreferences.getString("email_title", ""));
                    jVar.setBody(defaultSharedPreferences.getString("email_body", ""));
                    break;
            }
        }
        if (i2 == 2) {
            if (intent == null) {
                return;
            } else {
                MyApplication.b().f9036d = intent.getExtras().getParcelableArrayList("serverList");
            }
        }
        if (i2 == 3) {
            SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
            int iC = this.f9205j.c();
            if (iC != 1) {
                switch (iC) {
                    case 4:
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.u) this.f9204i).f8903k;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 5:
                        ru.himik.nightscream.kascada.CustomComponents.q qVar = (ru.himik.nightscream.kascada.CustomComponents.q) this.f9204i;
                        qVar.f8865g.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = qVar.f8865g;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 6:
                        ru.himik.nightscream.kascada.CustomComponents.e eVar2 = (ru.himik.nightscream.kascada.CustomComponents.e) this.f9204i;
                        eVar2.f8769i.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = eVar2.f8769i;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 7:
                        CustomDynText customDynText2 = (CustomDynText) this.f9204i;
                        customDynText2.f8667i.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = customDynText2.f8667i;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 8:
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.i) this.f9204i).f8813j;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 9:
                        ru.himik.nightscream.kascada.CustomComponents.c cVar = (ru.himik.nightscream.kascada.CustomComponents.c) this.f9204i;
                        cVar.f8742h.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = cVar.f8742h;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 10:
                        ru.himik.nightscream.kascada.CustomComponents.w wVar2 = (ru.himik.nightscream.kascada.CustomComponents.w) this.f9204i;
                        wVar2.f8921g.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = wVar2.f8921g;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 11:
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.r) this.f9204i).f8874e;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 12:
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.g) this.f9204i).I;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 13:
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.v) this.f9204i).f8909f;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 14:
                        bVar2 = ((ru.himik.nightscream.kascada.CustomComponents.o) this.f9204i).T;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 15:
                        ru.himik.nightscream.kascada.CustomComponents.d dVar2 = (ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i;
                        dVar2.f8753h.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = dVar2.f8753h;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 16:
                        ru.himik.nightscream.kascada.CustomComponents.n nVar = (ru.himik.nightscream.kascada.CustomComponents.n) this.f9204i;
                        nVar.f8854g.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = nVar.f8854g;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 17:
                        ru.himik.nightscream.kascada.CustomComponents.h hVar2 = (ru.himik.nightscream.kascada.CustomComponents.h) this.f9204i;
                        hVar2.f8798e.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                        if (b2 < 16) {
                            bVar = hVar2.f8798e;
                            bVar.t(b2);
                        } else {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                        }
                        break;
                    case 18:
                        ru.himik.nightscream.kascada.CustomComponents.x xVar2 = (ru.himik.nightscream.kascada.CustomComponents.x) this.f9204i;
                        xVar2.f8932g.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        xVar2.setTypeCommand(Integer.parseInt(defaultSharedPreferences2.getString("SmsReceiveTypeCommand", "0")));
                        if (xVar2.getTypeCommand() == 1) {
                            b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                            if (b2 < 16) {
                                bVar = xVar2.f8932g;
                                bVar.t(b2);
                            } else {
                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                            }
                        }
                        break;
                    case 19:
                        ru.himik.nightscream.kascada.CustomComponents.k kVar2 = (ru.himik.nightscream.kascada.CustomComponents.k) this.f9204i;
                        bVar2 = kVar2.f8836k ? kVar2.f8832g : kVar2.f8833h;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 20:
                        bVar2 = ((CustomList) this.f9204i).f8687i;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                    case 21:
                        bVar2 = ((CustomSound) this.f9204i).f8696g;
                        bVar2.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                        break;
                }
            } else {
                ru.himik.nightscream.kascada.CustomComponents.y yVar = (ru.himik.nightscream.kascada.CustomComponents.y) this.f9204i;
                yVar.f8943g.v(Integer.parseInt(defaultSharedPreferences2.getString("address_register", "0")));
                b2 = (byte) Integer.parseInt(defaultSharedPreferences2.getString("address_bit", "0"));
                if (b2 < 16) {
                    bVar = yVar.f8943g;
                    bVar.t(b2);
                } else {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.you_entered_the_wrong_bit_address), 0).show();
                }
            }
        }
        if (i2 == 5 && i3 == -1) {
            ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(this.f9205j.d())).d(true, true, ru.himik.nightscream.kascada.Utils.q.f(this, intent.getData()));
        }
        if (i2 == 10 && i3 == -1) {
            ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(this.f9205j.d())).d(false, true, ru.himik.nightscream.kascada.Utils.q.f(this, intent.getData()));
        }
        if (i2 == 6) {
            if (intent == null) {
                return;
            }
            MyApplication.b().f9042j = intent.getExtras().getInt("COUNT_NETWORK_DEVICE");
            MyApplication.b().E = intent.getExtras().getParcelableArrayList("networkDevice");
            MyApplication.b().f9036d = intent.getExtras().getParcelableArrayList("serverList");
        }
        if (i2 == 9) {
            if (intent == null) {
                return;
            }
            MyApplication.b().f9042j = intent.getExtras().getInt("COUNT_NETWORK_DEVICE");
            MyApplication.b().E = intent.getExtras().getParcelableArrayList("networkDevice");
            MyApplication.b().f9036d = intent.getExtras().getParcelableArrayList("serverList");
        }
        if (i2 == 7 && i3 == -1) {
            if (intent == null) {
                return;
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.c) this.f9204i).setPosSound(intent.getExtras().getInt("POSITION"));
            }
        }
        if (i2 == 8 && i3 == -1 && intent != null) {
            MyApplication.b().f9043k = intent.getData().toString();
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.f9206k) {
            A();
            return;
        }
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.dialog_quit, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(this).create();
        j jVar = new j(alertDialogCreate);
        viewInflate.findViewById(R.id.exit_save_as).setOnClickListener(jVar);
        viewInflate.findViewById(R.id.exit_no_save).setOnClickListener(jVar);
        viewInflate.findViewById(R.id.exit_yes).setOnClickListener(jVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public void onClickGetCalculator(View view) {
        this.K.show(getFragmentManager(), "");
    }

    public void onClickGetInfo(View view) {
        if (this.f9206k) {
            FragmentManager fragmentManager = getFragmentManager();
            this.Q.a(MyApplication.b().f9040h, MyApplication.b().f9041i);
            this.Q.b(Uri.parse(MyApplication.b().f9043k));
            this.Q.show(fragmentManager, "");
            return;
        }
        androidx.appcompat.widget.l0 l0Var = new androidx.appcompat.widget.l0(this, view);
        l0Var.b(R.menu.popup_pdf_info);
        l0Var.d();
        l0Var.c(new o0());
    }

    public void onClickIcoCharging(View view) {
        Context applicationContext;
        Resources resources;
        int i2;
        if (c1) {
            applicationContext = getApplicationContext();
            resources = getResources();
            i2 = R.string.charging_connected;
        } else {
            applicationContext = getApplicationContext();
            resources = getResources();
            i2 = R.string.charging_disconnected;
        }
        Toast.makeText(applicationContext, resources.getString(i2), 0).show();
    }

    public void onClickSetNameScreen(View view) {
        if (this.f9206k) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.enter_new_name_screen));
        if (a1 == 0) {
            return;
        }
        EditText editText = new EditText(this);
        editText.setInputType(1);
        editText.setText(MyApplication.b().C.get(a1 - 1).d());
        editText.setSelection(editText.getText().length());
        builder.setView(editText);
        builder.setPositiveButton(getResources().getString(R.string.dialog_accept), new v0(editText));
        builder.setNegativeButton(getResources().getString(R.string.dialog_cancel), new w0(this));
        builder.show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onClickView(View view) {
        StringBuilder sb;
        this.f9204i = view;
        D();
        if (!this.f9206k) {
            ru.himik.nightscream.kascada.r.h0.l(this, (ru.himik.nightscream.kascada.CustomComponents.z) view);
        }
        if (this.f9206k) {
            int iC = this.f9205j.c();
            if (iC == 1) {
                ru.himik.nightscream.kascada.CustomComponents.y yVar = (ru.himik.nightscream.kascada.CustomComponents.y) view;
                if (yVar.f8943g.l() == 100) {
                    ru.himik.nightscream.kascada.CustomComponents.b bVar = yVar.f8943g;
                    bVar.J(!bVar.s());
                    yVar.setState(yVar.f8943g.s());
                    MyApplication.b().v0.e(yVar.f8943g);
                    return;
                }
                if (yVar.f8943g.k() != -1) {
                    ru.himik.nightscream.kascada.CustomComponents.b bVar2 = yVar.f8943g;
                    bVar2.J(!bVar2.s());
                    Y0.get(yVar.f8943g.k()).e(yVar.f8943g);
                    ru.himik.nightscream.kascada.CustomComponents.b bVar3 = new ru.himik.nightscream.kascada.CustomComponents.b(yVar.getIdComponent(), (byte) MyApplication.b().E.get(yVar.f8943g.l()).a(), yVar.f8943g.c(), yVar.f8943g.a(), (byte) 1, yVar.f8943g.j());
                    bVar3.F(yVar.f8943g.r());
                    bVar3.x(this.o.c(bVar3, yVar.f8943g.i()));
                    Y0.get(yVar.f8943g.k()).c(bVar3);
                } else {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.toast_no_connection), 1).show();
                }
                z0();
                return;
            }
            if (iC == 8) {
                ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) this.f9204i;
                if (iVar.f8813j.k() == -1 && iVar.f8813j.l() != 100) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.toast_no_connection), 1).show();
                    return;
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getResources().getString(R.string.dialog_enter_new_value));
                TextView textView = new TextView(this);
                if (iVar.getType() == 0) {
                    sb = new StringBuilder();
                    sb.append(getResources().getString(R.string.dialog_range));
                    sb.append(": ");
                    sb.append((int) iVar.getMinValue());
                    sb.append(" - ");
                    sb.append((int) iVar.getMaxValue());
                } else {
                    sb = new StringBuilder();
                    sb.append(getResources().getString(R.string.dialog_range));
                    sb.append(": ");
                    sb.append(iVar.getMinValue());
                    sb.append(" - ");
                    sb.append(iVar.getMaxValue());
                }
                textView.setText(sb.toString());
                textView.setTextColor(-16777216);
                EditText editText = new EditText(this);
                editText.setInputType(iVar.getType() == 0 ? 4098 : 12290);
                editText.setText(iVar.getCustomText());
                editText.setSelection(editText.getText().length());
                editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15)});
                editText.setImeOptions(6);
                editText.setFocusable(true);
                editText.setFocusableInTouchMode(true);
                editText.addTextChangedListener(new l(this, iVar, editText));
                TextView textView2 = new TextView(this);
                textView2.setText(getResources().getString(R.string.dialog_enter_password));
                textView2.setTextColor(-16777216);
                EditText editText2 = new EditText(this);
                editText2.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
                editText2.setImeOptions(6);
                editText2.setFocusable(true);
                editText2.setFocusableInTouchMode(true);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                layoutParams.weight = 1.0f;
                layoutParams.gravity = 17;
                textView.setLayoutParams(layoutParams);
                textView2.setLayoutParams(layoutParams);
                LinearLayout linearLayout = new LinearLayout(this);
                linearLayout.setOrientation(1);
                if (iVar.getPassword().length() > 0) {
                    linearLayout.addView(textView2);
                    linearLayout.addView(editText2);
                }
                linearLayout.addView(textView);
                linearLayout.addView(editText);
                builder.setView(linearLayout);
                builder.setPositiveButton(getResources().getString(R.string.dialog_set_value), new m(iVar, editText, editText2));
                builder.setNegativeButton(getApplicationContext().getResources().getString(R.string.dialog_cancel), new n(this));
                AlertDialog alertDialogCreate = builder.create();
                alertDialogCreate.show();
                alertDialogCreate.getWindow().setSoftInputMode(5);
                editText.requestFocus();
                editText.setOnEditorActionListener(new o(iVar, editText, editText2, alertDialogCreate));
                return;
            }
            if (iC == 15) {
                ru.himik.nightscream.kascada.r.h0.l(this, (ru.himik.nightscream.kascada.CustomComponents.z) view);
                return;
            }
            if (iC == 20) {
                CustomList customList = (CustomList) this.f9204i;
                if (!customList.j()) {
                    View viewInflate = LayoutInflater.from(this).inflate(R.layout.menu_list, (ViewGroup) null);
                    AlertDialog alertDialogCreate2 = new AlertDialog.Builder(this).create();
                    alertDialogCreate2.setTitle(getResources().getString(R.string.set_text));
                    ((TextView) viewInflate.findViewById(R.id.textBit0)).setText(customList.h(0));
                    ((TextView) viewInflate.findViewById(R.id.textBit1)).setText(customList.h(1));
                    ((TextView) viewInflate.findViewById(R.id.textBit2)).setText(customList.h(2));
                    ((TextView) viewInflate.findViewById(R.id.textBit3)).setText(customList.h(3));
                    ((TextView) viewInflate.findViewById(R.id.textBit4)).setText(customList.h(4));
                    ((TextView) viewInflate.findViewById(R.id.textBit5)).setText(customList.h(5));
                    ((TextView) viewInflate.findViewById(R.id.textBit6)).setText(customList.h(6));
                    ((TextView) viewInflate.findViewById(R.id.textBit7)).setText(customList.h(7));
                    ((TextView) viewInflate.findViewById(R.id.textBit8)).setText(customList.h(8));
                    ((TextView) viewInflate.findViewById(R.id.textBit9)).setText(customList.h(9));
                    ((TextView) viewInflate.findViewById(R.id.textBit10)).setText(customList.h(10));
                    ((TextView) viewInflate.findViewById(R.id.textBit11)).setText(customList.h(11));
                    ((TextView) viewInflate.findViewById(R.id.textBit12)).setText(customList.h(12));
                    ((TextView) viewInflate.findViewById(R.id.textBit13)).setText(customList.h(13));
                    ((TextView) viewInflate.findViewById(R.id.textBit14)).setText(customList.h(14));
                    ((TextView) viewInflate.findViewById(R.id.textBit15)).setText(customList.h(15));
                    RelativeLayout relativeLayout = (RelativeLayout) viewInflate.findViewById(R.id.bit0);
                    RelativeLayout relativeLayout2 = (RelativeLayout) viewInflate.findViewById(R.id.bit1);
                    RelativeLayout relativeLayout3 = (RelativeLayout) viewInflate.findViewById(R.id.bit2);
                    RelativeLayout relativeLayout4 = (RelativeLayout) viewInflate.findViewById(R.id.bit3);
                    RelativeLayout relativeLayout5 = (RelativeLayout) viewInflate.findViewById(R.id.bit4);
                    RelativeLayout relativeLayout6 = (RelativeLayout) viewInflate.findViewById(R.id.bit5);
                    RelativeLayout relativeLayout7 = (RelativeLayout) viewInflate.findViewById(R.id.bit6);
                    RelativeLayout relativeLayout8 = (RelativeLayout) viewInflate.findViewById(R.id.bit7);
                    RelativeLayout relativeLayout9 = (RelativeLayout) viewInflate.findViewById(R.id.bit8);
                    RelativeLayout relativeLayout10 = (RelativeLayout) viewInflate.findViewById(R.id.bit9);
                    RelativeLayout relativeLayout11 = (RelativeLayout) viewInflate.findViewById(R.id.bit10);
                    RelativeLayout relativeLayout12 = (RelativeLayout) viewInflate.findViewById(R.id.bit11);
                    RelativeLayout relativeLayout13 = (RelativeLayout) viewInflate.findViewById(R.id.bit12);
                    RelativeLayout relativeLayout14 = (RelativeLayout) viewInflate.findViewById(R.id.bit13);
                    RelativeLayout relativeLayout15 = (RelativeLayout) viewInflate.findViewById(R.id.bit14);
                    RelativeLayout relativeLayout16 = (RelativeLayout) viewInflate.findViewById(R.id.bit15);
                    TextView textView3 = (TextView) viewInflate.findViewById(R.id.listValue);
                    textView3.setText(customList.getValue() + "");
                    Button button = (Button) viewInflate.findViewById(R.id.listSend);
                    Button button2 = (Button) viewInflate.findViewById(R.id.listCancel);
                    p pVar = new p(customList, relativeLayout, relativeLayout2, relativeLayout3, relativeLayout4, relativeLayout5, relativeLayout6, relativeLayout7, relativeLayout8, relativeLayout9, relativeLayout10, relativeLayout11, relativeLayout12, relativeLayout13, relativeLayout14, relativeLayout15, relativeLayout16, textView3);
                    relativeLayout.setOnClickListener(pVar);
                    if (customList.g(0)) {
                        relativeLayout.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout2.setOnClickListener(pVar);
                    if (customList.g(1)) {
                        relativeLayout2.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout3.setOnClickListener(pVar);
                    if (customList.g(2)) {
                        relativeLayout3.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout4.setOnClickListener(pVar);
                    if (customList.g(3)) {
                        relativeLayout4.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout5.setOnClickListener(pVar);
                    if (customList.g(4)) {
                        relativeLayout5.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout6.setOnClickListener(pVar);
                    if (customList.g(5)) {
                        relativeLayout6.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout7.setOnClickListener(pVar);
                    if (customList.g(6)) {
                        relativeLayout7.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout8.setOnClickListener(pVar);
                    if (customList.g(7)) {
                        relativeLayout8.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout9.setOnClickListener(pVar);
                    if (customList.g(8)) {
                        relativeLayout9.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout10.setOnClickListener(pVar);
                    if (customList.g(9)) {
                        relativeLayout10.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout11.setOnClickListener(pVar);
                    if (customList.g(10)) {
                        relativeLayout11.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout12.setOnClickListener(pVar);
                    if (customList.g(11)) {
                        relativeLayout12.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout13.setOnClickListener(pVar);
                    if (customList.g(12)) {
                        relativeLayout13.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout14.setOnClickListener(pVar);
                    if (customList.g(13)) {
                        relativeLayout14.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout15.setOnClickListener(pVar);
                    if (customList.g(14)) {
                        relativeLayout15.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    relativeLayout16.setOnClickListener(pVar);
                    if (customList.g(15)) {
                        relativeLayout16.setBackgroundColor(Color.parseColor("#005005"));
                    }
                    button.setOnClickListener(pVar);
                    button2.setOnClickListener(pVar);
                    alertDialogCreate2.setView(viewInflate);
                    alertDialogCreate2.show();
                    return;
                }
                if (customList.f8687i.l() == 100) {
                    customList.f8687i.H(customList.getValueCheckNoChange());
                    MyApplication.b().v0.e(customList.f8687i);
                } else if (customList.f8687i.l() != -1) {
                    customList.f8687i.H(customList.getValueCheckNoChange());
                    Y0.get(customList.f8687i.k()).e(customList.f8687i);
                } else {
                    Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.toast_no_connection), 1).show();
                }
            }
        }
    }

    public void onClickWorkToolbar(View view) {
        if (this.f9206k) {
            A();
        } else {
            h(false);
            w0();
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_work_portrait);
        X0 = (RelativeLayout) findViewById(R.id.mainWorkLayout);
        this.m0 = (RelativeLayout) findViewById(R.id.layoutProgress);
        ImageView imageView = (ImageView) findViewById(R.id.menu_app_bar_show);
        this.a0 = imageView;
        imageView.setOnClickListener(this.s0);
        findViewById(R.id.menu_app_bar_hide).setOnClickListener(this.s0);
        ImageView imageView2 = (ImageView) findViewById(R.id.menu_bar_component);
        this.b0 = imageView2;
        imageView2.setOnClickListener(this.r0);
        ImageView imageView3 = (ImageView) findViewById(R.id.menu_appbar_right);
        this.c0 = imageView3;
        imageView3.setOnClickListener(this.q0);
        this.f9207l = (RelativeLayout) findViewById(R.id.toolbar);
        this.f9208m = (ImageView) findViewById(R.id.workToolbar);
        this.f9209n = (ImageView) findViewById(R.id.ico_charging);
        ru.himik.nightscream.kascada.Logic.a aVar = new ru.himik.nightscream.kascada.Logic.a(this);
        f1 = aVar;
        X0.addView(aVar);
        f1.setFbCollection(MyApplication.b().D);
        this.O = (TextView) findViewById(R.id.nowTime);
        ImageView imageView4 = (ImageView) findViewById(R.id.basket);
        this.f9201f = imageView4;
        imageView4.setOnDragListener(this.Q0);
        this.a = (FrameLayout) findViewById(R.id.frameLayout);
        this.W = (LinearLayout) findViewById(R.id.layoutSelectAction);
        X0.setOnDragListener(this.P0);
        ImageView imageView5 = (ImageView) findViewById(R.id.resize_top_left);
        this.b = imageView5;
        imageView5.setVisibility(4);
        ImageView imageView6 = (ImageView) findViewById(R.id.resize_top_right);
        this.c = imageView6;
        imageView6.setVisibility(4);
        ImageView imageView7 = (ImageView) findViewById(R.id.resize_bottom_left);
        this.f9199d = imageView7;
        imageView7.setVisibility(4);
        ImageView imageView8 = (ImageView) findViewById(R.id.resize_bottom_right);
        this.f9200e = imageView8;
        imageView8.setVisibility(4);
        this.b.setOnTouchListener(this.D0);
        this.c.setOnTouchListener(this.D0);
        this.f9199d.setOnTouchListener(this.D0);
        this.f9200e.setOnTouchListener(this.D0);
        X0.setOnTouchListener(this.D0);
        n.a.f.d dVar = new n.a.f.d();
        n.a.g.d dVar2 = new n.a.g.d();
        n.a.e.g gVar = new n.a.e.g(dVar, dVar2);
        gVar.N("HH:mm:ss  dd-MM");
        ru.himik.nightscream.kascada.CustomComponents.p pVar = new ru.himik.nightscream.kascada.CustomComponents.p(getApplicationContext(), gVar);
        this.L = pVar;
        pVar.F = dVar;
        pVar.G = dVar2;
        X0.addView(pVar);
        this.L.m(1, 1, 1, true);
        this.L.setVisibility(4);
        MyApplication.b().v0.X(c1);
        MyApplication.b().v0.Q(a1);
        MyApplication.b().v0.S(this.J);
        Intent intent = getIntent();
        this.f9203h = new ru.himik.nightscream.kascada.Bd.e(this);
        MyApplication.b().m0 = intent.getStringExtra("PROJECT_NAME");
        MyApplication.b().l0 = intent.getStringExtra("TABLE_NAME");
        Z0 = intent.getBooleanExtra("STATION_MODE", true);
        MyApplication.b().f9042j = intent.getIntExtra("COUNT_DEVICE", 16);
        MyApplication.b().i0 = intent.getBooleanExtra("PORTRAIT_MODE", false);
        G();
        MyApplication.b().j0 = "pro_" + MyApplication.b().l0 + "_connections";
        MyApplication.b().k0 = "pro_" + MyApplication.b().l0 + "_component";
        if (intent.getBooleanExtra("LOADING", false)) {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.project) + " " + MyApplication.b().m0 + " " + getResources().getString(R.string.loaded_from_bd), 0).show();
            g();
            this.h0 = true;
        } else {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.project) + " " + MyApplication.b().m0 + " " + getResources().getString(R.string.project_created), 0).show();
            x();
            for (int i2 = 0; i2 < b1; i2++) {
                MyApplication.b().C.add(new x0(Boolean.FALSE, "", 15592941, "", getResources().getString(R.string.screen)));
            }
        }
        if (MyApplication.b().i0) {
            setRequestedOrientation(1);
        }
        this.l0 = getSupportFragmentManager().a();
        this.d0 = new ru.himik.nightscream.kascada.t.b();
        this.e0 = new ru.himik.nightscream.kascada.t.c();
        this.f0 = new ru.himik.nightscream.kascada.t.d.b();
        this.l0.b(R.id.frameLayout, this.d0);
        this.l0.e();
        this.f9205j = new ru.himik.nightscream.kascada.CustomComponents.a();
        this.F = new IntentFilter("android.intent.action.BATTERY_CHANGED");
        IntentFilter intentFilter = new IntentFilter();
        this.G = intentFilter;
        intentFilter.addAction("SMS_RECEIVED_ACTION");
        this.G.setPriority(999);
        this.C = new a();
        u0();
        this.K = new ru.himik.nightscream.kascada.p();
        d1 = new ru.himik.nightscream.kascada.a0(this);
        this.Q = new ru.himik.nightscream.kascada.v();
        this.R = new ru.himik.nightscream.kascada.c0.a(8080, this, this.C);
        ru.himik.nightscream.kascada.z zVar = new ru.himik.nightscream.kascada.z(this);
        this.U = zVar;
        zVar.setBackgroundDrawable(getResources().getDrawable(R.drawable.select_rect));
        X0.addView(this.U);
        this.U.setVisibility(4);
        this.U.setOnLongClickListener(this.L0);
        if (Build.VERSION.SDK_INT >= 21) {
            this.U.setElevation(102.0f);
        }
        n0(1);
        MyApplication.b().v0.P(this.C);
        MyApplication.b().w0.a(this.C);
        Cursor cursorQuery = this.f9203h.getWritableDatabase().query("Settings", null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            String string = cursorQuery.getString(cursorQuery.getColumnIndex(ru.himik.nightscream.kascada.Utils.q.b(getResources().getString(R.string.v9), getApplicationContext())));
            if (string.length() > 0) {
                MyApplication.b().f9044l = string;
                YandexMetrica.putErrorEnvironmentValue("key", MyApplication.b().f9044l);
            }
        }
        this.p0 = new v(this);
        y0();
        z0();
        findViewById(R.id.calc).setOnLongClickListener(new View.OnLongClickListener() { // from class: ru.himik.nightscream.kascada.k
            @Override // android.view.View.OnLongClickListener
            public final boolean onLongClick(View view) {
                return this.a.L(view);
            }
        });
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, android.app.Activity
    protected void onDestroy() {
        ru.himik.nightscream.kascada.b0.d.a.y();
        i.b.l.a aVar = this.n0;
        if (aVar != null) {
            aVar.i();
        }
        ru.himik.nightscream.kascada.Connections.Cloud.b bVar = this.g0;
        if (bVar != null) {
            bVar.a();
        }
        d1.b();
        Timer timer = this.E;
        if (timer != null) {
            timer.cancel();
            this.E = null;
        }
        this.R.w();
        super.onDestroy();
    }

    @org.greenrobot.eventbus.m(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(ru.himik.nightscream.kascada.Utils.p pVar) {
        int i2;
        String strA = pVar.a();
        strA.hashCode();
        switch (strA) {
            case "SAVE_ERROR":
                i2 = R.string.save_error;
                break;
            case "SAVE_FINISH_CLOSE_ACTIVITY":
                finish();
                return;
            case "SAVE_FINISH":
                i2 = R.string.project_saved;
                break;
            case "UPDATE_LINE_LOGIC":
                f1.invalidate();
                return;
            default:
                return;
        }
        Toast.makeText(this, getString(i2), 0).show();
    }

    @org.greenrobot.eventbus.m(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(ru.himik.nightscream.kascada.q.f.a.g gVar) {
        this.C.obtainMessage(gVar.getEvent(), gVar.getId(), gVar.getKey(), gVar.getObj()).sendToTarget();
    }

    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onPause() {
        try {
            unregisterReceiver(this.p0);
        } catch (Exception unused) {
        }
        if (!MyApplication.b().f9046n || !MyApplication.b().n0.booleanValue()) {
            MyApplication.b().a.d(new ru.himik.nightscream.kascada.Utils.m(7));
            SQLiteDatabase writableDatabase = this.f9203h.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("work", Boolean.valueOf(this.f9206k));
            writableDatabase.update("TableNameProject", contentValues, "name = ?", new String[]{MyApplication.b().m0});
            this.f9206k = false;
            MyApplication.b().i();
        }
        super.onPause();
    }

    @Override // android.app.Activity
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        Z0 = bundle.getBoolean("stationMode");
    }

    @Override // androidx.fragment.app.d, android.app.Activity
    protected void onResume() {
        MyApplication.b().e();
        this.W.animate().translationY(200.0f);
        if (this.E == null) {
            u0();
        }
        try {
            Cursor cursorRawQuery = this.f9203h.getWritableDatabase().rawQuery("SELECT work FROM TableNameProject WHERE _id=" + MyApplication.b().l0, null);
            cursorRawQuery.moveToFirst();
            if (cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("work")) == 1) {
                v0(true);
            }
        } catch (Exception e2) {
            YandexMetrica.reportError("Загрузка work флага в onResume", e2);
            v0(true);
        }
        registerReceiver(this.p0, this.o0);
        registerReceiver(this.u0, this.G);
        if (this.h0) {
            this.h0 = false;
            v0(true);
        }
        this.i0 = false;
        this.j0 = false;
        super.onResume();
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putBoolean("stationMode", Z0);
        bundle.putBoolean("work", this.f9206k);
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, android.app.Activity
    protected void onStart() {
        super.onStart();
        x0(true);
        this.b0.bringToFront();
        System.currentTimeMillis();
        org.greenrobot.eventbus.c.c().o(this);
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, android.app.Activity
    protected void onStop() {
        Timer timer = this.E;
        if (timer != null) {
            timer.cancel();
            this.E = null;
        }
        try {
            unregisterReceiver(this.u0);
        } catch (Exception unused) {
        }
        org.greenrobot.eventbus.c.c().q(this);
        super.onStop();
    }

    public void openDialogAlignComponents(View view) {
        ru.himik.nightscream.kascada.r.h0.n(this);
    }

    public void p(FB_MACRO fb_macro) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < MyApplication.b().D.size(); i2++) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = MyApplication.b().D.get(MyApplication.b().D.keyAt(i2));
            if (aVar.getTypeFb() == 135 && fb_macro.getName().equals(aVar.getName())) {
                FB_MACRO fb_macro2 = (FB_MACRO) aVar;
                if (fb_macro.c != fb_macro2.c) {
                    arrayList.add(fb_macro2);
                }
            }
        }
        if (arrayList.size() > 0) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                w(fb_macro, (FB_MACRO) it.next(), false);
            }
        }
        arrayList.clear();
        try {
            fb_macro.v(MyApplication.b().D, MyApplication.b().m0);
        } catch (Exception unused) {
            Toast.makeText(this, "Ошибка при сохранении в файл макроса", 0).show();
        }
    }

    public void p0() {
        x0(true);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(17);
        TextView textView = new TextView(this);
        textView.setText(getResources().getString(R.string.choose_channel));
        CheckBox checkBox = new CheckBox(this);
        checkBox.setText("1");
        checkBox.setChecked(true);
        CheckBox checkBox2 = new CheckBox(this);
        checkBox2.setText("2");
        checkBox2.setChecked(true);
        CheckBox checkBox3 = new CheckBox(this);
        checkBox3.setText("3");
        checkBox3.setChecked(true);
        CheckBox checkBox4 = new CheckBox(this);
        checkBox4.setText("4");
        checkBox4.setChecked(true);
        linearLayout.addView(textView);
        linearLayout.addView(checkBox);
        linearLayout.addView(checkBox2);
        linearLayout.addView(checkBox3);
        linearLayout.addView(checkBox4);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(17);
        TextView textView2 = new TextView(this);
        textView2.setText("-");
        TextView textView3 = new TextView(this);
        textView3.setText("-");
        TextView textView4 = new TextView(this);
        textView4.setText(getResources().getString(R.string.choose_date));
        EditText editText = new EditText(this);
        editText.setInputType(2);
        editText.setText(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getLastDay());
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2)});
        EditText editText2 = new EditText(this);
        editText2.setInputType(2);
        editText2.setText(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getLastMonth());
        editText2.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2)});
        EditText editText3 = new EditText(this);
        editText3.setInputType(2);
        editText3.setText(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getLastYear());
        editText3.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        linearLayout2.addView(textView4);
        linearLayout2.addView(editText);
        linearLayout2.addView(textView2);
        linearLayout2.addView(editText2);
        linearLayout2.addView(textView3);
        linearLayout2.addView(editText3);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(17);
        TextView textView5 = new TextView(this);
        textView5.setText(":");
        TextView textView6 = new TextView(this);
        textView6.setText(":");
        TextView textView7 = new TextView(this);
        textView7.setText(getResources().getString(R.string.choose_time));
        EditText editText4 = new EditText(this);
        editText4.setInputType(2);
        editText4.setText(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getLastHour());
        editText4.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2)});
        EditText editText5 = new EditText(this);
        editText5.setInputType(2);
        editText5.setText(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getLastMin());
        editText5.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2)});
        EditText editText6 = new EditText(this);
        editText6.setInputType(2);
        editText6.setText(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getLastSek());
        editText6.setFilters(new InputFilter[]{new InputFilter.LengthFilter(2)});
        linearLayout3.addView(textView7);
        linearLayout3.addView(editText4);
        linearLayout3.addView(textView5);
        linearLayout3.addView(editText5);
        linearLayout3.addView(textView6);
        linearLayout3.addView(editText6);
        LinearLayout linearLayout4 = new LinearLayout(this);
        linearLayout4.setOrientation(1);
        linearLayout4.setGravity(17);
        linearLayout4.addView(linearLayout);
        linearLayout4.addView(linearLayout2);
        linearLayout4.addView(linearLayout3);
        long jQueryNumEntries = DatabaseUtils.queryNumEntries(((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getDb(), "Archive");
        String fileName = ((ru.himik.nightscream.kascada.CustomComponents.d) this.f9204i).getFileName();
        AlertDialog alertDialogCreate = new AlertDialog.Builder(this).setView(linearLayout4).setTitle(fileName + ". " + jQueryNumEntries + " " + getResources().getString(R.string.records)).setPositiveButton(android.R.string.ok, (DialogInterface.OnClickListener) null).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).create();
        alertDialogCreate.setOnShowListener(new c0(alertDialogCreate, editText, editText2, editText3, editText4, editText5, editText6, checkBox, checkBox2, checkBox3, checkBox4));
        alertDialogCreate.show();
    }

    public void q(boolean z2) {
        ImageView imageView;
        int i2;
        if (z2) {
            imageView = this.b;
            i2 = 0;
        } else {
            imageView = this.b;
            i2 = 4;
        }
        imageView.setVisibility(i2);
        this.c.setVisibility(i2);
        this.f9199d.setVisibility(i2);
        this.f9200e.setVisibility(i2);
    }

    public void q0() {
        new ru.himik.nightscream.kascada.r.g0().x1(getSupportFragmentManager(), "");
    }

    /* JADX WARN: Code duplicated, block: B:20:0x003b  */
    /* JADX WARN: Code duplicated, block: B:24:0x0043  */
    /* JADX WARN: Code duplicated, block: B:25:0x0046  */
    public void r(boolean z2) {
        int i2;
        int i3;
        Fragment fragment;
        androidx.fragment.app.n nVarA = getSupportFragmentManager().a();
        this.l0 = nVarA;
        if (a1 == -1) {
            fragment = this.e0;
        } else {
            if (z2) {
                int i4 = this.k0;
                if (i4 - 1 < 0) {
                    this.k0 = 2;
                } else {
                    i2 = i4 - 1;
                }
                i3 = this.k0;
                if (i3 != 0) {
                    fragment = this.d0;
                } else if (i3 == 1 && i3 == 2) {
                    fragment = this.f0;
                } else {
                    fragment = this.e0;
                }
            } else {
                int i5 = this.k0;
                i2 = i5 + 1 > 2 ? 0 : i5 + 1;
            }
            this.k0 = i2;
            i3 = this.k0;
            if (i3 != 0) {
                fragment = this.d0;
            } else if (i3 == 1) {
                fragment = this.e0;
            } else {
                fragment = this.e0;
            }
        }
        nVarA.i(R.id.frameLayout, fragment);
        this.l0.e();
    }

    void r0() {
        EditText editText = new EditText(this);
        new AlertDialog.Builder(this).setTitle(R.string.enter_license_code).setView(editText).setPositiveButton("OK", new q0(editText)).setNegativeButton(getResources().getString(R.string.dialog_cancel), (DialogInterface.OnClickListener) null).create().show();
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0026 A[PHI: r0
      0x0026: PHI (r0v3 int) = (r0v2 int), (r0v4 int) binds: [B:13:0x0023, B:6:0x0010] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:19:0x0033  */
    public void s(boolean z2) {
        int i2;
        q(false);
        int i3 = a1;
        int i4 = 1;
        if (this.f9206k) {
            if (z2) {
                i2 = i3 + 1;
                if (i2 <= MyApplication.b().o) {
                    i4 = i2;
                }
            } else if (i3 - 1 < 1) {
                i4 = MyApplication.b().o;
            } else {
                i4 = i3 - 1;
            }
        } else if (z2) {
            i2 = i3 + 1;
            if (i2 <= b1) {
                i4 = i2;
            }
        } else if (i3 - 1 < 1) {
            i4 = b1;
        } else {
            i4 = i3 - 1;
        }
        n0(i4);
    }

    public void s0(ru.himik.nightscream.kascada.Logic.c.a aVar) {
        ru.himik.nightscream.kascada.r.e0.o0(this, aVar);
        aVar.q();
    }

    public void selectActionCopy(View view) {
        this.Z = 2;
        this.X.clear();
        for (int i2 = 0; i2 < this.V.size(); i2++) {
            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = this.V;
            if (sparseArray.get(sparseArray.keyAt(i2)).p()) {
                if (this.X.size() == 0) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = this.X;
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray3 = this.V;
                    sparseArray2.append(0, sparseArray3.get(sparseArray3.keyAt(i2)));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray4 = this.X;
                    int iKeyAt = sparseArray4.keyAt(sparseArray4.size() - 1) + 1;
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray5 = this.V;
                    sparseArray4.append(iKeyAt, sparseArray5.get(sparseArray5.keyAt(i2)));
                }
            }
        }
        this.U.getLayoutParams().width = 0;
        this.U.getLayoutParams().height = 0;
        this.Y = true;
    }

    public void selectActionCut(View view) {
        this.Z = 1;
        this.X.clear();
        for (int i2 = 0; i2 < this.V.size(); i2++) {
            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = this.V;
            if (sparseArray.get(sparseArray.keyAt(i2)).p()) {
                if (this.X.size() == 0) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = this.X;
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray3 = this.V;
                    sparseArray2.append(0, sparseArray3.get(sparseArray3.keyAt(i2)));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray4 = this.X;
                    int iKeyAt = sparseArray4.keyAt(sparseArray4.size() - 1) + 1;
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray5 = this.V;
                    sparseArray4.append(iKeyAt, sparseArray5.get(sparseArray5.keyAt(i2)));
                }
                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray6 = this.V;
                if (sparseArray6.get(sparseArray6.keyAt(i2)) instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray7 = this.V;
                    ru.himik.nightscream.kascada.Logic.c.a aVar = (ru.himik.nightscream.kascada.Logic.c.a) sparseArray7.get(sparseArray7.keyAt(i2));
                    try {
                        aVar.setSaveIdBeforeCopy(aVar.getKey());
                        if (aVar.q() != null) {
                            aVar.setSaveIdOutBeforeCopy(aVar.q().getKey());
                            aVar.setSaveNumInBeforeCopy(aVar.getNumOnIn());
                        }
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
        this.U0.clear();
        for (int i3 = 0; i3 < this.X.size(); i3++) {
            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray8 = this.X;
            if (sparseArray8.get(sparseArray8.keyAt(i3)).getIdComponent() != 135) {
                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray9 = this.X;
                deleteView((View) sparseArray9.get(sparseArray9.keyAt(i3)));
            } else {
                ArrayList<FB_MACRO> arrayList = this.U0;
                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray10 = this.X;
                arrayList.add((FB_MACRO) sparseArray10.get(sparseArray10.keyAt(i3)));
                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray11 = this.X;
                ((FB_MACRO) sparseArray11.get(sparseArray11.keyAt(i3))).setVisibility(4);
            }
        }
        this.U.getLayoutParams().width = 0;
        this.U.getLayoutParams().height = 0;
        z0();
        this.Y = true;
    }

    /* JADX WARN: Code duplicated, block: B:107:0x03e5  */
    /* JADX WARN: Code duplicated, block: B:109:0x0409  */
    /* JADX WARN: Code duplicated, block: B:110:0x0413  */
    /* JADX WARN: Code duplicated, block: B:113:0x0422  */
    /* JADX WARN: Code duplicated, block: B:114:0x042c  */
    /* JADX WARN: Code duplicated, block: B:117:0x043f  */
    /* JADX WARN: Code duplicated, block: B:120:0x0460  */
    /* JADX WARN: Code duplicated, block: B:121:0x0469  */
    /* JADX WARN: Code duplicated, block: B:123:0x0475  */
    /* JADX WARN: Code duplicated, block: B:124:0x047a  */
    /* JADX WARN: Code duplicated, block: B:127:0x0483  */
    /* JADX WARN: Code duplicated, block: B:128:0x0488  */
    /* JADX WARN: Code duplicated, block: B:131:0x0497  */
    /* JADX WARN: Code duplicated, block: B:134:0x04b0  */
    /* JADX WARN: Code duplicated, block: B:172:0x04bc A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:173:0x04bc A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r15v3 */
    public void selectActionPaste(View view) {
        int i2;
        ?? r15;
        Context applicationContext;
        String string;
        float customY;
        int i3;
        boolean z2;
        SparseArray sparseArray = new SparseArray();
        for (int i4 = 0; i4 < this.V.size(); i4++) {
            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = this.V;
            sparseArray2.get(sparseArray2.keyAt(i4)).setCustomSelect(false);
        }
        float customX = 0.0f;
        if (this.Z == 1) {
            float customX2 = MyApplication.b().f9040h;
            float customY2 = MyApplication.b().f9041i;
            int i5 = 0;
            float customX3 = 0.0f;
            float customY3 = 0.0f;
            while (i5 < this.X.size()) {
                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray3 = this.X;
                ru.himik.nightscream.kascada.CustomComponents.z zVar = sparseArray3.get(sparseArray3.keyAt(i5));
                try {
                    int i6 = i5;
                    float f2 = customY2;
                    float f3 = customX2;
                    z2 = true;
                    try {
                        ru.himik.nightscream.kascada.CustomComponents.z zVarM = m(zVar.getIdComponent(), zVar.getCustomText(), zVar.getCustomWidth(), zVar.getCustomHeight(), e1 + ((int) zVar.getCustomX()), ((int) zVar.getCustomY()) + e1, (int) zVar.getTextSize(), zVar.getJsonConnectionInfo().toString(), zVar.getCurrentTextColor(), zVar.getCustomBackground(), zVar.getJsonOtherForCopy().toString());
                        zVarM.setCustomSelect(true);
                        if (zVarM instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                            ru.himik.nightscream.kascada.Logic.c.a aVar = (ru.himik.nightscream.kascada.Logic.c.a) zVarM;
                            ru.himik.nightscream.kascada.Logic.c.a aVar2 = (ru.himik.nightscream.kascada.Logic.c.a) zVar;
                            aVar.setRootNameMacro(aVar2.getRootNameMacro());
                            aVar.setRootUniqueIdMacro(aVar2.getRootUniqueIdMacro());
                            if (aVar.getTypeFb() == 135 && aVar2.getTypeFb() == 135) {
                                w((FB_MACRO) zVar, (FB_MACRO) zVarM, true);
                            }
                            sparseArray.append(sparseArray.size() == 0 ? 0 : sparseArray.keyAt(sparseArray.size() - 1) + 1, aVar);
                            aVar.setSaveIdBeforeCopy(aVar2.getSaveIdBeforeCopy());
                            aVar.setSaveIdOutBeforeCopy(aVar2.getSaveIdOutBeforeCopy());
                            aVar.setSaveNumInBeforeCopy(aVar2.getSaveNumInBeforeCopy());
                            if (aVar instanceof ru.himik.nightscream.kascada.Logic.e) {
                                ru.himik.nightscream.kascada.Logic.e eVar = (ru.himik.nightscream.kascada.Logic.e) zVar;
                                ((ru.himik.nightscream.kascada.Logic.e) zVarM).j(eVar.getReg(), eVar.getBit());
                            }
                        }
                        zVarM.setDiffX(zVar.getDiffX());
                        zVarM.setDiffY(zVar.getDiffY());
                        zVarM.setNumScreen(a1);
                        if (zVarM.getConnectionInfo() != null) {
                            zVarM.getConnectionInfo().v(0);
                            zVarM.getConnectionInfo().t((byte) 0);
                            zVarM.getConnectionInfo().u((byte) 0);
                            if (MyApplication.b().f9042j == 1 && zVarM.getConnectionInfo().l() == -1) {
                                zVarM.getConnectionInfo().E(0);
                            }
                        }
                        customX2 = zVar.getCustomX() + ((float) e1) < f3 ? zVar.getCustomX() + e1 : f3;
                        customY2 = zVar.getCustomY() + ((float) e1) < f2 ? zVar.getCustomY() + e1 : f2;
                        if (zVar.getCustomX() + e1 + zVar.getCustomWidth() > customX3) {
                            customX3 = zVar.getCustomX() + e1 + zVar.getCustomWidth();
                        }
                        if (zVar.getCustomY() + e1 + zVar.getCustomHeight() > customY3) {
                            customY3 = zVar.getCustomY() + e1 + zVar.getCustomHeight();
                        }
                        i5 = i6 + 1;
                    } catch (JSONException unused) {
                        applicationContext = getApplicationContext();
                        string = getResources().getString(R.string.error_copy_component);
                        i3 = z2;
                        Toast.makeText(applicationContext, string, i3).show();
                        return;
                    }
                } catch (JSONException unused2) {
                    z2 = true;
                }
            }
            float f4 = customY2;
            float f5 = customX2;
            i2 = 135;
            r15 = 1;
            for (int i7 = 0; i7 < sparseArray.size(); i7++) {
                ru.himik.nightscream.kascada.Logic.c.a aVar3 = (ru.himik.nightscream.kascada.Logic.c.a) sparseArray.get(sparseArray.keyAt(i7));
                if (aVar3.getSaveIdOutBeforeCopy() >= 0) {
                    for (int i8 = 0; i8 < sparseArray.size(); i8++) {
                        ru.himik.nightscream.kascada.Logic.c.a aVar4 = (ru.himik.nightscream.kascada.Logic.c.a) sparseArray.get(sparseArray.keyAt(i8));
                        if (aVar4.getSaveIdBeforeCopy() == aVar3.getSaveIdOutBeforeCopy()) {
                            aVar3.e(aVar4);
                            aVar3.setNumOnIn(aVar3.getSaveNumInBeforeCopy());
                            aVar4.d(aVar3, aVar3.getSaveNumInBeforeCopy());
                        }
                    }
                }
            }
            sparseArray.clear();
            z0();
            this.U.setX(f5);
            this.U.setY(f4);
            this.U.getLayoutParams().width = (int) (customX3 - f5);
            this.U.getLayoutParams().height = (int) (customY3 - f4);
            this.U.bringToFront();
            this.U.requestLayout();
            f1.invalidate();
            Iterator<FB_MACRO> it = this.U0.iterator();
            while (it.hasNext()) {
                deleteView(it.next());
            }
            this.U0.clear();
        } else {
            i2 = 135;
            r15 = 1;
        }
        if (this.Z == 2) {
            float customX4 = MyApplication.b().f9040h;
            float customY4 = MyApplication.b().f9041i;
            int i9 = 0;
            float customHeight = 0.0f;
            while (i9 < this.X.size()) {
                SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray4 = this.X;
                ru.himik.nightscream.kascada.CustomComponents.z zVar2 = sparseArray4.get(sparseArray4.keyAt(i9));
                try {
                    int i10 = i9;
                    float f6 = customY4;
                    float f7 = customX4;
                    ru.himik.nightscream.kascada.CustomComponents.z zVarM2 = m(zVar2.getIdComponent(), zVar2.getCustomText(), zVar2.getCustomWidth(), zVar2.getCustomHeight(), (int) zVar2.getCustomX(), (int) zVar2.getCustomY(), (int) zVar2.getTextSize(), zVar2.getJsonConnectionInfo().toString(), zVar2.getCurrentTextColor(), zVar2.getCustomBackground(), zVar2.getJsonOtherForCopy().toString());
                    zVarM2.setCustomSelect(r15);
                    zVarM2.setDiffX(zVar2.getDiffX());
                    zVarM2.setDiffY(zVar2.getDiffY());
                    zVarM2.setNumScreen(a1);
                    if (zVarM2 instanceof ru.himik.nightscream.kascada.Logic.c.a) {
                        ru.himik.nightscream.kascada.Logic.c.a aVar5 = (ru.himik.nightscream.kascada.Logic.c.a) zVarM2;
                        ru.himik.nightscream.kascada.Logic.c.a aVar6 = (ru.himik.nightscream.kascada.Logic.c.a) zVar2;
                        aVar5.setRootNameMacro(aVar6.getRootNameMacro());
                        aVar5.setRootUniqueIdMacro(aVar6.getRootUniqueIdMacro());
                        if (aVar5.getTypeFb() == i2 && aVar6.getTypeFb() == i2) {
                            w((FB_MACRO) zVar2, (FB_MACRO) zVarM2, r15);
                        }
                        sparseArray.append(sparseArray.size() == 0 ? 0 : sparseArray.keyAt(sparseArray.size() - r15) + r15, aVar5);
                        aVar5.setSaveIdBeforeCopy(aVar6.getKey());
                        if (aVar6.q() != null) {
                            aVar5.setSaveNumInBeforeCopy(aVar6.getNumOnIn());
                            aVar5.setSaveIdOutBeforeCopy(aVar6.q().getKey());
                        }
                        aVar5.setSaveKey(zVarM2.getKey());
                    }
                    if (zVarM2.getConnectionInfo() != null) {
                        zVarM2.getConnectionInfo().v(0);
                        zVarM2.getConnectionInfo().t((byte) 0);
                        zVarM2.getConnectionInfo().u((byte) 0);
                        if (MyApplication.b().f9042j == r15) {
                            if (zVarM2.getConnectionInfo().l() == -1) {
                                zVarM2.getConnectionInfo().E(0);
                            }
                        }
                        if (zVar2.getCustomNumScreen() == zVarM2.getCustomNumScreen()) {
                            zVarM2.setX(zVar2.getCustomX() + e1);
                            zVarM2.setY(zVar2.getCustomY() + e1);
                            if (zVar2.getCustomX() + e1 < f7) {
                                customX4 = zVar2.getCustomX() + e1;
                            } else {
                                customX4 = f7;
                            }
                            if (zVar2.getCustomY() + e1 < f6) {
                                customY4 = zVar2.getCustomY() + e1;
                            } else {
                                customY4 = f6;
                            }
                            if (zVar2.getCustomX() + e1 + zVar2.getCustomWidth() > customX) {
                                customX = zVar2.getCustomX() + e1 + zVar2.getCustomWidth();
                            }
                            if (zVar2.getCustomY() + e1 + zVar2.getCustomHeight() > customHeight) {
                                customY = zVar2.getCustomY() + e1;
                                customHeight = customY + zVar2.getCustomHeight();
                            }
                        } else {
                            if (zVar2.getCustomX() < f7) {
                                customX4 = zVar2.getCustomX();
                            } else {
                                customX4 = f7;
                            }
                            if (zVar2.getCustomY() < f6) {
                                customY4 = zVar2.getCustomY();
                            } else {
                                customY4 = f6;
                            }
                            if (zVar2.getCustomX() + zVar2.getCustomWidth() > customX) {
                                customX = zVar2.getCustomX() + zVar2.getCustomWidth();
                            }
                            if (zVar2.getCustomY() + zVar2.getCustomHeight() > customHeight) {
                                customY = zVar2.getCustomY();
                                customHeight = customY + zVar2.getCustomHeight();
                            }
                        }
                        i9 = i10 + 1;
                    }
                    if (zVar2.getCustomNumScreen() == zVarM2.getCustomNumScreen()) {
                        zVarM2.setX(zVar2.getCustomX() + e1);
                        zVarM2.setY(zVar2.getCustomY() + e1);
                        if (zVar2.getCustomX() + e1 < f7) {
                            customX4 = zVar2.getCustomX() + e1;
                        } else {
                            customX4 = f7;
                        }
                        if (zVar2.getCustomY() + e1 < f6) {
                            customY4 = zVar2.getCustomY() + e1;
                        } else {
                            customY4 = f6;
                        }
                        if (zVar2.getCustomX() + e1 + zVar2.getCustomWidth() > customX) {
                            customX = zVar2.getCustomX() + e1 + zVar2.getCustomWidth();
                        }
                        if (zVar2.getCustomY() + e1 + zVar2.getCustomHeight() > customHeight) {
                            customY = zVar2.getCustomY() + e1;
                            customHeight = customY + zVar2.getCustomHeight();
                        }
                    } else {
                        if (zVar2.getCustomX() < f7) {
                            customX4 = zVar2.getCustomX();
                        } else {
                            customX4 = f7;
                        }
                        if (zVar2.getCustomY() < f6) {
                            customY4 = zVar2.getCustomY();
                        } else {
                            customY4 = f6;
                        }
                        if (zVar2.getCustomX() + zVar2.getCustomWidth() > customX) {
                            customX = zVar2.getCustomX() + zVar2.getCustomWidth();
                        }
                        if (zVar2.getCustomY() + zVar2.getCustomHeight() > customHeight) {
                            customY = zVar2.getCustomY();
                            customHeight = customY + zVar2.getCustomHeight();
                        }
                    }
                    i9 = i10 + 1;
                } catch (Exception unused3) {
                    applicationContext = getApplicationContext();
                    string = getResources().getString(R.string.error_copy_component);
                    i3 = r15;
                    Toast.makeText(applicationContext, string, i3).show();
                    return;
                }
            }
            float f8 = customY4;
            float f9 = customX4;
            for (int i11 = 0; i11 < sparseArray.size(); i11++) {
                ru.himik.nightscream.kascada.Logic.c.a aVar7 = (ru.himik.nightscream.kascada.Logic.c.a) sparseArray.get(sparseArray.keyAt(i11));
                if (aVar7.getSaveIdOutBeforeCopy() >= 0) {
                    for (int i12 = 0; i12 < sparseArray.size(); i12++) {
                        ru.himik.nightscream.kascada.Logic.c.a aVar8 = (ru.himik.nightscream.kascada.Logic.c.a) sparseArray.get(sparseArray.keyAt(i12));
                        if (aVar8.getSaveIdBeforeCopy() == aVar7.getSaveIdOutBeforeCopy()) {
                            aVar7.e(aVar8);
                            aVar7.setKeyOut(aVar8.getKey());
                            aVar7.setNumOnIn(aVar7.getSaveNumInBeforeCopy());
                            aVar8.d(aVar7, aVar7.getSaveNumInBeforeCopy());
                        }
                    }
                }
            }
            sparseArray.clear();
            z0();
            this.U.setX(f9);
            this.U.setY(f8);
            this.U.getLayoutParams().width = (int) (customX - f9);
            this.U.getLayoutParams().height = (int) (customHeight - f8);
            this.U.bringToFront();
            this.U.requestLayout();
            f1.invalidate();
        }
    }

    public void t(ru.himik.nightscream.kascada.CustomComponents.i iVar, String str, String str2) {
        boolean z2 = iVar.f8813j.l() == 100;
        if ((iVar.getPassword().length() > 0) && !iVar.getPassword().equals(str2)) {
            Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.toast_cancel_wrong_password), 0).show();
            return;
        }
        if (str.length() <= 0) {
            Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.toast_cancel_empty_value), 0).show();
            return;
        }
        if (iVar.getType() == 0) {
            try {
                int i2 = (int) Float.parseFloat(str.toString());
                float f2 = i2;
                if (f2 > iVar.getMaxValue() || f2 < iVar.getMinValue()) {
                    Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.toast_cancel_new_value_error), 0).show();
                    return;
                }
                iVar.f8813j.H(i2);
                if (z2) {
                    MyApplication.b().v0.e(iVar.f8813j);
                    iVar.f(i2 + "");
                    return;
                }
                Y0.get(iVar.f8813j.k()).e(iVar.f8813j);
                ru.himik.nightscream.kascada.CustomComponents.b bVar = new ru.himik.nightscream.kascada.CustomComponents.b(iVar.getIdComponent(), (byte) MyApplication.b().E.get(iVar.f8813j.l()).a(), iVar.f8813j.c(), (byte) 0, (byte) 3, iVar.getKey());
                bVar.F(iVar.f8813j.r());
                bVar.x(this.o.c(bVar, iVar.f8813j.i()));
                Y0.get(iVar.f8813j.k()).c(bVar);
                return;
            } catch (Exception unused) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.toast_cancel_int_error), 0).show();
                return;
            }
        }
        try {
            float f3 = Float.parseFloat(str);
            if (f3 > iVar.getMaxValue() || f3 < iVar.getMinValue()) {
                Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.toast_cancel_new_value_error), 0).show();
                return;
            }
            if (z2) {
                ru.himik.nightscream.kascada.CustomComponents.b bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b();
                bVar2.C(iVar.getKey());
                bVar2.L((byte) 16);
                bVar2.K(1);
                bVar2.v(iVar.f8813j.c());
                bVar2.I(f3);
                bVar2.A(6);
                MyApplication.b().v0.e(bVar2);
                MyApplication.b().v0.e(iVar.getInitConnectionInfo());
                return;
            }
            ru.himik.nightscream.kascada.CustomComponents.b bVar3 = new ru.himik.nightscream.kascada.CustomComponents.b();
            bVar3.C(iVar.getKey());
            bVar3.L((byte) 16);
            bVar3.K(1);
            bVar3.v(iVar.f8813j.c());
            bVar3.I(f3);
            bVar3.A(8);
            bVar3.B(MyApplication.b().E.get(iVar.f8813j.l()).b());
            bVar3.F(MyApplication.b().E.get(iVar.f8813j.l()).g());
            bVar3.u((byte) MyApplication.b().E.get(iVar.f8813j.l()).a());
            Y0.get(iVar.f8813j.k()).e(bVar3);
            Y0.get(iVar.f8813j.k()).e(iVar.getInitConnectionInfo());
        } catch (Exception unused2) {
            Toast.makeText(getApplicationContext(), getApplicationContext().getResources().getString(R.string.toast_cancel_float_error), 0).show();
        }
    }

    void u0() {
        Timer timer = new Timer();
        this.E = timer;
        timer.schedule(new u0(), 100L, 5000L);
    }

    public void v(boolean z2) {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        Intent intent2 = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent2.setType("image/*");
        Intent intentCreateChooser = Intent.createChooser(intent, getResources().getString(R.string.choose_image));
        intentCreateChooser.putExtra("android.intent.extra.INITIAL_INTENTS", new Intent[]{intent2});
        startActivityForResult(intentCreateChooser, z2 ? 5 : 10);
    }

    void v0(boolean z2) {
        if (!this.f9206k && E() > n1) {
            if (ru.himik.nightscream.kascada.Utils.l.a.f()) {
                C0(z2);
            } else {
                t0();
            }
        }
    }

    void w(FB_MACRO fb_macro, FB_MACRO fb_macro2, boolean z2) {
        int i2;
        y(fb_macro2.getName(), fb_macro2.c);
        ArrayList arrayList = new ArrayList();
        for (int i3 = 0; i3 < MyApplication.b().D.size(); i3++) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = MyApplication.b().D.get(MyApplication.b().D.keyAt(i3));
            if (aVar.getRootUniqueIdMacro() == fb_macro.c && ((aVar.getTypeFb() != 133 || !((VarNameIn) aVar).t()) && (aVar.getTypeFb() != 134 || !((VarNameOut) aVar).t()))) {
                arrayList.add((ru.himik.nightscream.kascada.CustomComponents.z) aVar);
            }
        }
        ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ru.himik.nightscream.kascada.CustomComponents.z zVar = (ru.himik.nightscream.kascada.CustomComponents.z) it.next();
            try {
                Iterator it2 = it;
                i2 = 1;
                try {
                    ru.himik.nightscream.kascada.CustomComponents.z zVarM = m(zVar.getIdComponent(), zVar.getCustomText(), zVar.getCustomWidth(), zVar.getCustomHeight(), (int) zVar.getCustomX(), (int) zVar.getCustomY(), (int) zVar.getTextSize(), zVar.getJsonConnectionInfo().toString(), zVar.getCurrentTextColor(), zVar.getCustomBackground(), zVar.getJsonOtherForCopy().toString());
                    ((ru.himik.nightscream.kascada.Logic.c.a) zVarM).setRootNameMacro(fb_macro2.getName());
                    ((ru.himik.nightscream.kascada.Logic.c.a) zVarM).setRootUniqueIdMacro(fb_macro2.c);
                    zVarM.setNumScreen(-1);
                    zVarM.setCustomVisible(4);
                    ru.himik.nightscream.kascada.Logic.c.a aVar2 = (ru.himik.nightscream.kascada.Logic.c.a) zVarM;
                    arrayList2.add(aVar2);
                    ru.himik.nightscream.kascada.Logic.c.a aVar3 = (ru.himik.nightscream.kascada.Logic.c.a) zVar;
                    aVar2.setSaveIdBeforeCopy(aVar3.getKey());
                    if (aVar3.q() != null) {
                        aVar2.setSaveNumInBeforeCopy(aVar3.getNumOnIn());
                        aVar2.setSaveIdOutBeforeCopy(aVar3.q().getKey());
                    }
                    it = it2;
                } catch (Exception unused) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_copy_component), i2).show();
                    return;
                }
            } catch (Exception unused2) {
                i2 = 1;
            }
        }
        fb_macro2.t(fb_macro.getCountIn(), true);
        if (fb_macro.E.a.q() != null) {
            fb_macro2.E.a.setSaveIdOutBeforeCopy(fb_macro.E.a.q().getKey());
            fb_macro2.E.a.setSaveNumInBeforeCopy(fb_macro.E.a.getNumOnIn());
        }
        if (fb_macro.F.a.q() != null) {
            fb_macro2.F.a.setSaveIdOutBeforeCopy(fb_macro.F.a.q().getKey());
            fb_macro2.F.a.setSaveNumInBeforeCopy(fb_macro.F.a.getNumOnIn());
        }
        if (fb_macro.G.a.q() != null) {
            fb_macro2.G.a.setSaveIdOutBeforeCopy(fb_macro.G.a.q().getKey());
            fb_macro2.G.a.setSaveNumInBeforeCopy(fb_macro.G.a.getNumOnIn());
        }
        if (fb_macro.H.a.q() != null) {
            fb_macro2.H.a.setSaveIdOutBeforeCopy(fb_macro.H.a.q().getKey());
            fb_macro2.H.a.setSaveNumInBeforeCopy(fb_macro.H.a.getNumOnIn());
        }
        fb_macro2.I.a.setSaveIdBeforeCopy(fb_macro.I.a.getKey());
        for (ru.himik.nightscream.kascada.Logic.c.a aVar4 : arrayList2) {
            if (aVar4.getSaveIdOutBeforeCopy() >= 0) {
                for (ru.himik.nightscream.kascada.Logic.c.a aVar5 : arrayList2) {
                    if (aVar5.getSaveIdBeforeCopy() == aVar4.getSaveIdOutBeforeCopy()) {
                        aVar4.e(aVar5);
                        aVar4.setNumOnIn(aVar4.getSaveNumInBeforeCopy());
                        aVar5.d(aVar4, aVar4.getSaveNumInBeforeCopy());
                    }
                }
            }
        }
        if (fb_macro.E.a.q() == null) {
            fb_macro2.E.a.c();
        } else if (fb_macro.E.a.q().getKey() == fb_macro.I.a.getKey()) {
            fb_macro2.E.a.e(fb_macro2.I.a);
            fb_macro2.I.a.d(fb_macro2.E.a, 1);
        }
        if (fb_macro.F.a.q() == null) {
            fb_macro2.F.a.c();
        } else if (fb_macro.F.a.q().getKey() == fb_macro.I.a.getKey()) {
            fb_macro2.F.a.e(fb_macro2.I.a);
            fb_macro2.I.a.d(fb_macro2.F.a, 1);
        }
        if (fb_macro.G.a.q() == null) {
            fb_macro2.G.a.c();
        } else if (fb_macro.G.a.q().getKey() == fb_macro.I.a.getKey()) {
            fb_macro2.G.a.e(fb_macro2.I.a);
            fb_macro2.I.a.d(fb_macro2.G.a, 1);
        }
        if (fb_macro.H.a.q() == null) {
            fb_macro2.H.a.c();
        } else if (fb_macro.H.a.q().getKey() == fb_macro.I.a.getKey()) {
            fb_macro2.H.a.e(fb_macro2.I.a);
            fb_macro2.I.a.d(fb_macro2.H.a, 1);
        }
        for (ru.himik.nightscream.kascada.Logic.c.a aVar6 : arrayList2) {
            if (aVar6.getSaveIdOutBeforeCopy() == fb_macro2.I.a.getSaveIdBeforeCopy()) {
                aVar6.e(fb_macro2.I.a);
                aVar6.setNumOnIn(aVar6.getSaveNumInBeforeCopy());
                fb_macro2.I.a.d(aVar6, aVar6.getNumOnIn());
            }
            if (fb_macro2.E.a.getSaveIdOutBeforeCopy() == aVar6.getSaveIdBeforeCopy()) {
                fb_macro2.E.a.e(aVar6);
                VarNameIn varNameIn = fb_macro2.E.a;
                varNameIn.setNumOnIn(varNameIn.getSaveNumInBeforeCopy());
                VarNameIn varNameIn2 = fb_macro2.E.a;
                aVar6.d(varNameIn2, varNameIn2.getNumOnIn());
            }
            if (fb_macro2.F.a.getSaveIdOutBeforeCopy() == aVar6.getSaveIdBeforeCopy()) {
                fb_macro2.F.a.e(aVar6);
                VarNameIn varNameIn3 = fb_macro2.F.a;
                varNameIn3.setNumOnIn(varNameIn3.getSaveNumInBeforeCopy());
                VarNameIn varNameIn4 = fb_macro2.F.a;
                aVar6.d(varNameIn4, varNameIn4.getSaveNumInBeforeCopy());
            }
            if (fb_macro2.G.a.getSaveIdOutBeforeCopy() == aVar6.getSaveIdBeforeCopy()) {
                fb_macro2.G.a.e(aVar6);
                VarNameIn varNameIn5 = fb_macro2.G.a;
                varNameIn5.setNumOnIn(varNameIn5.getSaveNumInBeforeCopy());
                VarNameIn varNameIn6 = fb_macro2.G.a;
                aVar6.d(varNameIn6, varNameIn6.getSaveNumInBeforeCopy());
            }
            if (fb_macro2.H.a.getSaveIdOutBeforeCopy() == aVar6.getSaveIdBeforeCopy()) {
                fb_macro2.H.a.e(aVar6);
                VarNameIn varNameIn7 = fb_macro2.H.a;
                varNameIn7.setNumOnIn(varNameIn7.getSaveNumInBeforeCopy());
                VarNameIn varNameIn8 = fb_macro2.H.a;
                aVar6.d(varNameIn8, varNameIn8.getSaveNumInBeforeCopy());
            }
        }
        arrayList2.clear();
        z0();
        f1.invalidate();
    }

    public void w0() {
        x0(true);
        if (this.f9206k) {
            B0(false);
        } else {
            v0(false);
        }
        invalidateOptionsMenu();
    }

    public void x() {
        MyApplication.b().E.clear();
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 1", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 2", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 3", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 4", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 5", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 6", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 7", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 8", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 9", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 10", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 11", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 12", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 13", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 14", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 15", 1, "", "", "", 1));
        MyApplication.b().E.add(new ru.himik.nightscream.kascada.Preference.NetworkDevicePref.a("Dev. 16", 1, "", "", "", 1));
    }

    public void x0(boolean z2) {
        ViewPropertyAnimator viewPropertyAnimatorAnimate;
        float f2;
        this.e0.o1(a1 == -1);
        if (z2) {
            if (this.f9207l.getVisibility() == 4) {
                this.a0.setVisibility(0);
            }
            this.b0.setVisibility(0);
            viewPropertyAnimatorAnimate = this.a.animate();
            f2 = -MyApplication.b().f9040h;
        } else {
            this.f9207l.setVisibility(4);
            this.a0.setVisibility(4);
            this.b0.setVisibility(4);
            viewPropertyAnimatorAnimate = this.a.animate();
            f2 = 0.0f;
        }
        viewPropertyAnimatorAnimate.translationX(f2);
        this.f9207l.bringToFront();
        this.a.bringToFront();
    }

    public void y(String str, long j2) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < MyApplication.b().D.size(); i2++) {
            int iKeyAt = MyApplication.b().D.keyAt(i2);
            if (MyApplication.b().D.get(iKeyAt).getRootUniqueIdMacro() == j2) {
                arrayList.add(MyApplication.b().D.get(iKeyAt));
            }
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            deleteView((View) ((ru.himik.nightscream.kascada.Logic.c.a) it.next()));
        }
        arrayList.clear();
    }

    public void y0() {
        RelativeLayout relativeLayout;
        Drawable drawableC;
        RelativeLayout relativeLayout2;
        Drawable drawableC2;
        if (a1 == -1) {
            this.Z = 0;
            this.e0.o1(true);
            this.a0.setImageResource(R.drawable.arrow_left);
            this.f9207l.setVisibility(4);
            this.a0.setVisibility(0);
        } else {
            this.a0.setImageResource(R.drawable.menu_app_bar);
            this.e0.o1(false);
        }
        if (a1 == 1 || this.f9206k) {
            findViewById(R.id.lockScreen).setVisibility(4);
        }
        if (a1 > 1 && !this.f9206k) {
            findViewById(R.id.lockScreen).setVisibility(0);
        }
        if (MyApplication.b().v0 != null) {
            MyApplication.b().v0.V(a1);
        }
        if (a1 == 0) {
            this.L.setVisibility(0);
        } else {
            this.L.setVisibility(4);
            this.L.l();
        }
        for (int i2 = 0; i2 < MyApplication.b().F.size(); i2++) {
            ru.himik.nightscream.kascada.CustomComponents.y yVar = (ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(MyApplication.b().F.keyAt(i2));
            if (yVar.getNumScreen() != a1) {
                yVar.setVisibility(4);
            } else {
                yVar.setVisibility(0);
                if (this.f9206k) {
                    if (yVar.f8943g.k() != -1) {
                        ru.himik.nightscream.kascada.CustomComponents.b bVar = new ru.himik.nightscream.kascada.CustomComponents.b(yVar.getIdComponent(), (byte) MyApplication.b().E.get(yVar.f8943g.l()).a(), yVar.f8943g.c(), yVar.f8943g.a(), (byte) 1, yVar.f8943g.j());
                        bVar.F(yVar.f8943g.r());
                        bVar.x(this.o.c(bVar, yVar.f8943g.i()));
                        Y0.get(yVar.f8943g.k()).c(bVar);
                    }
                    if (yVar.f8943g.l() == 100) {
                        ru.himik.nightscream.kascada.CustomComponents.b bVar2 = new ru.himik.nightscream.kascada.CustomComponents.b(yVar.getIdComponent(), (byte) 1, yVar.f8943g.c(), yVar.f8943g.a(), (byte) 1, yVar.f8943g.j());
                        bVar2.F(yVar.f8943g.r());
                        bVar2.x(this.o.c(bVar2, yVar.f8943g.i()));
                        MyApplication.b().v0.e(bVar2);
                    }
                }
            }
        }
        for (int i3 = 0; i3 < MyApplication.b().G.size(); i3++) {
            int iKeyAt = MyApplication.b().G.keyAt(i3);
            if (((CustomLabel) MyApplication.b().G.get(iKeyAt)).getNumScreen() != a1) {
                ((CustomLabel) MyApplication.b().G.get(iKeyAt)).setVisibility(4);
            } else {
                ((CustomLabel) MyApplication.b().G.get(iKeyAt)).setVisibility(0);
            }
        }
        for (int i4 = 0; i4 < MyApplication.b().H.size(); i4++) {
            ru.himik.nightscream.kascada.CustomComponents.u uVar = (ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(MyApplication.b().H.keyAt(i4));
            if (uVar.getNumScreen() != a1) {
                uVar.setVisibility(4);
            } else {
                uVar.setVisibility(0);
            }
        }
        for (int i5 = 0; i5 < MyApplication.b().I.size(); i5++) {
            int iKeyAt2 = MyApplication.b().I.keyAt(i5);
            if (((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt2)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt2)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt2)).setVisibility(0);
            }
        }
        for (int i6 = 0; i6 < MyApplication.b().J.size(); i6++) {
            int iKeyAt3 = MyApplication.b().J.keyAt(i6);
            if (((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt3)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt3)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt3)).setVisibility(0);
            }
        }
        for (int i7 = 0; i7 < MyApplication.b().K.size(); i7++) {
            int iKeyAt4 = MyApplication.b().K.keyAt(i7);
            if (((CustomDynText) MyApplication.b().K.get(iKeyAt4)).getNumScreen() != a1) {
                ((CustomDynText) MyApplication.b().K.get(iKeyAt4)).setVisibility(4);
            } else {
                ((CustomDynText) MyApplication.b().K.get(iKeyAt4)).setVisibility(0);
            }
        }
        for (int i8 = 0; i8 < MyApplication.b().L.size(); i8++) {
            ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(MyApplication.b().L.keyAt(i8));
            if (iVar.getNumScreen() != a1) {
                iVar.setVisibility(4);
            } else {
                iVar.setVisibility(0);
                if (this.f9206k) {
                    if (iVar.f8813j.l() == 100) {
                        MyApplication.b().v0.e(iVar.getInitConnectionInfo());
                    }
                    if (iVar.f8813j.k() != -1) {
                        Y0.get(iVar.f8813j.k()).c(iVar.getInitConnectionInfo());
                    }
                }
            }
        }
        for (int i9 = 0; i9 < MyApplication.b().M.size(); i9++) {
            int iKeyAt5 = MyApplication.b().M.keyAt(i9);
            if (((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt5)).invalidate();
        }
        for (int i10 = 0; i10 < MyApplication.b().N.size(); i10++) {
            int iKeyAt6 = MyApplication.b().N.keyAt(i10);
            if (((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt6)).invalidate();
        }
        for (int i11 = 0; i11 < MyApplication.b().O.size(); i11++) {
            int iKeyAt7 = MyApplication.b().O.keyAt(i11);
            if (((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt7)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt7)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt7)).setVisibility(0);
            }
        }
        for (int i12 = 0; i12 < MyApplication.b().P.size(); i12++) {
            int iKeyAt8 = MyApplication.b().P.keyAt(i12);
            if (((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt8)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt8)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt8)).setVisibility(0);
            }
        }
        for (int i13 = 0; i13 < MyApplication.b().Q.size(); i13++) {
            ru.himik.nightscream.kascada.CustomComponents.v vVar = (ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(MyApplication.b().Q.keyAt(i13));
            if (vVar.getNumScreen() != a1) {
                vVar.setVisibility(4);
            } else {
                vVar.setVisibility(0);
                if (this.f9206k) {
                    ru.himik.nightscream.kascada.CustomComponents.b bVar3 = new ru.himik.nightscream.kascada.CustomComponents.b();
                    bVar3.A(vVar.getIdComponent());
                    bVar3.v(vVar.f8909f.c());
                    bVar3.t(vVar.f8909f.a());
                    bVar3.L((byte) 3);
                    bVar3.C(vVar.getKey());
                    bVar3.F(vVar.f8909f.r());
                    bVar3.u(vVar.f8909f.b());
                    bVar3.x(this.o.c(bVar3, vVar.f8909f.i()));
                    if (vVar.f8909f.l() == 100) {
                        MyApplication.b().v0.e(bVar3);
                    } else if (vVar.f8909f.k() != -1) {
                        Y0.get(vVar.f8909f.k()).c(bVar3);
                    }
                }
            }
        }
        for (int i14 = 0; i14 < MyApplication.b().R.size(); i14++) {
            int iKeyAt9 = MyApplication.b().R.keyAt(i14);
            if (((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt9)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt9)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt9)).setVisibility(0);
            }
        }
        for (int i15 = 0; i15 < MyApplication.b().S.size(); i15++) {
            int iKeyAt10 = MyApplication.b().S.keyAt(i15);
            if (((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(iKeyAt10)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(iKeyAt10)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(iKeyAt10)).setVisibility(0);
            }
        }
        for (int i16 = 0; i16 < MyApplication.b().T.size(); i16++) {
            int iKeyAt11 = MyApplication.b().T.keyAt(i16);
            if (((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt11)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt11)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt11)).setVisibility(0);
            }
        }
        for (int i17 = 0; i17 < MyApplication.b().U.size(); i17++) {
            int iKeyAt12 = MyApplication.b().U.keyAt(i17);
            if (((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt12)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt12)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt12)).setVisibility(0);
            }
        }
        for (int i18 = 0; i18 < MyApplication.b().V.size(); i18++) {
            int iKeyAt13 = MyApplication.b().V.keyAt(i18);
            if (((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt13)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt13)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt13)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt13)).invalidate();
        }
        for (int i19 = 0; i19 < MyApplication.b().W.size(); i19++) {
            int iKeyAt14 = MyApplication.b().W.keyAt(i19);
            if (((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).setVisibility(4);
            } else {
                if (!this.f9206k || ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).c() || ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).d() || ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).e()) {
                    ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).invalidate();
        }
        for (int i20 = 0; i20 < MyApplication.b().X.size(); i20++) {
            CustomList customList = (CustomList) MyApplication.b().X.get(MyApplication.b().X.keyAt(i20));
            if (customList.getNumScreen() != a1) {
                customList.setVisibility(4);
                customList.invalidate();
            } else {
                customList.setVisibility(0);
                customList.invalidate();
                if (this.f9206k) {
                    if (customList.f8687i.l() == 100) {
                        MyApplication.b().v0.e(customList.getInitConnectionInfo());
                    }
                    if (customList.f8687i.k() != -1) {
                        Y0.get(customList.f8687i.k()).c(customList.getInitConnectionInfo());
                    }
                }
            }
        }
        for (int i21 = 0; i21 < MyApplication.b().Y.size(); i21++) {
            int iKeyAt15 = MyApplication.b().Y.keyAt(i21);
            if (((CustomSound) MyApplication.b().Y.get(iKeyAt15)).getNumScreen() != a1) {
                ((CustomSound) MyApplication.b().Y.get(iKeyAt15)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((CustomSound) MyApplication.b().Y.get(iKeyAt15)).setVisibility(0);
                }
            }
            ((CustomSound) MyApplication.b().Y.get(iKeyAt15)).invalidate();
        }
        for (int i22 = 0; i22 < MyApplication.b().Z.size(); i22++) {
            int iKeyAt16 = MyApplication.b().Z.keyAt(i22);
            if (((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt16)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt16)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt16)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt16)).invalidate();
        }
        for (int i23 = 0; i23 < MyApplication.b().a0.size(); i23++) {
            int iKeyAt17 = MyApplication.b().a0.keyAt(i23);
            if (((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt17)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt17)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt17)).h();
                ((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt17)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt17)).invalidate();
        }
        for (int i24 = 0; i24 < MyApplication.b().b0.size(); i24++) {
            int iKeyAt18 = MyApplication.b().b0.keyAt(i24);
            if (((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt18)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt18)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt18)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt18)).invalidate();
        }
        for (int i25 = 0; i25 < MyApplication.b().c0.size(); i25++) {
            int iKeyAt19 = MyApplication.b().c0.keyAt(i25);
            if (((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt19)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt19)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt19)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt19)).invalidate();
        }
        for (int i26 = 0; i26 < MyApplication.b().d0.size(); i26++) {
            int iKeyAt20 = MyApplication.b().d0.keyAt(i26);
            if (((ru.himik.nightscream.kascada.CustomComponents.b0) MyApplication.b().d0.get(iKeyAt20)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.b0) MyApplication.b().d0.get(iKeyAt20)).setVisibility(4);
            } else {
                ((ru.himik.nightscream.kascada.CustomComponents.b0) MyApplication.b().d0.get(iKeyAt20)).setVisibility(0);
            }
            ((ru.himik.nightscream.kascada.CustomComponents.b0) MyApplication.b().d0.get(iKeyAt20)).invalidate();
        }
        for (int i27 = 0; i27 < MyApplication.b().f0.size(); i27++) {
            int iKeyAt21 = MyApplication.b().f0.keyAt(i27);
            if (((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt21)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt21)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt21)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt21)).invalidate();
        }
        for (int i28 = 0; i28 < MyApplication.b().e0.size(); i28++) {
            int iKeyAt22 = MyApplication.b().e0.keyAt(i28);
            if (((ru.himik.nightscream.kascada.CustomComponents.j) MyApplication.b().e0.get(iKeyAt22)).getNumScreen() != a1) {
                ((ru.himik.nightscream.kascada.CustomComponents.j) MyApplication.b().e0.get(iKeyAt22)).setVisibility(4);
            } else {
                if (!this.f9206k) {
                    ((ru.himik.nightscream.kascada.CustomComponents.j) MyApplication.b().e0.get(iKeyAt22)).setVisibility(0);
                }
            }
            ((ru.himik.nightscream.kascada.CustomComponents.j) MyApplication.b().e0.get(iKeyAt22)).invalidate();
        }
        if (!this.f9206k) {
            if (a1 == -1) {
                for (int i29 = 0; i29 < MyApplication.b().D.size(); i29++) {
                    int iKeyAt23 = MyApplication.b().D.keyAt(i29);
                    if (MyApplication.b().D.get(iKeyAt23).getTypeFb() == 135 || MyApplication.b().D.get(iKeyAt23).getRootUniqueIdMacro() != this.W0.c) {
                        ((View) MyApplication.b().D.get(iKeyAt23)).setVisibility(4);
                    } else {
                        if (MyApplication.b().D.get(iKeyAt23).getRootUniqueIdMacro() == this.W0.c) {
                            ((View) MyApplication.b().D.get(iKeyAt23)).setVisibility(0);
                        }
                    }
                    ((View) MyApplication.b().D.get(iKeyAt23)).invalidate();
                }
            } else {
                for (int i30 = 0; i30 < MyApplication.b().D.size(); i30++) {
                    int iKeyAt24 = MyApplication.b().D.keyAt(i30);
                    if (MyApplication.b().D.get(iKeyAt24).getNumScreen() != a1) {
                        ((View) MyApplication.b().D.get(iKeyAt24)).setVisibility(4);
                    } else {
                        ((View) MyApplication.b().D.get(iKeyAt24)).setVisibility(0);
                    }
                    ((View) MyApplication.b().D.get(iKeyAt24)).invalidate();
                }
            }
        }
        f1.invalidate();
        try {
            if (MyApplication.b().C.get(a1 - 1).g()) {
                if (Build.VERSION.SDK_INT < 16) {
                    relativeLayout2 = X0;
                    drawableC2 = getResources().getDrawable(R.drawable.background_default);
                    relativeLayout2.setBackgroundDrawable(drawableC2);
                } else {
                    relativeLayout = X0;
                    drawableC = getResources().getDrawable(R.drawable.background_default);
                    relativeLayout.setBackground(drawableC);
                }
            } else if (MyApplication.b().C.get(a1 - 1).a().booleanValue()) {
                X0.setBackgroundColor(MyApplication.b().C.get(a1 - 1).b());
            } else if (Build.VERSION.SDK_INT < 16) {
                relativeLayout2 = X0;
                drawableC2 = MyApplication.b().C.get(a1 - 1).c();
                relativeLayout2.setBackgroundDrawable(drawableC2);
            } else {
                relativeLayout = X0;
                drawableC = MyApplication.b().C.get(a1 - 1).c();
                relativeLayout.setBackground(drawableC);
            }
            ((TextView) findViewById(R.id.numScreen)).setText(MyApplication.b().C.get(a1 - 1).d() + ": " + a1);
        } catch (Exception unused) {
        }
        z0();
    }

    public void z(FB_MACRO fb_macro) {
        this.W0 = fb_macro;
        fb_macro.u();
        androidx.fragment.app.n nVarA = getSupportFragmentManager().a();
        this.l0 = nVarA;
        nVarA.i(R.id.frameLayout, this.e0);
        this.l0.e();
        a1 = -1;
        y0();
    }

    void z0() {
        this.V.clear();
        for (int i2 = 0; i2 < MyApplication.b().J.size(); i2++) {
            int iKeyAt = MyApplication.b().J.keyAt(i2);
            if (((ru.himik.nightscream.kascada.CustomComponents.e) MyApplication.b().J.get(iKeyAt)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().J.get(iKeyAt));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray = this.V;
                    sparseArray.append(sparseArray.keyAt(sparseArray.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().J.get(iKeyAt));
                }
            }
        }
        for (int i3 = 0; i3 < MyApplication.b().H.size(); i3++) {
            int iKeyAt2 = MyApplication.b().H.keyAt(i3);
            if (((ru.himik.nightscream.kascada.CustomComponents.u) MyApplication.b().H.get(iKeyAt2)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().H.get(iKeyAt2));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray2 = this.V;
                    sparseArray2.append(sparseArray2.keyAt(sparseArray2.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().H.get(iKeyAt2));
                }
            }
        }
        for (int i4 = 0; i4 < MyApplication.b().F.size(); i4++) {
            int iKeyAt3 = MyApplication.b().F.keyAt(i4);
            if (((ru.himik.nightscream.kascada.CustomComponents.y) MyApplication.b().F.get(iKeyAt3)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().F.get(iKeyAt3));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray3 = this.V;
                    sparseArray3.append(sparseArray3.keyAt(sparseArray3.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().F.get(iKeyAt3));
                }
            }
        }
        for (int i5 = 0; i5 < MyApplication.b().P.size(); i5++) {
            int iKeyAt4 = MyApplication.b().P.keyAt(i5);
            if (((ru.himik.nightscream.kascada.CustomComponents.g) MyApplication.b().P.get(iKeyAt4)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().P.get(iKeyAt4));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray4 = this.V;
                    sparseArray4.append(sparseArray4.keyAt(sparseArray4.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().P.get(iKeyAt4));
                }
            }
        }
        for (int i6 = 0; i6 < MyApplication.b().L.size(); i6++) {
            int iKeyAt5 = MyApplication.b().L.keyAt(i6);
            if (((ru.himik.nightscream.kascada.CustomComponents.i) MyApplication.b().L.get(iKeyAt5)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().L.get(iKeyAt5));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray5 = this.V;
                    sparseArray5.append(sparseArray5.keyAt(sparseArray5.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().L.get(iKeyAt5));
                }
            }
        }
        for (int i7 = 0; i7 < MyApplication.b().G.size(); i7++) {
            int iKeyAt6 = MyApplication.b().G.keyAt(i7);
            if (((CustomLabel) MyApplication.b().G.get(iKeyAt6)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().G.get(iKeyAt6));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray6 = this.V;
                    sparseArray6.append(sparseArray6.keyAt(sparseArray6.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().G.get(iKeyAt6));
                }
            }
        }
        for (int i8 = 0; i8 < MyApplication.b().I.size(); i8++) {
            int iKeyAt7 = MyApplication.b().I.keyAt(i8);
            if (((ru.himik.nightscream.kascada.CustomComponents.q) MyApplication.b().I.get(iKeyAt7)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().I.get(iKeyAt7));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray7 = this.V;
                    sparseArray7.append(sparseArray7.keyAt(sparseArray7.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().I.get(iKeyAt7));
                }
            }
        }
        for (int i9 = 0; i9 < MyApplication.b().O.size(); i9++) {
            int iKeyAt8 = MyApplication.b().O.keyAt(i9);
            if (((ru.himik.nightscream.kascada.CustomComponents.r) MyApplication.b().O.get(iKeyAt8)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().O.get(iKeyAt8));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray8 = this.V;
                    sparseArray8.append(sparseArray8.keyAt(sparseArray8.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().O.get(iKeyAt8));
                }
            }
        }
        for (int i10 = 0; i10 < MyApplication.b().Q.size(); i10++) {
            int iKeyAt9 = MyApplication.b().Q.keyAt(i10);
            if (((ru.himik.nightscream.kascada.CustomComponents.v) MyApplication.b().Q.get(iKeyAt9)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().Q.get(iKeyAt9));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray9 = this.V;
                    sparseArray9.append(sparseArray9.keyAt(sparseArray9.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().Q.get(iKeyAt9));
                }
            }
        }
        for (int i11 = 0; i11 < MyApplication.b().M.size(); i11++) {
            int iKeyAt10 = MyApplication.b().M.keyAt(i11);
            if (((ru.himik.nightscream.kascada.CustomComponents.c) MyApplication.b().M.get(iKeyAt10)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().M.get(iKeyAt10));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray10 = this.V;
                    sparseArray10.append(sparseArray10.keyAt(sparseArray10.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().M.get(iKeyAt10));
                }
            }
        }
        for (int i12 = 0; i12 < MyApplication.b().S.size(); i12++) {
            int iKeyAt11 = MyApplication.b().S.keyAt(i12);
            if (((ru.himik.nightscream.kascada.CustomComponents.d) MyApplication.b().S.get(iKeyAt11)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().S.get(iKeyAt11));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray11 = this.V;
                    sparseArray11.append(sparseArray11.keyAt(sparseArray11.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().S.get(iKeyAt11));
                }
            }
        }
        for (int i13 = 0; i13 < MyApplication.b().U.size(); i13++) {
            int iKeyAt12 = MyApplication.b().U.keyAt(i13);
            if (((ru.himik.nightscream.kascada.CustomComponents.h) MyApplication.b().U.get(iKeyAt12)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().U.get(iKeyAt12));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray12 = this.V;
                    sparseArray12.append(sparseArray12.keyAt(sparseArray12.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().U.get(iKeyAt12));
                }
            }
        }
        for (int i14 = 0; i14 < MyApplication.b().K.size(); i14++) {
            int iKeyAt13 = MyApplication.b().K.keyAt(i14);
            if (((CustomDynText) MyApplication.b().K.get(iKeyAt13)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().K.get(iKeyAt13));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray13 = this.V;
                    sparseArray13.append(sparseArray13.keyAt(sparseArray13.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().K.get(iKeyAt13));
                }
            }
        }
        for (int i15 = 0; i15 < MyApplication.b().W.size(); i15++) {
            int iKeyAt14 = MyApplication.b().W.keyAt(i15);
            if (((ru.himik.nightscream.kascada.CustomComponents.k) MyApplication.b().W.get(iKeyAt14)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().W.get(iKeyAt14));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray14 = this.V;
                    sparseArray14.append(sparseArray14.keyAt(sparseArray14.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().W.get(iKeyAt14));
                }
            }
        }
        for (int i16 = 0; i16 < MyApplication.b().T.size(); i16++) {
            int iKeyAt15 = MyApplication.b().T.keyAt(i16);
            if (((ru.himik.nightscream.kascada.CustomComponents.n) MyApplication.b().T.get(iKeyAt15)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().T.get(iKeyAt15));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray15 = this.V;
                    sparseArray15.append(sparseArray15.keyAt(sparseArray15.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().T.get(iKeyAt15));
                }
            }
        }
        for (int i17 = 0; i17 < MyApplication.b().R.size(); i17++) {
            int iKeyAt16 = MyApplication.b().R.keyAt(i17);
            if (((ru.himik.nightscream.kascada.CustomComponents.o) MyApplication.b().R.get(iKeyAt16)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().R.get(iKeyAt16));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray16 = this.V;
                    sparseArray16.append(sparseArray16.keyAt(sparseArray16.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().R.get(iKeyAt16));
                }
            }
        }
        for (int i18 = 0; i18 < MyApplication.b().X.size(); i18++) {
            int iKeyAt17 = MyApplication.b().X.keyAt(i18);
            if (((CustomList) MyApplication.b().X.get(iKeyAt17)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().X.get(iKeyAt17));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray17 = this.V;
                    sparseArray17.append(sparseArray17.keyAt(sparseArray17.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().X.get(iKeyAt17));
                }
            }
        }
        for (int i19 = 0; i19 < MyApplication.b().N.size(); i19++) {
            int iKeyAt18 = MyApplication.b().N.keyAt(i19);
            if (((ru.himik.nightscream.kascada.CustomComponents.w) MyApplication.b().N.get(iKeyAt18)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().N.get(iKeyAt18));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray18 = this.V;
                    sparseArray18.append(sparseArray18.keyAt(sparseArray18.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().N.get(iKeyAt18));
                }
            }
        }
        for (int i20 = 0; i20 < MyApplication.b().V.size(); i20++) {
            int iKeyAt19 = MyApplication.b().V.keyAt(i20);
            if (((ru.himik.nightscream.kascada.CustomComponents.x) MyApplication.b().V.get(iKeyAt19)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().V.get(iKeyAt19));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray19 = this.V;
                    sparseArray19.append(sparseArray19.keyAt(sparseArray19.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().V.get(iKeyAt19));
                }
            }
        }
        for (int i21 = 0; i21 < MyApplication.b().Y.size(); i21++) {
            int iKeyAt20 = MyApplication.b().Y.keyAt(i21);
            if (((CustomSound) MyApplication.b().Y.get(iKeyAt20)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().Y.get(iKeyAt20));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray20 = this.V;
                    sparseArray20.append(sparseArray20.keyAt(sparseArray20.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().Y.get(iKeyAt20));
                }
            }
        }
        for (int i22 = 0; i22 < MyApplication.b().Z.size(); i22++) {
            int iKeyAt21 = MyApplication.b().Z.keyAt(i22);
            if (((ru.himik.nightscream.kascada.CustomComponents.l) MyApplication.b().Z.get(iKeyAt21)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().Z.get(iKeyAt21));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray21 = this.V;
                    sparseArray21.append(sparseArray21.keyAt(sparseArray21.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().Z.get(iKeyAt21));
                }
            }
        }
        for (int i23 = 0; i23 < MyApplication.b().a0.size(); i23++) {
            int iKeyAt22 = MyApplication.b().a0.keyAt(i23);
            if (((ru.himik.nightscream.kascada.CustomComponents.f) MyApplication.b().a0.get(iKeyAt22)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().a0.get(iKeyAt22));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray22 = this.V;
                    sparseArray22.append(sparseArray22.keyAt(sparseArray22.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().a0.get(iKeyAt22));
                }
            }
        }
        if (a1 == -1) {
            for (int i24 = 0; i24 < MyApplication.b().D.size(); i24++) {
                int iKeyAt23 = MyApplication.b().D.keyAt(i24);
                if (MyApplication.b().D.get(iKeyAt23).getNumScreen() == a1 && MyApplication.b().D.get(iKeyAt23).getRootUniqueIdMacro() == this.W0.c) {
                    if (this.V.size() == 0) {
                        this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().D.get(iKeyAt23));
                    } else {
                        SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray23 = this.V;
                        sparseArray23.append(sparseArray23.keyAt(sparseArray23.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().D.get(iKeyAt23));
                    }
                }
            }
        } else {
            for (int i25 = 0; i25 < MyApplication.b().D.size(); i25++) {
                int iKeyAt24 = MyApplication.b().D.keyAt(i25);
                if (MyApplication.b().D.get(iKeyAt24).getNumScreen() == a1) {
                    if (this.V.size() == 0) {
                        this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().D.get(iKeyAt24));
                    } else {
                        SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray24 = this.V;
                        sparseArray24.append(sparseArray24.keyAt(sparseArray24.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().D.get(iKeyAt24));
                    }
                }
            }
        }
        for (int i26 = 0; i26 < MyApplication.b().b0.size(); i26++) {
            int iKeyAt25 = MyApplication.b().b0.keyAt(i26);
            if (((ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt25)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().b0.get(iKeyAt25));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray25 = this.V;
                    sparseArray25.append(sparseArray25.keyAt(sparseArray25.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.m) MyApplication.b().b0.get(iKeyAt25));
                }
            }
        }
        for (int i27 = 0; i27 < MyApplication.b().c0.size(); i27++) {
            int iKeyAt26 = MyApplication.b().c0.keyAt(i27);
            if (((ru.himik.nightscream.kascada.CustomComponents.t) MyApplication.b().c0.get(iKeyAt26)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().c0.get(iKeyAt26));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray26 = this.V;
                    sparseArray26.append(sparseArray26.keyAt(sparseArray26.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().c0.get(iKeyAt26));
                }
            }
        }
        for (int i28 = 0; i28 < MyApplication.b().d0.size(); i28++) {
            int iKeyAt27 = MyApplication.b().d0.keyAt(i28);
            if (((ru.himik.nightscream.kascada.CustomComponents.b0) MyApplication.b().d0.get(iKeyAt27)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().d0.get(iKeyAt27));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray27 = this.V;
                    sparseArray27.append(sparseArray27.keyAt(sparseArray27.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().d0.get(iKeyAt27));
                }
            }
        }
        for (int i29 = 0; i29 < MyApplication.b().e0.size(); i29++) {
            int iKeyAt28 = MyApplication.b().e0.keyAt(i29);
            if (((ru.himik.nightscream.kascada.CustomComponents.j) MyApplication.b().e0.get(iKeyAt28)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().e0.get(iKeyAt28));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray28 = this.V;
                    sparseArray28.append(sparseArray28.keyAt(sparseArray28.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().e0.get(iKeyAt28));
                }
            }
        }
        for (int i30 = 0; i30 < MyApplication.b().f0.size(); i30++) {
            int iKeyAt29 = MyApplication.b().f0.keyAt(i30);
            if (((ru.himik.nightscream.kascada.CustomComponents.a0) MyApplication.b().f0.get(iKeyAt29)).getNumScreen() == a1) {
                if (this.V.size() == 0) {
                    this.V.append(0, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().f0.get(iKeyAt29));
                } else {
                    SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray29 = this.V;
                    sparseArray29.append(sparseArray29.keyAt(sparseArray29.size() - 1) + 1, (ru.himik.nightscream.kascada.CustomComponents.z) MyApplication.b().f0.get(iKeyAt29));
                }
            }
        }
        ArrayList<Object> arrayList = new ArrayList();
        for (int i31 = 0; i31 < this.V.size(); i31++) {
            SparseArray<ru.himik.nightscream.kascada.CustomComponents.z> sparseArray30 = this.V;
            arrayList.add(sparseArray30.get(sparseArray30.keyAt(i31)));
        }
        Collections.sort(arrayList, new Comparator() { // from class: ru.himik.nightscream.kascada.h
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return mbCanvas.U((ru.himik.nightscream.kascada.CustomComponents.z) obj, (ru.himik.nightscream.kascada.CustomComponents.z) obj2);
            }
        });
        for (Object obj : arrayList) {
            if (Build.VERSION.SDK_INT >= 21) {
                ((View) obj).setElevation(4.0f);
            }
            ((View) obj).bringToFront();
        }
        X0.invalidate();
        this.a0.bringToFront();
        this.f9207l.bringToFront();
        this.a.bringToFront();
    }
}
