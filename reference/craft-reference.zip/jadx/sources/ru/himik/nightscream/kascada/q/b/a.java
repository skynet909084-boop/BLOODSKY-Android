package ru.himik.nightscream.kascada.q.b;

import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    private String a;
    private int b;
    private String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f9247d;

    public a(String str, int i2, String str2, String str3) {
        j.d(str, "ip");
        j.d(str2, "login");
        j.d(str3, "pass");
        this.a = str;
        this.b = i2;
        this.c = str2;
        this.f9247d = str3;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.c;
    }

    public final String c() {
        return this.f9247d;
    }

    public final int d() {
        return this.b;
    }

    public final void e(String str) {
        j.d(str, "<set-?>");
        this.a = str;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return j.a(this.a, aVar.a) && this.b == aVar.b && j.a(this.c, aVar.c) && j.a(this.f9247d, aVar.f9247d);
    }

    public final void f(String str) {
        j.d(str, "<set-?>");
        this.c = str;
    }

    public final void g(String str) {
        j.d(str, "<set-?>");
        this.f9247d = str;
    }

    public final void h(int i2) {
        this.b = i2;
    }

    public int hashCode() {
        return (((((this.a.hashCode() * 31) + this.b) * 31) + this.c.hashCode()) * 31) + this.f9247d.hashCode();
    }

    public String toString() {
        return "MqttServer(ip='" + this.a + "', port=" + this.b + ", login='" + this.c + "', pass='" + this.f9247d + "')";
    }
}
