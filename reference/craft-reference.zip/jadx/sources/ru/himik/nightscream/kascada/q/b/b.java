package ru.himik.nightscream.kascada.q.b;

import android.content.Context;
import com.yandex.metrica.YandexMetrica;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import kotlin.b0.d.j;
import kotlin.w.o;
import kotlin.w.w;
import n.b.a.a.a.f;
import n.b.a.a.a.l;
import n.b.a.a.a.n;
import n.b.a.a.a.p;
import n.b.a.a.a.q;
import ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER;
import ru.himik.nightscream.kascada.MyApplication;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    private final int a;
    private org.eclipse.paho.android.service.d b;
    private String c = "";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private List<String> f9248d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private List<String> f9249e = o.g();

    public static final class a implements n.b.a.a.a.b {
        a() {
        }

        @Override // n.b.a.a.a.b
        public void a(f fVar, Throwable th) {
            j.d(fVar, "asyncActionToken");
            j.d(th, "exception");
            th.printStackTrace();
            YandexMetrica.reportError("[MqttConnector.connect] Отключение MQTT onFailure", th.getMessage());
        }

        @Override // n.b.a.a.a.b
        public void b(f fVar) {
            j.d(fVar, "asyncActionToken");
            List<String> listC = b.this.c();
            b bVar = b.this;
            Iterator<T> it = listC.iterator();
            while (it.hasNext()) {
                bVar.i((String) it.next());
            }
            b.this.f();
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.q.b.b$b, reason: collision with other inner class name */
    public static final class C0301b implements n.b.a.a.a.b {
        C0301b() {
        }

        @Override // n.b.a.a.a.b
        public void a(f fVar, Throwable th) {
            j.d(fVar, "asyncActionToken");
            j.d(th, "exception");
        }

        @Override // n.b.a.a.a.b
        public void b(f fVar) {
            j.d(fVar, "asyncActionToken");
        }
    }

    public static final class c implements n.b.a.a.a.j {
        c() {
        }

        @Override // n.b.a.a.a.j
        public void a(String str, q qVar) {
            j.d(str, "topic");
            j.d(qVar, "message");
            try {
                byte[] bArrB = qVar.b();
                j.c(bArrB, "message.payload");
                Charset charsetForName = Charset.forName("UTF-8");
                j.c(charsetForName, "forName(charsetName)");
                String str2 = new String(bArrB, charsetForName);
                int i2 = 0;
                int size = MyApplication.b().D.size();
                while (i2 < size) {
                    int i3 = i2 + 1;
                    int iKeyAt = MyApplication.b().D.keyAt(i2);
                    if (MyApplication.b().D.get(iKeyAt) instanceof MQTT_SUBSCRIBER) {
                        ru.himik.nightscream.kascada.Logic.c.a aVar = MyApplication.b().D.get(iKeyAt);
                        if (aVar == null) {
                            throw new NullPointerException("null cannot be cast to non-null type ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER");
                        }
                        if (((MQTT_SUBSCRIBER) aVar).getNumMqttServer() != b.this.d()) {
                            continue;
                        } else {
                            ru.himik.nightscream.kascada.Logic.c.a aVar2 = MyApplication.b().D.get(iKeyAt);
                            if (aVar2 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER");
                            }
                            if (j.a(((MQTT_SUBSCRIBER) aVar2).getTopic(), str)) {
                                ru.himik.nightscream.kascada.Logic.c.a aVar3 = MyApplication.b().D.get(iKeyAt);
                                if (aVar3 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER");
                                }
                                ((MQTT_SUBSCRIBER) aVar3).u(str2);
                            } else {
                                continue;
                            }
                        }
                    }
                    i2 = i3;
                }
            } catch (Exception e2) {
                YandexMetrica.reportError("[MqttConnector.receiveMessages] Отключение MQTT catch", e2.getMessage());
                e2.printStackTrace();
            }
        }

        @Override // n.b.a.a.a.j
        public void b(Throwable th) {
            YandexMetrica.reportError("[MqttConnector.receiveMessages] Отключение MQTT connectionLost", th == null ? null : th.getMessage());
            if (th == null) {
                return;
            }
            th.printStackTrace();
        }

        @Override // n.b.a.a.a.j
        public void c(n.b.a.a.a.d dVar) {
            j.d(dVar, "token");
        }
    }

    public static final class d implements n.b.a.a.a.b {
        d() {
        }

        @Override // n.b.a.a.a.b
        public void a(f fVar, Throwable th) {
            j.d(fVar, "asyncActionToken");
            j.d(th, "exception");
        }

        @Override // n.b.a.a.a.b
        public void b(f fVar) {
            j.d(fVar, "asyncActionToken");
        }
    }

    public b(int i2) {
        this.a = i2;
    }

    private final void a(Context context) {
        String strA = l.a();
        j.c(strA, "generateClientId()");
        this.c = strA;
        boolean z = true;
        ru.himik.nightscream.kascada.q.b.a aVar = this.a == 1 ? MyApplication.b().o0 : MyApplication.b().p0;
        String strB = aVar.b();
        if (strB == null || strB.length() == 0) {
            String strC = aVar.c();
            if (strC == null || strC.length() == 0) {
                z = false;
            }
        }
        n nVar = new n();
        if (z) {
            nVar.q(aVar.b());
            char[] charArray = aVar.c().toCharArray();
            j.c(charArray, "this as java.lang.String).toCharArray()");
            nVar.p(charArray);
        }
        org.eclipse.paho.android.service.d dVar = new org.eclipse.paho.android.service.d(context, "tcp://" + aVar.a() + ':' + aVar.d(), this.c);
        this.b = dVar;
        try {
            (z ? dVar.j(nVar) : dVar.h()).b(new a());
        } catch (p e2) {
            e2.printStackTrace();
            YandexMetrica.reportError("[MqttConnector.connect] Отключение MQTT catch", e2.getMessage());
        }
    }

    private final void b() {
        try {
            org.eclipse.paho.android.service.d dVar = this.b;
            if (dVar == null) {
                j.m("mqttAndroidClient_");
                throw null;
            }
            dVar.g();
            org.eclipse.paho.android.service.d dVar2 = this.b;
            if (dVar2 != null) {
                dVar2.o().b(new C0301b());
            } else {
                j.m("mqttAndroidClient_");
                throw null;
            }
        } catch (Exception unused) {
        }
    }

    public final List<String> c() {
        return this.f9249e;
    }

    public final int d() {
        return this.a;
    }

    public final void e(String str, String str2, boolean z) {
        j.d(str, "topic");
        j.d(str2, "data");
        try {
            Charset charsetForName = Charset.forName("UTF-8");
            j.c(charsetForName, "forName(charsetName)");
            byte[] bytes = str2.getBytes(charsetForName);
            j.c(bytes, "this as java.lang.String).getBytes(charset)");
            q qVar = new q(bytes);
            qVar.j(2);
            qVar.k(z);
            org.eclipse.paho.android.service.d dVar = this.b;
            if (dVar != null) {
                dVar.u(str, qVar);
            } else {
                j.m("mqttAndroidClient_");
                throw null;
            }
        } catch (Exception unused) {
        }
    }

    public final void f() {
        org.eclipse.paho.android.service.d dVar = this.b;
        if (dVar != null) {
            dVar.z(new c());
        } else {
            j.m("mqttAndroidClient_");
            throw null;
        }
    }

    public final void g() {
        boolean z = true;
        String strA = (this.a == 1 ? MyApplication.b().o0 : MyApplication.b().p0).a();
        int i2 = 0;
        if (strA != null && strA.length() != 0) {
            z = false;
        }
        if (z) {
            return;
        }
        int size = MyApplication.b().D.size();
        while (i2 < size) {
            int i3 = i2 + 1;
            int iKeyAt = MyApplication.b().D.keyAt(i2);
            if (MyApplication.b().D.get(iKeyAt) instanceof MQTT_SUBSCRIBER) {
                ru.himik.nightscream.kascada.Logic.c.a aVar = MyApplication.b().D.get(iKeyAt);
                Objects.requireNonNull(aVar, "null cannot be cast to non-null type ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER");
                if (((MQTT_SUBSCRIBER) aVar).getNumMqttServer() == this.a) {
                    List<String> list = this.f9248d;
                    ru.himik.nightscream.kascada.Logic.c.a aVar2 = MyApplication.b().D.get(iKeyAt);
                    Objects.requireNonNull(aVar2, "null cannot be cast to non-null type ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER");
                    String topic = ((MQTT_SUBSCRIBER) aVar2).getTopic();
                    j.c(topic, "MyApplication.get().FbCo…as MQTT_SUBSCRIBER).topic");
                    list.add(topic);
                }
            }
            i2 = i3;
        }
        List<String> listA = w.A(this.f9248d);
        this.f9249e = listA;
        for (String str : listA) {
        }
        Context context = MyApplication.b().h0;
        j.c(context, "get().context");
        a(context);
    }

    public final void h() {
        b();
        this.f9248d.clear();
    }

    public final void i(String str) {
        j.d(str, "topic");
        try {
            org.eclipse.paho.android.service.d dVar = this.b;
            if (dVar != null) {
                dVar.C(str, 2, null, new d());
            } else {
                j.m("mqttAndroidClient_");
                throw null;
            }
        } catch (p unused) {
        }
    }
}
