package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class e extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    Paint C;
    Drawable D;
    int E;
    int F;
    int G;
    int H;
    int I;
    String J;
    boolean K;
    int L;
    int M;
    boolean N;
    private long O;
    private RectF P;
    private RectF Q;
    private SparseIntArray R;
    private TextPaint S;
    private float T;
    private float U;
    private float V;
    private float W;
    private int a0;
    private int b0;
    public String c;
    private boolean c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8764d;
    private boolean d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8765e;
    private final b e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8766f;
    public Point f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    Context f8767g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public byte f8768h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8769i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f8770j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    boolean f8771k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f8772l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f8773m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    Bitmap f8774n;
    Paint o;

    class a implements b {
        a() {
        }

        @Override // ru.himik.nightscream.kascada.CustomComponents.e.b
        public int a(int i2, RectF rectF) {
            RectF rectF2;
            float fMeasureText;
            e.this.S.setTextSize(i2);
            String string = e.this.getText().toString();
            if (e.this.getMaxLines() == 1) {
                e.this.P.bottom = e.this.S.getFontSpacing();
                rectF2 = e.this.P;
                fMeasureText = e.this.S.measureText(string);
            } else {
                StaticLayout staticLayout = new StaticLayout(string, e.this.S, e.this.a0, Layout.Alignment.ALIGN_NORMAL, e.this.U, e.this.V, true);
                if (e.this.getMaxLines() != -1 && staticLayout.getLineCount() > e.this.getMaxLines()) {
                    return 1;
                }
                e.this.P.bottom = staticLayout.getHeight();
                int lineWidth = -1;
                for (int i3 = 0; i3 < staticLayout.getLineCount(); i3++) {
                    if (lineWidth < staticLayout.getLineWidth(i3)) {
                        lineWidth = (int) staticLayout.getLineWidth(i3);
                    }
                }
                rectF2 = e.this.P;
                fMeasureText = lineWidth;
            }
            rectF2.right = fMeasureText;
            e.this.P.offsetTo(0.0f, 0.0f);
            return rectF.contains(e.this.P) ? -1 : 1;
        }
    }

    private interface b {
        int a(int i2, RectF rectF);
    }

    public e(Context context) {
        super(context);
        this.c = getResources().getString(R.string.button);
        this.f8764d = 6;
        this.f8768h = (byte) 5;
        this.f8769i = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8774n = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.o = new Paint();
        this.C = new Paint();
        this.E = 1;
        this.F = 0;
        this.G = 1;
        this.H = 0;
        this.I = 0;
        this.J = "0";
        this.K = false;
        this.L = 0;
        this.M = 0;
        this.N = true;
        this.O = 0L;
        this.P = new RectF();
        this.Q = new RectF();
        this.R = new SparseIntArray();
        this.S = new TextPaint(getPaint());
        this.T = 500.0f;
        this.U = 1.0f;
        this.V = 0.0f;
        this.W = getResources().getDimension(R.dimen.text_size);
        this.b0 = 1;
        this.c0 = true;
        this.e0 = new a();
        this.f0 = new Point();
        this.f8767g = context;
        if (this.N) {
            g();
        }
    }

    private void g() {
        if (this.d0) {
            int i2 = (int) this.W;
            int measuredHeight = (getMeasuredHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop();
            int measuredWidth = (getMeasuredWidth() - getCompoundPaddingLeft()) - getCompoundPaddingRight();
            this.a0 = measuredWidth;
            RectF rectF = this.Q;
            rectF.right = measuredWidth;
            rectF.bottom = measuredHeight;
            super.setTextSize(0, this.N ? i(i2, (int) this.T, this.e0, rectF) : this.T);
        }
    }

    private static int h(int i2, int i3, b bVar, RectF rectF) {
        int i4 = i3 - 1;
        int i5 = i2;
        while (i2 <= i4) {
            i5 = (i2 + i4) >>> 1;
            int iA = bVar.a(i5, rectF);
            if (iA >= 0) {
                if (iA <= 0) {
                    break;
                }
                i5--;
                i4 = i5;
            } else {
                int i6 = i5 + 1;
                i5 = i2;
                i2 = i6;
            }
        }
        return i5;
    }

    private int i(int i2, int i3, b bVar, RectF rectF) {
        if (!this.c0) {
            return h(i2, i3, bVar, rectF);
        }
        int length = getText().toString().length();
        int i4 = this.R.get(length);
        if (i4 != 0) {
            return i4;
        }
        int iH = h(i2, i3, bVar, rectF);
        this.R.put(length, iH);
        return iH;
    }

    public void a(int i2) {
        setText(this.c + " " + i2);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public int getChangeScreen() {
        return this.G;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.f8769i;
    }

    public String getConstant() {
        return this.J;
    }

    public int getConstantRegister() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8764d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8770j;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return getText().toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    public int getDefaultHeight() {
        int iA = ru.himik.nightscream.kascada.Utils.q.a(40.0f, this.f8767g);
        this.f8766f = iA;
        return iA;
    }

    public int getDefaultWidth() {
        ru.himik.nightscream.kascada.Utils.q.a(150.0f, this.f8767g);
        return this.f8766f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.M;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8764d;
    }

    public int getImagePosition() {
        return this.E;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8769i.l());
        jSONObject.put("addressRegister", this.f8769i.c());
        jSONObject.put("addressBit", (int) this.f8769i.a());
        jSONObject.put("typeRequest", (int) this.f8769i.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("visibleInWork", m());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("imagePosition", getImagePosition());
        jSONObject.put("mode", getMode());
        jSONObject.put("changeScreen", getChangeScreen());
        jSONObject.put("typeRegister", getTypeRegister());
        jSONObject.put("constantRegister", getConstantRegister());
        jSONObject.put("constant", getConstant());
        jSONObject.put("autoResizeText", l());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8765e;
    }

    @Override // android.widget.TextView
    public int getMaxLines() {
        return this.b0;
    }

    public int getMode() {
        return this.F;
    }

    public int getNumScreen() {
        return this.f8770j;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.f0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8769i.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        int i2 = this.F;
        if (i2 == 0) {
            if (this.f8769i.l() >= 100) {
                this.f8769i.u((byte) 1);
                return getResources().getString(R.string.dialog_address) + ": S#" + this.f8769i.c() + "." + ((int) this.f8769i.a());
            }
            this.f8769i.u((byte) MyApplication.b().E.get(this.f8769i.l()).a());
            return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8769i.b()) + "#" + this.f8769i.c() + "." + ((int) this.f8769i.a());
        }
        if (i2 == 1) {
            return getResources().getString(R.string.dialog_button_screen) + ": " + getChangeScreen();
        }
        if (i2 != 2) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8769i.l() >= 100) {
            this.f8769i.u((byte) 1);
            return getResources().getString(R.string.dialog_button_const) + ": S#" + getConstantRegister() + " (" + getConstant() + ")";
        }
        this.f8769i.u((byte) MyApplication.b().E.get(this.f8769i.l()).a());
        return getResources().getString(R.string.dialog_button_const) + ": " + ((int) this.f8769i.b()) + "#" + getConstantRegister() + " (" + getConstant() + ")";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8769i.l() >= 0) {
            if (this.f8769i.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8769i.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.O;
    }

    public int getTypeRegister() {
        return this.H;
    }

    public void j(int i2, int i3, int i4, boolean z) {
        setImageState(this.E);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            a(i4);
        }
        setKey(i4);
        setTextColor(getResources().getColor(R.color.text_black));
        this.f8769i.A(this.f8764d);
        if (this.b0 == 0) {
            this.b0 = -1;
        }
        this.W = getResources().getDimension(R.dimen.text_size_small);
    }

    public void k(int i2, int i3, int i4, boolean z, int i5) {
        int iRound;
        Resources resources;
        setImageState(this.E);
        if (!z) {
            int i6 = R.dimen.view_base_width;
            if (i5 == 1 || i5 == 3 || i5 == 4) {
                iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
                resources = getResources();
                i6 = R.dimen.view_base_height;
            } else {
                iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
                resources = getResources();
            }
            int iRound2 = Math.round(resources.getDimension(i6));
            int i7 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i7) * i7);
            setX(((i2 - (iRound / 2)) / i7) * i7);
            a(i4);
        }
        setKey(i4);
        setTextColor(getResources().getColor(R.color.text_black));
        this.f8769i.A(this.f8764d);
        if (this.b0 == 0) {
            this.b0 = -1;
        }
        this.W = getResources().getDimension(R.dimen.text_size_small);
    }

    public boolean l() {
        return this.N;
    }

    public boolean m() {
        return this.f8771k;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8773m) {
            this.C.setColor(-65536);
            this.C.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.C);
        }
        if (this.f8772l && mbCanvas.g1) {
            canvas.drawBitmap(this.f8774n, getWidth() - this.f8774n.getWidth(), getHeight() - this.f8774n.getHeight(), this.o);
        }
        if (this.K) {
            this.C.setColor(-16711936);
            this.C.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.C);
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        this.d0 = true;
        this.R.clear();
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        g();
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.widget.TextView
    protected void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        g();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.K;
    }

    public void setAutoResizeText(boolean z) {
        this.N = z;
        if (z) {
            this.T = 500.0f;
        }
    }

    public void setChangeScreen(int i2) {
        this.G = i2;
    }

    public void setConnectionError(boolean z) {
        this.f8773m = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8772l = z;
    }

    public void setConstant(String str) {
        this.J = str;
    }

    public void setConstantRegister(int i2) {
        this.I = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.K = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.L = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.M = i2;
    }

    public void setFont(String str) {
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0036 A[PHI: r0
      0x0036: PHI (r0v3 int) = (r0v2 int), (r0v5 int), (r0v6 int) binds: [B:20:0x0034, B:17:0x002a, B:14:0x0020] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:22:0x003f A[PHI: r0
      0x003f: PHI (r0v4 int) = (r0v2 int), (r0v5 int), (r0v6 int) binds: [B:20:0x0034, B:17:0x002a, B:14:0x0020] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:25:0x004e  */
    /* JADX WARN: Code duplicated, block: B:26:0x0057  */
    public void setImageState(int i2) {
        Drawable drawable;
        int i3;
        if (i2 == 1) {
            this.E = 1;
            if (Build.VERSION.SDK_INT >= 21) {
                drawable = getResources().getDrawable(R.drawable.button, null);
            } else {
                drawable = getResources().getDrawable(R.drawable.button);
            }
        } else if (i2 == 2) {
            this.E = 2;
            int i4 = Build.VERSION.SDK_INT;
            i3 = R.drawable.button2;
            if (i4 >= 21) {
                drawable = getResources().getDrawable(i3, null);
            } else {
                drawable = getResources().getDrawable(i3);
            }
        } else if (i2 == 3) {
            this.E = 3;
            int i5 = Build.VERSION.SDK_INT;
            i3 = R.drawable.button3;
            if (i5 >= 21) {
                drawable = getResources().getDrawable(i3, null);
            } else {
                drawable = getResources().getDrawable(i3);
            }
        } else if (i2 != 4) {
            this.E = 1;
            if (Build.VERSION.SDK_INT >= 21) {
                drawable = getResources().getDrawable(R.drawable.button, null);
            } else {
                drawable = getResources().getDrawable(R.drawable.button);
            }
        } else {
            this.E = 4;
            int i6 = Build.VERSION.SDK_INT;
            i3 = R.drawable.tab_button;
            if (i6 >= 21) {
                drawable = getResources().getDrawable(i3, null);
            } else {
                drawable = getResources().getDrawable(i3);
            }
        }
        this.D = drawable;
        if (Build.VERSION.SDK_INT < 16) {
            setBackgroundDrawable(this.D);
        } else {
            setBackground(this.D);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8765e = i2;
    }

    @Override // android.widget.TextView
    public void setLineSpacing(float f2, float f3) {
        super.setLineSpacing(f2, f3);
        this.U = f3;
        this.V = f2;
    }

    @Override // android.widget.TextView
    public void setLines(int i2) {
        super.setLines(i2);
        this.b0 = i2;
        g();
    }

    @Override // android.widget.TextView
    public void setMaxLines(int i2) {
        super.setMaxLines(i2);
        this.b0 = i2;
        g();
    }

    public void setMinTextSize(float f2) {
        this.W = f2;
        g();
    }

    public void setMode(int i2) {
        this.F = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8770j = i2;
    }

    @Override // android.widget.TextView
    public void setSingleLine() {
        super.setSingleLine();
        this.b0 = 1;
        g();
    }

    @Override // android.widget.TextView
    public void setSingleLine(boolean z) {
        super.setSingleLine(z);
        this.b0 = z ? 1 : -1;
        g();
    }

    public void setStateOn(boolean z) {
    }

    @Override // android.widget.TextView
    public void setTextSize(float f2) {
        this.T = f2;
        this.R.clear();
        g();
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.widget.TextView
    public void setTextSize(int i2, float f2) {
        Context context = getContext();
        this.T = TypedValue.applyDimension(i2, f2, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        this.R.clear();
        g();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.O = j2;
    }

    public void setTypeRegister(int i2) {
        this.H = i2;
    }

    public void setVisibleInWork(boolean z) {
        this.f8771k = z;
    }
}
