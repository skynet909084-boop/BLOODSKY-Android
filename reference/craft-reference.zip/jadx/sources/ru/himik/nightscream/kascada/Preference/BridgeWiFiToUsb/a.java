package ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb;

import android.os.Handler;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

/* JADX INFO: loaded from: classes2.dex */
public class a extends Thread {
    Handler a;
    ServerSocket b;
    Socket c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    InputStream f9064d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    OutputStream f9065e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f9066f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    byte f9067g = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f9068h = 0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    byte[] f9069i = new byte[2000];

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    b f9070j;

    public a(Handler handler) {
        this.a = handler;
        start();
    }

    public void a(b bVar) {
        this.f9070j = bVar;
    }

    public void b() {
        this.f9066f = false;
    }

    public void c(byte[] bArr) {
        if (this.f9067g == 3) {
            try {
                this.f9065e.write(bArr);
                this.f9065e.flush();
            } catch (Exception unused) {
                this.f9067g = (byte) 4;
            }
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        while (true) {
            if (!this.f9066f) {
                break;
            }
            byte b = this.f9067g;
            if (b == 0) {
                ServerSocket serverSocket = new ServerSocket();
                this.b = serverSocket;
                serverSocket.setReuseAddress(true);
                this.b.bind(new InetSocketAddress(8081));
                this.b.setSoTimeout(3000);
                this.c = this.b.accept();
                this.a.obtainMessage(0).sendToTarget();
                this.f9064d = this.c.getInputStream();
                this.f9065e = this.c.getOutputStream();
                this.f9067g = (byte) 3;
            } else if (b == 3) {
                try {
                    Thread.sleep(50L);
                } catch (InterruptedException unused) {
                }
                try {
                    if (this.f9064d.available() > 0) {
                        int i2 = this.f9064d.read(this.f9069i);
                        this.f9068h = i2;
                        byte[] bArr = new byte[i2];
                        System.arraycopy(this.f9069i, 0, bArr, 0, i2);
                        b bVar = this.f9070j;
                        if (bVar != null) {
                            bVar.c(bArr);
                        }
                    }
                } catch (Exception unused2) {
                    this.f9067g = (byte) 4;
                }
            } else if (b == 4) {
                this.a.obtainMessage(1).sendToTarget();
                try {
                    ServerSocket serverSocket2 = this.b;
                    if (serverSocket2 != null) {
                        serverSocket2.close();
                    }
                    Socket socket = this.c;
                    if (socket != null) {
                        socket.close();
                    }
                    InputStream inputStream = this.f9064d;
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    OutputStream outputStream = this.f9065e;
                    if (outputStream != null) {
                        outputStream.close();
                    }
                    this.f9067g = (byte) 0;
                } catch (Exception unused3) {
                }
            }
        }
        this.a.obtainMessage(1).sendToTarget();
        try {
            Socket socket2 = this.c;
            if (socket2 != null) {
                socket2.close();
            }
            this.c = null;
            ServerSocket serverSocket3 = this.b;
            if (serverSocket3 != null) {
                serverSocket3.close();
            }
            this.b = null;
            InputStream inputStream2 = this.f9064d;
            if (inputStream2 != null) {
                inputStream2.close();
            }
            OutputStream outputStream2 = this.f9065e;
            if (outputStream2 != null) {
                outputStream2.close();
            }
        } catch (Exception unused4) {
        } finally {
            this.a.obtainMessage(4).sendToTarget();
        }
    }
}
