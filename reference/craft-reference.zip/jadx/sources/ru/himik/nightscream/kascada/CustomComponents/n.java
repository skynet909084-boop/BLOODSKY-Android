package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Build;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class n extends androidx.appcompat.widget.n implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    boolean C;
    boolean D;
    int E;
    int F;
    private long G;
    public Point H;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8851d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8852e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8853f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ru.himik.nightscream.kascada.CustomComponents.b f8854g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8855h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f8856i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f8857j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    Bitmap f8858k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    Paint f8859l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    Paint f8860m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8861n;
    int o;

    class a implements f.b.a.t.f<File, f.b.a.p.k.h.b> {
        a() {
        }

        @Override // f.b.a.t.f
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public boolean b(Exception exc, File file, f.b.a.t.j.j<f.b.a.p.k.h.b> jVar, boolean z) {
            Toast.makeText(n.this.getContext(), n.this.getResources().getString(R.string.custom_gif_error_load_gif), 1).show();
            n.this.c();
            return true;
        }

        @Override // f.b.a.t.f
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public boolean a(f.b.a.p.k.h.b bVar, File file, f.b.a.t.j.j<f.b.a.p.k.h.b> jVar, boolean z, boolean z2) {
            n.this.setFirstFrame(bVar.e());
            return true;
        }
    }

    class b implements f.b.a.t.f<File, f.b.a.p.k.h.b> {
        b() {
        }

        @Override // f.b.a.t.f
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public boolean b(Exception exc, File file, f.b.a.t.j.j<f.b.a.p.k.h.b> jVar, boolean z) {
            Toast.makeText(n.this.getContext(), n.this.getResources().getString(R.string.custom_gif_error_load_gif), 1).show();
            n.this.c();
            return true;
        }

        @Override // f.b.a.t.f
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public boolean a(f.b.a.p.k.h.b bVar, File file, f.b.a.t.j.j<f.b.a.p.k.h.b> jVar, boolean z, boolean z2) {
            return false;
        }
    }

    public n(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_gif);
        this.f8851d = 16;
        this.f8853f = (byte) 1;
        this.f8854g = new ru.himik.nightscream.kascada.CustomComponents.b();
        this.f8858k = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.f8859l = new Paint();
        this.f8860m = new Paint();
        this.f8861n = "";
        this.o = 0;
        this.C = false;
        this.D = false;
        this.E = 0;
        this.F = 0;
        this.G = 0L;
        this.H = new Point();
    }

    public void c() {
        setImageDrawable(Build.VERSION.SDK_INT >= 21 ? getResources().getDrawable(R.drawable.animation, null) : getResources().getDrawable(R.drawable.animation));
    }

    public void d(int i2, int i3, int i4, boolean z) {
        setScaleType(ImageView.ScaleType.FIT_XY);
        setPadding(10, 10, 10, 10);
        setImageDrawable(Build.VERSION.SDK_INT >= 21 ? getResources().getDrawable(R.drawable.animation, null) : getResources().getDrawable(R.drawable.animation));
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setKey(i4);
        this.f8854g.A(this.f8851d);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.H.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e() {
        if (this.f8861n.toString().length() == 0) {
            return;
        }
        f.b.a.h<File> hVarL = f.b.a.i.v(getContext()).t(new File(this.f8861n)).L();
        hVarL.F(new a());
        hVarL.n(this);
    }

    public void f() {
        if (this.f8861n.toString().length() == 0) {
            return;
        }
        try {
            f.b.a.h<File> hVarL = f.b.a.i.v(getContext()).t(new File(this.f8861n)).L();
            hVarL.F(new b());
            hVarL.n(this);
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return this.f8854g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8851d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8855h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.E;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8851d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8854g.l());
        jSONObject.put("addressRegister", this.f8854g.c());
        jSONObject.put("addressBit", (int) this.f8854g.a());
        jSONObject.put("typeRequest", (int) this.f8854g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("pathGif", getPathGif());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8852e;
    }

    public int getNumScreen() {
        return this.f8855h;
    }

    public String getPathGif() {
        return this.f8861n;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8854g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8854g.l() >= 100) {
            this.f8854g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8854g.c() + "." + ((int) this.f8854g.a());
        }
        this.f8854g.u((byte) MyApplication.b().E.get(this.f8854g.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8854g.b()) + "#" + this.f8854g.c() + "." + ((int) this.f8854g.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8854g.l() >= 0) {
            if (this.f8854g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8854g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.G;
    }

    public boolean getValue() {
        return this.o == 1;
    }

    @Override // android.widget.ImageView, android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8857j) {
            this.f8860m.setColor(-65536);
            this.f8860m.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f8860m);
        }
        if (this.f8856i && mbCanvas.g1) {
            canvas.drawBitmap(this.f8858k, (getWidth() / 2) - (this.f8858k.getWidth() / 2), (getHeight() / 2) - this.f8858k.getHeight(), this.f8859l);
        }
        if (this.D) {
            this.f8860m.setColor(-16711936);
            this.f8860m.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f8860m);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.D;
    }

    public void setConnectionError(boolean z) {
        this.f8857j = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8856i = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.D = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.E = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.F = i2;
    }

    public void setFirstFrame(Bitmap bitmap) {
        setImageBitmap(bitmap);
    }

    public void setFont(String str) {
    }

    public void setIdComponent(int i2) {
        this.f8851d = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8852e = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8854g.G(i2);
        this.f8855h = i2;
    }

    public void setPathGif(String str) {
        if (str.toString().length() <= 0 || this.f8861n.equals(str)) {
            return;
        }
        this.f8861n = str;
        e();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.G = j2;
    }

    public void setValue(int i2) {
        this.o = i2;
        if (i2 == 1 && !this.C) {
            this.C = true;
            f();
        }
        if (i2 == 0 && this.C) {
            this.C = false;
            e();
        }
    }
}
