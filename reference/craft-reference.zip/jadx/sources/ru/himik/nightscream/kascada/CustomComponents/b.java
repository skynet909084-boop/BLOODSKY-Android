package ru.himik.nightscream.kascada.CustomComponents;

import java.util.Arrays;

/* JADX INFO: loaded from: classes2.dex */
public class b {
    private int a;
    private byte b;
    private int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private byte f8716d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private byte f8717e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f8718f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private byte[] f8719g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f8720h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f8721i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f8722j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f8723k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private byte f8724l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f8725m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f8726n;
    private int o;
    private float p;
    private int[] q;
    private int r;
    private int s;

    public b() {
        this.b = (byte) 0;
        this.c = 0;
        this.f8716d = (byte) 0;
        this.f8717e = (byte) 0;
        this.f8718f = -1;
        this.f8720h = -1;
        this.f8721i = false;
        this.f8722j = 0;
        this.f8723k = -1;
        this.f8724l = (byte) 1;
        this.f8725m = 0;
        this.f8726n = false;
        this.o = 0;
        this.p = 0.0f;
        this.q = new int[1];
        this.r = 1;
        this.s = 0;
    }

    public b(int i2, byte b, int i3, byte b2, byte b3, int i4) {
        this.b = (byte) 0;
        this.c = 0;
        this.f8716d = (byte) 0;
        this.f8717e = (byte) 0;
        this.f8718f = -1;
        this.f8720h = -1;
        this.f8721i = false;
        this.f8722j = 0;
        this.f8723k = -1;
        this.f8724l = (byte) 1;
        this.f8725m = 0;
        this.f8726n = false;
        this.o = 0;
        this.p = 0.0f;
        this.q = new int[1];
        this.r = 1;
        this.s = 0;
        this.a = i2;
        this.b = b;
        this.c = i3;
        this.f8716d = b2;
        this.f8717e = b3;
        this.f8720h = i4;
    }

    public void A(int i2) {
        this.a = i2;
    }

    public void B(int i2) {
        this.f8725m = i2;
    }

    public void C(int i2) {
        this.f8720h = i2;
    }

    public void D(int i2) {
        this.f8718f = i2;
    }

    public void E(int i2) {
        this.f8723k = i2;
    }

    public void F(boolean z) {
        this.f8726n = z;
    }

    public void G(int i2) {
        this.s = i2;
    }

    public void H(int i2) {
        this.f8722j = i2;
    }

    public void I(float f2) {
        this.p = f2;
    }

    public void J(boolean z) {
        this.f8721i = z;
    }

    public void K(int i2) {
        this.o = i2;
    }

    public void L(byte b) {
        this.f8717e = b;
    }

    public byte a() {
        return this.f8716d;
    }

    public byte b() {
        return this.b;
    }

    public int c() {
        return this.c;
    }

    public int[] d() {
        return this.q;
    }

    public byte[] e() {
        return this.f8719g;
    }

    public int f() {
        return this.r;
    }

    public byte g() {
        return this.f8724l;
    }

    public int h() {
        return this.a;
    }

    public int i() {
        return this.f8725m;
    }

    public int j() {
        return this.f8720h;
    }

    public int k() {
        return this.f8718f;
    }

    public int l() {
        return this.f8723k;
    }

    public int m() {
        return this.s;
    }

    public int n() {
        return this.f8722j;
    }

    public float o() {
        return this.p;
    }

    public int p() {
        return this.o;
    }

    public byte q() {
        return this.f8717e;
    }

    public boolean r() {
        return this.f8726n;
    }

    public boolean s() {
        return this.f8721i;
    }

    public void t(byte b) {
        this.f8716d = b;
    }

    public String toString() {
        return "ConnectionInfo{idComponent=" + this.a + ", addressPLC=" + ((int) this.b) + ", addressRegister=" + this.c + ", addressBit=" + ((int) this.f8716d) + ", typeRequest=" + ((int) this.f8717e) + ", posConnectionInList=" + this.f8718f + ", arrayRequest=" + Arrays.toString(this.f8719g) + ", key=" + this.f8720h + ", state=" + this.f8721i + ", sendValue=" + this.f8722j + ", posDeviceNetworkInList=" + this.f8723k + ", countRegister=" + ((int) this.f8724l) + ", idConnector=" + this.f8725m + ", rtu=" + this.f8726n + ", type=" + this.o + ", sendValueFloat=" + this.p + ", arrayReg=" + Arrays.toString(this.q) + ", countBit=" + this.r + '}';
    }

    public void u(byte b) {
        this.b = b;
    }

    public void v(int i2) {
        this.c = i2;
    }

    public void w(int[] iArr) {
        this.q = iArr;
    }

    public void x(byte[] bArr) {
        this.f8719g = bArr;
    }

    public void y(int i2) {
        this.r = i2;
    }

    public void z(byte b) {
        this.f8724l = b;
    }
}
