package ru.himik.nightscream.kascada.s;

/* JADX INFO: loaded from: classes2.dex */
public interface b {
}
