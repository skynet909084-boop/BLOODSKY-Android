package ru.himik.nightscream.kascada;

import android.content.Context;
import android.graphics.Point;
import android.view.MotionEvent;
import android.widget.RelativeLayout;

/* JADX INFO: loaded from: classes.dex */
public class z extends RelativeLayout implements ru.himik.nightscream.kascada.s.a {
    public Point a;

    public z(Context context) {
        super(context);
        this.a = new Point();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.a.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.a;
    }
}
