package ru.himik.nightscream.kascada.Connections.Cloud;

import android.database.Cursor;
import android.os.Handler;
import com.sun.mail.imap.IMAPStore;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public class a extends Thread {
    boolean D;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private Socket f8633d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    SocketAddress f8635f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    Handler f8638i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private String f8639j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    Cursor f8640k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f8641l;
    String a = "94.250.249.225";
    int b = 25554;
    boolean c = true;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f8634e = 1000;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    long f8636g = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    long f8637h = 3000;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f8642m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    JSONObject f8643n = null;
    String o = "";
    private int C = 0;

    public a(String str, Cursor cursor, Handler handler, String str2, boolean z) {
        this.f8639j = "error";
        this.f8641l = "default";
        this.D = false;
        this.f8639j = str;
        this.f8640k = cursor;
        this.f8638i = handler;
        this.f8641l = str2;
        this.D = z;
        if (z) {
            ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] получил cursor.getCount(): " + cursor.getCount() + " key: " + str);
        }
    }

    public void a() {
        if (this.D) {
            ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] ->cancel();");
        }
        this.c = false;
    }

    /* JADX WARN: Code duplicated, block: B:103:0x0248 A[Catch: Exception -> 0x02fc, TryCatch #11 {Exception -> 0x02fc, blocks: (B:122:0x02ec, B:101:0x0244, B:103:0x0248, B:104:0x025d, B:105:0x0262, B:107:0x0270, B:109:0x0274, B:110:0x0279, B:112:0x028e, B:115:0x029c, B:118:0x02a3, B:120:0x02e5, B:121:0x02ea), top: B:229:0x02ec }] */
    /* JADX WARN: Code duplicated, block: B:184:0x03e4  */
    /* JADX WARN: Code duplicated, block: B:187:0x0400 A[Catch: IOException -> 0x040d, TryCatch #6 {IOException -> 0x040d, blocks: (B:185:0x03fc, B:187:0x0400, B:189:0x0405, B:191:0x040a), top: B:219:0x03fc }] */
    /* JADX WARN: Code duplicated, block: B:189:0x0405 A[Catch: IOException -> 0x040d, TryCatch #6 {IOException -> 0x040d, blocks: (B:185:0x03fc, B:187:0x0400, B:189:0x0405, B:191:0x040a), top: B:219:0x03fc }] */
    /* JADX WARN: Code duplicated, block: B:191:0x040a A[Catch: IOException -> 0x040d, TRY_LEAVE, TryCatch #6 {IOException -> 0x040d, blocks: (B:185:0x03fc, B:187:0x0400, B:189:0x0405, B:191:0x040a), top: B:219:0x03fc }] */
    /* JADX WARN: Instruction removed from duplicated block: B:103:0x0248, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:184:0x03e4, please report this as an issue */
    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        char c;
        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;
        String str;
        Socket socket;
        char c2;
        BufferedWriter bufferedWriter2;
        char c3;
        String str2;
        System.currentTimeMillis();
        this.f8635f = new InetSocketAddress(this.a, this.b);
        this.f8636g = System.currentTimeMillis();
        char c4 = 4;
        char c5 = 0;
        BufferedReader bufferedReader2 = null;
        BufferedWriter bufferedWriter3 = null;
        while (this.c) {
            if (System.currentTimeMillis() - this.f8636g >= 3000) {
                if (this.D) {
                    ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] timeout");
                }
                c = 4;
            } else {
                c = c5;
            }
            c5 = 1;
            if (c == 0) {
                bufferedReader = bufferedReader2;
                bufferedWriter = bufferedWriter3;
                str = "Archive";
                try {
                    if (this.D) {
                        ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] CREATE_SOCKET");
                    }
                    Socket socket2 = this.f8633d;
                    if (socket2 == null || !socket2.isConnected()) {
                        this.f8633d = new Socket();
                    }
                    bufferedWriter3 = bufferedWriter;
                    bufferedReader2 = bufferedReader;
                } catch (Exception e2) {
                    e = e2;
                    bufferedWriter3 = bufferedWriter;
                    if (this.D) {
                        ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] MAIN EXCEPTION " + e.getMessage());
                    }
                    socket = this.f8633d;
                    if (socket != null) {
                        socket.close();
                    }
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                    if (bufferedWriter3 != null) {
                        bufferedWriter3.close();
                    }
                    bufferedReader2 = bufferedReader;
                    c5 = 4;
                }
            } else if (c != 1) {
                if (c != 2) {
                    if (c == c4) {
                        try {
                            if (this.D) {
                                ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] STEP ERROR");
                            }
                            this.f8638i.obtainMessage(3).sendToTarget();
                            a();
                        } catch (Exception e3) {
                            e = e3;
                            bufferedReader = bufferedReader2;
                            str = "Archive";
                            if (this.D) {
                                ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] MAIN EXCEPTION " + e.getMessage());
                            }
                            try {
                                socket = this.f8633d;
                                if (socket != null) {
                                    socket.close();
                                }
                                if (bufferedReader != null) {
                                    bufferedReader.close();
                                }
                                if (bufferedWriter3 != null) {
                                    bufferedWriter3.close();
                                }
                            } catch (IOException unused) {
                            }
                            bufferedReader2 = bufferedReader;
                            c5 = 4;
                        }
                    }
                    c3 = c;
                    bufferedReader = bufferedReader2;
                    bufferedWriter2 = bufferedWriter3;
                } else {
                    try {
                        int i2 = this.f8642m;
                        if (i2 == 0) {
                            c3 = c;
                            bufferedReader = bufferedReader2;
                            bufferedWriter2 = bufferedWriter3;
                            str = "Archive";
                            JSONObject jSONObject = new JSONObject();
                            this.f8643n = jSONObject;
                            jSONObject.put("key", this.f8639j);
                            this.f8643n.put("action", "checkPermission");
                            this.f8643n.put("fileName", this.f8641l);
                            this.f8643n.put("allCount", this.f8640k.getCount());
                            bufferedWriter2.write(this.f8643n.toString());
                            bufferedWriter2.newLine();
                            bufferedWriter2.flush();
                            if (this.D) {
                                ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] SEND->READ");
                            }
                            this.f8642m = 1;
                        } else if (i2 == 1) {
                            c3 = c;
                            bufferedReader = bufferedReader2;
                            bufferedWriter2 = bufferedWriter3;
                            str = "Archive";
                            String line = bufferedReader.readLine();
                            this.o = line;
                            if (line != null) {
                                if (this.D) {
                                    ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] READ OK");
                                }
                                this.f8636g = System.currentTimeMillis();
                                JSONObject jSONObject2 = new JSONObject(this.o);
                                this.f8643n = jSONObject2;
                                if (jSONObject2.getBoolean("checkPermission")) {
                                    this.f8642m = 2;
                                    this.f8640k.moveToFirst();
                                    if (this.D) {
                                        str2 = "[CloudArchive] READ->ACTION_SEND_DATA";
                                        ru.himik.nightscream.kascada.w.b.a(str, str2);
                                    }
                                } else if (this.D) {
                                    str2 = "[CloudArchive] READ сервер не разрешил подключаться";
                                    ru.himik.nightscream.kascada.w.b.a(str, str2);
                                }
                            }
                        } else if (i2 != 2) {
                            if (i2 == 3) {
                                String line2 = bufferedReader2.readLine();
                                this.o = line2;
                                if (line2 != null) {
                                    if (this.D) {
                                        ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] ACTION_READ_SEND_DATA OK ");
                                    }
                                    this.f8636g = System.currentTimeMillis();
                                    JSONObject jSONObject3 = new JSONObject(this.o);
                                    this.f8643n = jSONObject3;
                                    String string = jSONObject3.getString("status");
                                    byte b = -1;
                                    int iHashCode = string.hashCode();
                                    if (iHashCode != -799233872) {
                                        if (iHashCode == 96784904 && string.equals("error")) {
                                            b = 1;
                                        }
                                    } else if (string.equals("recorded")) {
                                        b = 0;
                                    }
                                    if (b == 0) {
                                        if (this.D) {
                                            ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] ACTION_READ_SEND_DATA recorded successful");
                                        }
                                        this.f8638i.obtainMessage(2).sendToTarget();
                                        a();
                                    } else if (b == 1) {
                                        if (this.D) {
                                            ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] ACTION_READ_SEND_DATA ERROR");
                                        }
                                        this.f8642m = 4;
                                    }
                                }
                            }
                            c3 = c;
                            bufferedReader = bufferedReader2;
                            bufferedWriter2 = bufferedWriter3;
                            str = "Archive";
                        } else {
                            this.f8643n = new JSONObject();
                            try {
                                if (this.C < this.f8640k.getCount()) {
                                    int i3 = this.C + 1;
                                    this.C = i3;
                                    this.f8640k.moveToPosition(i3 - 1);
                                    Cursor cursor = this.f8640k;
                                    String strReplace = cursor.getString(cursor.getColumnIndex("var1")).replace('.', ',');
                                    Cursor cursor2 = this.f8640k;
                                    String strReplace2 = cursor2.getString(cursor2.getColumnIndex("var2")).replace('.', ',');
                                    Cursor cursor3 = this.f8640k;
                                    String strReplace3 = cursor3.getString(cursor3.getColumnIndex("var3")).replace('.', ',');
                                    Cursor cursor4 = this.f8640k;
                                    c3 = c;
                                    try {
                                        String strReplace4 = cursor4.getString(cursor4.getColumnIndex("var4")).replace('.', ',');
                                        Cursor cursor5 = this.f8640k;
                                        bufferedReader = bufferedReader2;
                                        try {
                                            String strReplace5 = cursor5.getString(cursor5.getColumnIndex("var5")).replace('.', ',');
                                            Cursor cursor6 = this.f8640k;
                                            String string2 = cursor6.getString(cursor6.getColumnIndex("_time"));
                                            Cursor cursor7 = this.f8640k;
                                            try {
                                                String string3 = cursor7.getString(cursor7.getColumnIndex("_date"));
                                                BufferedWriter bufferedWriter4 = bufferedWriter3;
                                                try {
                                                    this.f8643n.put("action", "data");
                                                    this.f8643n.put("var1", strReplace);
                                                    this.f8643n.put("var2", strReplace2);
                                                    this.f8643n.put("var3", strReplace3);
                                                    this.f8643n.put("var4", strReplace4);
                                                    this.f8643n.put("var5", strReplace5);
                                                    this.f8643n.put("time", string2);
                                                    this.f8643n.put(IMAPStore.ID_DATE, string3);
                                                    this.f8643n.put("countSend", this.C);
                                                    bufferedWriter2 = bufferedWriter4;
                                                    try {
                                                        bufferedWriter2.write(this.f8643n.toString());
                                                        bufferedWriter2.newLine();
                                                        bufferedWriter2.flush();
                                                        this.f8636g = System.currentTimeMillis();
                                                        str = "Archive";
                                                    } catch (Exception e4) {
                                                        e = e4;
                                                        str = "Archive";
                                                        if (this.D) {
                                                            str2 = "[CloudArchive] ACTION_SEND_DATA EXCEPTION: " + e.getMessage();
                                                            ru.himik.nightscream.kascada.w.b.a(str, str2);
                                                        }
                                                    }
                                                } catch (Exception e5) {
                                                    e = e5;
                                                    bufferedWriter2 = bufferedWriter4;
                                                }
                                            } catch (Exception e6) {
                                                e = e6;
                                                bufferedWriter2 = bufferedWriter3;
                                            }
                                        } catch (Exception e7) {
                                            e = e7;
                                            bufferedWriter2 = bufferedWriter3;
                                            str = "Archive";
                                            if (this.D) {
                                                str2 = "[CloudArchive] ACTION_SEND_DATA EXCEPTION: " + e.getMessage();
                                                ru.himik.nightscream.kascada.w.b.a(str, str2);
                                            }
                                            System.currentTimeMillis();
                                            Thread.sleep(1L);
                                            bufferedWriter3 = bufferedWriter2;
                                            c5 = c3;
                                            bufferedReader2 = bufferedReader;
                                            c4 = 4;
                                        }
                                    } catch (Exception e8) {
                                        e = e8;
                                        bufferedReader = bufferedReader2;
                                        bufferedWriter2 = bufferedWriter3;
                                        str = "Archive";
                                        if (this.D) {
                                            str2 = "[CloudArchive] ACTION_SEND_DATA EXCEPTION: " + e.getMessage();
                                            ru.himik.nightscream.kascada.w.b.a(str, str2);
                                        }
                                        System.currentTimeMillis();
                                        Thread.sleep(1L);
                                        bufferedWriter3 = bufferedWriter2;
                                        c5 = c3;
                                        bufferedReader2 = bufferedReader;
                                        c4 = 4;
                                    }
                                } else {
                                    c3 = c;
                                    bufferedReader = bufferedReader2;
                                    bufferedWriter2 = bufferedWriter3;
                                    if (this.D) {
                                        str = "Archive";
                                        try {
                                            ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] ACTION_SEND_DATA countSend: " + this.C);
                                        } catch (Exception e9) {
                                            e = e9;
                                            if (this.D) {
                                                str2 = "[CloudArchive] ACTION_SEND_DATA EXCEPTION: " + e.getMessage();
                                                ru.himik.nightscream.kascada.w.b.a(str, str2);
                                            }
                                        }
                                    } else {
                                        str = "Archive";
                                    }
                                    JSONObject jSONObject4 = new JSONObject();
                                    this.f8643n = jSONObject4;
                                    jSONObject4.put("action", "checkWrite");
                                    bufferedWriter2.write(this.f8643n.toString());
                                    bufferedWriter2.newLine();
                                    bufferedWriter2.flush();
                                    this.f8642m = 3;
                                    if (this.D) {
                                        ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] ACTION_SEND_DATA->ACTION_READ_SEND_DATA");
                                    }
                                }
                            } catch (Exception e10) {
                                e = e10;
                                c3 = c;
                            }
                        }
                        try {
                            System.currentTimeMillis();
                            Thread.sleep(1L);
                        } catch (Exception e11) {
                            e = e11;
                            try {
                                if (this.D) {
                                    ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] SEND EXCEPTION " + e.getMessage());
                                }
                                bufferedWriter3 = bufferedWriter2;
                                bufferedReader2 = bufferedReader;
                                c5 = 4;
                            } catch (Exception e12) {
                                e = e12;
                                bufferedWriter3 = bufferedWriter2;
                                if (this.D) {
                                    ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] MAIN EXCEPTION " + e.getMessage());
                                }
                                socket = this.f8633d;
                                if (socket != null) {
                                    socket.close();
                                }
                                if (bufferedReader != null) {
                                    bufferedReader.close();
                                }
                                if (bufferedWriter3 != null) {
                                    bufferedWriter3.close();
                                }
                                bufferedReader2 = bufferedReader;
                                c5 = 4;
                            }
                        }
                    } catch (Exception e13) {
                        e = e13;
                        bufferedReader = bufferedReader2;
                        bufferedWriter2 = bufferedWriter3;
                        str = "Archive";
                    }
                }
                bufferedWriter3 = bufferedWriter2;
                c5 = c3;
                bufferedReader2 = bufferedReader;
            } else {
                char c6 = c;
                bufferedReader = bufferedReader2;
                bufferedWriter = bufferedWriter3;
                str = "Archive";
                try {
                    if (this.D) {
                        ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] CONNECT");
                    }
                    try {
                        this.f8633d.connect(this.f8635f, this.f8634e);
                        BufferedReader bufferedReader3 = new BufferedReader(new InputStreamReader(this.f8633d.getInputStream()));
                        try {
                            bufferedWriter3 = new BufferedWriter(new OutputStreamWriter(this.f8633d.getOutputStream()));
                            bufferedReader = bufferedReader3;
                            c2 = c6;
                        } catch (Exception e14) {
                            e = e14;
                            bufferedReader = bufferedReader3;
                            if (this.D) {
                                ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] STEP CONNECT EXCEPTION: " + e.getMessage());
                            }
                            try {
                                Thread.sleep(this.f8634e);
                                this.f8633d.close();
                                try {
                                    this.f8633d = null;
                                    if (bufferedReader != null) {
                                        bufferedReader.close();
                                    }
                                    if (bufferedWriter != null) {
                                        bufferedWriter.close();
                                    }
                                } catch (Exception unused2) {
                                }
                            } catch (Exception unused3) {
                            }
                            bufferedWriter3 = bufferedWriter;
                            c2 = 4;
                        }
                    } catch (Exception e15) {
                        e = e15;
                    }
                    try {
                        Socket socket3 = this.f8633d;
                        if (socket3 == null || !socket3.isConnected()) {
                            c5 = c2;
                            bufferedReader2 = bufferedReader;
                        } else {
                            bufferedReader2 = bufferedReader;
                            c5 = 2;
                        }
                    } catch (Exception e16) {
                        e = e16;
                        if (this.D) {
                            ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] MAIN EXCEPTION " + e.getMessage());
                        }
                        socket = this.f8633d;
                        if (socket != null) {
                            socket.close();
                        }
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                        if (bufferedWriter3 != null) {
                            bufferedWriter3.close();
                        }
                        bufferedReader2 = bufferedReader;
                        c5 = 4;
                    }
                } catch (Exception e17) {
                    e = e17;
                    bufferedWriter3 = bufferedWriter;
                    if (this.D) {
                        ru.himik.nightscream.kascada.w.b.a(str, "[CloudArchive] MAIN EXCEPTION " + e.getMessage());
                    }
                    socket = this.f8633d;
                    if (socket != null) {
                        socket.close();
                    }
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                    if (bufferedWriter3 != null) {
                        bufferedWriter3.close();
                    }
                    bufferedReader2 = bufferedReader;
                    c5 = 4;
                    c4 = 4;
                }
            }
            c4 = 4;
        }
        BufferedReader bufferedReader4 = bufferedReader2;
        BufferedWriter bufferedWriter5 = bufferedWriter3;
        if (this.D) {
            ru.himik.nightscream.kascada.w.b.a("Archive", "[CloudArchive] thread stop ");
        }
        try {
            Socket socket4 = this.f8633d;
            if (socket4 != null) {
                socket4.close();
            }
            if (bufferedReader4 != null) {
                bufferedReader4.close();
            }
            if (bufferedWriter5 != null) {
                bufferedWriter5.close();
            }
        } catch (IOException unused4) {
        }
    }
}
