package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextPaint;
import android.view.MotionEvent;
import java.nio.ByteBuffer;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class u extends androidx.appcompat.widget.y implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    int C;
    int D;
    private boolean E;
    private boolean F;
    Bitmap G;
    Paint H;
    Paint I;
    boolean J;
    int K;
    int L;
    int M;
    byte[] N;
    String O;
    boolean P;
    boolean Q;
    private long R;
    Paint S;
    int T;
    int U;
    int V;
    String W;
    boolean a0;
    int b0;
    String c0;
    int d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f8897e;
    int e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8898f;
    int f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8899g;
    String g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8900h;
    String h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public byte f8901i;
    public Point i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    Context f8902j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public b f8903k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    float f8904l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8905m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    boolean f8906n;
    int o;

    public u(Context context) {
        super(context);
        this.f8897e = getResources().getString(R.string.custom_register);
        this.f8898f = 4;
        this.f8901i = (byte) 3;
        this.f8903k = new b();
        this.f8904l = 0.0f;
        this.f8905m = 0;
        this.f8906n = false;
        this.o = 5;
        this.C = 0;
        this.G = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.H = new Paint();
        this.I = new Paint();
        this.J = false;
        this.K = 0;
        this.L = 0;
        this.M = 1;
        this.N = new byte[4];
        this.O = "0";
        this.P = false;
        this.Q = false;
        this.R = 0L;
        this.W = "";
        this.b0 = 0;
        this.c0 = "";
        this.i0 = new Point();
        this.f8902j = context;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.i0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void f(float f2) {
        String formatTextFloat;
        try {
            int i2 = this.M;
            if (i2 != 0) {
                if (i2 == 1) {
                    String str = ((int) f2) + "";
                    this.c0 = str;
                    this.b0 = str.length();
                    if (this.c0.length() <= this.o) {
                        for (int i3 = 0; i3 < this.o - this.b0; i3++) {
                            this.c0 = "0" + this.c0;
                        }
                    } else {
                        String str2 = this.c0;
                        this.c0 = str2.substring(0, str2.length() - (this.c0.length() - this.o));
                    }
                    if (this.C > 0) {
                        StringBuilder sb = new StringBuilder();
                        String str3 = this.c0;
                        sb.append(str3.substring(0, str3.length() - this.C));
                        sb.append(".");
                        String str4 = this.c0;
                        sb.append(str4.substring(str4.length() - this.C, this.c0.length()));
                        this.c0 = sb.toString();
                    }
                    formatTextFloat = this.c0;
                } else if (i2 != 2) {
                    if (i2 == 3) {
                        g(0);
                    }
                } else if (f2 >= 0.0f || this.C == 0) {
                    formatTextFloat = getFormatTextFloat();
                } else {
                    formatTextFloat = "-" + getFormatTextFloat();
                }
                this.O = formatTextFloat;
            } else {
                String str5 = ((int) f2) + "";
                this.c0 = str5;
                this.b0 = str5.length();
                if (f2 < 0.0f) {
                    this.a0 = true;
                    String str6 = this.c0;
                    this.c0 = str6.substring(1, str6.length());
                }
                this.b0 = this.c0.length();
                if (this.c0.length() <= this.o) {
                    for (int i4 = 0; i4 < this.o - this.b0; i4++) {
                        this.c0 = "0" + this.c0;
                    }
                } else {
                    String str7 = this.c0;
                    this.c0 = str7.substring(0, str7.length() - (this.c0.length() - this.o));
                }
                if (this.C > 0) {
                    StringBuilder sb2 = new StringBuilder();
                    String str8 = this.c0;
                    sb2.append(str8.substring(0, str8.length() - this.C));
                    sb2.append(".");
                    String str9 = this.c0;
                    sb2.append(str9.substring(str9.length() - this.C, this.c0.length()));
                    this.c0 = sb2.toString();
                }
                this.O = this.a0 ? "-" + this.c0 : this.c0;
                this.a0 = false;
            }
        } catch (Exception unused) {
            this.O = "Error...";
            invalidate();
        }
        i();
        h();
        invalidate();
    }

    public void g(int i2) {
        this.O = i2 + "";
        i();
        h();
        invalidate();
    }

    public int getBackgroundColorReg() {
        return this.f8905m;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8903k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return getBackgroundColorReg();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8898f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    public int getDefaultHeight() {
        int iA = ru.himik.nightscream.kascada.Utils.q.a(40.0f, this.f8902j);
        this.f8900h = iA;
        return iA;
    }

    public int getDefaultWidth() {
        ru.himik.nightscream.kascada.Utils.q.a(150.0f, this.f8902j);
        return this.f8900h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.L;
    }

    public int getDigit() {
        return this.o;
    }

    public int getDivisor() {
        return this.C;
    }

    String getFormatTextFloat() {
        StringBuilder sb;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(this.f8904l);
        String str = "";
        sb2.append("");
        this.c0 = sb2.toString();
        this.d0 = (int) Math.abs(this.f8904l);
        this.e0 = (this.d0 + "").length();
        String str2 = this.c0;
        String strSubstring = str2.substring(str2.indexOf(".") + 1);
        this.g0 = strSubstring;
        int length = strSubstring.length();
        this.f0 = length;
        this.h0 = "";
        int i2 = this.C;
        int i3 = 0;
        if (i2 == 0) {
            if (this.e0 > this.o) {
                while (i3 < this.o) {
                    this.h0 += "9";
                    i3++;
                }
                return this.h0;
            }
            return (this.f8904l + "").substring(0, (this.f8904l + "").indexOf("."));
        }
        if (this.e0 <= this.o - i2) {
            if (length < i2) {
                for (int i4 = 0; i4 < this.C - this.f0; i4++) {
                    str = str + "0";
                }
                this.g0 += str;
            }
            if (this.f0 > this.C) {
                String str3 = this.g0;
                this.g0 = str3.substring(0, str3.length() - (this.f0 - this.C));
            }
            return this.d0 + "." + this.g0;
        }
        while (true) {
            int i5 = this.o;
            if (i3 >= i5) {
                return this.h0;
            }
            if (i3 == i5 - this.C) {
                sb = new StringBuilder();
                sb.append(this.h0);
                sb.append(".9");
            } else {
                sb = new StringBuilder();
                sb.append(this.h0);
                sb.append("9");
            }
            this.h0 = sb.toString();
            i3++;
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8898f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8903k.l());
        jSONObject.put("addressRegister", this.f8903k.c());
        jSONObject.put("typeRequest", (int) this.f8903k.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("digit", getDigit());
        jSONObject.put("divisor", getDivisor());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("type", getType());
        jSONObject.put("fontChange", m());
        jSONObject.put("enableFrameRegister", l());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8899g;
    }

    public int getNumScreen() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.i0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8903k.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8903k.l() >= 100) {
            this.f8903k.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8903k.c();
        }
        this.f8903k.u((byte) MyApplication.b().E.get(this.f8903k.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8903k.b()) + "#" + this.f8903k.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8903k.l() >= 0) {
            if (this.f8903k.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8903k.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.R;
    }

    public int getType() {
        return this.M;
    }

    public float getValue() {
        return this.f8904l;
    }

    void h() {
        this.S.setTextScaleX(1.0f);
        Rect rect = new Rect();
        Paint paint = this.S;
        String str = this.W;
        paint.getTextBounds(str, 0, str.length(), rect);
        int i2 = (int) ((rect.right - rect.left) * 1.1f);
        int i3 = rect.bottom;
        this.T = i3 + ((this.V - (i3 - rect.top)) / 2);
        this.S.setTextScaleX(((this.U - getPaddingLeft()) - getPaddingRight()) / i2);
    }

    void i() {
        this.W = "";
        if (this.M == 3) {
            this.W = "т2147483648";
        } else {
            for (int i2 = 0; i2 < this.o; i2++) {
                this.W += "0";
            }
            if (this.C > 0 && this.M != 2) {
                this.W += ".";
            }
            int i3 = this.M;
            if (i3 == 0 || i3 == 1) {
                this.W += "-";
            }
            if (this.M == 2) {
                this.W += "-.";
            }
            if (this.W.length() == 0) {
                return;
            }
        }
        this.S.setTextSize(100.0f);
        this.S.setTextScaleX(1.0f);
        Rect rect = new Rect();
        Paint paint = this.S;
        String str = this.W;
        paint.getTextBounds(str, 0, str.length(), rect);
        this.S.setTextSize(((this.V * 0.7f) / (rect.bottom - rect.top)) * 100.0f);
    }

    public float j(byte[] bArr) {
        return ByteBuffer.wrap(bArr).getFloat();
    }

    public void k(int i2, int i3, int i4, boolean z) {
        TextPaint textPaint = new TextPaint();
        this.S = textPaint;
        textPaint.setTextAlign(Paint.Align.CENTER);
        this.S.setAntiAlias(true);
        setPadding(10, 10, 10, 10);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            setTextSize(1, 25.0f);
            f(this.f8904l);
            setBackgroundColor(0);
        }
        setKey(i4);
        setGravity(17);
        setFont("");
    }

    public boolean l() {
        return this.Q;
    }

    public boolean m() {
        return this.P;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.F) {
            this.I.setColor(-65536);
            this.I.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.I);
        }
        if (this.E && mbCanvas.g1) {
            canvas.drawBitmap(this.G, getWidth() - this.G.getWidth(), getHeight() - this.G.getHeight(), this.H);
        }
        if (this.J) {
            this.I.setColor(-16711936);
            this.I.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.I);
        }
        canvas.drawText(this.O, this.U / 2, this.V - this.T, this.S);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        this.U = i2;
        this.V = i3;
        i();
        h();
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.J;
    }

    public void setBackgroundColorReg(int i2) {
        this.f8905m = i2;
    }

    public void setConnectionError(boolean z) {
        this.F = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.E = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.J = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.K = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.L = i2;
    }

    public void setDigit(int i2) {
        this.o = i2;
        f(this.f8904l);
        i();
        h();
        invalidate();
        f(this.f8904l);
    }

    public void setDivisor(int i2) {
        this.C = i2;
        f(this.f8904l);
        i();
        h();
        invalidate();
        f(this.f8904l);
    }

    public void setEnableFrameRegister(boolean z) {
        this.Q = z;
        if (!z) {
            setBackgroundColor(this.f8905m);
            return;
        }
        int i2 = Build.VERSION.SDK_INT;
        Drawable drawable = i2 >= 21 ? getResources().getDrawable(R.drawable.bg_text, null) : getResources().getDrawable(R.drawable.bg_text);
        if (i2 < 16) {
            setBackgroundDrawable(drawable);
        } else {
            setBackground(drawable);
        }
    }

    public void setFont(String str) {
        Paint paint;
        Typeface typefaceCreateFromAsset;
        if (this.P) {
            paint = this.S;
            typefaceCreateFromAsset = Typeface.DEFAULT;
        } else {
            paint = this.S;
            typefaceCreateFromAsset = Typeface.createFromAsset(this.f8902j.getAssets(), "fonts/sf_digital_readout_heavy.ttf");
        }
        paint.setTypeface(typefaceCreateFromAsset);
        i();
        h();
        invalidate();
    }

    public void setFontChange(boolean z) {
        this.P = z;
        setFont("");
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8899g = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8903k.G(i2);
        this.D = i2;
    }

    @Override // android.widget.TextView
    public void setTextColor(int i2) {
        super.setTextColor(i2);
        this.S.setColor(i2);
        invalidate();
    }

    public void setTimeOut(boolean z) {
        if (this.f8906n != z) {
            this.f8906n = z;
            setBackgroundColor(z ? -65536 : this.f8905m);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.R = j2;
    }

    public void setType(int i2) {
        if (i2 != 2) {
            if (i2 != 3) {
                this.f8903k.z((byte) 1);
            } else {
                this.f8903k.z((byte) 2);
            }
            this.f8903k.K(0);
        } else {
            this.f8903k.z((byte) 2);
            this.f8903k.K(1);
        }
        this.M = i2;
    }

    public void setValue(int[] iArr) {
        float fJ;
        int i2 = this.M;
        if (i2 == 0) {
            fJ = (short) ((iArr[0] * 256) + iArr[1]);
            if (this.f8904l == fJ) {
                return;
            }
        } else if (i2 == 1) {
            fJ = (char) ((iArr[0] * 256) + iArr[1]);
            if (this.f8904l == fJ) {
                return;
            }
        } else {
            if (i2 != 2) {
                if (i2 != 3) {
                    return;
                }
                setTimeOut(false);
                g((iArr[0] * 256 * 256 * 256) + (iArr[1] * 256 * 256) + (iArr[2] * 256) + iArr[3]);
                return;
            }
            byte[] bArr = this.N;
            bArr[0] = (byte) iArr[0];
            bArr[1] = (byte) iArr[1];
            bArr[2] = (byte) iArr[2];
            bArr[3] = (byte) iArr[3];
            if (this.f8904l == j(bArr)) {
                return;
            } else {
                fJ = j(this.N);
            }
        }
        this.f8904l = fJ;
        f(fJ);
        setTimeOut(false);
    }
}
