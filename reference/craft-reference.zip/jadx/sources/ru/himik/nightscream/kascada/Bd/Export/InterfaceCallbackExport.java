package ru.himik.nightscream.kascada.Bd.Export;

/* JADX INFO: loaded from: classes.dex */
public interface InterfaceCallbackExport {
    void showError(String str);

    void showFileCreated(String str);

    void showInWork();

    void showUploadInWork();

    void showUploadSuccessful(String str);
}
