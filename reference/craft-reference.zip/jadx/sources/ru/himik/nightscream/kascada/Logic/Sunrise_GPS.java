package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import java.util.Calendar;
import java.util.TimeZone;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;

/* JADX INFO: loaded from: classes2.dex */
public class Sunrise_GPS extends f {
    String V;
    int W;
    float a0;
    float b0;
    int c0;
    f.h.a.d.a d0;
    f.h.a.a e0;
    long f0;

    public Sunrise_GPS(Context context) {
        super(context);
        this.V = "Sunrise";
        this.W = 1;
        this.a0 = 0.0f;
        this.b0 = 0.0f;
        this.c0 = 0;
        this.d0 = null;
        this.e0 = null;
        this.f0 = 0L;
    }

    public Sunrise_GPS(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = "Sunrise";
        this.W = 1;
        this.a0 = 0.0f;
        this.b0 = 0.0f;
        this.c0 = 0;
        this.d0 = null;
        this.e0 = null;
        this.f0 = 0L;
    }

    public int getActionExecute() {
        return this.W;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("type", getActionExecute());
        jSONObject.put("latitude", this.a0);
        jSONObject.put("longitude", this.b0);
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    public float getLatitude() {
        return this.a0;
    }

    public float getLongitude() {
        return this.b0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        try {
            if (System.currentTimeMillis() - this.f0 >= 10000) {
                this.f0 = System.currentTimeMillis();
                u();
            }
            return Integer.valueOf(this.c0);
        } catch (Exception unused) {
            return 0;
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 127;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawRect(this.G, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawRect(this.G, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        canvas.drawLine(getWidth() - this.Q, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        String str;
        int i4 = this.W;
        if (i4 != 1) {
            str = i4 == 2 ? "SS" : "SR";
            super.onMeasure(i2, i3);
        }
        this.E = str;
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
        String str;
        this.W = i2;
        if (i2 != 1) {
            str = i2 == 2 ? "SS" : "SR";
            invalidate();
        }
        this.E = str;
        invalidate();
    }

    public void setLatitude(float f2) {
        this.a0 = f2;
    }

    public void setLongitude(float f2) {
        this.b0 = f2;
    }

    public void u() {
        String strReplace;
        try {
            float f2 = this.a0;
            if (f2 == 0.0f && this.b0 == 0.0f) {
                this.c0 = 0;
                return;
            }
            f.h.a.d.a aVar = new f.h.a.d.a(f2, this.b0);
            this.d0 = aVar;
            f.h.a.a aVar2 = new f.h.a.a(aVar, TimeZone.getDefault());
            this.e0 = aVar2;
            int i2 = this.W;
            if (i2 == 1) {
                strReplace = aVar2.a(Calendar.getInstance()).replace(":", "");
            } else if (i2 != 2) {
                return;
            } else {
                strReplace = aVar2.b(Calendar.getInstance()).replace(":", "");
            }
            this.c0 = Integer.parseInt(strReplace);
        } catch (Exception unused) {
        }
    }
}
