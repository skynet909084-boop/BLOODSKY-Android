package ru.himik.nightscream.kascada.q.f.a;

/* JADX INFO: loaded from: classes.dex */
public enum c {
    ON_CONNECT(0),
    DISCONNECT(1),
    SETTING(2),
    ON_CLICK(3),
    CHANGE_SCREEN(4),
    MSG(5),
    CONTROLS(6);


    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final int f9282i;

    c(int i2) {
        this.f9282i = i2;
    }

    public final int getI() {
        return this.f9282i;
    }
}
