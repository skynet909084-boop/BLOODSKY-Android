package ru.himik.nightscream.kascada.Utils;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.LinkedHashMap;
import java.util.Objects;
import kotlin.b0.d.v;
import ru.himik.nightscream.kascada.Bd.Export.ExportPresenter;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class ShowQrCode extends androidx.appcompat.app.d {
    public ru.himik.nightscream.kascada.d0.a a;

    private final Bitmap f(String str, int i2) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(f.f.c.g.CHARACTER_SET, "utf-8");
        linkedHashMap.put(f.f.c.g.MARGIN, 0);
        f.f.c.y.b bVarA = new f.f.c.l().a(str, f.f.c.a.QR_CODE, i2, i2, linkedHashMap);
        int iN = bVarA.n();
        int iJ = bVarA.j();
        int[] iArr = new int[iN * iJ];
        int i3 = 0;
        while (i3 < iJ) {
            int i4 = i3 + 1;
            int i5 = 0;
            while (i5 < iN) {
                int i6 = i5 + 1;
                if (bVarA.e(i5, i3)) {
                    iArr[(i3 * iN) + i5] = -16777216;
                } else {
                    iArr[(i3 * iN) + i5] = -1;
                }
                i5 = i6;
            }
            i3 = i4;
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(iN, iJ, Bitmap.Config.ARGB_8888);
        bitmapCreateBitmap.setPixels(iArr, 0, iN, 0, 0, iN, iJ);
        kotlin.b0.d.j.c(bitmapCreateBitmap, "bitmap");
        return bitmapCreateBitmap;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void j(ShowQrCode showQrCode, View view) {
        kotlin.b0.d.j.d(showQrCode, "this$0");
        showQrCode.onBackPressed();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void k(ShowQrCode showQrCode, v vVar, View view) {
        kotlin.b0.d.j.d(showQrCode, "this$0");
        kotlin.b0.d.j.d(vVar, "$url");
        Object systemService = showQrCode.getSystemService("clipboard");
        Objects.requireNonNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
        ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText("UrlKaScada", (CharSequence) vVar.a));
        g.a.a.e.d(MyApplication.b().h0, showQrCode.getString(R.string.copied), 1).show();
    }

    public final ru.himik.nightscream.kascada.d0.a g() {
        ru.himik.nightscream.kascada.d0.a aVar = this.a;
        if (aVar != null) {
            return aVar;
        }
        kotlin.b0.d.j.m("binding");
        throw null;
    }

    public final void l(ru.himik.nightscream.kascada.d0.a aVar) {
        kotlin.b0.d.j.d(aVar, "<set-?>");
        this.a = aVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ru.himik.nightscream.kascada.d0.a aVarC = ru.himik.nightscream.kascada.d0.a.c(getLayoutInflater());
        kotlin.b0.d.j.c(aVarC, "inflate(layoutInflater)");
        l(aVarC);
        ConstraintLayout constraintLayoutB = g().b();
        kotlin.b0.d.j.c(constraintLayoutB, "binding.root");
        setContentView(constraintLayoutB);
        getWindow().setFlags(1024, 1024);
        View viewFindViewById = findViewById(R.id.toolbar);
        Objects.requireNonNull(viewFindViewById, "null cannot be cast to non-null type androidx.appcompat.widget.Toolbar");
        Toolbar toolbar = (Toolbar) viewFindViewById;
        toolbar.setTitle(getResources().getString(R.string.kascada));
        toolbar.setSubtitle(getString(R.string.qr_project_code));
        setSupportActionBar(toolbar);
        androidx.appcompat.app.a supportActionBar = getSupportActionBar();
        kotlin.b0.d.j.b(supportActionBar);
        supportActionBar.s(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Utils.j
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ShowQrCode.j(this.a, view);
            }
        });
        final v vVar = new v();
        String stringExtra = getIntent().getStringExtra("URL");
        String strI = kotlin.b0.d.j.i(ExportPresenter.URL_UPLOAD_PROJECT_FILES_DIR, stringExtra == null ? null : kotlin.i0.q.w(stringExtra, "\\", "/", false, 4, null));
        T t = strI;
        if (strI == null) {
            t = "";
        }
        vVar.a = t;
        g().c.setImageBitmap(f((String) vVar.a, 400));
        g().f9194d.setText((CharSequence) vVar.a);
        g().b.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Utils.k
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ShowQrCode.k(this.a, vVar, view);
            }
        });
    }
}
