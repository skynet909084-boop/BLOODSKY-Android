package ru.himik.nightscream.kascada.r;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b0 extends DialogFragment {
    EditText C;
    CheckBox D;
    CheckBox E;
    CheckBox F;
    EditText G;
    Button H;
    private FB_MACRO I;
    EditText J;
    View.OnClickListener K = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.e
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.d(view);
        }
    };
    View.OnClickListener L = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.h
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.f(view);
        }
    };
    View.OnClickListener M = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.g
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.h(view);
        }
    };
    View.OnClickListener N = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.b
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.j(view);
        }
    };
    View.OnClickListener O = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.f
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.l(view);
        }
    };
    View.OnClickListener P = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.d
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            this.a.n(view);
        }
    };
    CheckBox a;
    CheckBox b;
    CheckBox c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    EditText f9289d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    CheckBox f9290e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    CheckBox f9291f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    CheckBox f9292g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    EditText f9293h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    CheckBox f9294i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    CheckBox f9295j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    CheckBox f9296k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    EditText f9297l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    CheckBox f9298m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    CheckBox f9299n;
    CheckBox o;

    private void b() {
        ArrayList arrayList = new ArrayList();
        if (this.a.isChecked() || this.b.isChecked() || this.c.isChecked()) {
            this.I.E.h(this.f9289d.getText().toString());
            if (this.a.isChecked()) {
                this.I.E.i(1);
            }
            if (this.b.isChecked()) {
                this.I.E.i(2);
            }
            if (this.c.isChecked()) {
                this.I.E.i(3);
            }
            arrayList.add(this.I.E);
        }
        if (this.f9290e.isChecked() || this.f9291f.isChecked() || this.f9292g.isChecked()) {
            this.I.F.h(this.f9293h.getText().toString());
            if (this.f9290e.isChecked()) {
                this.I.F.i(1);
            }
            if (this.f9291f.isChecked()) {
                this.I.F.i(2);
            }
            if (this.f9292g.isChecked()) {
                this.I.F.i(3);
            }
            arrayList.add(this.I.F);
        }
        if (this.f9294i.isChecked() || this.f9295j.isChecked() || this.f9296k.isChecked()) {
            this.I.G.h(this.f9297l.getText().toString());
            if (this.f9294i.isChecked()) {
                this.I.G.i(1);
            }
            if (this.f9295j.isChecked()) {
                this.I.G.i(2);
            }
            if (this.f9296k.isChecked()) {
                this.I.G.i(3);
            }
            arrayList.add(this.I.G);
        }
        if (this.f9298m.isChecked() || this.f9299n.isChecked() || this.o.isChecked()) {
            this.I.H.h(this.C.getText().toString());
            if (this.f9298m.isChecked()) {
                this.I.H.i(1);
            }
            if (this.f9299n.isChecked()) {
                this.I.H.i(2);
            }
            if (this.o.isChecked()) {
                this.I.H.i(3);
            }
            arrayList.add(this.I.H);
        }
        if (this.D.isChecked() || this.E.isChecked() || this.F.isChecked()) {
            this.I.I.h(this.G.getText().toString());
            if (this.D.isChecked()) {
                this.I.I.i(1);
            }
            if (this.E.isChecked()) {
                this.I.I.i(2);
            }
            if (this.F.isChecked()) {
                this.I.I.i(3);
            }
        } else {
            this.I.I.i(1);
        }
        int size = arrayList.size();
        if (size == 1) {
            this.I.E = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(0);
        } else if (size == 2) {
            this.I.E = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(0);
            this.I.F = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(1);
        } else if (size == 3) {
            this.I.E = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(0);
            this.I.F = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(1);
            this.I.G = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(2);
        } else if (size == 4) {
            this.I.E = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(0);
            this.I.F = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(1);
            this.I.G = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(2);
            this.I.H = (ru.himik.nightscream.kascada.Logic.c.e.a) arrayList.get(3);
        }
        this.I.t(arrayList.size(), true);
        arrayList.clear();
        this.I.setName(this.J.getText().toString());
        ((mbCanvas) getActivity()).z(this.I);
        dismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void d(View view) {
        CheckBox checkBox;
        CheckBox checkBox2;
        switch (view.getId()) {
            case R.id.ch_B /* 2131296472 */:
                checkBox = this.b;
                break;
            case R.id.ch_F /* 2131296473 */:
                this.a.setChecked(false);
                checkBox2 = this.b;
                checkBox2.setChecked(false);
            case R.id.ch_I /* 2131296474 */:
                checkBox = this.a;
                break;
            default:
                return;
        }
        checkBox.setChecked(false);
        checkBox2 = this.c;
        checkBox2.setChecked(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void f(View view) {
        CheckBox checkBox;
        CheckBox checkBox2;
        switch (view.getId()) {
            case R.id.ch_B /* 2131296472 */:
                checkBox = this.f9291f;
                break;
            case R.id.ch_F /* 2131296473 */:
                this.f9290e.setChecked(false);
                checkBox2 = this.f9291f;
                checkBox2.setChecked(false);
            case R.id.ch_I /* 2131296474 */:
                checkBox = this.f9290e;
                break;
            default:
                return;
        }
        checkBox.setChecked(false);
        checkBox2 = this.f9292g;
        checkBox2.setChecked(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void h(View view) {
        CheckBox checkBox;
        CheckBox checkBox2;
        switch (view.getId()) {
            case R.id.ch_B /* 2131296472 */:
                checkBox = this.f9295j;
                break;
            case R.id.ch_F /* 2131296473 */:
                this.f9294i.setChecked(false);
                checkBox2 = this.f9295j;
                checkBox2.setChecked(false);
            case R.id.ch_I /* 2131296474 */:
                checkBox = this.f9294i;
                break;
            default:
                return;
        }
        checkBox.setChecked(false);
        checkBox2 = this.f9296k;
        checkBox2.setChecked(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void j(View view) {
        CheckBox checkBox;
        CheckBox checkBox2;
        switch (view.getId()) {
            case R.id.ch_B /* 2131296472 */:
                checkBox = this.f9299n;
                break;
            case R.id.ch_F /* 2131296473 */:
                this.f9298m.setChecked(false);
                checkBox2 = this.f9299n;
                checkBox2.setChecked(false);
            case R.id.ch_I /* 2131296474 */:
                checkBox = this.f9298m;
                break;
            default:
                return;
        }
        checkBox.setChecked(false);
        checkBox2 = this.o;
        checkBox2.setChecked(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: k, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void l(View view) {
        switch (view.getId()) {
            case R.id.ch_B /* 2131296472 */:
                this.D.setChecked(true);
                this.E.setChecked(false);
                break;
            case R.id.ch_F /* 2131296473 */:
                this.D.setChecked(false);
                this.E.setChecked(false);
                this.F.setChecked(true);
                return;
            case R.id.ch_I /* 2131296474 */:
                this.D.setChecked(false);
                this.E.setChecked(true);
                break;
            default:
                return;
        }
        this.F.setChecked(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void n(View view) {
        if (a(this.J.getText().toString())) {
            return;
        }
        if (!ru.himik.nightscream.kascada.Utils.n.a.a(this.J.getText().toString())) {
            b();
            return;
        }
        androidx.appcompat.app.c.a aVar = new androidx.appcompat.app.c.a(getActivity());
        aVar.k(MyApplication.b().h0.getString(R.string.overwrite_macros_file) + " " + this.J.getText().toString() + "?");
        aVar.f(MyApplication.b().h0.getString(R.string.info_macros_name_use_in_library));
        aVar.i(MyApplication.b().h0.getString(R.string.yes), new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.c
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                this.a.p(dialogInterface, i2);
            }
        });
        aVar.g(MyApplication.b().h0.getString(R.string.no), new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.i
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.dismiss();
            }
        });
        aVar.a().show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: o, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void p(DialogInterface dialogInterface, int i2) {
        b();
        dialogInterface.dismiss();
    }

    public boolean a(String str) {
        boolean z = false;
        for (int i2 = 0; i2 < MyApplication.b().D.size(); i2++) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = MyApplication.b().D.get(MyApplication.b().D.keyAt(i2));
            if (aVar.getTypeFb() == 135 && str.equals(aVar.getName())) {
                z = true;
                break;
            }
        }
        if (z) {
            Toast.makeText(MyApplication.b().h0, getResources().getString(R.string.this_macro_name_used), 1).show();
        }
        return z;
    }

    @Override // android.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        getDialog().getWindow().requestFeature(1);
        getDialog().setCanceledOnTouchOutside(false);
        return layoutInflater.inflate(R.layout.create_macro, viewGroup, false);
    }

    @Override // android.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
    }

    @Override // android.app.DialogFragment, android.app.Fragment
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(-1, -1);
        }
    }

    @Override // android.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        setCancelable(false);
        this.J = (EditText) view.findViewById(R.id.nameMacro);
        ViewGroup viewGroup = (ViewGroup) view.findViewById(R.id.item_in1);
        this.a = (CheckBox) viewGroup.findViewById(R.id.ch_B);
        this.b = (CheckBox) viewGroup.findViewById(R.id.ch_I);
        this.c = (CheckBox) viewGroup.findViewById(R.id.ch_F);
        this.f9289d = (EditText) viewGroup.findViewById(R.id.eName);
        ((TextView) viewGroup.findViewById(R.id.title)).setText(getString(R.string.dialog_create_macro_title_name_in) + " 1");
        this.f9289d.setText("in 1");
        ViewGroup viewGroup2 = (ViewGroup) view.findViewById(R.id.item_in2);
        this.f9290e = (CheckBox) viewGroup2.findViewById(R.id.ch_B);
        this.f9291f = (CheckBox) viewGroup2.findViewById(R.id.ch_I);
        this.f9292g = (CheckBox) viewGroup2.findViewById(R.id.ch_F);
        this.f9293h = (EditText) viewGroup2.findViewById(R.id.eName);
        ((TextView) viewGroup2.findViewById(R.id.title)).setText(getString(R.string.dialog_create_macro_title_name_in) + " 2");
        this.f9293h.setText("in 2");
        ViewGroup viewGroup3 = (ViewGroup) view.findViewById(R.id.item_in3);
        this.f9294i = (CheckBox) viewGroup3.findViewById(R.id.ch_B);
        this.f9295j = (CheckBox) viewGroup3.findViewById(R.id.ch_I);
        this.f9296k = (CheckBox) viewGroup3.findViewById(R.id.ch_F);
        this.f9297l = (EditText) viewGroup3.findViewById(R.id.eName);
        ((TextView) viewGroup3.findViewById(R.id.title)).setText(getString(R.string.dialog_create_macro_title_name_in) + " 3");
        this.f9297l.setText("in 3");
        ViewGroup viewGroup4 = (ViewGroup) view.findViewById(R.id.item_in4);
        this.f9298m = (CheckBox) viewGroup4.findViewById(R.id.ch_B);
        this.f9299n = (CheckBox) viewGroup4.findViewById(R.id.ch_I);
        this.o = (CheckBox) viewGroup4.findViewById(R.id.ch_F);
        this.C = (EditText) viewGroup4.findViewById(R.id.eName);
        ((TextView) viewGroup4.findViewById(R.id.title)).setText(getString(R.string.dialog_create_macro_title_name_in) + " 4");
        this.C.setText("in 4");
        ViewGroup viewGroup5 = (ViewGroup) view.findViewById(R.id.item_out);
        this.D = (CheckBox) viewGroup5.findViewById(R.id.ch_B);
        this.E = (CheckBox) viewGroup5.findViewById(R.id.ch_I);
        this.F = (CheckBox) viewGroup5.findViewById(R.id.ch_F);
        this.G = (EditText) viewGroup5.findViewById(R.id.eName);
        ((TextView) viewGroup5.findViewById(R.id.title)).setText(getString(R.string.dialog_create_macro_title_name_out));
        this.G.setText("out");
        this.a.setOnClickListener(this.K);
        this.b.setOnClickListener(this.K);
        this.c.setOnClickListener(this.K);
        this.f9290e.setOnClickListener(this.L);
        this.f9291f.setOnClickListener(this.L);
        this.f9292g.setOnClickListener(this.L);
        this.f9294i.setOnClickListener(this.M);
        this.f9295j.setOnClickListener(this.M);
        this.f9296k.setOnClickListener(this.M);
        this.f9298m.setOnClickListener(this.N);
        this.f9299n.setOnClickListener(this.N);
        this.o.setOnClickListener(this.N);
        this.D.setOnClickListener(this.O);
        this.E.setOnClickListener(this.O);
        this.F.setOnClickListener(this.O);
        Button button = (Button) view.findViewById(R.id.bCreateMacro);
        this.H = button;
        button.setOnClickListener(this.P);
    }

    public void r(FB_MACRO fb_macro) {
        this.I = fb_macro;
    }
}
