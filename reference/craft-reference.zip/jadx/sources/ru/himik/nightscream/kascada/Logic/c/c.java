package ru.himik.nightscream.kascada.Logic.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.z;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class c extends View implements a, ru.himik.nightscream.kascada.s.a, z {
    public int C;
    public boolean D;
    public int E;
    public int F;
    public Paint G;
    public int H;
    public int I;
    public int J;
    private long K;
    public String L;
    public String M;
    public int N;
    public String O;
    public int P;
    public String Q;
    public int R;
    public Paint S;
    public int T;
    public int U;
    public RectF V;
    public TextPaint W;
    String a;
    public float a0;
    long b;
    public int b0;
    public int c;
    public Point c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8972d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f8973e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8974f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public a f8975g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public a f8976h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public a f8977i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8978j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Point f8979k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Point f8980l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Point f8981m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f8982n;
    public int o;

    public c(Context context) {
        super(context);
        this.a = "";
        this.b = 0L;
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width));
        this.f8972d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height));
        this.f8973e = false;
        this.f8978j = 0;
        this.f8979k = new Point(0, 0);
        this.f8980l = new Point(0, 0);
        this.f8981m = new Point(0, 0);
        this.f8982n = 1;
        this.o = 0;
        this.C = -1;
        this.D = false;
        this.E = 0;
        this.F = 0;
        this.G = new Paint();
        this.H = -1;
        this.I = -1;
        this.J = -1;
        this.K = 0L;
        this.L = IMAPStore.ID_NAME;
        this.M = "";
        this.N = 0;
        this.O = "";
        this.P = 0;
        this.Q = "";
        this.R = 0;
        new Paint();
        this.S = new Paint();
        this.T = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.U = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.V = new RectF();
        this.W = new TextPaint();
        this.a0 = 0.0f;
        this.b0 = (int) getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.c0 = new Point();
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width));
        this.f8972d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height));
    }

    public c(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = "";
        this.b = 0L;
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width));
        this.f8972d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height));
        this.f8973e = false;
        this.f8978j = 0;
        this.f8979k = new Point(0, 0);
        this.f8980l = new Point(0, 0);
        this.f8981m = new Point(0, 0);
        this.f8982n = 1;
        this.o = 0;
        this.C = -1;
        this.D = false;
        this.E = 0;
        this.F = 0;
        this.G = new Paint();
        this.H = -1;
        this.I = -1;
        this.J = -1;
        this.K = 0L;
        this.L = IMAPStore.ID_NAME;
        this.M = "";
        this.N = 0;
        this.O = "";
        this.P = 0;
        this.Q = "";
        this.R = 0;
        new Paint();
        this.S = new Paint();
        this.T = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.U = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.V = new RectF();
        this.W = new TextPaint();
        this.a0 = 0.0f;
        this.b0 = (int) getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.c0 = new Point();
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.c = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_width)));
            this.f8972d = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_height)));
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void a() {
        a aVar = this.f8975g;
        if (aVar != null) {
            aVar.m();
        }
        a aVar2 = this.f8976h;
        if (aVar2 != null) {
            aVar2.m();
        }
        a aVar3 = this.f8977i;
        if (aVar3 != null) {
            aVar3.k(this.f8978j);
        }
    }

    public void b() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void c() {
        a aVar = this.f8977i;
        if (aVar != null) {
            aVar.k(this.f8978j);
            this.f8977i = null;
        }
        this.C = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void d(a aVar, int i2) {
        if (i2 == 1) {
            this.f8975g = aVar;
        }
        if (i2 == 2) {
            this.f8976h = aVar;
        }
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.c0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void e(a aVar) {
        this.f8977i = aVar;
        this.C = aVar.getKey();
    }

    public void f() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean g() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return null;
    }

    public int getCountIn() {
        return 2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return getTypeFb();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return getNumScreen();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.E;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getFreeIn() {
        if (this.f8975g == null) {
            return 1;
        }
        return this.f8976h == null ? 2 : 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return getTypeFb();
    }

    public Object getIn() {
        return null;
    }

    public a getIn1() {
        return this.f8975g;
    }

    public a getIn2() {
        return this.f8976h;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getInvertOut() {
        return this.f8973e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getJsonMacroOutIfNeed() {
        if (q() == null || q().getTypeFb() != 135) {
            return "";
        }
        FB_MACRO fb_macro = (FB_MACRO) q();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(IMAPStore.ID_NAME, fb_macro.getName());
            jSONObject.put("x", (int) fb_macro.getX());
            jSONObject.put("y", (int) fb_macro.getY());
            jSONObject.put("numScreen", fb_macro.getNumScreen());
            return jSONObject.toString();
        } catch (JSONException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public JSONObject getJsonOther() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a, ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8974f;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getKeyOut() {
        return this.C;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumOnIn() {
        return this.f8978j;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumScreen() {
        return this.f8982n;
    }

    public Object getOut() {
        return null;
    }

    public Point getPointIn1() {
        return null;
    }

    public Point getPointIn2() {
        return this.f8980l;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point getPointOut() {
        return this.f8981m;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.c0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getRootNameMacro() {
        return this.a;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public long getRootUniqueIdMacro() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdBeforeCopy() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdOutBeforeCopy() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveKey() {
        return this.o;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveNumInBeforeCopy() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.K;
    }

    public int getTypeFb() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return this.R;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getVarConstant() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public float getVarFloatConstant() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getVarIntConstant() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void i() {
        this.f8973e = !this.f8973e;
        invalidate();
    }

    public void j(int i2, int i3, int i4, boolean z) {
        getLayoutParams().height = this.f8972d;
        getLayoutParams().width = this.c;
        setY(i3 - (this.f8972d / 2));
        setX(i2 - (this.c / 2));
        setBackgroundColor(0);
        setKey(i4);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void k(int i2) {
        if (i2 == 1) {
            this.f8975g = null;
        }
        if (i2 == 2) {
            this.f8976h = null;
        }
    }

    public a l(int i2) {
        if (i2 == 1) {
            return this.f8975g;
        }
        if (i2 != 2) {
            return null;
        }
        return this.f8976h;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void m() {
        this.f8977i = null;
        this.f8978j = 0;
        this.C = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point n(int i2) {
        if (i2 == 1) {
            return this.f8979k;
        }
        return i2 == 2 ? this.f8980l : new Point((int) getX(), (int) getY());
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        if (i2 == 1) {
            return this.N;
        }
        if (i2 != 2) {
            return 0;
        }
        return this.P;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.D) {
            this.G.setColor(-16711936);
            this.G.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.G);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        this.W.setTextAlign(Paint.Align.CENTER);
        this.W.setTextSize(getResources().getDimension(R.dimen.text_size_root_fb));
        this.W.setColor(getResources().getColor(R.color.text_color_logic));
        this.a0 = ((this.W.descent() - this.W.ascent()) / 2.0f) - this.W.descent();
        setMeasuredDimension(this.c, this.f8972d);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public a q() {
        return this.f8977i;
    }

    public void r() {
        this.f8979k.set((int) getX(), ((int) getY()) + ((getHeight() / 3) / 2) + (getHeight() / 3));
        this.f8980l.set((int) getX(), ((int) getY()) + ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2));
        this.f8981m.set(((int) getX()) + getWidth(), ((int) getY()) + ((getHeight() / 3) / 2) + (getHeight() / 3));
    }

    public void s(String str, int i2) {
        this.M = str;
        this.N = i2;
    }

    public void setActionExecute(int i2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.D = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.E = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.F = i2;
    }

    public void setFont(String str) {
    }

    public void setIn(Object obj) {
    }

    public void setInvert(boolean z) {
        this.f8973e = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8974f = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setKeyOut(int i2) {
        if (i2 == this.o) {
            i2 = -1;
        }
        this.C = i2;
    }

    public void setName(String str) {
        this.L = str;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setNumOnIn(int i2) {
        this.f8978j = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8982n = i2;
    }

    public void setOut(Object obj) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootNameMacro(String str) {
        this.a = str;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootUniqueIdMacro(long j2) {
        this.b = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdBeforeCopy(int i2) {
        this.H = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdOutBeforeCopy(int i2) {
        this.J = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveKey(int i2) {
        this.o = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveNumInBeforeCopy(int i2) {
        this.I = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.K = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarFloatConstant(float f2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarIntConstant(int i2) {
    }

    public void t(String str, int i2) {
        this.O = str;
        this.P = i2;
    }

    public void u(String str, int i2) {
        this.Q = str;
        this.R = i2;
    }
}
