package ru.himik.nightscream.kascada.Bd;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import java.io.File;

/* JADX INFO: loaded from: classes.dex */
public class f extends SQLiteOpenHelper {
    public f(Context context, String str, String str2) {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS));
        String str3 = File.separator;
        sb.append(str3);
        sb.append("KaScada/Archive");
        sb.append(str3);
        sb.append(str);
        sb.append(str3);
        sb.append(str2);
        sb.append(".db");
        super(context, sb.toString(), (SQLiteDatabase.CursorFactory) null, 2);
    }

    private boolean a(SQLiteDatabase sQLiteDatabase, String str, String str2) {
        Cursor cursorRawQuery = null;
        try {
            cursorRawQuery = sQLiteDatabase.rawQuery("SELECT * FROM " + str + " LIMIT 0", null);
            if (cursorRawQuery.getColumnIndex(str2) != -1) {
                if (cursorRawQuery != null) {
                    cursorRawQuery.close();
                }
                return true;
            }
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            return false;
        } catch (Exception unused) {
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            return false;
        } catch (Throwable th) {
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            throw th;
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS Archive (_id integer primary key autoincrement,var1 text default '',var2 text default '',var3 text default '',var4 text default '',_time text default '00:00:00',_date text default '2000-01-01',var5 text default '');");
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i2, int i3) {
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i2, int i3) {
        if (a(sQLiteDatabase, "TableNameProject", "var5")) {
            return;
        }
        sQLiteDatabase.execSQL("ALTER TABLE Archive ADD var5 text DEFAULT ''");
    }
}
