package ru.himik.nightscream.kascada.q.f.a;

import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final int f9283h;
    private final int id;
    private final int key;
    private final String settings;
    private final int w;
    private final int x;
    private final int y;

    public static final class a {
        private final String max;
        private final String min;
        private final int password;
        private final int type;

        public a(int i2, int i3, String str, String str2) {
            j.d(str, "min");
            j.d(str2, "max");
            this.password = i2;
            this.type = i3;
            this.min = str;
            this.max = str2;
        }

        public static /* synthetic */ a copy$default(a aVar, int i2, int i3, String str, String str2, int i4, Object obj) {
            if ((i4 & 1) != 0) {
                i2 = aVar.password;
            }
            if ((i4 & 2) != 0) {
                i3 = aVar.type;
            }
            if ((i4 & 4) != 0) {
                str = aVar.min;
            }
            if ((i4 & 8) != 0) {
                str2 = aVar.max;
            }
            return aVar.copy(i2, i3, str, str2);
        }

        public final int component1() {
            return this.password;
        }

        public final int component2() {
            return this.type;
        }

        public final String component3() {
            return this.min;
        }

        public final String component4() {
            return this.max;
        }

        public final a copy(int i2, int i3, String str, String str2) {
            j.d(str, "min");
            j.d(str2, "max");
            return new a(i2, i3, str, str2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.password == aVar.password && this.type == aVar.type && j.a(this.min, aVar.min) && j.a(this.max, aVar.max);
        }

        public final String getMax() {
            return this.max;
        }

        public final String getMin() {
            return this.min;
        }

        public final int getPassword() {
            return this.password;
        }

        public final int getType() {
            return this.type;
        }

        public int hashCode() {
            return (((((this.password * 31) + this.type) * 31) + this.min.hashCode()) * 31) + this.max.hashCode();
        }

        public String toString() {
            return "SettingsEditNumber(password=" + this.password + ", type=" + this.type + ", min=" + this.min + ", max=" + this.max + ')';
        }
    }

    public static final class b {
        private final int max;

        public b(int i2) {
            this.max = i2;
        }

        public static /* synthetic */ b copy$default(b bVar, int i2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                i2 = bVar.max;
            }
            return bVar.copy(i2);
        }

        public final int component1() {
            return this.max;
        }

        public final b copy(int i2) {
            return new b(i2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof b) && this.max == ((b) obj).max;
        }

        public final int getMax() {
            return this.max;
        }

        public int hashCode() {
            return this.max;
        }

        public String toString() {
            return "SettingsSeekBar(max=" + this.max + ')';
        }
    }

    public d(int i2, int i3, int i4, int i5, int i6, int i7, String str) {
        this.id = i2;
        this.key = i3;
        this.x = i4;
        this.y = i5;
        this.w = i6;
        this.f9283h = i7;
        this.settings = str;
    }

    public static /* synthetic */ d copy$default(d dVar, int i2, int i3, int i4, int i5, int i6, int i7, String str, int i8, Object obj) {
        if ((i8 & 1) != 0) {
            i2 = dVar.id;
        }
        if ((i8 & 2) != 0) {
            i3 = dVar.key;
        }
        int i9 = i3;
        if ((i8 & 4) != 0) {
            i4 = dVar.x;
        }
        int i10 = i4;
        if ((i8 & 8) != 0) {
            i5 = dVar.y;
        }
        int i11 = i5;
        if ((i8 & 16) != 0) {
            i6 = dVar.w;
        }
        int i12 = i6;
        if ((i8 & 32) != 0) {
            i7 = dVar.f9283h;
        }
        int i13 = i7;
        if ((i8 & 64) != 0) {
            str = dVar.settings;
        }
        return dVar.copy(i2, i9, i10, i11, i12, i13, str);
    }

    public final int component1() {
        return this.id;
    }

    public final int component2() {
        return this.key;
    }

    public final int component3() {
        return this.x;
    }

    public final int component4() {
        return this.y;
    }

    public final int component5() {
        return this.w;
    }

    public final int component6() {
        return this.f9283h;
    }

    public final String component7() {
        return this.settings;
    }

    public final d copy(int i2, int i3, int i4, int i5, int i6, int i7, String str) {
        return new d(i2, i3, i4, i5, i6, i7, str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return this.id == dVar.id && this.key == dVar.key && this.x == dVar.x && this.y == dVar.y && this.w == dVar.w && this.f9283h == dVar.f9283h && j.a(this.settings, dVar.settings);
    }

    public final int getH() {
        return this.f9283h;
    }

    public final int getId() {
        return this.id;
    }

    public final int getKey() {
        return this.key;
    }

    public final String getSettings() {
        return this.settings;
    }

    public final int getW() {
        return this.w;
    }

    public final int getX() {
        return this.x;
    }

    public final int getY() {
        return this.y;
    }

    public int hashCode() {
        int i2 = ((((((((((this.id * 31) + this.key) * 31) + this.x) * 31) + this.y) * 31) + this.w) * 31) + this.f9283h) * 31;
        String str = this.settings;
        return i2 + (str == null ? 0 : str.hashCode());
    }

    public String toString() {
        return "Control(id=" + this.id + ", key=" + this.key + ", x=" + this.x + ", y=" + this.y + ", w=" + this.w + ", h=" + this.f9283h + ", settings=" + ((Object) this.settings) + ')';
    }
}
