package ru.himik.nightscream.kascada.Connections.Usb.driver;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.KotlinVersion;

/* JADX INFO: loaded from: classes.dex */
public class Cp21xxSerialDriver implements UsbSerialDriver {
    private static final String TAG = "Cp21xxSerialDriver";
    private final UsbDevice mDevice;
    private final UsbSerialPort mPort;

    public class Cp21xxSerialPort extends CommonUsbSerialPort {
        private static final int BAUD_RATE_GEN_FREQ = 3686400;
        private static final int CONTROL_WRITE_DTR = 256;
        private static final int CONTROL_WRITE_RTS = 512;
        private static final int DEFAULT_BAUD_RATE = 9600;
        private static final int FLUSH_READ_CODE = 10;
        private static final int FLUSH_WRITE_CODE = 5;
        private static final int MCR_ALL = 3;
        private static final int MCR_DTR = 1;
        private static final int MCR_RTS = 2;
        private static final int REQTYPE_HOST_TO_DEVICE = 65;
        private static final int SILABSER_FLUSH_REQUEST_CODE = 18;
        private static final int SILABSER_IFC_ENABLE_REQUEST_CODE = 0;
        private static final int SILABSER_SET_BAUDDIV_REQUEST_CODE = 1;
        private static final int SILABSER_SET_BAUDRATE = 30;
        private static final int SILABSER_SET_LINE_CTL_REQUEST_CODE = 3;
        private static final int SILABSER_SET_MHS_REQUEST_CODE = 7;
        private static final int UART_DISABLE = 0;
        private static final int UART_ENABLE = 1;
        private static final int USB_WRITE_TIMEOUT_MILLIS = 5000;
        private UsbEndpoint mReadEndpoint;
        private UsbEndpoint mWriteEndpoint;

        public Cp21xxSerialPort(UsbDevice usbDevice, int i2) {
            super(usbDevice, i2);
        }

        private void setBaudRate(int i2) throws IOException {
            if (this.mConnection.controlTransfer(65, 30, 0, 0, new byte[]{(byte) (i2 & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((i2 >> 8) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((i2 >> 16) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((i2 >> 24) & KotlinVersion.MAX_COMPONENT_VALUE)}, 4, 5000) < 0) {
                throw new IOException("Error setting baud rate.");
            }
        }

        private int setConfigSingle(int i2, int i3) {
            return this.mConnection.controlTransfer(65, i2, i3, 0, null, 0, 5000);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void close() throws IOException {
            if (this.mConnection == null) {
                throw new IOException("Already closed");
            }
            try {
                setConfigSingle(0, 0);
                this.mConnection.close();
            } finally {
                this.mConnection = null;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCD() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getCTS() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDSR() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getDTR() {
            return true;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public UsbSerialDriver getDriver() {
            return Cp21xxSerialDriver.this;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public /* bridge */ /* synthetic */ int getPortNumber() {
            return super.getPortNumber();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRI() {
            return false;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean getRTS() {
            return true;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public /* bridge */ /* synthetic */ String getSerial() {
            return super.getSerial();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void open(UsbDeviceConnection usbDeviceConnection) throws IOException {
            if (this.mConnection != null) {
                throw new IOException("Already opened.");
            }
            this.mConnection = usbDeviceConnection;
            for (int i2 = 0; i2 < this.mDevice.getInterfaceCount(); i2++) {
                try {
                    this.mConnection.claimInterface(this.mDevice.getInterface(i2), true);
                } catch (Throwable th) {
                    try {
                        close();
                    } catch (IOException unused) {
                    }
                    throw th;
                }
            }
            UsbDevice usbDevice = this.mDevice;
            UsbInterface usbInterface = usbDevice.getInterface(usbDevice.getInterfaceCount() - 1);
            for (int i3 = 0; i3 < usbInterface.getEndpointCount(); i3++) {
                UsbEndpoint endpoint = usbInterface.getEndpoint(i3);
                if (endpoint.getType() == 2) {
                    if (endpoint.getDirection() == 128) {
                        this.mReadEndpoint = endpoint;
                    } else {
                        this.mWriteEndpoint = endpoint;
                    }
                }
            }
            setConfigSingle(0, 1);
            setConfigSingle(7, 771);
            setConfigSingle(1, 384);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public boolean purgeHwBuffers(boolean z, boolean z2) {
            int i2 = (z ? 10 : 0) | (z2 ? 5 : 0);
            if (i2 == 0) {
                return true;
            }
            setConfigSingle(18, i2);
            return true;
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int read(byte[] bArr, int i2) {
            synchronized (this.mReadBufferLock) {
                int iBulkTransfer = this.mConnection.bulkTransfer(this.mReadEndpoint, this.mReadBuffer, Math.min(bArr.length, this.mReadBuffer.length), i2);
                if (iBulkTransfer < 0) {
                    return 0;
                }
                System.arraycopy(this.mReadBuffer, 0, bArr, 0, iBulkTransfer);
                return iBulkTransfer;
            }
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setDTR(boolean z) {
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setParameters(int i2, int i3, int i4, int i5) throws IOException {
            setBaudRate(i2);
            int i6 = 2048;
            if (i3 == 5) {
                i6 = 1280;
            } else if (i3 == 6) {
                i6 = 1536;
            } else if (i3 == 7) {
                i6 = 1792;
            }
            if (i5 == 1) {
                i6 |= 16;
            } else if (i5 == 2) {
                i6 |= 32;
            }
            if (i4 == 1) {
                i6 |= 0;
            } else if (i4 == 2) {
                i6 |= 2;
            }
            setConfigSingle(3, i6);
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public void setRTS(boolean z) {
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort
        public /* bridge */ /* synthetic */ String toString() {
            return super.toString();
        }

        @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.CommonUsbSerialPort, ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort
        public int write(byte[] bArr, int i2) throws IOException {
            int iMin;
            byte[] bArr2;
            int iBulkTransfer;
            int i3 = 0;
            while (i3 < bArr.length) {
                synchronized (this.mWriteBufferLock) {
                    iMin = Math.min(bArr.length - i3, this.mWriteBuffer.length);
                    if (i3 == 0) {
                        bArr2 = bArr;
                    } else {
                        System.arraycopy(bArr, i3, this.mWriteBuffer, 0, iMin);
                        bArr2 = this.mWriteBuffer;
                    }
                    iBulkTransfer = this.mConnection.bulkTransfer(this.mWriteEndpoint, bArr2, iMin, i2);
                }
                if (iBulkTransfer <= 0) {
                    throw new IOException("Error writing " + iMin + " bytes at offset " + i3 + " length=" + bArr.length);
                }
                i3 += iBulkTransfer;
            }
            return i3;
        }
    }

    public Cp21xxSerialDriver(UsbDevice usbDevice) {
        this.mDevice = usbDevice;
        this.mPort = new Cp21xxSerialPort(usbDevice, 0);
    }

    public static Map<Integer, int[]> getSupportedDevices() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(Integer.valueOf(UsbId.VENDOR_SILABS), new int[]{UsbId.SILABS_CP2102, UsbId.SILABS_CP2105, UsbId.SILABS_CP2108, UsbId.SILABS_CP2110});
        return linkedHashMap;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public UsbDevice getDevice() {
        return this.mDevice;
    }

    @Override // ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver
    public List<UsbSerialPort> getPorts() {
        return Collections.singletonList(this.mPort);
    }
}
