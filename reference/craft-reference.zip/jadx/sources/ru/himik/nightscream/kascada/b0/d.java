package ru.himik.nightscream.kascada.b0;

import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.util.Log;
import f.c.a.f;
import f.c.a.k;
import f.c.a.m;
import f.g.a.d.y0;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import kotlin.b0.d.j;
import kotlin.i0.q;
import kotlin.i0.r;
import l.c0;
import org.kaldi.Model;
import ru.himik.nightscream.kascada.CustomComponents.a0;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.l;
import ru.himik.nightscream.kascada.Utils.n;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class d implements org.kaldi.a {
    private static Model b;
    private static org.kaldi.b c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static boolean f9178d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static boolean f9179e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static boolean f9180f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static y0 f9182h;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static String f9184j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static String f9185k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static boolean f9186l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private static String f9187m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static boolean f9188n;
    private static final CountDownTimer o;
    public static final d a = new d();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static final Locale f9181g = new Locale(MyApplication.b().h0.getResources().getString(R.string.voice_language));

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static final Map<String, String> f9183i = new LinkedHashMap();

    public static final class a extends AsyncTask<String, Void, Boolean> {
        private b a;

        public a(b bVar) {
            j.d(bVar, "callBack");
            this.a = bVar;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Boolean doInBackground(String... strArr) {
            j.d(strArr, "params");
            String str = strArr[0];
            try {
                new k.a.a.a(str).f(strArr[1]);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            return Boolean.valueOf(new File(str).delete());
        }

        protected void b(boolean z) {
            this.a.d();
        }

        @Override // android.os.AsyncTask
        public /* bridge */ /* synthetic */ void onPostExecute(Boolean bool) {
            b(bool.booleanValue());
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
        }
    }

    public interface b {
        void a();

        void d();
    }

    public static final class c extends AsyncTask<Void, Void, Exception> {
        private b a;

        public c(b bVar) {
            j.d(bVar, "callBack");
            this.a = bVar;
        }

        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Exception doInBackground(Void... voidArr) {
            j.d(voidArr, "p0");
            try {
                d.a.v(new Model(n.a.f()));
                return null;
            } catch (Exception e2) {
                this.a.a();
                return e2;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void onPostExecute(Exception exc) {
            if (exc != null) {
                this.a.a();
            } else {
                this.a.d();
            }
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.b0.d$d, reason: collision with other inner class name */
    public static final class C0298d implements b {
        C0298d() {
        }

        @Override // ru.himik.nightscream.kascada.b0.d.b
        public void a() {
        }

        @Override // ru.himik.nightscream.kascada.b0.d.b
        public void d() {
            try {
                d dVar = d.a;
                d.c = new org.kaldi.b(dVar.n());
                org.kaldi.b bVar = d.c;
                j.b(bVar);
                bVar.g(dVar);
                org.kaldi.b bVar2 = d.c;
                j.b(bVar2);
                bVar2.i();
            } catch (IOException unused) {
            }
        }
    }

    public static final class e extends CountDownTimer {
        e() {
            super(10000L, 1000L);
        }

        @Override // android.os.CountDownTimer
        public void onFinish() {
            if (d.f9186l) {
                d dVar = d.a;
                d.f9186l = false;
                MyApplication.b().b.d("закрыть окно");
            }
        }

        @Override // android.os.CountDownTimer
        public void onTick(long j2) {
        }
    }

    static {
        try {
            System.loadLibrary("kaldi_jni");
            f9179e = true;
        } catch (UnsatisfiedLinkError unused) {
            f9179e = false;
        }
        f9184j = "";
        f9185k = "";
        f9187m = "";
        o = new e();
    }

    private d() {
    }

    private final boolean i() {
        int size = MyApplication.b().f0.size();
        int i2 = 0;
        while (i2 < size) {
            int i3 = i2 + 1;
            Object obj = MyApplication.b().f0.get(MyApplication.b().f0.keyAt(i2));
            Objects.requireNonNull(obj, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomVoiceRecognition");
            if (((a0) obj).b()) {
                return true;
            }
            i2 = i3;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void k(String str) {
        Log.d("NS", str);
    }

    private final void s() {
        if (f9188n) {
            return;
        }
        ru.himik.nightscream.kascada.b0.c.a.c();
    }

    private final void t() {
        ru.himik.nightscream.kascada.b0.c.a.d();
        f9188n = true;
    }

    private final void u() {
        boolean z = false;
        f9188n = false;
        if (f9180f) {
            f9187m = r.D0(f9185k, " ", null, 2, null);
            for (Map.Entry<String, String> entry : f9183i.entrySet()) {
            }
            Map<String, String> map = f9183i;
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (Map.Entry<String, String> entry2 : map.entrySet()) {
                if (j.a(r.D0(entry2.getValue(), " ", null, 2, null), a.m())) {
                    linkedHashMap.put(entry2.getKey(), entry2.getValue());
                }
            }
            if (linkedHashMap.isEmpty()) {
                ru.himik.nightscream.kascada.b0.c.a.c();
                return;
            }
            for (Map.Entry entry3 : linkedHashMap.entrySet()) {
                if (r.F((CharSequence) entry3.getValue(), "#", z, 2, null)) {
                    int length = ((String) entry3.getValue()).length() - q.w((String) entry3.getValue(), "#", "", false, 4, null).length();
                    if (length == 1) {
                        if (r.v0((String) entry3.getValue(), "#", null, 2, null).length() < 4) {
                            String strD0 = r.D0((String) entry3.getValue(), "#", null, 2, null);
                            if (r.F(f9185k, strD0, z, 2, null)) {
                                try {
                                    d dVar = a;
                                    int iIntValue = dVar.o().E(r.v0(f9185k, strD0, null, 2, null)).intValue();
                                    int i2 = Integer.parseInt(r.v0((String) entry3.getValue(), "#", null, 2, null));
                                    MyApplication.b().v0.K(Integer.parseInt(r.D0(r.v0((String) entry3.getKey(), ":", null, 2, null), ".", null, 2, null)), Integer.parseInt(r.v0((String) entry3.getKey(), ".", null, 2, null)), true);
                                    MyApplication.b().v0.T(i2, iIntValue);
                                    dVar.t();
                                } catch (Exception unused) {
                                }
                            }
                        } else {
                            String strD1 = r.D0((String) entry3.getValue(), "#", null, 2, null);
                            String strV0 = r.v0(r.v0((String) entry3.getValue(), "#", null, 2, null), " ", null, 2, null);
                            if (r.F(f9185k, strD1, false, 2, null) && r.F(f9185k, strV0, false, 2, null)) {
                                d dVar2 = a;
                                int iIntValue2 = dVar2.o().E(r.D0(r.v0(f9185k, strD1, null, 2, null), strV0, null, 2, null)).intValue();
                                int i3 = Integer.parseInt(r.D0(r.v0((String) entry3.getValue(), "#", null, 2, null), " ", null, 2, null));
                                MyApplication.b().v0.K(Integer.parseInt(r.D0(r.v0((String) entry3.getKey(), ":", null, 2, null), ".", null, 2, null)), Integer.parseInt(r.v0((String) entry3.getKey(), ".", null, 2, null)), true);
                                MyApplication.b().v0.T(i3, iIntValue2);
                                dVar2.t();
                            }
                        }
                    }
                    if (length == 2) {
                        if (r.v0(r.v0((String) entry3.getValue(), "#", null, 2, null), "#", null, 2, null).length() < 4) {
                            String strD2 = r.D0((String) entry3.getValue(), "#", null, 2, null);
                            String strD3 = r.D0(r.v0(r.v0((String) entry3.getValue(), "#", null, 2, null), " ", null, 2, null), "#", null, 2, null);
                            if (r.F(f9185k, strD2, false, 2, null) && r.F(f9185k, strD3, false, 2, null)) {
                                d dVar3 = a;
                                int iIntValue3 = dVar3.o().E(r.D0(r.v0(f9185k, strD2, null, 2, null), strD3, null, 2, null)).intValue();
                                int iIntValue4 = dVar3.o().E(r.v0(f9185k, strD3, null, 2, null)).intValue();
                                int i4 = Integer.parseInt(r.D0(r.v0((String) entry3.getValue(), "#", null, 2, null), " ", null, 2, null));
                                int i5 = Integer.parseInt(r.v0(r.v0((String) entry3.getValue(), "#", null, 2, null), "#", null, 2, null));
                                MyApplication.b().v0.K(Integer.parseInt(r.D0(r.v0((String) entry3.getKey(), ":", null, 2, null), ".", null, 2, null)), Integer.parseInt(r.v0((String) entry3.getKey(), ".", null, 2, null)), true);
                                MyApplication.b().v0.T(i4, iIntValue3);
                                MyApplication.b().v0.T(i5, iIntValue4);
                                dVar3.t();
                            }
                        } else {
                            String strD4 = r.D0((String) entry3.getValue(), "#", null, 2, null);
                            String strD5 = r.D0(r.v0(r.v0((String) entry3.getValue(), "#", null, 2, null), " ", null, 2, null), "#", null, 2, null);
                            String strV1 = r.v0(r.v0(r.v0((String) entry3.getValue(), "#", null, 2, null), "#", null, 2, null), " ", null, 2, null);
                            if (r.F(f9185k, strD4, false, 2, null) && r.F(f9185k, strD5, false, 2, null) && r.F(f9185k, strV1, false, 2, null)) {
                                try {
                                    d dVar4 = a;
                                    int iIntValue5 = dVar4.o().E(r.D0(r.v0(f9185k, strD4, null, 2, null), strD5, null, 2, null)).intValue();
                                    int iIntValue6 = dVar4.o().E(r.D0(r.v0(f9185k, strD5, null, 2, null), strV1, null, 2, null)).intValue();
                                    int i6 = Integer.parseInt(r.D0(r.v0((String) entry3.getValue(), "#", null, 2, null), " ", null, 2, null));
                                    int i7 = Integer.parseInt(r.D0(r.v0(r.v0((String) entry3.getValue(), "#", null, 2, null), "#", null, 2, null), " ", null, 2, null));
                                    MyApplication.b().v0.K(Integer.parseInt(r.D0(r.v0((String) entry3.getKey(), ":", null, 2, null), ".", null, 2, null)), Integer.parseInt(r.v0((String) entry3.getKey(), ".", null, 2, null)), true);
                                    MyApplication.b().v0.T(i6, iIntValue5);
                                    MyApplication.b().v0.T(i7, iIntValue6);
                                    dVar4.t();
                                } catch (Exception unused2) {
                                }
                            }
                        }
                    }
                    z = false;
                } else if (j.a(f9185k, entry3.getValue())) {
                    try {
                        MyApplication.b().v0.K(Integer.parseInt(r.D0(r.v0((String) entry3.getKey(), ":", null, 2, null), ".", null, 2, null)), Integer.parseInt(r.v0((String) entry3.getKey(), ".", null, 2, null)), true);
                        a.t();
                    } catch (Exception unused3) {
                    }
                }
                z = false;
            }
        } else {
            for (Map.Entry<String, String> entry4 : f9183i.entrySet()) {
                if (j.a(f9185k, entry4.getValue())) {
                    try {
                        MyApplication.b().v0.K(Integer.parseInt(r.D0(r.v0(entry4.getKey(), ":", null, 2, null), ".", null, 2, null)), Integer.parseInt(r.v0(entry4.getKey(), ".", null, 2, null)), true);
                        a.t();
                    } catch (Exception unused4) {
                    }
                }
            }
        }
        s();
    }

    @Override // org.kaldi.a
    public void a(Exception exc) {
    }

    @Override // org.kaldi.a
    public void b() {
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:43:0x008a  */
    /* JADX WARN: Code duplicated, block: B:44:0x0097  */
    /* JADX WARN: Code duplicated, block: B:47:0x009c  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // org.kaldi.a
    public void c(String str) {
        if (str == null || str.length() == 0) {
        }
        String strZ0 = r.z0(r.F0(str, "\"", null, 2, null), "\"", null, 2, null);
        f9185k = strZ0;
        if (strZ0 == null || strZ0.length() == 0) {
            return;
        }
        MyApplication.b().b.d(f9185k);
        String str2 = f9185k;
        switch (str2.hashCode()) {
            case -1218096562:
                if (str2.equals("тоскана")) {
                    ru.himik.nightscream.kascada.b0.c.a.e();
                    f9186l = true;
                    o.start();
                } else if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                }
                f9185k = "";
                break;
            case -1218096543:
                if (str2.equals("тоскану")) {
                    ru.himik.nightscream.kascada.b0.c.a.e();
                    f9186l = true;
                    o.start();
                } else if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                }
                f9185k = "";
                break;
            case -1102508601:
                if (str2.equals("listen")) {
                    ru.himik.nightscream.kascada.b0.c.a.e();
                    f9186l = true;
                    o.start();
                } else if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                }
                f9185k = "";
                break;
            case -128999811:
                if (str2.equals("каскада")) {
                    ru.himik.nightscream.kascada.b0.c.a.e();
                    f9186l = true;
                    o.start();
                } else if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                }
                f9185k = "";
                break;
            case 295974663:
                if (str2.equals("каскадов")) {
                    ru.himik.nightscream.kascada.b0.c.a.e();
                    f9186l = true;
                    o.start();
                } else if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                }
                f9185k = "";
                break;
            case 295974673:
                if (str2.equals("каскадом")) {
                    ru.himik.nightscream.kascada.b0.c.a.e();
                    f9186l = true;
                    o.start();
                } else if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                }
                f9185k = "";
                break;
            case 359933095:
                if (str2.equals("закрыть окно")) {
                    o.onFinish();
                    ru.himik.nightscream.kascada.b0.c.a.d();
                } else if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                }
                f9185k = "";
                break;
            default:
                if (!f9186l) {
                    f9185k = r.G0(f9185k).toString();
                    u();
                    f9185k = "";
                    break;
                }
                break;
        }
    }

    @Override // org.kaldi.a
    public void d(String str) {
        if (str == null || str.length() == 0) {
            return;
        }
        String strZ0 = r.z0(r.F0(str, "\"", null, 2, null), "\"", null, 2, null);
        f9184j = strZ0;
        if ((strZ0.length() > 0) && f9186l) {
            CountDownTimer countDownTimer = o;
            countDownTimer.cancel();
            countDownTimer.start();
        }
        f9184j = "";
    }

    public final void j(f.c.a.a aVar) {
        j.d(aVar, "callback");
        c0 c0Var = new c0();
        f.c.a.e.a aVar2 = new f.c.a.e.a();
        aVar2.f(MyApplication.b().h0);
        aVar2.g(k.g(c0Var));
        aVar2.i(3);
        aVar2.h(new f.c.a.j() { // from class: ru.himik.nightscream.kascada.b0.b
            @Override // f.c.a.j
            public final void a(String str) {
                d.k(str);
            }
        });
        f.c.a.e eVarE = aVar2.e();
        j.c(eVarE, "Builder().context(MyAppl…\n                .build()");
        n.a aVar3 = n.a;
        File file = new File(aVar3.f());
        if (!file.exists()) {
            file.mkdirs();
        }
        String strI = j.i(aVar3.f(), "model.zip");
        f.b bVar = new f.b();
        bVar.t(q() ? "https://bitbucket.org/aleksandrmozgovoi/kascadavoice/raw/2e3399cbca883e0d97c83c506fc0e354acb86b6c/vosk-model-small-ru-0.4.zip" : "https://bitbucket.org/aleksandrmozgovoi/kascadavoice/raw/2e3399cbca883e0d97c83c506fc0e354acb86b6c/vosk-model-small-en-us-0.3.zip");
        bVar.r(5);
        TimeUnit timeUnit = TimeUnit.SECONDS;
        bVar.q(2L, timeUnit);
        bVar.p(1L, timeUnit);
        bVar.o(m.HIGH);
        bVar.k(2);
        bVar.m(strI);
        bVar.n(aVar);
        f fVarL = bVar.l();
        j.c(fVarL, "Builder()\n              …\n                .build()");
        eVarE.a(fVarL);
    }

    public final boolean l() {
        return f9179e;
    }

    public final String m() {
        return f9187m;
    }

    public final Model n() {
        return b;
    }

    public final y0 o() {
        y0 y0Var = f9182h;
        if (y0Var != null) {
            return y0Var;
        }
        j.m("numberFormat");
        throw null;
    }

    public final CountDownTimer p() {
        return o;
    }

    public final boolean q() {
        return j.a(MyApplication.b().h0.getResources().getString(R.string.voice_language), "ru");
    }

    public final void v(Model model) {
        b = model;
    }

    public final void w(y0 y0Var) {
        j.d(y0Var, "<set-?>");
        f9182h = y0Var;
    }

    public final void x() {
        f9183i.clear();
        int size = MyApplication.b().f0.size();
        int i2 = 0;
        while (i2 < size) {
            int i3 = i2 + 1;
            int iKeyAt = MyApplication.b().f0.keyAt(i2);
            Object obj = MyApplication.b().f0.get(iKeyAt);
            Objects.requireNonNull(obj, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomVoiceRecognition");
            int iC = ((a0) obj).f8708g.c();
            int i4 = 0;
            while (i4 < 16) {
                int i5 = i4 + 1;
                Object obj2 = MyApplication.b().f0.get(iKeyAt);
                Objects.requireNonNull(obj2, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomVoiceRecognition");
                String strA = ((a0) obj2).a(i4);
                j.c(strA, "MyApplication.get().cust…nition).getTextVoice(bit)");
                if (strA.length() > 0) {
                    Map<String, String> map = f9183i;
                    StringBuilder sb = new StringBuilder();
                    sb.append(iKeyAt);
                    sb.append(':');
                    sb.append(iC);
                    sb.append('.');
                    sb.append(i4);
                    String string = sb.toString();
                    Object obj3 = MyApplication.b().f0.get(iKeyAt);
                    Objects.requireNonNull(obj3, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomVoiceRecognition");
                    String strA2 = ((a0) obj3).a(i4);
                    j.c(strA2, "MyApplication.get().cust…nition).getTextVoice(bit)");
                    Locale locale = Locale.getDefault();
                    j.c(locale, "getDefault()");
                    String lowerCase = strA2.toLowerCase(locale);
                    j.c(lowerCase, "this as java.lang.String).toLowerCase(locale)");
                    map.put(string, lowerCase);
                }
                if (!l.a.l()) {
                    break;
                } else {
                    i4 = i5;
                }
            }
            if (!l.a.l()) {
                break;
            } else {
                i2 = i3;
            }
        }
        boolean zI = i();
        f9180f = zI;
        if (zI) {
            w(new y0(f9181g, 1));
        }
        if (f9178d) {
            return;
        }
        f9178d = true;
        new c(new C0298d()).execute(new Void[0]);
    }

    public final void y() {
        f9186l = false;
        o.onFinish();
        f9178d = false;
        org.kaldi.b bVar = c;
        if (bVar != null) {
            j.b(bVar);
            bVar.h();
            c = null;
        }
    }
}
