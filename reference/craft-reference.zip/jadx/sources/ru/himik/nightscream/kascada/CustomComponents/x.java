package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class x extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    Paint C;
    Paint D;
    boolean E;
    int F;
    int G;
    boolean H;
    int I;
    int J;
    private long K;
    public Point L;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8929d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8930e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8931f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8932g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8933h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    String f8934i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    String f8935j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f8936k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f8937l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f8938m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f8939n;
    Bitmap o;

    public x(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_sms_receive);
        this.f8929d = 18;
        this.f8931f = (byte) 0;
        this.f8932g = new b();
        this.f8934i = "";
        this.f8935j = "";
        this.f8936k = 0;
        this.f8937l = "";
        this.o = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.C = new Paint();
        this.D = new Paint();
        this.E = false;
        this.F = 0;
        this.G = 0;
        this.H = false;
        this.I = 0;
        this.J = 0;
        this.K = 0L;
        this.L = new Point();
    }

    public void a(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_sms_in);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
        this.f8932g.A(this.f8929d);
    }

    public boolean b() {
        return this.E;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.L.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public int getBitStrob() {
        return this.G;
    }

    public String getCommand() {
        return this.f8937l;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8932g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8929d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8933h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8929d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8932g.l());
        jSONObject.put("addressRegister", this.f8932g.c());
        jSONObject.put("addressBit", (int) this.f8932g.a());
        jSONObject.put("typeRequest", (int) this.f8932g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("phone", getPhone());
        jSONObject.put(IMAPStore.ID_COMMAND, getCommand());
        jSONObject.put("typeCommand", getTypeCommand());
        jSONObject.put("strob", b());
        jSONObject.put("regStrob", getRegStrob());
        jSONObject.put("bitStrob", getBitStrob());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8930e;
    }

    public String getMessage() {
        return this.f8935j;
    }

    public int getNumScreen() {
        return this.f8933h;
    }

    public String getPhone() {
        return this.f8934i;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.L;
    }

    public int getRegStrob() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8932g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8932g.l() >= 100) {
            this.f8932g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8932g.c() + "." + ((int) this.f8932g.a());
        }
        this.f8932g.u((byte) MyApplication.b().E.get(this.f8932g.l()).a());
        if (getTypeCommand() == 0) {
            return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8932g.b()) + "#" + this.f8932g.c();
        }
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8932g.b()) + "#" + this.f8932g.c() + "." + ((int) this.f8932g.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8932g.l() >= 0) {
            if (this.f8932g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8932g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.K;
    }

    public int getTypeCommand() {
        return this.f8936k;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8939n) {
            this.D.setColor(-65536);
            this.D.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.D);
        }
        if (this.f8938m && mbCanvas.g1) {
            canvas.drawBitmap(this.o, getWidth() - this.o.getWidth(), getHeight() - this.o.getHeight(), this.C);
        }
        if (this.H) {
            this.D.setColor(-16711936);
            this.D.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.D);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.H;
    }

    public void setBitStrob(int i2) {
        this.G = i2;
    }

    public void setCommand(String str) {
        this.f8937l = str;
    }

    public void setConnectionError(boolean z) {
        if (this.f8939n != z) {
            this.f8939n = z;
            setVisibility(z ? 0 : 4);
            invalidate();
        }
    }

    public void setConnectionTimeOut(boolean z) {
        if (this.f8938m != z) {
            this.f8938m = z;
            setVisibility(z ? 0 : 4);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.H = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.I = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.J = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8930e = i2;
    }

    public void setMessage(String str) {
        this.f8935j = str;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8933h = i2;
    }

    public void setPhone(String str) {
        this.f8934i = str;
    }

    public void setRegStrob(int i2) {
        this.F = i2;
    }

    public void setStrob(boolean z) {
        this.E = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.K = j2;
    }

    public void setTypeCommand(int i2) {
        this.f8936k = i2;
    }
}
