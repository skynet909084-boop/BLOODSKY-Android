package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.g;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class VarOutFloat extends g implements e {
    private float Q;
    String R;
    public boolean S;
    public boolean T;
    int[] U;
    byte[] V;

    public VarOutFloat(Context context) {
        super(context);
        this.Q = 0.0f;
        this.R = "VarOutFloat";
        this.S = false;
        this.T = false;
        this.U = new int[4];
        this.V = new byte[4];
    }

    public VarOutFloat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.Q = 0.0f;
        this.R = "VarOutFloat";
        this.S = false;
        this.T = false;
        this.U = new int[4];
        this.V = new byte[4];
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.Q = 0.0f;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f9022d;
        if (aVar == null || aVar.getOut() == null) {
            return;
        }
        float fFloatValue = ((Float) this.f9022d.getOut()).floatValue();
        this.Q = fFloatValue;
        byte[] bArrC = ru.himik.nightscream.kascada.x.b.c(fFloatValue);
        this.V = bArrC;
        boolean z = this.S;
        if (!z && !this.T) {
            int[] iArr = this.U;
            iArr[0] = bArrC[0] & 255;
            iArr[1] = bArrC[1] & 255;
            iArr[2] = bArrC[2] & 255;
            iArr[3] = bArrC[3] & 255;
        }
        if (z && !this.T) {
            int[] iArr2 = this.U;
            iArr2[0] = bArrC[2] & 255;
            iArr2[1] = bArrC[3] & 255;
            iArr2[2] = bArrC[0] & 255;
            iArr2[3] = bArrC[1] & 255;
        }
        if (!z && this.T) {
            int[] iArr3 = this.U;
            iArr3[0] = bArrC[1] & 255;
            iArr3[1] = bArrC[0] & 255;
            iArr3[2] = bArrC[3] & 255;
            iArr3[3] = bArrC[2] & 255;
        }
        if (z && this.T) {
            int[] iArr4 = this.U;
            iArr4[0] = bArrC[3] & 255;
            iArr4[1] = bArrC[2] & 255;
            iArr4[2] = bArrC[1] & 255;
            iArr4[3] = bArrC[0] & 255;
        }
        ru.himik.nightscream.kascada.q.d.b bVar = MyApplication.b().v0;
        int i2 = this.f9030l;
        int[] iArr5 = this.U;
        bVar.U(i2, (iArr5[0] * 256) + iArr5[1]);
        ru.himik.nightscream.kascada.q.d.b bVar2 = MyApplication.b().v0;
        int i3 = this.f9030l + 1;
        int[] iArr6 = this.U;
        bVar2.U(i3, (iArr6[2] * 256) + iArr6[3]);
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getBit() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("reg", 0);
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.R + this.f9030l + "";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        return Float.valueOf(this.Q);
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getReg() {
        return this.f9030l;
    }

    public String getTextOrder() {
        StringBuilder sb;
        String str;
        boolean z = this.S;
        if (!z && !this.T) {
            sb = new StringBuilder();
            sb.append(getResources().getString(R.string.byte_order));
            str = ": [1 2] [3 4]";
        } else if (z && !this.T) {
            sb = new StringBuilder();
            sb.append(getResources().getString(R.string.byte_order));
            str = ": [3 4] [1 2]";
        } else if (!z && this.T) {
            sb = new StringBuilder();
            sb.append(getResources().getString(R.string.byte_order));
            str = ": [2 1] [4 3]";
        } else {
            if (!z || !this.T) {
                return ": [error] [error]";
            }
            sb = new StringBuilder();
            sb.append(getResources().getString(R.string.byte_order));
            str = ": [4 3] [2 1]";
        }
        sb.append(str);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return com.karumi.dexter.R.styleable.AppCompatTheme_textColorSearchUrl;
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public void j(int i2, int i3) {
        if (i2 < 0 || i2 > ru.himik.nightscream.kascada.q.d.b.F - 1 || i3 < 0 || i3 > 15) {
            return;
        }
        this.f9030l = i2;
        this.f9031m = i3;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        return i2 == 1 ? 3 : 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, android.view.View
    protected void onDraw(Canvas canvas) {
        this.C.set(this.M, this.N, getWidth(), getHeight() - this.N);
        this.f9023e.setStyle(Paint.Style.FILL);
        this.f9023e.setColor(-7829368);
        canvas.drawPath(u(this.C, 0.0f, getHeight(), getHeight(), 0.0f), this.f9023e);
        this.f9023e.setStyle(Paint.Style.STROKE);
        this.f9023e.setColor(-16777216);
        canvas.drawPath(u(this.C, 0.0f, getHeight(), getHeight(), 0.0f), this.f9023e);
        canvas.drawText(this.f9032n, (getWidth() / 2) + (this.M / 2), (int) ((getHeight() / 2) - ((this.f9024f.descent() + this.f9024f.ascent()) / 2.0f)), this.f9024f);
        canvas.drawLine(this.M, getHeight() / 2, this.N, getHeight() / 2, this.f9023e);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, android.view.View
    protected void onMeasure(int i2, int i3) {
        this.f9032n = "S#" + this.f9030l;
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g
    public void setIn(Object obj) {
        this.Q = ((Integer) obj).intValue();
    }

    public Path u(RectF rectF, float f2, float f3, float f4, float f5) {
        Path path = new Path();
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f5 < 0.0f) {
            f5 = 0.0f;
        }
        if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        float f6 = f2 / 2.0f;
        path.moveTo(rectF.left + f6, rectF.top);
        float f7 = f3 / 2.0f;
        path.lineTo(rectF.right - f7, rectF.top);
        float f8 = rectF.right;
        float f9 = rectF.top;
        path.quadTo(f8, f9, f8, f7 + f9);
        float f10 = f4 / 2.0f;
        path.lineTo(rectF.right, rectF.bottom - f10);
        float f11 = rectF.right;
        float f12 = rectF.bottom;
        path.quadTo(f11, f12, f11 - f10, f12);
        float f13 = f5 / 2.0f;
        path.lineTo(rectF.left + f13, rectF.bottom);
        float f14 = rectF.left;
        float f15 = rectF.bottom;
        path.quadTo(f14, f15, f14, f15 - f13);
        path.lineTo(rectF.left, rectF.top + f6);
        float f16 = rectF.left;
        float f17 = rectF.top;
        path.quadTo(f16, f17, f6 + f16, f17);
        path.close();
        return path;
    }
}
