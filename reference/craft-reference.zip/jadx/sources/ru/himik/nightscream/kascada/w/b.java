package ru.himik.nightscream.kascada.w;

import android.os.Environment;
import android.util.Log;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/* JADX INFO: loaded from: classes2.dex */
public class b {
    static String a = Environment.getExternalStorageState();
    static boolean b = false;
    static boolean c = false;

    public static void a(String str, String str2) {
        if ("mounted".equals(a)) {
            c = true;
            b = true;
        } else if ("mounted_ro".equals(a)) {
            b = true;
            c = false;
        } else {
            c = false;
            b = false;
        }
        if (!c || !b) {
            if (a.a) {
                Log.d("NS", "SD-карта не доступна: " + Environment.getExternalStorageState());
                return;
            }
            return;
        }
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath() + "/KaScada/Logger/");
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, str + ".log");
        if (!file2.exists()) {
            try {
                file2.createNewFile();
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file2, true));
            new FileWriter(file2, true).write(str2 + " " + b());
            bufferedWriter.write(str2 + " " + b());
            bufferedWriter.newLine();
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (IOException e3) {
            e3.printStackTrace();
        }
    }

    static String b() {
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime());
    }
}
