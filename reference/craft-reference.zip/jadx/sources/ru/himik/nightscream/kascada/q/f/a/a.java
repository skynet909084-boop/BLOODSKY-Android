package ru.himik.nightscream.kascada.q.f.a;

import kotlin.b0.d.j;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    private final String pass;
    private final int screen;

    public a(int i2, String str) {
        this.screen = i2;
        this.pass = str;
    }

    public static /* synthetic */ a copy$default(a aVar, int i2, String str, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i2 = aVar.screen;
        }
        if ((i3 & 2) != 0) {
            str = aVar.pass;
        }
        return aVar.copy(i2, str);
    }

    public final int component1() {
        return this.screen;
    }

    public final String component2() {
        return this.pass;
    }

    public final a copy(int i2, String str) {
        return new a(i2, str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return this.screen == aVar.screen && j.a(this.pass, aVar.pass);
    }

    public final String getPass() {
        return this.pass;
    }

    public final int getScreen() {
        return this.screen;
    }

    public int hashCode() {
        int i2 = this.screen * 31;
        String str = this.pass;
        return i2 + (str == null ? 0 : str.hashCode());
    }

    public String toString() {
        return "ChangeScreen(screen=" + this.screen + ", pass=" + ((Object) this.pass) + ')';
    }
}
