package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextPaint;
import android.view.MotionEvent;
import java.nio.ByteBuffer;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class i extends androidx.appcompat.widget.y implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    int C;
    Bitmap D;
    Paint E;
    Paint F;
    String G;
    boolean H;
    int I;
    int J;
    int K;
    int L;
    byte[] M;
    int N;
    String O;
    boolean P;
    boolean Q;
    private long R;
    Paint S;
    int T;
    int U;
    int V;
    String W;
    public Point a0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f8808e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8809f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8810g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    Context f8811h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public byte f8812i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public b f8813j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f8814k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f8815l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f8816m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f8817n;
    private float o;

    public i(Context context) {
        super(context);
        this.f8808e = getResources().getString(R.string.custom_edit_number);
        this.f8809f = 8;
        this.f8812i = (byte) 6;
        this.f8813j = new b();
        this.f8817n = 0.0f;
        this.o = 100.0f;
        this.C = 0;
        this.D = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.E = new Paint();
        this.F = new Paint();
        this.G = "";
        this.H = false;
        this.I = 0;
        this.J = 0;
        this.K = 0;
        this.L = 0;
        this.M = new byte[4];
        this.N = 1;
        this.O = "0";
        this.P = false;
        this.Q = false;
        this.R = 0L;
        this.W = "";
        this.a0 = new Point();
        this.f8811h = context;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.a0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void f(String str) {
        this.O = str;
        h();
        g();
        invalidate();
    }

    void g() {
        this.S.setTextScaleX(1.0f);
        Rect rect = new Rect();
        Paint paint = this.S;
        String str = this.W;
        paint.getTextBounds(str, 0, str.length(), rect);
        int i2 = (int) ((rect.right - rect.left) * 1.1f);
        int i3 = rect.bottom;
        this.T = i3 + ((this.V - (i3 - rect.top)) / 2);
        this.S.setTextScaleX(((this.U - getPaddingLeft()) - getPaddingRight()) / i2);
    }

    public int getBackgroundColorEditNumber() {
        return this.C;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8813j;
    }

    public int getCountNumAfterPointEditNumber() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return getBackgroundColorEditNumber();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8809f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8814k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return this.O;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8809f;
    }

    public b getInitConnectionInfo() {
        if (getType() == 0) {
            b bVar = new b();
            bVar.A(getIdComponent());
            bVar.v(this.f8813j.c());
            bVar.L((byte) 3);
            bVar.C(getKey());
            bVar.K(0);
            bVar.F(this.f8813j.r());
            bVar.u(this.f8813j.b());
            bVar.x(new ru.himik.nightscream.kascada.x.a().c(bVar, this.f8813j.i()));
            return bVar;
        }
        b bVar2 = new b();
        bVar2.A(getIdComponent());
        bVar2.v(this.f8813j.c());
        bVar2.L((byte) 3);
        bVar2.z((byte) 2);
        bVar2.K(1);
        bVar2.C(getKey());
        bVar2.F(this.f8813j.r());
        bVar2.u(this.f8813j.b());
        bVar2.x(new ru.himik.nightscream.kascada.x.a().c(bVar2, this.f8813j.i()));
        return bVar2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8813j.l());
        jSONObject.put("min", getMinValue());
        jSONObject.put("max", getMaxValue());
        jSONObject.put("addressRegister", this.f8813j.c());
        jSONObject.put("password", getPassword());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("type", getType());
        jSONObject.put("typeInt", getTypeInt());
        jSONObject.put("countNumAfterPointEditNumber", this.N);
        jSONObject.put("fontChange", l());
        jSONObject.put("enableFrameEditNumber", k());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8810g;
    }

    public float getMaxValue() {
        return this.o;
    }

    public float getMinValue() {
        return this.f8817n;
    }

    public int getNumScreen() {
        return this.f8814k;
    }

    public String getPassword() {
        return this.G;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.a0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8813j.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8813j.l() >= 100) {
            this.f8813j.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8813j.c();
        }
        this.f8813j.u((byte) MyApplication.b().E.get(this.f8813j.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8813j.b()) + "#" + this.f8813j.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8813j.l() >= 0) {
            if (this.f8813j.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8813j.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // androidx.appcompat.widget.y, android.widget.TextView
    public String getText() {
        return this.O;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.R;
    }

    public int getType() {
        return this.K;
    }

    public int getTypeInt() {
        return this.L;
    }

    void h() {
        StringBuilder sb;
        if (this.K == 0) {
            if (this.L == 0) {
                sb = new StringBuilder();
                sb.append((int) this.o);
                sb.append("");
            } else {
                sb = new StringBuilder();
                sb.append("-");
                sb.append((int) this.o);
            }
            String string = sb.toString();
            this.W = string;
            this.W = string.replace("1", "0");
        } else {
            String str = "-" + ((int) this.o);
            this.W = str;
            this.W = str.replace("1", "0");
            for (int i2 = 0; i2 < this.N; i2++) {
                this.W += "0";
            }
        }
        if (this.W.length() == 0) {
            return;
        }
        this.S.setTextSize(100.0f);
        this.S.setTextScaleX(1.0f);
        Rect rect = new Rect();
        Paint paint = this.S;
        String str2 = this.W;
        paint.getTextBounds(str2, 0, str2.length(), rect);
        this.S.setTextSize(((this.V * 0.7f) / (rect.bottom - rect.top)) * 100.0f);
    }

    public float i(byte[] bArr) {
        return ByteBuffer.wrap(bArr).getFloat();
    }

    public void j(int i2, int i3, int i4, boolean z) {
        TextPaint textPaint = new TextPaint();
        this.S = textPaint;
        textPaint.setTextAlign(Paint.Align.CENTER);
        this.S.setAntiAlias(true);
        setPadding(10, 10, 10, 10);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            setBackgroundColor(0);
        }
        setKey(i4);
        f("000");
        setGravity(17);
        this.f8813j.A(this.f8809f);
        setFont("");
    }

    public boolean k() {
        return this.Q;
    }

    public boolean l() {
        return this.P;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8816m) {
            this.F.setColor(-65536);
            this.F.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.F);
        }
        if (this.f8815l && mbCanvas.g1) {
            canvas.drawBitmap(this.D, getWidth() - this.D.getWidth(), getHeight() - this.D.getHeight(), this.E);
        }
        if (this.H) {
            this.F.setColor(-16711936);
            this.F.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.F);
        }
        canvas.drawText(this.O, this.U / 2, this.V - this.T, this.S);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        this.U = i2;
        this.V = i3;
        h();
        g();
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.H;
    }

    public void setBackgroundColorEditNumber(int i2) {
        this.C = i2;
    }

    public void setConnectionError(boolean z) {
        this.f8816m = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8815l = z;
    }

    public void setCountNumAfterPointEditNumber(int i2) {
        this.N = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.H = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.I = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.J = i2;
    }

    public void setEnableFrameEditNumber(boolean z) {
        this.Q = z;
        if (!z) {
            setBackgroundColor(this.C);
            return;
        }
        int i2 = Build.VERSION.SDK_INT;
        Drawable drawable = i2 >= 21 ? getResources().getDrawable(R.drawable.tab_button, null) : getResources().getDrawable(R.drawable.tab_button);
        if (i2 < 16) {
            setBackgroundDrawable(drawable);
        } else {
            setBackground(drawable);
        }
    }

    public void setFont(String str) {
        Paint paint;
        Typeface typefaceCreateFromAsset;
        if (this.P) {
            paint = this.S;
            typefaceCreateFromAsset = Typeface.DEFAULT;
        } else {
            paint = this.S;
            typefaceCreateFromAsset = Typeface.createFromAsset(this.f8811h.getAssets(), "fonts/sf_digital_readout_heavy.ttf");
        }
        paint.setTypeface(typefaceCreateFromAsset);
        h();
        g();
        invalidate();
    }

    public void setFontChange(boolean z) {
        this.P = z;
        setFont("");
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8810g = i2;
    }

    public void setMaxValue(float f2) {
        this.o = f2;
    }

    public void setMinValue(float f2) {
        this.f8817n = f2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8814k = i2;
    }

    public void setPassword(String str) {
        this.G = str;
    }

    @Override // android.widget.TextView
    public void setTextColor(int i2) {
        super.setTextColor(i2);
        this.S.setColor(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.R = j2;
    }

    public void setType(int i2) {
        this.K = i2;
    }

    public void setTypeInt(int i2) {
        this.L = i2;
    }

    public void setValue(int[] iArr) {
        short s;
        StringBuilder sb;
        String string;
        int i2 = this.K;
        if (i2 != 0) {
            if (i2 != 1) {
                return;
            }
            byte[] bArr = this.M;
            bArr[0] = (byte) iArr[0];
            bArr[1] = (byte) iArr[1];
            bArr[2] = (byte) iArr[2];
            bArr[3] = (byte) iArr[3];
            String str = i(this.M) + "";
            this.O = str;
            if (str.contains(".")) {
                String str2 = this.O;
                if (str2.charAt(str2.length() - 1) != '.' && this.O.length() - (this.O.indexOf(".") + 1) > this.N) {
                    String str3 = this.O;
                    string = str3.substring(0, str3.indexOf(".") + 1 + this.N);
                }
            }
            h();
            g();
            invalidate();
        }
        int i3 = this.L;
        if (i3 == 0) {
            s = (char) ((iArr[0] * 256) + iArr[1]);
            sb = new StringBuilder();
        } else {
            if (i3 != 1) {
                return;
            }
            s = (short) ((iArr[0] * 256) + iArr[1]);
            sb = new StringBuilder();
        }
        sb.append((int) s);
        sb.append("");
        string = sb.toString();
        f(string);
        h();
        g();
        invalidate();
    }
}
