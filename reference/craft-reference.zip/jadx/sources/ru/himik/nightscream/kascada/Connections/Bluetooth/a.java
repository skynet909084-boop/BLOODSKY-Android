package ru.himik.nightscream.kascada.Connections.Bluetooth;

import android.bluetooth.BluetoothSocket;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import kotlin.KotlinVersion;

/* JADX INFO: loaded from: classes.dex */
public class a extends Thread {
    private final BluetoothSocket a;
    private InputStream b;
    private OutputStream c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    boolean f8603d = true;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f8604e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte[] f8605f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f8606g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8607h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f8608i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f8609j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f8610k;

    public a(BluetoothSocket bluetoothSocket, ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> arrayList) {
        this.b = null;
        this.c = null;
        new ArrayList();
        this.f8604e = 0;
        this.f8605f = new byte[KotlinVersion.MAX_COMPONENT_VALUE];
        this.f8606g = false;
        this.f8607h = 0;
        this.f8608i = 0;
        this.f8609j = false;
        this.a = bluetoothSocket;
        try {
            this.b = bluetoothSocket.getInputStream();
            this.c = bluetoothSocket.getOutputStream();
        } catch (IOException unused) {
        }
    }

    public void a() {
        try {
            this.f8603d = false;
            this.a.close();
        } catch (IOException unused) {
        }
    }

    public void b(byte[] bArr) {
        try {
            this.c.write(bArr);
            this.c.flush();
        } catch (IOException unused) {
            this.f8609j = true;
            this.f8603d = false;
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        while (this.f8603d) {
            try {
                int iAvailable = this.b.available();
                this.f8610k = iAvailable;
                if (iAvailable > 0) {
                    int i2 = this.b.read(this.f8605f, this.f8608i, iAvailable);
                    this.f8604e = i2;
                    int i3 = this.f8608i + i2;
                    this.f8608i = i3;
                    if (i3 >= this.f8607h) {
                        this.f8606g = true;
                        this.f8604e = i3;
                        this.f8608i = 0;
                    }
                }
            } catch (IOException e2) {
                e2.printStackTrace();
                this.f8609j = true;
                this.f8603d = false;
                this.a.close();
            } catch (Exception e3) {
                e3.printStackTrace();
                this.f8609j = true;
                this.f8603d = false;
                try {
                    this.a.close();
                } catch (IOException e4) {
                    e4.printStackTrace();
                }
            }
        }
    }
}
