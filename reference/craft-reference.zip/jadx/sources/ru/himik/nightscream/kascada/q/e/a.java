package ru.himik.nightscream.kascada.q.e;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.KotlinVersion;
import ru.himik.nightscream.kascada.Connections.Usb.driver.CdcAcmSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.Ch34xSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.Cp21xxSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.FtdiSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.ProbeTable;
import ru.himik.nightscream.kascada.Connections.Usb.driver.ProlificSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbId;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialProber;
import ru.himik.nightscream.kascada.CustomComponents.b;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class a extends Thread implements ru.himik.nightscream.kascada.q.a {
    int C;
    int D;
    int E;
    String F;
    Context G;
    UsbManager M;
    public UsbSerialPort N;
    UsbDevice O;
    int P;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f9270d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    Handler f9271e;
    int o;
    int a = 3;
    boolean b = true;
    ArrayList<b> c = new ArrayList<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f9272f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f9273g = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f9274h = 0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ArrayList<b> f9275i = new ArrayList<>();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    b f9276j = null;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    ru.himik.nightscream.kascada.x.a f9277k = new ru.himik.nightscream.kascada.x.a();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    long f9278l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    long f9279m = 2000;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f9280n = 3000;
    byte H = 0;
    long I = 0;
    byte J = 0;
    byte[] K = new byte[KotlinVersion.MAX_COMPONENT_VALUE];
    byte[] L = new byte[KotlinVersion.MAX_COMPONENT_VALUE];
    final BroadcastReceiver Q = new C0302a();

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.q.e.a$a, reason: collision with other inner class name */
    class C0302a extends BroadcastReceiver {
        C0302a() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("com.android.example.USB_PERMISSION".equals(intent.getAction())) {
                synchronized (this) {
                    UsbDevice usbDevice = (UsbDevice) intent.getParcelableExtra("device");
                    if (!intent.getBooleanExtra("permission", false)) {
                        Toast.makeText(context, context.getResources().getString(R.string.access_is_denied_for_usb), 1).show();
                    } else if (usbDevice != null) {
                        a.this.H = (byte) 2;
                    }
                }
            }
        }
    }

    public a(ru.himik.nightscream.kascada.Preference.ServerList.a aVar, Handler handler, int i2, Context context, boolean z, int i3) {
        this.f9270d = -1;
        this.o = 9600;
        this.C = 8;
        this.D = 2;
        this.E = 0;
        this.F = "";
        this.P = 0;
        this.o = aVar.a();
        this.C = aVar.b();
        this.D = aVar.j();
        this.E = aVar.e();
        this.F = aVar.h();
        this.f9271e = handler;
        this.f9270d = i2;
        this.G = context;
        this.P = i3;
        this.M = (UsbManager) context.getSystemService("usb");
        start();
    }

    private void g(b bVar, int[] iArr, byte[] bArr) {
        Handler handler;
        int iH;
        int iJ;
        byte b;
        Message messageObtainMessage;
        Handler handler2;
        int iH2;
        int iJ2;
        int i2;
        int i3;
        Integer numValueOf;
        if (bVar == null) {
            return;
        }
        byte bQ = bVar.q();
        if (bQ == 1) {
            int iH3 = bVar.h();
            if (iH3 == 19) {
                handler = this.f9271e;
                iH = com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceListItemSecondary;
                iJ = bVar.j();
                b = bArr[3];
            } else if (iH3 != 22) {
                handler = this.f9271e;
                iH = bVar.h();
                iJ = bVar.j();
                b = bArr[3];
            } else if (bVar.f() > 8) {
                byte[] bArr2 = new byte[2];
                System.arraycopy(bArr, 3, bArr2, 0, 2);
                messageObtainMessage = this.f9271e.obtainMessage(1, 22, bVar.j(), bArr2);
            } else {
                byte[] bArr3 = new byte[1];
                System.arraycopy(bArr, 3, bArr3, 0, 1);
                messageObtainMessage = this.f9271e.obtainMessage(1, 22, bVar.j(), bArr3);
            }
            messageObtainMessage = handler.obtainMessage(1, iH, iJ, Integer.valueOf((b >> 0) & 1));
        } else if (bQ != 2) {
            if (bQ != 3) {
                if (bQ != 4) {
                    if (bQ != 5 || bVar.h() == 22) {
                        return;
                    }
                    handler2 = this.f9271e;
                    iH2 = bVar.h();
                    iJ2 = bVar.j();
                    numValueOf = Integer.valueOf(iArr[4]);
                    messageObtainMessage = handler2.obtainMessage(1, iH2, iJ2, numValueOf);
                } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                    int[] iArr2 = new int[bVar.g() * 2];
                    System.arraycopy(iArr, 3, iArr2, 0, bVar.g() * 2);
                    messageObtainMessage = this.f9271e.obtainMessage(1, bVar.h(), bVar.j(), iArr2);
                } else {
                    handler2 = this.f9271e;
                    iH2 = bVar.h();
                    iJ2 = bVar.j();
                    i2 = iArr[3] * 256;
                    i3 = iArr[4];
                    numValueOf = Integer.valueOf(i2 + i3);
                    messageObtainMessage = handler2.obtainMessage(1, iH2, iJ2, numValueOf);
                }
            } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                int[] iArr3 = new int[bVar.g() * 2];
                System.arraycopy(iArr, 3, iArr3, 0, bVar.g() * 2);
                messageObtainMessage = this.f9271e.obtainMessage(1, bVar.h(), bVar.j(), iArr3);
            } else {
                handler2 = this.f9271e;
                iH2 = bVar.h();
                iJ2 = bVar.j();
                i2 = iArr[3] * 256;
                i3 = iArr[4];
                numValueOf = Integer.valueOf(i2 + i3);
                messageObtainMessage = handler2.obtainMessage(1, iH2, iJ2, numValueOf);
            }
        } else if (bVar.h() != 22) {
            handler = this.f9271e;
            iH = bVar.h();
            iJ = bVar.j();
            b = bArr[3];
            messageObtainMessage = handler.obtainMessage(1, iH, iJ, Integer.valueOf((b >> 0) & 1));
        } else if (bVar.f() > 8) {
            byte[] bArr4 = new byte[2];
            System.arraycopy(bArr, 3, bArr4, 0, 2);
            messageObtainMessage = this.f9271e.obtainMessage(1, 22, bVar.j(), bArr4);
        } else {
            byte[] bArr5 = new byte[1];
            System.arraycopy(bArr, 3, bArr5, 0, 1);
            messageObtainMessage = this.f9271e.obtainMessage(1, 22, bVar.j(), bArr5);
        }
        messageObtainMessage.sendToTarget();
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public int a() {
        return this.f9270d;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public String b() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void c(b bVar) {
        if (bVar != null) {
            this.f9275i.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void cancel() {
        this.b = false;
        try {
            UsbSerialPort usbSerialPort = this.N;
            if (usbSerialPort != null) {
                usbSerialPort.purgeHwBuffers(true, true);
                this.N.close();
            }
        } catch (IOException | Exception unused) {
        }
        try {
            this.G.unregisterReceiver(this.Q);
        } catch (Exception unused2) {
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void d() {
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void e(b bVar) {
        if (bVar != null) {
            this.f9275i.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void f(b bVar) {
        this.c.add(bVar);
    }

    /* JADX WARN: Code duplicated, block: B:107:0x01ee  */
    /* JADX WARN: Code duplicated, block: B:108:0x01f0  */
    /* JADX WARN: Code duplicated, block: B:72:0x0155  */
    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        int iG;
        int iG2;
        int i2;
        byte b = 1;
        this.f9271e.obtainMessage(8, 1, this.f9270d).sendToTarget();
        while (true) {
            boolean z = this.b;
            if (!z) {
                return;
            }
            byte b2 = this.H;
            if (b2 == 0) {
                ProbeTable probeTable = new ProbeTable();
                probeTable.addProduct(5461, 4, Cp21xxSerialDriver.class);
                probeTable.addProduct(UsbId.VENDOR_QINHENG, 1010, Ch34xSerialDriver.class);
                probeTable.addProduct(5461, 22, CdcAcmSerialDriver.class);
                UsbSerialProber usbSerialProber = new UsbSerialProber(probeTable);
                probeTable.addDriver(CdcAcmSerialDriver.class);
                probeTable.addDriver(Cp21xxSerialDriver.class);
                probeTable.addDriver(FtdiSerialDriver.class);
                probeTable.addDriver(ProlificSerialDriver.class);
                probeTable.addDriver(Ch34xSerialDriver.class);
                List<UsbSerialDriver> listFindAllDrivers = usbSerialProber.findAllDrivers(this.M);
                ArrayList arrayList = new ArrayList();
                Iterator<UsbSerialDriver> it = listFindAllDrivers.iterator();
                while (it.hasNext()) {
                    arrayList.addAll(it.next().getPorts());
                }
                if (arrayList.size() == 0) {
                    this.H = (byte) 5;
                } else {
                    UsbSerialPort usbSerialPort = (UsbSerialPort) arrayList.get(0);
                    this.N = usbSerialPort;
                    this.O = usbSerialPort.getDriver().getDevice();
                    PendingIntent broadcast = PendingIntent.getBroadcast(this.G, 0, new Intent("com.android.example.USB_PERMISSION"), 0);
                    this.G.registerReceiver(this.Q, new IntentFilter("com.android.example.USB_PERMISSION"));
                    this.M.requestPermission(this.O, broadcast);
                    this.H = (byte) 1;
                    this.I = System.currentTimeMillis();
                    this.f9271e.obtainMessage(8, 1, this.f9270d).sendToTarget();
                }
                b = 1;
            } else if (b2 == b) {
                if (!z) {
                    return;
                }
                try {
                    Thread.sleep(500L);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
                this.f9272f = this.c.size();
                if (System.currentTimeMillis() - this.I > 5000) {
                    this.H = (byte) 0;
                }
            } else if (b2 == 2) {
                if (!z) {
                    return;
                }
                try {
                    this.N.open(this.M.openDevice(this.N.getDriver().getDevice()));
                    this.N.setParameters(this.o, this.C, this.D, this.E);
                } catch (IOException | Exception unused) {
                    this.H = (byte) 5;
                }
                this.H = (byte) 3;
            } else if (b2 == 3) {
                if (!z) {
                    return;
                }
                if (this.f9275i.size() > 0) {
                    b bVar = this.f9275i.get(0);
                    this.f9276j = bVar;
                    if (this.N == null || bVar == null) {
                        this.H = (byte) 5;
                    } else {
                        try {
                            if (this.N.write(this.f9277k.c(this.f9276j, this.a), 100) == this.f9277k.c(bVar, this.a).length) {
                                this.f9278l = System.currentTimeMillis();
                                this.f9275i.remove(0);
                                this.H = (byte) 4;
                            } else {
                                this.H = (byte) 5;
                            }
                        } catch (IOException unused2) {
                            this.H = (byte) 5;
                        }
                    }
                    b bVar2 = this.f9276j;
                    if (bVar2 != null) {
                        byte bQ = bVar2.q();
                        if (bQ != 16) {
                            switch (bQ) {
                                case 1:
                                case 2:
                                    iG2 = 6;
                                    this.f9274h = iG2;
                                    break;
                                case 3:
                                case 4:
                                    iG2 = (this.f9276j.g() * 2) + 5;
                                    this.f9274h = iG2;
                                    break;
                                case 5:
                                case 6:
                                    this.f9274h = 8;
                                    break;
                            }
                        } else {
                            iG2 = 6;
                            this.f9274h = iG2;
                        }
                    }
                    this.J = (byte) 0;
                } else if (this.f9272f > 0) {
                    b bVar3 = this.c.get(this.f9273g);
                    this.f9276j = bVar3;
                    if (bVar3.h() == 19 && this.f9276j.q() == 6 && !this.f9276j.s()) {
                        int i3 = this.f9273g;
                        if (i3 != this.f9272f - 1) {
                            this.f9273g = i3 + 1;
                        } else {
                            this.f9273g = 0;
                        }
                    } else {
                        if (this.N != null) {
                            try {
                                if (this.N.write(this.f9277k.c(this.f9276j, this.a), 100) == this.f9277k.c(this.f9276j, this.a).length) {
                                    this.f9278l = System.currentTimeMillis();
                                    this.H = (byte) 4;
                                } else {
                                    this.H = (byte) 5;
                                }
                            } catch (IOException unused3) {
                                this.H = (byte) 5;
                            }
                        } else {
                            this.H = (byte) 5;
                        }
                        b bVar4 = this.f9276j;
                        if (bVar4 != null) {
                            byte bQ2 = bVar4.q();
                            if (bQ2 == 15) {
                                this.f9274h = 8;
                            } else if (bQ2 != 16) {
                                switch (bQ2) {
                                    case 1:
                                    case 2:
                                        if (this.f9276j.f() > 8) {
                                            iG = 7;
                                        } else {
                                            iG = 6;
                                        }
                                        this.f9274h = iG;
                                        break;
                                    case 3:
                                    case 4:
                                        iG = (this.f9276j.g() * 2) + 5;
                                        this.f9274h = iG;
                                        break;
                                    case 5:
                                    case 6:
                                        this.f9274h = 8;
                                        break;
                                }
                            } else {
                                iG = 6;
                                this.f9274h = iG;
                            }
                        }
                        this.J = (byte) 0;
                        int i4 = this.f9273g;
                        if (i4 != this.f9272f - 1) {
                            this.f9273g = i4 + 1;
                        } else {
                            this.f9273g = 0;
                        }
                    }
                }
                Thread.sleep(5L);
            } else if (b2 == 4) {
                if (!z) {
                    return;
                }
                try {
                    i2 = this.N.read(this.L, 100);
                } catch (IOException unused4) {
                    i2 = 0;
                }
                if (i2 > 0) {
                    System.arraycopy(this.L, 0, this.K, this.J, i2);
                    this.J = (byte) (this.J + i2);
                }
                int i5 = this.J;
                if (i5 >= this.f9274h) {
                    int[] iArr = new int[i5];
                    for (int i6 = 0; i6 < this.J; i6++) {
                        iArr[i6] = this.K[i6] & 255;
                    }
                    if (this.f9276j.b() == iArr[0] && this.f9276j.q() == iArr[b]) {
                        g(this.f9276j, iArr, this.K);
                        try {
                            int i7 = this.P;
                            if (i7 > 0) {
                                Thread.sleep(i7);
                            }
                            Thread.sleep(5L);
                        } catch (InterruptedException e3) {
                            e3.printStackTrace();
                        }
                    } else {
                        this.f9271e.obtainMessage(2, this.f9276j.h(), this.f9276j.j()).sendToTarget();
                    }
                    this.H = (byte) 3;
                }
                if (System.currentTimeMillis() - this.f9278l >= this.f9279m) {
                    this.f9271e.obtainMessage(2, this.f9276j.h(), this.f9276j.j()).sendToTarget();
                    this.H = (byte) 3;
                    try {
                        Thread.sleep(50L);
                    } catch (InterruptedException e4) {
                        e4.printStackTrace();
                    }
                }
            } else if (b2 == 5) {
                if (!z) {
                    return;
                }
                try {
                    this.f9271e.obtainMessage(8, 2, this.f9270d).sendToTarget();
                    Thread.sleep(this.f9280n);
                    this.H = (byte) 0;
                } catch (Exception unused5) {
                }
            }
            b = 1;
        }
    }
}
