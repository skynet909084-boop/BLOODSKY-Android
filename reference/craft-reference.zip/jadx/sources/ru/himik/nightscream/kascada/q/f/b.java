package ru.himik.nightscream.kascada.q.f;

import android.graphics.Bitmap;
import android.os.CountDownTimer;
import com.karumi.dexter.R;
import f.f.b.e;
import i.a.a.f.w.g;
import i.a.b.p0.m.z;
import i.a.b.t;
import io.ktor.client.engine.cio.d;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Objects;
import kotlin.b0.c.l;
import kotlin.b0.c.p;
import kotlin.b0.d.j;
import kotlin.b0.d.k;
import kotlin.n;
import kotlin.u;
import kotlin.y.j.a.f;
import kotlinx.coroutines.b1;
import kotlinx.coroutines.c3.s;
import kotlinx.coroutines.i;
import kotlinx.coroutines.m0;
import kotlinx.coroutines.n0;
import kotlinx.coroutines.x0;
import ru.himik.nightscream.kascada.CustomComponents.v;
import ru.himik.nightscream.kascada.CustomComponents.y;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.himik.nightscream.kascada.q.f.a.h;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    public i.a.a.a a;
    public i.a.a.f.w.b b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CountDownTimer f9285d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private long f9288g;
    private e c = new e();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f9286e = true;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private long f9287f = 1000;

    static final class a extends k implements l<i.a.a.b<d>, u> {
        public static final a b = new a();

        a() {
            super(1);
        }

        public final void a(i.a.a.b<d> bVar) {
            j.d(bVar, "$this$HttpClient");
            i.a.a.b.j(bVar, g.f6512e, null, 2, null);
        }

        @Override // kotlin.b0.c.l
        public /* bridge */ /* synthetic */ u l(i.a.a.b<d> bVar) {
            a(bVar);
            return u.a;
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.q.f.b$b, reason: collision with other inner class name */
    public static final class CountDownTimerC0303b extends CountDownTimer {

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.q.f.b$b$a */
        @f(c = "ru.himik.nightscream.kascada.Connections.WebSocketClient.WebSocketClient$connect$1$onTick$1", f = "WebSocketClient.kt", l = {R.styleable.AppCompatTheme_panelMenuListTheme, R.styleable.AppCompatTheme_panelMenuListWidth, R.styleable.AppCompatTheme_popupMenuStyle}, m = "invokeSuspend")
        static final class a extends kotlin.y.j.a.l implements p<m0, kotlin.y.d<? super u>, Object> {
            int a;
            final /* synthetic */ b b;
            final /* synthetic */ byte[] c;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(b bVar, byte[] bArr, kotlin.y.d<? super a> dVar) {
                super(2, dVar);
                this.b = bVar;
                this.c = bArr;
            }

            @Override // kotlin.y.j.a.a
            public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
                return new a(this.b, this.c, dVar);
            }

            @Override // kotlin.b0.c.p
            public final Object invoke(m0 m0Var, kotlin.y.d<? super u> dVar) {
                return ((a) create(m0Var, dVar)).invokeSuspend(u.a);
            }

            /* JADX WARN: Code duplicated, block: B:20:0x006c A[RETURN] */
            @Override // kotlin.y.j.a.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                i.a.a.f.w.b bVarJ;
                String strR;
                Object objC = kotlin.y.i.d.c();
                int i2 = this.a;
                if (i2 != 0) {
                    if (i2 == 1) {
                        n.b(obj);
                    } else if (i2 == 2) {
                        n.b(obj);
                        bVarJ = this.b.j();
                        strR = this.b.i().r(this.b.f());
                        j.c(strR, "gson.toJson(createMsgControls())");
                        this.a = 3;
                        if (z.d(bVarJ, strR, this) == objC) {
                            return objC;
                        }
                    } else {
                        if (i2 != 3) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        n.b(obj);
                    }
                    return u.a;
                }
                n.b(obj);
                i.a.a.f.w.b bVarJ2 = this.b.j();
                i.a.b.p0.m.f.a aVar = new i.a.b.p0.m.f.a(true, this.c);
                this.a = 1;
                if (bVarJ2.k0(aVar, this) == objC) {
                    return objC;
                }
                this.a = 2;
                if (x0.a(100L, this) == objC) {
                    return objC;
                }
                bVarJ = this.b.j();
                strR = this.b.i().r(this.b.f());
                j.c(strR, "gson.toJson(createMsgControls())");
                this.a = 3;
                if (z.d(bVarJ, strR, this) == objC) {
                    return objC;
                }
                return u.a;
            }
        }

        CountDownTimerC0303b() {
            super(Long.MAX_VALUE, 250L);
        }

        @Override // android.os.CountDownTimer
        public void onFinish() {
            b.this.k().cancel();
            b.this.k().start();
        }

        @Override // android.os.CountDownTimer
        public void onTick(long j2) {
            if (System.currentTimeMillis() - b.this.f9288g >= b.this.l()) {
                if (!n0.e(b.this.j())) {
                    b.this.k().cancel();
                }
                b.this.f9288g = System.currentTimeMillis();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                mbCanvas.X0.setDrawingCacheEnabled(true);
                Bitmap.createBitmap(mbCanvas.X0.getDrawingCache()).compress(Bitmap.CompressFormat.JPEG, 20, byteArrayOutputStream);
                mbCanvas.X0.setDrawingCacheEnabled(false);
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                j.c(byteArray, "baos.toByteArray()");
                i.d(n0.a(b1.b()), null, null, new a(b.this, byteArray, null), 3, null);
            }
        }
    }

    @f(c = "ru.himik.nightscream.kascada.Connections.WebSocketClient.WebSocketClient$connect$2", f = "WebSocketClient.kt", l = {R.styleable.AppCompatTheme_textAppearanceListItemSecondary}, m = "invokeSuspend")
    static final class c extends kotlin.y.j.a.l implements p<m0, kotlin.y.d<? super u>, Object> {
        int a;

        @f(c = "ru.himik.nightscream.kascada.Connections.WebSocketClient.WebSocketClient$connect$2$1", f = "WebSocketClient.kt", l = {R.styleable.AppCompatTheme_windowActionBarOverlay, R.styleable.AppCompatTheme_windowFixedHeightMinor, 166}, m = "invokeSuspend")
        static final class a extends kotlin.y.j.a.l implements p<i.a.a.f.w.b, kotlin.y.d<? super u>, Object> {
            int a;
            private /* synthetic */ Object b;
            final /* synthetic */ b c;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(b bVar, kotlin.y.d<? super a> dVar) {
                super(2, dVar);
                this.c = bVar;
            }

            @Override // kotlin.b0.c.p
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public final Object invoke(i.a.a.f.w.b bVar, kotlin.y.d<? super u> dVar) {
                return ((a) create(bVar, dVar)).invokeSuspend(u.a);
            }

            @Override // kotlin.y.j.a.a
            public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
                a aVar = new a(this.c, dVar);
                aVar.b = obj;
                return aVar;
            }

            /* JADX WARN: Code duplicated, block: B:17:0x006b  */
            /* JADX WARN: Code duplicated, block: B:19:0x0079 A[RETURN] */
            /* JADX WARN: Code duplicated, block: B:20:0x007a  */
            /* JADX WARN: Code duplicated, block: B:23:0x0085  */
            /* JADX WARN: Code duplicated, block: B:25:0x00a7  */
            /* JADX WARN: Code duplicated, block: B:27:0x00c0  */
            /* JADX WARN: Code duplicated, block: B:29:0x00c3  */
            /* JADX WARN: Code duplicated, block: B:31:0x00c7  */
            /* JADX WARN: Code duplicated, block: B:34:0x00cd  */
            /* JADX WARN: Code duplicated, block: B:35:0x00eb  */
            /* JADX WARN: Code duplicated, block: B:36:0x0115  */
            /* JADX WARN: Code duplicated, block: B:37:0x0126  */
            /* JADX WARN: Code duplicated, block: B:39:0x0137  */
            /* JADX WARN: Code duplicated, block: B:41:0x013f  */
            /* JADX WARN: Code duplicated, block: B:43:0x0152 A[RETURN] */
            /* JADX WARN: Code duplicated, block: B:44:0x0153  */
            /* JADX WARN: Code duplicated, block: B:48:0x0184  */
            /* JADX WARN: Code duplicated, block: B:53:0x015b A[EXC_TOP_SPLITTER, SYNTHETIC] */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0186 -> B:15:0x0063). Please report as a decompilation issue!!! */
            /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                */
            @Override // kotlin.y.j.a.a
            public final java.lang.Object invokeSuspend(java.lang.Object r15) {
                /*
                    Method dump skipped, instruction units count: 398
                    To view this dump add '--comments-level debug' option
                */
                throw new UnsupportedOperationException("Method not decompiled: ru.himik.nightscream.kascada.q.f.b.c.a.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        c(kotlin.y.d<? super c> dVar) {
            super(2, dVar);
        }

        @Override // kotlin.y.j.a.a
        public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
            return b.this.new c(dVar);
        }

        @Override // kotlin.b0.c.p
        public final Object invoke(m0 m0Var, kotlin.y.d<? super u> dVar) {
            return ((c) create(m0Var, dVar)).invokeSuspend(u.a);
        }

        @Override // kotlin.y.j.a.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object objC = kotlin.y.i.d.c();
            int i2 = this.a;
            try {
                if (i2 == 0) {
                    n.b(obj);
                    i.a.a.a aVarH = b.this.h();
                    t tVarB = t.f6743j.b();
                    a aVar = new a(b.this, null);
                    this.a = 1;
                    if (i.a.a.f.w.a.c(aVarH, (16 & 1) != 0 ? t.f6743j.b() : tVarB, (16 & 2) != 0 ? "localhost" : "94.250.249.225", (16 & 4) != 0 ? 0 : 8084, (16 & 8) != 0 ? "/" : "/kascada-control", (16 & 16) != 0 ? i.a.a.f.w.a.f.b : null, aVar, this) == objC) {
                        return objC;
                    }
                } else {
                    if (i2 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    n.b(obj);
                }
            } catch (s e2) {
                e2.printStackTrace();
                b.this.k().cancel();
            }
            return u.a;
        }
    }

    public b() {
        n(i.a.a.c.a(io.ktor.client.engine.cio.a.a, a.b));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final h f() {
        ArrayList arrayList = new ArrayList();
        int i2 = MyApplication.b().o;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            int i5 = 1;
            if (i4 >= i2) {
                break;
            }
            int i6 = i4 + 1;
            String strD = MyApplication.b().C.get(i4).d();
            j.c(strD, "MyApplication.get().backgroundScreen_[i].name");
            String strE = MyApplication.b().C.get(i4).e();
            j.c(strE, "MyApplication.get().backgroundScreen_[i].password");
            if (strE.length() <= 0) {
                i5 = 0;
            }
            arrayList.add(new ru.himik.nightscream.kascada.q.f.a.f.a(i6, strD, i5));
            i4 = i6;
        }
        ru.himik.nightscream.kascada.q.f.a.f fVar = new ru.himik.nightscream.kascada.q.f.a.f(mbCanvas.a1, MyApplication.b().o, MyApplication.b().f9040h, MyApplication.b().f9041i, arrayList);
        ArrayList arrayList2 = new ArrayList();
        int size = MyApplication.b().J.size();
        int i7 = 0;
        while (i7 < size) {
            int i8 = i7 + 1;
            int iKeyAt = MyApplication.b().J.keyAt(i7);
            Object obj = MyApplication.b().J.get(iKeyAt);
            Objects.requireNonNull(obj, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomButton");
            if (((ru.himik.nightscream.kascada.CustomComponents.e) obj).getNumScreen() == mbCanvas.a1) {
                Object obj2 = MyApplication.b().J.get(iKeyAt);
                Objects.requireNonNull(obj2, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomButton");
                ru.himik.nightscream.kascada.CustomComponents.e eVar = (ru.himik.nightscream.kascada.CustomComponents.e) obj2;
                arrayList2.add(new ru.himik.nightscream.kascada.q.f.a.d(eVar.getIdComponent(), iKeyAt, (int) eVar.getX(), (int) eVar.getY(), eVar.getWidth(), eVar.getHeight(), ""));
            }
            i7 = i8;
        }
        int size2 = MyApplication.b().F.size();
        int i9 = 0;
        while (i9 < size2) {
            int i10 = i9 + 1;
            int iKeyAt2 = MyApplication.b().F.keyAt(i9);
            Object obj3 = MyApplication.b().F.get(iKeyAt2);
            Objects.requireNonNull(obj3, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSwitch");
            if (((y) obj3).getNumScreen() == mbCanvas.a1) {
                Object obj4 = MyApplication.b().F.get(iKeyAt2);
                Objects.requireNonNull(obj4, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSwitch");
                y yVar = (y) obj4;
                arrayList2.add(new ru.himik.nightscream.kascada.q.f.a.d(yVar.getIdComponent(), iKeyAt2, (int) yVar.getX(), (int) yVar.getY(), yVar.getWidth(), yVar.getHeight(), ""));
            }
            i9 = i10;
        }
        int size3 = MyApplication.b().L.size();
        int i11 = 0;
        while (i11 < size3) {
            int i12 = i11 + 1;
            int iKeyAt3 = MyApplication.b().L.keyAt(i11);
            Object obj5 = MyApplication.b().L.get(iKeyAt3);
            Objects.requireNonNull(obj5, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomEditNumber");
            if (((ru.himik.nightscream.kascada.CustomComponents.i) obj5).getNumScreen() == mbCanvas.a1) {
                Object obj6 = MyApplication.b().L.get(iKeyAt3);
                Objects.requireNonNull(obj6, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomEditNumber");
                ru.himik.nightscream.kascada.CustomComponents.i iVar = (ru.himik.nightscream.kascada.CustomComponents.i) obj6;
                String password = iVar.getPassword();
                j.c(password, "cb.password");
                arrayList2.add(new ru.himik.nightscream.kascada.q.f.a.d(iVar.getIdComponent(), iKeyAt3, (int) iVar.getX(), (int) iVar.getY(), iVar.getWidth(), iVar.getHeight(), this.c.r(new ru.himik.nightscream.kascada.q.f.a.d.a(password.length() > 0 ? 1 : 0, iVar.getType(), String.valueOf(iVar.getMinValue()), String.valueOf(iVar.getMaxValue())))));
            }
            i11 = i12;
        }
        int size4 = MyApplication.b().Q.size();
        while (i3 < size4) {
            int i13 = i3 + 1;
            int iKeyAt4 = MyApplication.b().Q.keyAt(i3);
            Object obj7 = MyApplication.b().Q.get(iKeyAt4);
            Objects.requireNonNull(obj7, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSeekBar");
            if (((v) obj7).getNumScreen() == mbCanvas.a1) {
                Object obj8 = MyApplication.b().Q.get(iKeyAt4);
                Objects.requireNonNull(obj8, "null cannot be cast to non-null type ru.himik.nightscream.kascada.CustomComponents.CustomSeekBar");
                v vVar = (v) obj8;
                arrayList2.add(new ru.himik.nightscream.kascada.q.f.a.d(vVar.getIdComponent(), iKeyAt4, (int) vVar.getX(), (int) vVar.getY(), vVar.getWidth(), vVar.getHeight(), this.c.r(new ru.himik.nightscream.kascada.q.f.a.d.b(vVar.getMax()))));
            }
            i3 = i13;
        }
        int i14 = ru.himik.nightscream.kascada.q.f.a.c.CONTROLS.getI();
        String str = MyApplication.b().f9044l;
        int i15 = ru.himik.nightscream.kascada.q.f.a.b.KASCADA.getI();
        String strR = this.c.r(new ru.himik.nightscream.kascada.q.f.a.i(fVar, arrayList2));
        j.c(str, "saveKey");
        j.c(strR, "toJson(OtherControls(\n  …ntrols)\n                )");
        return new h(i14, i15, str, strR);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final h g() {
        int i2 = ru.himik.nightscream.kascada.q.f.a.c.ON_CONNECT.getI();
        String str = MyApplication.b().f9044l;
        int i3 = ru.himik.nightscream.kascada.q.f.a.b.KASCADA.getI();
        j.c(str, "saveKey");
        return new h(i2, i3, str, "");
    }

    public final void e() {
        ru.himik.nightscream.kascada.Utils.l lVar = ru.himik.nightscream.kascada.Utils.l.a;
        if (lVar.f() && lVar.k() && MyApplication.b().f9038f) {
            this.f9286e = true;
            p(new CountDownTimerC0303b());
            i.d(n0.a(b1.b()), null, null, new c(null), 3, null);
        }
    }

    public final i.a.a.a h() {
        i.a.a.a aVar = this.a;
        if (aVar != null) {
            return aVar;
        }
        j.m("client");
        throw null;
    }

    public final e i() {
        return this.c;
    }

    public final i.a.a.f.w.b j() {
        i.a.a.f.w.b bVar = this.b;
        if (bVar != null) {
            return bVar;
        }
        j.m("session");
        throw null;
    }

    public final CountDownTimer k() {
        CountDownTimer countDownTimer = this.f9285d;
        if (countDownTimer != null) {
            return countDownTimer;
        }
        j.m("timer");
        throw null;
    }

    public final long l() {
        return this.f9287f;
    }

    public final boolean m() {
        return this.f9286e;
    }

    public final void n(i.a.a.a aVar) {
        j.d(aVar, "<set-?>");
        this.a = aVar;
    }

    public final void o(i.a.a.f.w.b bVar) {
        j.d(bVar, "<set-?>");
        this.b = bVar;
    }

    public final void p(CountDownTimer countDownTimer) {
        j.d(countDownTimer, "<set-?>");
        this.f9285d = countDownTimer;
    }
}
