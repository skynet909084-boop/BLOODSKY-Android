package ru.himik.nightscream.kascada.Bd.Import;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.karumi.dexter.R;
import com.sun.mail.imap.IMAPStore;
import com.yandex.metrica.YandexMetrica;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import kotlin.b0.c.p;
import kotlin.b0.d.v;
import kotlin.i0.q;
import kotlin.i0.r;
import kotlin.n;
import kotlin.u;
import kotlin.w.w;
import kotlin.y.j.a.l;
import kotlinx.coroutines.b1;
import kotlinx.coroutines.f2;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.m0;
import kotlinx.coroutines.n1;
import kotlinx.coroutines.x0;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;

/* JADX INFO: loaded from: classes.dex */
public final class h {
    private ArrayList<j> a = new ArrayList<>();
    public i b;

    public static final class a<T> implements Comparator {
        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.util.Comparator
        public final int compare(T t, T t2) {
            return kotlin.x.b.a(Boolean.valueOf(((File) t).isFile()), Boolean.valueOf(((File) t2).isFile()));
        }
    }

    @kotlin.y.j.a.f(c = "ru.himik.nightscream.kascada.Bd.Import.ImportPresenter$unzipAndInstall$1", f = "ImportPresenter.kt", l = {R.styleable.AppCompatTheme_spinnerStyle}, m = "invokeSuspend")
    static final class b extends l implements p<m0, kotlin.y.d<? super u>, Object> {
        int a;
        final /* synthetic */ File b;
        final /* synthetic */ h c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ String f8590d;

        @kotlin.y.j.a.f(c = "ru.himik.nightscream.kascada.Bd.Import.ImportPresenter$unzipAndInstall$1$1", f = "ImportPresenter.kt", l = {R.styleable.AppCompatTheme_switchStyle, R.styleable.AppCompatTheme_windowActionModeOverlay, R.styleable.AppCompatTheme_toolbarNavigationButtonStyle, R.styleable.AppCompatTheme_windowActionModeOverlay, R.styleable.AppCompatTheme_windowActionModeOverlay}, m = "invokeSuspend")
        static final class a extends l implements p<m0, kotlin.y.d<? super u>, Object> {
            Object a;
            int b;
            final /* synthetic */ File c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            final /* synthetic */ h f8591d;

            /* JADX INFO: renamed from: e, reason: collision with root package name */
            final /* synthetic */ String f8592e;

            /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Import.h$b$a$a, reason: collision with other inner class name */
            @kotlin.y.j.a.f(c = "ru.himik.nightscream.kascada.Bd.Import.ImportPresenter$unzipAndInstall$1$1$3", f = "ImportPresenter.kt", l = {}, m = "invokeSuspend")
            static final class C0284a extends l implements p<m0, kotlin.y.d<? super u>, Object> {
                int a;
                final /* synthetic */ Exception b;
                final /* synthetic */ h c;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                C0284a(Exception exc, h hVar, kotlin.y.d<? super C0284a> dVar) {
                    super(2, dVar);
                    this.b = exc;
                    this.c = hVar;
                }

                @Override // kotlin.y.j.a.a
                public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
                    return new C0284a(this.b, this.c, dVar);
                }

                @Override // kotlin.b0.c.p
                public final Object invoke(m0 m0Var, kotlin.y.d<? super u> dVar) {
                    return ((C0284a) create(m0Var, dVar)).invokeSuspend(u.a);
                }

                @Override // kotlin.y.j.a.a
                public final Object invokeSuspend(Object obj) throws Throwable {
                    kotlin.y.i.d.c();
                    if (this.a != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    n.b(obj);
                    this.b.printStackTrace();
                    YandexMetrica.reportError("Ошибка во время распаковки архива", this.b);
                    this.c.d().b();
                    return u.a;
                }
            }

            /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Import.h$b$a$b, reason: collision with other inner class name */
            @kotlin.y.j.a.f(c = "ru.himik.nightscream.kascada.Bd.Import.ImportPresenter$unzipAndInstall$1$1$4", f = "ImportPresenter.kt", l = {}, m = "invokeSuspend")
            static final class C0285b extends l implements p<m0, kotlin.y.d<? super u>, Object> {
                int a;
                final /* synthetic */ h b;
                final /* synthetic */ v<String> c;

                /* JADX INFO: renamed from: d, reason: collision with root package name */
                final /* synthetic */ String f8593d;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                C0285b(h hVar, v<String> vVar, String str, kotlin.y.d<? super C0285b> dVar) {
                    super(2, dVar);
                    this.b = hVar;
                    this.c = vVar;
                    this.f8593d = str;
                }

                @Override // kotlin.y.j.a.a
                public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
                    return new C0285b(this.b, this.c, this.f8593d, dVar);
                }

                @Override // kotlin.b0.c.p
                public final Object invoke(m0 m0Var, kotlin.y.d<? super u> dVar) {
                    return ((C0285b) create(m0Var, dVar)).invokeSuspend(u.a);
                }

                @Override // kotlin.y.j.a.a
                public final Object invokeSuspend(Object obj) throws Throwable {
                    kotlin.y.i.d.c();
                    if (this.a != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    n.b(obj);
                    this.b.d().e();
                    File file = new File((ru.himik.nightscream.kascada.Utils.n.a.e() + this.c.a + '/') + this.c.a + ".pro");
                    Reader inputStreamReader = new InputStreamReader(new FileInputStream(file), kotlin.i0.d.b);
                    BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
                    try {
                        String strE = kotlin.a0.p.e(bufferedReader);
                        kotlin.a0.c.a(bufferedReader, null);
                        MyApplication.b().g0.edit().putString(this.c.a, this.f8593d).apply();
                        h hVar = this.b;
                        String absolutePath = file.getAbsolutePath();
                        kotlin.b0.d.j.c(absolutePath, "filePro.absolutePath");
                        hVar.f(strE, absolutePath);
                        return u.a;
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            kotlin.a0.c.a(bufferedReader, th);
                            throw th2;
                        }
                    }
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(File file, h hVar, String str, kotlin.y.d<? super a> dVar) {
                super(2, dVar);
                this.c = file;
                this.f8591d = hVar;
                this.f8592e = str;
            }

            @Override // kotlin.y.j.a.a
            public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
                return new a(this.c, this.f8591d, this.f8592e, dVar);
            }

            @Override // kotlin.b0.c.p
            public final Object invoke(m0 m0Var, kotlin.y.d<? super u> dVar) {
                return ((a) create(m0Var, dVar)).invokeSuspend(u.a);
            }

            /* JADX WARN: Code duplicated, block: B:43:0x00f4 A[RETURN] */
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r1v0, types: [int] */
            /* JADX WARN: Type inference failed for: r1v3, types: [java.lang.Object, kotlin.b0.d.v] */
            /* JADX WARN: Type inference failed for: r8v8, types: [T, java.lang.String] */
            @Override // kotlin.y.j.a.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                v vVar;
                f2 f2VarC;
                C0285b c0285b;
                Object objC = kotlin.y.i.d.c();
                v vVar2 = this.b;
                try {
                    try {
                        if (vVar2 != 0) {
                            if (vVar2 != 1) {
                                if (vVar2 != 2) {
                                    if (vVar2 == 3) {
                                        v vVar3 = (v) this.a;
                                        n.b(obj);
                                        vVar = vVar3;
                                        f2VarC = b1.c();
                                        c0285b = new C0285b(this.f8591d, vVar, this.f8592e, null);
                                        this.a = null;
                                        this.b = 4;
                                        if (kotlinx.coroutines.g.h(f2VarC, c0285b, this) == objC) {
                                            return objC;
                                        }
                                    } else if (vVar2 != 4) {
                                        if (vVar2 != 5) {
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                        }
                                        Throwable th = (Throwable) this.a;
                                        n.b(obj);
                                        throw th;
                                    }
                                }
                                n.b(obj);
                            } else {
                                n.b(obj);
                            }
                            return u.a;
                        }
                        n.b(obj);
                        this.b = 1;
                        if (x0.a(1000L, this) == objC) {
                            return objC;
                        }
                        k.a.a.a aVar = new k.a.a.a(this.c);
                        List<k.a.a.f.i> listH = aVar.h();
                        kotlin.b0.d.j.c(listH, "zip.fileHeaders");
                        ArrayList arrayList = new ArrayList();
                        for (Object obj2 : listH) {
                            if (((k.a.a.f.i) obj2).s()) {
                                arrayList.add(obj2);
                            }
                        }
                        Iterator it = arrayList.iterator();
                        while (it.hasNext()) {
                            String strK = ((k.a.a.f.i) it.next()).k();
                            kotlin.b0.d.j.c(strK, "it.fileName");
                            vVar2.a = r.D0(strK, "/", null, 2, null);
                        }
                        aVar.f(ru.himik.nightscream.kascada.Utils.n.a.e());
                        f2 f2VarC2 = b1.c();
                        C0285b c0285b2 = new C0285b(this.f8591d, vVar2, this.f8592e, null);
                        this.b = 2;
                        if (kotlinx.coroutines.g.h(f2VarC2, c0285b2, this) == objC) {
                            return objC;
                        }
                    } catch (Exception e2) {
                        f2 f2VarC3 = b1.c();
                        C0284a c0284a = new C0284a(e2, this.f8591d, null);
                        this.a = vVar2;
                        this.b = 3;
                        vVar = vVar2;
                        if (kotlinx.coroutines.g.h(f2VarC3, c0284a, this) == objC) {
                            return objC;
                        }
                        f2VarC = b1.c();
                        c0285b = new C0285b(this.f8591d, vVar, this.f8592e, null);
                        this.a = null;
                        this.b = 4;
                        if (kotlinx.coroutines.g.h(f2VarC, c0285b, this) == objC) {
                            return objC;
                        }
                    }
                    vVar2 = new v();
                    vVar2.a = "";
                    return u.a;
                } catch (Throwable th2) {
                    f2 f2VarC4 = b1.c();
                    C0285b c0285b3 = new C0285b(this.f8591d, vVar2, this.f8592e, null);
                    this.a = th2;
                    this.b = 5;
                    if (kotlinx.coroutines.g.h(f2VarC4, c0285b3, this) == objC) {
                        return objC;
                    }
                    throw th2;
                }
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        b(File file, h hVar, String str, kotlin.y.d<? super b> dVar) {
            super(2, dVar);
            this.b = file;
            this.c = hVar;
            this.f8590d = str;
        }

        @Override // kotlin.y.j.a.a
        public final kotlin.y.d<u> create(Object obj, kotlin.y.d<?> dVar) {
            return new b(this.b, this.c, this.f8590d, dVar);
        }

        @Override // kotlin.b0.c.p
        public final Object invoke(m0 m0Var, kotlin.y.d<? super u> dVar) {
            return ((b) create(m0Var, dVar)).invokeSuspend(u.a);
        }

        @Override // kotlin.y.j.a.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object objC = kotlin.y.i.d.c();
            int i2 = this.a;
            if (i2 == 0) {
                n.b(obj);
                h0 h0VarB = b1.b();
                a aVar = new a(this.b, this.c, this.f8590d, null);
                this.a = 1;
                if (kotlinx.coroutines.g.h(h0VarB, aVar, this) == objC) {
                    return objC;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                n.b(obj);
            }
            return u.a;
        }
    }

    public h() {
        File[] fileArrListFiles = new File(ru.himik.nightscream.kascada.Utils.n.a.e()).listFiles();
        if (fileArrListFiles != null) {
            ArrayList arrayList = new ArrayList();
            int length = fileArrListFiles.length;
            int i2 = 0;
            while (i2 < length) {
                File file = fileArrListFiles[i2];
                i2++;
                String name = file.getName();
                kotlin.b0.d.j.c(name, "it.name");
                if (q.m(name, ".zip", false)) {
                    arrayList.add(file);
                }
            }
            List listX = w.X(arrayList, new a());
            ArrayList<File> arrayList2 = new ArrayList();
            Iterator it = listX.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (((File) next).getName().length() > 4) {
                    arrayList2.add(next);
                }
            }
            if (!arrayList2.isEmpty()) {
                this.a.add(new j(k.FOLDER, ru.himik.nightscream.kascada.Utils.n.a.e(), null, null, 12, null));
                for (File file2 : arrayList2) {
                    ArrayList<j> arrayListE = e();
                    k kVar = k.ZIP_FILE;
                    String name2 = file2.getName();
                    kotlin.b0.d.j.c(name2, "file.name");
                    arrayListE.add(new j(kVar, name2, c(file2.length()), b(file2.lastModified())));
                }
            }
            g.a.a.e.e(MyApplication.b().h0, MyApplication.b().h0.getString(ru.kascada.modbus.R.string.toast_backup_projects), 0, true).show();
        }
    }

    private final String b(long j2) {
        String str = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(Long.valueOf(j2));
        kotlin.b0.d.j.c(str, "fmt.format(date)");
        return str;
    }

    private final String c(long j2) {
        String str;
        String str2;
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        double d2 = j2;
        if (d2 < 1048576.0d) {
            str = decimalFormat.format(d2 / 1024.0d);
            str2 = g() ? " Кб" : " KB";
        } else {
            str = decimalFormat.format(d2 / 1048576.0d);
            str2 = g() ? " Мбайт" : " MB";
        }
        return kotlin.b0.d.j.i(str, str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    public final void f(String str, String str2) throws JSONException {
        int i2;
        String string;
        String string2;
        String string3;
        String string4;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        String str9;
        String str10;
        String str11;
        String str12;
        String str13;
        String str14;
        JSONObject jSONObject;
        JSONObject jSONObject2;
        JSONObject jSONObject3;
        JSONObject jSONObject4;
        JSONObject jSONObject5;
        JSONObject jSONObject6;
        JSONObject jSONObject7;
        JSONObject jSONObject8;
        JSONObject jSONObject9;
        JSONObject jSONObject10;
        JSONObject jSONObject11;
        JSONObject jSONObject12;
        JSONObject jSONObject13;
        JSONObject jSONObject14;
        String str15 = "pathPic_4";
        String str16 = "pathPic_3";
        String str17 = "pathSound_2";
        String str18 = "pathSound_1";
        try {
            JSONObject jSONObject15 = new JSONObject(str);
            JSONObject jSONObject16 = jSONObject15.getJSONObject("TableNameProject");
            String string5 = jSONObject16.getString(IMAPStore.ID_NAME);
            jSONObject16.getInt("stationMode");
            int i3 = jSONObject16.getInt("countScreen");
            String string6 = jSONObject16.getString("pass");
            String str19 = "screen";
            String str20 = "pathPic_0";
            String str21 = "pathSound_0";
            String str22 = "pathSound_4";
            String str23 = "pathPic_1";
            String str24 = "jsTableComponent_other";
            String str25 = "pathSound_3";
            String strSubstring = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
            kotlin.b0.d.j.c(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
            String strI = kotlin.b0.d.j.i(strSubstring, "help.pdf");
            try {
                i2 = jSONObject16.getInt("countDevice");
            } catch (Exception unused) {
                i iVarD = d();
                String string7 = MyApplication.b().getResources().getString(ru.kascada.modbus.R.string.error_import_network_device);
                kotlin.b0.d.j.c(string7, "get().resources.getStrin…or_import_network_device)");
                iVarD.c(string7);
                i2 = 1;
            }
            try {
                string = jSONObject16.getString("deviceNetwork");
            } catch (Exception unused2) {
                i iVarD2 = d();
                String string8 = MyApplication.b().getResources().getString(ru.kascada.modbus.R.string.error_import_network_device);
                kotlin.b0.d.j.c(string8, "get().resources.getStrin…or_import_network_device)");
                iVarD2.c(string8);
                string = "";
            }
            try {
                string2 = jSONObject16.getString("systemRegisters");
            } catch (Exception unused3) {
                i iVarD3 = d();
                String string9 = MyApplication.b().getResources().getString(ru.kascada.modbus.R.string.error_import_sys_reg);
                kotlin.b0.d.j.c(string9, "get().resources.getStrin…ing.error_import_sys_reg)");
                iVarD3.c(string9);
                string2 = "";
            }
            try {
                string3 = jSONObject16.getString("modbusSlave");
            } catch (Exception unused4) {
                string3 = "";
            }
            try {
                string4 = jSONObject16.getString("settings");
            } catch (Exception unused5) {
                i iVarD4 = d();
                String string10 = MyApplication.b().getResources().getString(ru.kascada.modbus.R.string.msg_error_import_settings);
                kotlin.b0.d.j.c(string10, "get().resources.getStrin…sg_error_import_settings)");
                iVarD4.c(string10);
                string4 = "";
            }
            JSONObject jSONObject17 = jSONObject16.getJSONObject("jsTableNameProject_screenBackground");
            JSONArray jSONArray = jSONObject15.getJSONArray("TableComponent");
            JSONArray jSONArray2 = jSONObject15.getJSONArray("TableConnections");
            SQLiteDatabase writableDatabase = new ru.himik.nightscream.kascada.Bd.e(MyApplication.b()).getWritableDatabase();
            kotlin.b0.d.j.c(writableDatabase, "DBHelper(MyApplication.get()).writableDatabase");
            String str26 = "pathPic_6";
            Cursor cursorQuery = writableDatabase.query("TableNameProject", null, "name = ?", new String[]{string5}, null, null, null);
            cursorQuery.moveToFirst();
            String str27 = "pathPic_5";
            if (cursorQuery.getCount() > 0) {
                Cursor cursorRawQuery = writableDatabase.rawQuery("select _id from TableNameProject where name = '" + ((Object) string5) + '\'', null);
                cursorRawQuery.moveToFirst();
                int i4 = cursorRawQuery.getInt(cursorRawQuery.getColumnIndex("_id"));
                str3 = "TableNameProject";
                writableDatabase.delete(str3, "name = '" + ((Object) string5) + '\'', null);
                writableDatabase.execSQL("DROP TABLE IF EXISTS pro_" + i4 + "_component");
                writableDatabase.execSQL("DROP TABLE IF EXISTS pro_" + i4 + "_connections");
            } else {
                str3 = "TableNameProject";
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put(IMAPStore.ID_NAME, string5);
            contentValues.put("countScreen", Integer.valueOf(i3));
            contentValues.put("pass", string6);
            contentValues.put("countDevice", Integer.valueOf(i2));
            contentValues.put("deviceNetwork", string);
            contentValues.put("systemRegisters", string2);
            contentValues.put("modbusSlave", string3);
            contentValues.put("settings", string4);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
            Date date = new Date();
            contentValues.put("createdTime", simpleDateFormat.format(date));
            contentValues.put("createdDate", new SimpleDateFormat("yyyy-MM-dd").format(date));
            contentValues.put("pdfDocument", strI);
            String str28 = IMAPStore.ID_NAME;
            String strSubstring2 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
            kotlin.b0.d.j.c(strSubstring2, "this as java.lang.String…ing(startIndex, endIndex)");
            int i5 = 1;
            while (i5 < 21) {
                int i6 = i5 + 1;
                StringBuilder sb = new StringBuilder();
                String str29 = str19;
                sb.append(str29);
                sb.append(i5);
                sb.append("IsColor");
                if (!jSONObject17.getBoolean(sb.toString())) {
                    if (!jSONObject17.getBoolean(str29 + i5 + "DefaultBackground")) {
                        String string11 = jSONObject17.getString(str29 + i5 + "PathImage");
                        kotlin.b0.d.j.c(string11, "pathImage");
                        String strSubstring3 = string11.substring(r.W(string11, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring3, "this as java.lang.String).substring(startIndex)");
                        jSONObject17.put(str29 + i5 + "PathImage", kotlin.b0.d.j.i(strSubstring2, strSubstring3));
                    }
                }
                i5 = i6;
                str19 = str29;
            }
            contentValues.put("screenBackground", jSONObject17.toString());
            int iInsert = (int) writableDatabase.insert(str3, null, contentValues);
            writableDatabase.execSQL("create table pro_" + iInsert + "_component (_id integer primary key autoincrement,componentId int,text text default 'default',width int default 100,height int default 100,x int default 300,y int default 300,textSize int default 32,connectionInfo text default '',colorText int default -65536,colorBackground int default -65536,other text default '');");
            ContentValues contentValues2 = new ContentValues();
            new JSONObject();
            int length = jSONArray.length();
            int i7 = 0;
            while (i7 < length) {
                int i8 = i7 + 1;
                JSONObject jSONObject18 = jSONArray.getJSONObject(i7);
                kotlin.b0.d.j.c(jSONObject18, "TableComponent.getJSONObject(i)");
                int i9 = jSONObject18.getInt("componentId");
                contentValues2.put("componentId", Integer.valueOf(i9));
                contentValues2.put("text", jSONObject18.getString("text"));
                contentValues2.put("width", Integer.valueOf(jSONObject18.getInt("width")));
                contentValues2.put("height", Integer.valueOf(jSONObject18.getInt("height")));
                contentValues2.put("x", Integer.valueOf(jSONObject18.getInt("x")));
                contentValues2.put("y", Integer.valueOf(jSONObject18.getInt("y")));
                contentValues2.put("textSize", Integer.valueOf(jSONObject18.getInt("textSize")));
                contentValues2.put("connectionInfo", jSONObject18.getString("jsTableComponent_connectionInfo"));
                contentValues2.put("colorText", Integer.valueOf(jSONObject18.getInt("colorText")));
                contentValues2.put("colorBackground", Integer.valueOf(jSONObject18.getInt("colorBackground")));
                String str30 = str24;
                if (jSONObject18.getString(str30).length() <= 0) {
                    str4 = str30;
                    str22 = str22;
                    str5 = str20;
                    str6 = str23;
                    str7 = str25;
                    str8 = str17;
                    str9 = str18;
                    str10 = str21;
                    String str31 = str16;
                    str11 = str26;
                    str12 = str27;
                    str13 = str15;
                    str14 = str31;
                } else if (i9 == 5) {
                    str22 = str22;
                    str5 = str20;
                    str6 = str23;
                    str7 = str25;
                    str8 = str17;
                    str9 = str18;
                    str10 = str21;
                    String str32 = str16;
                    str11 = str26;
                    str12 = str27;
                    str13 = str15;
                    str14 = str32;
                    try {
                        try {
                            JSONObject jSONObject19 = new JSONObject(jSONObject18.getString(str30));
                            if (jSONObject19.getBoolean("isImageUserOn")) {
                                String string12 = jSONObject19.getString("pathOrNameOn");
                                str4 = str30;
                                try {
                                    String strSubstring4 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                    kotlin.b0.d.j.c(strSubstring4, "this as java.lang.String…ing(startIndex, endIndex)");
                                    jSONObject = jSONObject19;
                                    jSONObject.put("pathOrNameOn", kotlin.b0.d.j.i(strSubstring4, string12));
                                } catch (Exception unused6) {
                                }
                            } else {
                                str4 = str30;
                                jSONObject = jSONObject19;
                            }
                            if (jSONObject.getBoolean("isImageUserOff")) {
                                String string13 = jSONObject.getString("pathOrNameOff");
                                JSONObject jSONObject20 = jSONObject;
                                try {
                                    String strSubstring5 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                    kotlin.b0.d.j.c(strSubstring5, "this as java.lang.String…ing(startIndex, endIndex)");
                                    jSONObject2 = jSONObject20;
                                    jSONObject2.put("pathOrNameOff", kotlin.b0.d.j.i(strSubstring5, string13));
                                } catch (Exception unused7) {
                                }
                            } else {
                                jSONObject2 = jSONObject;
                            }
                            contentValues2.put("other", jSONObject2.toString());
                        } catch (Exception unused8) {
                            str4 = str30;
                        }
                    } catch (Exception unused9) {
                        str4 = str30;
                    }
                    u uVar = u.a;
                } else if (i9 != 21) {
                    if (i9 == 16) {
                        str5 = str20;
                        str6 = str23;
                        String str33 = str16;
                        str11 = str26;
                        str12 = str27;
                        str13 = str15;
                        str14 = str33;
                        JSONObject jSONObject21 = new JSONObject(jSONObject18.getString(str30));
                        String string14 = jSONObject21.getString("pathGif");
                        String strSubstring6 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring6, "this as java.lang.String…ing(startIndex, endIndex)");
                        jSONObject21.put("pathGif", kotlin.b0.d.j.i(strSubstring6, string14));
                        contentValues2.put("other", jSONObject21.toString());
                        u uVar2 = u.a;
                        str4 = str30;
                    } else if (i9 != 17) {
                        contentValues2.put("other", jSONObject18.getString(str30));
                        u uVar3 = u.a;
                        str4 = str30;
                        str22 = str22;
                        str5 = str20;
                        str6 = str23;
                        str7 = str25;
                        str8 = str17;
                        str9 = str18;
                        str10 = str21;
                        String str34 = str16;
                        str11 = str26;
                        str12 = str27;
                        str13 = str15;
                        str14 = str34;
                    } else {
                        JSONObject jSONObject22 = new JSONObject(jSONObject18.getString(str30));
                        String str35 = str20;
                        String string15 = jSONObject22.getString(str35);
                        String strSubstring7 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring7, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI2 = kotlin.b0.d.j.i(strSubstring7, string15);
                        if (kotlin.b0.d.j.a(string15, "")) {
                            jSONObject22.put(str35, "");
                        } else {
                            jSONObject22.put(str35, strI2);
                        }
                        String str36 = str23;
                        String string16 = jSONObject22.getString(str36);
                        str5 = str35;
                        String strSubstring8 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring8, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI3 = kotlin.b0.d.j.i(strSubstring8, string16);
                        if (kotlin.b0.d.j.a(string16, "")) {
                            jSONObject22.put(str36, "");
                        } else {
                            jSONObject22.put(str36, strI3);
                        }
                        String string17 = jSONObject22.getString("pathPic_2");
                        str6 = str36;
                        String strSubstring9 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring9, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI4 = kotlin.b0.d.j.i(strSubstring9, string17);
                        if (kotlin.b0.d.j.a(string17, "")) {
                            jSONObject22.put("pathPic_2", "");
                        } else {
                            jSONObject22.put("pathPic_2", strI4);
                        }
                        String str37 = str16;
                        String string18 = jSONObject22.getString(str37);
                        String strSubstring10 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring10, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI5 = kotlin.b0.d.j.i(strSubstring10, string18);
                        if (kotlin.b0.d.j.a(string18, "")) {
                            jSONObject22.put(str37, "");
                        } else {
                            jSONObject22.put(str37, strI5);
                        }
                        String str38 = str15;
                        String string19 = jSONObject22.getString(str38);
                        str14 = str37;
                        String strSubstring11 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring11, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI6 = kotlin.b0.d.j.i(strSubstring11, string19);
                        if (kotlin.b0.d.j.a(string19, "")) {
                            jSONObject22.put(str38, "");
                        } else {
                            jSONObject22.put(str38, strI6);
                        }
                        String str39 = str27;
                        String string20 = jSONObject22.getString(str39);
                        str13 = str38;
                        String strSubstring12 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring12, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI7 = kotlin.b0.d.j.i(strSubstring12, string20);
                        if (kotlin.b0.d.j.a(string20, "")) {
                            jSONObject22.put(str39, "");
                        } else {
                            jSONObject22.put(str39, strI7);
                        }
                        String str40 = str26;
                        String string21 = jSONObject22.getString(str40);
                        str12 = str39;
                        String strSubstring13 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring13, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI8 = kotlin.b0.d.j.i(strSubstring13, string21);
                        if (kotlin.b0.d.j.a(string21, "")) {
                            jSONObject22.put(str40, "");
                        } else {
                            jSONObject22.put(str40, strI8);
                        }
                        String string22 = jSONObject22.getString("pathPic_7");
                        str11 = str40;
                        String strSubstring14 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                        kotlin.b0.d.j.c(strSubstring14, "this as java.lang.String…ing(startIndex, endIndex)");
                        String strI9 = kotlin.b0.d.j.i(strSubstring14, string22);
                        if (kotlin.b0.d.j.a(string22, "")) {
                            jSONObject6 = jSONObject22;
                            jSONObject6.put("pathPic_7", "");
                        } else {
                            jSONObject6 = jSONObject22;
                            jSONObject6.put("pathPic_7", strI9);
                        }
                        try {
                            String string23 = jSONObject6.getString("pathPic_8");
                            JSONObject jSONObject23 = jSONObject6;
                            try {
                                String strSubstring15 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                kotlin.b0.d.j.c(strSubstring15, "this as java.lang.String…ing(startIndex, endIndex)");
                                String strI10 = kotlin.b0.d.j.i(strSubstring15, string23);
                                if (kotlin.b0.d.j.a(string23, "")) {
                                    jSONObject8 = jSONObject23;
                                    jSONObject8.put("pathPic_8", "");
                                } else {
                                    jSONObject8 = jSONObject23;
                                    jSONObject8.put("pathPic_8", strI10);
                                }
                                String string24 = jSONObject8.getString("pathPic_9");
                                JSONObject jSONObject24 = jSONObject8;
                                try {
                                    String strSubstring16 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                    kotlin.b0.d.j.c(strSubstring16, "this as java.lang.String…ing(startIndex, endIndex)");
                                    String strI11 = kotlin.b0.d.j.i(strSubstring16, string24);
                                    if (kotlin.b0.d.j.a(string24, "")) {
                                        jSONObject9 = jSONObject24;
                                        jSONObject9.put("pathPic_9", "");
                                    } else {
                                        jSONObject9 = jSONObject24;
                                        jSONObject9.put("pathPic_9", strI11);
                                    }
                                    String string25 = jSONObject9.getString("pathPic_10");
                                    JSONObject jSONObject25 = jSONObject9;
                                    try {
                                        String strSubstring17 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                        kotlin.b0.d.j.c(strSubstring17, "this as java.lang.String…ing(startIndex, endIndex)");
                                        String strI12 = kotlin.b0.d.j.i(strSubstring17, string25);
                                        if (kotlin.b0.d.j.a(string25, "")) {
                                            jSONObject10 = jSONObject25;
                                            jSONObject10.put("pathPic_10", "");
                                        } else {
                                            jSONObject10 = jSONObject25;
                                            jSONObject10.put("pathPic_10", strI12);
                                        }
                                        String string26 = jSONObject10.getString("pathPic_11");
                                        JSONObject jSONObject26 = jSONObject10;
                                        try {
                                            String strSubstring18 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                            kotlin.b0.d.j.c(strSubstring18, "this as java.lang.String…ing(startIndex, endIndex)");
                                            String strI13 = kotlin.b0.d.j.i(strSubstring18, string26);
                                            if (kotlin.b0.d.j.a(string26, "")) {
                                                jSONObject11 = jSONObject26;
                                                jSONObject11.put("pathPic_11", "");
                                            } else {
                                                jSONObject11 = jSONObject26;
                                                jSONObject11.put("pathPic_11", strI13);
                                            }
                                            String string27 = jSONObject11.getString("pathPic_12");
                                            JSONObject jSONObject27 = jSONObject11;
                                            try {
                                                String strSubstring19 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                                kotlin.b0.d.j.c(strSubstring19, "this as java.lang.String…ing(startIndex, endIndex)");
                                                String strI14 = kotlin.b0.d.j.i(strSubstring19, string27);
                                                if (kotlin.b0.d.j.a(string27, "")) {
                                                    jSONObject12 = jSONObject27;
                                                    jSONObject12.put("pathPic_12", "");
                                                } else {
                                                    jSONObject12 = jSONObject27;
                                                    jSONObject12.put("pathPic_12", strI14);
                                                }
                                                String string28 = jSONObject12.getString("pathPic_13");
                                                JSONObject jSONObject28 = jSONObject12;
                                                try {
                                                    String strSubstring20 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                                    kotlin.b0.d.j.c(strSubstring20, "this as java.lang.String…ing(startIndex, endIndex)");
                                                    String strI15 = kotlin.b0.d.j.i(strSubstring20, string28);
                                                    if (kotlin.b0.d.j.a(string28, "")) {
                                                        jSONObject13 = jSONObject28;
                                                        jSONObject13.put("pathPic_13", "");
                                                    } else {
                                                        jSONObject13 = jSONObject28;
                                                        jSONObject13.put("pathPic_13", strI15);
                                                    }
                                                    String string29 = jSONObject13.getString("pathPic_14");
                                                    JSONObject jSONObject29 = jSONObject13;
                                                    try {
                                                        String strSubstring21 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                                        kotlin.b0.d.j.c(strSubstring21, "this as java.lang.String…ing(startIndex, endIndex)");
                                                        String strI16 = kotlin.b0.d.j.i(strSubstring21, string29);
                                                        if (kotlin.b0.d.j.a(string29, "")) {
                                                            jSONObject14 = jSONObject29;
                                                            jSONObject14.put("pathPic_14", "");
                                                        } else {
                                                            jSONObject14 = jSONObject29;
                                                            jSONObject14.put("pathPic_14", strI16);
                                                        }
                                                        String string30 = jSONObject14.getString("pathPic_15");
                                                        JSONObject jSONObject30 = jSONObject14;
                                                        try {
                                                            String strSubstring22 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                                                            kotlin.b0.d.j.c(strSubstring22, "this as java.lang.String…ing(startIndex, endIndex)");
                                                            String strI17 = kotlin.b0.d.j.i(strSubstring22, string30);
                                                            if (kotlin.b0.d.j.a(string30, "")) {
                                                                jSONObject7 = jSONObject30;
                                                                try {
                                                                    jSONObject7.put("pathPic_15", "");
                                                                } catch (Exception unused10) {
                                                                }
                                                            } else {
                                                                jSONObject7 = jSONObject30;
                                                                jSONObject7.put("pathPic_15", strI17);
                                                            }
                                                        } catch (Exception unused11) {
                                                            jSONObject7 = jSONObject30;
                                                        }
                                                    } catch (Exception unused12) {
                                                        jSONObject7 = jSONObject29;
                                                    }
                                                } catch (Exception unused13) {
                                                    jSONObject7 = jSONObject28;
                                                }
                                            } catch (Exception unused14) {
                                                jSONObject7 = jSONObject27;
                                            }
                                        } catch (Exception unused15) {
                                            jSONObject7 = jSONObject26;
                                        }
                                    } catch (Exception unused16) {
                                        jSONObject7 = jSONObject25;
                                    }
                                } catch (Exception unused17) {
                                    jSONObject7 = jSONObject24;
                                }
                            } catch (Exception unused18) {
                                jSONObject7 = jSONObject23;
                            }
                        } catch (Exception unused19) {
                            jSONObject7 = jSONObject6;
                        }
                        contentValues2.put("other", jSONObject7.toString());
                        u uVar4 = u.a;
                        str4 = str30;
                    }
                    str7 = str25;
                    str8 = str17;
                    str9 = str18;
                    str10 = str21;
                } else {
                    str5 = str20;
                    str6 = str23;
                    String str41 = str16;
                    str11 = str26;
                    str12 = str27;
                    str13 = str15;
                    str14 = str41;
                    JSONObject jSONObject31 = new JSONObject(jSONObject18.getString(str30));
                    String str42 = str21;
                    String string31 = jSONObject31.getString(str42);
                    String strSubstring23 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring23, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI18 = kotlin.b0.d.j.i(strSubstring23, string31);
                    if (kotlin.b0.d.j.a(string31, "")) {
                        jSONObject31.put(str42, "");
                    } else {
                        jSONObject31.put(str42, strI18);
                    }
                    String str43 = str18;
                    String string32 = jSONObject31.getString(str43);
                    str10 = str42;
                    String strSubstring24 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring24, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI19 = kotlin.b0.d.j.i(strSubstring24, string32);
                    if (kotlin.b0.d.j.a(string32, "")) {
                        jSONObject31.put(str43, "");
                    } else {
                        jSONObject31.put(str43, strI19);
                    }
                    String str44 = str17;
                    String string33 = jSONObject31.getString(str44);
                    str9 = str43;
                    String strSubstring25 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring25, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI20 = kotlin.b0.d.j.i(strSubstring25, string33);
                    if (kotlin.b0.d.j.a(string33, "")) {
                        jSONObject31.put(str44, "");
                    } else {
                        jSONObject31.put(str44, strI20);
                    }
                    String str45 = str25;
                    String string34 = jSONObject31.getString(str45);
                    str8 = str44;
                    String strSubstring26 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring26, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI21 = kotlin.b0.d.j.i(strSubstring26, string34);
                    if (kotlin.b0.d.j.a(string34, "")) {
                        jSONObject31.put(str45, "");
                    } else {
                        jSONObject31.put(str45, strI21);
                    }
                    String str46 = str22;
                    String string35 = jSONObject31.getString(str46);
                    str7 = str45;
                    String strSubstring27 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring27, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI22 = kotlin.b0.d.j.i(strSubstring27, string35);
                    if (kotlin.b0.d.j.a(string35, "")) {
                        jSONObject31.put(str46, "");
                    } else {
                        jSONObject31.put(str46, strI22);
                    }
                    String string36 = jSONObject31.getString("pathSound_5");
                    str22 = str46;
                    String strSubstring28 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring28, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI23 = kotlin.b0.d.j.i(strSubstring28, string36);
                    if (kotlin.b0.d.j.a(string36, "")) {
                        jSONObject3 = jSONObject31;
                        jSONObject3.put("pathSound_5", "");
                    } else {
                        jSONObject3 = jSONObject31;
                        jSONObject3.put("pathSound_53", strI23);
                    }
                    String string37 = jSONObject3.getString("pathSound_6");
                    JSONObject jSONObject32 = jSONObject3;
                    String strSubstring29 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring29, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI24 = kotlin.b0.d.j.i(strSubstring29, string37);
                    if (kotlin.b0.d.j.a(string37, "")) {
                        jSONObject4 = jSONObject32;
                        jSONObject4.put("pathSound_6", "");
                    } else {
                        jSONObject4 = jSONObject32;
                        jSONObject4.put("pathSound_6", strI24);
                    }
                    String string38 = jSONObject4.getString("pathSound_7");
                    JSONObject jSONObject33 = jSONObject4;
                    String strSubstring30 = str2.substring(0, r.W(str2, "/", 0, false, 6, null) + 1);
                    kotlin.b0.d.j.c(strSubstring30, "this as java.lang.String…ing(startIndex, endIndex)");
                    String strI25 = kotlin.b0.d.j.i(strSubstring30, string38);
                    if (kotlin.b0.d.j.a(string38, "")) {
                        jSONObject5 = jSONObject33;
                        jSONObject5.put("pathSound_7", "");
                    } else {
                        jSONObject5 = jSONObject33;
                        jSONObject5.put("pathSound_7", strI25);
                    }
                    contentValues2.put("other", jSONObject5.toString());
                    u uVar5 = u.a;
                    str4 = str30;
                }
                writableDatabase.insert("pro_" + iInsert + "_component", null, contentValues2);
                str21 = str10;
                str18 = str9;
                i7 = i8;
                str20 = str5;
                str23 = str6;
                str24 = str4;
                str17 = str8;
                str25 = str7;
                str22 = str22;
                String str47 = str13;
                str27 = str12;
                str26 = str11;
                str16 = str14;
                str15 = str47;
            }
            writableDatabase.execSQL("create table pro_" + iInsert + "_connections(_id integer primary key autoincrement,connectionsId int,name text,server text);");
            ContentValues contentValues3 = new ContentValues();
            new JSONObject();
            int length2 = jSONArray2.length();
            int i10 = 0;
            while (i10 < length2) {
                int i11 = i10 + 1;
                JSONArray jSONArray3 = jSONArray2;
                JSONObject jSONObject34 = jSONArray3.getJSONObject(i10);
                kotlin.b0.d.j.c(jSONObject34, "TableConnections.getJSONObject(i)");
                contentValues3.put("connectionsId", Integer.valueOf(jSONObject34.getInt("connectionsId")));
                String str48 = str28;
                contentValues3.put(str48, jSONObject34.getString(str48));
                contentValues3.put("server", jSONObject34.getString("server"));
                writableDatabase.insert("pro_" + iInsert + "_connections", null, contentValues3);
                i10 = i11;
                jSONArray2 = jSONArray3;
                str28 = str48;
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
            i iVarD5 = d();
            String string39 = MyApplication.b().getResources().getString(ru.kascada.modbus.R.string.error_import_project);
            kotlin.b0.d.j.c(string39, "get().resources.getStrin…ing.error_import_project)");
            iVarD5.c(string39);
        }
        d().a();
    }

    private final boolean g() {
        return kotlin.b0.d.j.a(MyApplication.b().h0.getResources().getString(ru.kascada.modbus.R.string.voice_language), "ru");
    }

    public final i d() {
        i iVar = this.b;
        if (iVar != null) {
            return iVar;
        }
        kotlin.b0.d.j.m("interfaceCallbackImport");
        throw null;
    }

    public final ArrayList<j> e() {
        return this.a;
    }

    public final void h(int i2) {
        File file = new File(kotlin.b0.d.j.i(ru.himik.nightscream.kascada.Utils.n.a.e(), this.a.get(i2).b()));
        if (this.a.get(i2).d() == k.FOLDER) {
            return;
        }
        k(file, "");
    }

    public final void i(i iVar) {
        kotlin.b0.d.j.d(iVar, "callback");
        j(iVar);
    }

    public final void j(i iVar) {
        kotlin.b0.d.j.d(iVar, "<set-?>");
        this.b = iVar;
    }

    public final void k(File file, String str) {
        kotlin.b0.d.j.d(file, "file");
        kotlin.b0.d.j.d(str, "url");
        i iVarD = d();
        String name = file.getName();
        kotlin.b0.d.j.c(name, "file.name");
        iVarD.d(name);
        kotlinx.coroutines.i.d(n1.a, null, null, new b(file, this, str, null), 3, null);
    }
}
