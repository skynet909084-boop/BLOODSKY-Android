package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class l extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    Paint C;
    Paint D;
    int E;
    int F;
    int G;
    int H;
    boolean I;
    int J;
    int K;
    byte[] L;
    private long M;
    boolean N;
    public Point O;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8840d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8841e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public b f8842f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8843g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public b f8844h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f8845i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f8846j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f8847k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f8848l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f8849m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f8850n;
    Bitmap o;

    public l(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_gateway_bit);
        this.f8840d = 22;
        this.f8842f = new b();
        this.f8843g = new b();
        this.f8844h = new b();
        this.f8846j = false;
        this.f8847k = 0;
        this.o = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.C = new Paint();
        this.D = new Paint();
        this.E = 0;
        this.F = 0;
        this.G = 0;
        this.H = 0;
        this.I = false;
        this.J = 0;
        this.K = 0;
        this.M = 0L;
        this.N = false;
        this.O = new Point();
        this.f8842f.L((byte) 1);
        this.f8843g.L((byte) 15);
        if (this.f8842f.l() == -1) {
            this.f8842f.E(0);
        }
    }

    public void a(int i2) {
        if (i2 != 1) {
            this.N = false;
        } else {
            if (this.N) {
                return;
            }
            mbCanvas.F(this.f8842f.k(), this.f8842f);
            this.N = true;
        }
    }

    public void b(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_gateway_bit);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
    }

    public void c() {
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.O.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public int getBitMode() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8840d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8845i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8840d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList_source", this.f8842f.l());
        jSONObject.put("addressRegister_source", this.f8842f.c());
        jSONObject.put("addressBit_source", (int) this.f8842f.a());
        jSONObject.put("countBit", this.f8842f.f());
        jSONObject.put("posDeviceNetworkInList_receive", this.f8843g.l());
        jSONObject.put("addressRegister_receive", this.f8843g.c());
        jSONObject.put("addressBit_receive", (int) this.f8843g.a());
        jSONObject.put("posDeviceNetworkInList_trigger", this.f8844h.l());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("functionModbusSource", (int) this.f8842f.q());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("mode", getMode());
        jSONObject.put("regMode", getRegMode());
        jSONObject.put("bitMode", getBitMode());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8841e;
    }

    public int getMode() {
        return this.F;
    }

    public int getNumScreen() {
        return this.f8845i;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.O;
    }

    public int getRegMode() {
        return this.G;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return "";
    }

    public String getStringAddressReceive() {
        StringBuilder sb;
        String str = "#";
        if (this.f8843g.l() >= 0) {
            if (this.f8843g.l() >= 100) {
                this.f8843g.u((byte) 1);
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_address));
                str = ": S#";
            } else {
                this.f8843g.u((byte) MyApplication.b().E.get(this.f8843g.l()).a());
                sb = new StringBuilder();
            }
            sb.append(str);
            sb.append(this.f8843g.c());
            return sb.toString();
        }
        if (this.f8843g.l() == -1) {
            this.f8843g.E(0);
        }
        this.f8843g.u((byte) MyApplication.b().E.get(this.f8843g.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_address));
        sb.append(": ");
        sb.append((int) this.f8843g.b());
        sb.append(str);
        sb.append(this.f8843g.c());
        return sb.toString();
    }

    public String getStringAddressSource() {
        StringBuilder sb;
        String str = "#";
        if (this.f8842f.l() >= 0) {
            if (this.f8842f.l() >= 100) {
                this.f8842f.u((byte) 1);
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_address));
                str = ": S#";
            } else {
                this.f8842f.u((byte) MyApplication.b().E.get(this.f8842f.l()).a());
                sb = new StringBuilder();
            }
            sb.append(str);
            sb.append(this.f8842f.c());
            return sb.toString();
        }
        if (this.f8842f.l() == -1) {
            this.f8842f.E(0);
        }
        this.f8842f.u((byte) MyApplication.b().E.get(this.f8842f.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_address));
        sb.append(": ");
        sb.append((int) this.f8842f.b());
        sb.append(str);
        sb.append(this.f8842f.c());
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return "";
    }

    public String getStringNameDeviceReceive() {
        StringBuilder sb;
        String strC;
        if (this.f8843g.l() >= 0) {
            if (this.f8843g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name_receive));
                sb.append(": ");
                strC = getResources().getString(R.string.dialog_device_system);
            } else {
                sb = new StringBuilder();
            }
            sb.append(strC);
            return sb.toString();
        }
        if (this.f8843g.l() == -1) {
            this.f8843g.E(0);
        }
        this.f8843g.u((byte) MyApplication.b().E.get(this.f8843g.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name_receive));
        sb.append(": ");
        strC = MyApplication.b().E.get(this.f8843g.l()).c();
        sb.append(strC);
        return sb.toString();
    }

    public String getStringNameDeviceSource() {
        StringBuilder sb;
        String strC;
        if (this.f8842f.l() >= 0) {
            if (this.f8842f.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name_source));
                sb.append(": ");
                strC = getResources().getString(R.string.dialog_device_system);
            } else {
                sb = new StringBuilder();
            }
            sb.append(strC);
            return sb.toString();
        }
        if (this.f8842f.l() == -1) {
            this.f8842f.E(0);
        }
        this.f8842f.u((byte) MyApplication.b().E.get(this.f8842f.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name_source));
        sb.append(": ");
        strC = MyApplication.b().E.get(this.f8842f.l()).c();
        sb.append(strC);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.M;
    }

    public int getValueSource() {
        return this.f8847k;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8849m || this.f8850n) {
            this.D.setColor(-65536);
            this.D.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.D);
        }
        if (this.f8848l && mbCanvas.g1) {
            canvas.drawBitmap(this.o, getWidth() - this.o.getWidth(), getHeight() - this.o.getHeight(), this.C);
        }
        if (this.I) {
            this.D.setColor(-16711936);
            this.D.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.D);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.I;
    }

    public void setBitMode(int i2) {
        this.H = i2;
    }

    public void setConnectionErrorReceive(boolean z) {
        if (this.f8850n != z) {
            this.f8850n = z;
            if (z) {
                this.f8843g.J(false);
            }
            invalidate();
        }
    }

    public void setConnectionErrorSource(boolean z) {
        if (this.f8849m != z) {
            this.f8849m = z;
            if (z) {
                this.f8843g.J(false);
            }
            invalidate();
        }
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8848l = z;
        if (z) {
            this.E = 0;
            if (getVisibility() == 4 && mbCanvas.a1 == this.f8845i) {
                setVisibility(0);
                invalidate();
                this.f8843g.J(false);
            }
        } else if (!this.f8849m || !this.f8850n) {
            this.E++;
        }
        if (this.E >= 4) {
            if (getVisibility() == 0 && !this.f8850n && !this.f8849m) {
                setVisibility(4);
                invalidate();
            }
            this.f8843g.J(true);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.I = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.J = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.K = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8841e = i2;
    }

    public void setMode(int i2) {
        this.F = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8845i = i2;
    }

    public void setPosDeviceNetworkInList(int i2) {
        (this.f8846j ? this.f8842f : this.f8843g).E(i2);
    }

    public void setRegMode(int i2) {
        this.G = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.M = j2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0031, code lost:
    
        if (r5.f8843g.l() != 100) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0047, code lost:
    
        if (r5.f8843g.l() != 100) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x004a, code lost:
    
        r5.f8848l = true;
        invalidate();
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:?, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void setValueSource(byte[] bArr) {
        int i2 = this.F;
        if (i2 == 0) {
            this.f8843g.x(bArr);
            this.f8843g.J(true);
            return;
        }
        if (i2 == 1) {
            this.f8843g.x(bArr);
            if (this.f8843g.k() == -1) {
            }
            mbCanvas.F(this.f8843g.k(), this.f8843g);
        } else {
            if (i2 != 2) {
                return;
            }
            if (this.L == null) {
                this.L = bArr;
            }
            if (Arrays.equals(this.L, bArr)) {
                return;
            }
            this.L = bArr;
            this.f8843g.x(bArr);
            if (this.f8843g.k() == -1) {
            }
            mbCanvas.F(this.f8843g.k(), this.f8843g);
        }
    }
}
