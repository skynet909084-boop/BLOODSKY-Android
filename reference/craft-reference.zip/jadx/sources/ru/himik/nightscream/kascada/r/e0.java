package ru.himik.nightscream.kascada.r;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.himik.nightscream.kascada.Logic.FB_TIMER;
import ru.himik.nightscream.kascada.Logic.MQTT_PUBLISHER;
import ru.himik.nightscream.kascada.Logic.MQTT_SUBSCRIBER;
import ru.himik.nightscream.kascada.Logic.ODTEMP;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameIn;
import ru.himik.nightscream.kascada.Logic.VarName.VarNameOut;
import ru.himik.nightscream.kascada.Logic.VarOutFloat;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class e0 {

    static class a implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;

        a(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = context;
            this.b = aVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (view.getId() != R.id.logic_edit) {
                return;
            }
            e0.s0(this.a, this.b);
        }
    }

    static class a0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        a0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class a1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ MQTT_SUBSCRIBER a;
        final /* synthetic */ EditText b;

        a1(MQTT_SUBSCRIBER mqtt_subscriber, EditText editText) {
            this.a = mqtt_subscriber;
            this.b = editText;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            this.a.setTopic(this.b.getText().toString());
        }
    }

    static class b implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;

        b(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = context;
            this.b = aVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (view.getId() != R.id.logic_edit) {
                return;
            }
            e0.u0(this.a, this.b);
        }
    }

    static class b0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        b0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class b1 implements DialogInterface.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ TextView b;
        final /* synthetic */ Context c;

        b1(ru.himik.nightscream.kascada.Logic.c.a aVar, TextView textView, Context context) {
            this.a = aVar;
            this.b = textView;
            this.c = context;
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            TextView textView;
            StringBuilder sb;
            String str;
            if (i2 == 0) {
                ru.himik.nightscream.kascada.Logic.c.a aVar = this.a;
                if (aVar instanceof MQTT_SUBSCRIBER) {
                    ((MQTT_SUBSCRIBER) aVar).setTypeQ(1);
                }
                ru.himik.nightscream.kascada.Logic.c.a aVar2 = this.a;
                if (aVar2 instanceof MQTT_PUBLISHER) {
                    ((MQTT_PUBLISHER) aVar2).setTypeIn(1);
                }
                textView = this.b;
                sb = new StringBuilder();
                sb.append(this.c.getString(R.string.type_q));
                str = ": BOOL";
            } else if (i2 == 1) {
                ru.himik.nightscream.kascada.Logic.c.a aVar3 = this.a;
                if (aVar3 instanceof MQTT_SUBSCRIBER) {
                    ((MQTT_SUBSCRIBER) aVar3).setTypeQ(2);
                }
                ru.himik.nightscream.kascada.Logic.c.a aVar4 = this.a;
                if (aVar4 instanceof MQTT_PUBLISHER) {
                    ((MQTT_PUBLISHER) aVar4).setTypeIn(2);
                }
                textView = this.b;
                sb = new StringBuilder();
                sb.append(this.c.getString(R.string.type_q));
                str = ": INT";
            } else {
                if (i2 != 2) {
                    return;
                }
                ru.himik.nightscream.kascada.Logic.c.a aVar5 = this.a;
                if (aVar5 instanceof MQTT_SUBSCRIBER) {
                    ((MQTT_SUBSCRIBER) aVar5).setTypeQ(3);
                }
                ru.himik.nightscream.kascada.Logic.c.a aVar6 = this.a;
                if (aVar6 instanceof MQTT_PUBLISHER) {
                    ((MQTT_PUBLISHER) aVar6).setTypeIn(3);
                }
                textView = this.b;
                sb = new StringBuilder();
                sb.append(this.c.getString(R.string.type_q));
                str = ": FLOAT";
            }
            sb.append(str);
            textView.setText(sb.toString());
        }
    }

    static class c implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ EditText b;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9300d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ Context f9301e;

        c(EditText editText, EditText editText2, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = editText2;
            this.c = aVar;
            this.f9300d = alertDialog;
            this.f9301e = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (this.a.getText().toString().length() <= 0 || this.b.getText().toString().length() <= 0) {
                return;
            }
            int iIntValue = Integer.valueOf(this.a.getText().toString()).intValue();
            int iIntValue2 = Integer.valueOf(this.b.getText().toString()).intValue();
            if (iIntValue < 0 || iIntValue > ru.himik.nightscream.kascada.q.d.b.F || iIntValue2 < 0 || iIntValue2 > 15) {
                Context context = this.f9301e;
                Toast.makeText(context, context.getResources().getString(R.string.error_input_num_sys_reg), 1).show();
            } else {
                ((ru.himik.nightscream.kascada.Logic.e) this.c).j(Integer.valueOf(this.a.getText().toString()).intValue(), Integer.valueOf(this.b.getText().toString()).intValue());
                this.f9300d.dismiss();
            }
        }
    }

    static class c0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        c0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class c1 implements AdapterView.OnItemSelectedListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;

        c1(ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = aVar;
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            this.a.setVarConstant(i2 == 0);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    static class d implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Context f9302d;

        d(EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = aVar;
            this.c = alertDialog;
            this.f9302d = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int iIntValue = Integer.valueOf(this.a.getText().toString()).intValue();
            if (iIntValue < 0 || iIntValue > ru.himik.nightscream.kascada.q.d.b.F) {
                Context context = this.f9302d;
                Toast.makeText(context, context.getResources().getString(R.string.error_input_num_sys_reg), 1).show();
            } else {
                ((ru.himik.nightscream.kascada.Logic.e) this.b).j(iIntValue, 0);
                this.c.dismiss();
            }
        }
    }

    static class d0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        d0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_edit /* 2131296790 */:
                    e0.S(this.a, this.b);
                    return;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class d1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ ru.himik.nightscream.kascada.q.b.a a;
        final /* synthetic */ EditText b;
        final /* synthetic */ EditText c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Context f9303d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ EditText f9304e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ EditText f9305f;

        d1(ru.himik.nightscream.kascada.q.b.a aVar, EditText editText, EditText editText2, Context context, EditText editText3, EditText editText4) {
            this.a = aVar;
            this.b = editText;
            this.c = editText2;
            this.f9303d = context;
            this.f9304e = editText3;
            this.f9305f = editText4;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            this.a.e(this.b.getText().toString());
            try {
                this.a.h(Integer.parseInt(this.c.getText().toString()));
            } catch (Exception unused) {
                Context context = this.f9303d;
                Toast.makeText(context, context.getString(R.string.mqtt_error_parse_port), 0).show();
            }
            this.a.f(this.f9304e.getText().toString());
            this.a.g(this.f9305f.getText().toString());
        }
    }

    static class e implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        e(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_invert /* 2131296796 */:
                    this.b.i();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.r.e0$e0, reason: collision with other inner class name */
    static class ViewOnClickListenerC0305e0 implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ AlertDialog b;

        ViewOnClickListenerC0305e0(ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            int i2;
            switch (view.getId()) {
                case R.id.sensorActionX /* 2131297017 */:
                    aVar = this.a;
                    i2 = 1;
                    break;
                case R.id.sensorActionY /* 2131297018 */:
                    aVar = this.a;
                    i2 = 2;
                    break;
                case R.id.sensorActionZ /* 2131297019 */:
                    aVar = this.a;
                    i2 = 3;
                    break;
                default:
                    return;
            }
            aVar.setActionExecute(i2);
            this.b.dismiss();
        }
    }

    static class e1 implements DialogInterface.OnDismissListener {
        final /* synthetic */ MQTT_PUBLISHER a;
        final /* synthetic */ EditText b;

        e1(MQTT_PUBLISHER mqtt_publisher, EditText editText) {
            this.a = mqtt_publisher;
            this.b = editText;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            this.a.setTopic(this.b.getText().toString());
        }
    }

    static class f implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        f(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_edit /* 2131296790 */:
                    e0.q0(this.a, this.b);
                    return;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class f0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        f0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class f1 implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ EditText b;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ AlertDialog f9306d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ Context f9307e;

        f1(EditText editText, EditText editText2, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = editText2;
            this.c = aVar;
            this.f9306d = alertDialog;
            this.f9307e = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (this.a.getText().toString().length() <= 0 || this.b.getText().toString().length() <= 0) {
                return;
            }
            int iIntValue = Integer.valueOf(this.a.getText().toString()).intValue();
            int iIntValue2 = Integer.valueOf(this.b.getText().toString()).intValue();
            if (iIntValue < 0 || iIntValue > ru.himik.nightscream.kascada.q.d.b.F || iIntValue2 < 0 || iIntValue2 > 15) {
                Context context = this.f9307e;
                Toast.makeText(context, context.getResources().getString(R.string.error_input_num_sys_reg), 1).show();
            } else {
                ((ru.himik.nightscream.kascada.Logic.e) this.c).j(Integer.valueOf(this.a.getText().toString()).intValue(), Integer.valueOf(this.b.getText().toString()).intValue());
                this.f9306d.dismiss();
            }
        }
    }

    static class g implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        g(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_edit /* 2131296790 */:
                    e0.x(this.a, this.b);
                    return;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class g0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        g0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id != R.id.logic_invert) {
                switch (id) {
                    case R.id.logic_connect /* 2131296788 */:
                        Context context = this.a;
                        ((mbCanvas) context).T0 = this.b;
                        ((mbCanvas) context).S0 = true;
                        break;
                    case R.id.logic_disconnect_out /* 2131296789 */:
                        this.b.c();
                        mbCanvas.f1.invalidate();
                        break;
                    case R.id.logic_edit /* 2131296790 */:
                        e0.p0(this.a, this.b);
                        return;
                    default:
                        return;
                }
            } else {
                this.b.i();
            }
            this.c.dismiss();
        }
    }

    static class g1 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        g1(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_edit /* 2131296790 */:
                    e0.r0(this.a, this.b);
                    return;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class h implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ AlertDialog b;

        h(ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            int i2;
            switch (view.getId()) {
                case R.id.arithmeticActionADD /* 2131296379 */:
                    aVar = this.a;
                    i2 = 1;
                    break;
                case R.id.arithmeticActionDIV /* 2131296380 */:
                    aVar = this.a;
                    i2 = 4;
                    break;
                case R.id.arithmeticActionMUL /* 2131296381 */:
                    aVar = this.a;
                    i2 = 3;
                    break;
                case R.id.arithmeticActionSUB /* 2131296382 */:
                    aVar = this.a;
                    i2 = 2;
                    break;
                default:
                    return;
            }
            aVar.setActionExecute(i2);
            this.b.dismiss();
        }
    }

    static class h0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        h0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class h1 implements AdapterView.OnItemSelectedListener {
        final /* synthetic */ TextView a;
        final /* synthetic */ Context b;
        final /* synthetic */ EditText c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a f9308d;

        h1(TextView textView, Context context, EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = textView;
            this.b = context;
            this.c = editText;
            this.f9308d = aVar;
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            boolean z;
            TextView textView = this.a;
            if (i2 == 0) {
                textView.setText(this.b.getResources().getString(R.string.register));
                this.c.setText(((ru.himik.nightscream.kascada.Logic.e) this.f9308d).getReg() + "");
                aVar = this.f9308d;
                z = false;
            } else {
                textView.setText(this.b.getResources().getString(R.string.constanta));
                this.c.setText(this.f9308d.getVarIntConstant() + "");
                aVar = this.f9308d;
                z = true;
            }
            aVar.setConstant(z);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    static class i implements AdapterView.OnItemSelectedListener {
        final /* synthetic */ TextView a;
        final /* synthetic */ Context b;
        final /* synthetic */ EditText c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a f9309d;

        i(TextView textView, Context context, EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = textView;
            this.b = context;
            this.c = editText;
            this.f9309d = aVar;
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            boolean z;
            TextView textView = this.a;
            if (i2 == 0) {
                textView.setText(this.b.getResources().getString(R.string.register));
                this.c.setText(((ru.himik.nightscream.kascada.Logic.e) this.f9309d).getReg() + "");
                aVar = this.f9309d;
                z = false;
            } else {
                textView.setText(this.b.getResources().getString(R.string.constanta));
                this.c.setText(this.f9309d.getVarFloatConstant() + "");
                aVar = this.f9309d;
                z = true;
            }
            aVar.setConstant(z);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    static class i0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        i0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class i1 implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Context f9310d;

        i1(EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = aVar;
            this.c = alertDialog;
            this.f9310d = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Context context;
            Resources resources;
            int i2;
            if (this.a.getText().toString().length() > 0) {
                if (this.b.g()) {
                    int iIntValue = Integer.valueOf(this.a.getText().toString()).intValue();
                    if (iIntValue >= -32768 && iIntValue <= 65535) {
                        this.b.setVarIntConstant(iIntValue);
                        this.c.dismiss();
                    } else {
                        context = this.f9310d;
                        resources = context.getResources();
                        i2 = R.string.error_input_val_reg;
                        Toast.makeText(context, resources.getString(i2), 1).show();
                    }
                }
                int iIntValue2 = Integer.valueOf(this.a.getText().toString()).intValue();
                if (iIntValue2 >= 0 && iIntValue2 <= ru.himik.nightscream.kascada.q.d.b.F) {
                    ((ru.himik.nightscream.kascada.Logic.e) this.b).j(iIntValue2, 0);
                    this.c.dismiss();
                } else {
                    context = this.f9310d;
                    resources = context.getResources();
                    i2 = R.string.error_input_num_sys_reg;
                    Toast.makeText(context, resources.getString(i2), 1).show();
                }
            }
        }
    }

    static class j implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Context f9311d;

        j(EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = aVar;
            this.c = alertDialog;
            this.f9311d = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (this.a.getText().toString().length() > 0) {
                try {
                    if (this.b.g()) {
                        this.b.setVarFloatConstant(Float.valueOf(this.a.getText().toString()).floatValue());
                    } else {
                        int iIntValue = Integer.valueOf(this.a.getText().toString()).intValue();
                        if (iIntValue < 0 || iIntValue > ru.himik.nightscream.kascada.q.d.b.F - 1) {
                            Context context = this.f9311d;
                            Toast.makeText(context, context.getResources().getString(R.string.error_input_num_sys_reg), 1).show();
                            return;
                        }
                        ((ru.himik.nightscream.kascada.Logic.e) this.b).j(iIntValue, 0);
                    }
                    this.c.dismiss();
                } catch (Exception unused) {
                    Context context2 = this.f9311d;
                    Toast.makeText(context2, context2.getResources().getString(R.string.error_input_parse_float), 1).show();
                }
            }
        }
    }

    static class j0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        j0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class k implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        k(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id != R.id.logic_invert) {
                switch (id) {
                    case R.id.logic_connect /* 2131296788 */:
                        Context context = this.a;
                        ((mbCanvas) context).T0 = this.b;
                        ((mbCanvas) context).S0 = true;
                        break;
                    case R.id.logic_disconnect_out /* 2131296789 */:
                        this.b.c();
                        mbCanvas.f1.invalidate();
                        break;
                    case R.id.logic_edit /* 2131296790 */:
                        e0.C(this.a, this.b);
                        return;
                    default:
                        return;
                }
            } else {
                this.b.i();
            }
            this.c.dismiss();
        }
    }

    static class k0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        k0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class l implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;

        l(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = context;
            this.b = aVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (view.getId() != R.id.logic_edit) {
                return;
            }
            e0.t0(this.a, this.b);
        }
    }

    static class l0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        l0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class m implements CompoundButton.OnCheckedChangeListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ TextView b;

        m(ru.himik.nightscream.kascada.Logic.c.a aVar, TextView textView) {
            this.a = aVar;
            this.b = textView;
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = this.a;
            ((VarOutFloat) aVar).S = z;
            this.b.setText(((VarOutFloat) aVar).getTextOrder());
        }
    }

    static class m0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        m0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_edit /* 2131296790 */:
                    e0.W(this.a, this.b);
                    return;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class n implements CompoundButton.OnCheckedChangeListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ TextView b;

        n(ru.himik.nightscream.kascada.Logic.c.a aVar, TextView textView) {
            this.a = aVar;
            this.b = textView;
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            ru.himik.nightscream.kascada.Logic.c.a aVar = this.a;
            ((VarOutFloat) aVar).T = z;
            this.b.setText(((VarOutFloat) aVar).getTextOrder());
        }
    }

    static class n0 implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ AlertDialog b;

        n0(ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            int i2;
            switch (view.getId()) {
                case R.id.sunriseTime /* 2131297070 */:
                    aVar = this.a;
                    i2 = 1;
                    break;
                case R.id.sunsetTime /* 2131297071 */:
                    aVar = this.a;
                    i2 = 2;
                    break;
                default:
                    return;
            }
            aVar.setActionExecute(i2);
            this.b.dismiss();
        }
    }

    static class o implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Context f9312d;

        o(EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = aVar;
            this.c = alertDialog;
            this.f9312d = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int iIntValue = Integer.valueOf(this.a.getText().toString()).intValue();
            if (iIntValue < 0 || iIntValue > ru.himik.nightscream.kascada.q.d.b.F - 1) {
                Context context = this.f9312d;
                Toast.makeText(context, context.getResources().getString(R.string.error_input_num_sys_reg), 1).show();
            } else {
                ((ru.himik.nightscream.kascada.Logic.e) this.b).j(iIntValue, 0);
                this.c.dismiss();
            }
        }
    }

    static class o0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        o0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class p implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        p(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_edit /* 2131296790 */:
                    e0.x(this.a, this.b);
                    return;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class p0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ ODTEMP f9313d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ TextView f9314e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ TextView f9315f;

        class a implements DialogInterface.OnClickListener {
            a() {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                if (i2 == 0) {
                    p0.this.f9313d.setTypeSensor(1);
                    p0.this.f9313d.setTypeResponse(1);
                    p0.this.f9314e.setText("ODTEMP_2U");
                } else {
                    if (i2 != 1) {
                        return;
                    }
                    p0.this.f9313d.setTypeSensor(2);
                    p0.this.f9314e.setText("ODTEMP_2W");
                    int typeResponse = p0.this.f9313d.getTypeResponse();
                    if (typeResponse != 1) {
                        if (typeResponse != 2) {
                            return;
                        }
                        p0.this.f9315f.setText(R.string.humidity);
                        return;
                    }
                }
                p0.this.f9315f.setText(R.string.temperature);
            }
        }

        class b implements DialogInterface.OnClickListener {
            b() {
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                TextView textView;
                int i3;
                if (i2 == 0) {
                    p0.this.f9313d.setTypeResponse(1);
                    textView = p0.this.f9315f;
                    i3 = R.string.temperature;
                } else {
                    if (i2 != 1) {
                        return;
                    }
                    p0.this.f9313d.setTypeResponse(2);
                    textView = p0.this.f9315f;
                    i3 = R.string.humidity;
                }
                textView.setText(i3);
            }
        }

        p0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, ODTEMP odtemp, TextView textView, TextView textView2) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
            this.f9313d = odtemp;
            this.f9314e = textView;
            this.f9315f = textView2;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            AlertDialog.Builder builder;
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    this.c.dismiss();
                    return;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    this.c.dismiss();
                    return;
                case R.id.logic_edit /* 2131296790 */:
                case R.id.logic_edit_time /* 2131296791 */:
                case R.id.logic_edit_type_response_text /* 2131296793 */:
                default:
                    return;
                case R.id.logic_edit_type_response /* 2131296792 */:
                    if (this.f9313d.getTypeSensor() == 1) {
                        this.f9313d.setTypeResponse(1);
                        this.f9315f.setText(R.string.temperature);
                        return;
                    } else {
                        builder = new AlertDialog.Builder(this.a);
                        builder.setTitle(R.string.choose_type_response);
                        builder.setItems(new String[]{this.a.getResources().getString(R.string.temperature), this.a.getResources().getString(R.string.humidity)}, new b());
                    }
                    break;
                case R.id.logic_edit_type_sensor /* 2131296794 */:
                    builder = new AlertDialog.Builder(this.a);
                    builder.setTitle(R.string.choose_model_sensor);
                    builder.setItems(new String[]{"ODTEMP_2U", "ODTEMP_2W"}, new a());
                    break;
            }
            builder.create().show();
        }
    }

    static class q implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        q(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id != R.id.logic_invert) {
                switch (id) {
                    case R.id.logic_connect /* 2131296788 */:
                        Context context = this.a;
                        ((mbCanvas) context).T0 = this.b;
                        ((mbCanvas) context).S0 = true;
                        break;
                    case R.id.logic_disconnect_out /* 2131296789 */:
                        this.b.c();
                        mbCanvas.f1.invalidate();
                        break;
                    case R.id.logic_edit /* 2131296790 */:
                        e0.C(this.a, this.b);
                        return;
                    default:
                        return;
                }
            } else {
                this.b.i();
            }
            this.c.dismiss();
        }
    }

    static class q0 implements DialogInterface.OnDismissListener {
        final /* synthetic */ ODTEMP a;
        final /* synthetic */ EditText b;

        q0(ODTEMP odtemp, EditText editText) {
            this.a = odtemp;
            this.b = editText;
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            this.a.setIp(this.b.getText().toString());
        }
    }

    static class r implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        r(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_invert /* 2131296796 */:
                    this.b.i();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class r0 implements AdapterView.OnItemSelectedListener {
        final /* synthetic */ Spinner a;
        final /* synthetic */ EditText b;
        final /* synthetic */ EditText c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ TextView f9316d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ TextView f9317e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a f9318f;

        r0(Spinner spinner, EditText editText, EditText editText2, TextView textView, TextView textView2, ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = spinner;
            this.b = editText;
            this.c = editText2;
            this.f9316d = textView;
            this.f9317e = textView2;
            this.f9318f = aVar;
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            boolean z = false;
            if (i2 == 0) {
                this.a.setVisibility(8);
                this.b.setVisibility(0);
                this.c.setVisibility(0);
                this.f9316d.setVisibility(0);
                this.f9317e.setVisibility(0);
                aVar = this.f9318f;
            } else {
                this.a.setVisibility(0);
                this.b.setVisibility(8);
                this.c.setVisibility(8);
                this.f9316d.setVisibility(8);
                this.f9317e.setVisibility(8);
                aVar = this.f9318f;
                z = true;
            }
            aVar.setConstant(z);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    static class s implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        s(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id != R.id.logic_invert) {
                switch (id) {
                    case R.id.logic_connect /* 2131296788 */:
                        Context context = this.a;
                        ((mbCanvas) context).T0 = this.b;
                        ((mbCanvas) context).S0 = true;
                        break;
                    case R.id.logic_disconnect_out /* 2131296789 */:
                        this.b.c();
                        mbCanvas.f1.invalidate();
                        break;
                    case R.id.logic_edit /* 2131296790 */:
                        e0.b0(this.a, this.b);
                        return;
                    default:
                        return;
                }
            } else {
                this.b.i();
            }
            this.c.dismiss();
        }
    }

    static class s0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        s0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class t implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        t(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int id = view.getId();
            if (id != R.id.logic_invert) {
                switch (id) {
                    case R.id.logic_connect /* 2131296788 */:
                        Context context = this.a;
                        ((mbCanvas) context).T0 = this.b;
                        ((mbCanvas) context).S0 = true;
                        break;
                    case R.id.logic_disconnect_out /* 2131296789 */:
                        this.b.c();
                        mbCanvas.f1.invalidate();
                        break;
                    case R.id.logic_edit /* 2131296790 */:
                        e0.Y(this.a, this.b);
                        return;
                    case R.id.logic_edit_time /* 2131296791 */:
                        e0.Z(this.a, this.b);
                        return;
                    default:
                        return;
                }
            } else {
                this.b.i();
            }
            this.c.dismiss();
        }
    }

    static class t0 implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        t0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class u implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ AlertDialog b;

        u(ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            int i2;
            switch (view.getId()) {
                case R.id.timerActionF /* 2131297291 */:
                    aVar = this.a;
                    i2 = 3;
                    break;
                case R.id.timerActionR /* 2131297292 */:
                    aVar = this.a;
                    i2 = 2;
                    break;
                case R.id.timerActionT /* 2131297293 */:
                    aVar = this.a;
                    i2 = 1;
                    break;
                default:
                    return;
            }
            aVar.setActionExecute(i2);
            this.b.dismiss();
        }
    }

    static class u0 implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ Context b;
        final /* synthetic */ AlertDialog c;

        u0(ru.himik.nightscream.kascada.Logic.c.a aVar, Context context, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = context;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.b;
                    ((mbCanvas) context).T0 = this.a;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.a.c();
                    mbCanvas.f1.invalidate();
                    break;
                case R.id.logic_edit /* 2131296790 */:
                    if (((ru.himik.nightscream.kascada.Logic.VarName.b) this.a).getTypeVarValue() != 2) {
                        e0.n(this.b, this.a);
                        return;
                    }
                    int typeVar = ((ru.himik.nightscream.kascada.Logic.VarName.b) this.a).getTypeVar();
                    if (typeVar == 1) {
                        e0.k(this.b, this.a);
                        return;
                    } else if (typeVar == 2) {
                        e0.f0(this.b, this.a);
                        return;
                    } else {
                        if (typeVar != 3) {
                            return;
                        }
                        e0.e0(this.b, this.a);
                        return;
                    }
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class v implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ AlertDialog b;

        v(ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            int i2;
            switch (view.getId()) {
                case R.id.compareActionEQ /* 2131296498 */:
                    aVar = this.a;
                    i2 = 5;
                    break;
                case R.id.compareActionGE /* 2131296499 */:
                    aVar = this.a;
                    i2 = 4;
                    break;
                case R.id.compareActionGT /* 2131296500 */:
                    aVar = this.a;
                    i2 = 1;
                    break;
                case R.id.compareActionLE /* 2131296501 */:
                    aVar = this.a;
                    i2 = 3;
                    break;
                case R.id.compareActionLT /* 2131296502 */:
                    aVar = this.a;
                    i2 = 2;
                    break;
                case R.id.compareActionNE /* 2131296503 */:
                    aVar = this.a;
                    i2 = 6;
                    break;
                default:
                    return;
            }
            aVar.setActionExecute(i2);
            this.b.dismiss();
        }
    }

    static class v0 implements DialogInterface.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.VarName.b a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ Context c;

        v0(ru.himik.nightscream.kascada.Logic.VarName.b bVar, ru.himik.nightscream.kascada.Logic.c.a aVar, Context context) {
            this.a = bVar;
            this.b = aVar;
            this.c = context;
        }

        /* JADX WARN: Code restructure failed: missing block: B:12:0x0025, code lost:
        
            if (r2.b.getTypeFb() == 133) goto L16;
         */
        /* JADX WARN: Code restructure failed: missing block: B:15:0x0033, code lost:
        
            if (r2.b.getTypeFb() == 133) goto L16;
         */
        /* JADX WARN: Code restructure failed: missing block: B:16:0x0035, code lost:
        
            ru.himik.nightscream.kascada.r.e0.q(r2.c, r2.b);
         */
        /* JADX WARN: Code restructure failed: missing block: B:17:0x003d, code lost:
        
            ru.himik.nightscream.kascada.r.e0.n(r2.c, r2.b);
         */
        /* JADX WARN: Code restructure failed: missing block: B:18:0x0044, code lost:
        
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:19:?, code lost:
        
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:9:0x0017, code lost:
        
            if (r2.b.getTypeFb() == 133) goto L16;
         */
        @Override // android.content.DialogInterface.OnClickListener
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public void onClick(DialogInterface dialogInterface, int i2) {
            if (i2 == 0) {
                this.a.setTypeVar(1);
            } else if (i2 == 1) {
                this.a.setTypeVar(2);
            } else if (i2 != 2) {
            } else {
                this.a.setTypeVar(3);
            }
        }
    }

    static class w implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ AlertDialog b;

        w(ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ru.himik.nightscream.kascada.Logic.c.a aVar;
            int i2;
            int id = view.getId();
            if (id != R.id.timerActionBLINK) {
                switch (id) {
                    case R.id.timerActionTOF /* 2131297294 */:
                        aVar = this.a;
                        i2 = 2;
                        break;
                    case R.id.timerActionTON /* 2131297295 */:
                        aVar = this.a;
                        i2 = 1;
                        break;
                    case R.id.timerActionTP /* 2131297296 */:
                        aVar = this.a;
                        i2 = 3;
                        break;
                    default:
                        return;
                }
            } else {
                aVar = this.a;
                i2 = 4;
            }
            aVar.setActionExecute(i2);
            this.b.dismiss();
        }
    }

    static class w0 implements AdapterView.OnItemSelectedListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;

        w0(ru.himik.nightscream.kascada.Logic.c.a aVar) {
            this.a = aVar;
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            this.a.setVarConstant(i2 == 0);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    static class x implements View.OnClickListener {
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a a;
        final /* synthetic */ AlertDialog b;

        x(ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = aVar;
            this.b = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            FB_TIMER fb_timer;
            int i2;
            switch (view.getId()) {
                case R.id.timerMin /* 2131297297 */:
                    fb_timer = (FB_TIMER) this.a;
                    i2 = 3;
                    break;
                case R.id.timerMs /* 2131297298 */:
                    fb_timer = (FB_TIMER) this.a;
                    i2 = 1;
                    break;
                case R.id.timerSek /* 2131297299 */:
                    fb_timer = (FB_TIMER) this.a;
                    i2 = 2;
                    break;
                default:
                    return;
            }
            fb_timer.setTypeTime(i2);
            this.b.dismiss();
        }
    }

    static class x0 implements View.OnClickListener {
        final /* synthetic */ AlertDialog a;

        x0(AlertDialog alertDialog) {
            this.a = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.a.dismiss();
        }
    }

    static class y implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        y(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class y0 implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Context f9319d;

        y0(EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = aVar;
            this.c = alertDialog;
            this.f9319d = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            try {
                if (this.a.getText().toString().length() > 0) {
                    int iIntValue = Integer.valueOf(this.a.getText().toString()).intValue();
                    if (iIntValue < -32768 || iIntValue > 65535) {
                        Context context = this.f9319d;
                        Toast.makeText(context, context.getResources().getString(R.string.error_input_val_reg), 1).show();
                    } else {
                        this.b.setVarIntConstant(iIntValue);
                        this.c.dismiss();
                    }
                }
            } catch (Exception unused) {
                Context context2 = this.f9319d;
                Toast.makeText(context2, context2.getResources().getString(R.string.error_input_val_reg), 1).show();
            }
        }
    }

    static class z implements View.OnClickListener {
        final /* synthetic */ Context a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        z(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog) {
            this.a = context;
            this.b = aVar;
            this.c = alertDialog;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.logic_connect /* 2131296788 */:
                    Context context = this.a;
                    ((mbCanvas) context).T0 = this.b;
                    ((mbCanvas) context).S0 = true;
                    break;
                case R.id.logic_disconnect_out /* 2131296789 */:
                    this.b.c();
                    mbCanvas.f1.invalidate();
                    break;
                default:
                    return;
            }
            this.c.dismiss();
        }
    }

    static class z0 implements View.OnClickListener {
        final /* synthetic */ EditText a;
        final /* synthetic */ ru.himik.nightscream.kascada.Logic.c.a b;
        final /* synthetic */ AlertDialog c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ Context f9320d;

        z0(EditText editText, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, Context context) {
            this.a = editText;
            this.b = aVar;
            this.c = alertDialog;
            this.f9320d = context;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            try {
                if (this.a.getText().toString().length() > 0) {
                    this.b.setVarFloatConstant(Float.valueOf(this.a.getText().toString()).floatValue());
                    this.c.dismiss();
                }
            } catch (Exception unused) {
                Context context = this.f9320d;
                Toast.makeText(context, context.getResources().getString(R.string.error_input_parse_float), 1).show();
            }
        }
    }

    public static void A(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_change_i, (ViewGroup) null);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.s
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.f(context, aVar, alertDialogCreate, view);
            }
        };
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(onClickListener);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void B(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_compare, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        k kVar = new k(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(kVar);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(kVar);
        viewInflate.findViewById(R.id.logic_invert).setOnClickListener(kVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(kVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void C(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_compare_action_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        v vVar = new v(aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.compareActionGT).setOnClickListener(vVar);
        viewInflate.findViewById(R.id.compareActionLT).setOnClickListener(vVar);
        viewInflate.findViewById(R.id.compareActionLE).setOnClickListener(vVar);
        viewInflate.findViewById(R.id.compareActionGE).setOnClickListener(vVar);
        viewInflate.findViewById(R.id.compareActionEQ).setOnClickListener(vVar);
        viewInflate.findViewById(R.id.compareActionNE).setOnClickListener(vVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void D(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_compare, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        q qVar = new q(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(qVar);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(qVar);
        viewInflate.findViewById(R.id.logic_invert).setOnClickListener(qVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(qVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void E(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_ctu, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        y yVar = new y(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(yVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(yVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void F(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_float_to_int, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        c0 c0Var = new c0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(c0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(c0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void G(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_int_to_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        a0 a0Var = new a0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(a0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(a0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void H(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_log, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        h0 h0Var = new h0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(h0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(h0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void I(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_macro, (ViewGroup) null);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.m
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.g(context, aVar, alertDialogCreate, view);
            }
        };
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(onClickListener);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void J(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_move, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        z zVar = new z(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(zVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(zVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void K(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar) {
        StringBuilder sb;
        String str;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_mqtt_publisher, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        final MQTT_PUBLISHER mqtt_publisher = (MQTT_PUBLISHER) aVar;
        CheckBox checkBox = (CheckBox) viewInflate.findViewById(R.id.cbMqttTopicRetain);
        EditText editText = (EditText) viewInflate.findViewById(R.id.mqtt_topic);
        final TextView textView = (TextView) viewInflate.findViewById(R.id.tvTypeIn);
        final TextView textView2 = (TextView) viewInflate.findViewById(R.id.mqttServerIp);
        if (mqtt_publisher.getNumMqttServer() == 1) {
            textView2.setText(MyApplication.b().o0.a());
        }
        if (mqtt_publisher.getNumMqttServer() == 2) {
            textView2.setText(MyApplication.b().p0.a());
        }
        int typeIn = mqtt_publisher.getTypeIn();
        if (typeIn == 1) {
            sb = new StringBuilder();
            sb.append(context.getString(R.string.type_in));
            str = ": BOOL";
        } else {
            if (typeIn != 2) {
                if (typeIn == 3) {
                    sb = new StringBuilder();
                    sb.append(context.getString(R.string.type_in));
                    str = ": FLOAT";
                }
                checkBox.setChecked(mqtt_publisher.v());
                checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: ru.himik.nightscream.kascada.r.l
                    @Override // android.widget.CompoundButton.OnCheckedChangeListener
                    public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
                        mqtt_publisher.setMqttRetain(z2);
                    }
                });
                editText.setText(mqtt_publisher.getTopic());
                View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.q
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        e0.i(context, aVar, textView, textView2, view);
                    }
                };
                alertDialogCreate.setOnDismissListener(new e1(mqtt_publisher, editText));
                viewInflate.findViewById(R.id.type_in).setOnClickListener(onClickListener);
                viewInflate.findViewById(R.id.mqtt_server).setOnClickListener(onClickListener);
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
            }
            sb = new StringBuilder();
            sb.append(context.getString(R.string.type_in));
            str = ": INT";
        }
        sb.append(str);
        textView.setText(sb.toString());
        checkBox.setChecked(mqtt_publisher.v());
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: ru.himik.nightscream.kascada.r.l
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
                mqtt_publisher.setMqttRetain(z2);
            }
        });
        editText.setText(mqtt_publisher.getTopic());
        View.OnClickListener onClickListener2 = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.q
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.i(context, aVar, textView, textView2, view);
            }
        };
        alertDialogCreate.setOnDismissListener(new e1(mqtt_publisher, editText));
        viewInflate.findViewById(R.id.type_in).setOnClickListener(onClickListener2);
        viewInflate.findViewById(R.id.mqtt_server).setOnClickListener(onClickListener2);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void L(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar) {
        StringBuilder sb;
        String str;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_mqtt_subscriber, (ViewGroup) null);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        MQTT_SUBSCRIBER mqtt_subscriber = (MQTT_SUBSCRIBER) aVar;
        EditText editText = (EditText) viewInflate.findViewById(R.id.mqtt_topic);
        final TextView textView = (TextView) viewInflate.findViewById(R.id.tvTypeQ);
        final TextView textView2 = (TextView) viewInflate.findViewById(R.id.mqttServerIp);
        if (mqtt_subscriber.getNumMqttServer() == 1) {
            textView2.setText(MyApplication.b().o0.a());
        }
        if (mqtt_subscriber.getNumMqttServer() == 2) {
            textView2.setText(MyApplication.b().p0.a());
        }
        int typeQ = mqtt_subscriber.getTypeQ();
        if (typeQ == 1) {
            sb = new StringBuilder();
            sb.append(context.getString(R.string.type_q));
            str = ": BOOL";
        } else {
            if (typeQ != 2) {
                if (typeQ == 3) {
                    sb = new StringBuilder();
                    sb.append(context.getString(R.string.type_q));
                    str = ": FLOAT";
                }
                editText.setText(mqtt_subscriber.getTopic());
                View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.n
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        e0.j(context, aVar, alertDialogCreate, textView, textView2, view);
                    }
                };
                alertDialogCreate.setOnDismissListener(new a1(mqtt_subscriber, editText));
                viewInflate.findViewById(R.id.logic_connect).setOnClickListener(onClickListener);
                viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(onClickListener);
                viewInflate.findViewById(R.id.type_q).setOnClickListener(onClickListener);
                viewInflate.findViewById(R.id.mqtt_server).setOnClickListener(onClickListener);
                alertDialogCreate.setView(viewInflate);
                alertDialogCreate.show();
            }
            sb = new StringBuilder();
            sb.append(context.getString(R.string.type_q));
            str = ": INT";
        }
        sb.append(str);
        textView.setText(sb.toString());
        editText.setText(mqtt_subscriber.getTopic());
        View.OnClickListener onClickListener2 = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.n
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.j(context, aVar, alertDialogCreate, textView, textView2, view);
            }
        };
        alertDialogCreate.setOnDismissListener(new a1(mqtt_subscriber, editText));
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(onClickListener2);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(onClickListener2);
        viewInflate.findViewById(R.id.type_q).setOnClickListener(onClickListener2);
        viewInflate.findViewById(R.id.mqtt_server).setOnClickListener(onClickListener2);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void M(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_mx, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        o0 o0Var = new o0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(o0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(o0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void N(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_pow, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        j0 j0Var = new j0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(j0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(j0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void O(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_rs, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        r rVar = new r(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(rVar);
        viewInflate.findViewById(R.id.logic_invert).setOnClickListener(rVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(rVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void P(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sel, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        l0 l0Var = new l0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(l0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(l0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void Q(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sensor_light, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        s0 s0Var = new s0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(s0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(s0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void R(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sensor_orientation, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        d0 d0Var = new d0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(d0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(d0Var);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(d0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void S(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sensor_orientation_edit_type, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        ViewOnClickListenerC0305e0 viewOnClickListenerC0305e0 = new ViewOnClickListenerC0305e0(aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.sensorActionX).setOnClickListener(viewOnClickListenerC0305e0);
        viewInflate.findViewById(R.id.sensorActionY).setOnClickListener(viewOnClickListenerC0305e0);
        viewInflate.findViewById(R.id.sensorActionZ).setOnClickListener(viewOnClickListenerC0305e0);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void T(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sensor_speed, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        t0 t0Var = new t0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(t0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(t0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void U(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sin, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        f0 f0Var = new f0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(f0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(f0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void V(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sunrise, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        m0 m0Var = new m0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(m0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(m0Var);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(m0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void W(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_sunrise_edit_type, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        n0 n0Var = new n0(aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.sunriseTime).setOnClickListener(n0Var);
        viewInflate.findViewById(R.id.sunsetTime).setOnClickListener(n0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void X(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_timer, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        t tVar = new t(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(tVar);
        viewInflate.findViewById(R.id.logic_edit_time).setOnClickListener(tVar);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(tVar);
        viewInflate.findViewById(R.id.logic_invert).setOnClickListener(tVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(tVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void Y(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_timer_edit_type, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        w wVar = new w(aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.timerActionTON).setOnClickListener(wVar);
        viewInflate.findViewById(R.id.timerActionTOF).setOnClickListener(wVar);
        viewInflate.findViewById(R.id.timerActionTP).setOnClickListener(wVar);
        viewInflate.findViewById(R.id.timerActionBLINK).setOnClickListener(wVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void Z(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_timer_edit_type_time, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        x xVar = new x(aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.timerMs).setOnClickListener(xVar);
        viewInflate.findViewById(R.id.timerSek).setOnClickListener(xVar);
        viewInflate.findViewById(R.id.timerMin).setOnClickListener(xVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void a(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, TextView textView, AlertDialog alertDialog, View view) {
        g0(context, 1);
        if (aVar instanceof MQTT_SUBSCRIBER) {
            ((MQTT_SUBSCRIBER) aVar).setNumMqttServer(1);
            textView.setText(MyApplication.b().o0.a());
        }
        if (aVar instanceof MQTT_PUBLISHER) {
            ((MQTT_PUBLISHER) aVar).setNumMqttServer(1);
            textView.setText(MyApplication.b().o0.a());
        }
        alertDialog.dismiss();
    }

    public static void a0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_trigger, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        s sVar = new s(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(sVar);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(sVar);
        viewInflate.findViewById(R.id.logic_invert).setOnClickListener(sVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(sVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void b(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, TextView textView, AlertDialog alertDialog, View view) {
        g0(context, 2);
        if (aVar instanceof MQTT_SUBSCRIBER) {
            ((MQTT_SUBSCRIBER) aVar).setNumMqttServer(2);
            textView.setText(MyApplication.b().p0.a());
        }
        if (aVar instanceof MQTT_PUBLISHER) {
            ((MQTT_PUBLISHER) aVar).setNumMqttServer(2);
            textView.setText(MyApplication.b().p0.a());
        }
        alertDialog.dismiss();
    }

    static void b0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_trigger_edit_type, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        u uVar = new u(aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.timerActionT).setOnClickListener(uVar);
        viewInflate.findViewById(R.id.timerActionR).setOnClickListener(uVar);
        viewInflate.findViewById(R.id.timerActionF).setOnClickListener(uVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void c(ru.himik.nightscream.kascada.Logic.VarName.b bVar, Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, DialogInterface dialogInterface, int i2) {
        if (i2 == 0) {
            bVar.setTypeVarValue(1);
            n(context, aVar);
        } else {
            if (i2 != 1) {
                return;
            }
            bVar.setTypeVarValue(2);
            aVar.setConstant(true);
            l(context, aVar);
        }
    }

    public static void c0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_word_to_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        b0 b0Var = new b0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(b0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(b0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void d(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, View view) {
        switch (view.getId()) {
            case R.id.logic_connect /* 2131296788 */:
                mbCanvas mbcanvas = (mbCanvas) context;
                mbcanvas.T0 = aVar;
                mbcanvas.S0 = true;
                break;
            case R.id.logic_disconnect_out /* 2131296789 */:
                aVar.c();
                mbCanvas.f1.invalidate();
                break;
            default:
                return;
        }
        alertDialog.dismiss();
    }

    public static void d0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_xor, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        k0 k0Var = new k0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(k0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(k0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void e(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, View view) {
        switch (view.getId()) {
            case R.id.logic_connect /* 2131296788 */:
                mbCanvas mbcanvas = (mbCanvas) context;
                mbcanvas.T0 = aVar;
                mbcanvas.S0 = true;
                break;
            case R.id.logic_disconnect_out /* 2131296789 */:
                aVar.c();
                mbCanvas.f1.invalidate();
                break;
            default:
                return;
        }
        alertDialog.dismiss();
    }

    static void e0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_constant_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        EditText editText = (EditText) viewInflate.findViewById(R.id.eConstFloatNumber);
        editText.setText(aVar.getVarFloatConstant() + "");
        viewInflate.findViewById(R.id.bOk).setOnClickListener(new z0(editText, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void f(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, View view) {
        switch (view.getId()) {
            case R.id.logic_connect /* 2131296788 */:
                mbCanvas mbcanvas = (mbCanvas) context;
                mbcanvas.T0 = aVar;
                mbcanvas.S0 = true;
                break;
            case R.id.logic_disconnect_out /* 2131296789 */:
                aVar.c();
                mbCanvas.f1.invalidate();
                break;
            default:
                return;
        }
        alertDialog.dismiss();
    }

    static void f0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_constant_int, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        EditText editText = (EditText) viewInflate.findViewById(R.id.eConstIntNumber);
        editText.setText(aVar.getVarIntConstant() + "");
        viewInflate.findViewById(R.id.bOk).setOnClickListener(new y0(editText, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void g(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, View view) {
        switch (view.getId()) {
            case R.id.logic_connect /* 2131296788 */:
                mbCanvas mbcanvas = (mbCanvas) context;
                mbcanvas.T0 = aVar;
                mbcanvas.S0 = true;
                break;
            case R.id.logic_disconnect_out /* 2131296789 */:
                aVar.c();
                mbCanvas.f1.invalidate();
                break;
            case R.id.logic_edit /* 2131296790 */:
                ((mbCanvas) context).z((FB_MACRO) aVar);
                break;
            default:
                return;
        }
        alertDialog.dismiss();
    }

    public static void g0(Context context, int i2) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_mqtt_server, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        EditText editText = (EditText) viewInflate.findViewById(R.id.mqtt_ip);
        EditText editText2 = (EditText) viewInflate.findViewById(R.id.mqtt_port);
        EditText editText3 = (EditText) viewInflate.findViewById(R.id.mqtt_login);
        EditText editText4 = (EditText) viewInflate.findViewById(R.id.mqtt_pass);
        ru.himik.nightscream.kascada.q.b.a aVar = i2 == 1 ? MyApplication.b().o0 : MyApplication.b().p0;
        editText.setText(aVar.a());
        editText2.setText(aVar.d() + "");
        editText3.setText(aVar.b());
        editText4.setText(aVar.c());
        alertDialogCreate.setOnDismissListener(new d1(aVar, editText, editText2, context, editText3, editText4));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void h0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_var, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        g0 g0Var = new g0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(g0Var);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(g0Var);
        viewInflate.findViewById(R.id.logic_invert).setOnClickListener(g0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(g0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void i(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, TextView textView, TextView textView2, View view) {
        int id = view.getId();
        if (id == R.id.mqtt_server) {
            m(context, aVar, textView2);
        } else {
            if (id != R.id.type_in) {
                return;
            }
            p(context, aVar, textView);
        }
    }

    public static void i0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_var_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        f fVar = new f(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(fVar);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(fVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(fVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static /* synthetic */ void j(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, AlertDialog alertDialog, TextView textView, TextView textView2, View view) {
        switch (view.getId()) {
            case R.id.logic_connect /* 2131296788 */:
                mbCanvas mbcanvas = (mbCanvas) context;
                mbcanvas.T0 = aVar;
                mbcanvas.S0 = true;
                break;
            case R.id.logic_disconnect_out /* 2131296789 */:
                aVar.c();
                mbCanvas.f1.invalidate();
                break;
            case R.id.mqtt_server /* 2131296857 */:
                m(context, aVar, textView2);
                return;
            case R.id.type_q /* 2131297334 */:
                p(context, aVar, textView);
                return;
            default:
                return;
        }
        alertDialog.dismiss();
    }

    public static void j0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_var_int, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        g1 g1Var = new g1(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(g1Var);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(g1Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(g1Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void k(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_constant_bool, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        Spinner spinner = (Spinner) viewInflate.findViewById(R.id.spinnerLogicVarConstant);
        spinner.setSelection(!aVar.getVarConstant() ? 1 : 0);
        spinner.setOnItemSelectedListener(new w0(aVar));
        viewInflate.findViewById(R.id.bOk).setOnClickListener(new x0(alertDialogCreate));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void k0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_var_name_in, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        u0 u0Var = new u0(aVar, context, alertDialogCreate);
        if (((VarNameIn) aVar).t()) {
            viewInflate.findViewById(R.id.logic_edit).setVisibility(8);
        }
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(u0Var);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(u0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(u0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void l(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        int typeVar = ((ru.himik.nightscream.kascada.Logic.VarName.b) aVar).getTypeVar();
        if (typeVar == 1) {
            k(context, aVar);
        } else if (typeVar == 2) {
            f0(context, aVar);
        } else {
            if (typeVar != 3) {
                return;
            }
            e0(context, aVar);
        }
    }

    public static void l0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_var_out, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(new a(context, aVar));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void m(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar, final TextView textView) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_choose_mqtt_server, (ViewGroup) null);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        alertDialogCreate.setTitle("Выбор сервера");
        LinearLayout linearLayout = (LinearLayout) viewInflate.findViewById(R.id.lChooseServer1);
        LinearLayout linearLayout2 = (LinearLayout) viewInflate.findViewById(R.id.lChooseServer2);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvIpServer1);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvIpServer2);
        textView2.setText(MyApplication.b().o0.a());
        textView3.setText(MyApplication.b().p0.a());
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.p
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.a(context, aVar, textView, alertDialogCreate, view);
            }
        });
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.o
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.b(context, aVar, textView, alertDialogCreate, view);
            }
        });
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void m0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_var_out_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(new l(context, aVar));
        TextView textView = (TextView) viewInflate.findViewById(R.id.textByteOrder);
        VarOutFloat varOutFloat = (VarOutFloat) aVar;
        ((CheckBox) viewInflate.findViewById(R.id.checkHighRegister)).setChecked(varOutFloat.S);
        ((CheckBox) viewInflate.findViewById(R.id.checkHighByte)).setChecked(varOutFloat.T);
        ((CheckBox) viewInflate.findViewById(R.id.checkHighRegister)).setOnCheckedChangeListener(new m(aVar, textView));
        ((CheckBox) viewInflate.findViewById(R.id.checkHighByte)).setOnCheckedChangeListener(new n(aVar, textView));
        textView.setText(varOutFloat.getTextOrder());
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v4, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r13v5, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r13v7, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r1v0, types: [android.app.DialogFragment, ru.himik.nightscream.kascada.r.i0.d] */
    public static void n(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        ?? D;
        mbCanvas mbcanvas = (mbCanvas) context;
        FragmentManager fragmentManager = mbcanvas.getFragmentManager();
        ?? dVar = new ru.himik.nightscream.kascada.r.i0.d();
        ru.himik.nightscream.kascada.Logic.VarName.b bVar = (ru.himik.nightscream.kascada.Logic.VarName.b) aVar;
        dVar.e(bVar);
        if (aVar.getNumScreen() == -1) {
            D = new ArrayList();
            SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray = MyApplication.b().D;
            for (int i2 = 0; i2 < sparseArray.size(); i2++) {
                ru.himik.nightscream.kascada.Logic.c.a aVar2 = sparseArray.get(sparseArray.keyAt(i2));
                if (aVar2.getTypeFb() != 134) {
                    if (aVar2.getTypeFb() != 133 && !((VarNameIn) aVar2).t()) {
                        ru.himik.nightscream.kascada.Logic.VarName.b bVar2 = (ru.himik.nightscream.kascada.Logic.VarName.b) aVar2;
                        if (bVar2.getTypeVar() == bVar.getTypeVar() && aVar2.getRootUniqueIdMacro() == aVar.getRootUniqueIdMacro() && !bVar2.getVarName().equals("var name") && !D.contains(bVar2.getVarName())) {
                            D.add(bVar2.getVarName());
                        }
                    }
                } else if (!((VarNameOut) aVar2).t()) {
                    ru.himik.nightscream.kascada.Logic.VarName.b bVar3 = (ru.himik.nightscream.kascada.Logic.VarName.b) aVar2;
                    if (bVar3.getTypeVar() == bVar.getTypeVar() && aVar2.getRootUniqueIdMacro() == aVar.getRootUniqueIdMacro() && !bVar3.getVarName().equals("var name") && !D.contains(bVar3.getVarName())) {
                        D.add(bVar3.getVarName());
                    }
                    if (aVar2.getTypeFb() != 133) {
                    }
                }
            }
        } else {
            D = mbcanvas.C().c().d(bVar.getTypeVar());
        }
        dVar.d(D);
        dVar.show(fragmentManager, "");
    }

    public static void n0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_var_out_int, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(new b(context, aVar));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void o(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.dialog_title_choose_type_varname);
        builder.setItems(new String[]{"BOOL", "INT", "FLOAT"}, new v0((ru.himik.nightscream.kascada.Logic.VarName.b) aVar, aVar, context));
        AlertDialog alertDialogCreate = builder.create();
        alertDialogCreate.setCancelable(false);
        alertDialogCreate.show();
    }

    public static void o0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        if (aVar.getTypeFb() == 117) {
            J(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 116) {
            E(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 115) {
            X(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 113) {
            O(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 114) {
            a0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 107) {
            B(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 103 || aVar.getTypeFb() == 104) {
            u(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 101) {
            h0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 102) {
            l0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 105) {
            j0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 106) {
            n0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 110) {
            w(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 108) {
            i0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 109) {
            m0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 111) {
            v(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 112) {
            D(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 118) {
            G(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 129) {
            c0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 119) {
            F(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 120) {
            R(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 121) {
            U(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 122) {
            H(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 123) {
            t(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 124) {
            N(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 125) {
            d0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 126) {
            P(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 127) {
            V(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 128) {
            M(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 130) {
            s(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 131) {
            Q(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 132) {
            T(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 133) {
            k0(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 134) {
            if (((VarNameOut) aVar).t()) {
                return;
            }
            n(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 135) {
            I(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 136) {
            y(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 137) {
            A(context, aVar);
            return;
        }
        if (aVar.getTypeFb() == 138) {
            z(context, aVar);
        } else if (aVar.getTypeFb() == 139) {
            L(context, aVar);
        } else if (aVar.getTypeFb() == 140) {
            K(context, aVar);
        }
    }

    public static void p(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar, TextView textView) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.type_q);
        builder.setItems(new String[]{"BOOL", "INT", "FLOAT"}, new b1(aVar, textView, context));
        builder.create().show();
    }

    static void p0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_set_reg_bool, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        EditText editText = (EditText) viewInflate.findViewById(R.id.logicSetReg);
        StringBuilder sb = new StringBuilder();
        ru.himik.nightscream.kascada.Logic.e eVar = (ru.himik.nightscream.kascada.Logic.e) aVar;
        sb.append(eVar.getReg());
        sb.append("");
        editText.setText(sb.toString());
        EditText editText2 = (EditText) viewInflate.findViewById(R.id.logicSetBit);
        editText2.setText(eVar.getBit() + "");
        TextView textView = (TextView) viewInflate.findViewById(R.id.textBitLogicVar);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.textRegLogicVar);
        Spinner spinner = (Spinner) viewInflate.findViewById(R.id.spinnerLogicVar);
        Spinner spinner2 = (Spinner) viewInflate.findViewById(R.id.spinnerLogicVarConstant);
        spinner2.setSelection(!aVar.getVarConstant() ? 1 : 0);
        if (aVar.g()) {
            spinner.setSelection(1);
            spinner2.setVisibility(0);
            editText.setVisibility(8);
            editText2.setVisibility(8);
            textView.setVisibility(8);
            textView2.setVisibility(8);
        } else {
            spinner.setSelection(0);
            spinner2.setVisibility(8);
            editText.setVisibility(0);
            editText2.setVisibility(0);
            textView.setVisibility(0);
            textView2.setVisibility(0);
        }
        spinner.setOnItemSelectedListener(new r0(spinner2, editText, editText2, textView, textView2, aVar));
        spinner2.setOnItemSelectedListener(new c1(aVar));
        viewInflate.findViewById(R.id.logicSetRegOk).setOnClickListener(new f1(editText, editText2, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void q(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar) {
        final ru.himik.nightscream.kascada.Logic.VarName.b bVar = (ru.himik.nightscream.kascada.Logic.VarName.b) aVar;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.dialog_title_choose_type_varname);
        builder.setItems(context.getResources().getStringArray(R.array.listVarNameValue), new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.r
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                e0.c(bVar, context, aVar, dialogInterface, i2);
            }
        });
        AlertDialog alertDialogCreate = builder.create();
        alertDialogCreate.setCancelable(false);
        alertDialogCreate.show();
    }

    static void q0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        StringBuilder sb;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_set_reg_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        Spinner spinner = (Spinner) viewInflate.findViewById(R.id.spinnerLogicVarFloat);
        TextView textView = (TextView) viewInflate.findViewById(R.id.textRegLogicVarFloat);
        EditText editText = (EditText) viewInflate.findViewById(R.id.logicSetRegFloat);
        spinner.setSelection(!aVar.getVarConstant() ? 1 : 0);
        if (aVar.g()) {
            spinner.setSelection(1);
            sb = new StringBuilder();
            sb.append(aVar.getVarFloatConstant());
        } else {
            spinner.setSelection(0);
            sb = new StringBuilder();
            sb.append(((ru.himik.nightscream.kascada.Logic.e) aVar).getReg());
        }
        sb.append("");
        editText.setText(sb.toString());
        spinner.setOnItemSelectedListener(new i(textView, context, editText, aVar));
        viewInflate.findViewById(R.id.logicSetRegOk).setOnClickListener(new j(editText, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void r(Context context, FB_MACRO fb_macro) {
        FragmentManager fragmentManager = ((mbCanvas) context).getFragmentManager();
        ru.himik.nightscream.kascada.r.b0 b0Var = new ru.himik.nightscream.kascada.r.b0();
        b0Var.r(fb_macro);
        b0Var.show(fragmentManager, "");
    }

    static void r0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        StringBuilder sb;
        int reg;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_set_reg_int, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        Spinner spinner = (Spinner) viewInflate.findViewById(R.id.spinnerLogicVarInt);
        TextView textView = (TextView) viewInflate.findViewById(R.id.textRegLogicVarInt);
        EditText editText = (EditText) viewInflate.findViewById(R.id.logicSetRegInt);
        spinner.setSelection(!aVar.getVarConstant() ? 1 : 0);
        if (aVar.g()) {
            spinner.setSelection(1);
            sb = new StringBuilder();
            reg = aVar.getVarIntConstant();
        } else {
            spinner.setSelection(0);
            sb = new StringBuilder();
            reg = ((ru.himik.nightscream.kascada.Logic.e) aVar).getReg();
        }
        sb.append(reg);
        sb.append("");
        editText.setText(sb.toString());
        spinner.setOnItemSelectedListener(new h1(textView, context, editText, aVar));
        viewInflate.findViewById(R.id.logicSetRegOk).setOnClickListener(new i1(editText, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void s(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_dt, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        TextView textView = (TextView) viewInflate.findViewById(R.id.logic_edit_type_sensor_text);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.logic_edit_type_response_text);
        EditText editText = (EditText) viewInflate.findViewById(R.id.ip);
        ODTEMP odtemp = (ODTEMP) aVar;
        p0 p0Var = new p0(context, aVar, alertDialogCreate, odtemp, textView, textView2);
        alertDialogCreate.setOnDismissListener(new q0(odtemp, editText));
        int typeSensor = odtemp.getTypeSensor();
        if (typeSensor != 1) {
            if (typeSensor != 2) {
                odtemp.setTypeSensor(1);
                textView.setText("ODTEMP_2U");
            } else {
                textView.setText("ODTEMP_2W");
                int typeResponse = odtemp.getTypeResponse();
                if (typeResponse != 1) {
                    if (typeResponse != 2) {
                        odtemp.setTypeResponse(1);
                    } else {
                        textView2.setText(R.string.humidity);
                    }
                }
            }
            editText.setText(odtemp.getIp());
            viewInflate.findViewById(R.id.logic_edit_type_response).setOnClickListener(p0Var);
            viewInflate.findViewById(R.id.logic_edit_type_sensor).setOnClickListener(p0Var);
            viewInflate.findViewById(R.id.logic_connect).setOnClickListener(p0Var);
            viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(p0Var);
            alertDialogCreate.setView(viewInflate);
            alertDialogCreate.show();
        }
        textView.setText("ODTEMP_2U");
        textView2.setText(R.string.temperature);
        editText.setText(odtemp.getIp());
        viewInflate.findViewById(R.id.logic_edit_type_response).setOnClickListener(p0Var);
        viewInflate.findViewById(R.id.logic_edit_type_sensor).setOnClickListener(p0Var);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(p0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(p0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void s0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_set_reg_bool_out, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        EditText editText = (EditText) viewInflate.findViewById(R.id.logicSetReg);
        StringBuilder sb = new StringBuilder();
        ru.himik.nightscream.kascada.Logic.e eVar = (ru.himik.nightscream.kascada.Logic.e) aVar;
        sb.append(eVar.getReg());
        sb.append("");
        editText.setText(sb.toString());
        EditText editText2 = (EditText) viewInflate.findViewById(R.id.logicSetBit);
        editText2.setText(eVar.getBit() + "");
        viewInflate.findViewById(R.id.logicSetRegOk).setOnClickListener(new c(editText, editText2, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void t(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_abs, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        i0 i0Var = new i0(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(i0Var);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(i0Var);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void t0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_set_reg_out_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        EditText editText = (EditText) viewInflate.findViewById(R.id.logicSetReg);
        editText.setText(((ru.himik.nightscream.kascada.Logic.e) aVar).getReg() + "");
        viewInflate.findViewById(R.id.logicSetRegOk).setOnClickListener(new o(editText, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void u(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_and_or, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        e eVar = new e(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(eVar);
        viewInflate.findViewById(R.id.logic_invert).setOnClickListener(eVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(eVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void u0(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.dialog_set_reg_out_int, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        EditText editText = (EditText) viewInflate.findViewById(R.id.logicSetReg);
        editText.setText(((ru.himik.nightscream.kascada.Logic.e) aVar).getReg() + "");
        viewInflate.findViewById(R.id.logicSetRegOk).setOnClickListener(new d(editText, aVar, alertDialogCreate, context));
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void v(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_arithmetic_float, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        p pVar = new p(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(pVar);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(pVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(pVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void w(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_arithmetic_int, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        g gVar = new g(context, aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.logic_edit).setOnClickListener(gVar);
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(gVar);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(gVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    static void x(Context context, ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_arithmetic_action, (ViewGroup) null);
        AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        h hVar = new h(aVar, alertDialogCreate);
        viewInflate.findViewById(R.id.arithmeticActionADD).setOnClickListener(hVar);
        viewInflate.findViewById(R.id.arithmeticActionSUB).setOnClickListener(hVar);
        viewInflate.findViewById(R.id.arithmeticActionMUL).setOnClickListener(hVar);
        viewInflate.findViewById(R.id.arithmeticActionDIV).setOnClickListener(hVar);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void y(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_array, (ViewGroup) null);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.k
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.d(context, aVar, alertDialogCreate, view);
            }
        };
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(onClickListener);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }

    public static void z(final Context context, final ru.himik.nightscream.kascada.Logic.c.a aVar) {
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.popup_logic_fb_change_f, (ViewGroup) null);
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(context).create();
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.r.j
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                e0.e(context, aVar, alertDialogCreate, view);
            }
        };
        viewInflate.findViewById(R.id.logic_connect).setOnClickListener(onClickListener);
        viewInflate.findViewById(R.id.logic_disconnect_out).setOnClickListener(onClickListener);
        alertDialogCreate.setView(viewInflate);
        alertDialogCreate.show();
    }
}
