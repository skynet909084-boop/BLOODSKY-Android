package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b0 extends WebView implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b, View.OnTouchListener {
    String C;
    String D;
    String E;
    String F;
    String G;
    String H;
    String I;
    String J;
    int K;
    boolean L;
    int M;
    int N;
    private long O;
    public Point P;
    long Q;
    Context a;
    public String b;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8727d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public byte f8728e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public b f8729f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8730g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    String f8731h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    String f8732i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    String f8733j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    String f8734k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f8735l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    String f8736m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8737n;
    String o;

    public b0(Context context) {
        super(context);
        this.b = getResources().getString(R.string.custom_web_view);
        this.c = 26;
        this.f8728e = (byte) 3;
        this.f8729f = new b();
        new Paint();
        this.f8731h = "https://hmi-kascada.ru/";
        this.f8732i = "";
        this.f8733j = "";
        this.f8734k = "";
        this.f8735l = "";
        this.f8736m = "";
        this.f8737n = "";
        this.o = "";
        this.C = "";
        this.D = "";
        this.E = "";
        this.F = "";
        this.G = "";
        this.H = "";
        this.I = "";
        this.J = "";
        this.K = -1;
        this.L = false;
        this.M = 0;
        this.N = 0;
        this.O = 0L;
        this.P = new Point();
        this.Q = 0L;
        this.a = context;
    }

    private void a(boolean z) {
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (z) {
            this.Q = jCurrentTimeMillis;
        } else if (jCurrentTimeMillis - this.Q < 300) {
            ((mbCanvas) this.a).onClickView(this);
        }
    }

    public String b(int i2) {
        switch (i2) {
            case 0:
                return this.f8731h;
            case 1:
                return this.f8732i;
            case 2:
                return this.f8733j;
            case 3:
                return this.f8734k;
            case 4:
                return this.f8735l;
            case 5:
                return this.f8736m;
            case 6:
                return this.f8737n;
            case 7:
                return this.o;
            case 8:
                return this.C;
            case 9:
                return this.D;
            case 10:
                return this.E;
            case 11:
                return this.F;
            case 12:
                return this.G;
            case 13:
                return this.H;
            case 14:
                return this.I;
            case 15:
                return this.J;
            default:
                return "";
        }
    }

    public void c(int i2, int i3, int i4, boolean z) {
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setKey(i4);
        this.f8729f.A(this.c);
        this.f8729f.L(this.f8728e);
        getSettings().setJavaScriptEnabled(true);
        setWebViewClient(new WebViewClient());
        setWebChromeClient(new WebChromeClient());
        getSettings().setBuiltInZoomControls(true);
        getSettings().setDisplayZoomControls(false);
        setInitialScale(100);
        setOnTouchListener(this);
        loadUrl("");
    }

    public void d(int i2, String str) {
        switch (i2) {
            case 0:
                this.f8731h = str;
                break;
            case 1:
                this.f8732i = str;
                break;
            case 2:
                this.f8733j = str;
                break;
            case 3:
                this.f8734k = str;
                break;
            case 4:
                this.f8735l = str;
                break;
            case 5:
                this.f8736m = str;
                break;
            case 6:
                this.f8737n = str;
                break;
            case 7:
                this.o = str;
                break;
            case 8:
                this.C = str;
                break;
            case 9:
                this.D = str;
                break;
            case 10:
                this.E = str;
                break;
            case 11:
                this.F = str;
                break;
            case 12:
                this.G = str;
                break;
            case 13:
                this.H = str;
                break;
            case 14:
                this.I = str;
                break;
            case 15:
                this.J = str;
                break;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.P.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void e(int i2) {
        if (i2 != this.K) {
            for (int i3 = 0; i3 < 16; i3++) {
                if (((i2 >> i3) & 1) == 1) {
                    loadUrl((b(i3).toLowerCase().contains("http://") || b(i3).toLowerCase().contains("https://")) ? b(i3) : "http://" + b(i3));
                    this.K = i2;
                    return;
                }
            }
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8729f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.c;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8730g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.M;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.c;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8729f.l());
        jSONObject.put("addressRegister", this.f8729f.c());
        jSONObject.put("addressBit", (int) this.f8729f.a());
        jSONObject.put("typeRequest", (int) this.f8729f.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("timeZ", getTimeZ());
        jSONObject.put("link0", this.f8731h);
        jSONObject.put("link1", this.f8732i);
        jSONObject.put("link2", this.f8733j);
        jSONObject.put("link3", this.f8734k);
        jSONObject.put("link4", this.f8735l);
        jSONObject.put("link5", this.f8736m);
        jSONObject.put("link6", this.f8737n);
        jSONObject.put("link7", this.o);
        jSONObject.put("link8", this.C);
        jSONObject.put("link9", this.D);
        jSONObject.put("link10", this.E);
        jSONObject.put("link11", this.F);
        jSONObject.put("link12", this.G);
        jSONObject.put("link13", this.H);
        jSONObject.put("link14", this.I);
        jSONObject.put("link15", this.J);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8727d;
    }

    public int getNumScreen() {
        return this.f8730g;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8729f.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8729f.l() >= 100) {
            this.f8729f.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8729f.c();
        }
        this.f8729f.u((byte) MyApplication.b().E.get(this.f8729f.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8729f.b()) + "#" + this.f8729f.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8729f.l() >= 0) {
            if (this.f8729f.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8729f.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.O;
    }

    @Override // android.webkit.WebView, android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            a(true);
        } else if (action == 1 || action == 3) {
            a(false);
        }
        return false;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.L = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.M = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.N = i2;
    }

    public void setFont(String str) {
    }

    public void setIdComponent(int i2) {
        this.c = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8727d = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8730g = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.O = j2;
    }
}
