package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.c;

/* JADX INFO: loaded from: classes2.dex */
public class FB_OR extends c {
    boolean d0;

    public FB_OR(Context context) {
        super(context);
        this.d0 = false;
        setName("OR");
        s("IN1", 1);
        t("IN2", 1);
        u("Q", 1);
    }

    public FB_OR(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = false;
        setName("OR");
        s("IN1", 1);
        t("IN2", 1);
        u("Q", 1);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.d0 = false;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return;
        }
        try {
            this.d0 = ((Boolean) this.f8975g.getOut()).booleanValue() || ((Boolean) this.f8976h.getOut()).booleanValue();
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return null;
        }
        return Boolean.valueOf(this.f8973e ? !this.d0 : this.d0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_textAppearancePopupMenuHeader;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.S.setStyle(Paint.Style.FILL);
        this.S.setColor(-7829368);
        this.S.setStrokeWidth(this.U);
        this.V.set(this.T, this.U, getWidth() - this.T, getHeight() - this.U);
        canvas.drawRect(this.V, this.S);
        this.S.setStyle(Paint.Style.STROKE);
        this.S.setColor(-16777216);
        canvas.drawRect(this.V, this.S);
        this.W.setTextAlign(Paint.Align.CENTER);
        this.W.setFlags(1);
        canvas.drawText(this.L, getWidth() / 2, (int) ((getHeight() / 2) - ((this.W.descent() + this.W.ascent()) / 2.0f)), this.W);
        canvas.drawLine(0.0f, getHeight() / 4, this.T, getHeight() / 4, this.S);
        canvas.drawLine(0.0f, (getHeight() / 4) * 3, this.T, (getHeight() / 4) * 3, this.S);
        if (this.f8973e && this.R == 1) {
            canvas.drawCircle((getWidth() - this.T) + this.b0, ((getHeight() / 3) / 2) + (getHeight() / 3), this.b0, this.S);
            width = (getWidth() - this.T) + (this.b0 * 2);
        } else {
            width = getWidth() - this.T;
        }
        canvas.drawLine(width, ((getHeight() / 3) / 2) + (getHeight() / 3), getWidth(), ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        this.f8979k.set((int) getX(), ((int) getY()) + (getHeight() / 4));
        this.f8980l.set((int) getX(), ((int) getY()) + ((getHeight() / 4) * 3));
        this.f8981m.set(((int) getX()) + getWidth(), ((int) getY()) + ((getHeight() / 3) / 2) + (getHeight() / 3));
    }
}
