package ru.himik.nightscream.kascada.Connections.Usb.driver;

/* JADX INFO: loaded from: classes.dex */
public class UsbSerialRuntimeException extends RuntimeException {
    public UsbSerialRuntimeException() {
    }

    public UsbSerialRuntimeException(String str) {
        super(str);
    }

    public UsbSerialRuntimeException(String str, Throwable th) {
        super(str, th);
    }

    public UsbSerialRuntimeException(Throwable th) {
        super(th);
    }
}
