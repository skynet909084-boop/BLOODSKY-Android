package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class Sensor_Speed extends f {
    String V;

    public Sensor_Speed(Context context) {
        super(context);
        this.V = "SENSOR_SPEED";
    }

    public Sensor_Speed(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = "SENSOR_SPEED";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        try {
            return Float.valueOf(mbCanvas.m1);
        } catch (Exception unused) {
            return 0;
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 132;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 3;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        canvas.drawRect(this.G, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        canvas.drawRect(this.G, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        canvas.drawLine(getWidth() - this.Q, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        this.E = "SM";
        super.onMeasure(i2, i3);
    }
}
