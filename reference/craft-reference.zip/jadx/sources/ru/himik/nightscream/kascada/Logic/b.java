package ru.himik.nightscream.kascada.Logic;

import android.os.Handler;
import android.os.Message;
import android.util.SparseArray;
import android.view.View;
import java.util.ArrayList;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class b {
    C0288b a;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    ru.himik.nightscream.kascada.Logic.c.a f8958i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    ru.himik.nightscream.kascada.Logic.c.a f8959j;
    public SparseArray<ru.himik.nightscream.kascada.Logic.c.a> b = new SparseArray<>();
    public ArrayList<ru.himik.nightscream.kascada.Logic.c.a> c = new ArrayList<>();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList<ru.himik.nightscream.kascada.Logic.c.a> f8953d = new ArrayList<>();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ArrayList<d> f8954e = new ArrayList<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8955f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f8956g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8957h = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    Handler f8960k = new a();

    class a extends Handler {
        a() {
        }

        /* JADX WARN: Code duplicated, block: B:16:0x005e  */
        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            int i3 = 0;
            if (i2 != 1) {
                if (i2 != 2) {
                    return;
                }
                while (i3 < b.this.b.size()) {
                    SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray = b.this.b;
                    sparseArray.get(sparseArray.keyAt(i3)).b();
                    i3++;
                }
                return;
            }
            while (i3 < b.this.b.size()) {
                SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray2 = b.this.b;
                if (sparseArray2.get(sparseArray2.keyAt(i3)).getTypeFb() != 101) {
                    SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray3 = b.this.b;
                    if (sparseArray3.get(sparseArray3.keyAt(i3)).getTypeFb() == 102) {
                        SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray4 = b.this.b;
                        ((View) sparseArray4.get(sparseArray4.keyAt(i3))).invalidate();
                    }
                } else {
                    SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray5 = b.this.b;
                    ((View) sparseArray5.get(sparseArray5.keyAt(i3))).invalidate();
                }
                i3++;
            }
            mbCanvas.f1.invalidate();
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Logic.b$b, reason: collision with other inner class name */
    class C0288b extends Thread {
        boolean a = true;
        Handler b;

        public C0288b(Handler handler) {
            this.b = handler;
        }

        public void a() {
            this.a = false;
            b.this.f8957h = 0;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            while (this.a) {
                try {
                    Thread.sleep(1L);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
                for (int i2 = 0; i2 < b.this.c.size() && this.a; i2++) {
                    b.this.c.get(i2).f();
                }
            }
            this.b.obtainMessage(2).sendToTarget();
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x009a  */
    /* JADX WARN: Code duplicated, block: B:222:0x054e  */
    /* JADX WARN: Code duplicated, block: B:236:0x055e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:23:0x00ae  */
    /* JADX WARN: Code duplicated, block: B:25:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:282:0x054a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:283:0x0508 A[SYNTHETIC] */
    public void a() {
        ru.himik.nightscream.kascada.Logic.c.a aVar;
        ru.himik.nightscream.kascada.Logic.c.a aVarL;
        ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList;
        ArrayList<d> arrayList2;
        d dVar;
        ArrayList<d> arrayList3;
        d dVar2;
        ArrayList<d> arrayList4;
        d dVar3;
        SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray = MyApplication.b().D;
        this.b = sparseArray;
        if (sparseArray.size() == 0) {
            return;
        }
        for (int i2 = 0; i2 < this.b.size(); i2++) {
            for (int size = this.f8953d.size() - 1; size >= 0; size--) {
                this.c.add(this.f8953d.get(size));
            }
            this.f8953d.clear();
            SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray2 = this.b;
            if (sparseArray2.get(sparseArray2.keyAt(i2)).getTypeFb() != 102) {
                SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray3 = this.b;
                if (sparseArray3.get(sparseArray3.keyAt(i2)).getTypeFb() != 106) {
                    SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray4 = this.b;
                    if (sparseArray4.get(sparseArray4.keyAt(i2)).getTypeFb() != 109) {
                        SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray5 = this.b;
                        if (sparseArray5.get(sparseArray5.keyAt(i2)).getTypeFb() != 134) {
                            SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray6 = this.b;
                            if (sparseArray6.get(sparseArray6.keyAt(i2)).getTypeFb() == 140) {
                                SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray7 = this.b;
                                aVar = sparseArray7.get(sparseArray7.keyAt(i2));
                                this.f8958i = aVar;
                                if (aVar.l(1) != null) {
                                    if (this.f8958i.l(1).getTypeFb() != 101 || this.f8958i.l(1).getTypeFb() == 105 || this.f8958i.l(1).getTypeFb() == 108 || this.f8958i.l(1).getTypeFb() == 133) {
                                        this.f8953d.add(this.f8958i);
                                        this.f8955f = this.f8953d.size() - 1;
                                    } else {
                                        this.f8953d.add(this.f8958i);
                                        this.f8955f = this.f8953d.size() - 1;
                                        this.f8953d.add(this.f8958i.l(1));
                                        this.f8955f = this.f8953d.size() - 1;
                                        this.f8956g = false;
                                        while (!this.f8956g) {
                                            this.f8957h++;
                                            ru.himik.nightscream.kascada.Logic.c.a aVar2 = this.f8953d.get(this.f8955f);
                                            this.f8959j = aVar2;
                                            int countIn = aVar2.getCountIn();
                                            if (countIn != 1) {
                                                if (countIn != 2) {
                                                    if (countIn != 3) {
                                                        if (countIn == 4) {
                                                            if (this.f8959j.l(1) != null && this.f8959j.l(2) != null && this.f8959j.l(3) != null && this.f8959j.l(4) != null) {
                                                                if (this.f8959j.l(1).h() && this.f8959j.l(2).h() && this.f8959j.l(3).h() && this.f8959j.l(4).h()) {
                                                                    this.f8954e.add(new d(this.f8955f, 2));
                                                                    this.f8954e.add(new d(this.f8955f, 3));
                                                                    arrayList4 = this.f8954e;
                                                                    dVar3 = new d(this.f8955f, 4);
                                                                } else {
                                                                    if (this.f8959j.l(1).h() && this.f8959j.l(2).h()) {
                                                                        arrayList2 = this.f8954e;
                                                                        dVar = new d(this.f8955f, 2);
                                                                        arrayList2.add(dVar);
                                                                    } else if (this.f8959j.l(1).h() && this.f8959j.l(3).h()) {
                                                                        arrayList4 = this.f8954e;
                                                                        dVar3 = new d(this.f8955f, 3);
                                                                    } else if (this.f8959j.l(1).h() && this.f8959j.l(4).h()) {
                                                                        arrayList4 = this.f8954e;
                                                                        dVar3 = new d(this.f8955f, 4);
                                                                    } else {
                                                                        if (this.f8959j.l(2).h() && this.f8959j.l(3).h()) {
                                                                            arrayList3 = this.f8954e;
                                                                            dVar2 = new d(this.f8955f, 3);
                                                                            arrayList3.add(dVar2);
                                                                        } else if (this.f8959j.l(2).h() && this.f8959j.l(4).h()) {
                                                                            this.f8954e.add(new d(this.f8955f, 4));
                                                                        } else {
                                                                            if (this.f8959j.l(3).h() && this.f8959j.l(4).h()) {
                                                                                this.f8954e.add(new d(this.f8955f, 4));
                                                                            } else if (!this.f8959j.l(1).h()) {
                                                                                if (!this.f8959j.l(2).h()) {
                                                                                    if (!this.f8959j.l(3).h()) {
                                                                                        if (this.f8959j.l(4).h()) {
                                                                                            arrayList = this.f8953d;
                                                                                            aVarL = this.f8959j.l(4);
                                                                                            arrayList.add(aVarL);
                                                                                            this.f8955f = this.f8953d.size() - 1;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                            arrayList = this.f8953d;
                                                                            aVarL = this.f8959j.l(3);
                                                                            arrayList.add(aVarL);
                                                                            this.f8955f = this.f8953d.size() - 1;
                                                                        }
                                                                        arrayList = this.f8953d;
                                                                        aVarL = this.f8959j.l(2);
                                                                        arrayList.add(aVarL);
                                                                        this.f8955f = this.f8953d.size() - 1;
                                                                    }
                                                                    arrayList = this.f8953d;
                                                                    aVarL = this.f8959j.l(1);
                                                                    arrayList.add(aVarL);
                                                                    this.f8955f = this.f8953d.size() - 1;
                                                                }
                                                                arrayList4.add(dVar3);
                                                                arrayList = this.f8953d;
                                                                aVarL = this.f8959j.l(1);
                                                                arrayList.add(aVarL);
                                                                this.f8955f = this.f8953d.size() - 1;
                                                            } else if (this.f8959j.l(1) != null && this.f8959j.l(1).h()) {
                                                                arrayList = this.f8953d;
                                                                aVarL = this.f8959j.l(1);
                                                                arrayList.add(aVarL);
                                                                this.f8955f = this.f8953d.size() - 1;
                                                            } else if (this.f8959j.l(2) != null && this.f8959j.l(2).h()) {
                                                                arrayList = this.f8953d;
                                                                aVarL = this.f8959j.l(2);
                                                                arrayList.add(aVarL);
                                                                this.f8955f = this.f8953d.size() - 1;
                                                            } else if (this.f8959j.l(3) != null && this.f8959j.l(3).h()) {
                                                                arrayList = this.f8953d;
                                                                aVarL = this.f8959j.l(3);
                                                                arrayList.add(aVarL);
                                                                this.f8955f = this.f8953d.size() - 1;
                                                            } else if (this.f8959j.l(4) != null && this.f8959j.l(4).h()) {
                                                                arrayList = this.f8953d;
                                                                aVarL = this.f8959j.l(4);
                                                                arrayList.add(aVarL);
                                                                this.f8955f = this.f8953d.size() - 1;
                                                            }
                                                        }
                                                        if (this.f8954e.size() > 0) {
                                                            ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList5 = this.f8953d;
                                                            ArrayList<d> arrayList6 = this.f8954e;
                                                            ru.himik.nightscream.kascada.Logic.c.a aVar3 = arrayList5.get(arrayList6.get(arrayList6.size() - 1).a);
                                                            ArrayList<d> arrayList7 = this.f8954e;
                                                            arrayList5.add(aVar3.l(arrayList7.get(arrayList7.size() - 1).b));
                                                            this.f8955f = this.f8953d.size() - 1;
                                                            ArrayList<d> arrayList8 = this.f8954e;
                                                            arrayList8.remove(arrayList8.size() - 1);
                                                        } else {
                                                            this.f8956g = true;
                                                        }
                                                    } else if (this.f8959j.l(1) != null && this.f8959j.l(2) != null && this.f8959j.l(3) != null) {
                                                        if (this.f8959j.l(1).h() && this.f8959j.l(2).h() && this.f8959j.l(3).h()) {
                                                            this.f8954e.add(new d(this.f8955f, 2));
                                                            arrayList4 = this.f8954e;
                                                            dVar3 = new d(this.f8955f, 3);
                                                        } else {
                                                            if (this.f8959j.l(1).h() && this.f8959j.l(2).h()) {
                                                                arrayList2 = this.f8954e;
                                                                dVar = new d(this.f8955f, 2);
                                                                arrayList2.add(dVar);
                                                            } else if (this.f8959j.l(1).h() && this.f8959j.l(3).h()) {
                                                                arrayList4 = this.f8954e;
                                                                dVar3 = new d(this.f8955f, 3);
                                                            } else {
                                                                if (this.f8959j.l(2).h() && this.f8959j.l(3).h()) {
                                                                    arrayList3 = this.f8954e;
                                                                    dVar2 = new d(this.f8955f, 3);
                                                                    arrayList3.add(dVar2);
                                                                } else if (!this.f8959j.l(1).h()) {
                                                                    if (!this.f8959j.l(2).h()) {
                                                                        if (this.f8959j.l(3).h()) {
                                                                            arrayList = this.f8953d;
                                                                            aVarL = this.f8959j.l(3);
                                                                            arrayList.add(aVarL);
                                                                            this.f8955f = this.f8953d.size() - 1;
                                                                        } else if (this.f8954e.size() > 0) {
                                                                            ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList9 = this.f8953d;
                                                                            ArrayList<d> arrayList10 = this.f8954e;
                                                                            ru.himik.nightscream.kascada.Logic.c.a aVar4 = arrayList9.get(arrayList10.get(arrayList10.size() - 1).a);
                                                                            ArrayList<d> arrayList11 = this.f8954e;
                                                                            arrayList9.add(aVar4.l(arrayList11.get(arrayList11.size() - 1).b));
                                                                            this.f8955f = this.f8953d.size() - 1;
                                                                            ArrayList<d> arrayList12 = this.f8954e;
                                                                            arrayList12.remove(arrayList12.size() - 1);
                                                                        } else {
                                                                            this.f8956g = true;
                                                                        }
                                                                    }
                                                                }
                                                                arrayList = this.f8953d;
                                                                aVarL = this.f8959j.l(2);
                                                                arrayList.add(aVarL);
                                                                this.f8955f = this.f8953d.size() - 1;
                                                            }
                                                            arrayList = this.f8953d;
                                                            aVarL = this.f8959j.l(1);
                                                            arrayList.add(aVarL);
                                                            this.f8955f = this.f8953d.size() - 1;
                                                        }
                                                        arrayList4.add(dVar3);
                                                        arrayList = this.f8953d;
                                                        aVarL = this.f8959j.l(1);
                                                        arrayList.add(aVarL);
                                                        this.f8955f = this.f8953d.size() - 1;
                                                    } else if (this.f8959j.l(1) != null && this.f8959j.l(1).h()) {
                                                        arrayList = this.f8953d;
                                                        aVarL = this.f8959j.l(1);
                                                        arrayList.add(aVarL);
                                                        this.f8955f = this.f8953d.size() - 1;
                                                    } else if (this.f8959j.l(2) != null && this.f8959j.l(2).h()) {
                                                        arrayList = this.f8953d;
                                                        aVarL = this.f8959j.l(2);
                                                        arrayList.add(aVarL);
                                                        this.f8955f = this.f8953d.size() - 1;
                                                    } else if (this.f8959j.l(3) != null && this.f8959j.l(3).h()) {
                                                        arrayList = this.f8953d;
                                                        aVarL = this.f8959j.l(3);
                                                        arrayList.add(aVarL);
                                                        this.f8955f = this.f8953d.size() - 1;
                                                    } else if (this.f8954e.size() > 0) {
                                                        ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList13 = this.f8953d;
                                                        ArrayList<d> arrayList14 = this.f8954e;
                                                        ru.himik.nightscream.kascada.Logic.c.a aVar5 = arrayList13.get(arrayList14.get(arrayList14.size() - 1).a);
                                                        ArrayList<d> arrayList15 = this.f8954e;
                                                        arrayList13.add(aVar5.l(arrayList15.get(arrayList15.size() - 1).b));
                                                        this.f8955f = this.f8953d.size() - 1;
                                                        ArrayList<d> arrayList16 = this.f8954e;
                                                        arrayList16.remove(arrayList16.size() - 1);
                                                    } else {
                                                        this.f8956g = true;
                                                    }
                                                } else if (this.f8959j.l(1) != null && this.f8959j.l(2) != null) {
                                                    if (this.f8959j.l(1).h() && this.f8959j.l(2).h()) {
                                                        arrayList2 = this.f8954e;
                                                        dVar = new d(this.f8955f, 2);
                                                        arrayList2.add(dVar);
                                                    } else if (!this.f8959j.l(1).h()) {
                                                        if (this.f8959j.l(2).h()) {
                                                            arrayList = this.f8953d;
                                                            aVarL = this.f8959j.l(2);
                                                            arrayList.add(aVarL);
                                                            this.f8955f = this.f8953d.size() - 1;
                                                        } else if (this.f8954e.size() > 0) {
                                                            ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList17 = this.f8953d;
                                                            ArrayList<d> arrayList18 = this.f8954e;
                                                            ru.himik.nightscream.kascada.Logic.c.a aVar6 = arrayList17.get(arrayList18.get(arrayList18.size() - 1).a);
                                                            ArrayList<d> arrayList19 = this.f8954e;
                                                            arrayList17.add(aVar6.l(arrayList19.get(arrayList19.size() - 1).b));
                                                            this.f8955f = this.f8953d.size() - 1;
                                                            ArrayList<d> arrayList110 = this.f8954e;
                                                            arrayList110.remove(arrayList110.size() - 1);
                                                        } else {
                                                            this.f8956g = true;
                                                        }
                                                    }
                                                    arrayList = this.f8953d;
                                                    aVarL = this.f8959j.l(1);
                                                    arrayList.add(aVarL);
                                                    this.f8955f = this.f8953d.size() - 1;
                                                } else if (this.f8959j.l(1) != null && this.f8959j.l(1).h()) {
                                                    arrayList = this.f8953d;
                                                    aVarL = this.f8959j.l(1);
                                                    arrayList.add(aVarL);
                                                    this.f8955f = this.f8953d.size() - 1;
                                                } else if (this.f8959j.l(2) != null && this.f8959j.l(2).h()) {
                                                    arrayList = this.f8953d;
                                                    aVarL = this.f8959j.l(2);
                                                    arrayList.add(aVarL);
                                                    this.f8955f = this.f8953d.size() - 1;
                                                } else if (this.f8954e.size() > 0) {
                                                    ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList111 = this.f8953d;
                                                    ArrayList<d> arrayList112 = this.f8954e;
                                                    ru.himik.nightscream.kascada.Logic.c.a aVar7 = arrayList111.get(arrayList112.get(arrayList112.size() - 1).a);
                                                    ArrayList<d> arrayList113 = this.f8954e;
                                                    arrayList111.add(aVar7.l(arrayList113.get(arrayList113.size() - 1).b));
                                                    this.f8955f = this.f8953d.size() - 1;
                                                    ArrayList<d> arrayList114 = this.f8954e;
                                                    arrayList114.remove(arrayList114.size() - 1);
                                                } else {
                                                    this.f8956g = true;
                                                }
                                            } else if (this.f8959j.l(1) != null && this.f8959j.l(1).h()) {
                                                arrayList = this.f8953d;
                                                aVarL = this.f8959j.l(1);
                                                arrayList.add(aVarL);
                                                this.f8955f = this.f8953d.size() - 1;
                                            } else if (this.f8954e.size() > 0) {
                                                ArrayList<ru.himik.nightscream.kascada.Logic.c.a> arrayList115 = this.f8953d;
                                                ArrayList<d> arrayList116 = this.f8954e;
                                                ru.himik.nightscream.kascada.Logic.c.a aVar8 = arrayList115.get(arrayList116.get(arrayList116.size() - 1).a);
                                                ArrayList<d> arrayList117 = this.f8954e;
                                                arrayList115.add(aVar8.l(arrayList117.get(arrayList117.size() - 1).b));
                                                this.f8955f = this.f8953d.size() - 1;
                                                ArrayList<d> arrayList118 = this.f8954e;
                                                arrayList118.remove(arrayList118.size() - 1);
                                            } else {
                                                this.f8956g = true;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray8 = this.b;
                            aVar = sparseArray8.get(sparseArray8.keyAt(i2));
                            this.f8958i = aVar;
                            if (aVar.l(1) != null) {
                                if (this.f8958i.l(1).getTypeFb() != 101) {
                                    this.f8953d.add(this.f8958i);
                                    this.f8955f = this.f8953d.size() - 1;
                                } else {
                                    this.f8953d.add(this.f8958i);
                                    this.f8955f = this.f8953d.size() - 1;
                                }
                            }
                        }
                    } else {
                        SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray9 = this.b;
                        aVar = sparseArray9.get(sparseArray9.keyAt(i2));
                        this.f8958i = aVar;
                        if (aVar.l(1) != null) {
                            if (this.f8958i.l(1).getTypeFb() != 101) {
                                this.f8953d.add(this.f8958i);
                                this.f8955f = this.f8953d.size() - 1;
                            } else {
                                this.f8953d.add(this.f8958i);
                                this.f8955f = this.f8953d.size() - 1;
                            }
                        }
                    }
                } else {
                    SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray10 = this.b;
                    aVar = sparseArray10.get(sparseArray10.keyAt(i2));
                    this.f8958i = aVar;
                    if (aVar.l(1) != null) {
                        if (this.f8958i.l(1).getTypeFb() != 101) {
                            this.f8953d.add(this.f8958i);
                            this.f8955f = this.f8953d.size() - 1;
                        } else {
                            this.f8953d.add(this.f8958i);
                            this.f8955f = this.f8953d.size() - 1;
                        }
                    }
                }
            } else {
                SparseArray<ru.himik.nightscream.kascada.Logic.c.a> sparseArray11 = this.b;
                aVar = sparseArray11.get(sparseArray11.keyAt(i2));
                this.f8958i = aVar;
                if (aVar.l(1) != null) {
                    if (this.f8958i.l(1).getTypeFb() != 101) {
                        this.f8953d.add(this.f8958i);
                        this.f8955f = this.f8953d.size() - 1;
                    } else {
                        this.f8953d.add(this.f8958i);
                        this.f8955f = this.f8953d.size() - 1;
                    }
                }
            }
        }
        for (int size2 = this.f8953d.size() - 1; size2 >= 0; size2--) {
            this.c.add(this.f8953d.get(size2));
        }
        this.f8953d.clear();
        for (int i3 = 0; i3 < this.c.size(); i3++) {
        }
        C0288b c0288b = new C0288b(this.f8960k);
        this.a = c0288b;
        c0288b.start();
    }

    public void b() {
        C0288b c0288b = this.a;
        if (c0288b != null) {
            c0288b.a();
        }
        this.c.clear();
        this.f8954e.clear();
        this.f8955f = 0;
    }
}
