package ru.himik.nightscream.kascada.Connections.Usb.driver;

import android.util.Pair;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class ProbeTable {
    private final Map<Pair<Integer, Integer>, Class<? extends UsbSerialDriver>> mProbeTable = new LinkedHashMap();

    public ProbeTable addDriver(Class<? extends UsbSerialDriver> cls) {
        try {
            try {
                for (Map.Entry entry : ((Map) cls.getMethod("getSupportedDevices", new Class[0]).invoke(null, new Object[0])).entrySet()) {
                    int iIntValue = ((Integer) entry.getKey()).intValue();
                    for (int i2 : (int[]) entry.getValue()) {
                        addProduct(iIntValue, i2, cls);
                    }
                }
                return this;
            } catch (IllegalAccessException e2) {
                throw new RuntimeException(e2);
            } catch (IllegalArgumentException e3) {
                throw new RuntimeException(e3);
            } catch (InvocationTargetException e4) {
                throw new RuntimeException(e4);
            }
        } catch (NoSuchMethodException e5) {
            throw new RuntimeException(e5);
        } catch (SecurityException e6) {
            throw new RuntimeException(e6);
        }
    }

    public ProbeTable addProduct(int i2, int i3, Class<? extends UsbSerialDriver> cls) {
        this.mProbeTable.put(Pair.create(Integer.valueOf(i2), Integer.valueOf(i3)), cls);
        return this;
    }

    public Class<? extends UsbSerialDriver> findDriver(int i2, int i3) {
        return this.mProbeTable.get(Pair.create(Integer.valueOf(i2), Integer.valueOf(i3)));
    }
}
