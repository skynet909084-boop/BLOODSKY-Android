package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class m extends ru.himik.nightscream.kascada.CustomComponents.c0.a implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    public String F0;
    int G0;
    int H0;
    int I0;
    public b J0;
    private boolean K0;
    private boolean L0;
    Bitmap M0;
    Paint N0;
    Paint O0;
    boolean P0;
    int Q0;
    int R0;
    int S0;
    int T0;
    int U0;
    int V0;
    int W0;
    int X0;
    int Y0;
    int Z0;
    int a1;
    int b1;
    int c1;
    private long d1;
    private String e1;
    public Point f1;

    public m(Context context) {
        super(context);
        this.F0 = getResources().getString(R.string.custom_gauge2);
        this.G0 = 24;
        this.J0 = new b();
        this.M0 = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.N0 = new Paint();
        this.O0 = new Paint();
        this.P0 = false;
        this.Q0 = 0;
        this.R0 = 0;
        this.S0 = 0;
        this.T0 = 100;
        this.U0 = -16777216;
        this.V0 = -16777216;
        this.W0 = 6;
        this.X0 = 20;
        this.Y0 = Color.parseColor("#BFBFBF");
        this.Z0 = -16776961;
        this.a1 = -16777216;
        this.b1 = 75;
        this.c1 = 90;
        this.d1 = 0L;
        this.e1 = f.e.a.a.d.a.a.b.NormalIndicator.name();
        this.f1 = new Point();
    }

    public void T(int i2, int i3, int i4, boolean z) {
        try {
            setIndicator(f.e.a.a.d.a.a.b.valueOf(this.e1));
        } catch (Exception unused) {
            setIndicator(f.e.a.a.d.a.a.b.LineIndicator);
        }
        setWithTremble(false);
        setSpeedTextFormat((byte) 0);
        setUnit("");
        setMinSpeed(this.S0);
        setMaxSpeed(this.T0);
        setSpeedTextColor(this.U0);
        setTextColor(this.V0);
        setCountTextScale(this.W0);
        setTextSize(this.X0);
        setCenterCircleColor(this.Y0);
        setIndicatorColor(this.Z0);
        setMarkColor(this.a1);
        U(this.b1, this.c1);
        setTickPadding(10);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_width);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_width);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_width)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_width)) / 2));
        }
        setKey(i4);
        this.J0.L((byte) 3);
    }

    public void U(int i2, int i3) {
        float fAbs;
        if (i2 < i3) {
            try {
                int i4 = this.S0;
                int i5 = this.T0;
                if (i4 >= i5 || i2 <= i4 || i3 >= i5) {
                    return;
                }
                this.b1 = i2;
                this.c1 = i3;
                if (i4 < 0) {
                    float fAbs2 = ((i2 + Math.abs(i4)) / (this.T0 + Math.abs(this.S0))) * 100.0f;
                    fAbs = ((i3 + Math.abs(this.S0)) / (this.T0 + Math.abs(this.S0))) * 100.0f;
                    setLowSpeedPercent((int) fAbs2);
                } else {
                    fAbs = ((i3 - i4) / (i5 - i4)) * 100.0f;
                    setLowSpeedPercent((int) (((i2 - i4) / (i5 - i4)) * 100.0f));
                }
                setMediumSpeedPercent((int) fAbs);
            } catch (Exception unused) {
            }
        }
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f1.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public int getColorCenterCircle() {
        return this.Y0;
    }

    public int getColorIndicator() {
        return this.Z0;
    }

    public int getColorMark() {
        return this.a1;
    }

    public int getColorTextScale() {
        return this.V0;
    }

    public int getColorTextValue() {
        return this.U0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.J0;
    }

    public int getCountTextScale() {
        return this.W0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.G0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.I0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.Q0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.R0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.G0;
    }

    public String getIndicatorName() {
        return this.e1;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.J0.l());
        jSONObject.put("addressRegister", this.J0.c());
        jSONObject.put("typeRequest", (int) this.J0.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("minGauge", getMinGauge());
        jSONObject.put("maxGauge", getMaxGauge());
        jSONObject.put("colorTextValue", getColorTextValue());
        jSONObject.put("colorTextScale", getColorTextScale());
        jSONObject.put("countTextScale", getCountTextScale());
        jSONObject.put("sizeText", getSizeText());
        jSONObject.put("colorCenterCircle", getColorCenterCircle());
        jSONObject.put("colorIndicator", getColorIndicator());
        jSONObject.put("colorMark", getColorMark());
        jSONObject.put("percentLowScale", getPercentLowScale());
        jSONObject.put("percentMediumScale", getPercentMediumScale());
        jSONObject.put("timeZ", getTimeZ());
        jSONObject.put("hideBackground", S());
        jSONObject.put("indicatorName", getIndicatorName());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.H0;
    }

    public int getMaxGauge() {
        return this.T0;
    }

    public int getMinGauge() {
        return this.S0;
    }

    public int getNumScreen() {
        return this.I0;
    }

    public int getPercentLowScale() {
        return this.b1;
    }

    public int getPercentMediumScale() {
        return this.c1;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.f1;
    }

    public int getSizeText() {
        return this.X0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.J0.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.J0.l() >= 100) {
            this.J0.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.J0.c();
        }
        this.J0.u((byte) MyApplication.b().E.get(this.J0.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.J0.b()) + "#" + this.J0.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.J0.l() >= 0) {
            if (this.J0.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.J0.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.d1;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.c0.a, f.e.a.a.c, f.e.a.a.a, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.L0) {
            this.O0.setColor(-65536);
            this.O0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.O0);
        }
        if (this.K0 && mbCanvas.g1) {
            canvas.drawBitmap(this.M0, (getWidth() / 2) - (this.M0.getWidth() / 2), getHeight() - this.M0.getHeight(), this.N0);
        }
        if (this.P0) {
            this.O0.setColor(-16711936);
            this.O0.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.O0);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.P0;
    }

    public void setColorCenterCircle(int i2) {
        this.Y0 = i2;
        setCenterCircleColor(i2);
    }

    public void setColorIndicator(int i2) {
        this.Z0 = i2;
        setIndicatorColor(i2);
    }

    public void setColorMark(int i2) {
        this.a1 = i2;
        setMarkColor(i2);
    }

    public void setColorTextScale(int i2) {
        this.V0 = i2;
        setTextColor(i2);
    }

    public void setColorTextValue(int i2) {
        this.U0 = i2;
        setSpeedTextColor(i2);
    }

    public void setConnectionError(boolean z) {
        this.L0 = z;
    }

    public void setConnectionTimeOut(boolean z) {
        this.K0 = z;
    }

    public void setCountTextScale(int i2) {
        ArrayList arrayList = new ArrayList();
        this.W0 = i2;
        if (i2 == 2 || i2 < 2) {
            arrayList.add(Integer.valueOf(getMinSpeed()));
        } else {
            int i3 = 1;
            if (getMinSpeed() < 0) {
                int iAbs = (Math.abs(getMinSpeed()) + getMaxSpeed()) / i2;
                arrayList.add(Integer.valueOf(getMinSpeed()));
                while (i3 < i2) {
                    arrayList.add(Integer.valueOf((i3 * iAbs) + getMinSpeed()));
                    i3++;
                }
            } else {
                int maxSpeed = (getMaxSpeed() - getMinSpeed()) / i2;
                arrayList.add(Integer.valueOf(getMinSpeed()));
                while (i3 < i2) {
                    arrayList.add(Integer.valueOf((i3 * maxSpeed) + getMinSpeed()));
                    i3++;
                }
            }
        }
        arrayList.add(Integer.valueOf(getMaxSpeed()));
        setTicks(arrayList);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.P0 = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.Q0 = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.R0 = i2;
    }

    public void setFont(String str) {
    }

    public void setIndicatorName(String str) {
        try {
            setIndicator(f.e.a.a.d.a.a.b.valueOf(str));
            this.e1 = str;
        } catch (Exception unused) {
            setIndicator(f.e.a.a.d.a.a.b.NormalIndicator);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.H0 = i2;
    }

    public void setMaxGauge(int i2) {
        this.T0 = i2;
        setMaxSpeed(i2);
    }

    public void setMinGauge(int i2) {
        this.S0 = i2;
        setMinSpeed(i2);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.J0.G(i2);
        this.I0 = i2;
    }

    public void setSizeText(int i2) {
        this.X0 = i2;
        setTextSize(i2);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.d1 = j2;
    }

    public void setValue(int i2) {
        short s = (short) i2;
        if (s < getMinSpeed()) {
            z(getMinSpeed());
        } else if (s > getMaxSpeed()) {
            z(getMaxSpeed());
        } else {
            A(s, 300L);
        }
    }
}
