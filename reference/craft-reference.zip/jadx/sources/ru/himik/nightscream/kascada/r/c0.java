package ru.himik.nightscream.kascada.r;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class c0 extends Dialog {
    public TextView a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c0(Context context) {
        super(context);
        kotlin.b0.d.j.d(context, "context");
        setCancelable(false);
    }

    public final TextView a() {
        TextView textView = this.a;
        if (textView != null) {
            return textView;
        }
        kotlin.b0.d.j.m("title");
        throw null;
    }

    public final void b(TextView textView) {
        kotlin.b0.d.j.d(textView, "<set-?>");
        this.a = textView;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.dialog_load_voice_model);
        View viewFindViewById = findViewById(R.id.title);
        kotlin.b0.d.j.c(viewFindViewById, "findViewById(R.id.title)");
        b((TextView) viewFindViewById);
    }
}
