package ru.himik.nightscream.kascada.CustomComponents;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class CustomLabel extends androidx.appcompat.widget.y implements z, ru.himik.nightscream.kascada.s.a, ru.himik.nightscream.kascada.s.b {
    private long C;
    private RectF D;
    private RectF E;
    private SparseIntArray F;
    private TextPaint G;
    private float H;
    private float I;
    private float J;
    private float K;
    private int L;
    private int M;
    private boolean N;
    private boolean O;
    private final b P;
    public Point Q;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f8673e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8674f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8675g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8676h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    Paint f8677i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    boolean f8678j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f8679k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    int f8680l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    boolean f8681m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    boolean f8682n;
    int o;

    class a implements b {
        a() {
        }

        @Override // ru.himik.nightscream.kascada.CustomComponents.CustomLabel.b
        @TargetApi(16)
        public int a(int i2, RectF rectF) {
            RectF rectF2;
            float fMeasureText;
            CustomLabel.this.G.setTextSize(i2);
            String string = CustomLabel.this.getText().toString();
            if (CustomLabel.this.getMaxLines() == 1) {
                CustomLabel.this.D.bottom = CustomLabel.this.G.getFontSpacing();
                rectF2 = CustomLabel.this.D;
                fMeasureText = CustomLabel.this.G.measureText(string);
            } else {
                StaticLayout staticLayout = new StaticLayout(string, CustomLabel.this.G, CustomLabel.this.L, Layout.Alignment.ALIGN_NORMAL, CustomLabel.this.I, CustomLabel.this.J, true);
                if (CustomLabel.this.getMaxLines() != -1 && staticLayout.getLineCount() > CustomLabel.this.getMaxLines()) {
                    return 1;
                }
                CustomLabel.this.D.bottom = staticLayout.getHeight();
                int lineWidth = -1;
                for (int i3 = 0; i3 < staticLayout.getLineCount(); i3++) {
                    if (lineWidth < staticLayout.getLineWidth(i3)) {
                        lineWidth = (int) staticLayout.getLineWidth(i3);
                    }
                }
                rectF2 = CustomLabel.this.D;
                fMeasureText = lineWidth;
            }
            rectF2.right = fMeasureText;
            CustomLabel.this.D.offsetTo(0.0f, 0.0f);
            return rectF.contains(CustomLabel.this.D) ? -1 : 1;
        }
    }

    private interface b {
        int a(int i2, RectF rectF);
    }

    public CustomLabel(Context context) {
        super(context);
        this.f8673e = getResources().getString(R.string.custom_text);
        this.f8674f = 2;
        this.f8677i = new Paint();
        this.f8678j = false;
        this.f8679k = 0;
        this.f8680l = 0;
        this.f8681m = true;
        this.f8682n = false;
        this.o = 0;
        this.C = 0L;
        this.D = new RectF();
        this.E = new RectF();
        this.F = new SparseIntArray();
        this.G = new TextPaint(getPaint());
        this.H = 500.0f;
        this.I = 1.0f;
        this.J = 0.0f;
        this.K = getResources().getDimension(R.dimen.text_size);
        this.N = true;
        this.P = new a();
        this.Q = new Point();
        if (this.f8681m) {
            l();
        }
    }

    public CustomLabel(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f8673e = getResources().getString(R.string.custom_text);
        this.f8674f = 2;
        this.f8677i = new Paint();
        this.f8678j = false;
        this.f8679k = 0;
        this.f8680l = 0;
        this.f8681m = true;
        this.f8682n = false;
        this.o = 0;
        this.C = 0L;
        this.D = new RectF();
        this.E = new RectF();
        this.F = new SparseIntArray();
        this.G = new TextPaint(getPaint());
        this.H = 500.0f;
        this.I = 1.0f;
        this.J = 0.0f;
        this.K = getResources().getDimension(R.dimen.text_size);
        this.N = true;
        this.P = new a();
        this.Q = new Point();
        if (this.f8681m) {
            l();
        }
    }

    private void l() {
        if (this.O) {
            int i2 = (int) this.K;
            int measuredHeight = (getMeasuredHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop();
            int measuredWidth = (getMeasuredWidth() - getCompoundPaddingLeft()) - getCompoundPaddingRight();
            this.L = measuredWidth;
            RectF rectF = this.E;
            rectF.right = measuredWidth;
            rectF.bottom = measuredHeight;
            super.setTextSize(0, this.f8681m ? n(i2, (int) this.H, this.P, rectF) : this.H);
        }
    }

    private static int m(int i2, int i3, b bVar, RectF rectF) {
        int i4 = i3 - 1;
        int i5 = i2;
        while (i2 <= i4) {
            i5 = (i2 + i4) >>> 1;
            int iA = bVar.a(i5, rectF);
            if (iA >= 0) {
                if (iA <= 0) {
                    break;
                }
                i5--;
                i4 = i5;
            } else {
                int i6 = i5 + 1;
                i5 = i2;
                i2 = i6;
            }
        }
        return i5;
    }

    private int n(int i2, int i3, b bVar, RectF rectF) {
        if (!this.N) {
            return m(i2, i3, bVar, rectF);
        }
        int length = getText().toString().length();
        int i4 = this.F.get(length);
        if (i4 != 0) {
            return i4;
        }
        int iM = m(i2, i3, bVar, rectF);
        this.F.put(length, iM);
        return iM;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.Q.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public void f(int i2) {
        setText(this.f8673e + " " + i2);
    }

    public int getBackgroundColor_() {
        return this.o;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        if (r()) {
            return 0;
        }
        return ((ColorDrawable) getBackground()).getColor();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8674f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8676h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return getText().toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.f8679k;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.f8680l;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8674f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("autoResizeText", q());
        jSONObject.put("enableFrameLabel", r());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8675g;
    }

    @Override // android.widget.TextView
    public int getMaxLines() {
        return this.M;
    }

    public int getNumScreen() {
        return this.f8676h;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.Q;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.C;
    }

    public void o(int i2, int i3, int i4, boolean z) {
        setTextColor(-1);
        if (!z) {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_width));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
            f(i4);
            setBackgroundColor(0);
        }
        setKey(i4);
        setGravity(17);
        if (this.M == 0) {
            this.M = -1;
        }
        this.K = getResources().getDimension(R.dimen.text_size_small);
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8678j) {
            this.f8677i.setColor(-16711936);
            this.f8677i.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.f8677i);
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        this.O = true;
        this.F.clear();
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        l();
    }

    @Override // androidx.appcompat.widget.y, android.widget.TextView
    protected void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        l();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.f8678j;
    }

    public boolean q() {
        return this.f8681m;
    }

    public boolean r() {
        return this.f8682n;
    }

    public void setAutoResizeText(boolean z) {
        this.f8681m = z;
        if (z) {
            this.H = 500.0f;
        }
    }

    public void setBackgroundColor_(int i2) {
        this.o = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.f8678j = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.f8679k = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.f8680l = i2;
    }

    public void setEnableFrameLabel(boolean z) {
        this.f8682n = z;
        if (!z) {
            setBackgroundColor(this.o);
            return;
        }
        int i2 = Build.VERSION.SDK_INT;
        Drawable drawable = i2 >= 21 ? getResources().getDrawable(R.drawable.bg_text, null) : getResources().getDrawable(R.drawable.bg_text);
        if (i2 < 16) {
            setBackgroundDrawable(drawable);
        } else {
            setBackground(drawable);
        }
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8675g = i2;
    }

    @Override // android.widget.TextView
    public void setLineSpacing(float f2, float f3) {
        super.setLineSpacing(f2, f3);
        this.I = f3;
        this.J = f2;
    }

    @Override // android.widget.TextView
    public void setLines(int i2) {
        super.setLines(i2);
        this.M = i2;
        l();
    }

    @Override // android.widget.TextView
    public void setMaxLines(int i2) {
        super.setMaxLines(i2);
        this.M = i2;
        l();
    }

    public void setMinTextSize(float f2) {
        this.K = f2;
        l();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8676h = i2;
    }

    @Override // android.widget.TextView
    public void setSingleLine() {
        super.setSingleLine();
        this.M = 1;
        l();
    }

    @Override // android.widget.TextView
    public void setSingleLine(boolean z) {
        super.setSingleLine(z);
        this.M = z ? 1 : -1;
        l();
    }

    @Override // android.widget.TextView
    public void setTextSize(float f2) {
        this.H = f2;
        this.F.clear();
        l();
    }

    @Override // androidx.appcompat.widget.y, android.widget.TextView
    public void setTextSize(int i2, float f2) {
        Context context = getContext();
        this.H = TypedValue.applyDimension(i2, f2, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        this.F.clear();
        l();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.C = j2;
    }
}
