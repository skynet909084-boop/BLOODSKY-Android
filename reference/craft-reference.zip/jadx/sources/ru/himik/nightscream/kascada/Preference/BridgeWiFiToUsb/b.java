package ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Handler;
import android.widget.Toast;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import ru.himik.nightscream.kascada.Connections.Usb.driver.CdcAcmSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.Ch34xSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.Cp21xxSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.FtdiSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.ProbeTable;
import ru.himik.nightscream.kascada.Connections.Usb.driver.ProlificSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbId;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialDriver;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialPort;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbSerialProber;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class b extends Thread {
    Handler a;
    int c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f9071d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f9072e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f9073f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    UsbManager f9075h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    Context f9076i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    UsbSerialPort f9077j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    UsbDevice f9078k;
    ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a o;
    boolean b = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    byte f9074g = 0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    long f9079l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    byte[] f9080m = new byte[512];

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f9081n = 1000;
    final BroadcastReceiver C = new a();

    class a extends BroadcastReceiver {
        a() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if ("com.android.example.USB_PERMISSION".equals(intent.getAction())) {
                synchronized (this) {
                    UsbDevice usbDevice = (UsbDevice) intent.getParcelableExtra("device");
                    if (!intent.getBooleanExtra("permission", false)) {
                        Toast.makeText(context, context.getResources().getString(R.string.access_is_denied_for_usb), 1).show();
                    } else if (usbDevice != null) {
                        b.this.f9074g = (byte) 2;
                    }
                }
            }
        }
    }

    public b(Context context, Handler handler, int i2, int i3, int i4, int i5, int i6) {
        this.c = 9600;
        this.f9071d = 8;
        this.f9072e = 2;
        this.f9073f = 0;
        String str = i6 + " ";
        this.a = handler;
        this.c = i2;
        this.f9071d = i3;
        this.f9072e = i4;
        this.f9073f = i5;
        this.f9076i = context;
        this.f9075h = (UsbManager) context.getSystemService("usb");
        start();
    }

    public void a(ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a aVar) {
        this.o = aVar;
    }

    public void b() {
        this.b = false;
        try {
            this.f9077j.purgeHwBuffers(true, true);
            this.f9077j.close();
        } catch (Exception unused) {
        }
    }

    public void c(byte[] bArr) {
        if (this.f9074g == 4) {
            try {
                this.f9077j.write(bArr, 100);
            } catch (Exception unused) {
                this.f9074g = (byte) 5;
            }
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        while (true) {
            boolean z = this.b;
            if (!z) {
                break;
            }
            byte b = this.f9074g;
            if (b == 0) {
                ProbeTable probeTable = new ProbeTable();
                probeTable.addProduct(5461, 22, CdcAcmSerialDriver.class);
                probeTable.addProduct(UsbId.VENDOR_QINHENG, UsbId.QINHENG_HL340, Ch34xSerialDriver.class);
                UsbSerialProber usbSerialProber = new UsbSerialProber(probeTable);
                probeTable.addDriver(CdcAcmSerialDriver.class);
                probeTable.addDriver(Cp21xxSerialDriver.class);
                probeTable.addDriver(FtdiSerialDriver.class);
                probeTable.addDriver(ProlificSerialDriver.class);
                probeTable.addDriver(Ch34xSerialDriver.class);
                List<UsbSerialDriver> listFindAllDrivers = usbSerialProber.findAllDrivers(this.f9075h);
                ArrayList arrayList = new ArrayList();
                Iterator<UsbSerialDriver> it = listFindAllDrivers.iterator();
                while (it.hasNext()) {
                    arrayList.addAll(it.next().getPorts());
                }
                if (arrayList.size() == 0) {
                    this.f9074g = (byte) 5;
                } else {
                    UsbSerialPort usbSerialPort = (UsbSerialPort) arrayList.get(0);
                    this.f9077j = usbSerialPort;
                    this.f9078k = usbSerialPort.getDriver().getDevice();
                    PendingIntent broadcast = PendingIntent.getBroadcast(this.f9076i, 0, new Intent("com.android.example.USB_PERMISSION"), 0);
                    this.f9076i.registerReceiver(this.C, new IntentFilter("com.android.example.USB_PERMISSION"));
                    this.f9075h.requestPermission(this.f9078k, broadcast);
                    this.f9074g = (byte) 1;
                    this.f9079l = System.currentTimeMillis();
                }
            } else if (b != 1) {
                if (b == 2) {
                    this.a.obtainMessage(2).sendToTarget();
                    if (this.b) {
                        try {
                            this.f9077j.open(this.f9075h.openDevice(this.f9077j.getDriver().getDevice()));
                            this.f9077j.setParameters(this.c, this.f9071d, this.f9072e, this.f9073f);
                        } catch (IOException | Exception unused) {
                            this.f9074g = (byte) 5;
                        }
                        this.f9074g = (byte) 4;
                    }
                } else if (b != 4) {
                    if (b == 5) {
                        this.a.obtainMessage(3).sendToTarget();
                        if (this.b) {
                            try {
                                Thread.sleep(this.f9081n);
                                UsbSerialPort usbSerialPort2 = this.f9077j;
                                if (usbSerialPort2 != null) {
                                    usbSerialPort2.purgeHwBuffers(true, true);
                                    this.f9077j.close();
                                }
                                this.f9074g = (byte) 0;
                            } catch (Exception unused2) {
                                this.f9074g = (byte) 0;
                            }
                        }
                    }
                } else if (z) {
                    try {
                        int i2 = this.f9077j.read(this.f9080m, 100);
                        if (i2 > 0) {
                            byte[] bArr = new byte[i2];
                            System.arraycopy(this.f9080m, 0, bArr, 0, i2);
                            ru.himik.nightscream.kascada.Preference.BridgeWiFiToUsb.a aVar = this.o;
                            if (aVar != null) {
                                aVar.c(bArr);
                            }
                            Thread.sleep(50L);
                        }
                    } catch (Exception unused3) {
                        this.f9074g = (byte) 5;
                    }
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            } else if (z) {
                try {
                    Thread.sleep(500L);
                } catch (InterruptedException e3) {
                    e3.printStackTrace();
                }
                if (System.currentTimeMillis() - this.f9079l > 5000) {
                    this.f9074g = (byte) 0;
                }
            }
        }
        this.a.obtainMessage(3).sendToTarget();
        try {
            UsbSerialPort usbSerialPort3 = this.f9077j;
            if (usbSerialPort3 != null) {
                usbSerialPort3.purgeHwBuffers(true, true);
                this.f9077j.close();
            }
        } catch (Exception unused4) {
        }
        try {
            this.f9076i.unregisterReceiver(this.C);
        } catch (Exception unused5) {
        }
    }
}
