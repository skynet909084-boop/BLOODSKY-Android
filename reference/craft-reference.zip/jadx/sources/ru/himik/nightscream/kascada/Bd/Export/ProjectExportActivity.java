package ru.himik.nightscream.kascada.Bd.Export;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.d;
import androidx.appcompat.widget.Toolbar;
import com.sun.mail.imap.IMAPStore;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Bd.e;
import ru.himik.nightscream.kascada.Bd.g;
import ru.himik.nightscream.kascada.Utils.ShowQrCode;
import ru.himik.nightscream.kascada.Utils.n;
import ru.himik.nightscream.kascada.Utils.q;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class ProjectExportActivity extends d implements InterfaceCallbackExport {
    ru.himik.nightscream.kascada.Bd.d adapter;
    SQLiteDatabase db;
    e dbHelper;
    AlertDialog dialogUploadInWork;
    ListView lvMain;
    ArrayList<g> projectsName = new ArrayList<>();
    boolean mExternalStorageAvailable = false;
    boolean mExternalStorageWritable = false;
    ExportPresenter presenter = new ExportPresenter();
    private final AdapterView.OnItemClickListener mDeviceClickListener = new AdapterView.OnItemClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Export.ProjectExportActivity.2
        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            String string = ((TextView) view.findViewById(R.id.nameProject)).getText().toString();
            Toast.makeText(ProjectExportActivity.this.getApplicationContext(), ProjectExportActivity.this.getResources().getString(R.string.project) + " " + string + " " + ProjectExportActivity.this.getResources().getString(R.string.for_export_selected), 0).show();
            ProjectExportActivity.this.exportProjectToZip(string, false);
        }
    };

    public interface OnClickUploadQr {
        void onClickQR(String str);
    }

    private void copyFile(String str, String str2, String str3) {
        try {
            File file = new File(str3 + str2);
            if (file.exists()) {
                file.delete();
            }
            File file2 = new File(str3);
            if (!file2.exists()) {
                file2.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(str);
            FileOutputStream fileOutputStream = new FileOutputStream(str3 + str2);
            byte[] bArr = new byte[1024];
            while (true) {
                int i2 = fileInputStream.read(bArr);
                if (i2 == -1) {
                    fileInputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
                fileOutputStream.write(bArr, 0, i2);
            }
        } catch (FileNotFoundException | Exception unused) {
        }
    }

    private void copyFilePdf(Uri uri, String str, String str2) {
        try {
            if (new File(str2 + str).exists()) {
                return;
            }
            File file = new File(str2);
            if (!file.exists()) {
                file.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(new File(q.f(getApplicationContext(), uri)));
            FileOutputStream fileOutputStream = new FileOutputStream(str2 + str);
            byte[] bArr = new byte[1024];
            while (true) {
                int i2 = fileInputStream.read(bArr);
                if (i2 == -1) {
                    fileInputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
                fileOutputStream.write(bArr, 0, i2);
            }
        } catch (FileNotFoundException | Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
    public /* synthetic */ void g(String str) {
        exportProjectToZip(str, true);
    }

    boolean checkLicense() {
        Cursor cursorQuery = this.dbHelper.getWritableDatabase().query("Settings", null, null, null, null, null, null);
        return (cursorQuery.moveToFirst() ? cursorQuery.getString(cursorQuery.getColumnIndex(q.b(getResources().getString(R.string.v9), getApplicationContext()))) : "").length() != 0;
    }

    /* JADX WARN: Code duplicated, block: B:126:0x07ab A[Catch: Exception -> 0x07ff, TRY_LEAVE, TryCatch #23 {Exception -> 0x07ff, blocks: (B:102:0x0703, B:126:0x07ab), top: B:297:0x0703 }] */
    /* JADX WARN: Code duplicated, block: B:132:0x0809 A[Catch: Exception -> 0x09b2, TRY_LEAVE, TryCatch #8 {Exception -> 0x09b2, blocks: (B:128:0x07c7, B:132:0x0809, B:147:0x09d1), top: B:267:0x07c7 }] */
    /* JADX WARN: Code duplicated, block: B:144:0x09b5  */
    /* JADX WARN: Code duplicated, block: B:150:0x09e4 A[Catch: Exception -> 0x0a64, TryCatch #12 {Exception -> 0x0a64, blocks: (B:148:0x09dc, B:150:0x09e4, B:151:0x0a0f, B:153:0x0a17), top: B:275:0x09dc }] */
    /* JADX WARN: Code duplicated, block: B:153:0x0a17 A[Catch: Exception -> 0x0a64, TRY_LEAVE, TryCatch #12 {Exception -> 0x0a64, blocks: (B:148:0x09dc, B:150:0x09e4, B:151:0x0a0f, B:153:0x0a17), top: B:275:0x09dc }] */
    /* JADX WARN: Code duplicated, block: B:158:0x0a4b  */
    /* JADX WARN: Code duplicated, block: B:192:0x0b3b A[LOOP:3: B:263:0x0301->B:192:0x0b3b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:193:0x0b4e  */
    /* JADX WARN: Code duplicated, block: B:232:0x0c24  */
    /* JADX WARN: Code duplicated, block: B:236:0x0c32 A[LOOP:2: B:301:0x0bbf->B:236:0x0c32, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:237:0x0c3b  */
    /* JADX WARN: Code duplicated, block: B:246:0x0c6b  */
    /* JADX WARN: Code duplicated, block: B:263:0x0301 A[EXC_TOP_SPLITTER, LOOP:3: B:263:0x0301->B:192:0x0b3b, LOOP_START, PHI: r2 r3 r4 r5 r6 r8 r10 r19 r20 r21 r23 r25 r28 r29
      0x0301: PHI (r2v8 java.lang.String) = (r2v7 java.lang.String), (r2v15 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r3v9 int) = (r3v8 int), (r3v15 int) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r4v9 android.database.Cursor) = (r4v2 android.database.Cursor), (r4v14 android.database.Cursor) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r5v7 org.json.JSONObject) = (r5v6 org.json.JSONObject), (r5v13 org.json.JSONObject) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r6v9 android.database.Cursor) = (r6v8 android.database.Cursor), (r6v15 android.database.Cursor) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r8v4 java.io.File) = (r8v3 java.io.File), (r8v5 java.io.File) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r10v3 java.lang.String) = (r10v2 java.lang.String), (r10v4 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r19v3 java.lang.String) = (r19v0 java.lang.String), (r19v9 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r20v2 java.lang.String) = (r20v1 java.lang.String), (r20v7 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r21v2 org.json.JSONArray) = (r21v1 org.json.JSONArray), (r21v3 org.json.JSONArray) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r23v2 java.lang.String) = (r23v1 java.lang.String), (r23v7 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r25v2 java.lang.String) = (r25v1 java.lang.String), (r25v7 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r28v1 java.lang.String) = (r28v0 java.lang.String), (r28v6 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE]
      0x0301: PHI (r29v1 java.lang.String) = (r29v0 java.lang.String), (r29v6 java.lang.String) binds: [B:50:0x02ff, B:192:0x0b3b] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:289:0x041d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:301:0x0bbf A[EXC_TOP_SPLITTER, LOOP:2: B:301:0x0bbf->B:236:0x0c32, LOOP_START, PHI: r16 r17 r22 r30
      0x0bbf: PHI (r16v1 java.lang.String) = (r16v0 java.lang.String), (r16v2 java.lang.String) binds: [B:207:0x0bbd, B:236:0x0c32] A[DONT_GENERATE, DONT_INLINE]
      0x0bbf: PHI (r17v1 java.lang.String) = (r17v0 java.lang.String), (r17v2 java.lang.String) binds: [B:207:0x0bbd, B:236:0x0c32] A[DONT_GENERATE, DONT_INLINE]
      0x0bbf: PHI (r22v2 org.json.JSONArray) = (r22v1 org.json.JSONArray), (r22v3 org.json.JSONArray) binds: [B:207:0x0bbd, B:236:0x0c32] A[DONT_GENERATE, DONT_INLINE]
      0x0bbf: PHI (r30v34 java.lang.String) = (r30v33 java.lang.String), (r30v35 java.lang.String) binds: [B:207:0x0bbd, B:236:0x0c32] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:311:0x03ab A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:331:0x0b5c A[EDGE_INSN: B:331:0x0b5c->B:194:0x0b5c BREAK  A[LOOP:3: B:263:0x0301->B:192:0x0b3b], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:70:0x03d4 A[Catch: Exception -> 0x0a92, TRY_ENTER, TRY_LEAVE, TryCatch #22 {Exception -> 0x0a92, blocks: (B:63:0x0361, B:70:0x03d4), top: B:295:0x0361 }] */
    /* JADX WARN: Code duplicated, block: B:74:0x03eb  */
    /* JADX WARN: Code duplicated, block: B:76:0x03ee  */
    /* JADX WARN: Code duplicated, block: B:78:0x03f2  */
    /* JADX WARN: Code duplicated, block: B:80:0x03f6  */
    /* JADX WARN: Code duplicated, block: B:82:0x03fa A[Catch: Exception -> 0x0a7f, TRY_LEAVE, TryCatch #26 {Exception -> 0x0a7f, blocks: (B:72:0x03dd, B:82:0x03fa), top: B:303:0x03dd }] */
    /* JADX WARN: Instruction removed from duplicated block: B:150:0x09e4, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:153:0x0a17, please report this as an issue */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    void exportProjectToZip(String str, boolean z) {
        Cursor cursor;
        JSONObject jSONObject;
        JSONObject jSONObject2;
        int i2;
        String str2;
        Cursor cursorQuery;
        String str3;
        Exception exc;
        JSONObject jSONObject3;
        String str4;
        int i3;
        String str5;
        String str6;
        String str7;
        String str8;
        JSONObject jSONObject4;
        String str9;
        JSONObject jSONObject5;
        JSONObject jSONObject6;
        JSONObject jSONObject7;
        Cursor cursor2;
        Cursor cursor3;
        String str10;
        Cursor cursorQuery2;
        String str11;
        JSONArray jSONArray;
        String str12;
        Exception exc2;
        Exception exc3;
        int i4;
        String str13;
        JSONObject jSONObject8;
        String str14 = "createdDate";
        String str15 = "createdTime";
        String str16 = "countScreen";
        String str17 = "stationMode";
        String str18 = "server";
        String str19 = "connectionsId";
        String str20 = "other";
        SQLiteDatabase writableDatabase = this.dbHelper.getWritableDatabase();
        this.db = writableDatabase;
        String str21 = "x";
        StringBuilder sb = new StringBuilder();
        String str22 = "height";
        sb.append("name = '");
        sb.append(str);
        sb.append("'");
        Cursor cursorQuery3 = writableDatabase.query("TableNameProject", null, sb.toString(), null, null, null, null);
        JSONObject jSONObject9 = new JSONObject();
        JSONObject jSONObject10 = new JSONObject();
        String str23 = "width";
        JSONArray jSONArray2 = new JSONArray();
        JSONArray jSONArray3 = new JSONArray();
        String str24 = "text";
        StringBuilder sb2 = new StringBuilder();
        String str25 = "componentId";
        sb2.append(n.a.e());
        sb2.append(str);
        sb2.append("/");
        File file = new File(sb2.toString());
        if (cursorQuery3.moveToFirst()) {
            int count = cursorQuery3.getCount();
            String str26 = IMAPStore.ID_NAME;
            if (count == 1) {
                int i5 = 0;
                while (true) {
                    try {
                        int i6 = cursorQuery3.getInt(cursorQuery3.getColumnIndex("_id"));
                        try {
                            jSONObject10.put("_id", i6);
                            i4 = i6;
                            try {
                                jSONObject10.put(IMAPStore.ID_VERSION, com.karumi.dexter.R.styleable.AppCompatTheme_textAppearanceSmallPopupMenu);
                                jSONObject10.put(IMAPStore.ID_NAME, cursorQuery3.getString(cursorQuery3.getColumnIndex(IMAPStore.ID_NAME)));
                                jSONObject10.put("pass", cursorQuery3.getString(cursorQuery3.getColumnIndex("pass")));
                                jSONObject10.put(str17, cursorQuery3.getString(cursorQuery3.getColumnIndex(str17)));
                                int i7 = Integer.parseInt(cursorQuery3.getString(cursorQuery3.getColumnIndex(str16)));
                                jSONObject10.put(str16, i7);
                                jSONObject10.put(str15, cursorQuery3.getString(cursorQuery3.getColumnIndex(str15)));
                                jSONObject10.put(str14, cursorQuery3.getString(cursorQuery3.getColumnIndex(str14)));
                                String str27 = str14;
                                jSONObject10.put("countDevice", cursorQuery3.getString(cursorQuery3.getColumnIndex("countDevice")));
                                jSONObject10.put("deviceNetwork", cursorQuery3.getString(cursorQuery3.getColumnIndex("deviceNetwork")));
                                jSONObject10.put("systemRegisters", cursorQuery3.getString(cursorQuery3.getColumnIndex("systemRegisters")));
                                jSONObject10.put("modbusSlave", cursorQuery3.getString(cursorQuery3.getColumnIndex("modbusSlave")));
                                jSONObject10.put("settings", cursorQuery3.getString(cursorQuery3.getColumnIndex("settings")));
                                Uri uri = Uri.parse(cursorQuery3.getString(cursorQuery3.getColumnIndex("pdfDocument")));
                                String str28 = str15;
                                StringBuilder sb3 = new StringBuilder();
                                String str29 = str16;
                                sb3.append(file.getPath());
                                sb3.append("/");
                                copyFilePdf(uri, "help.pdf", sb3.toString());
                                jSONObject10.put("pdfDocument", file.getPath() + "/help.pdf");
                                if (!file.exists()) {
                                    try {
                                        file.mkdirs();
                                    } catch (Exception e2) {
                                        exc3 = e2;
                                        jSONObject2 = jSONObject9;
                                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                                        exc3.printStackTrace();
                                    }
                                }
                                if (cursorQuery3.getString(cursorQuery3.getColumnIndex("screenBackground")).length() > 0) {
                                    jSONObject8 = new JSONObject(cursorQuery3.getString(cursorQuery3.getColumnIndex("screenBackground")));
                                    int i8 = 0;
                                    while (i8 < i7) {
                                        StringBuilder sb4 = new StringBuilder();
                                        sb4.append("screen");
                                        i8++;
                                        sb4.append(i8);
                                        sb4.append("IsColor");
                                        if (!jSONObject8.getBoolean(sb4.toString())) {
                                            String string = jSONObject8.getString("screen" + i8 + "PathImage");
                                            String strSubstring = string.substring(string.lastIndexOf("/") + 1);
                                            copyFile(string, strSubstring, file.getPath() + "/");
                                            jSONObject8.put("screen" + i8 + "PathImage", file.getPath() + "/" + strSubstring);
                                        }
                                        i7 = i7;
                                        str17 = str17;
                                    }
                                    str13 = str17;
                                } else {
                                    str13 = str17;
                                    jSONObject8 = new JSONObject("{\"screen1IsColor\":true,\"screen1Color\":15592941,\"screen1PathImage\":\"\"}");
                                }
                                jSONObject10.put("jsTableNameProject_screenBackground", jSONObject8);
                                if (!cursorQuery3.moveToNext()) {
                                    break;
                                }
                                i5 = i4;
                                str14 = str27;
                                str15 = str28;
                                str16 = str29;
                                str17 = str13;
                            } catch (Exception e3) {
                                e = e3;
                                jSONObject2 = jSONObject9;
                                exc3 = e;
                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                                exc3.printStackTrace();
                                i2 = i4;
                                SQLiteDatabase sQLiteDatabase = this.db;
                                StringBuilder sb5 = new StringBuilder();
                                str2 = "pro_";
                                sb5.append("pro_");
                                sb5.append(i2);
                                sb5.append("_component");
                                cursorQuery = sQLiteDatabase.query(sb5.toString(), null, null, null, null, null, null);
                                if (cursorQuery.moveToFirst()) {
                                    while (true) {
                                        try {
                                            jSONObject3 = new JSONObject();
                                            new JSONObject();
                                            new JSONObject();
                                            str4 = str25;
                                            try {
                                                i3 = cursorQuery.getInt(cursorQuery.getColumnIndex(str4));
                                                jSONObject3.put(str4, cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                                                str5 = str24;
                                                try {
                                                    jSONObject3.put(str5, cursorQuery.getString(cursorQuery.getColumnIndex(str5)));
                                                    str6 = str23;
                                                    try {
                                                        jSONObject3.put(str6, cursorQuery.getString(cursorQuery.getColumnIndex(str6)));
                                                        str25 = str4;
                                                        str7 = str22;
                                                        try {
                                                            jSONObject3.put(str7, cursorQuery.getString(cursorQuery.getColumnIndex(str7)));
                                                            str24 = str5;
                                                            str8 = str21;
                                                            try {
                                                                jSONObject3.put(str8, cursorQuery.getString(cursorQuery.getColumnIndex(str8)));
                                                                str21 = str8;
                                                                try {
                                                                    jSONObject3.put("y", cursorQuery.getString(cursorQuery.getColumnIndex("y")));
                                                                    jSONObject3.put("textSize", cursorQuery.getString(cursorQuery.getColumnIndex("textSize")));
                                                                    jSONObject3.put("colorText", cursorQuery.getString(cursorQuery.getColumnIndex("colorText")));
                                                                    jSONObject3.put("colorBackground", cursorQuery.getString(cursorQuery.getColumnIndex("colorBackground")));
                                                                    if (cursorQuery.getString(cursorQuery.getColumnIndex("connectionInfo")).length() > 0) {
                                                                        try {
                                                                            jSONObject4 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex("connectionInfo")));
                                                                        } catch (Exception e4) {
                                                                            str26 = str26;
                                                                            i2 = i2;
                                                                            jSONObject2 = jSONObject2;
                                                                            cursorQuery = cursorQuery;
                                                                            file = file;
                                                                            str2 = str2;
                                                                            str23 = str6;
                                                                            str22 = str7;
                                                                            str3 = str20;
                                                                            exc = e4;
                                                                            cursor = cursorQuery3;
                                                                            jSONArray2 = jSONArray2;
                                                                            Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                            Log.d("NS", "ERROR " + exc.toString());
                                                                            if (!cursorQuery.moveToNext()) {
                                                                                break;
                                                                                jSONObject = jSONObject2;
                                                                                jSONObject.put("TableComponent", jSONArray2);
                                                                                str10 = "kascada";
                                                                                cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                                                                if (cursorQuery2.moveToFirst()) {
                                                                                    while (true) {
                                                                                        try {
                                                                                            JSONObject jSONObject11 = new JSONObject();
                                                                                            str11 = str19;
                                                                                            try {
                                                                                                jSONObject11.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                                                                                str12 = str26;
                                                                                                try {
                                                                                                    jSONObject11.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                                                                                    str18 = str18;
                                                                                                    try {
                                                                                                        jSONObject11.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                                                                                        jSONArray = jSONArray3;
                                                                                                        try {
                                                                                                            jSONArray.put(jSONObject11);
                                                                                                        } catch (Exception e5) {
                                                                                                            e = e5;
                                                                                                            exc2 = e;
                                                                                                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                                                                                                            if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                                Log.d(str10, exc2.toString());
                                                                                                            }
                                                                                                        }
                                                                                                    } catch (Exception e6) {
                                                                                                        e = e6;
                                                                                                        jSONArray = jSONArray3;
                                                                                                        exc2 = e;
                                                                                                        Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                                                                                                        if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                            Log.d(str10, exc2.toString());
                                                                                                        }
                                                                                                        if (cursorQuery2.moveToNext()) {
                                                                                                            break;
                                                                                                        }
                                                                                                        str19 = str11;
                                                                                                        str26 = str12;
                                                                                                        str18 = str18;
                                                                                                        jSONArray3 = jSONArray;
                                                                                                        jSONObject.put("TableConnections", jSONArray);
                                                                                                        if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                            Log.d(str10, jSONObject.toString());
                                                                                                        }
                                                                                                        String str30 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                        writeFileSD(str, jSONObject.toString());
                                                                                                        this.presenter.createZip_(file, str30, z);
                                                                                                        cursor.close();
                                                                                                        this.db.close();
                                                                                                    }
                                                                                                } catch (Exception e7) {
                                                                                                    e = e7;
                                                                                                    str18 = str18;
                                                                                                }
                                                                                            } catch (Exception e8) {
                                                                                                e = e8;
                                                                                                jSONArray = jSONArray3;
                                                                                                str12 = str26;
                                                                                                exc2 = e;
                                                                                                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                    Log.d(str10, exc2.toString());
                                                                                                }
                                                                                                if (cursorQuery2.moveToNext()) {
                                                                                                    break;
                                                                                                }
                                                                                                str19 = str11;
                                                                                                str26 = str12;
                                                                                                str18 = str18;
                                                                                                jSONArray3 = jSONArray;
                                                                                                jSONObject.put("TableConnections", jSONArray);
                                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                    Log.d(str10, jSONObject.toString());
                                                                                                }
                                                                                                String str31 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                writeFileSD(str, jSONObject.toString());
                                                                                                this.presenter.createZip_(file, str31, z);
                                                                                                cursor.close();
                                                                                                this.db.close();
                                                                                            }
                                                                                        } catch (Exception e9) {
                                                                                            e = e9;
                                                                                            str11 = str19;
                                                                                        }
                                                                                        if (cursorQuery2.moveToNext()) {
                                                                                            break;
                                                                                        }
                                                                                        str19 = str11;
                                                                                        str26 = str12;
                                                                                        str18 = str18;
                                                                                        jSONArray3 = jSONArray;
                                                                                    }
                                                                                    jSONObject.put("TableConnections", jSONArray);
                                                                                    if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                        Log.d(str10, jSONObject.toString());
                                                                                    }
                                                                                    String str32 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                    writeFileSD(str, jSONObject.toString());
                                                                                    this.presenter.createZip_(file, str32, z);
                                                                                    cursor.close();
                                                                                    this.db.close();
                                                                                }
                                                                                jSONArray = jSONArray3;
                                                                                jSONObject.put("TableConnections", jSONArray);
                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                    Log.d(str10, jSONObject.toString());
                                                                                }
                                                                                String str33 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                writeFileSD(str, jSONObject.toString());
                                                                                this.presenter.createZip_(file, str33, z);
                                                                                cursor.close();
                                                                                this.db.close();
                                                                            }
                                                                            cursorQuery = cursorQuery;
                                                                            jSONArray2 = jSONArray2;
                                                                            cursorQuery3 = cursor;
                                                                            str26 = str26;
                                                                            jSONObject2 = jSONObject2;
                                                                            str2 = str2;
                                                                            file = file;
                                                                            str20 = str3;
                                                                            i2 = i2;
                                                                        }
                                                                    } else {
                                                                        jSONObject4 = new JSONObject();
                                                                    }
                                                                    str23 = str6;
                                                                    str9 = str20;
                                                                    try {
                                                                        try {
                                                                            try {
                                                                                if (cursorQuery.getString(cursorQuery.getColumnIndex(str9)).length() <= 0) {
                                                                                    if (i3 != 5) {
                                                                                        str26 = str26;
                                                                                        i2 = i2;
                                                                                        cursor = cursorQuery3;
                                                                                        jSONObject2 = jSONObject2;
                                                                                        cursor2 = cursorQuery;
                                                                                        jSONObject5 = jSONObject3;
                                                                                        file = file;
                                                                                        str2 = str2;
                                                                                        jSONObject6 = jSONObject4;
                                                                                        str22 = str7;
                                                                                        try {
                                                                                            cursorQuery = cursor2;
                                                                                            str3 = str9;
                                                                                            jSONObject7 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str3)));
                                                                                            try {
                                                                                                if (jSONObject7.getBoolean("isImageUserOn")) {
                                                                                                    String string2 = jSONObject7.getString("pathOrNameOn");
                                                                                                    String strSubstring2 = string2.substring(string2.lastIndexOf("/") + 1);
                                                                                                    copyFile(string2, strSubstring2, file.getPath() + "/");
                                                                                                    jSONObject7.put("pathOrNameOn", strSubstring2);
                                                                                                }
                                                                                                if (jSONObject7.getBoolean("isImageUserOff")) {
                                                                                                    String string3 = jSONObject7.getString("pathOrNameOff");
                                                                                                    String strSubstring3 = string3.substring(string3.lastIndexOf("/") + 1);
                                                                                                    copyFile(string3, strSubstring3, file.getPath() + "/");
                                                                                                    jSONObject7.put("pathOrNameOff", strSubstring3);
                                                                                                }
                                                                                            } catch (Exception unused) {
                                                                                            }
                                                                                        } catch (Exception e10) {
                                                                                            e = e10;
                                                                                            cursorQuery = cursor2;
                                                                                            str3 = str9;
                                                                                            exc = e;
                                                                                            jSONArray2 = jSONArray2;
                                                                                            Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                            Log.d("NS", "ERROR " + exc.toString());
                                                                                        }
                                                                                    } else if (i3 != 21) {
                                                                                        str26 = str26;
                                                                                        i2 = i2;
                                                                                        cursor = cursorQuery3;
                                                                                        jSONObject2 = jSONObject2;
                                                                                        Cursor cursor4 = cursorQuery;
                                                                                        jSONObject5 = jSONObject3;
                                                                                        file = file;
                                                                                        str2 = str2;
                                                                                        jSONObject6 = jSONObject4;
                                                                                        str3 = str9;
                                                                                        str22 = str7;
                                                                                        JSONObject jSONObject12 = new JSONObject(cursor4.getString(cursor4.getColumnIndex(str3)));
                                                                                        String string4 = jSONObject12.getString("pathSound_0");
                                                                                        String strSubstring4 = string4.substring(string4.lastIndexOf("/") + 1);
                                                                                        String string5 = jSONObject12.getString("pathSound_1");
                                                                                        String strSubstring5 = string5.substring(string5.lastIndexOf("/") + 1);
                                                                                        String string6 = jSONObject12.getString("pathSound_2");
                                                                                        String strSubstring6 = string6.substring(string6.lastIndexOf("/") + 1);
                                                                                        String string7 = jSONObject12.getString("pathSound_3");
                                                                                        String strSubstring7 = string7.substring(string7.lastIndexOf("/") + 1);
                                                                                        String string8 = jSONObject12.getString("pathSound_4");
                                                                                        cursor3 = cursor4;
                                                                                        try {
                                                                                            String strSubstring8 = string8.substring(string8.lastIndexOf("/") + 1);
                                                                                            String string9 = jSONObject12.getString("pathSound_5");
                                                                                            try {
                                                                                                String strSubstring9 = string9.substring(string9.lastIndexOf("/") + 1);
                                                                                                String string10 = jSONObject12.getString("pathSound_6");
                                                                                                String strSubstring10 = string10.substring(string10.lastIndexOf("/") + 1);
                                                                                                String string11 = jSONObject12.getString("pathSound_7");
                                                                                                String strSubstring11 = string11.substring(string11.lastIndexOf("/") + 1);
                                                                                                copyFile(string4, strSubstring4, file.getPath() + "/");
                                                                                                copyFile(string5, strSubstring5, file.getPath() + "/");
                                                                                                copyFile(string6, strSubstring6, file.getPath() + "/");
                                                                                                copyFile(string7, strSubstring7, file.getPath() + "/");
                                                                                                copyFile(string8, strSubstring8, file.getPath() + "/");
                                                                                                copyFile(string9, strSubstring9, file.getPath() + "/");
                                                                                                copyFile(string10, strSubstring10, file.getPath() + "/");
                                                                                                copyFile(string11, strSubstring11, file.getPath() + "/");
                                                                                                jSONObject12.put("pathSound_0", strSubstring4);
                                                                                                jSONObject12.put("pathSound_1", strSubstring5);
                                                                                                jSONObject12.put("pathSound_2", strSubstring6);
                                                                                                jSONObject12.put("pathSound_3", strSubstring7);
                                                                                                jSONObject12.put("pathSound_4", strSubstring8);
                                                                                                jSONObject12.put("pathSound_5", strSubstring9);
                                                                                                jSONObject12.put("pathSound_6", strSubstring10);
                                                                                                jSONObject12.put("pathSound_7", strSubstring11);
                                                                                                jSONObject7 = jSONObject12;
                                                                                                cursorQuery = cursor3;
                                                                                                str3 = str3;
                                                                                            } catch (Exception e11) {
                                                                                                exc = e11;
                                                                                                jSONArray2 = jSONArray2;
                                                                                                cursorQuery = cursor3;
                                                                                                str3 = str3;
                                                                                                Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                                Log.d("NS", "ERROR " + exc.toString());
                                                                                            }
                                                                                        } catch (Exception e12) {
                                                                                            exc = e12;
                                                                                            cursorQuery = cursor3;
                                                                                            Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                            Log.d("NS", "ERROR " + exc.toString());
                                                                                            if (!cursorQuery.moveToNext()) {
                                                                                                break;
                                                                                                jSONObject = jSONObject2;
                                                                                                jSONObject.put("TableComponent", jSONArray2);
                                                                                                str10 = "kascada";
                                                                                                cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                                                                                if (cursorQuery2.moveToFirst()) {
                                                                                                    while (true) {
                                                                                                        JSONObject jSONObject13 = new JSONObject();
                                                                                                        str11 = str19;
                                                                                                        jSONObject13.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                                                                                        str12 = str26;
                                                                                                        jSONObject13.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                                                                                        str18 = str18;
                                                                                                        jSONObject13.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                                                                                        jSONArray = jSONArray3;
                                                                                                        jSONArray.put(jSONObject13);
                                                                                                        if (cursorQuery2.moveToNext()) {
                                                                                                            break;
                                                                                                        }
                                                                                                        str19 = str11;
                                                                                                        str26 = str12;
                                                                                                        str18 = str18;
                                                                                                        jSONArray3 = jSONArray;
                                                                                                    }
                                                                                                    jSONObject.put("TableConnections", jSONArray);
                                                                                                    if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                        Log.d(str10, jSONObject.toString());
                                                                                                    }
                                                                                                    String str34 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                    writeFileSD(str, jSONObject.toString());
                                                                                                    this.presenter.createZip_(file, str34, z);
                                                                                                    cursor.close();
                                                                                                    this.db.close();
                                                                                                }
                                                                                                jSONArray = jSONArray3;
                                                                                                jSONObject.put("TableConnections", jSONArray);
                                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                    Log.d(str10, jSONObject.toString());
                                                                                                }
                                                                                                String str35 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                writeFileSD(str, jSONObject.toString());
                                                                                                this.presenter.createZip_(file, str35, z);
                                                                                                cursor.close();
                                                                                                this.db.close();
                                                                                            }
                                                                                            cursorQuery = cursorQuery;
                                                                                            jSONArray2 = jSONArray2;
                                                                                            cursorQuery3 = cursor;
                                                                                            str26 = str26;
                                                                                            jSONObject2 = jSONObject2;
                                                                                            str2 = str2;
                                                                                            file = file;
                                                                                            str20 = str3;
                                                                                            i2 = i2;
                                                                                        }
                                                                                    } else if (i3 != 16) {
                                                                                        str26 = str26;
                                                                                        i2 = i2;
                                                                                        cursor = cursorQuery3;
                                                                                        jSONObject2 = jSONObject2;
                                                                                        jSONObject5 = jSONObject3;
                                                                                        file = file;
                                                                                        str2 = str2;
                                                                                        jSONObject6 = jSONObject4;
                                                                                        str22 = str7;
                                                                                        str3 = str9;
                                                                                        cursorQuery = cursorQuery;
                                                                                        try {
                                                                                            jSONObject7 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str3)));
                                                                                            String string12 = jSONObject7.getString("pathGif");
                                                                                            String strSubstring12 = string12.substring(string12.lastIndexOf("/") + 1);
                                                                                            copyFile(string12, strSubstring12, file.getPath() + "/");
                                                                                            jSONObject7.put("pathGif", strSubstring12);
                                                                                        } catch (Exception e13) {
                                                                                            e = e13;
                                                                                            exc = e;
                                                                                            jSONArray2 = jSONArray2;
                                                                                            Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                            Log.d("NS", "ERROR " + exc.toString());
                                                                                        }
                                                                                    } else if (i3 != 17) {
                                                                                        jSONObject7 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str9)));
                                                                                        str26 = str26;
                                                                                        i2 = i2;
                                                                                        cursor = cursorQuery3;
                                                                                        jSONObject2 = jSONObject2;
                                                                                        cursorQuery = cursorQuery;
                                                                                        jSONObject5 = jSONObject3;
                                                                                        file = file;
                                                                                        str2 = str2;
                                                                                        jSONObject6 = jSONObject4;
                                                                                        str3 = str9;
                                                                                        str22 = str7;
                                                                                    } else {
                                                                                        try {
                                                                                            JSONObject jSONObject14 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str9)));
                                                                                            String string13 = jSONObject14.getString("pathPic_0");
                                                                                            str22 = str7;
                                                                                            try {
                                                                                                String strSubstring13 = string13.substring(string13.lastIndexOf("/") + 1);
                                                                                                cursor = cursorQuery3;
                                                                                                try {
                                                                                                    String string14 = jSONObject14.getString("pathPic_1");
                                                                                                    str26 = str26;
                                                                                                    try {
                                                                                                        String strSubstring14 = string14.substring(string14.lastIndexOf("/") + 1);
                                                                                                        i2 = i2;
                                                                                                        try {
                                                                                                            String string15 = jSONObject14.getString("pathPic_2");
                                                                                                            str2 = str2;
                                                                                                            try {
                                                                                                                String strSubstring15 = string15.substring(string15.lastIndexOf("/") + 1);
                                                                                                                jSONObject2 = jSONObject2;
                                                                                                                try {
                                                                                                                    String string16 = jSONObject14.getString("pathPic_3");
                                                                                                                    jSONObject5 = jSONObject3;
                                                                                                                    String strSubstring16 = string16.substring(string16.lastIndexOf("/") + 1);
                                                                                                                    jSONObject6 = jSONObject4;
                                                                                                                    String string17 = jSONObject14.getString("pathPic_4");
                                                                                                                    cursor3 = cursorQuery;
                                                                                                                    try {
                                                                                                                        String strSubstring17 = string17.substring(string17.lastIndexOf("/") + 1);
                                                                                                                        try {
                                                                                                                            String string18 = jSONObject14.getString("pathPic_5");
                                                                                                                            String strSubstring18 = string18.substring(string18.lastIndexOf("/") + 1);
                                                                                                                            String string19 = jSONObject14.getString("pathPic_6");
                                                                                                                            String strSubstring19 = string19.substring(string19.lastIndexOf("/") + 1);
                                                                                                                            String string20 = jSONObject14.getString("pathPic_7");
                                                                                                                            String strSubstring20 = string20.substring(string20.lastIndexOf("/") + 1);
                                                                                                                            String string21 = jSONObject14.getString("pathPic_8");
                                                                                                                            String strSubstring21 = string21.substring(string21.lastIndexOf("/") + 1);
                                                                                                                            String string22 = jSONObject14.getString("pathPic_9");
                                                                                                                            String strSubstring22 = string22.substring(string22.lastIndexOf("/") + 1);
                                                                                                                            String string23 = jSONObject14.getString("pathPic_10");
                                                                                                                            String strSubstring23 = string23.substring(string23.lastIndexOf("/") + 1);
                                                                                                                            String string24 = jSONObject14.getString("pathPic_11");
                                                                                                                            String strSubstring24 = string24.substring(string24.lastIndexOf("/") + 1);
                                                                                                                            String string25 = jSONObject14.getString("pathPic_12");
                                                                                                                            String strSubstring25 = string25.substring(string25.lastIndexOf("/") + 1);
                                                                                                                            String string26 = jSONObject14.getString("pathPic_13");
                                                                                                                            String strSubstring26 = string26.substring(string26.lastIndexOf("/") + 1);
                                                                                                                            String string27 = jSONObject14.getString("pathPic_14");
                                                                                                                            String strSubstring27 = string27.substring(string27.lastIndexOf("/") + 1);
                                                                                                                            String string28 = jSONObject14.getString("pathPic_15");
                                                                                                                            String strSubstring28 = string28.substring(string28.lastIndexOf("/") + 1);
                                                                                                                            copyFile(string13, strSubstring13, file.getPath() + "/");
                                                                                                                            copyFile(string14, strSubstring14, file.getPath() + "/");
                                                                                                                            copyFile(string15, strSubstring15, file.getPath() + "/");
                                                                                                                            copyFile(string16, strSubstring16, file.getPath() + "/");
                                                                                                                            copyFile(string17, strSubstring17, file.getPath() + "/");
                                                                                                                            copyFile(string18, strSubstring18, file.getPath() + "/");
                                                                                                                            copyFile(string19, strSubstring19, file.getPath() + "/");
                                                                                                                            copyFile(string20, strSubstring20, file.getPath() + "/");
                                                                                                                            copyFile(string21, strSubstring21, file.getPath() + "/");
                                                                                                                            copyFile(string22, strSubstring22, file.getPath() + "/");
                                                                                                                            copyFile(string23, strSubstring23, file.getPath() + "/");
                                                                                                                            copyFile(string24, strSubstring24, file.getPath() + "/");
                                                                                                                            copyFile(string25, strSubstring25, file.getPath() + "/");
                                                                                                                            copyFile(string26, strSubstring26, file.getPath() + "/");
                                                                                                                            copyFile(string27, strSubstring27, file.getPath() + "/");
                                                                                                                            file = file;
                                                                                                                            try {
                                                                                                                                copyFile(string28, strSubstring28, file.getPath() + "/");
                                                                                                                                jSONObject14.put("pathPic_0", strSubstring13);
                                                                                                                                jSONObject14.put("pathPic_1", strSubstring14);
                                                                                                                                jSONObject14.put("pathPic_2", strSubstring15);
                                                                                                                                jSONObject14.put("pathPic_3", strSubstring16);
                                                                                                                                jSONObject14.put("pathPic_4", strSubstring17);
                                                                                                                                jSONObject14.put("pathPic_5", strSubstring18);
                                                                                                                                jSONObject14.put("pathPic_6", strSubstring19);
                                                                                                                                jSONObject14.put("pathPic_7", strSubstring20);
                                                                                                                                jSONObject14.put("pathPic_8", strSubstring21);
                                                                                                                                jSONObject14.put("pathPic_9", strSubstring22);
                                                                                                                                jSONObject14.put("pathPic_10", strSubstring23);
                                                                                                                                jSONObject14.put("pathPic_11", strSubstring24);
                                                                                                                                jSONObject14.put("pathPic_12", strSubstring25);
                                                                                                                                jSONObject14.put("pathPic_13", strSubstring26);
                                                                                                                                jSONObject14.put("pathPic_14", strSubstring27);
                                                                                                                                jSONObject14.put("pathPic_15", strSubstring28);
                                                                                                                                jSONObject7 = jSONObject14;
                                                                                                                                str3 = str9;
                                                                                                                                cursorQuery = cursor3;
                                                                                                                            } catch (Exception e14) {
                                                                                                                                e = e14;
                                                                                                                                exc = e;
                                                                                                                                str3 = str9;
                                                                                                                                cursorQuery = cursor3;
                                                                                                                                Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                                                                Log.d("NS", "ERROR " + exc.toString());
                                                                                                                            }
                                                                                                                        } catch (Exception e15) {
                                                                                                                            e = e15;
                                                                                                                            file = file;
                                                                                                                        }
                                                                                                                    } catch (Exception e16) {
                                                                                                                        file = file;
                                                                                                                        exc = e16;
                                                                                                                        str3 = str9;
                                                                                                                        cursorQuery = cursor3;
                                                                                                                        Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                                                        Log.d("NS", "ERROR " + exc.toString());
                                                                                                                        if (!cursorQuery.moveToNext()) {
                                                                                                                            break;
                                                                                                                            jSONObject = jSONObject2;
                                                                                                                            jSONObject.put("TableComponent", jSONArray2);
                                                                                                                            str10 = "kascada";
                                                                                                                            cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                                                                                                            if (cursorQuery2.moveToFirst()) {
                                                                                                                                while (true) {
                                                                                                                                    JSONObject jSONObject15 = new JSONObject();
                                                                                                                                    str11 = str19;
                                                                                                                                    jSONObject15.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                                                                                                                    str12 = str26;
                                                                                                                                    jSONObject15.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                                                                                                                    str18 = str18;
                                                                                                                                    jSONObject15.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                                                                                                                    jSONArray = jSONArray3;
                                                                                                                                    jSONArray.put(jSONObject15);
                                                                                                                                    if (cursorQuery2.moveToNext()) {
                                                                                                                                        break;
                                                                                                                                    }
                                                                                                                                    str19 = str11;
                                                                                                                                    str26 = str12;
                                                                                                                                    str18 = str18;
                                                                                                                                    jSONArray3 = jSONArray;
                                                                                                                                }
                                                                                                                                jSONObject.put("TableConnections", jSONArray);
                                                                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                                                    Log.d(str10, jSONObject.toString());
                                                                                                                                }
                                                                                                                                String str36 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                                                writeFileSD(str, jSONObject.toString());
                                                                                                                                this.presenter.createZip_(file, str36, z);
                                                                                                                                cursor.close();
                                                                                                                                this.db.close();
                                                                                                                            }
                                                                                                                            jSONArray = jSONArray3;
                                                                                                                            jSONObject.put("TableConnections", jSONArray);
                                                                                                                            if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                                                Log.d(str10, jSONObject.toString());
                                                                                                                            }
                                                                                                                            String str37 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                                            writeFileSD(str, jSONObject.toString());
                                                                                                                            this.presenter.createZip_(file, str37, z);
                                                                                                                            cursor.close();
                                                                                                                            this.db.close();
                                                                                                                        }
                                                                                                                        cursorQuery = cursorQuery;
                                                                                                                        jSONArray2 = jSONArray2;
                                                                                                                        cursorQuery3 = cursor;
                                                                                                                        str26 = str26;
                                                                                                                        jSONObject2 = jSONObject2;
                                                                                                                        str2 = str2;
                                                                                                                        file = file;
                                                                                                                        str20 = str3;
                                                                                                                        i2 = i2;
                                                                                                                    }
                                                                                                                } catch (Exception e17) {
                                                                                                                    e = e17;
                                                                                                                    exc = e;
                                                                                                                    cursorQuery = cursorQuery;
                                                                                                                    str3 = str9;
                                                                                                                    jSONArray2 = jSONArray2;
                                                                                                                    Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                                                    Log.d("NS", "ERROR " + exc.toString());
                                                                                                                }
                                                                                                            } catch (Exception e18) {
                                                                                                                e = e18;
                                                                                                                jSONObject2 = jSONObject2;
                                                                                                            }
                                                                                                        } catch (Exception e19) {
                                                                                                            e = e19;
                                                                                                            jSONObject2 = jSONObject2;
                                                                                                            str2 = str2;
                                                                                                            exc = e;
                                                                                                            cursorQuery = cursorQuery;
                                                                                                            str3 = str9;
                                                                                                            jSONArray2 = jSONArray2;
                                                                                                            Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                                            Log.d("NS", "ERROR " + exc.toString());
                                                                                                            if (!cursorQuery.moveToNext()) {
                                                                                                                break;
                                                                                                                jSONObject = jSONObject2;
                                                                                                                jSONObject.put("TableComponent", jSONArray2);
                                                                                                                str10 = "kascada";
                                                                                                                cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                                                                                                if (cursorQuery2.moveToFirst()) {
                                                                                                                    while (true) {
                                                                                                                        JSONObject jSONObject16 = new JSONObject();
                                                                                                                        str11 = str19;
                                                                                                                        jSONObject16.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                                                                                                        str12 = str26;
                                                                                                                        jSONObject16.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                                                                                                        str18 = str18;
                                                                                                                        jSONObject16.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                                                                                                        jSONArray = jSONArray3;
                                                                                                                        jSONArray.put(jSONObject16);
                                                                                                                        if (cursorQuery2.moveToNext()) {
                                                                                                                            break;
                                                                                                                        }
                                                                                                                        str19 = str11;
                                                                                                                        str26 = str12;
                                                                                                                        str18 = str18;
                                                                                                                        jSONArray3 = jSONArray;
                                                                                                                    }
                                                                                                                    jSONObject.put("TableConnections", jSONArray);
                                                                                                                    if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                                        Log.d(str10, jSONObject.toString());
                                                                                                                    }
                                                                                                                    String str38 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                                    writeFileSD(str, jSONObject.toString());
                                                                                                                    this.presenter.createZip_(file, str38, z);
                                                                                                                    cursor.close();
                                                                                                                    this.db.close();
                                                                                                                }
                                                                                                                jSONArray = jSONArray3;
                                                                                                                jSONObject.put("TableConnections", jSONArray);
                                                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                                    Log.d(str10, jSONObject.toString());
                                                                                                                }
                                                                                                                String str39 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                                writeFileSD(str, jSONObject.toString());
                                                                                                                this.presenter.createZip_(file, str39, z);
                                                                                                                cursor.close();
                                                                                                                this.db.close();
                                                                                                            }
                                                                                                            cursorQuery = cursorQuery;
                                                                                                            jSONArray2 = jSONArray2;
                                                                                                            cursorQuery3 = cursor;
                                                                                                            str26 = str26;
                                                                                                            jSONObject2 = jSONObject2;
                                                                                                            str2 = str2;
                                                                                                            file = file;
                                                                                                            str20 = str3;
                                                                                                            i2 = i2;
                                                                                                        }
                                                                                                    } catch (Exception e20) {
                                                                                                        e = e20;
                                                                                                        i2 = i2;
                                                                                                        jSONObject2 = jSONObject2;
                                                                                                        str2 = str2;
                                                                                                        exc = e;
                                                                                                        cursorQuery = cursorQuery;
                                                                                                        str3 = str9;
                                                                                                        jSONArray2 = jSONArray2;
                                                                                                        Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                                        Log.d("NS", "ERROR " + exc.toString());
                                                                                                        if (!cursorQuery.moveToNext()) {
                                                                                                            break;
                                                                                                            jSONObject = jSONObject2;
                                                                                                            jSONObject.put("TableComponent", jSONArray2);
                                                                                                            str10 = "kascada";
                                                                                                            cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                                                                                            if (cursorQuery2.moveToFirst()) {
                                                                                                                while (true) {
                                                                                                                    JSONObject jSONObject17 = new JSONObject();
                                                                                                                    str11 = str19;
                                                                                                                    jSONObject17.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                                                                                                    str12 = str26;
                                                                                                                    jSONObject17.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                                                                                                    str18 = str18;
                                                                                                                    jSONObject17.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                                                                                                    jSONArray = jSONArray3;
                                                                                                                    jSONArray.put(jSONObject17);
                                                                                                                    if (cursorQuery2.moveToNext()) {
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    str19 = str11;
                                                                                                                    str26 = str12;
                                                                                                                    str18 = str18;
                                                                                                                    jSONArray3 = jSONArray;
                                                                                                                }
                                                                                                                jSONObject.put("TableConnections", jSONArray);
                                                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                                    Log.d(str10, jSONObject.toString());
                                                                                                                }
                                                                                                                String str310 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                                writeFileSD(str, jSONObject.toString());
                                                                                                                this.presenter.createZip_(file, str310, z);
                                                                                                                cursor.close();
                                                                                                                this.db.close();
                                                                                                            }
                                                                                                            jSONArray = jSONArray3;
                                                                                                            jSONObject.put("TableConnections", jSONArray);
                                                                                                            if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                                                Log.d(str10, jSONObject.toString());
                                                                                                            }
                                                                                                            String str311 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                                            writeFileSD(str, jSONObject.toString());
                                                                                                            this.presenter.createZip_(file, str311, z);
                                                                                                            cursor.close();
                                                                                                            this.db.close();
                                                                                                        }
                                                                                                        cursorQuery = cursorQuery;
                                                                                                        jSONArray2 = jSONArray2;
                                                                                                        cursorQuery3 = cursor;
                                                                                                        str26 = str26;
                                                                                                        jSONObject2 = jSONObject2;
                                                                                                        str2 = str2;
                                                                                                        file = file;
                                                                                                        str20 = str3;
                                                                                                        i2 = i2;
                                                                                                    }
                                                                                                } catch (Exception e21) {
                                                                                                    e = e21;
                                                                                                    str26 = str26;
                                                                                                }
                                                                                            } catch (Exception e22) {
                                                                                                e = e22;
                                                                                                str26 = str26;
                                                                                                i2 = i2;
                                                                                                cursor = cursorQuery3;
                                                                                            }
                                                                                        } catch (Exception e23) {
                                                                                            e = e23;
                                                                                            str26 = str26;
                                                                                            i2 = i2;
                                                                                            cursor = cursorQuery3;
                                                                                            jSONObject2 = jSONObject2;
                                                                                            str2 = str2;
                                                                                            str22 = str7;
                                                                                        }
                                                                                    }
                                                                                    String str312 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                    writeFileSD(str, jSONObject.toString());
                                                                                    this.presenter.createZip_(file, str312, z);
                                                                                    cursor.close();
                                                                                    this.db.close();
                                                                                }
                                                                                str26 = str26;
                                                                                i2 = i2;
                                                                                cursor = cursorQuery3;
                                                                                jSONObject2 = jSONObject2;
                                                                                cursorQuery = cursorQuery;
                                                                                jSONObject5 = jSONObject3;
                                                                                file = file;
                                                                                str2 = str2;
                                                                                jSONObject6 = jSONObject4;
                                                                                str3 = str9;
                                                                                str22 = str7;
                                                                                jSONObject7 = new JSONObject();
                                                                                jSONArray2.put(jSONObject);
                                                                            } catch (Exception e24) {
                                                                                e = e24;
                                                                                exc = e;
                                                                                Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                                Log.d("NS", "ERROR " + exc.toString());
                                                                            }
                                                                            JSONObject jSONObject18 = jSONObject5;
                                                                            jSONObject18.put("jsTableComponent_connectionInfo", jSONObject6);
                                                                            jSONObject18.put("jsTableComponent_other", jSONObject7);
                                                                            jSONArray2 = jSONArray2;
                                                                        } catch (Exception e25) {
                                                                            e = e25;
                                                                            jSONArray2 = jSONArray2;
                                                                            exc = e;
                                                                            Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                            Log.d("NS", "ERROR " + exc.toString());
                                                                            if (!cursorQuery.moveToNext()) {
                                                                                break;
                                                                                jSONObject = jSONObject2;
                                                                                jSONObject.put("TableComponent", jSONArray2);
                                                                                str10 = "kascada";
                                                                                cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                                                                if (cursorQuery2.moveToFirst()) {
                                                                                    while (true) {
                                                                                        JSONObject jSONObject19 = new JSONObject();
                                                                                        str11 = str19;
                                                                                        jSONObject19.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                                                                        str12 = str26;
                                                                                        jSONObject19.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                                                                        str18 = str18;
                                                                                        jSONObject19.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                                                                        jSONArray = jSONArray3;
                                                                                        jSONArray.put(jSONObject19);
                                                                                        if (cursorQuery2.moveToNext()) {
                                                                                            break;
                                                                                        }
                                                                                        str19 = str11;
                                                                                        str26 = str12;
                                                                                        str18 = str18;
                                                                                        jSONArray3 = jSONArray;
                                                                                    }
                                                                                    jSONObject.put("TableConnections", jSONArray);
                                                                                    if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                        Log.d(str10, jSONObject.toString());
                                                                                    }
                                                                                    String str313 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                    writeFileSD(str, jSONObject.toString());
                                                                                    this.presenter.createZip_(file, str313, z);
                                                                                    cursor.close();
                                                                                    this.db.close();
                                                                                }
                                                                                jSONArray = jSONArray3;
                                                                                jSONObject.put("TableConnections", jSONArray);
                                                                                if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                    Log.d(str10, jSONObject.toString());
                                                                                }
                                                                                String str314 = new File(n.a.e()) + "/" + str + ".zip";
                                                                                writeFileSD(str, jSONObject.toString());
                                                                                this.presenter.createZip_(file, str314, z);
                                                                                cursor.close();
                                                                                this.db.close();
                                                                            }
                                                                            cursorQuery = cursorQuery;
                                                                            jSONArray2 = jSONArray2;
                                                                            cursorQuery3 = cursor;
                                                                            str26 = str26;
                                                                            jSONObject2 = jSONObject2;
                                                                            str2 = str2;
                                                                            file = file;
                                                                            str20 = str3;
                                                                            i2 = i2;
                                                                        }
                                                                    } catch (Exception e26) {
                                                                        e = e26;
                                                                        str26 = str26;
                                                                        i2 = i2;
                                                                        cursor = cursorQuery3;
                                                                        jSONObject2 = jSONObject2;
                                                                        cursorQuery = cursorQuery;
                                                                        file = file;
                                                                        str2 = str2;
                                                                        str3 = str9;
                                                                        str22 = str7;
                                                                    }
                                                                } catch (Exception e27) {
                                                                    e = e27;
                                                                    str23 = str6;
                                                                    str22 = str7;
                                                                    str3 = str20;
                                                                    cursor = cursorQuery3;
                                                                    jSONArray2 = jSONArray2;
                                                                    exc = e;
                                                                    Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                                                                    Log.d("NS", "ERROR " + exc.toString());
                                                                    if (!cursorQuery.moveToNext()) {
                                                                        break;
                                                                        jSONObject = jSONObject2;
                                                                        jSONObject.put("TableComponent", jSONArray2);
                                                                        str10 = "kascada";
                                                                        cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                                                        if (cursorQuery2.moveToFirst()) {
                                                                            while (true) {
                                                                                JSONObject jSONObject110 = new JSONObject();
                                                                                str11 = str19;
                                                                                jSONObject110.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                                                                str12 = str26;
                                                                                jSONObject110.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                                                                str18 = str18;
                                                                                jSONObject110.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                                                                jSONArray = jSONArray3;
                                                                                jSONArray.put(jSONObject110);
                                                                                if (cursorQuery2.moveToNext()) {
                                                                                    break;
                                                                                }
                                                                                str19 = str11;
                                                                                str26 = str12;
                                                                                str18 = str18;
                                                                                jSONArray3 = jSONArray;
                                                                            }
                                                                            jSONObject.put("TableConnections", jSONArray);
                                                                            if (ru.himik.nightscream.kascada.w.a.a) {
                                                                                Log.d(str10, jSONObject.toString());
                                                                            }
                                                                            String str315 = new File(n.a.e()) + "/" + str + ".zip";
                                                                            writeFileSD(str, jSONObject.toString());
                                                                            this.presenter.createZip_(file, str315, z);
                                                                            cursor.close();
                                                                            this.db.close();
                                                                        }
                                                                        jSONArray = jSONArray3;
                                                                        jSONObject.put("TableConnections", jSONArray);
                                                                        if (ru.himik.nightscream.kascada.w.a.a) {
                                                                            Log.d(str10, jSONObject.toString());
                                                                        }
                                                                        String str316 = new File(n.a.e()) + "/" + str + ".zip";
                                                                        writeFileSD(str, jSONObject.toString());
                                                                        this.presenter.createZip_(file, str316, z);
                                                                        cursor.close();
                                                                        this.db.close();
                                                                    }
                                                                    cursorQuery = cursorQuery;
                                                                    jSONArray2 = jSONArray2;
                                                                    cursorQuery3 = cursor;
                                                                    str26 = str26;
                                                                    jSONObject2 = jSONObject2;
                                                                    str2 = str2;
                                                                    file = file;
                                                                    str20 = str3;
                                                                    i2 = i2;
                                                                }
                                                            } catch (Exception e28) {
                                                                e = e28;
                                                                str21 = str8;
                                                            }
                                                        } catch (Exception e29) {
                                                            e = e29;
                                                            str24 = str5;
                                                        }
                                                    } catch (Exception e30) {
                                                        e = e30;
                                                        str26 = str26;
                                                        i2 = i2;
                                                        jSONObject2 = jSONObject2;
                                                        cursorQuery = cursorQuery;
                                                        file = file;
                                                        str2 = str2;
                                                        str25 = str4;
                                                        str24 = str5;
                                                        str23 = str6;
                                                    }
                                                } catch (Exception e31) {
                                                    e = e31;
                                                    str26 = str26;
                                                    i2 = i2;
                                                    jSONObject2 = jSONObject2;
                                                    cursorQuery = cursorQuery;
                                                    file = file;
                                                    str2 = str2;
                                                    str25 = str4;
                                                    str24 = str5;
                                                }
                                            } catch (Exception e32) {
                                                e = e32;
                                                str26 = str26;
                                                i2 = i2;
                                                jSONObject2 = jSONObject2;
                                                cursorQuery = cursorQuery;
                                                file = file;
                                                str2 = str2;
                                                str25 = str4;
                                            }
                                        } catch (Exception e33) {
                                            e = e33;
                                            str26 = str26;
                                            i2 = i2;
                                            jSONObject2 = jSONObject2;
                                            cursorQuery = cursorQuery;
                                            file = file;
                                            str2 = str2;
                                        }
                                        if (!cursorQuery.moveToNext()) {
                                            break;
                                        }
                                        cursorQuery = cursorQuery;
                                        jSONArray2 = jSONArray2;
                                        cursorQuery3 = cursor;
                                        str26 = str26;
                                        jSONObject2 = jSONObject2;
                                        str2 = str2;
                                        file = file;
                                        str20 = str3;
                                        i2 = i2;
                                    }
                                } else {
                                    str26 = IMAPStore.ID_NAME;
                                    i2 = i2;
                                    cursor = cursorQuery3;
                                    jSONObject2 = jSONObject2;
                                    file = file;
                                    str2 = "pro_";
                                    jSONArray2 = jSONArray2;
                                }
                                jSONObject = jSONObject2;
                                jSONObject.put("TableComponent", jSONArray2);
                                str10 = "kascada";
                                cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                                if (cursorQuery2.moveToFirst()) {
                                    while (true) {
                                        JSONObject jSONObject111 = new JSONObject();
                                        str11 = str19;
                                        jSONObject111.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                                        str12 = str26;
                                        jSONObject111.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                                        str18 = str18;
                                        jSONObject111.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                                        jSONArray = jSONArray3;
                                        jSONArray.put(jSONObject111);
                                        if (cursorQuery2.moveToNext()) {
                                            break;
                                        }
                                        str19 = str11;
                                        str26 = str12;
                                        str18 = str18;
                                        jSONArray3 = jSONArray;
                                    }
                                    jSONObject.put("TableConnections", jSONArray);
                                    if (ru.himik.nightscream.kascada.w.a.a) {
                                        Log.d(str10, jSONObject.toString());
                                    }
                                    String str317 = new File(n.a.e()) + "/" + str + ".zip";
                                    writeFileSD(str, jSONObject.toString());
                                    this.presenter.createZip_(file, str317, z);
                                    cursor.close();
                                    this.db.close();
                                }
                                jSONArray = jSONArray3;
                                jSONObject.put("TableConnections", jSONArray);
                                if (ru.himik.nightscream.kascada.w.a.a) {
                                    Log.d(str10, jSONObject.toString());
                                }
                                String str318 = new File(n.a.e()) + "/" + str + ".zip";
                                writeFileSD(str, jSONObject.toString());
                                this.presenter.createZip_(file, str318, z);
                                cursor.close();
                                this.db.close();
                            }
                        } catch (Exception e34) {
                            e = e34;
                            i4 = i6;
                        }
                    } catch (Exception e35) {
                        jSONObject2 = jSONObject9;
                        exc3 = e35;
                        i4 = i5;
                    }
                }
                jSONObject2 = jSONObject9;
                try {
                    jSONObject2.put("TableNameProject", jSONObject10);
                } catch (Exception e36) {
                    e = e36;
                    exc3 = e;
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                    exc3.printStackTrace();
                }
                i2 = i4;
            } else {
                jSONObject2 = jSONObject9;
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                i2 = 0;
            }
            SQLiteDatabase sQLiteDatabase2 = this.db;
            StringBuilder sb6 = new StringBuilder();
            str2 = "pro_";
            sb6.append("pro_");
            sb6.append(i2);
            sb6.append("_component");
            cursorQuery = sQLiteDatabase2.query(sb6.toString(), null, null, null, null, null, null);
            if (cursorQuery.moveToFirst()) {
                while (true) {
                    jSONObject3 = new JSONObject();
                    new JSONObject();
                    new JSONObject();
                    str4 = str25;
                    i3 = cursorQuery.getInt(cursorQuery.getColumnIndex(str4));
                    jSONObject3.put(str4, cursorQuery.getString(cursorQuery.getColumnIndex(str4)));
                    str5 = str24;
                    jSONObject3.put(str5, cursorQuery.getString(cursorQuery.getColumnIndex(str5)));
                    str6 = str23;
                    jSONObject3.put(str6, cursorQuery.getString(cursorQuery.getColumnIndex(str6)));
                    str25 = str4;
                    str7 = str22;
                    jSONObject3.put(str7, cursorQuery.getString(cursorQuery.getColumnIndex(str7)));
                    str24 = str5;
                    str8 = str21;
                    jSONObject3.put(str8, cursorQuery.getString(cursorQuery.getColumnIndex(str8)));
                    str21 = str8;
                    jSONObject3.put("y", cursorQuery.getString(cursorQuery.getColumnIndex("y")));
                    jSONObject3.put("textSize", cursorQuery.getString(cursorQuery.getColumnIndex("textSize")));
                    jSONObject3.put("colorText", cursorQuery.getString(cursorQuery.getColumnIndex("colorText")));
                    jSONObject3.put("colorBackground", cursorQuery.getString(cursorQuery.getColumnIndex("colorBackground")));
                    if (cursorQuery.getString(cursorQuery.getColumnIndex("connectionInfo")).length() > 0) {
                        jSONObject4 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex("connectionInfo")));
                    } else {
                        jSONObject4 = new JSONObject();
                    }
                    str23 = str6;
                    str9 = str20;
                    if (cursorQuery.getString(cursorQuery.getColumnIndex(str9)).length() <= 0) {
                        str26 = str26;
                        i2 = i2;
                        cursor = cursorQuery3;
                        jSONObject2 = jSONObject2;
                        cursorQuery = cursorQuery;
                        jSONObject5 = jSONObject3;
                        file = file;
                        str2 = str2;
                        jSONObject6 = jSONObject4;
                        str3 = str9;
                        str22 = str7;
                        jSONObject7 = new JSONObject();
                    } else if (i3 != 5) {
                        str26 = str26;
                        i2 = i2;
                        cursor = cursorQuery3;
                        jSONObject2 = jSONObject2;
                        cursor2 = cursorQuery;
                        jSONObject5 = jSONObject3;
                        file = file;
                        str2 = str2;
                        jSONObject6 = jSONObject4;
                        str22 = str7;
                        cursorQuery = cursor2;
                        str3 = str9;
                        jSONObject7 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str3)));
                        if (jSONObject7.getBoolean("isImageUserOn")) {
                            String string29 = jSONObject7.getString("pathOrNameOn");
                            String strSubstring29 = string29.substring(string29.lastIndexOf("/") + 1);
                            copyFile(string29, strSubstring29, file.getPath() + "/");
                            jSONObject7.put("pathOrNameOn", strSubstring29);
                        }
                        if (jSONObject7.getBoolean("isImageUserOff")) {
                            String string30 = jSONObject7.getString("pathOrNameOff");
                            String strSubstring30 = string30.substring(string30.lastIndexOf("/") + 1);
                            copyFile(string30, strSubstring30, file.getPath() + "/");
                            jSONObject7.put("pathOrNameOff", strSubstring30);
                        }
                    } else if (i3 != 21) {
                        str26 = str26;
                        i2 = i2;
                        cursor = cursorQuery3;
                        jSONObject2 = jSONObject2;
                        Cursor cursor5 = cursorQuery;
                        jSONObject5 = jSONObject3;
                        file = file;
                        str2 = str2;
                        jSONObject6 = jSONObject4;
                        str3 = str9;
                        str22 = str7;
                        JSONObject jSONObject112 = new JSONObject(cursor5.getString(cursor5.getColumnIndex(str3)));
                        String string31 = jSONObject112.getString("pathSound_0");
                        String strSubstring31 = string31.substring(string31.lastIndexOf("/") + 1);
                        String string32 = jSONObject112.getString("pathSound_1");
                        String strSubstring32 = string32.substring(string32.lastIndexOf("/") + 1);
                        String string33 = jSONObject112.getString("pathSound_2");
                        String strSubstring33 = string33.substring(string33.lastIndexOf("/") + 1);
                        String string34 = jSONObject112.getString("pathSound_3");
                        String strSubstring34 = string34.substring(string34.lastIndexOf("/") + 1);
                        String string35 = jSONObject112.getString("pathSound_4");
                        cursor3 = cursor5;
                        String strSubstring35 = string35.substring(string35.lastIndexOf("/") + 1);
                        String string36 = jSONObject112.getString("pathSound_5");
                        String strSubstring36 = string36.substring(string36.lastIndexOf("/") + 1);
                        String string110 = jSONObject112.getString("pathSound_6");
                        String strSubstring110 = string110.substring(string110.lastIndexOf("/") + 1);
                        String string111 = jSONObject112.getString("pathSound_7");
                        String strSubstring111 = string111.substring(string111.lastIndexOf("/") + 1);
                        copyFile(string31, strSubstring31, file.getPath() + "/");
                        copyFile(string32, strSubstring32, file.getPath() + "/");
                        copyFile(string33, strSubstring33, file.getPath() + "/");
                        copyFile(string34, strSubstring34, file.getPath() + "/");
                        copyFile(string35, strSubstring35, file.getPath() + "/");
                        copyFile(string36, strSubstring36, file.getPath() + "/");
                        copyFile(string110, strSubstring110, file.getPath() + "/");
                        copyFile(string111, strSubstring111, file.getPath() + "/");
                        jSONObject112.put("pathSound_0", strSubstring31);
                        jSONObject112.put("pathSound_1", strSubstring32);
                        jSONObject112.put("pathSound_2", strSubstring33);
                        jSONObject112.put("pathSound_3", strSubstring34);
                        jSONObject112.put("pathSound_4", strSubstring35);
                        jSONObject112.put("pathSound_5", strSubstring36);
                        jSONObject112.put("pathSound_6", strSubstring110);
                        jSONObject112.put("pathSound_7", strSubstring111);
                        jSONObject7 = jSONObject112;
                        cursorQuery = cursor3;
                        str3 = str3;
                    } else if (i3 != 16) {
                        str26 = str26;
                        i2 = i2;
                        cursor = cursorQuery3;
                        jSONObject2 = jSONObject2;
                        jSONObject5 = jSONObject3;
                        file = file;
                        str2 = str2;
                        jSONObject6 = jSONObject4;
                        str22 = str7;
                        str3 = str9;
                        cursorQuery = cursorQuery;
                        jSONObject7 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str3)));
                        String string112 = jSONObject7.getString("pathGif");
                        String strSubstring112 = string112.substring(string112.lastIndexOf("/") + 1);
                        copyFile(string112, strSubstring112, file.getPath() + "/");
                        jSONObject7.put("pathGif", strSubstring112);
                    } else if (i3 != 17) {
                        jSONObject7 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str9)));
                        str26 = str26;
                        i2 = i2;
                        cursor = cursorQuery3;
                        jSONObject2 = jSONObject2;
                        cursorQuery = cursorQuery;
                        jSONObject5 = jSONObject3;
                        file = file;
                        str2 = str2;
                        jSONObject6 = jSONObject4;
                        str3 = str9;
                        str22 = str7;
                    } else {
                        JSONObject jSONObject113 = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex(str9)));
                        String string113 = jSONObject113.getString("pathPic_0");
                        str22 = str7;
                        String strSubstring113 = string113.substring(string113.lastIndexOf("/") + 1);
                        cursor = cursorQuery3;
                        String string114 = jSONObject113.getString("pathPic_1");
                        str26 = str26;
                        String strSubstring114 = string114.substring(string114.lastIndexOf("/") + 1);
                        i2 = i2;
                        String string115 = jSONObject113.getString("pathPic_2");
                        str2 = str2;
                        String strSubstring115 = string115.substring(string115.lastIndexOf("/") + 1);
                        jSONObject2 = jSONObject2;
                        String string116 = jSONObject113.getString("pathPic_3");
                        jSONObject5 = jSONObject3;
                        String strSubstring116 = string116.substring(string116.lastIndexOf("/") + 1);
                        jSONObject6 = jSONObject4;
                        String string117 = jSONObject113.getString("pathPic_4");
                        cursor3 = cursorQuery;
                        String strSubstring117 = string117.substring(string117.lastIndexOf("/") + 1);
                        String string118 = jSONObject113.getString("pathPic_5");
                        String strSubstring118 = string118.substring(string118.lastIndexOf("/") + 1);
                        String string119 = jSONObject113.getString("pathPic_6");
                        String strSubstring119 = string119.substring(string119.lastIndexOf("/") + 1);
                        String string210 = jSONObject113.getString("pathPic_7");
                        String strSubstring210 = string210.substring(string210.lastIndexOf("/") + 1);
                        String string211 = jSONObject113.getString("pathPic_8");
                        String strSubstring211 = string211.substring(string211.lastIndexOf("/") + 1);
                        String string212 = jSONObject113.getString("pathPic_9");
                        String strSubstring212 = string212.substring(string212.lastIndexOf("/") + 1);
                        String string213 = jSONObject113.getString("pathPic_10");
                        String strSubstring213 = string213.substring(string213.lastIndexOf("/") + 1);
                        String string214 = jSONObject113.getString("pathPic_11");
                        String strSubstring214 = string214.substring(string214.lastIndexOf("/") + 1);
                        String string215 = jSONObject113.getString("pathPic_12");
                        String strSubstring215 = string215.substring(string215.lastIndexOf("/") + 1);
                        String string216 = jSONObject113.getString("pathPic_13");
                        String strSubstring216 = string216.substring(string216.lastIndexOf("/") + 1);
                        String string217 = jSONObject113.getString("pathPic_14");
                        String strSubstring217 = string217.substring(string217.lastIndexOf("/") + 1);
                        String string218 = jSONObject113.getString("pathPic_15");
                        String strSubstring218 = string218.substring(string218.lastIndexOf("/") + 1);
                        copyFile(string113, strSubstring113, file.getPath() + "/");
                        copyFile(string114, strSubstring114, file.getPath() + "/");
                        copyFile(string115, strSubstring115, file.getPath() + "/");
                        copyFile(string116, strSubstring116, file.getPath() + "/");
                        copyFile(string117, strSubstring117, file.getPath() + "/");
                        copyFile(string118, strSubstring118, file.getPath() + "/");
                        copyFile(string119, strSubstring119, file.getPath() + "/");
                        copyFile(string210, strSubstring210, file.getPath() + "/");
                        copyFile(string211, strSubstring211, file.getPath() + "/");
                        copyFile(string212, strSubstring212, file.getPath() + "/");
                        copyFile(string213, strSubstring213, file.getPath() + "/");
                        copyFile(string214, strSubstring214, file.getPath() + "/");
                        copyFile(string215, strSubstring215, file.getPath() + "/");
                        copyFile(string216, strSubstring216, file.getPath() + "/");
                        copyFile(string217, strSubstring217, file.getPath() + "/");
                        file = file;
                        copyFile(string218, strSubstring218, file.getPath() + "/");
                        jSONObject113.put("pathPic_0", strSubstring113);
                        jSONObject113.put("pathPic_1", strSubstring114);
                        jSONObject113.put("pathPic_2", strSubstring115);
                        jSONObject113.put("pathPic_3", strSubstring116);
                        jSONObject113.put("pathPic_4", strSubstring117);
                        jSONObject113.put("pathPic_5", strSubstring118);
                        jSONObject113.put("pathPic_6", strSubstring119);
                        jSONObject113.put("pathPic_7", strSubstring210);
                        jSONObject113.put("pathPic_8", strSubstring211);
                        jSONObject113.put("pathPic_9", strSubstring212);
                        jSONObject113.put("pathPic_10", strSubstring213);
                        jSONObject113.put("pathPic_11", strSubstring214);
                        jSONObject113.put("pathPic_12", strSubstring215);
                        jSONObject113.put("pathPic_13", strSubstring216);
                        jSONObject113.put("pathPic_14", strSubstring217);
                        jSONObject113.put("pathPic_15", strSubstring218);
                        jSONObject7 = jSONObject113;
                        str3 = str9;
                        cursorQuery = cursor3;
                    }
                    JSONObject jSONObject114 = jSONObject5;
                    jSONObject114.put("jsTableComponent_connectionInfo", jSONObject6);
                    jSONObject114.put("jsTableComponent_other", jSONObject7);
                    jSONArray2 = jSONArray2;
                    jSONArray2.put(jSONObject114);
                    if (!cursorQuery.moveToNext()) {
                        break;
                        break;
                    }
                    cursorQuery = cursorQuery;
                    jSONArray2 = jSONArray2;
                    cursorQuery3 = cursor;
                    str26 = str26;
                    jSONObject2 = jSONObject2;
                    str2 = str2;
                    file = file;
                    str20 = str3;
                    i2 = i2;
                }
            } else {
                str26 = IMAPStore.ID_NAME;
                i2 = i2;
                cursor = cursorQuery3;
                jSONObject2 = jSONObject2;
                file = file;
                str2 = "pro_";
                jSONArray2 = jSONArray2;
            }
            jSONObject = jSONObject2;
            try {
                jSONObject.put("TableComponent", jSONArray2);
            } catch (Exception e37) {
                Toast.makeText(this, getResources().getString(R.string.error_export_project), 0).show();
                if (ru.himik.nightscream.kascada.w.a.a) {
                    str10 = "kascada";
                    Log.d(str10, e37.toString());
                }
                cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
                if (cursorQuery2.moveToFirst()) {
                    while (true) {
                        JSONObject jSONObject115 = new JSONObject();
                        str11 = str19;
                        jSONObject115.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                        str12 = str26;
                        jSONObject115.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                        str18 = str18;
                        jSONObject115.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                        jSONArray = jSONArray3;
                        jSONArray.put(jSONObject115);
                        if (cursorQuery2.moveToNext()) {
                            break;
                        }
                        str19 = str11;
                        str26 = str12;
                        str18 = str18;
                        jSONArray3 = jSONArray;
                    }
                    jSONObject.put("TableConnections", jSONArray);
                    if (ru.himik.nightscream.kascada.w.a.a) {
                        Log.d(str10, jSONObject.toString());
                    }
                    String str319 = new File(n.a.e()) + "/" + str + ".zip";
                    writeFileSD(str, jSONObject.toString());
                    this.presenter.createZip_(file, str319, z);
                    cursor.close();
                    this.db.close();
                }
                jSONArray = jSONArray3;
                jSONObject.put("TableConnections", jSONArray);
                if (ru.himik.nightscream.kascada.w.a.a) {
                    Log.d(str10, jSONObject.toString());
                }
                String str3110 = new File(n.a.e()) + "/" + str + ".zip";
                writeFileSD(str, jSONObject.toString());
                this.presenter.createZip_(file, str3110, z);
                cursor.close();
                this.db.close();
            }
            str10 = "kascada";
            cursorQuery2 = this.db.query(str2 + i2 + "_connections", null, null, null, null, null, null);
            try {
                if (cursorQuery2.moveToFirst()) {
                    while (true) {
                        JSONObject jSONObject116 = new JSONObject();
                        str11 = str19;
                        jSONObject116.put(str11, cursorQuery2.getString(cursorQuery2.getColumnIndex(str11)));
                        str12 = str26;
                        jSONObject116.put(str12, cursorQuery2.getString(cursorQuery2.getColumnIndex(str12)));
                        str18 = str18;
                        jSONObject116.put(str18, cursorQuery2.getString(cursorQuery2.getColumnIndex(str18)));
                        jSONArray = jSONArray3;
                        jSONArray.put(jSONObject116);
                        if (cursorQuery2.moveToNext()) {
                            break;
                        }
                        str19 = str11;
                        str26 = str12;
                        str18 = str18;
                        jSONArray3 = jSONArray;
                    }
                    jSONObject.put("TableConnections", jSONArray);
                    if (ru.himik.nightscream.kascada.w.a.a) {
                        Log.d(str10, jSONObject.toString());
                    }
                } else {
                    jSONArray = jSONArray3;
                }
                jSONObject.put("TableConnections", jSONArray);
            } catch (Exception e38) {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_export_project), 0).show();
                if (ru.himik.nightscream.kascada.w.a.a) {
                    Log.d(str10, e38.toString());
                }
            }
            if (ru.himik.nightscream.kascada.w.a.a) {
                Log.d(str10, jSONObject.toString());
            }
        } else {
            cursor = cursorQuery3;
            jSONObject = jSONObject9;
            file = file;
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.not_found_project), 1).show();
            finish();
        }
        String str3111 = new File(n.a.e()) + "/" + str + ".zip";
        writeFileSD(str, jSONObject.toString());
        this.presenter.createZip_(file, str3111, z);
        cursor.close();
        this.db.close();
    }

    public void getProjectFromBd() {
        this.projectsName.clear();
        e eVar = new e(this);
        this.dbHelper = eVar;
        SQLiteDatabase writableDatabase = eVar.getWritableDatabase();
        this.db = writableDatabase;
        Cursor cursorQuery = writableDatabase.query("TableNameProject", null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            do {
                String string = cursorQuery.getString(cursorQuery.getColumnIndex(IMAPStore.ID_NAME));
                int i2 = cursorQuery.getInt(cursorQuery.getColumnIndex("_id"));
                int i3 = cursorQuery.getInt(cursorQuery.getColumnIndex("countScreen"));
                int i4 = cursorQuery.getInt(cursorQuery.getColumnIndex("countDevice"));
                this.projectsName.add(new g(string, i2, i3, cursorQuery.getString(cursorQuery.getColumnIndex("createdTime")), cursorQuery.getString(cursorQuery.getColumnIndex("createdDate")), i4, false));
            } while (cursorQuery.moveToNext());
        } else {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.not_found_project), 1).show();
            finish();
        }
        cursorQuery.close();
        this.db.close();
        this.lvMain = (ListView) findViewById(R.id.lvMain);
        this.adapter = new ru.himik.nightscream.kascada.Bd.d(this, this.projectsName);
        if (checkLicense()) {
            this.adapter.c(new OnClickUploadQr() { // from class: ru.himik.nightscream.kascada.Bd.Export.a
                @Override // ru.himik.nightscream.kascada.Bd.Export.ProjectExportActivity.OnClickUploadQr
                public final void onClickQR(String str) {
                    this.a.g(str);
                }
            });
            this.adapter.d();
        }
        this.lvMain.setAdapter((ListAdapter) this.adapter);
        this.lvMain.setOnItemClickListener(this.mDeviceClickListener);
        String externalStorageState = Environment.getExternalStorageState();
        if ("mounted".equals(externalStorageState)) {
            this.mExternalStorageWritable = true;
            this.mExternalStorageAvailable = true;
        } else if ("mounted_ro".equals(externalStorageState)) {
            this.mExternalStorageAvailable = true;
            this.mExternalStorageWritable = false;
        } else {
            this.mExternalStorageWritable = false;
            this.mExternalStorageAvailable = false;
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.project_list);
        getWindow().setFlags(1024, 1024);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getResources().getString(R.string.export_project));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
        }
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Export.ProjectExportActivity.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ProjectExportActivity.this.onBackPressed();
                }
            });
        }
        this.presenter.interfaceCallbackExport = this;
        getProjectFromBd();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Export.InterfaceCallbackExport
    public void showError(String str) {
        this.dialogUploadInWork.dismiss();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.an_error_has_occurred);
        builder.setMessage(str);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: ru.himik.nightscream.kascada.Bd.Export.b
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                dialogInterface.dismiss();
            }
        });
        builder.create().show();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Export.InterfaceCallbackExport
    public void showFileCreated(String str) {
        this.dialogUploadInWork.dismiss();
        g.a.a.e.h(this, getString(R.string.file_created) + " " + str, 1).show();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Export.InterfaceCallbackExport
    public void showInWork() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.wait);
        builder.setMessage(R.string.archive_created);
        builder.setCancelable(false);
        AlertDialog alertDialogCreate = builder.create();
        this.dialogUploadInWork = alertDialogCreate;
        alertDialogCreate.show();
    }

    @Override // ru.himik.nightscream.kascada.Bd.Export.InterfaceCallbackExport
    public void showUploadInWork() {
        this.dialogUploadInWork.setMessage(getString(R.string.uploading_to_the_server));
    }

    @Override // ru.himik.nightscream.kascada.Bd.Export.InterfaceCallbackExport
    public void showUploadSuccessful(String str) {
        this.dialogUploadInWork.dismiss();
        Intent intent = new Intent(this, (Class<?>) ShowQrCode.class);
        intent.putExtra("URL", str);
        startActivity(intent);
    }

    void writeFile(String str, String str2) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).toString() + "/KaScada Export Project/");
        if (!file.exists()) {
            file.mkdirs();
        }
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(openFileOutput(str, 0)));
            bufferedWriter.write(str2);
            bufferedWriter.close();
        } catch (FileNotFoundException e2) {
            e2.printStackTrace();
        } catch (IOException e3) {
            e3.printStackTrace();
        }
    }

    void writeFileSD(String str, String str2) {
        if (!this.mExternalStorageWritable || !this.mExternalStorageAvailable) {
            Toast.makeText(this, getResources().getString(R.string.error_sd_card), 0).show();
            return;
        }
        File file = new File(n.a.e() + str + "/");
        if (!file.exists()) {
            file.mkdirs();
        }
        File file2 = new File(file, str + ".pro");
        if (ru.himik.nightscream.kascada.w.a.a) {
            Log.d("kascada", "FILE = " + file2.getPath());
        }
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file2));
            bufferedWriter.write(str2);
            bufferedWriter.close();
        } catch (IOException e2) {
            Log.d("NS", "ProjectExportActivity.writeFileSD: ERROR");
            e2.printStackTrace();
        }
    }
}
