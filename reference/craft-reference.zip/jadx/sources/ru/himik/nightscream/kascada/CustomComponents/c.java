package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.media.SoundPool;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class c extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    private boolean C;
    private boolean D;
    Bitmap E;
    Paint F;
    Paint G;
    boolean H;
    boolean I;
    int J;
    int K;
    private long L;
    public Point M;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8738d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8739e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    Context f8740f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public byte f8741g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public b f8742h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f8743i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f8744j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private SoundPool f8745k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f8746l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f8747m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    boolean f8748n;
    boolean o;

    class a implements SoundPool.OnLoadCompleteListener {
        a() {
        }

        @Override // android.media.SoundPool.OnLoadCompleteListener
        public void onLoadComplete(SoundPool soundPool, int i2, int i3) {
            c.this.f8748n = true;
        }
    }

    public c(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_alarm);
        this.f8738d = 9;
        this.f8741g = (byte) 1;
        this.f8742h = new b();
        this.f8744j = 1;
        this.f8748n = false;
        this.o = false;
        this.E = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.F = new Paint();
        this.G = new Paint();
        this.H = false;
        this.I = false;
        this.J = 0;
        this.K = 0;
        this.L = 0L;
        this.M = new Point();
        this.f8740f = context;
    }

    public void a(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_alarm);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
        this.f8742h.A(this.f8738d);
    }

    public void b() {
        Context context;
        int i2;
        SoundPool soundPool = new SoundPool(1, 3, 0);
        this.f8745k = soundPool;
        int i3 = this.f8744j;
        if (i3 == 1) {
            context = this.f8740f;
            i2 = R.raw.alarm1;
        } else if (i3 == 2) {
            context = this.f8740f;
            i2 = R.raw.alarm2;
        } else if (i3 == 3) {
            context = this.f8740f;
            i2 = R.raw.alarm3;
        } else {
            if (i3 != 4) {
                if (i3 == 5) {
                    context = this.f8740f;
                    i2 = R.raw.alarm5;
                }
                this.f8745k.setOnLoadCompleteListener(new a());
            }
            context = this.f8740f;
            i2 = R.raw.alarm4;
        }
        this.f8746l = soundPool.load(context, i2, 1);
        this.f8745k.setOnLoadCompleteListener(new a());
    }

    public void c(int i2) {
        if (i2 != 1) {
            this.H = false;
            this.o = false;
            SoundPool soundPool = this.f8745k;
            if (soundPool != null) {
                soundPool.stop(this.f8747m);
                return;
            }
            return;
        }
        this.H = true;
        if (!this.f8748n || this.o) {
            return;
        }
        SoundPool soundPool2 = this.f8745k;
        if (soundPool2 != null) {
            this.f8747m = soundPool2.play(this.f8746l, 1.0f, 1.0f, 1, -1, 1.0f);
        }
        this.o = true;
    }

    public void d() {
        SoundPool soundPool = this.f8745k;
        if (soundPool != null) {
            soundPool.release();
        }
        this.f8748n = false;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.M.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8742h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8738d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8743i;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8738d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8742h.l());
        jSONObject.put("addressRegister", this.f8742h.c());
        jSONObject.put("addressBit", (int) this.f8742h.a());
        jSONObject.put("typeRequest", (int) this.f8742h.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posSound", getPosSound());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8739e;
    }

    public int getNumScreen() {
        return this.f8743i;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.M;
    }

    public int getPosSound() {
        return this.f8744j;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8742h.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8742h.l() >= 100) {
            this.f8742h.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8742h.c() + "." + ((int) this.f8742h.a());
        }
        this.f8742h.u((byte) MyApplication.b().E.get(this.f8742h.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8742h.b()) + "#" + this.f8742h.c() + "." + ((int) this.f8742h.a());
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8742h.l() >= 0) {
            if (this.f8742h.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8742h.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.L;
    }

    public boolean getValue() {
        return this.H;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.D) {
            this.G.setColor(-65536);
            this.G.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.G);
        }
        if (this.C && mbCanvas.g1) {
            canvas.drawBitmap(this.E, getWidth() - this.E.getWidth(), getHeight() - this.E.getHeight(), this.F);
        }
        if (this.I) {
            this.G.setColor(-16711936);
            this.G.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.G);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.I;
    }

    public void setConnectionError(boolean z) {
        if (this.D != z) {
            this.D = z;
            setVisibility(z ? 0 : 4);
            invalidate();
        }
    }

    public void setConnectionTimeOut(boolean z) {
        if (this.C != z) {
            this.C = z;
            setVisibility(z ? 0 : 4);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.I = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.J = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.K = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8739e = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8743i = i2;
    }

    public void setPosSound(int i2) {
        this.f8744j = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.L = j2;
    }
}
