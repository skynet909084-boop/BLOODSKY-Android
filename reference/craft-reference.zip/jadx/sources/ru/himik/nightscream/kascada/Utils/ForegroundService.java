package ru.himik.nightscream.kascada.Utils;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import com.yandex.metrica.YandexMetrica;
import java.util.concurrent.TimeUnit;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public final class ForegroundService extends Service {
    private final String a = "KaScada Service";
    private final i.b.l.a b;
    private boolean c;

    public ForegroundService() {
        i.b.l.a aVar = new i.b.l.a();
        this.b = aVar;
        n.a.c();
        aVar.c(i.b.c.b(1L, TimeUnit.SECONDS, i.b.r.a.a()).c(new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.g
            @Override // i.b.n.c
            public final void a(Object obj) {
                ForegroundService.a((Long) obj);
            }
        }));
        aVar.c(MyApplication.b().a.h(i.b.r.a.a()).n(i.b.k.b.a.a()).j(new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.h
            @Override // i.b.n.c
            public final void a(Object obj) {
                ForegroundService.b(this.a, (m) obj);
            }
        }, new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.i
            @Override // i.b.n.c
            public final void a(Object obj) {
                ForegroundService.c((Throwable) obj);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void a(Long l2) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void b(final ForegroundService foregroundService, m mVar) {
        i.b.l.a aVar;
        i.b.f<Boolean> fVarE;
        i.b.n.c<? super Boolean> cVar;
        i.b.n.c<? super Throwable> cVar2;
        kotlin.b0.d.j.d(foregroundService, "this$0");
        Log.d("NS", kotlin.b0.d.j.i("ForegroundService.: ", mVar));
        switch (mVar.a()) {
            case 1:
                Log.d("NS", "ForegroundService.: COMMAND_START_SAVE_PROJECT");
                foregroundService.c = true;
                aVar = foregroundService.b;
                fVarE = ru.himik.nightscream.kascada.Bd.h.a.c().e(i.b.k.b.a.a());
                cVar = new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.b
                    @Override // i.b.n.c
                    public final void a(Object obj) {
                        ForegroundService.n(this.a, (Boolean) obj);
                    }
                };
                cVar2 = new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.c
                    @Override // i.b.n.c
                    public final void a(Object obj) {
                        ForegroundService.o(this.a, (Throwable) obj);
                    }
                };
                aVar.c(fVarE.c(cVar, cVar2));
                return;
            case 2:
                foregroundService.c = true;
                aVar = foregroundService.b;
                fVarE = ru.himik.nightscream.kascada.Bd.h.a.c().e(i.b.k.b.a.a());
                cVar = new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.a
                    @Override // i.b.n.c
                    public final void a(Object obj) {
                        ForegroundService.p(this.a, (Boolean) obj);
                    }
                };
                cVar2 = new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.e
                    @Override // i.b.n.c
                    public final void a(Object obj) {
                        ForegroundService.q(this.a, (Throwable) obj);
                    }
                };
                aVar.c(fVarE.c(cVar, cVar2));
                return;
            case 3:
                MyApplication.b().f();
                return;
            case 4:
                MyApplication.b().i();
                return;
            case 5:
                foregroundService.c = true;
                aVar = foregroundService.b;
                fVarE = ru.himik.nightscream.kascada.Bd.h.a.c().e(i.b.k.b.a.a());
                cVar = new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.f
                    @Override // i.b.n.c
                    public final void a(Object obj) {
                        ForegroundService.r(this.a, (Boolean) obj);
                    }
                };
                cVar2 = new i.b.n.c() { // from class: ru.himik.nightscream.kascada.Utils.d
                    @Override // i.b.n.c
                    public final void a(Object obj) {
                        ForegroundService.s(this.a, (Throwable) obj);
                    }
                };
                aVar.c(fVarE.c(cVar, cVar2));
                return;
            case 6:
                MyApplication.b().i();
                break;
            case 7:
                break;
            default:
                return;
        }
        foregroundService.t();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void c(Throwable th) {
        th.printStackTrace();
    }

    private final void d() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(this.a, "KaScada main channel", 4);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            kotlin.b0.d.j.b(notificationManager);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void n(ForegroundService foregroundService, Boolean bool) {
        kotlin.b0.d.j.d(foregroundService, "this$0");
        foregroundService.c = false;
        org.greenrobot.eventbus.c.c().k(new p("SAVE_FINISH"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void o(ForegroundService foregroundService, Throwable th) {
        kotlin.b0.d.j.d(foregroundService, "this$0");
        foregroundService.c = false;
        org.greenrobot.eventbus.c.c().k(new p("SAVE_ERROR"));
        YandexMetrica.reportError("COMMAND_START_SAVE_PROJECT ERROR", kotlin.b0.d.j.i("ForegroundService.: rxSaveBd ERROR: ", th.getMessage()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void p(ForegroundService foregroundService, Boolean bool) {
        kotlin.b0.d.j.d(foregroundService, "this$0");
        foregroundService.c = false;
        MyApplication.b().a();
        org.greenrobot.eventbus.c.c().k(new p("SAVE_FINISH_CLOSE_ACTIVITY"));
        foregroundService.t();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void q(ForegroundService foregroundService, Throwable th) {
        kotlin.b0.d.j.d(foregroundService, "this$0");
        foregroundService.c = false;
        YandexMetrica.reportError("COMMAND_START_SAVE_PROJECT_AND_EXIT ERROR", kotlin.b0.d.j.i("ForegroundService.: rxSaveBd ERROR: ", th.getMessage()));
        MyApplication.b().a();
        org.greenrobot.eventbus.c.c().k(new p("SAVE_FINISH_CLOSE_ACTIVITY"));
        foregroundService.t();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void r(ForegroundService foregroundService, Boolean bool) {
        kotlin.b0.d.j.d(foregroundService, "this$0");
        foregroundService.c = false;
        MyApplication.b().f();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void s(ForegroundService foregroundService, Throwable th) {
        kotlin.b0.d.j.d(foregroundService, "this$0");
        foregroundService.c = false;
        YandexMetrica.reportError("COMMAND_SAVE_PROJECT_AND_START ERROR", kotlin.b0.d.j.i("ForegroundService.: rxSaveBd ERROR: ", th.getMessage()));
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        kotlin.b0.d.j.d(intent, "intent");
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.b.i();
        super.onDestroy();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i2, int i3) {
        if (intent == null) {
            return 2;
        }
        String action = intent.getAction();
        if (!kotlin.b0.d.j.a(action, "ACTION_START_FOREGROUND_SERVICE")) {
            if (!kotlin.b0.d.j.a(action, "ACTION_STOP_FOREGROUND_SERVICE")) {
                return 2;
            }
            t();
            return 2;
        }
        intent.getStringExtra("inputExtra");
        d();
        PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) mbCanvas.class), 0);
        androidx.core.app.h.e eVar = new androidx.core.app.h.e(this, this.a);
        eVar.k("KaScada Service");
        eVar.j("version: 1.0.7");
        eVar.u(R.mipmap.hmi_kascada_modbus_logo);
        startForeground(1, eVar.b());
        return 2;
    }

    public final void t() {
        stopForeground(true);
        stopSelf();
    }
}
