package ru.himik.nightscream.kascada.Logic;

/* JADX INFO: loaded from: classes2.dex */
public class d {
    public int a;
    public int b;

    public d(int i2, int i3) {
        this.a = i2;
        this.b = i3;
    }
}
