package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Connections.Usb.driver.UsbId;
import ru.himik.nightscream.kascada.Logic.c.c;

/* JADX INFO: loaded from: classes2.dex */
public class FB_TIMER extends c {
    private boolean d0;
    int e0;
    int f0;
    int g0;
    long h0;
    boolean i0;
    boolean j0;

    public FB_TIMER(Context context) {
        super(context);
        this.d0 = false;
        this.e0 = 1;
        this.f0 = 1;
        this.g0 = 0;
        this.h0 = 0L;
        this.i0 = false;
        this.j0 = false;
        setName("TON");
        s("IN", 1);
        t("MS", 2);
        u("Q", 1);
    }

    public FB_TIMER(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d0 = false;
        this.e0 = 1;
        this.f0 = 1;
        this.g0 = 0;
        this.h0 = 0L;
        this.i0 = false;
        this.j0 = false;
        setName("TON");
        s("IN", 1);
        t("MS", 2);
        u("Q", 1);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.d0 = false;
        this.i0 = false;
        this.j0 = false;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return;
        }
        try {
            int i2 = this.f0;
            boolean z = true;
            if (i2 == 1) {
                this.g0 = ((Integer) this.f8976h.getOut()).intValue();
            } else if (i2 == 2) {
                this.g0 = ((Integer) this.f8976h.getOut()).intValue() * 1000;
            } else if (i2 == 3) {
                this.g0 = ((Integer) this.f8976h.getOut()).intValue() * UsbId.SILABS_CP2102;
            }
            int i3 = this.e0;
            if (i3 == 1) {
                if (!((Boolean) this.f8975g.getOut()).booleanValue()) {
                    this.i0 = false;
                    this.d0 = false;
                    return;
                }
                if (!this.i0) {
                    this.i0 = true;
                    this.h0 = System.currentTimeMillis();
                }
                if (System.currentTimeMillis() - this.h0 >= this.g0) {
                    this.d0 = z;
                    return;
                }
                return;
            }
            if (i3 != 2) {
                if (i3 == 3) {
                    if (((Boolean) this.f8975g.getOut()).booleanValue()) {
                        if (!this.i0 && !this.j0) {
                            this.i0 = true;
                            this.j0 = true;
                            this.h0 = System.currentTimeMillis();
                        }
                    } else if (!this.d0) {
                        this.j0 = false;
                    }
                    if (System.currentTimeMillis() - this.h0 >= this.g0) {
                        this.d0 = false;
                    }
                } else {
                    if (i3 != 4) {
                        return;
                    }
                    if (!((Boolean) this.f8975g.getOut()).booleanValue()) {
                        this.i0 = false;
                        this.d0 = false;
                        this.j0 = false;
                        return;
                    }
                    if (!this.j0) {
                        this.d0 = true;
                        this.j0 = true;
                    }
                    if (!this.i0) {
                        this.h0 = System.currentTimeMillis();
                        this.i0 = true;
                        return;
                    } else {
                        if (System.currentTimeMillis() - this.h0 < this.g0) {
                            return;
                        }
                        this.i0 = false;
                        if (this.d0) {
                            z = false;
                        }
                    }
                }
                this.d0 = z;
                return;
            }
            if (!((Boolean) this.f8975g.getOut()).booleanValue()) {
                if (!this.i0) {
                    this.i0 = true;
                    this.h0 = System.currentTimeMillis();
                }
                if (System.currentTimeMillis() - this.h0 < this.g0) {
                    return;
                }
                this.d0 = false;
                return;
            }
            this.d0 = true;
            this.i0 = false;
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("type", getTimerType());
        jSONObject.put("typeTime", getTimerTypeTime());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8975g;
        if (aVar == null || this.f8976h == null || aVar.getOut() == null || this.f8976h.getOut() == null) {
            return null;
        }
        return Boolean.valueOf(this.f8973e ? !this.d0 : this.d0);
    }

    public int getTimerType() {
        return this.e0;
    }

    public int getTimerTypeTime() {
        return this.f0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_windowActionBar;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a l(int i2) {
        if (i2 == 1) {
            return this.f8975g;
        }
        if (i2 != 2) {
            return null;
        }
        return this.f8976h;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        this.S.setStyle(Paint.Style.FILL);
        this.S.setColor(-7829368);
        this.S.setStrokeWidth(this.U);
        this.V.set(this.T, this.U, getWidth() - this.T, getHeight() - this.U);
        canvas.drawRect(this.V, this.S);
        this.S.setStyle(Paint.Style.STROKE);
        this.S.setColor(-16777216);
        canvas.drawRect(this.V, this.S);
        this.W.setTextAlign(Paint.Align.CENTER);
        canvas.drawLine(this.T, getHeight() / 3, (getWidth() - this.T) - (this.U / 2), getHeight() / 3, this.S);
        canvas.drawLine(getWidth() / 2, getHeight() / 3, getWidth() / 2, getHeight() - this.U, this.S);
        canvas.drawText(this.L, getWidth() / 2, ((getHeight() / 3) - ((getHeight() / 3) / 2)) + this.a0, this.W);
        if (this.M.length() > 0) {
            String str = this.M;
            int width2 = getWidth() / 2;
            int i2 = this.T;
            canvas.drawText(str, ((width2 - i2) / 2) + i2, ((getHeight() / 3) / 2) + (getHeight() / 3) + this.a0, this.W);
            canvas.drawLine(0.0f, ((getHeight() / 3) / 2) + (getHeight() / 3), this.T, ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        }
        if (this.O.length() > 0) {
            String str2 = this.O;
            int width3 = getWidth() / 2;
            int i3 = this.T;
            canvas.drawText(str2, ((width3 - i3) / 2) + i3, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2) + this.a0, this.W);
            canvas.drawLine(0.0f, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2), this.T, ((getHeight() / 3) / 2) + ((getHeight() / 3) * 2), this.S);
        }
        if (this.Q.length() > 0) {
            canvas.drawText(this.Q, (getWidth() / 2) + (((getWidth() / 2) - this.T) / 2), ((getHeight() / 3) / 2) + (getHeight() / 3) + this.a0, this.W);
            if (this.f8973e && this.R == 1) {
                canvas.drawCircle((getWidth() - this.T) + this.b0, ((getHeight() / 3) / 2) + (getHeight() / 3), this.b0, this.S);
                width = (getWidth() - this.T) + (this.b0 * 2);
            } else {
                width = getWidth() - this.T;
            }
            canvas.drawLine(width, ((getHeight() / 3) / 2) + (getHeight() / 3), getWidth(), ((getHeight() / 3) / 2) + (getHeight() / 3), this.S);
        }
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.c, ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
        String str;
        this.e0 = i2;
        if (i2 == 1) {
            str = "TON";
        } else if (i2 == 2) {
            str = "TOF";
        } else {
            if (i2 != 3) {
                if (i2 == 4) {
                    str = "BLINK";
                }
                invalidate();
            }
            str = "TP";
        }
        setName(str);
        invalidate();
    }

    public void setTypeTime(int i2) {
        String str;
        this.f0 = i2;
        if (i2 == 1) {
            str = "MS";
        } else {
            if (i2 != 2) {
                if (i2 == 3) {
                    str = "MIN";
                }
                invalidate();
            }
            str = "SEK";
        }
        t(str, 2);
        invalidate();
    }
}
