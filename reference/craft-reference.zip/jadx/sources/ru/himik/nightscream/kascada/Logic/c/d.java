package ru.himik.nightscream.kascada.Logic.c;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.CustomComponents.z;
import ru.himik.nightscream.kascada.Logic.FB_MACRO;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class d extends View implements a, ru.himik.nightscream.kascada.s.a, z {
    public int C;
    public int D;
    public int E;
    public boolean F;
    public int G;
    public int H;
    public Paint I;
    public int J;
    public int K;
    public int L;
    private long M;
    String N;
    String O;
    int P;
    String Q;
    int R;
    String S;
    int T;
    String U;
    int V;
    Paint W;
    String a;
    int a0;
    long b;
    int b0;
    public int c;
    RectF c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8983d;
    TextPaint d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f8984e;
    float e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8985f;
    int f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public a f8986g;
    public Point g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public a f8987h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public a f8988i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public a f8989j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f8990k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Point f8991l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Point f8992m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Point f8993n;
    public Point o;

    public d(Context context) {
        super(context);
        this.a = "";
        this.b = 0L;
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width));
        this.f8983d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_height));
        this.f8984e = false;
        this.f8990k = 0;
        this.f8991l = new Point(0, 0);
        this.f8992m = new Point(0, 0);
        this.f8993n = new Point(0, 0);
        this.o = new Point(0, 0);
        this.C = 1;
        this.D = 0;
        this.E = -1;
        this.F = false;
        this.G = 0;
        this.H = 0;
        this.I = new Paint();
        this.J = -1;
        this.K = -1;
        this.L = -1;
        this.M = 0L;
        this.N = IMAPStore.ID_NAME;
        this.O = "";
        this.P = 0;
        this.Q = "";
        this.R = 0;
        this.S = "";
        this.T = 0;
        this.U = "";
        this.V = 0;
        new Paint();
        this.W = new Paint();
        this.a0 = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.b0 = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.c0 = new RectF();
        this.d0 = new TextPaint();
        this.e0 = 0.0f;
        this.f0 = (int) getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.g0 = new Point();
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width));
        this.f8983d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_height));
    }

    public d(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.a = "";
        this.b = 0L;
        this.c = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width));
        this.f8983d = Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_height));
        this.f8984e = false;
        this.f8990k = 0;
        this.f8991l = new Point(0, 0);
        this.f8992m = new Point(0, 0);
        this.f8993n = new Point(0, 0);
        this.o = new Point(0, 0);
        this.C = 1;
        this.D = 0;
        this.E = -1;
        this.F = false;
        this.G = 0;
        this.H = 0;
        this.I = new Paint();
        this.J = -1;
        this.K = -1;
        this.L = -1;
        this.M = 0L;
        this.N = IMAPStore.ID_NAME;
        this.O = "";
        this.P = 0;
        this.Q = "";
        this.R = 0;
        this.S = "";
        this.T = 0;
        this.U = "";
        this.V = 0;
        new Paint();
        this.W = new Paint();
        this.a0 = (int) getResources().getDimension(R.dimen.length_line_root_fb);
        this.b0 = (int) getResources().getDimension(R.dimen.stroke_line_root_fb);
        this.c0 = new RectF();
        this.d0 = new TextPaint();
        this.e0 = 0.0f;
        this.f0 = (int) getResources().getDimension(R.dimen.radius_invert_root_fb);
        this.g0 = new Point();
        try {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{android.R.attr.layout_width, android.R.attr.layout_height});
            this.c = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_width)));
            this.f8983d = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, Math.round(getResources().getDimension(R.dimen.view_var_root_fb_3in_height)));
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void a() {
        a aVar = this.f8986g;
        if (aVar != null) {
            aVar.m();
        }
        a aVar2 = this.f8987h;
        if (aVar2 != null) {
            aVar2.m();
        }
        a aVar3 = this.f8988i;
        if (aVar3 != null) {
            aVar3.m();
        }
        a aVar4 = this.f8989j;
        if (aVar4 != null) {
            aVar4.k(this.f8990k);
        }
    }

    public void b() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void c() {
        a aVar = this.f8989j;
        if (aVar != null) {
            aVar.k(this.f8990k);
            this.f8989j = null;
        }
        this.E = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void d(a aVar, int i2) {
        if (i2 == 1) {
            this.f8986g = aVar;
        }
        if (i2 == 2) {
            this.f8987h = aVar;
        }
        if (i2 == 3) {
            this.f8988i = aVar;
        }
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.g0.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void e(a aVar) {
        this.f8989j = aVar;
        this.E = aVar.getKey();
    }

    public void f() {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean g() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public ru.himik.nightscream.kascada.CustomComponents.b getConnectionInfo() {
        return null;
    }

    public int getCountIn() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCurrentTextColor() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return getTypeFb();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return getNumScreen();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.G;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getFreeIn() {
        if (this.f8986g == null) {
            return 1;
        }
        if (this.f8987h == null) {
            return 2;
        }
        return this.f8988i == null ? 3 : 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return getTypeFb();
    }

    public Object getIn() {
        return null;
    }

    public a getIn1() {
        return this.f8986g;
    }

    public a getIn2() {
        return this.f8987h;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getInvertOut() {
        return this.f8984e;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getJsonMacroOutIfNeed() {
        if (q() == null || q().getTypeFb() != 135) {
            return "";
        }
        FB_MACRO fb_macro = (FB_MACRO) q();
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put(IMAPStore.ID_NAME, fb_macro.getName());
            jSONObject.put("x", (int) fb_macro.getX());
            jSONObject.put("y", (int) fb_macro.getY());
            jSONObject.put("numScreen", fb_macro.getNumScreen());
            return jSONObject.toString();
        } catch (JSONException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public JSONObject getJsonOther() {
        return new JSONObject();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a, ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8985f;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getKeyOut() {
        return this.E;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumOnIn() {
        return this.f8990k;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getNumScreen() {
        return this.C;
    }

    public Object getOut() {
        return null;
    }

    public Point getPointIn1() {
        return null;
    }

    public Point getPointIn2() {
        return this.f8992m;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point getPointOut() {
        return this.o;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.g0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public String getRootNameMacro() {
        return this.a;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public long getRootUniqueIdMacro() {
        return this.b;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdBeforeCopy() {
        return this.J;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveIdOutBeforeCopy() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveKey() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getSaveNumInBeforeCopy() {
        return this.K;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.M;
    }

    public int getTypeFb() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean getVarConstant() {
        return false;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public float getVarFloatConstant() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int getVarIntConstant() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public boolean h() {
        return true;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void i() {
        this.f8984e = !this.f8984e;
        invalidate();
    }

    public void j(int i2, int i3, int i4, boolean z) {
        getLayoutParams().height = this.f8983d;
        getLayoutParams().width = this.c;
        setY(i3 - (this.f8983d / 2));
        setX(i2 - (this.c / 2));
        setBackgroundColor(0);
        setKey(i4);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void k(int i2) {
        if (i2 == 1) {
            this.f8986g = null;
        }
        if (i2 == 2) {
            this.f8987h = null;
        }
        if (i2 == 3) {
            this.f8988i = null;
        }
    }

    public a l(int i2) {
        if (i2 == 1) {
            return this.f8986g;
        }
        if (i2 == 2) {
            return this.f8987h;
        }
        if (i2 != 3) {
            return null;
        }
        return this.f8988i;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void m() {
        this.f8989j = null;
        this.f8990k = 0;
        this.E = -1;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public Point n(int i2) {
        if (i2 == 1) {
            return this.f8991l;
        }
        if (i2 == 2) {
            return this.f8992m;
        }
        return i2 == 3 ? this.f8993n : new Point((int) getX(), (int) getY());
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        if (i2 == 1) {
            return this.P;
        }
        if (i2 == 2) {
            return this.R;
        }
        if (i2 != 3) {
            return 0;
        }
        return this.T;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        this.W.setStyle(Paint.Style.FILL);
        this.W.setColor(-7829368);
        this.W.setStrokeWidth(this.b0);
        this.c0.set(this.a0, this.b0, getWidth() - this.a0, getHeight() - this.b0);
        canvas.drawRect(this.c0, this.W);
        this.W.setStyle(Paint.Style.STROKE);
        this.W.setColor(-16777216);
        canvas.drawRect(this.c0, this.W);
        this.d0.setTextAlign(Paint.Align.CENTER);
        canvas.drawLine(this.a0, getHeight() / 4, (getWidth() - this.a0) - (this.b0 / 2), getHeight() / 4, this.W);
        canvas.drawLine(getWidth() / 2, getHeight() / 4, getWidth() / 2, getHeight() - this.b0, this.W);
        canvas.drawText(this.N, getWidth() / 2, ((getHeight() / 4) - ((getHeight() / 4) / 2)) + this.e0, this.d0);
        if (this.O.length() > 0) {
            String str = this.O;
            int width2 = getWidth() / 2;
            int i2 = this.a0;
            canvas.drawText(str, ((width2 - i2) / 2) + i2, ((getHeight() / 4) / 2) + (getHeight() / 4) + this.e0, this.d0);
            canvas.drawLine(0.0f, ((getHeight() / 4) / 2) + (getHeight() / 4), this.a0, ((getHeight() / 4) / 2) + (getHeight() / 4), this.W);
        }
        if (this.Q.length() > 0) {
            String str2 = this.Q;
            int width3 = getWidth() / 2;
            int i3 = this.a0;
            canvas.drawText(str2, ((width3 - i3) / 2) + i3, ((getHeight() / 4) / 2) + ((getHeight() / 4) * 2) + this.e0, this.d0);
            canvas.drawLine(0.0f, ((getHeight() / 4) / 2) + ((getHeight() / 4) * 2), this.a0, ((getHeight() / 4) / 2) + ((getHeight() / 4) * 2), this.W);
        }
        if (this.S.length() > 0) {
            String str3 = this.S;
            int width4 = getWidth() / 2;
            int i4 = this.a0;
            canvas.drawText(str3, ((width4 - i4) / 2) + i4, ((getHeight() / 4) / 2) + ((getHeight() / 4) * 3) + this.e0, this.d0);
            canvas.drawLine(0.0f, ((getHeight() / 4) / 2) + ((getHeight() / 4) * 3), this.a0, ((getHeight() / 4) / 2) + ((getHeight() / 4) * 3), this.W);
        }
        if (this.U.length() > 0) {
            canvas.drawText(this.U, (getWidth() / 2) + (((getWidth() / 2) - this.a0) / 2), ((getHeight() / 4) / 2) + (getHeight() / 4) + this.e0, this.d0);
            if (this.f8984e && this.V == 1) {
                canvas.drawCircle((getWidth() - this.a0) + this.f0, ((getHeight() / 4) / 2) + (getHeight() / 4), this.f0, this.W);
                width = (getWidth() - this.a0) + (this.f0 * 2);
            } else {
                width = getWidth() - this.a0;
            }
            canvas.drawLine(width, ((getHeight() / 4) / 2) + (getHeight() / 4), getWidth(), ((getHeight() / 4) / 2) + (getHeight() / 4), this.W);
        }
        if (this.F) {
            this.I.setColor(-16711936);
            this.I.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.I);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        this.d0.setTextAlign(Paint.Align.CENTER);
        this.d0.setTextSize(getResources().getDimension(R.dimen.text_size_root_fb_4in));
        this.d0.setColor(getResources().getColor(R.color.text_color_logic));
        this.e0 = ((this.d0.descent() - this.d0.ascent()) / 2.0f) - this.d0.descent();
        setMeasuredDimension(this.c, this.f8983d);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.F;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public a q() {
        return this.f8989j;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void r() {
        this.f8991l.set((int) getX(), ((int) getY()) + ((getHeight() / 4) / 2) + (getHeight() / 4));
        this.f8992m.set((int) getX(), ((int) getY()) + ((getHeight() / 4) / 2) + ((getHeight() / 4) * 2));
        this.f8993n.set((int) getX(), ((int) getY()) + ((getHeight() / 4) / 2) + ((getHeight() / 4) * 3));
        this.o.set(((int) getX()) + getWidth(), ((int) getY()) + ((getHeight() / 4) / 2) + (getHeight() / 4));
    }

    public void s(String str, int i2) {
        this.O = str;
        this.P = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setActionExecute(int i2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.F = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.G = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.H = i2;
    }

    public void setFont(String str) {
    }

    public void setIn(Object obj) {
    }

    public void setInvert(boolean z) {
        this.f8984e = z;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8985f = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setKeyOut(int i2) {
        if (i2 == this.D) {
            i2 = -1;
        }
        this.E = i2;
    }

    public void setName(String str) {
        this.N = str;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setNumOnIn(int i2) {
        this.f8990k = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.C = i2;
    }

    public void setOut(Object obj) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootNameMacro(String str) {
        this.a = str;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setRootUniqueIdMacro(long j2) {
        this.b = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdBeforeCopy(int i2) {
        this.J = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveIdOutBeforeCopy(int i2) {
        this.L = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveKey(int i2) {
        this.D = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setSaveNumInBeforeCopy(int i2) {
        this.K = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.M = j2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarConstant(boolean z) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarFloatConstant(float f2) {
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.a
    public void setVarIntConstant(int i2) {
    }

    public void t(String str, int i2) {
        this.Q = str;
        this.R = i2;
    }

    public void u(String str, int i2) {
        this.S = str;
        this.T = i2;
    }

    public void v(String str, int i2) {
        this.U = str;
        this.V = i2;
    }
}
