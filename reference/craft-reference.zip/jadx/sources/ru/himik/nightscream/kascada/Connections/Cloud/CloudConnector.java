package ru.himik.nightscream.kascada.Connections.Cloud;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import com.karumi.dexter.R;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import kotlin.KotlinVersion;
import org.videolan.libvlc.media.MediaPlayer;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes.dex */
public class CloudConnector extends Thread implements ru.himik.nightscream.kascada.q.a {
    Context M;
    int O;
    String b;
    String c;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    Handler f8623e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f8624f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Socket f8627i;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    SocketAddress f8630l;
    String a = "94.250.249.225";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8622d = 25555;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f8625g = 2;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    boolean f8626h = true;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f8628j = 1000;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f8629k = 2000;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> f8631m = new ArrayList<>();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    int f8632n = 0;
    int o = 0;
    int C = 0;
    public ArrayList<ru.himik.nightscream.kascada.CustomComponents.b> D = new ArrayList<>();
    ru.himik.nightscream.kascada.CustomComponents.b E = null;
    ru.himik.nightscream.kascada.x.a F = new ru.himik.nightscream.kascada.x.a();
    long G = 0;
    long H = 3000;
    int I = 0;
    byte[] J = new byte[KotlinVersion.MAX_COMPONENT_VALUE];
    int K = 0;
    int L = 0;
    boolean N = false;
    private boolean P = false;

    static {
        System.loadLibrary("modbus");
    }

    public CloudConnector(String str, Handler handler, int i2, boolean z, Context context, String str2, int i3) {
        this.b = "000000";
        this.c = "error0";
        this.f8624f = -1;
        this.O = 0;
        this.b = str;
        this.c = str2;
        this.f8623e = handler;
        this.f8624f = i2;
        this.M = context;
        this.O = i3;
    }

    private void g(ru.himik.nightscream.kascada.CustomComponents.b bVar, byte[] bArr) {
        Handler handler;
        int iH;
        int iJ;
        int i2;
        Message messageObtainMessage;
        int i3;
        Integer numValueOf;
        int i4;
        int i5;
        if (bVar == null) {
            return;
        }
        int length = bArr.length;
        int[] iArr = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            iArr[i6] = bArr[i6] & 255;
        }
        byte bQ = bVar.q();
        if (bQ == 1) {
            int iH2 = bVar.h();
            if (iH2 == 19) {
                handler = this.f8623e;
                iH = R.styleable.AppCompatTheme_textAppearanceListItemSecondary;
                iJ = bVar.j();
                i2 = iArr[3];
            } else if (iH2 != 22) {
                handler = this.f8623e;
                iH = bVar.h();
                iJ = bVar.j();
                i2 = iArr[3];
            } else if (bVar.f() > 8) {
                byte[] bArr2 = new byte[2];
                System.arraycopy(bArr, 3, bArr2, 0, 2);
                messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr2);
            } else {
                byte[] bArr3 = new byte[1];
                System.arraycopy(bArr, 3, bArr3, 0, 1);
                messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr3);
            }
            i3 = (i2 >> 0) & 1;
            numValueOf = Integer.valueOf(i3);
            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
        } else if (bQ != 2) {
            if (bQ != 3) {
                if (bQ != 4) {
                    if (bQ != 5 || bVar.h() == 22) {
                        return;
                    }
                    handler = this.f8623e;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i3 = iArr[4];
                    numValueOf = Integer.valueOf(i3);
                    messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                    int[] iArr2 = new int[bVar.g() * 2];
                    System.arraycopy(iArr, 3, iArr2, 0, bVar.g() * 2);
                    messageObtainMessage = this.f8623e.obtainMessage(1, bVar.h(), bVar.j(), iArr2);
                } else {
                    handler = this.f8623e;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i4 = iArr[3] * 256;
                    i5 = iArr[4];
                    numValueOf = Integer.valueOf(i4 + i5);
                    messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                }
            } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                int[] iArr3 = new int[bVar.g() * 2];
                System.arraycopy(iArr, 3, iArr3, 0, bVar.g() * 2);
                messageObtainMessage = this.f8623e.obtainMessage(1, bVar.h(), bVar.j(), iArr3);
            } else {
                handler = this.f8623e;
                iH = bVar.h();
                iJ = bVar.j();
                i4 = iArr[3] * 256;
                i5 = iArr[4];
                numValueOf = Integer.valueOf(i4 + i5);
                messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
            }
        } else if (bVar.h() != 22) {
            handler = this.f8623e;
            iH = bVar.h();
            iJ = bVar.j();
            i2 = iArr[3];
            i3 = (i2 >> 0) & 1;
            numValueOf = Integer.valueOf(i3);
            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
        } else if (bVar.f() > 8) {
            byte[] bArr4 = new byte[2];
            System.arraycopy(bArr, 3, bArr4, 0, 2);
            messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr4);
        } else {
            byte[] bArr5 = new byte[1];
            System.arraycopy(bArr, 3, bArr5, 0, 1);
            messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr5);
        }
        messageObtainMessage.sendToTarget();
    }

    private void h(ru.himik.nightscream.kascada.CustomComponents.b bVar, byte[] bArr) {
        Message messageObtainMessage;
        Handler handler;
        int iH;
        int iJ;
        int i2;
        int i3;
        Integer numValueOf;
        int i4;
        int i5;
        if (bVar == null) {
            return;
        }
        int length = bArr.length;
        int[] iArr = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            iArr[i6] = bArr[i6] & 255;
        }
        if (length >= 10) {
            if (bVar.b() == iArr[6] && bVar.q() == iArr[7]) {
                byte bQ = bVar.q();
                if (bQ == 1) {
                    int iH2 = bVar.h();
                    if (iH2 != 22) {
                        if (iH2 != 102) {
                            handler = this.f8623e;
                            iH = bVar.h();
                            iJ = bVar.j();
                            i2 = iArr[9];
                            i3 = (i2 >> 0) & 1;
                            numValueOf = Integer.valueOf(i3);
                            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                        } else {
                            messageObtainMessage = this.f8623e.obtainMessage(1, R.styleable.AppCompatTheme_textAppearanceListItemSecondary, bVar.j(), Integer.valueOf((iArr[9] >> 0) & 1));
                        }
                    } else if (bVar.f() > 8) {
                        byte[] bArr2 = new byte[2];
                        System.arraycopy(bArr, 9, bArr2, 0, 2);
                        messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr2);
                    } else {
                        byte[] bArr3 = new byte[1];
                        System.arraycopy(bArr, 9, bArr3, 0, 1);
                        messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr3);
                    }
                } else if (bQ != 2) {
                    if (bQ != 3) {
                        if (bQ != 4) {
                            if (bQ != 5 || bVar.h() == 22) {
                                return;
                            }
                            handler = this.f8623e;
                            iH = bVar.h();
                            iJ = bVar.j();
                            i3 = iArr[10];
                            numValueOf = Integer.valueOf(i3);
                            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                        } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                            int[] iArr2 = new int[bVar.g() * 2];
                            System.arraycopy(iArr, 9, iArr2, 0, bVar.g() * 2);
                            messageObtainMessage = this.f8623e.obtainMessage(1, bVar.h(), bVar.j(), iArr2);
                        } else {
                            handler = this.f8623e;
                            iH = bVar.h();
                            iJ = bVar.j();
                            i4 = iArr[9] * 256;
                            i5 = iArr[10];
                            numValueOf = Integer.valueOf(i4 + i5);
                            messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                        }
                    } else if (bVar.h() == 152 || bVar.h() == 153 || bVar.h() == 100 || bVar.h() == 4 || bVar.h() == 8 || bVar.h() == 14 || bVar.h() == 19) {
                        int[] iArr3 = new int[bVar.g() * 2];
                        System.arraycopy(iArr, 9, iArr3, 0, bVar.g() * 2);
                        messageObtainMessage = this.f8623e.obtainMessage(1, bVar.h(), bVar.j(), iArr3);
                    } else {
                        handler = this.f8623e;
                        iH = bVar.h();
                        iJ = bVar.j();
                        i4 = iArr[9] * 256;
                        i5 = iArr[10];
                        numValueOf = Integer.valueOf(i4 + i5);
                        messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                    }
                } else if (bVar.h() != 22 && bVar.h() != 103) {
                    handler = this.f8623e;
                    iH = bVar.h();
                    iJ = bVar.j();
                    i2 = iArr[9];
                    i3 = (i2 >> 0) & 1;
                    numValueOf = Integer.valueOf(i3);
                    messageObtainMessage = handler.obtainMessage(1, iH, iJ, numValueOf);
                } else if (bVar.f() > 8) {
                    byte[] bArr4 = new byte[2];
                    System.arraycopy(bArr, 9, bArr4, 0, 2);
                    messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr4);
                } else {
                    byte[] bArr5 = new byte[1];
                    System.arraycopy(bArr, 9, bArr5, 0, 1);
                    messageObtainMessage = this.f8623e.obtainMessage(1, 22, bVar.j(), bArr5);
                }
            } else if (bVar.b() == 0) {
                return;
            }
            messageObtainMessage.sendToTarget();
        }
        if (bVar.b() == 0) {
            return;
        }
        messageObtainMessage = this.f8623e.obtainMessage(2, bVar.h(), bVar.j());
        messageObtainMessage.sendToTarget();
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public int a() {
        return this.f8624f;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public String b() {
        return this.a + ":" + this.f8622d;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void c(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        if (bVar != null) {
            this.D.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void cancel() {
        this.f8626h = false;
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void d() {
        start();
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void e(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        if (bVar != null) {
            this.D.add(bVar);
        }
    }

    @Override // ru.himik.nightscream.kascada.q.a
    public void f(ru.himik.nightscream.kascada.CustomComponents.b bVar) {
        this.f8631m.add(bVar);
    }

    public native int getSomeValue();

    public native void init(Context context);

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:153:0x02d1 A[Catch: Exception -> 0x03e9, TryCatch #3 {Exception -> 0x03e9, blocks: (B:15:0x0033, B:72:0x0143, B:74:0x0150, B:76:0x0154, B:78:0x016c, B:79:0x0173, B:81:0x0180, B:82:0x0182, B:84:0x018e, B:86:0x019a, B:88:0x01b8, B:89:0x01c1, B:94:0x01d1, B:140:0x029d, B:142:0x02a1, B:144:0x02a9, B:147:0x02b3, B:149:0x02b7, B:150:0x02c5, B:152:0x02cd, B:153:0x02d1, B:154:0x02d4, B:155:0x02d7, B:158:0x02e1, B:160:0x02e5, B:161:0x02e8, B:162:0x02f6, B:164:0x02fe, B:165:0x0303, B:167:0x0309, B:169:0x0312, B:171:0x031d, B:174:0x0329, B:95:0x01d8, B:97:0x01dc, B:99:0x01ee, B:101:0x01f8, B:103:0x01fc, B:104:0x01ff, B:106:0x0206, B:107:0x020b, B:112:0x0217, B:114:0x0221, B:120:0x023b, B:122:0x0243, B:124:0x024a, B:125:0x0250, B:128:0x0256, B:130:0x0276, B:131:0x027f, B:136:0x028f, B:138:0x0296, B:139:0x029b, B:116:0x0229, B:118:0x0233, B:175:0x032d, B:184:0x0364, B:186:0x0368, B:190:0x03c6, B:192:0x03cf, B:193:0x03d5, B:195:0x03d9, B:197:0x03df), top: B:226:0x0033 }] */
    /* JADX WARN: Code duplicated, block: B:154:0x02d4 A[Catch: Exception -> 0x03e9, TryCatch #3 {Exception -> 0x03e9, blocks: (B:15:0x0033, B:72:0x0143, B:74:0x0150, B:76:0x0154, B:78:0x016c, B:79:0x0173, B:81:0x0180, B:82:0x0182, B:84:0x018e, B:86:0x019a, B:88:0x01b8, B:89:0x01c1, B:94:0x01d1, B:140:0x029d, B:142:0x02a1, B:144:0x02a9, B:147:0x02b3, B:149:0x02b7, B:150:0x02c5, B:152:0x02cd, B:153:0x02d1, B:154:0x02d4, B:155:0x02d7, B:158:0x02e1, B:160:0x02e5, B:161:0x02e8, B:162:0x02f6, B:164:0x02fe, B:165:0x0303, B:167:0x0309, B:169:0x0312, B:171:0x031d, B:174:0x0329, B:95:0x01d8, B:97:0x01dc, B:99:0x01ee, B:101:0x01f8, B:103:0x01fc, B:104:0x01ff, B:106:0x0206, B:107:0x020b, B:112:0x0217, B:114:0x0221, B:120:0x023b, B:122:0x0243, B:124:0x024a, B:125:0x0250, B:128:0x0256, B:130:0x0276, B:131:0x027f, B:136:0x028f, B:138:0x0296, B:139:0x029b, B:116:0x0229, B:118:0x0233, B:175:0x032d, B:184:0x0364, B:186:0x0368, B:190:0x03c6, B:192:0x03cf, B:193:0x03d5, B:195:0x03d9, B:197:0x03df), top: B:226:0x0033 }] */
    /* JADX WARN: Code duplicated, block: B:160:0x02e5 A[Catch: Exception -> 0x03e9, TryCatch #3 {Exception -> 0x03e9, blocks: (B:15:0x0033, B:72:0x0143, B:74:0x0150, B:76:0x0154, B:78:0x016c, B:79:0x0173, B:81:0x0180, B:82:0x0182, B:84:0x018e, B:86:0x019a, B:88:0x01b8, B:89:0x01c1, B:94:0x01d1, B:140:0x029d, B:142:0x02a1, B:144:0x02a9, B:147:0x02b3, B:149:0x02b7, B:150:0x02c5, B:152:0x02cd, B:153:0x02d1, B:154:0x02d4, B:155:0x02d7, B:158:0x02e1, B:160:0x02e5, B:161:0x02e8, B:162:0x02f6, B:164:0x02fe, B:165:0x0303, B:167:0x0309, B:169:0x0312, B:171:0x031d, B:174:0x0329, B:95:0x01d8, B:97:0x01dc, B:99:0x01ee, B:101:0x01f8, B:103:0x01fc, B:104:0x01ff, B:106:0x0206, B:107:0x020b, B:112:0x0217, B:114:0x0221, B:120:0x023b, B:122:0x0243, B:124:0x024a, B:125:0x0250, B:128:0x0256, B:130:0x0276, B:131:0x027f, B:136:0x028f, B:138:0x0296, B:139:0x029b, B:116:0x0229, B:118:0x0233, B:175:0x032d, B:184:0x0364, B:186:0x0368, B:190:0x03c6, B:192:0x03cf, B:193:0x03d5, B:195:0x03d9, B:197:0x03df), top: B:226:0x0033 }] */
    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        Socket socket;
        System.currentTimeMillis();
        this.f8630l = new InetSocketAddress(this.a, this.f8622d);
        this.f8632n = this.f8631m.size();
        InputStream inputStream = null;
        OutputStream outputStream = null;
        do {
            char c = 0;
            while (true) {
                if (!this.f8626h) {
                    try {
                        Socket socket2 = this.f8627i;
                        if (socket2 != null) {
                            socket2.close();
                        }
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        if (outputStream != null) {
                            outputStream.close();
                            return;
                        }
                        return;
                    } catch (IOException unused) {
                        return;
                    }
                }
                if (c != 0) {
                    if (c != 1) {
                        char c2 = 3;
                        if (c == 2) {
                            if (System.currentTimeMillis() - this.G >= 1500) {
                                this.P = true;
                            }
                            if (this.D.size() > 0) {
                                ru.himik.nightscream.kascada.CustomComponents.b bVar = this.D.get(0);
                                this.E = bVar;
                                if (outputStream != null) {
                                    try {
                                        outputStream.write(this.F.c(bVar, this.f8625g));
                                        outputStream.flush();
                                        byte[] bArrC = this.F.c(this.E, this.f8625g);
                                        int length = bArrC.length;
                                        int[] iArr = new int[length];
                                        for (int i2 = 0; i2 < length; i2++) {
                                            iArr[i2] = bArrC[i2] & 255;
                                        }
                                        this.K++;
                                        this.G = System.currentTimeMillis();
                                    } catch (IOException unused2) {
                                        c = 4;
                                    }
                                } else {
                                    c2 = 4;
                                }
                                c = c2;
                                this.D.remove(0);
                            } else if (this.f8632n > 0) {
                                ru.himik.nightscream.kascada.CustomComponents.b bVar2 = this.f8631m.get(this.o);
                                this.E = bVar2;
                                if (bVar2.m() > 0 && mbCanvas.a1 != this.E.m()) {
                                    if (this.P) {
                                        this.P = false;
                                    } else {
                                        int i3 = this.o;
                                        if (i3 != this.f8632n - 1) {
                                            this.o = i3 + 1;
                                        } else {
                                            this.o = 0;
                                        }
                                        try {
                                            Thread.sleep(1L);
                                        } catch (Exception unused3) {
                                        }
                                    }
                                }
                                if (!((this.E.h() == 19 && this.E.q() == 16) || (this.E.h() == 22 && this.E.q() == 15)) || this.E.s()) {
                                    if (outputStream != null) {
                                        try {
                                            outputStream.write(this.F.c(this.E, this.f8625g));
                                            outputStream.flush();
                                            byte[] bArrC2 = this.F.c(this.E, this.f8625g);
                                            int length2 = bArrC2.length;
                                            int[] iArr2 = new int[length2];
                                            for (int i4 = 0; i4 < length2; i4++) {
                                                iArr2[i4] = bArrC2[i4] & 255;
                                            }
                                            this.K++;
                                            this.G = System.currentTimeMillis();
                                        } catch (IOException unused4) {
                                            c = 4;
                                        }
                                    } else {
                                        c2 = 4;
                                    }
                                    c = c2;
                                    int i5 = this.o;
                                    if (i5 != this.f8632n - 1) {
                                        this.o = i5 + 1;
                                    } else {
                                        this.o = 0;
                                    }
                                } else {
                                    int i6 = this.o;
                                    if (i6 != this.f8632n - 1) {
                                        this.o = i6 + 1;
                                    } else {
                                        this.o = 0;
                                    }
                                }
                            }
                            ru.himik.nightscream.kascada.CustomComponents.b bVar3 = this.E;
                            if (bVar3 != null) {
                                if (bVar3.r()) {
                                    byte bQ = this.E.q();
                                    if (bQ == 15) {
                                        this.C = 8;
                                    } else if (bQ != 16) {
                                        switch (bQ) {
                                            case 1:
                                            case 2:
                                                if (this.E.f() > 8) {
                                                    this.C = 7;
                                                } else {
                                                    this.C = 6;
                                                }
                                                break;
                                            case 3:
                                            case 4:
                                                this.C = (this.E.g() * 2) + 5;
                                                break;
                                            case 5:
                                            case 6:
                                                this.C = 8;
                                                break;
                                        }
                                    } else {
                                        this.C = 6;
                                    }
                                } else {
                                    byte bQ2 = this.E.q();
                                    if (bQ2 != 16) {
                                        switch (bQ2) {
                                            case 1:
                                            case 2:
                                                if (this.E.f() > 8) {
                                                    this.C = 11;
                                                } else {
                                                    this.C = 10;
                                                }
                                                break;
                                            case 3:
                                            case 4:
                                                this.C = (this.E.g() * 2) + 9;
                                                break;
                                            case 5:
                                            case 6:
                                                this.C = 10;
                                                break;
                                        }
                                    } else {
                                        this.C = 12;
                                    }
                                }
                            }
                            try {
                                Thread.sleep(10L);
                                if (this.K % MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK == 0) {
                                    init(this.M);
                                    if (getSomeValue() == 0) {
                                        this.f8627i.close();
                                        Thread.sleep(5000L);
                                    }
                                }
                            } catch (InterruptedException unused5) {
                                c = 4;
                            }
                            this.I = 0;
                        } else if (c == 3) {
                            try {
                                int iAvailable = inputStream.available();
                                byte[] bArr = new byte[30];
                                if (iAvailable > 0) {
                                    inputStream.read(this.J);
                                    System.arraycopy(this.J, 0, bArr, this.I, iAvailable);
                                    this.I += iAvailable;
                                    if (!this.E.r()) {
                                        int i7 = this.I;
                                        int i8 = this.C;
                                        if (i7 == i8) {
                                            this.L++;
                                            h(this.E, bArr);
                                            int i9 = this.O;
                                            if (i9 > 0) {
                                                Thread.sleep(i9);
                                            }
                                            if (!this.N) {
                                                this.f8623e.obtainMessage(6, 1, this.f8624f).sendToTarget();
                                                this.N = true;
                                            }
                                            c = 2;
                                        } else if (i7 > i8) {
                                            int[] iArr3 = new int[30];
                                            for (int i10 = 0; i10 < 30; i10++) {
                                                iArr3[i10] = bArr[i10] & 255;
                                            }
                                            int i11 = this.O;
                                            if (i11 > 0) {
                                                Thread.sleep(i11);
                                            }
                                            if (!this.N) {
                                                this.f8623e.obtainMessage(6, 1, this.f8624f).sendToTarget();
                                                this.N = true;
                                            }
                                            c = 2;
                                        }
                                    } else if (this.I == this.C && bArr[0] == this.E.b() && bArr[1] == this.E.q()) {
                                        this.L++;
                                        g(this.E, bArr);
                                        this.I = 0;
                                        int i12 = this.O;
                                        if (i12 > 0) {
                                            Thread.sleep(i12);
                                        }
                                        if (!this.N) {
                                            this.f8623e.obtainMessage(6, 1, this.f8624f).sendToTarget();
                                            this.N = true;
                                        }
                                        c = 2;
                                    } else if (this.I > this.C || bArr[0] == this.E.b() || bArr[1] == this.E.q()) {
                                        int[] iArr4 = new int[30];
                                        for (int i13 = 0; i13 < 30; i13++) {
                                            iArr4[i13] = bArr[i13] & 255;
                                        }
                                        this.I = 0;
                                        int i14 = this.O;
                                        if (i14 > 0) {
                                            Thread.sleep(i14);
                                        }
                                        if (!this.N) {
                                            this.f8623e.obtainMessage(6, 1, this.f8624f).sendToTarget();
                                            this.N = true;
                                        }
                                        c = 2;
                                    }
                                }
                            } catch (Exception unused6) {
                                c = 4;
                            }
                            if (System.currentTimeMillis() - this.G >= this.H) {
                                if (!this.f8626h) {
                                    return;
                                }
                                this.f8627i.close();
                                this.f8627i = null;
                                this.f8623e.obtainMessage(6, 4, this.f8624f).sendToTarget();
                                Thread.sleep(500L);
                                c = 0;
                            }
                            Thread.sleep(10L);
                        } else if (c != 4) {
                            continue;
                        } else {
                            try {
                                this.o = 0;
                                this.f8623e.obtainMessage(6, 4, this.f8624f).sendToTarget();
                                Thread.sleep(this.f8628j);
                            } catch (Exception unused7) {
                                this.f8623e.obtainMessage(6, 4, this.f8624f).sendToTarget();
                                try {
                                    Socket socket3 = this.f8627i;
                                    if (socket3 != null) {
                                        socket3.close();
                                    }
                                    if (inputStream != null) {
                                        inputStream.close();
                                    }
                                    if (outputStream != null) {
                                        outputStream.close();
                                    }
                                } catch (IOException unused8) {
                                }
                                c = 4;
                            }
                        }
                    } else {
                        this.N = false;
                        try {
                            try {
                                this.f8627i.connect(this.f8630l, this.f8628j);
                                this.f8627i.setSoTimeout(this.f8629k);
                                inputStream = this.f8627i.getInputStream();
                                outputStream = this.f8627i.getOutputStream();
                            } catch (Exception unused9) {
                                Thread.sleep(this.f8628j);
                                this.f8627i.close();
                                this.f8627i = null;
                                if (inputStream != null) {
                                    inputStream.close();
                                }
                                if (outputStream != null) {
                                    outputStream.close();
                                }
                                c = 4;
                                socket = this.f8627i;
                                if (socket == null) {
                                }
                            }
                        } catch (Exception unused10) {
                            c = 4;
                        }
                        socket = this.f8627i;
                        if (socket == null && socket.isConnected()) {
                            try {
                                int length3 = (byte) (this.c.getBytes().length + this.b.getBytes().length + 2);
                                byte[] bArr2 = new byte[length3];
                                bArr2[0] = length3;
                                bArr2[1] = (byte) this.c.getBytes().length;
                                System.arraycopy(this.c.getBytes(), 0, bArr2, 2, (byte) this.c.getBytes().length);
                                System.arraycopy(this.b.getBytes(), 0, bArr2, this.c.getBytes().length + 2, (byte) this.b.getBytes().length);
                                outputStream.write(bArr2);
                                outputStream.flush();
                                Thread.sleep(500L);
                            } catch (Exception unused11) {
                            }
                            c = 2;
                        }
                    }
                } else if (this.c.length() <= 2) {
                    Thread.sleep(3000L);
                    c = 4;
                } else {
                    Socket socket4 = this.f8627i;
                    if (socket4 == null || !socket4.isConnected()) {
                        this.f8627i = new Socket();
                    }
                    c = 1;
                }
            }
        } while (this.f8626h);
    }
}
