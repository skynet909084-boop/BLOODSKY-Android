package ru.himik.nightscream.kascada.Bd.Export;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.yandex.metrica.YandexMetrica;
import f.f.b.e;
import java.io.Closeable;
import java.io.File;
import kotlin.a0.c;
import kotlin.b0.c.p;
import kotlin.b0.d.g;
import kotlin.b0.d.j;
import kotlin.n;
import kotlin.u;
import kotlin.y.d;
import kotlin.y.j.a.f;
import kotlin.y.j.a.l;
import kotlinx.coroutines.b1;
import kotlinx.coroutines.f2;
import kotlinx.coroutines.h0;
import kotlinx.coroutines.i;
import kotlinx.coroutines.m0;
import kotlinx.coroutines.n1;
import kotlinx.coroutines.x0;
import l.a0;
import l.b0;
import l.c0;
import l.e0;
import l.f0;
import l.g0;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.Utils.q;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public final class ExportPresenter {
    public static final Companion Companion = new Companion(null);
    public static final String URL_UPLOAD_PROJECT_FILE = "upload.php";
    public static final String URL_UPLOAD_PROJECT_FILES_DIR = "http://kascada-cloud.fvds.ru/projects/files/";
    public static final String URL_UPLOAD_PROJECT_SCRIPT_DIR = "http://kascada-cloud.fvds.ru/projects/";
    public InterfaceCallbackExport interfaceCallbackExport;

    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(g gVar) {
            this();
        }
    }

    public static final class ResponseUploadProject {
        private String error;
        private String success;
        private String url;

        public ResponseUploadProject() {
            this(null, null, null, 7, null);
        }

        public ResponseUploadProject(String str, String str2, String str3) {
            j.d(str, "error");
            j.d(str2, "success");
            j.d(str3, "url");
            this.error = str;
            this.success = str2;
            this.url = str3;
        }

        public /* synthetic */ ResponseUploadProject(String str, String str2, String str3, int i2, g gVar) {
            this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? "" : str2, (i2 & 4) != 0 ? "" : str3);
        }

        public static /* synthetic */ ResponseUploadProject copy$default(ResponseUploadProject responseUploadProject, String str, String str2, String str3, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                str = responseUploadProject.error;
            }
            if ((i2 & 2) != 0) {
                str2 = responseUploadProject.success;
            }
            if ((i2 & 4) != 0) {
                str3 = responseUploadProject.url;
            }
            return responseUploadProject.copy(str, str2, str3);
        }

        public final String component1() {
            return this.error;
        }

        public final String component2() {
            return this.success;
        }

        public final String component3() {
            return this.url;
        }

        public final ResponseUploadProject copy(String str, String str2, String str3) {
            j.d(str, "error");
            j.d(str2, "success");
            j.d(str3, "url");
            return new ResponseUploadProject(str, str2, str3);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof ResponseUploadProject)) {
                return false;
            }
            ResponseUploadProject responseUploadProject = (ResponseUploadProject) obj;
            return j.a(this.error, responseUploadProject.error) && j.a(this.success, responseUploadProject.success) && j.a(this.url, responseUploadProject.url);
        }

        public final String getError() {
            return this.error;
        }

        public final String getSuccess() {
            return this.success;
        }

        public final String getUrl() {
            return this.url;
        }

        public int hashCode() {
            return (((this.error.hashCode() * 31) + this.success.hashCode()) * 31) + this.url.hashCode();
        }

        public final void setError(String str) {
            j.d(str, "<set-?>");
            this.error = str;
        }

        public final void setSuccess(String str) {
            j.d(str, "<set-?>");
            this.success = str;
        }

        public final void setUrl(String str) {
            j.d(str, "<set-?>");
            this.url = str;
        }

        public String toString() {
            return "ResponseUploadProject(error=" + this.error + ", success=" + this.success + ", url=" + this.url + ')';
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1, reason: invalid class name */
    @f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1", f = "ExportPresenter.kt", l = {43}, m = "invokeSuspend")
    static final class AnonymousClass1 extends l implements p<m0, d<? super u>, Object> {
        final /* synthetic */ File $sourceFolder;
        final /* synthetic */ boolean $upload;
        final /* synthetic */ String $zipName;
        int label;
        final /* synthetic */ ExportPresenter this$0;

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1$1, reason: invalid class name and collision with other inner class name */
        @f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1$1", f = "ExportPresenter.kt", l = {47, 59}, m = "invokeSuspend")
        static final class C02811 extends l implements p<m0, d<? super u>, Object> {
            final /* synthetic */ File $sourceFolder;
            final /* synthetic */ boolean $upload;
            final /* synthetic */ String $zipName;
            int label;
            final /* synthetic */ ExportPresenter this$0;

            /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1$1$1, reason: invalid class name and collision with other inner class name */
            @f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1$1$1", f = "ExportPresenter.kt", l = {}, m = "invokeSuspend")
            static final class C02821 extends l implements p<m0, d<? super u>, Object> {
                final /* synthetic */ boolean $upload;
                final /* synthetic */ k.a.a.a $zip;
                final /* synthetic */ String $zipName;
                int label;
                final /* synthetic */ ExportPresenter this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                C02821(boolean z, ExportPresenter exportPresenter, k.a.a.a aVar, String str, d<? super C02821> dVar) {
                    super(2, dVar);
                    this.$upload = z;
                    this.this$0 = exportPresenter;
                    this.$zip = aVar;
                    this.$zipName = str;
                }

                @Override // kotlin.y.j.a.a
                public final d<u> create(Object obj, d<?> dVar) {
                    return new C02821(this.$upload, this.this$0, this.$zip, this.$zipName, dVar);
                }

                @Override // kotlin.b0.c.p
                public final Object invoke(m0 m0Var, d<? super u> dVar) {
                    return ((C02821) create(m0Var, dVar)).invokeSuspend(u.a);
                }

                @Override // kotlin.y.j.a.a
                public final Object invokeSuspend(Object obj) throws Throwable {
                    kotlin.y.i.d.c();
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    n.b(obj);
                    if (this.$upload) {
                        this.this$0.onClickQr(this.$zip);
                    } else {
                        this.this$0.getInterfaceCallbackExport().showFileCreated(this.$zipName);
                    }
                    return u.a;
                }
            }

            /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1$1$2, reason: invalid class name */
            @f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$createZip_$1$1$2", f = "ExportPresenter.kt", l = {}, m = "invokeSuspend")
            static final class AnonymousClass2 extends l implements p<m0, d<? super u>, Object> {
                int label;
                final /* synthetic */ ExportPresenter this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnonymousClass2(ExportPresenter exportPresenter, d<? super AnonymousClass2> dVar) {
                    super(2, dVar);
                    this.this$0 = exportPresenter;
                }

                @Override // kotlin.y.j.a.a
                public final d<u> create(Object obj, d<?> dVar) {
                    return new AnonymousClass2(this.this$0, dVar);
                }

                @Override // kotlin.b0.c.p
                public final Object invoke(m0 m0Var, d<? super u> dVar) {
                    return ((AnonymousClass2) create(m0Var, dVar)).invokeSuspend(u.a);
                }

                @Override // kotlin.y.j.a.a
                public final Object invokeSuspend(Object obj) throws Throwable {
                    kotlin.y.i.d.c();
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    n.b(obj);
                    this.this$0.getInterfaceCallbackExport().showError(MyApplication.b().h0.getString(R.string.error_while_creating_the_archive));
                    return u.a;
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C02811(String str, File file, boolean z, ExportPresenter exportPresenter, d<? super C02811> dVar) {
                super(2, dVar);
                this.$zipName = str;
                this.$sourceFolder = file;
                this.$upload = z;
                this.this$0 = exportPresenter;
            }

            @Override // kotlin.y.j.a.a
            public final d<u> create(Object obj, d<?> dVar) {
                return new C02811(this.$zipName, this.$sourceFolder, this.$upload, this.this$0, dVar);
            }

            @Override // kotlin.b0.c.p
            public final Object invoke(m0 m0Var, d<? super u> dVar) {
                return ((C02811) create(m0Var, dVar)).invokeSuspend(u.a);
            }

            @Override // kotlin.y.j.a.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                Object objC = kotlin.y.i.d.c();
                int i2 = this.label;
                try {
                    if (i2 != 0) {
                        if (i2 == 1) {
                            n.b(obj);
                        } else {
                            if (i2 != 2) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            n.b(obj);
                        }
                        return u.a;
                    }
                    n.b(obj);
                    k.a.a.a aVar = new k.a.a.a(this.$zipName);
                    aVar.a(this.$sourceFolder);
                    f2 f2VarC = b1.c();
                    C02821 c02821 = new C02821(this.$upload, this.this$0, aVar, this.$zipName, null);
                    this.label = 1;
                    if (kotlinx.coroutines.g.h(f2VarC, c02821, this) == objC) {
                        return objC;
                    }
                } catch (k.a.a.c.a e2) {
                    Log.d("NS", j.i("ExportPresenter.createZip_: ERROR ", e2.getMessage()));
                    e2.printStackTrace();
                    YandexMetrica.reportError("Произошла ошибка при создании архива", e2);
                    f2 f2VarC2 = b1.c();
                    AnonymousClass2 anonymousClass2 = new AnonymousClass2(this.this$0, null);
                    this.label = 2;
                    if (kotlinx.coroutines.g.h(f2VarC2, anonymousClass2, this) == objC) {
                        return objC;
                    }
                }
                return u.a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(String str, File file, boolean z, ExportPresenter exportPresenter, d<? super AnonymousClass1> dVar) {
            super(2, dVar);
            this.$zipName = str;
            this.$sourceFolder = file;
            this.$upload = z;
            this.this$0 = exportPresenter;
        }

        @Override // kotlin.y.j.a.a
        public final d<u> create(Object obj, d<?> dVar) {
            return new AnonymousClass1(this.$zipName, this.$sourceFolder, this.$upload, this.this$0, dVar);
        }

        @Override // kotlin.b0.c.p
        public final Object invoke(m0 m0Var, d<? super u> dVar) {
            return ((AnonymousClass1) create(m0Var, dVar)).invokeSuspend(u.a);
        }

        @Override // kotlin.y.j.a.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object objC = kotlin.y.i.d.c();
            int i2 = this.label;
            if (i2 == 0) {
                n.b(obj);
                h0 h0VarB = b1.b();
                C02811 c02811 = new C02811(this.$zipName, this.$sourceFolder, this.$upload, this.this$0, null);
                this.label = 1;
                if (kotlinx.coroutines.g.h(h0VarB, c02811, this) == objC) {
                    return objC;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                n.b(obj);
            }
            return u.a;
        }
    }

    /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$uploadProjectToServer$1, reason: invalid class name and case insensitive filesystem */
    @f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$uploadProjectToServer$1", f = "ExportPresenter.kt", l = {com.karumi.dexter.R.styleable.AppCompatTheme_listPreferredItemPaddingEnd}, m = "invokeSuspend")
    static final class C09981 extends l implements p<m0, d<? super u>, Object> {
        final /* synthetic */ File $file;
        final /* synthetic */ String $licenseKey;
        final /* synthetic */ String $url;
        int label;
        final /* synthetic */ ExportPresenter this$0;

        /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$uploadProjectToServer$1$1, reason: invalid class name and collision with other inner class name */
        @f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$uploadProjectToServer$1$1", f = "ExportPresenter.kt", l = {com.karumi.dexter.R.styleable.AppCompatTheme_listPreferredItemPaddingLeft, com.karumi.dexter.R.styleable.AppCompatTheme_tooltipFrameBackground, com.karumi.dexter.R.styleable.AppCompatTheme_windowFixedHeightMajor, com.karumi.dexter.R.styleable.AppCompatTheme_windowMinWidthMajor, 145}, m = "invokeSuspend")
        static final class C02831 extends l implements p<m0, d<? super u>, Object> {
            final /* synthetic */ File $file;
            final /* synthetic */ String $licenseKey;
            final /* synthetic */ String $url;
            Object L$0;
            int label;
            final /* synthetic */ ExportPresenter this$0;

            /* JADX INFO: renamed from: ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$uploadProjectToServer$1$1$2, reason: invalid class name */
            @f(c = "ru.himik.nightscream.kascada.Bd.Export.ExportPresenter$uploadProjectToServer$1$1$2", f = "ExportPresenter.kt", l = {}, m = "invokeSuspend")
            static final class AnonymousClass2 extends l implements p<m0, d<? super u>, Object> {
                int label;
                final /* synthetic */ ExportPresenter this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnonymousClass2(ExportPresenter exportPresenter, d<? super AnonymousClass2> dVar) {
                    super(2, dVar);
                    this.this$0 = exportPresenter;
                }

                @Override // kotlin.y.j.a.a
                public final d<u> create(Object obj, d<?> dVar) {
                    return new AnonymousClass2(this.this$0, dVar);
                }

                @Override // kotlin.b0.c.p
                public final Object invoke(m0 m0Var, d<? super u> dVar) {
                    return ((AnonymousClass2) create(m0Var, dVar)).invokeSuspend(u.a);
                }

                @Override // kotlin.y.j.a.a
                public final Object invokeSuspend(Object obj) throws Throwable {
                    kotlin.y.i.d.c();
                    if (this.label != 0) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    n.b(obj);
                    this.this$0.getInterfaceCallbackExport().showError("Произошла непредвиденная ошибка");
                    return u.a;
                }
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C02831(String str, File file, String str2, ExportPresenter exportPresenter, d<? super C02831> dVar) {
                super(2, dVar);
                this.$licenseKey = str;
                this.$file = file;
                this.$url = str2;
                this.this$0 = exportPresenter;
            }

            @Override // kotlin.y.j.a.a
            public final d<u> create(Object obj, d<?> dVar) {
                return new C02831(this.$licenseKey, this.$file, this.$url, this.this$0, dVar);
            }

            @Override // kotlin.b0.c.p
            public final Object invoke(m0 m0Var, d<? super u> dVar) {
                return ((C02831) create(m0Var, dVar)).invokeSuspend(u.a);
            }

            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r1v0, types: [int] */
            /* JADX WARN: Type inference failed for: r1v19 */
            /* JADX WARN: Type inference failed for: r1v20 */
            /* JADX WARN: Type inference failed for: r1v21 */
            /* JADX WARN: Type inference failed for: r1v22 */
            /* JADX WARN: Type inference failed for: r1v3, types: [java.io.Closeable] */
            /* JADX WARN: Type inference failed for: r1v8, types: [java.io.Closeable] */
            @Override // kotlin.y.j.a.a
            public final Object invokeSuspend(Object obj) throws Throwable {
                Exception exc;
                Object objC = kotlin.y.i.d.c();
                ?? r1 = this.label;
                int i2 = 1;
                l.l0.a.b bVar = null;
                boolean z = false;
                boolean z2 = false;
                boolean z3 = false;
                try {
                    try {
                        if (r1 != 0) {
                            if (r1 == 1) {
                                n.b(obj);
                            } else {
                                if (r1 != 2 && r1 != 3 && r1 != 4) {
                                    if (r1 != 5) {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    exc = (Exception) this.L$0;
                                    n.b(obj);
                                    exc.printStackTrace();
                                    YandexMetrica.reportError("Ошибка при отправке zip на сервер", exc);
                                    Log.d("NS", j.i("ExportPresenter.upload: ERROR ", exc.getMessage()));
                                    return u.a;
                                }
                                Closeable closeable = (Closeable) this.L$0;
                                n.b(obj);
                                r1 = closeable;
                            }
                            r1 = g0VarF;
                            r1 = g0VarF;
                            r1 = g0VarF;
                            u uVar = u.a;
                            c.a(r1, null);
                            return u.a;
                        }
                        n.b(obj);
                        this.label = 1;
                        if (x0.a(1000L, this) == objC) {
                            return objC;
                        }
                        a0 a0VarA = a0.f7854f.a("application/zip");
                        l.l0.a aVar = new l.l0.a(bVar, i2, z3 ? 1 : 0);
                        aVar.c(l.l0.a.EnumC0268a.HEADERS);
                        c0.a aVar2 = new c0.a();
                        aVar2.a(aVar);
                        c0 c0VarB = aVar2.b();
                        b0.a aVar3 = new b0.a(z2 ? 1 : 0, i2, z ? 1 : 0);
                        aVar3.e(b0.f7856h);
                        String lowerCase = this.$licenseKey.toLowerCase();
                        j.c(lowerCase, "this as java.lang.String).toLowerCase()");
                        aVar3.a("licenseKey", lowerCase);
                        aVar3.b("file", this.$file.getName(), f0.a.a(this.$file, a0VarA));
                        b0 b0VarD = aVar3.d();
                        e0.a aVar4 = new e0.a();
                        aVar4.g(this.$url);
                        aVar4.e(b0VarD);
                        g0 g0VarF = c0VarB.y(aVar4.a()).f();
                        ExportPresenter exportPresenter = this.this$0;
                        if (!g0VarF.z()) {
                            Log.d("NS", j.i("ExportPresenter.uploadProjectToServer: ERROR ", g0VarF));
                        }
                        l.h0 h0VarA = g0VarF.a();
                        String strValueOf = String.valueOf(h0VarA == null ? null : h0VarA.g());
                        Log.d("NS", j.i("ExportPresenter.uploadProjectToServer: ОТВЕТ ", strValueOf));
                        ResponseUploadProject responseUploadProject = (ResponseUploadProject) new e().i(strValueOf, ResponseUploadProject.class);
                        Log.d("NS", j.i("ExportPresenter.uploadProjectToServer: ", responseUploadProject));
                        if (responseUploadProject.getError().length() > 0) {
                            f2 f2VarC = b1.c();
                            ExportPresenter$uploadProjectToServer$1$1$1$1 exportPresenter$uploadProjectToServer$1$1$1$1 = new ExportPresenter$uploadProjectToServer$1$1$1$1(exportPresenter, responseUploadProject, null);
                            this.L$0 = g0VarF;
                            this.label = 2;
                            if (kotlinx.coroutines.g.h(f2VarC, exportPresenter$uploadProjectToServer$1$1$1$1, this) == objC) {
                                r1 = g0VarF;
                                return objC;
                            }
                        } else {
                            if (responseUploadProject.getUrl().length() <= 0) {
                                i2 = 0;
                            }
                            if (i2 != 0) {
                                f2 f2VarC2 = b1.c();
                                ExportPresenter$uploadProjectToServer$1$1$1$2 exportPresenter$uploadProjectToServer$1$1$1$2 = new ExportPresenter$uploadProjectToServer$1$1$1$2(exportPresenter, responseUploadProject, null);
                                this.L$0 = g0VarF;
                                this.label = 3;
                                if (kotlinx.coroutines.g.h(f2VarC2, exportPresenter$uploadProjectToServer$1$1$1$2, this) == objC) {
                                    r1 = g0VarF;
                                    return objC;
                                }
                            } else {
                                f2 f2VarC3 = b1.c();
                                ExportPresenter$uploadProjectToServer$1$1$1$3 exportPresenter$uploadProjectToServer$1$1$1$3 = new ExportPresenter$uploadProjectToServer$1$1$1$3(exportPresenter, null);
                                this.L$0 = g0VarF;
                                this.label = 4;
                                if (kotlinx.coroutines.g.h(f2VarC3, exportPresenter$uploadProjectToServer$1$1$1$3, this) == objC) {
                                    r1 = g0VarF;
                                    return objC;
                                }
                            }
                        }
                        r1 = g0VarF;
                        r1 = g0VarF;
                        r1 = g0VarF;
                        u uVar2 = u.a;
                        c.a(r1, null);
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            c.a(r1, th);
                            throw th2;
                        }
                    }
                } catch (Exception e2) {
                    f2 f2VarC4 = b1.c();
                    AnonymousClass2 anonymousClass2 = new AnonymousClass2(this.this$0, null);
                    this.L$0 = e2;
                    this.label = 5;
                    if (kotlinx.coroutines.g.h(f2VarC4, anonymousClass2, this) == objC) {
                        return objC;
                    }
                    exc = e2;
                }
                return u.a;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C09981(String str, File file, String str2, ExportPresenter exportPresenter, d<? super C09981> dVar) {
            super(2, dVar);
            this.$licenseKey = str;
            this.$file = file;
            this.$url = str2;
            this.this$0 = exportPresenter;
        }

        @Override // kotlin.y.j.a.a
        public final d<u> create(Object obj, d<?> dVar) {
            return new C09981(this.$licenseKey, this.$file, this.$url, this.this$0, dVar);
        }

        @Override // kotlin.b0.c.p
        public final Object invoke(m0 m0Var, d<? super u> dVar) {
            return ((C09981) create(m0Var, dVar)).invokeSuspend(u.a);
        }

        @Override // kotlin.y.j.a.a
        public final Object invokeSuspend(Object obj) throws Throwable {
            Object objC = kotlin.y.i.d.c();
            int i2 = this.label;
            if (i2 == 0) {
                n.b(obj);
                h0 h0VarB = b1.b();
                C02831 c02831 = new C02831(this.$licenseKey, this.$file, this.$url, this.this$0, null);
                this.label = 1;
                if (kotlinx.coroutines.g.h(h0VarB, c02831, this) == objC) {
                    return objC;
                }
            } else {
                if (i2 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                n.b(obj);
            }
            return u.a;
        }
    }

    private final void uploadProjectToServer(String str, File file, String str2) {
        getInterfaceCallbackExport().showUploadInWork();
        i.d(n1.a, null, null, new C09981(str2, file, str, this, null), 3, null);
    }

    public final void createZip_(File file, String str, boolean z) {
        j.d(file, "sourceFolder");
        j.d(str, "zipName");
        Log.d("NS", j.i("ExportPresenter.createZip: ", str));
        getInterfaceCallbackExport().showInWork();
        i.d(n1.a, null, null, new AnonymousClass1(str, file, z, this, null), 3, null);
    }

    public final InterfaceCallbackExport getInterfaceCallbackExport() {
        InterfaceCallbackExport interfaceCallbackExport = this.interfaceCallbackExport;
        if (interfaceCallbackExport != null) {
            return interfaceCallbackExport;
        }
        j.m("interfaceCallbackExport");
        throw null;
    }

    public final void onClickQr(k.a.a.a aVar) {
        String string;
        j.d(aVar, "zipProject");
        SQLiteDatabase writableDatabase = new ru.himik.nightscream.kascada.Bd.e(MyApplication.b().h0).getWritableDatabase();
        j.c(writableDatabase, "DBHelper(MyApplication.g…context).writableDatabase");
        Cursor cursorQuery = writableDatabase.query("Settings", null, null, null, null, null, null);
        j.c(cursorQuery, "db.query(\"Settings\", nul…, null, null, null, null)");
        if (cursorQuery.moveToFirst()) {
            string = cursorQuery.getString(cursorQuery.getColumnIndex(q.b(MyApplication.b().getResources().getString(R.string.v9), MyApplication.b().h0)));
            j.c(string, "c.getString(c.getColumnI…lication.get().context)))");
        } else {
            string = "";
        }
        File fileG = aVar.g();
        j.c(fileG, "zipProject.file");
        uploadProjectToServer("http://kascada-cloud.fvds.ru/projects/upload.php", fileG, string);
    }

    public final void setInterfaceCallbackExport(InterfaceCallbackExport interfaceCallbackExport) {
        j.d(interfaceCallbackExport, "<set-?>");
        this.interfaceCallbackExport = interfaceCallbackExport;
    }
}
