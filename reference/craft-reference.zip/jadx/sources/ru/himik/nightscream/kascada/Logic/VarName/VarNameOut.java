package ru.himik.nightscream.kascada.Logic.VarName;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import com.sun.mail.imap.IMAPStore;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.g;
import ru.himik.nightscream.kascada.MyApplication;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class VarNameOut extends g implements b {
    String Q;
    int R;
    int S;
    Path T;
    public int U;
    private boolean V;
    private float W;

    public VarNameOut(Context context) {
        super(context);
        this.Q = "VAR_NAME_OUT";
        this.R = 1;
        this.S = 1;
        this.T = new Path();
        this.U = 0;
        this.V = false;
        this.W = 0.0f;
        this.f9032n = "var name";
    }

    public VarNameOut(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.Q = "VAR_NAME_OUT";
        this.R = 1;
        this.S = 1;
        this.T = new Path();
        this.U = 0;
        this.V = false;
        this.W = 0.0f;
        this.f9032n = "var name";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        a aVar;
        String varName;
        Object objValueOf;
        ru.himik.nightscream.kascada.Logic.c.a aVar2 = this.f9022d;
        if (aVar2 == null || aVar2.getOut() == null) {
            return;
        }
        int i2 = this.R;
        if (i2 == 1) {
            this.V = ((Boolean) this.f9022d.getOut()).booleanValue();
            long rootUniqueIdMacro = getRootUniqueIdMacro();
            aVar = MyApplication.A0;
            if (rootUniqueIdMacro > 0) {
                varName = getRootUniqueIdMacro() + "_" + getVarName();
            } else {
                varName = getVarName();
            }
            objValueOf = Boolean.valueOf(this.V);
        } else if (i2 == 2) {
            this.U = ((Integer) this.f9022d.getOut()).intValue();
            long rootUniqueIdMacro2 = getRootUniqueIdMacro();
            aVar = MyApplication.A0;
            if (rootUniqueIdMacro2 > 0) {
                varName = getRootUniqueIdMacro() + "_" + getVarName();
            } else {
                varName = getVarName();
            }
            objValueOf = Integer.valueOf(this.U);
        } else {
            if (i2 != 3) {
                return;
            }
            this.W = ((Float) this.f9022d.getOut()).floatValue();
            long rootUniqueIdMacro3 = getRootUniqueIdMacro();
            aVar = MyApplication.A0;
            if (rootUniqueIdMacro3 > 0) {
                varName = getRootUniqueIdMacro() + "_" + getVarName();
            } else {
                varName = getVarName();
            }
            objValueOf = Float.valueOf(this.W);
        }
        aVar.h(varName, objValueOf);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("typeVar", getTypeVar());
        jSONObject.put(IMAPStore.ID_NAME, getVarName());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.Q;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 134;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public int getTypeVar() {
        return this.R;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public int getTypeVarValue() {
        return this.S;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public String getVarName() {
        return this.f9032n;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, ru.himik.nightscream.kascada.Logic.c.a
    public int o(int i2) {
        if (i2 == 1) {
            return this.R;
        }
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, android.view.View
    protected void onDraw(Canvas canvas) {
        this.T.setFillType(Path.FillType.EVEN_ODD);
        this.f9023e.setStrokeWidth(this.N);
        this.T.reset();
        this.T.moveTo(this.N, getHeight() / 2);
        this.T.lineTo(this.M, getHeight() / 2);
        this.T.lineTo(this.M * 2, this.N);
        Path path = this.T;
        int width = getWidth();
        int i2 = this.N;
        path.lineTo(width - i2, i2);
        this.T.lineTo(getWidth() - this.N, getHeight() - this.N);
        this.T.lineTo(this.M * 2, getHeight() - this.N);
        this.T.lineTo(this.M, getHeight() / 2);
        this.T.close();
        this.f9023e.setStyle(Paint.Style.FILL);
        this.f9023e.setColor(-7829368);
        canvas.drawPath(this.T, this.f9023e);
        this.f9023e.setStyle(Paint.Style.STROKE);
        this.f9023e.setColor(-16777216);
        canvas.drawPath(this.T, this.f9023e);
        canvas.drawText(this.f9032n, (getWidth() / 2) + this.M, (int) ((getHeight() / 2) - ((this.f9024f.descent() + this.f9024f.ascent()) / 2.0f)), this.f9024f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.g, android.view.View
    protected void onMeasure(int i2, int i3) {
        Paint paint;
        int color;
        setVarName(this.f9032n);
        super.onMeasure(i2, i3);
        int i4 = this.R;
        if (i4 == 1) {
            paint = this.f9024f;
            color = getResources().getColor(R.color.text_color_logic);
        } else if (i4 == 2) {
            paint = this.f9024f;
            color = -16711936;
        } else {
            if (i4 != 3) {
                return;
            }
            paint = this.f9024f;
            color = -16776961;
        }
        paint.setColor(color);
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public void setTypeVar(int i2) {
        this.R = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public void setTypeVarValue(int i2) {
        this.S = i2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.VarName.b
    public void setVarName(String str) {
        this.f9032n = str;
        requestLayout();
        invalidate();
        r();
    }
}
