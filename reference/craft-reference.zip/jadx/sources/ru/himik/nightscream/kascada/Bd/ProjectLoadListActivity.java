package ru.himik.nightscream.kascada.Bd;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import com.sun.mail.imap.IMAPStore;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes.dex */
public class ProjectLoadListActivity extends androidx.appcompat.app.d {
    c b;
    ListView c;
    ArrayList<g> a = new ArrayList<>();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final AdapterView.OnItemClickListener f8597d = new b();

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ProjectLoadListActivity.this.onBackPressed();
        }
    }

    class b implements AdapterView.OnItemClickListener {
        b() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            Intent intent = new Intent();
            intent.putExtra("TABLE_NAME_PRO", Integer.toString(ProjectLoadListActivity.this.a.get(i2).d()));
            intent.putExtra("PROJECT_NAME", ProjectLoadListActivity.this.a.get(i2).e());
            intent.putExtra("COUNT_SCREEN", ProjectLoadListActivity.this.a.get(i2).b());
            intent.putExtra("PORTRAIT_MODE", ProjectLoadListActivity.this.a.get(i2).g());
            ProjectLoadListActivity.this.setResult(-1, intent);
            ProjectLoadListActivity.this.finish();
        }
    }

    @Override // androidx.appcompat.app.d, androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, android.app.Activity
    public void onCreate(Bundle bundle) throws JSONException {
        boolean z;
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.project_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(getResources().getString(R.string.kascada));
            toolbar.setSubtitle(getResources().getString(R.string.load_project));
            setSupportActionBar(toolbar);
            getSupportActionBar().s(true);
        }
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new a());
        }
        SQLiteDatabase writableDatabase = new e(this).getWritableDatabase();
        Cursor cursorQuery = writableDatabase.query("TableNameProject", null, null, null, null, null, null);
        if (cursorQuery.moveToFirst()) {
            do {
                String string = cursorQuery.getString(cursorQuery.getColumnIndex(IMAPStore.ID_NAME));
                int i2 = cursorQuery.getInt(cursorQuery.getColumnIndex("_id"));
                int i3 = cursorQuery.getInt(cursorQuery.getColumnIndex("countDevice"));
                String string2 = cursorQuery.getString(cursorQuery.getColumnIndex("createdTime"));
                String string3 = cursorQuery.getString(cursorQuery.getColumnIndex("createdDate"));
                try {
                    z = new JSONObject(cursorQuery.getString(cursorQuery.getColumnIndex("settings"))).getBoolean("portraitMode");
                } catch (Exception unused) {
                    z = false;
                }
                this.a.add(new g(string, i2, 16, string2, string3, i3, z));
            } while (cursorQuery.moveToNext());
        } else {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.toast_no_project), 1).show();
            finish();
        }
        cursorQuery.close();
        writableDatabase.close();
        this.c = (ListView) findViewById(R.id.lvMain);
        c cVar = new c(this, this.a);
        this.b = cVar;
        this.c.setAdapter((ListAdapter) cVar);
        this.c.setOnItemClickListener(this.f8597d);
    }
}
