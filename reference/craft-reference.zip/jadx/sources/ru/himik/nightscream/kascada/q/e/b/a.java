package ru.himik.nightscream.kascada.q.e.b;

/* JADX INFO: loaded from: classes.dex */
public class a {
    public static int a(String str) {
        str.hashCode();
        switch (str) {
            case "Odd":
                return 1;
            case "Even":
                return 2;
            case "Mark":
                return 3;
            case "Space":
                return 4;
            default:
                return 0;
        }
    }

    public static int b(String str) {
        str.hashCode();
        if (str.equals("1")) {
            return 1;
        }
        return !str.equals("1.5") ? 2 : 3;
    }

    public static String c(int i2) {
        if (i2 == 1) {
            return "Odd";
        }
        if (i2 == 2) {
            return "Even";
        }
        if (i2 != 3) {
            return i2 != 4 ? "None" : "Space";
        }
        return "Mark";
    }

    public static String d(int i2) {
        if (i2 != 1) {
            return i2 != 3 ? "2" : "1,5";
        }
        return "1";
    }
}
