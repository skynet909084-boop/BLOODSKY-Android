package ru.himik.nightscream.kascada.q.c;

import android.os.Handler;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import ru.himik.nightscream.kascada.MyApplication;

/* JADX INFO: loaded from: classes.dex */
public class b {
    Socket a;
    ServerSocket c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    Handler f9255d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    a f9257f;
    int b = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    boolean f9256e = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    ArrayList<ru.himik.nightscream.kascada.q.c.a> f9258g = new ArrayList<>();

    class a extends Thread {
        Handler a;
        private boolean b = false;

        public a(Handler handler) {
            this.a = handler;
        }

        public void a() {
            try {
                b.this.c.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            this.b = true;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            b bVar;
            try {
                b bVar2 = b.this;
                bVar2.f9256e = true;
                bVar2.c = new ServerSocket(MyApplication.b().f9039g);
                this.a.obtainMessage(15, 1, 0).sendToTarget();
                while (!this.b) {
                    try {
                        try {
                            b bVar3 = b.this;
                            bVar3.a = bVar3.c.accept();
                            b bVar4 = b.this;
                            bVar4.b++;
                            String string = bVar4.a.getInetAddress().toString();
                            if (MyApplication.b().f9039g == 15020) {
                                ru.himik.nightscream.kascada.w.b.a("ModbusSlave", "connect " + string);
                            }
                            this.a.obtainMessage(15, 4, 0, string).sendToTarget();
                            b bVar5 = b.this;
                            b.this.f9258g.add(new ru.himik.nightscream.kascada.q.c.a(bVar5.a, bVar5.b, string, MyApplication.b().f9039g == 15020));
                        } catch (Exception unused) {
                            return;
                        }
                    } catch (Exception unused2) {
                        if (MyApplication.b().f9039g == 15020) {
                            ru.himik.nightscream.kascada.w.b.a("ModbusSlave", "server close");
                        }
                        this.a.obtainMessage(15, 3, 0).sendToTarget();
                        b bVar6 = b.this;
                        bVar6.f9256e = false;
                        Iterator<ru.himik.nightscream.kascada.q.c.a> it = bVar6.f9258g.iterator();
                        while (it.hasNext()) {
                            it.next().a();
                        }
                        bVar = b.this;
                    } catch (Throwable th) {
                        try {
                            if (MyApplication.b().f9039g == 15020) {
                                ru.himik.nightscream.kascada.w.b.a("ModbusSlave", "server close");
                            }
                            this.a.obtainMessage(15, 3, 0).sendToTarget();
                            b bVar7 = b.this;
                            bVar7.f9256e = false;
                            Iterator<ru.himik.nightscream.kascada.q.c.a> it2 = bVar7.f9258g.iterator();
                            while (it2.hasNext()) {
                                it2.next().a();
                            }
                            b.this.f9258g.clear();
                        } catch (Exception unused3) {
                        }
                        throw th;
                    }
                }
                if (MyApplication.b().f9039g == 15020) {
                    ru.himik.nightscream.kascada.w.b.a("ModbusSlave", "server close");
                }
                this.a.obtainMessage(15, 3, 0).sendToTarget();
                b bVar8 = b.this;
                bVar8.f9256e = false;
                Iterator<ru.himik.nightscream.kascada.q.c.a> it3 = bVar8.f9258g.iterator();
                while (it3.hasNext()) {
                    it3.next().a();
                }
                bVar = b.this;
                bVar.f9258g.clear();
            } catch (Exception unused4) {
                this.a.obtainMessage(15, 2, 0).sendToTarget();
            }
        }
    }

    public void a(Handler handler) {
        this.f9255d = handler;
    }

    public void b() {
        if (this.f9256e) {
            return;
        }
        a aVar = new a(this.f9255d);
        this.f9257f = aVar;
        aVar.start();
    }

    public void c() {
        a aVar = this.f9257f;
        if (aVar != null) {
            aVar.a();
        }
    }
}
