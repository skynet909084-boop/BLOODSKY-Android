package ru.himik.nightscream.kascada.q.f.a;

/* JADX INFO: loaded from: classes.dex */
public enum b {
    KASCADA(1),
    CLIENT_BROWSER(2);


    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final int f9281i;

    b(int i2) {
        this.f9281i = i2;
    }

    public final int getI() {
        return this.f9281i;
    }
}
