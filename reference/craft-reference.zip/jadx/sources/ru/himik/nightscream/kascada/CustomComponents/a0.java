package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class a0 extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    String C;
    String D;
    String E;
    String F;
    String G;
    String H;
    String I;
    String J;
    String K;
    boolean L;
    int M;
    int N;
    private long O;
    public Point P;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8705d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8706e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8707f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8708g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f8709h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    String f8710i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    String f8711j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    String f8712k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    String f8713l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    String f8714m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    String f8715n;
    String o;

    public a0(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_voice_recognition);
        this.f8705d = 27;
        this.f8707f = (byte) 3;
        this.f8708g = new b();
        new Paint();
        this.f8710i = "";
        this.f8711j = "";
        this.f8712k = "";
        this.f8713l = "";
        this.f8714m = "";
        this.f8715n = "";
        this.o = "";
        this.C = "";
        this.D = "";
        this.E = "";
        this.F = "";
        this.G = "";
        this.H = "";
        this.I = "";
        this.J = "";
        this.K = "";
        this.L = false;
        this.M = 0;
        this.N = 0;
        this.O = 0L;
        this.P = new Point();
    }

    public String a(int i2) {
        switch (i2) {
            case 0:
                return this.f8710i;
            case 1:
                return this.f8711j;
            case 2:
                return this.f8712k;
            case 3:
                return this.f8713l;
            case 4:
                return this.f8714m;
            case 5:
                return this.f8715n;
            case 6:
                return this.o;
            case 7:
                return this.C;
            case 8:
                return this.D;
            case 9:
                return this.E;
            case 10:
                return this.F;
            case 11:
                return this.G;
            case 12:
                return this.H;
            case 13:
                return this.I;
            case 14:
                return this.J;
            case 15:
                return this.K;
            default:
                return "";
        }
    }

    public boolean b() {
        for (int i2 = 0; i2 < 16; i2++) {
            if (a(i2).contains("#")) {
                return true;
            }
        }
        return false;
    }

    public void c(int i2, int i3, int i4, boolean z) {
        setBackgroundResource(R.drawable.tab_voice_recognition);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            int iRound = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int iRound2 = Math.round(getResources().getDimension(R.dimen.view_base_height));
            int i5 = mbCanvas.e1;
            getLayoutParams().height = iRound2;
            getLayoutParams().width = iRound;
            setY(((i3 - (iRound2 / 2)) / i5) * i5);
            setX(((i2 - (iRound / 2)) / i5) * i5);
        }
        setKey(i4);
        this.f8708g.A(this.f8705d);
        this.f8708g.L(this.f8707f);
    }

    public void d(int i2, String str) {
        switch (i2) {
            case 0:
                this.f8710i = str;
                break;
            case 1:
                this.f8711j = str;
                break;
            case 2:
                this.f8712k = str;
                break;
            case 3:
                this.f8713l = str;
                break;
            case 4:
                this.f8714m = str;
                break;
            case 5:
                this.f8715n = str;
                break;
            case 6:
                this.o = str;
                break;
            case 7:
                this.C = str;
                break;
            case 8:
                this.D = str;
                break;
            case 9:
                this.E = str;
                break;
            case 10:
                this.F = str;
                break;
            case 11:
                this.G = str;
                break;
            case 12:
                this.H = str;
                break;
            case 13:
                this.I = str;
                break;
            case 14:
                this.J = str;
                break;
            case 15:
                this.K = str;
                break;
        }
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.P.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return this.f8708g;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8705d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8709h;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.M;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.N;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8705d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList", this.f8708g.l());
        jSONObject.put("addressRegister", this.f8708g.c());
        jSONObject.put("addressBit", (int) this.f8708g.a());
        jSONObject.put("typeRequest", (int) this.f8708g.q());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("timeZ", getTimeZ());
        jSONObject.put("textVoice0", this.f8710i);
        jSONObject.put("textVoice1", this.f8711j);
        jSONObject.put("textVoice2", this.f8712k);
        jSONObject.put("textVoice3", this.f8713l);
        jSONObject.put("textVoice4", this.f8714m);
        jSONObject.put("textVoice5", this.f8715n);
        jSONObject.put("textVoice6", this.o);
        jSONObject.put("textVoice7", this.C);
        jSONObject.put("textVoice8", this.D);
        jSONObject.put("textVoice9", this.E);
        jSONObject.put("textVoice10", this.F);
        jSONObject.put("textVoice11", this.G);
        jSONObject.put("textVoice12", this.H);
        jSONObject.put("textVoice13", this.I);
        jSONObject.put("textVoice14", this.J);
        jSONObject.put("textVoice15", this.K);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8706e;
    }

    public int getNumScreen() {
        return this.f8709h;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.P;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        if (this.f8708g.l() < 0) {
            return getResources().getString(R.string.dialog_address);
        }
        if (this.f8708g.l() >= 100) {
            this.f8708g.u((byte) 1);
            return getResources().getString(R.string.dialog_address) + ": S#" + this.f8708g.c();
        }
        this.f8708g.u((byte) MyApplication.b().E.get(this.f8708g.l()).a());
        return getResources().getString(R.string.dialog_address) + ": " + ((int) this.f8708g.b()) + "#" + this.f8708g.c();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        StringBuilder sb;
        Resources resources;
        int i2;
        String string;
        if (this.f8708g.l() >= 0) {
            if (this.f8708g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                resources = getResources();
                i2 = R.string.dialog_device_system;
            } else {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name));
                sb.append(": ");
                string = MyApplication.b().E.get(this.f8708g.l()).c();
            }
            sb.append(string);
            return sb.toString();
        }
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name));
        sb.append(": ");
        resources = getResources();
        i2 = R.string.dialog_device_none;
        string = resources.getString(i2);
        sb.append(string);
        return sb.toString();
    }

    @Override // android.widget.TextView, ru.himik.nightscream.kascada.CustomComponents.z
    public float getTextSize() {
        return 0.0f;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.O;
    }

    @Override // android.widget.TextView, android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.L = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.M = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.N = i2;
    }

    public void setFont(String str) {
    }

    public void setIdComponent(int i2) {
        this.f8705d = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8706e = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8709h = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.O = j2;
    }
}
