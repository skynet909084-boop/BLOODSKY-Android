package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.util.AttributeSet;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes2.dex */
public class FB_SEL extends ru.himik.nightscream.kascada.Logic.c.d {
    private int h0;

    public FB_SEL(Context context) {
        super(context);
        this.h0 = 0;
        setName("SEL");
        s("IN", 1);
        t("I1", 2);
        u("I2", 2);
        v("Q", 2);
    }

    public FB_SEL(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.h0 = 0;
        setName("SEL");
        s("IN", 1);
        t("I1", 2);
        u("I2", 2);
        v("Q", 2);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        this.h0 = 0;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public void f() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8986g;
        if (aVar == null || this.f8987h == null || this.f8988i == null || aVar.getOut() == null || this.f8987h.getOut() == null || this.f8988i.getOut() == null) {
            return;
        }
        try {
            this.h0 = (((Boolean) this.f8986g.getOut()).booleanValue() ? (Integer) this.f8988i.getOut() : (Integer) this.f8987h.getOut()).intValue();
        } catch (Exception unused) {
        }
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public int getCountIn() {
        return 3;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        ru.himik.nightscream.kascada.Logic.c.a aVar = this.f8986g;
        if (aVar == null || this.f8987h == null || this.f8988i == null || aVar.getOut() == null || this.f8987h.getOut() == null || this.f8988i.getOut() == null) {
            return null;
        }
        return Integer.valueOf(this.h0);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return 126;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.d, ru.himik.nightscream.kascada.Logic.c.a
    public ru.himik.nightscream.kascada.Logic.c.a l(int i2) {
        if (i2 == 1) {
            return this.f8986g;
        }
        if (i2 == 2) {
            return this.f8987h;
        }
        if (i2 != 3) {
            return null;
        }
        return this.f8988i;
    }
}
