package ru.himik.nightscream.kascada.Logic.c;

import android.graphics.Point;

/* JADX INFO: loaded from: classes2.dex */
public interface a {
    void a();

    void b();

    void c();

    void d(a aVar, int i2);

    void e(a aVar);

    void f();

    boolean g();

    int getCountIn();

    int getFreeIn();

    boolean getInvertOut();

    String getJsonMacroOutIfNeed();

    int getKey();

    int getKeyOut();

    String getName();

    int getNumOnIn();

    int getNumScreen();

    Object getOut();

    Point getPointOut();

    String getRootNameMacro();

    long getRootUniqueIdMacro();

    int getSaveIdBeforeCopy();

    int getSaveIdOutBeforeCopy();

    int getSaveKey();

    int getSaveNumInBeforeCopy();

    int getTypeFb();

    int getTypeVarOut();

    boolean getVarConstant();

    float getVarFloatConstant();

    int getVarIntConstant();

    boolean h();

    void i();

    void k(int i2);

    a l(int i2);

    void m();

    Point n(int i2);

    int o(int i2);

    a q();

    void r();

    void setActionExecute(int i2);

    void setConstant(boolean z);

    void setKeyOut(int i2);

    void setNumOnIn(int i2);

    void setRootNameMacro(String str);

    void setRootUniqueIdMacro(long j2);

    void setSaveIdBeforeCopy(int i2);

    void setSaveIdOutBeforeCopy(int i2);

    void setSaveKey(int i2);

    void setSaveNumInBeforeCopy(int i2);

    void setVarConstant(boolean z);

    void setVarFloatConstant(float f2);

    void setVarIntConstant(int i2);
}
