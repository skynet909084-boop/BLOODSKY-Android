package ru.himik.nightscream.kascada.CustomComponents;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatButton;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;
import ru.kascada.modbus.R;

/* JADX INFO: loaded from: classes2.dex */
public class k extends AppCompatButton implements z, ru.himik.nightscream.kascada.s.a {
    Bitmap C;
    Paint D;
    Paint E;
    int F;
    int G;
    int H;
    int I;
    int[] J;
    boolean K;
    int L;
    int M;
    private long N;
    boolean O;
    int P;
    public Point Q;
    public String c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f8829d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int f8830e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public byte f8831f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public b f8832g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public b f8833h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public b f8834i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f8835j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f8836k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    int f8837l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f8838m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f8839n;
    private boolean o;

    public k(Context context) {
        super(context);
        this.c = getResources().getString(R.string.custom_gateway);
        this.f8829d = 19;
        this.f8831f = (byte) 16;
        this.f8832g = new b();
        this.f8833h = new b();
        this.f8834i = new b();
        this.f8836k = false;
        this.f8837l = 0;
        this.C = BitmapFactory.decodeResource(getResources(), R.drawable.warning_32);
        this.D = new Paint();
        this.E = new Paint();
        this.F = 0;
        this.G = 0;
        this.H = 0;
        this.I = 0;
        this.K = false;
        this.L = 0;
        this.M = 0;
        this.N = 0L;
        this.O = false;
        this.P = 0;
        this.Q = new Point();
    }

    public void a(int i2) {
        if (i2 != 1) {
            this.O = false;
        } else {
            if (this.O) {
                return;
            }
            mbCanvas.F(this.f8832g.k(), this.f8832g);
            this.O = true;
        }
    }

    public void b(int i2, int i3, int i4, boolean z) {
        setPadding(10, 10, 10, 10);
        setBackgroundResource(R.drawable.tab_gateway);
        if (z) {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
        } else {
            getLayoutParams().height = (int) getResources().getDimension(R.dimen.view_base_height);
            getLayoutParams().width = (int) getResources().getDimension(R.dimen.view_base_height);
            setY(i3 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
            setX(i2 - (((int) getResources().getDimension(R.dimen.view_base_height)) / 2));
        }
        setKey(i4);
    }

    public boolean c() {
        return this.o;
    }

    public boolean d() {
        return this.f8839n;
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.Q.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public boolean e() {
        return this.f8838m;
    }

    public void f() {
        this.J = new int[this.f8832g.g()];
    }

    public int getBitMode() {
        return this.I;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public b getConnectionInfo() {
        return null;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomBackground() {
        return 0;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomHeight() {
        return getHeight();
    }

    public int getCustomId() {
        return this.f8829d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomNumScreen() {
        return this.f8835j;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getCustomText() {
        return "";
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getCustomWidth() {
        return getWidth();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomX() {
        return getX();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public float getCustomY() {
        return getY();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffX() {
        return this.L;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getDiffY() {
        return this.M;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getIdComponent() {
        return this.f8829d;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonConnectionInfo() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("posDeviceNetworkInList_source", this.f8832g.l());
        jSONObject.put("addressRegister_source", this.f8832g.c());
        jSONObject.put("countRegister_source", (int) this.f8832g.g());
        jSONObject.put("typeRequest_source", (int) this.f8832g.q());
        jSONObject.put("posDeviceNetworkInList_receive", this.f8833h.l());
        jSONObject.put("addressRegister_receive", this.f8833h.c());
        jSONObject.put("posDeviceNetworkInList_trigger", this.f8834i.l());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("mode", getMode());
        jSONObject.put("regMode", getRegMode());
        jSONObject.put("bitMode", getBitMode());
        jSONObject.put("timeZ", getTimeZ());
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOtherForCopy() {
        return getJsonOther();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public int getKey() {
        return this.f8830e;
    }

    public int getMode() {
        return this.G;
    }

    public int getNumScreen() {
        return this.f8835j;
    }

    @Override // ru.himik.nightscream.kascada.s.a
    public Point getPointTouch() {
        return this.Q;
    }

    public int getRegMode() {
        return this.H;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringAddress() {
        return "";
    }

    public String getStringAddressReceive() {
        StringBuilder sb;
        String str = "#";
        if (this.f8833h.l() >= 0) {
            if (this.f8833h.l() >= 100) {
                this.f8833h.u((byte) 1);
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_address));
                str = ": S#";
            } else {
                this.f8833h.u((byte) MyApplication.b().E.get(this.f8833h.l()).a());
                sb = new StringBuilder();
            }
            sb.append(str);
            sb.append(this.f8833h.c());
            return sb.toString();
        }
        if (this.f8833h.l() == -1) {
            this.f8833h.E(0);
        }
        this.f8833h.u((byte) MyApplication.b().E.get(this.f8833h.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_address));
        sb.append(": ");
        sb.append((int) this.f8833h.b());
        sb.append(str);
        sb.append(this.f8833h.c());
        return sb.toString();
    }

    public String getStringAddressSource() {
        StringBuilder sb;
        String str = "#";
        if (this.f8832g.l() >= 0) {
            if (this.f8832g.l() >= 100) {
                this.f8832g.u((byte) 1);
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_address));
                str = ": S#";
            } else {
                this.f8832g.u((byte) MyApplication.b().E.get(this.f8832g.l()).a());
                sb = new StringBuilder();
            }
            sb.append(str);
            sb.append(this.f8832g.c());
            return sb.toString();
        }
        if (this.f8832g.l() == -1) {
            this.f8832g.E(0);
        }
        this.f8832g.u((byte) MyApplication.b().E.get(this.f8832g.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_address));
        sb.append(": ");
        sb.append((int) this.f8832g.b());
        sb.append(str);
        sb.append(this.f8832g.c());
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public String getStringNameDevice() {
        return "";
    }

    public String getStringNameDeviceReceive() {
        StringBuilder sb;
        String strC;
        if (this.f8833h.l() >= 0) {
            if (this.f8833h.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name_receive));
                sb.append(": ");
                strC = getResources().getString(R.string.dialog_device_system);
            } else {
                sb = new StringBuilder();
            }
            sb.append(strC);
            return sb.toString();
        }
        if (this.f8833h.l() == -1) {
            this.f8833h.E(0);
        }
        this.f8833h.u((byte) MyApplication.b().E.get(this.f8833h.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name_receive));
        sb.append(": ");
        strC = MyApplication.b().E.get(this.f8833h.l()).c();
        sb.append(strC);
        return sb.toString();
    }

    public String getStringNameDeviceSource() {
        StringBuilder sb;
        String strC;
        if (this.f8832g.l() >= 0) {
            if (this.f8832g.l() >= 100) {
                sb = new StringBuilder();
                sb.append(getResources().getString(R.string.dialog_device_name_source));
                sb.append(": ");
                strC = getResources().getString(R.string.dialog_device_system);
            } else {
                sb = new StringBuilder();
            }
            sb.append(strC);
            return sb.toString();
        }
        if (this.f8832g.l() == -1) {
            this.f8832g.E(0);
        }
        this.f8832g.u((byte) MyApplication.b().E.get(this.f8832g.l()).a());
        sb = new StringBuilder();
        sb.append(getResources().getString(R.string.dialog_device_name_source));
        sb.append(": ");
        strC = MyApplication.b().E.get(this.f8832g.l()).c();
        sb.append(strC);
        return sb.toString();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public long getTimeZ() {
        return this.N;
    }

    public byte getTypeRequestSource() {
        return this.f8832g.q();
    }

    public int getValueSource() {
        return this.f8837l;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f8839n || this.o) {
            this.E.setColor(-65536);
            this.E.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.E);
        }
        if (this.f8838m && mbCanvas.g1) {
            canvas.drawBitmap(this.C, getWidth() - this.C.getWidth(), getHeight() - this.C.getHeight(), this.D);
        }
        if (this.K) {
            this.E.setColor(-16711936);
            this.E.setAlpha(100);
            canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), this.E);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public boolean p() {
        return this.K;
    }

    public void setBitMode(int i2) {
        this.I = i2;
    }

    public void setConnectionErrorReceive(boolean z) {
        if (this.o != z) {
            this.o = z;
            if (z) {
                this.f8833h.J(false);
            }
            invalidate();
        }
    }

    public void setConnectionErrorSource(boolean z) {
        if (this.f8839n != z) {
            this.f8839n = z;
            if (z) {
                this.f8833h.J(false);
            }
            invalidate();
        }
    }

    public void setConnectionTimeOut(boolean z) {
        this.f8838m = z;
        if (z) {
            this.F = 0;
            if (getVisibility() == 4 && mbCanvas.a1 == this.f8835j) {
                setVisibility(0);
                invalidate();
                this.f8833h.J(false);
            }
        } else if (!this.f8839n || !this.o) {
            this.F++;
        }
        if (this.F >= 4) {
            if (getVisibility() == 0 && !this.o && !this.f8839n) {
                setVisibility(4);
                invalidate();
            }
            this.f8833h.J(true);
        }
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomSelect(boolean z) {
        this.K = z;
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setCustomVisible(int i2) {
        setVisibility(i2);
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffX(int i2) {
        this.L = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setDiffY(int i2) {
        this.M = i2;
    }

    public void setFont(String str) {
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setKey(int i2) {
        this.f8830e = i2;
    }

    public void setMode(int i2) {
        this.G = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setNumScreen(int i2) {
        this.f8835j = i2;
    }

    public void setPosDeviceNetworkInList(int i2) {
        (this.f8836k ? this.f8832g : this.f8833h).E(i2);
    }

    public void setRegMode(int i2) {
        this.H = i2;
    }

    @Override // ru.himik.nightscream.kascada.CustomComponents.z
    public void setTimeZ(long j2) {
        this.N = j2;
    }

    public void setTypeRequestSource(byte b) {
        if (b == 3 || b == 4) {
            this.f8832g.L(b);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x004a, code lost:
    
        if (r9.f8833h.l() != 100) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x004d, code lost:
    
        r9.f8838m = true;
        invalidate();
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00a2, code lost:
    
        if (r9.f8833h.l() != 100) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:?, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void setValueSource(int[] iArr) {
        int i2 = this.G;
        if (i2 == 0) {
            for (int i3 = 0; i3 < iArr.length; i3 += 2) {
                int[] iArr2 = this.J;
                int i4 = this.P;
                iArr2[i4] = (iArr[i3] * 256) + iArr[i3 + 1];
                this.P = i4 + 1;
            }
            this.P = 0;
            this.f8833h.w(this.J);
            if (this.f8832g.g() == 1) {
                this.f8833h.H(this.J[0]);
            }
            this.f8833h.J(true);
            return;
        }
        if (i2 != 1) {
            if (i2 != 2) {
                return;
            }
            int[] iArr3 = this.J;
            if (iArr3[0] != (iArr[0] * 256) + iArr[1]) {
                iArr3[0] = (iArr[0] * 256) + iArr[1];
                this.f8833h.w(iArr3);
                if (this.f8832g.g() == 1) {
                    this.f8833h.H(this.J[0]);
                }
                if (this.f8833h.k() == -1) {
                }
                mbCanvas.F(this.f8833h.k(), this.f8833h);
            }
            return;
        }
        for (int i5 = 0; i5 < iArr.length; i5 += 2) {
            int[] iArr4 = this.J;
            int i6 = this.P;
            iArr4[i6] = (iArr[i5] * 256) + iArr[i5 + 1];
            this.P = i6 + 1;
        }
        this.P = 0;
        this.f8833h.w(this.J);
        if (this.f8832g.g() == 1) {
            this.f8833h.H(this.J[0]);
        }
        if (this.f8833h.k() == -1) {
        }
        mbCanvas.F(this.f8833h.k(), this.f8833h);
    }
}
