package ru.himik.nightscream.kascada.Logic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import com.karumi.dexter.R;
import org.json.JSONException;
import org.json.JSONObject;
import ru.himik.nightscream.kascada.Logic.c.f;
import ru.himik.nightscream.kascada.MyApplication;
import ru.himik.nightscream.kascada.mbCanvas;

/* JADX INFO: loaded from: classes2.dex */
public class VarInt extends f implements e {
    int V;
    public String W;

    public VarInt(Context context) {
        super(context);
        this.V = 0;
        this.W = "VAR_INT";
    }

    public VarInt(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.V = 0;
        this.W = "VAR_INT";
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void b() {
        invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getBit() {
        return this.D;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.CustomComponents.z
    public JSONObject getJsonOther() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("reg", 0);
        jSONObject.put("isConstant", g());
        jSONObject.put("constant", getVarIntConstant());
        jSONObject.put("numScreen", getNumScreen());
        jSONObject.put("invertOut", getInvertOut());
        jSONObject.put("saveKey", getKey());
        jSONObject.put("numOnIn", getNumOnIn());
        jSONObject.put("keyOut", q() != null ? q().getKey() : -1);
        return jSONObject;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public String getName() {
        return this.W + " " + this.C;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public Object getOut() {
        int I;
        if (this.o) {
            I = this.V;
        } else {
            I = MyApplication.b().v0 != null ? MyApplication.b().v0.I(this.C) : 0;
        }
        return Integer.valueOf(I);
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public int getReg() {
        return this.C;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeFb() {
        return R.styleable.AppCompatTheme_textAppearanceSearchResultSubtitle;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getTypeVarOut() {
        return 2;
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public int getVarIntConstant() {
        return this.V;
    }

    @Override // ru.himik.nightscream.kascada.Logic.e
    public void j(int i2, int i3) {
        if (i2 < 0 || i2 > ru.himik.nightscream.kascada.q.d.b.F || i3 < 0 || i3 > 15) {
            return;
        }
        this.C = i2;
        this.D = i3;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onDraw(Canvas canvas) {
        RectF rectF = this.G;
        int i2 = this.R;
        rectF.set(i2, i2, getWidth() - this.Q, getHeight() - this.R);
        this.f9013f.setStyle(Paint.Style.FILL);
        this.f9013f.setColor(-7829368);
        RectF rectF2 = this.G;
        int i3 = this.Q;
        canvas.drawRoundRect(rectF2, i3, i3, this.f9013f);
        this.f9013f.setStyle(Paint.Style.STROKE);
        this.f9013f.setColor(-16777216);
        RectF rectF3 = this.G;
        int i4 = this.Q;
        canvas.drawRoundRect(rectF3, i4, i4, this.f9013f);
        canvas.drawText(this.E, (getWidth() / 2) - (this.Q / 2), (int) ((getHeight() / 2) - ((this.f9014g.descent() + this.f9014g.ascent()) / 2.0f)), this.f9014g);
        canvas.drawLine(getWidth() - this.Q, getHeight() / 2, getWidth(), getHeight() / 2, this.f9013f);
        super.onDraw(canvas);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, android.view.View
    protected void onMeasure(int i2, int i3) {
        StringBuilder sb;
        if (this.o) {
            sb = new StringBuilder();
            sb.append(this.V);
            sb.append("");
        } else {
            sb = new StringBuilder();
            sb.append("S#");
            sb.append(this.C);
        }
        this.E = sb.toString();
        super.onMeasure(i2, i3);
    }

    @Override // ru.himik.nightscream.kascada.Logic.c.f, ru.himik.nightscream.kascada.Logic.c.a
    public void setVarIntConstant(int i2) {
        this.V = i2;
        requestLayout();
        invalidate();
        r();
        mbCanvas.f1.invalidate();
    }
}
