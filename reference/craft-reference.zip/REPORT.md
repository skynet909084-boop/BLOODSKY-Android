# BLOODSKY — отчёт декомпиляции

- Repository: skynet909084-boop/BLOODSKY-Android
- Run: 38600957172
- Commit: 44c48c85c2b52d7c13dfacede62b3116fa61ada0

## Количество файлов
- JADX: 11080
- Apktool: 15193

См. журналы jadx.log и apktool.log. Декомпиляция может содержать ошибки.
