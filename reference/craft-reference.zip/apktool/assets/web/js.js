		/*ver 1.0 (24.12.17) Created by NightScream 
		* ver 1.1 (30.12.17) изменение списка экранов только по изменению
		*/

		var canvas = new fabric.Canvas('canvas_');
		var imgBg = new Image();//Картинка background
		var timeLoad = 0.0;
		var lastTimeLoad = 0.0;
		var textTimeLoad;
		var textSaveTimeLoad;
		var work = false;
		var sendScreen = 0;//номер экрана который был отослан последний как скриншот (для синхронизации с кнопками)

		function incTimeLoad() {
		    timeLoad += 0.2;
		    textTimeLoad.text(timeLoad.toFixed(1));
		}
		
		window.onload = function () {
			textTimeLoad = $( "#textTimeLoad" );
			textSaveTimeLoad = $( "#textSaveTimeLoad" );
			$.ajax({
				url: 'getSizeScreen',
				data: {},
				success: function(response){
					//console.log("sizeScreen: " + response);
					var proRec = jQuery.parseJSON(response);
					canvas.setHeight(proRec.h / 2);
					canvas.setWidth(proRec.w / 2);
					canvas.selection = false;
				},
				error: function(){
					alert("Ошибка запроса размеров экрана");
				}
			});
			
			imgBg.onload = function(){
				//console.log("bg onLoad");
			    canvas.setBackgroundImage(imgBg.src, canvas.renderAll.bind(canvas), {
			        width: canvas.width,
					height: canvas.height,
					originX: 'left',
					originY: 'top'
			        });
			    textSaveTimeLoad.text(timeLoad.toFixed(1));
			    timeLoad = 0.0;
			    loadControlObject();
			    loadParams();
			    imgBg.src = "/KaScadaGetMeScreenShotPlease?g="+ Math.random();
			};
			imgBg.onerror = function(){
				setTimeout(imgBg.src = "/KaScadaGetMeScreenShotPlease?g="+ Math.random(), 1000);
			}

			imgBg.src = "/KaScadaGetMeScreenShotPlease?g="+ Math.random();
		};

		function clearObj(){
			var arrObj = canvas.getObjects();
			while(arrObj.length != 0){
			  arrObj[0].remove();
			}
		}

		function loadControlObject(){
			$.ajax({
				url: 'getControlObject',
				data: {screen:sendScreen},
				success: function(response){
					//console.log("getControlObject: " + response);
					clearObj();
					var json = jQuery.parseJSON(response);
					for(var i = 0; i < json.length; i++) {
						var obj = json[i];
						switch(obj.id){
							case 1://switch id,key,x,y,w,h,screen
								var cb = new CustomButton(obj.id,obj.key,obj.x / 2,obj.y / 2,obj.w / 2,obj.h / 2,obj.screen);
								canvas.add(cb.getObj());
								break;
							case 6://button id,key,x,y,w,h,screen
								var cb = new CustomButton(obj.id,obj.key,obj.x / 2,obj.y / 2,obj.w / 2,obj.h / 2,obj.screen);
								canvas.add(cb.getObj());
								break;
							case 8://editNumber id,key,x,y,w,h,screen,password,type,min,max
								var cb = new CustomEditNumber(obj.id,obj.key,obj.x / 2,obj.y / 2,obj.w / 2,obj.h / 2,obj.screen,obj.password,obj.type,obj.min,obj.max);
								canvas.add(cb.getObj());
								break;
							case 13://seekBar id,key,x,y,w,h,screen,max
								var cb = new CustomSeekBar(obj.id,obj.key,obj.x / 2,obj.y / 2,obj.w / 2,obj.h / 2,obj.screen,obj.max);
								canvas.add(cb.getObj());
								break;
						}
					}
					canvas.renderAll();
				},
				error: function(jqXHR, textStatus, errorThrown){
					if(jqXHR.status != 404)//потому что изначально sendScreen = 0
						alert("Ошибка запроса задатчиков");
				}
			});
		}
		
		function loadParams(){
			$.ajax({
				url: 'getParams',
				data: {},
				success: function(response){
					//console.log("getParams: " + response);
					var json = jQuery.parseJSON(response);
					work = json.work;
					sendScreen = json.sendScreen;
					var Screens = json["Screens"];

					var optScreen = document.getElementById("SelectScreen");

					if (Screens.length == optScreen.options.length) {
						for (i = 0; i < optScreen.options.length; i++) {
					        optScreen.options[i].value;
					        var obj = Screens[i];
							if (obj.pass){ 
								if(optScreen.options[i].value == ("*" + obj.num + ". " + obj.name)){
								}else{
									//обновление, пароль сменился
									updateScreen(Screens);
									return;
								}	

							}else{
								if(optScreen.options[i].value == (obj.num + ". " + obj.name)){
								}else{
									//обновление, имя экрана сменилось
									updateScreen(Screens);
									return;
								}	
							}
				    	}
				    }else{
				    	//Обновление по несовпадению кол-ва экранов пришло != в списке
				    	updateScreen(Screens);
				    }

					

				},
				error: function(){
					alert("Ошибка запроса CustomButton");
				}
			});
		}

		function updateScreen(Screens){
			removeOptionsScreen();
			for(var i = 0; i < Screens.length; i++) {
				var obj = Screens[i];
				if (obj.pass) 
					addOptionScreen("*" + obj.num + ". " + obj.name);	
				else
					addOptionScreen(obj.num + ". " + obj.name);
			}
			document.getElementById("SelectScreen").selectedIndex = sendScreen - 1;
		}

		//Удаление всех элементов из option
		function removeOptionsScreen(){
			var optScreen = document.getElementById("SelectScreen");
		    var i;
		    for(i = optScreen.options.length - 1 ; i >= 0 ; i--){
		        optScreen.remove(i);
		    }
		}
		//Добавление в конец списка одного элемента
		function addOptionScreen(name) {
		    var x = document.getElementById("SelectScreen");
		    var option = document.createElement("option");
		    option.text = name;
		    x.add(option);
		}
		//Обработчик выбора элемента в списке экранов
		function onChangeOptionScreen(){
			var screen = document.getElementById("SelectScreen").selectedIndex + 1;
			if(document.getElementById("SelectScreen").value.charAt(0) == '*'){
				var setPass = prompt("Экран требует ввод пароля");
				if(setPass == null) return;
				var xhr = new XMLHttpRequest();
				xhr.open("GET", "/changeScreen?screen=" + screen +"&pass=" + setPass, true);
				xhr.send();	
			}else{
				var xhr = new XMLHttpRequest();
				xhr.open("GET", "/changeScreen?screen=" + screen +"&pass=" + "0", true);
				xhr.send();	
			}
		}

		//SeekBar
		class CustomSeekBar {
			constructor(id,key,x,y,w,h,screen,max) {
				var parent = this;
		        this.id = id;
		        this.key = key;
		        this.screen = screen;
		        this.max = max;
		        this.obj = new fabric.Rect({
		            top : y,
		            left : x,
		            width : w,
		            height : h,
		            fill: 'rgba(0,0,0,0)',
		            stroke: 'rgba(34,177,76,1)',
       				strokeWidth: 1

		        });
		        this.obj.set({
		    		selectable: false,
			        lockMovementY: true,
			        lockMovementX: true,
			        hasBorders: false,
			        hasControls: false,
			        hoverCursor: 'pointer'
				 });
		        this.obj.setControlsVisibility({
			        mt: true,// 
			        mb: true,// 
			        ml: true,// 
			        mr: true,// 
			        bl: true,
			        br: true, 
			        tl: true, 
			        tr: true,
			        mtr: false
		    	});

		    	this.obj.on('mousedown', function(e) { 
		    		if (!work) return;
					var setPos = prompt('Укажите значение от 0 до ' + parent.max);
					if(setPos == null) return;
					setPos = parseInt(setPos,10);
					if(!isNaN(setPos)){
			    		var xhr = new XMLHttpRequest();
						xhr.open("GET", "/onClick?id=" + parent.getId() +"&key=" + parent.getKey() + "&val=" + setPos, true);
						xhr.send();
					}else{
						alert('Недопустимое значение!');
					}
				});
				
		    }

			getId(){
				return this.id;
			}

			getKey(){
				return this.key;
			}

			setId(id){
				this.id = id;
			}

			getObj(){
				return this.obj;
			}

			moveTo(x,y){
				this.obj.set({ left: x, top: y });
		        this.obj.setCoords();//Âûçûâàòü îáÿçàòåëüí
			}

		};

		//EditNumber
		class CustomEditNumber {
			constructor(id,key,x,y,w,h,screen,password,type,min,max) {
				var parent = this;
		        this.id = id;
		        this.key = key;
		        this.screen = screen;
		        this.password = password;
		        this.type = type;
		        this.min = min;
		        this.max = max;
		        this.obj = new fabric.Rect({
		            top : y,
		            left : x,
		            width : w,
		            height : h,
		            fill: 'rgba(0,0,0,0)',
		            stroke: 'rgba(34,177,76,1)',
       				strokeWidth: 1

		        });
		        this.obj.set({
		    		selectable: false,
			        lockMovementY: true,
			        lockMovementX: true,
			        hasBorders: false,
			        hasControls: false,
			        hoverCursor: 'pointer'
				 });
		        this.obj.setControlsVisibility({
			        mt: true,// 
			        mb: true,// 
			        ml: true,// 
			        mr: true,// 
			        bl: true,
			        br: true, 
			        tl: true, 
			        tr: true,
			        mtr: false
		    	});

		    	this.obj.on('mousedown', function(e) { 
		    		if (!work) return;
					var setPos = prompt('Укажите значение от ' + parent.min + ' до ' + parent.max);
					if(setPos == null) return;
					setPos = parseFloat(setPos);
					if(!isNaN(setPos)){
						if (parent.password) {
							var setPass = prompt("Задатчик требует ввод пароля");
							if(setPass == null) return;
							var xhr = new XMLHttpRequest();
							xhr.open("GET", "/onClick?id=" + parent.getId() +"&key=" + parent.getKey() + "&val=" + setPos + "&pass=" + setPass, true);
							xhr.send();
				    	}else{
				    		var xhr = new XMLHttpRequest();
							xhr.open("GET", "/onClick?id=" + parent.getId() +"&key=" + parent.getKey() + "&val=" + setPos + "&pass=" + 0, true);
							xhr.send();
				    	}
					}else{
						alert('Недопустимое значение!');
					}
				});
				
		    }

			getId(){
				return this.id;
			}

			getKey(){
				return this.key;
			}

			setId(id){
				this.id = id;
			}

			getObj(){
				return this.obj;
			}

			moveTo(x,y){
				this.obj.set({ left: x, top: y });
		        this.obj.setCoords();//Âûçûâàòü îáÿçàòåëüí
			}

		};

		//Button and Switch
		class CustomButton {
			constructor(id,key,x,y,w,h,screen) {
				var parent = this;
		        this.id = id;
		        this.key = key;
		        this.screen = screen;
		        this.obj = new fabric.Rect({
		            top : y,
		            left : x,
		            width : w,
		            height : h,
		            fill: 'rgba(0,0,0,0)',
		            stroke: 'rgba(34,177,76,1)',
       				strokeWidth: 1

		        });
		        this.obj.set({
		    		selectable: false,
			        lockMovementY: true,
			        lockMovementX: true,
			        hasBorders: false,
			        hasControls: false,
			        hoverCursor: 'pointer'
				 });
		        this.obj.setControlsVisibility({
			        mt: true,// 
			        mb: true,// 
			        ml: true,// 
			        mr: true,// 
			        bl: true,
			        br: true, 
			        tl: true, 
			        tr: true,
			        mtr: false
		    	});

		    	this.obj.on('mousedown', function(e) { 
				   if (work) {
					    var xhr = new XMLHttpRequest();
						xhr.open("GET", "/onClick?id=" + parent.getId() +"&key=" + parent.getKey(), true);
						xhr.send();
					}
				});
				
		    }

			getId(){
				return this.id;
			}

			getKey(){
				return this.key;
			}

			setId(id){
				this.id = id;
			}

			getObj(){
				return this.obj;
			}

			moveTo(x,y){
				this.obj.set({ left: x, top: y });
		        this.obj.setCoords();//Âûçûâàòü îáÿçàòåëüí
			}

		};

		setInterval(incTimeLoad, 200);