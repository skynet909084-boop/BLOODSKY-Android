function getJS(){
    alert('Hi, kascada');
}